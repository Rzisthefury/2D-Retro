/* Drive the built game in a real browser: click through title -> difficulty ->
   dialogue -> preparations -> battle, take a move, attack, undo, end the turn,
   and fail on any console error. Run: node test/browser.js */

const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const FILE = 'file://' + path.join(__dirname, '..', 'dist', 'Sundered Crown.html');
const SHOTS = path.join(__dirname, '..', 'dist', 'shots');

(async () => {
  if (!fs.existsSync(SHOTS)) fs.mkdirSync(SHOTS, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  let fails = 0;
  const errors = [];

  async function run(label, width, height) {
    const ctx = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: 2 });
    const page = await ctx.newPage();
    // the sandbox has no egress to fonts.googleapis.com; a blocked webfont is an
    // environment limit, not a page fault, and the fallback stacks cover it
    const NETWORK_NOISE = /ERR_TUNNEL_CONNECTION_FAILED|ERR_NAME_NOT_RESOLVED|fonts\.(googleapis|gstatic)\.com/;
    page.on('console', m => {
      if (m.type() !== 'error') return;
      if (NETWORK_NOISE.test(m.text())) return;
      errors.push(label + ': ' + m.text());
    });
    page.on('pageerror', e => { errors.push(label + ' PAGEERROR: ' + e.message); });

    await page.goto(FILE);
    await page.waitForTimeout(500);

    const shot = n => page.screenshot({ path: path.join(SHOTS, label + '-' + n + '.png') });

    await shot('1-title');

    // New Campaign
    await page.getByRole('button', { name: 'New Campaign' }).click();
    await page.waitForTimeout(300);
    await shot('2-difficulty');

    // Normal
    await page.locator('.diff-card').first().click();
    await page.waitForTimeout(300);

    // click through the opening dialogue
    for (let i = 0; i < 10; i++) {
      const dlg = page.locator('.dialog-box');
      if (await dlg.count() === 0) break;
      if (i === 0) {
        await shot('3-dialogue');
        // the speaker portrait must actually be drawn, not a blank box
        const por = await page.evaluate(() => {
          const cv = document.querySelector('.dlg-por canvas');
          if (!cv) return { missing: true };
          const g = cv.getContext('2d');
          const d = g.getImageData(0, 0, cv.width, cv.height).data;
          const seen = {};
          let opaque = 0;
          for (let k = 0; k < d.length; k += 4) {
            if (d[k + 3] < 20) continue;
            opaque++;
            seen[d[k] + ',' + d[k + 1] + ',' + d[k + 2]] = 1;
          }
          return { w: cv.width, h: cv.height, colours: Object.keys(seen).length, fill: opaque / (cv.width * cv.height) };
        });
        if (por.missing) errors.push(label + ': the dialogue speaker has no portrait canvas');
        else {
          if (por.colours < 8) errors.push(label + ': the portrait uses only ' + por.colours + ' colours - it is not a detailed face');
          if (por.fill < 0.25) errors.push(label + ': the portrait canvas is mostly empty (' + Math.round(por.fill * 100) + '% drawn)');
        }
      }
      await page.locator('.modal-back').last().click({ position: { x: 20, y: 20 } });
      await page.waitForTimeout(140);
    }

    await page.waitForTimeout(300);
    await shot('4-prep');

    // check the prep screen rendered units
    const cards = await page.locator('.unit-card').count();
    if (cards < 4) { errors.push(label + ': prep screen shows ' + cards + ' units, expected 4'); }

    // open a unit info sheet and back out
    await page.locator('.unit-card .btn', { hasText: 'Info' }).first().click();
    await page.waitForTimeout(250);
    await shot('5-unitinfo');
    const statRows = await page.locator('.st').count();
    if (statRows < 9) errors.push(label + ': stat sheet shows ' + statRows + ' stats, expected 10');
    await page.getByRole('button', { name: 'Close' }).last().click();
    await page.waitForTimeout(200);

    // shop
    await page.getByRole('button', { name: 'Shop' }).click();
    await page.waitForTimeout(250);
    await shot('8-shop');
    const goldBefore = await page.locator('.shop-gold').textContent();
    await page.locator('.shop-card').first().click();
    await page.waitForTimeout(200);
    const goldAfter = await page.locator('.shop-gold').textContent();
    if (goldBefore === goldAfter) errors.push(label + ': buying did not change gold');

    // selling: from the convoy, and from what a deployed unit is carrying
    const sold = await page.evaluate(async () => {
      const g = () => parseInt(document.querySelector('.shop-gold').textContent.replace(/\D/g, ''), 10);
      const sellBtns = () => [...document.querySelectorAll('.btn')].filter(x => /^Sell \d+g$/.test(x.textContent));
      const chips = () => [...document.querySelectorAll('.chip')];
      const out = { sources: chips().map(c => c.textContent) };
      // convoy first
      let before = g();
      let bs = sellBtns();
      out.convoyOffered = bs.length;
      if (bs.length) {
        bs[0].click();
        await new Promise(r => setTimeout(r, 150));
        out.convoyGain = g() - before;
      }
      // then a unit's own bag
      const unitChip = chips()[1];
      if (!unitChip) return out;
      unitChip.click();
      await new Promise(r => setTimeout(r, 150));
      bs = sellBtns();
      out.unitOffered = bs.length;
      if (bs.length) {
        before = g();
        bs[0].click();
        await new Promise(r => setTimeout(r, 150));
        out.unitGain = g() - before;
      }
      return out;
    });
    if ((sold.sources || []).length < 2) errors.push(label + ': the shop offers no unit to sell from (' + JSON.stringify(sold.sources) + ')');
    if (!sold.convoyOffered) errors.push(label + ': nothing in the convoy could be sold');
    else if (!(sold.convoyGain > 0)) errors.push(label + ': selling from the convoy paid nothing');
    if (!sold.unitOffered) errors.push(label + ": a deployed unit's items were not offered for sale");
    else if (!(sold.unitGain > 0)) errors.push(label + ': selling a unit\'s weapon paid nothing');

    await page.getByRole('button', { name: 'Done' }).click();
    await page.waitForTimeout(250);

    // start the chapter
    await page.getByRole('button', { name: 'Begin Chapter' }).click();
    await page.waitForTimeout(900);
    await shot('9-battle');

    // the map canvas must have drawn something other than the background
    const painted = await page.evaluate(() => {
      const c = document.getElementById('map');
      const g = c.getContext('2d');
      const d = g.getImageData(0, 0, c.width, c.height).data;
      const seen = new Set();
      for (let i = 0; i < d.length; i += 4 * 97) seen.add(d[i] + ',' + d[i + 1] + ',' + d[i + 2]);
      return seen.size;
    });
    if (painted < 8) errors.push(label + ': map canvas only has ' + painted + ' distinct colours - not drawing');

    // engine state sanity
    const st = await page.evaluate(() => {
      const s = window.FE.G.state;
      return {
        units: s.units.length,
        players: s.units.filter(u => u.faction === 'player').length,
        enemies: s.units.filter(u => u.faction === 'enemy').length,
        turn: s.turn, phase: s.phase,
        w: s.map.w, h: s.map.h
      };
    });
    if (st.players !== 4) errors.push(label + ': deployed ' + st.players + ' players, expected 4');
    if (st.enemies < 6) errors.push(label + ': ' + st.enemies + ' enemies on the field');

    // select a unit by tapping its tile, then move it
    const moved = await page.evaluate(async () => {
      const FE = window.FE, G = FE.G;
      const u = G.state.units.find(x => x.faction === 'player' && x.id === 'bram');
      FE.centerOn(G.state, u.x, u.y);
      const wrap = document.getElementById('map-wrap');
      const r = wrap.getBoundingClientRect();
      const ts = FE.tileSize();
      const sx = u.x * ts - FE.R.camX + ts / 2 + r.left;
      const sy = u.y * ts - FE.R.camY + ts / 2 + r.top;
      function tap(x, y) {
        ['pointerdown', 'pointerup'].forEach(t => {
          wrap.dispatchEvent(new PointerEvent(t, { clientX: x, clientY: y, bubbles: true, isPrimary: true }));
        });
      }
      tap(sx, sy);
      await new Promise(r2 => setTimeout(r2, 120));
      const selected = G.selected === u.uid && G.mode === 'move';
      const overlayCount = G.overlay ? Object.keys(G.overlay).length : 0;
      return { selected, overlayCount, ux: u.x, uy: u.y };
    });
    if (!moved.selected) errors.push(label + ': tapping a unit did not select it');
    if (moved.overlayCount < 5) errors.push(label + ': movement overlay has ' + moved.overlayCount + ' tiles');
    await shot('10-moverange');

    // move it a tile and confirm the action menu opens
    const menu = await page.evaluate(async () => {
      const FE = window.FE, G = FE.G;
      const u = G.selectedUnit;
      const dest = Object.keys(G.stand).map(k => k.split(',').map(Number))
        .filter(([x, y]) => !(x === u.x && y === u.y))
        .sort((a, b) => (G.stand[a[0] + ',' + a[1]] - G.stand[b[0] + ',' + b[1]]))[2];
      const wrap = document.getElementById('map-wrap');
      const r = wrap.getBoundingClientRect();
      const ts = FE.tileSize();
      function tap(x, y) {
        ['pointerdown', 'pointerup'].forEach(t => {
          wrap.dispatchEvent(new PointerEvent(t, { clientX: x, clientY: y, bubbles: true, isPrimary: true }));
        });
      }
      tap(dest[0] * ts - FE.R.camX + ts / 2 + r.left, dest[1] * ts - FE.R.camY + ts / 2 + r.top);
      await new Promise(r2 => setTimeout(r2, 900));
      return {
        open: document.getElementById('actionmenu').classList.contains('open'),
        buttons: [...document.querySelectorAll('#actionmenu .btn')].map(b => b.textContent),
        at: [u.x, u.y], dest,
        undoDepth: window.FE.Undo.depth(G.state)
      };
    });
    if (!menu.open) errors.push(label + ': action menu did not open after moving');
    if (!menu.buttons.includes('Wait')) errors.push(label + ': action menu missing Wait: ' + menu.buttons.join('/'));
    await shot('11-actionmenu');

    // Wait, then verify undo restores the unit
    await page.evaluate(() => {
      [...document.querySelectorAll('#actionmenu .btn')].find(b => b.textContent === 'Wait').click();
    });
    await page.waitForTimeout(400);

    const undone = await page.evaluate(async () => {
      const FE = window.FE, G = FE.G;
      const before = G.state.units.find(u => u.id === 'bram');
      const posBefore = [before.x, before.y, before.acted];
      document.getElementById('btn-undo').click();
      await new Promise(r => setTimeout(r, 300));
      const after = G.state.units.find(u => u.id === 'bram');
      return { posBefore, posAfter: [after.x, after.y, after.acted] };
    });
    if (JSON.stringify(undone.posBefore) === JSON.stringify(undone.posAfter)) {
      errors.push(label + ': undo did not revert the move');
    }
    await shot('12-afterundo');

    // ---- click accuracy: a real pointer event at a tile centre must hit
    // that tile, at several places across the board, not just the middle
    const aim = await page.evaluate(async () => {
      const FE = window.FE, G = FE.G;
      const wrap = document.getElementById('map-wrap');
      const r = wrap.getBoundingClientRect();
      const ts = FE.tileSize();
      const out = [];
      const spots = [];
      for (let i = 0; i < 12; i++) {
        const x = 1 + ((i * 5) % (G.state.map.w - 2));
        const y = 1 + ((i * 3) % (G.state.map.h - 2));
        spots.push([x, y]);
      }
      for (const [tx, ty] of spots) {
        FE.centerOn(G.state, tx, ty);
        const sx = tx * ts - FE.R.camX + ts / 2;
        const sy = ty * ts - FE.R.camY + ts / 2;
        if (sx < 0 || sy < 0 || sx > r.width || sy > r.height) continue;
        ['pointerdown', 'pointerup'].forEach(t => {
          wrap.dispatchEvent(new PointerEvent(t, {
            clientX: sx + r.left, clientY: sy + r.top, bubbles: true, isPrimary: true
          }));
        });
        await new Promise(res => setTimeout(res, 30));
        out.push({ want: [tx, ty], got: [G.cursor.x, G.cursor.y] });
      }
      return out;
    });
    const missed = aim.filter(a => a.want[0] !== a.got[0] || a.want[1] !== a.got[1]);
    if (missed.length) {
      errors.push(label + ': ' + missed.length + '/' + aim.length + ' clicks hit the wrong tile, e.g. '
        + JSON.stringify(missed[0]));
    }

    // the canvas backing store must match its CSS box or everything is offset
    const fit = await page.evaluate(() => {
      const c = document.getElementById('map');
      const r = c.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      return { bw: c.width, bh: c.height, cw: Math.round(r.width * dpr), ch: Math.round(r.height * dpr) };
    });
    if (Math.abs(fit.bw - fit.cw) > 2 || Math.abs(fit.bh - fit.ch) > 2) {
      errors.push(label + ': canvas backing ' + fit.bw + 'x' + fit.bh + ' does not match its box ' + fit.cw + 'x' + fit.ch);
    }

    // ---- staff: no option at full health, one click to heal when wounded
    const staff = await page.evaluate(async () => {
      const FE = window.FE, G = FE.G;
      const mira = G.state.units.find(u => u.id === 'mira');
      const dorn = G.state.units.find(u => u.id === 'dorn');
      if (!mira || !dorn) return { skip: true };

      // stand them next to each other, everyone at full health
      G.state.units.forEach(u => { if (u.faction === 'player') u.hp = u.maxhp; });
      dorn.x = mira.x + 1; dorn.y = mira.y;
      FE.recomputeSupports(G.state);

      const atFull = window.FE.G._testStaffTargets
        ? window.FE.G._testStaffTargets(mira).length
        : null;

      dorn.hp = Math.max(1, dorn.maxhp - 9);
      const wounded = window.FE.G._testStaffTargets(mira).length;
      const before = dorn.hp;

      // run the real action flow: open the menu, hit Staff, click the ally
      mira.acted = false; mira.moved = true;
      G.selectedUnit = mira; G.selected = mira.uid;
      window.FE.G._testOpenMenu(mira);
      const labels = [...document.querySelectorAll('#actionmenu .btn')].map(b => b.textContent);
      const staffBtn = [...document.querySelectorAll('#actionmenu .btn')].find(b => b.textContent === 'Staff');
      if (!staffBtn) return { atFull, wounded, labels, healed: false, reason: 'no Staff button' };
      staffBtn.click();
      await new Promise(r => setTimeout(r, 150));
      const mode = G.mode, hasPending = !!G.pendingTarget;

      // click the wounded ally on the map
      const wrap = document.getElementById('map-wrap');
      const r2 = wrap.getBoundingClientRect();
      const ts = FE.tileSize();
      FE.centerOn(G.state, dorn.x, dorn.y);
      const sx = dorn.x * ts - FE.R.camX + ts / 2 + r2.left;
      const sy = dorn.y * ts - FE.R.camY + ts / 2 + r2.top;
      ['pointerdown', 'pointerup'].forEach(t => {
        wrap.dispatchEvent(new PointerEvent(t, { clientX: sx, clientY: sy, bubbles: true, isPrimary: true }));
      });
      await new Promise(r3 => setTimeout(r3, 700));
      return { atFull, wounded, labels, mode, hasPending, before, after: dorn.hp, healed: dorn.hp > before };
    });
    if (!staff.skip) {
      if (staff.atFull !== 0) errors.push(label + ': staff offered ' + staff.atFull + ' targets at full health, expected 0');
      if (staff.wounded < 1) errors.push(label + ': staff offered no target for a wounded ally');
      if (!staff.healed) errors.push(label + ': clicking the ally did not heal (' + JSON.stringify(staff) + ')');
    }
    await shot('13-staff');

    // ---- an enemy that can reach a unit must attack, even into a bad counter
    const aggression = await page.evaluate(() => {
      const FE = window.FE, G = FE.G;
      const st = G.state;
      const foe = st.units.find(u => u.faction === 'enemy' && !u.boss && u.alive);
      const target = st.units.find(u => u.faction === 'player' && u.alive);
      if (!foe || !target) return { skip: true };
      // park it right next to a unit that will counter hard, and hurt it badly
      foe.x = target.x + 1; foe.y = target.y;
      foe.hp = 1;
      foe.ai = 'aggressive'; foe.awake = true;
      FE.recomputeSupports(st);
      const act = FE.aiDecide(st, foe);
      return { type: act && act.type, hp: foe.hp };
    });
    if (!aggression.skip && aggression.type !== 'attack') {
      errors.push(label + ': a 1 HP enemy standing next to a unit chose "' + aggression.type + '" instead of attacking');
    }

    // ---- the arena now stands on the map: walk a unit in and fight
    const arena = await page.evaluate(async () => {
      const FE = window.FE, G = FE.G;
      // chapter 2 is the one with an arena on it
      G._testBeginChapter(1, ['seren', 'dorn', 'mira', 'bram', 'rook', 'edran']);
      await new Promise(r => setTimeout(r, 700));
      const st = G.state;
      let tile = null;
      for (let y = 0; y < st.map.h; y++)
        for (let x = 0; x < st.map.w; x++)
          if (FE.TERRAIN[st.map.tiles[y][x]].arena) tile = { x, y };
      if (!tile) return { noTile: true };

      const u = st.units.find(z => z.id === 'dorn' && z.faction === 'player');
      if (!u) return { noUnit: true };
      u.x = tile.x; u.y = tile.y;
      u.moved = true; u.acted = false;
      FE.recomputeSupports(st);
      FE.centerOn(st, u.x, u.y);
      G.selectedUnit = u; G.selected = u.uid;
      G._testOpenMenu(u);
      const labels = [...document.querySelectorAll('#actionmenu .btn')].map(b => b.textContent);
      return { tile, labels, roundsBefore: FE.arenaRoundsLeft(st, u), hpBefore: u.hp, expBefore: u.exp };
    });
    if (arena.noTile) errors.push(label + ': chapter 2 has no arena tile');
    else if (arena.noUnit) errors.push(label + ': could not place a unit on the arena');
    else {
      const hasArena = arena.labels.some(l => l.indexOf('Arena') === 0);
      if (!hasArena) errors.push(label + ': no Arena action on the arena tile: ' + arena.labels.join('/'));
      if (arena.roundsBefore !== 7) errors.push(label + ': expected 7 arena rounds, got ' + arena.roundsBefore);
    }
    await shot('14-arena-menu');

    // open the bout and check the pre-fight panel shows both sides' numbers
    const bout = await page.evaluate(async () => {
      const btn = [...document.querySelectorAll('#actionmenu .btn')].find(b => b.textContent.indexOf('Arena') === 0);
      if (!btn) return { skip: true };
      btn.click();
      await new Promise(r => setTimeout(r, 400));
      const sides = document.querySelectorAll('.av-side').length;
      const rows = document.querySelectorAll('.av-side .row').length;
      const foe = document.querySelector('.av-side.them .av-c');
      return { sides, rows, foe: foe && foe.textContent };
    });
    if (!bout.skip) {
      if (bout.sides !== 2) errors.push(label + ': arena panel showed ' + bout.sides + ' fighters, expected 2');
      if (bout.rows < 6) errors.push(label + ': arena panel is missing the forecast rows (' + bout.rows + ')');
    }
    await shot('15-arena-offer');

    // fight, and confirm the duel scene actually animates
    const duel = await page.evaluate(async () => {
      const fight = [...document.querySelectorAll('.btn')].find(b => b.textContent === 'Fight');
      if (!fight) return { skip: true };
      const FE = window.FE, G = FE.G;
      const u = G.state.units.find(z => z.id === 'dorn');
      const hpBefore = u.hp, expBefore = u.exp, lvlBefore = u.level;
      const roundsBefore = FE.arenaRoundsLeft(G.state, u);
      fight.click();
      await new Promise(r => setTimeout(r, 300));

      const cv = document.querySelector('.duel-canvas');
      if (!cv) return { noCanvas: true };
      function snap() {
        const g = cv.getContext('2d');
        const d = g.getImageData(0, 0, cv.width, cv.height).data;
        let h = 0;
        for (let i = 0; i < d.length; i += 4 * 211) h = (h * 31 + d[i] + d[i + 1] * 3) >>> 0;
        return h;
      }
      const frames = [];
      for (let i = 0; i < 8; i++) {
        frames.push(snap());
        await new Promise(r => setTimeout(r, 160));
      }
      const distinct = new Set(frames).size;
      return {
        distinct, hpBefore, expBefore, lvlBefore, roundsBefore,
        canvasW: cv.width, canvasH: cv.height
      };
    });
    if (!duel.skip) {
      if (duel.noCanvas) errors.push(label + ': the duel scene never appeared');
      else if (duel.distinct < 3) errors.push(label + ': duel canvas is static across 8 frames (' + duel.distinct + ' distinct) - not animating');
    }
    await shot('16-duel');

    // let it finish and check the bout actually changed the unit
    const settled = await page.evaluate(async () => {
      if (window.FE.duelSkip) window.FE.duelSkip();
      await new Promise(r => setTimeout(r, 900));
      // step through any level-up modal
      for (let i = 0; i < 4; i++) {
        const cont = [...document.querySelectorAll('.btn')].find(b => b.textContent === 'Continue');
        if (!cont) break;
        cont.click();
        await new Promise(r => setTimeout(r, 250));
      }
      const FE = window.FE, G = FE.G;
      const u = G.state.units.find(z => z.id === 'dorn');
      return {
        roundsAfter: FE.arenaRoundsLeft(G.state, u),
        hp: u.hp, maxhp: u.maxhp, exp: u.exp, level: u.level,
        acted: u.acted,
        resultShown: !!document.querySelector('.modal-h')
      };
    });
    if (!duel.skip && !duel.noCanvas) {
      if (settled.roundsAfter !== duel.roundsBefore - 1) {
        errors.push(label + ': arena round was not spent (' + duel.roundsBefore + ' -> ' + settled.roundsAfter + ')');
      }
      const changed = settled.hp !== duel.hpBefore || settled.exp !== duel.expBefore || settled.level !== duel.lvlBefore;
      if (!changed) errors.push(label + ': the bout changed nothing about the unit - no damage, no experience');
      if (settled.acted) errors.push(label + ': the arena consumed the unit\'s action, it is meant to be free');
    }
    await shot('17-arena-result');

    // back to chapter 1 for the rest of the checks
    const leftArena = await page.evaluate(async () => {
      const leave = [...document.querySelectorAll('.btn')].find(b => b.textContent === 'Leave the arena');
      if (leave) leave.click();
      await new Promise(r => setTimeout(r, 400));
      const stuck = window.FE.G.busy;
      window.FE.G._testBeginChapter(0, ['seren', 'dorn', 'mira', 'bram']);
      await new Promise(r => setTimeout(r, 600));
      return { stuck };
    });
    if (leftArena && leftArena.stuck) errors.push(label + ': leaving the arena left the game stuck busy');

    // ---- the action menu must never be clipped by the pane, including at the
    // very bottom of the map where it used to disappear under the info bar
    const menuFit = await page.evaluate(async () => {
      const FE = window.FE, G = FE.G;
      const wrap = document.getElementById('map-wrap');
      const menu = document.getElementById('actionmenu');
      const out = [];
      const u = G.state.units.find(z => z.faction === 'player' && z.alive);
      const spots = [[2, G.state.map.h - 1], [2, 0], [G.state.map.w - 1, G.state.map.h - 1], [8, 6]];
      for (const [x, y] of spots) {
        u.x = x; u.y = y; u.acted = false; u.moved = true;
        FE.recomputeSupports(G.state);
        FE.centerOn(G.state, x, y);
        G.selectedUnit = u; G.selected = u.uid;
        G._testOpenMenu(u);
        await new Promise(r => setTimeout(r, 60));
        const mr = menu.getBoundingClientRect();
        const wr = wrap.getBoundingClientRect();
        out.push({
          at: [x, y],
          insideTop: mr.top >= wr.top - 1,
          insideBottom: mr.bottom <= wr.bottom + 1,
          insideLeft: mr.left >= wr.left - 1,
          insideRight: mr.right <= wr.right + 1,
          h: Math.round(mr.height)
        });
      }
      return out;
    });
    menuFit.forEach(m => {
      if (!m.insideTop || !m.insideBottom || !m.insideLeft || !m.insideRight) {
        errors.push(label + ': action menu at tile ' + m.at.join(',') + ' escapes the map pane ' + JSON.stringify(m));
      }
    });
    await shot('18-menufit');

    // ---- zoom: two-finger slide zooms, trackpad pinch does not
    const zoom = await page.evaluate(async () => {
      const FE = window.FE;
      const wrap = document.getElementById('map-wrap');
      function wheel(dy, ctrl) {
        wrap.dispatchEvent(new WheelEvent('wheel', {
          deltaY: dy, ctrlKey: !!ctrl, bubbles: true, cancelable: true
        }));
      }
      const start = FE.R.zoom;
      wheel(-120, false); wheel(-120, false);
      const afterSlide = FE.R.zoom;
      const mid = FE.R.zoom;
      wheel(-120, true); wheel(-120, true); wheel(120, true);
      const afterPinch = FE.R.zoom;
      return { start, afterSlide, mid, afterPinch };
    });
    if (zoom.afterSlide === zoom.start) errors.push(label + ': two-finger slide did not zoom');
    if (zoom.afterPinch !== zoom.mid) errors.push(label + ': trackpad pinch still zooms (' + zoom.mid + ' -> ' + zoom.afterPinch + ')');

    // ---- the forecast must name the weapon the enemy is holding
    const wep = await page.evaluate(async () => {
      const FE = window.FE, G = FE.G;
      const me = G.state.units.find(z => z.faction === 'player' && z.alive && FE.equipped(z));
      const foe = G.state.units.find(z => z.faction === 'enemy' && z.alive);
      foe.x = me.x + 1; foe.y = me.y;
      foe.awake = true;
      FE.recomputeSupports(G.state);
      FE.centerOn(G.state, me.x, me.y);
      me.acted = false; me.moved = true;
      G.selectedUnit = me; G.selected = me.uid;
      G._testOpenMenu(me);
      const atk = [...document.querySelectorAll('#actionmenu .btn')].find(b => b.textContent === 'Attack');
      if (!atk) return { skip: true };
      atk.click();
      await new Promise(r => setTimeout(r, 300));
      const names = [...document.querySelectorAll('.fc-wep-n')].map(n => n.textContent);
      const tags = [...document.querySelectorAll('.fc-tag')].map(n => n.textContent);
      const foeWep = FE.itemData(FE.equipped(foe));
      return { names, tags, expect: foeWep && foeWep.name };
    });
    if (!wep.skip) {
      if (!wep.names || wep.names.length < 2) {
        errors.push(label + ': forecast does not show both weapons (' + JSON.stringify(wep.names) + ')');
      } else if (wep.expect && wep.names.indexOf(wep.expect) === -1) {
        errors.push(label + ": forecast omits the enemy's weapon " + wep.expect + ' (' + wep.names.join(', ') + ')');
      }
      const bareTriangle = (wep.tags || []).some(t => /triangle\s*[+\u2212-]\s*$/.test(t));
      if (bareTriangle) errors.push(label + ': forecast still shows a bare "triangle +/-" tag');
    }
    await shot('19-forecast');
    await page.evaluate(() => {
      const back = [...document.querySelectorAll('.fc-bar .btn')].find(b => b.textContent === 'Back');
      if (back) back.click();
    });
    await page.waitForTimeout(200);

    // ---- the forecast warns about doubling, both ways round
    const dbl = await page.evaluate(async () => {
      const FE = window.FE, G = FE.G;
      function stage(fastSide) {
        const me = G.state.units.find(z => z.faction === 'player' && z.alive && FE.equipped(z));
        const foe = G.state.units.find(z => z.faction === 'enemy' && z.alive);
        if (!me || !foe) return null;
        me.hp = me.maxhp; foe.hp = foe.maxhp;
        foe.x = me.x + 1; foe.y = me.y; foe.awake = true;
        me.spd = fastSide === 'me' ? 30 : 1;
        foe.spd = fastSide === 'me' ? 1 : 30;
        FE.recomputeSupports(G.state);
        FE.centerOn(G.state, me.x, me.y);
        me.acted = false; me.moved = true;
        G.selectedUnit = me; G.selected = me.uid;
        G._testOpenMenu(me);
        const atk = [...document.querySelectorAll('#actionmenu .btn')].find(x => x.textContent === 'Attack');
        if (!atk) return null;
        atk.click();
        return true;
      }
      function readAndClose() {
        const n = document.querySelector('.fc-double');
        const out = n ? { text: n.textContent, good: n.classList.contains('good'), bad: n.classList.contains('bad') } : null;
        const back = [...document.querySelectorAll('.fc-bar .btn')].find(x => x.textContent === 'Back');
        if (back) back.click();
        return out;
      }
      if (!stage('me')) return { skip: true };
      await new Promise(r => setTimeout(r, 250));
      const mine = readAndClose();
      await new Promise(r => setTimeout(r, 200));
      if (!stage('foe')) return { skip: true };
      await new Promise(r => setTimeout(r, 250));
      const theirs = readAndClose();
      await new Promise(r => setTimeout(r, 200));
      return { skip: false, mine, theirs };
    });
    if (!dbl.skip) {
      if (!dbl.mine) errors.push(label + ': the forecast does not say when you will strike twice');
      else if (!/twice/i.test(dbl.mine.text) || !dbl.mine.good) {
        errors.push(label + ': your doubling badge reads "' + dbl.mine.text + '"');
      }
      if (!dbl.theirs) errors.push(label + ': the forecast does not warn when the enemy strikes back twice');
      else if (!/twice/i.test(dbl.theirs.text) || !dbl.theirs.bad) {
        errors.push(label + ': the enemy doubling badge reads "' + dbl.theirs.text + '"');
      }
    }

    // ---- the panel gets out of the way of a unit near the bottom of the map
    const flip = await page.evaluate(async () => {
      const FE = window.FE, G = FE.G;
      const heal = G.state.units.find(z => z.faction === 'player' && z.alive && FE.canStaff && FE.canStaff(z));
      const me = heal || G.state.units.find(z => z.faction === 'player' && z.alive && FE.equipped(z));
      const foe = G.state.units.find(z => z.faction === 'enemy' && z.alive);
      if (!me || !foe) return { skip: true };
      const out = {};
      function place(y) {
        me.x = 6; me.y = y;
        foe.x = 7; foe.y = y; foe.awake = true; foe.hp = foe.maxhp;
        me.hp = me.maxhp; me.acted = false; me.moved = true;
        FE.recomputeSupports(G.state);
        FE.centerOn(G.state, me.x, me.y);
        G.selectedUnit = me; G.selected = me.uid;
        G._testOpenMenu(me);
        const atk = [...document.querySelectorAll('#actionmenu .btn')].find(x => x.textContent === 'Attack');
        if (!atk) return false;
        atk.click();
        return true;
      }
      function closeIt() {
        const back = [...document.querySelectorAll('.fc-bar .btn')].find(x => x.textContent === 'Back');
        if (back) back.click();
      }
      if (!place(G.state.h - 2)) return { skip: true };
      await new Promise(r => setTimeout(r, 250));
      out.low = document.getElementById('forecast').classList.contains('at-top');
      closeIt();
      await new Promise(r => setTimeout(r, 200));
      if (!place(1)) return { skip: true };
      await new Promise(r => setTimeout(r, 250));
      out.high = document.getElementById('forecast').classList.contains('at-top');
      closeIt();
      await new Promise(r => setTimeout(r, 200));
      return out;
    });
    if (!flip.skip) {
      if (!flip.low) errors.push(label + ': the panel stayed at the bottom over a unit near the bottom of the map');
      if (flip.high) errors.push(label + ': the panel jumped to the top for a unit near the top of the map');
    }

    // ---- a player attack plays the full battle scene, and Off skips it
    async function stageAttack() {
      return page.evaluate(async () => {
        const FE = window.FE, G = FE.G;
        const me = G.state.units.find(z => z.faction === 'player' && z.alive && FE.equipped(z));
        const foe = G.state.units.find(z => z.faction === 'enemy' && z.alive && z.hp > 0);
        if (!me || !foe) return { skip: true };
        me.hp = me.maxhp; foe.hp = foe.maxhp;
        foe.x = me.x + 1; foe.y = me.y; foe.awake = true;
        // make the swing land: a genuine miss is not what this test is about
        foe.spd = 0; foe.lck = 0; foe.def = 0; foe.res = 0;
        me.skl = 40; me.lck = 40; me.str = 20; me.mag = 20;
        FE.recomputeSupports(G.state);
        FE.centerOn(G.state, me.x, me.y);
        me.acted = false; me.moved = true;
        G.selectedUnit = me; G.selected = me.uid;
        G._testOpenMenu(me);
        const atk = [...document.querySelectorAll('#actionmenu .btn')].find(b => b.textContent === 'Attack');
        if (!atk) return { skip: true };
        atk.click();
        await new Promise(r => setTimeout(r, 250));
        const go = [...document.querySelectorAll('.fc-bar .btn')].find(b => b.textContent === 'Attack');
        if (!go) return { skip: true };
        // the forecast may have opened on a different adjacent enemy - read who
        const cur = G.cursor || {};
        const aimed = G.state.units.find(z => z.faction === 'enemy' && z.alive && z.x === cur.x && z.y === cur.y) || foe;
        const out = { skip: false, foeUid: aimed.uid, foeHp: aimed.hp, meUid: me.uid };
        go.click();
        return out;
      });
    }

    const scene = await stageAttack();
    if (!scene.skip) {
      const anim = await page.evaluate(async () => {
        await new Promise(r => setTimeout(r, 220));
        const box = document.querySelector('.battle-scene');
        const cv = box && box.querySelector('.duel-canvas');
        if (!cv) return { noScene: true };
        const g = cv.getContext('2d');
        const frames = new Set();
        for (let i = 0; i < 8; i++) {
          const d = g.getImageData(0, 0, cv.width, cv.height).data;
          let h = 0;
          for (let k = 0; k < d.length; k += 997) h = (h * 31 + d[k]) | 0;
          frames.add(h);
          await new Promise(r => setTimeout(r, 160));
        }
        return { distinct: frames.size, w: cv.width, h: cv.height };
      });
      if (anim.noScene) errors.push(label + ': a player attack did not open the battle scene');
      else if (anim.distinct < 3) {
        errors.push(label + ': the battle scene is static across 8 frames (' + anim.distinct + ' distinct)');
      }
      await shot('20-battlescene');

      // tap to skip, then the attack must actually resolve and the unit finish
      const resolved = await page.evaluate(async (info) => {
        if (window.FE.duelSkip) window.FE.duelSkip();
        for (let i = 0; i < 60 && (window.FE.G.busy || document.querySelector('.battle-scene')); i++) {
          await new Promise(r => setTimeout(r, 120));
        }
        const FE = window.FE, G = FE.G;
        const foe = G.state.units.find(u => u.uid === info.foeUid);
        const me = G.state.units.find(u => u.uid === info.meUid);
        return {
          open: !!document.querySelector('.battle-scene'),
          busy: G.busy,
          hurt: !foe.alive || foe.hp < info.foeHp,
          acted: !!me.acted
        };
      }, scene);
      if (resolved.open) errors.push(label + ': the battle scene stayed open after skipping');
      if (resolved.busy) errors.push(label + ': the game stayed busy after the battle scene');
      if (!resolved.hurt) errors.push(label + ': the attack did the enemy no damage after the scene');
      if (!resolved.acted) errors.push(label + ': the attacker never finished its turn after the scene');
    }

    // ---- Off bypasses the scene entirely
    await page.evaluate(() => { try { localStorage.setItem('sundered-crown-anim', 'off'); } catch (e) { } });
    const off = await stageAttack();
    if (!off.skip) {
      const res = await page.evaluate(async (info) => {
        let sawScene = false;
        for (let i = 0; i < 40 && window.FE.G.busy; i++) {
          if (document.querySelector('.battle-scene')) sawScene = true;
          await new Promise(r => setTimeout(r, 100));
        }
        if (document.querySelector('.battle-scene')) sawScene = true;
        const foe = window.FE.G.state.units.find(u => u.uid === info.foeUid);
        return { sawScene, hurt: !foe.alive || foe.hp < info.foeHp, busy: window.FE.G.busy };
      }, off);
      if (res.sawScene) errors.push(label + ': animations set to Off still opened the battle scene');
      if (!res.hurt) errors.push(label + ': with animations off the attack did no damage');
      if (res.busy) errors.push(label + ': with animations off the attack never settled');
    }
    await page.evaluate(() => { try { localStorage.setItem('sundered-crown-anim', 'full'); } catch (e) { } });

    // danger zone toggle
    const danger = await page.evaluate(async () => {
      document.getElementById('btn-danger').click();
      await new Promise(r => setTimeout(r, 200));
      const n = window.FE.G.overlay ? Object.keys(window.FE.G.overlay).length : 0;
      return n;
    });
    if (danger < 5) errors.push(label + ': danger zone painted ' + danger + ' tiles');
    await shot('13-dangerzone');

    // end the turn and let the enemy phase run
    await page.evaluate(() => { document.getElementById('btn-danger').click(); });
    await page.getByRole('button', { name: 'End Turn' }).click();
    // the enemy phase must never stop to play a battle scene
    let enemyScene = false;
    for (let i = 0; i < 60; i++) {
      if (await page.locator('.battle-scene').count()) enemyScene = true;
      await page.waitForTimeout(100);
    }
    if (enemyScene) errors.push(label + ': the enemy phase opened a battle scene');
    const afterEnemy = await page.evaluate(() => ({
      turn: window.FE.G.state.turn,
      phase: window.FE.G.state.phase,
      busy: window.FE.G.busy
    }));
    if (afterEnemy.turn < 2) errors.push(label + ': turn did not advance past the enemy phase (turn ' + afterEnemy.turn + ')');
    if (afterEnemy.busy) errors.push(label + ': still busy after the enemy phase - it hung');
    await shot('14-turn2');

    console.log('  ' + label + '  ' + st.w + 'x' + st.h + ' map, ' + st.players + ' players vs ' + st.enemies
      + ' enemies, reached turn ' + afterEnemy.turn + ', ' + painted + ' colours drawn');

    await ctx.close();
  }

  await run('desktop', 1280, 800);
  await run('phone', 390, 844);

  await browser.close();

  if (errors.length) {
    console.log('\nFAILURES:');
    errors.forEach(e => console.log('  ' + e));
    process.exit(1);
  }
  console.log('\n  browser checks passed; screenshots in dist/shots');
})();
