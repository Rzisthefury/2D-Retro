/* ------------------------------------------------------------------
   RECRUITABLE ROSTER
   bases  = actual stats at the listed starting level
   growth = per-stat % chance to gain +1 on level up
------------------------------------------------------------------ */
(function (FE) {
  'use strict';

  function b(hp, str, mag, skl, spd, lck, def, res, con) {
    return { hp: hp, str: str, mag: mag, skl: skl, spd: spd, lck: lck, def: def, res: res, con: con };
  }
  function g(hp, str, mag, skl, spd, lck, def, res) {
    return { hp: hp, str: str, mag: mag, skl: skl, spd: spd, lck: lck, def: def, res: res };
  }

  var R = {

    seren: {
      name: 'Seren', full: 'Seren Valehart', title: 'Heir of Greywater',
      cls: 'lord', level: 1, affinity: 'light', lord: true,
      bases: b(18, 5, 1, 6, 7, 7, 5, 1, 5),
      growth: g(70, 45, 20, 50, 55, 60, 30, 30),
      items: ['valebrand', 'vulnerary'],
      bio: 'Second child of the Marquess, and heir to nothing in particular until this morning. Good with a blade, badly out of her depth at everything else.'
    },

    dorn: {
      name: 'Dorn', full: 'Dorn Hollis', title: "Shieldbearer",
      cls: 'knight', level: 3, affinity: 'ice',
      bases: b(22, 8, 0, 5, 4, 3, 11, 1, 14),
      growth: g(85, 50, 5, 40, 25, 25, 50, 20),
      items: ['ironlance', 'vulnerary'],
      bio: "Held her father's shield for thirty years. Slow, immovable, and says about six words a chapter. Calls her Marquess now, which she hates."
    },

    mira: {
      name: 'Mira', full: 'Mira Ashgrove', title: 'Village Healer',
      cls: 'cleric', level: 1, affinity: 'anima',
      bases: b(16, 1, 4, 4, 5, 6, 2, 6, 5),
      growth: g(60, 10, 55, 45, 50, 55, 15, 50),
      items: ['heal', 'vulnerary'],
      bio: 'Greywater’s healer. Complains about the war constantly and has never once considered leaving.'
    },

    bram: {
      name: 'Bram', full: 'Bram Teague', title: 'Knight of Greywater',
      cls: 'cavalier', level: 2, affinity: 'fire',
      bases: b(20, 7, 0, 6, 7, 4, 7, 1, 9),
      growth: g(75, 50, 5, 45, 45, 35, 35, 25),
      items: ['ironsword', 'ironlance'],
      bio: 'Nineteen, newly spurred, desperate to be useful. Will charge anything if you let him.'
    },

    rook: {
      name: 'Rook', full: 'Rook', title: 'Caldmark Bandit',
      cls: 'thief', level: 2, affinity: 'dark',
      bases: b(17, 4, 0, 8, 11, 5, 3, 1, 6),
      growth: g(65, 35, 5, 55, 65, 50, 20, 25),
      items: ['ironsword', 'lockpick'],
      bio: 'On the other side this morning. Perfectly honest about being a coward, which is more than most.'
    },

    edran: {
      name: 'Edran', full: 'Edran Coyle', title: 'Company Captain',
      cls: 'mercenary', level: 5, affinity: 'fire',
      bases: b(26, 9, 0, 11, 10, 5, 7, 2, 10),
      growth: g(80, 50, 5, 55, 50, 30, 30, 25),
      items: ['steelsword', 'ironsword', 'vulnerary'],
      bio: 'Hired last spring and never fully paid. Stays because the contract is not fulfilled. That is the only reason he will admit to.'
    },

    nessa: {
      name: 'Nessa', full: 'Nessa Crowe', title: 'Greywater Poacher',
      cls: 'archer', level: 2, affinity: 'wind',
      bases: b(18, 5, 0, 8, 7, 4, 4, 1, 7),
      growth: g(65, 45, 5, 60, 50, 40, 25, 25),
      items: ['ironbow', 'vulnerary'],
      bio: 'Has been illegally shooting Valehart deer for six years and is entirely unbothered to be meeting the heir.'
    },

    cass: {
      name: 'Cass', full: 'Cass Ferrow', title: 'Drifter',
      cls: 'myrmidon', level: 3, affinity: 'thunder',
      bases: b(19, 5, 0, 12, 13, 6, 4, 2, 5),
      growth: g(60, 40, 5, 65, 65, 45, 20, 30),
      items: ['killingedge'],
      bio: 'No surname offered, and a Killing Edge she should not be able to afford.'
    },

    ilya: {
      name: 'Ilya', full: 'Ilya Vance', title: 'Estrel Courier',
      cls: 'pegasusknight', level: 3, affinity: 'wind',
      bases: b(19, 6, 0, 8, 12, 7, 6, 8, 6),
      growth: g(65, 40, 5, 50, 60, 50, 25, 50),
      items: ['slimlance', 'javelin'],
      bio: 'Royal courier carrying a message that stopped mattering three days ago. Attached herself to Seren for want of orders.'
    },

    petra: {
      name: 'Petra', full: 'Petra Quill', title: 'Academy Apprentice',
      cls: 'mage', level: 2, affinity: 'anima',
      bases: b(17, 1, 6, 6, 7, 5, 3, 4, 5),
      growth: g(60, 10, 60, 50, 50, 40, 20, 45),
      items: ['fire', 'vulnerary'],
      bio: 'Expelled two months early for setting a thing on fire. Delighted to be in a war.'
    },

    garrick: {
      name: 'Garrick', full: 'Garrick Stone', title: 'Caldmark Axeman',
      cls: 'fighter', level: 4, affinity: 'thunder',
      bases: b(27, 10, 0, 6, 6, 3, 6, 0, 13),
      growth: g(85, 60, 5, 40, 40, 30, 30, 15),
      items: ['ironaxe', 'handaxe'],
      bio: 'Took Varn coin, watched what Varn did with it, and gave the coin back.'
    }
  };

  Object.keys(R).forEach(function (k) { R[k].id = k; });
  FE.ROSTER = R;

  /* ---------------- BOSSES ---------------- */
  FE.BOSSES = {
    gorr: {
      name: 'Gorr', full: 'Gorr', title: 'Brigand Chief',
      cls: 'bandit', level: 5, affinity: 'fire', boss: true,
      /* tutorial boss: has to be threatening and has to die in about two turns
         of focused fire from three level-1 units standing on plain ground */
      bases: b(28, 9, 0, 6, 5, 2, 6, 1, 15),
      growth: g(70, 40, 0, 30, 25, 20, 30, 10),
      items: ['ironaxe', 'vulnerary'],
      drop: 'valesignet',
      bio: 'Loud, greedy, and hired by somebody whose name he was never told.',
      quote: 'Big house, big silver. Kill the girl and we go home rich!'
    },
    halvard: {
      name: 'Halvard', full: 'Captain Halvard Renn', title: 'Varn Regular',
      cls: 'knight', level: 8, affinity: 'ice', boss: true,
      bases: b(30, 13, 0, 10, 7, 4, 9, 3, 16),
      growth: g(75, 45, 0, 35, 25, 20, 40, 15),
      items: ['steellance', 'javelin'],
      drop: 'doorkey',
      bio: 'Professional. Polite. Entirely willing to burn a village on schedule.',
      quote: 'The crossing is Imperial ground as of dawn. Step onto it and I will treat you as I am ordered to.'
    },
    sirin: {
      name: 'Sirin', full: 'Wing-Captain Sirin Vale', title: 'Varn Wyvern Flight',
      cls: 'wyvernrider', level: 10, affinity: 'wind', boss: true, withdraws: 10,
      bases: b(33, 14, 0, 12, 12, 6, 13, 3, 14),
      growth: g(75, 50, 0, 40, 40, 25, 40, 15),
      items: ['steellance', 'javelin'],
      bio: 'Flies away at turn 10 whatever you do. Remember the face.',
      quote: 'Hold your line if you like. I have until the tenth bell and no longer.'
    }
  };

  /* ---------------- ENEMY GENERATION ---------------- */
  var ENEMY_GROWTH = g(60, 35, 30, 30, 30, 20, 25, 15);

  /* generic stat lines by class at level 1, scaled up by level */
  var ENEMY_BASE = {
    soldier:      b(18, 5, 0, 3, 3, 1, 4, 0, 10),
    brigand:      b(21, 6, 0, 3, 3, 0, 3, 0, 14),
    pirate:       b(20, 6, 0, 4, 4, 0, 3, 0, 13),
    mercenary:    b(19, 5, 0, 6, 6, 2, 4, 1, 10),
    myrmidon:     b(17, 4, 0, 8, 9, 3, 3, 1, 6),
    archer:       b(17, 4, 0, 5, 5, 1, 3, 1, 7),
    knight:       b(20, 6, 0, 3, 2, 1, 9, 0, 14),
    cavalier:     b(19, 5, 0, 4, 5, 2, 5, 0, 10),
    fighter:      b(21, 6, 0, 3, 4, 1, 3, 0, 13),
    shaman:       b(16, 0, 5, 3, 2, 1, 2, 4, 8),
    mage:         b(16, 0, 5, 4, 4, 1, 2, 4, 6),
    wyvernrider:  b(22, 7, 0, 5, 5, 1, 8, 0, 12),
    bandit:       b(23, 7, 0, 4, 4, 1, 4, 0, 15),
    thief:        b(16, 3, 0, 5, 8, 2, 2, 0, 6)
  };

  /* deterministic-ish enemy stat line: base + level-1 * growth/100, rounded */
  FE.makeEnemyStats = function (clsKey, level) {
    var base = ENEMY_BASE[clsKey] || ENEMY_BASE.soldier;
    var out = {};
    var lv = Math.max(0, level - 1);
    ['hp', 'str', 'mag', 'skl', 'spd', 'lck', 'def', 'res'].forEach(function (s) {
      out[s] = Math.floor(base[s] + lv * (ENEMY_GROWTH[s] / 100));
    });
    out.con = base.con;
    return out;
  };

  FE.ENEMY_GROWTH = ENEMY_GROWTH;

})(window.FE = window.FE || {});
