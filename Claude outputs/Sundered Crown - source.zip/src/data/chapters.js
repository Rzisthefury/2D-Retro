/* ------------------------------------------------------------------
   CHAPTERS
   Map legend:
     . plain    , road     f forest   t thicket   h hill
     m mountain ^ peak     F fort     G gate      T throne
     v village  H house    x ruin     _ floor     I pillar
     # wall     c cliff    ~ water    r river     = bridge
     D door     C chest    A armory   V vendor    R arena
------------------------------------------------------------------ */
(function (FE) {
  'use strict';

  var LEGEND = {
    '.': 'plain', ',': 'road', 'f': 'forest', 't': 'thicket', 'h': 'hill',
    'm': 'mountain', '^': 'peak', 'F': 'fort', 'G': 'gate', 'T': 'throne',
    'v': 'village', 'H': 'house', 'x': 'ruin', '_': 'floor', 'I': 'pillar',
    '#': 'wall', 'c': 'cliff', '~': 'water', 'r': 'river', '=': 'bridge',
    'D': 'door', 'C': 'chest', 'A': 'armory', 'V': 'vendor', 'R': 'arena'
  };
  FE.LEGEND = LEGEND;

  /* helper: enemy definition */
  function e(cls, level, x, y, items, opts) {
    var o = { cls: cls, level: level, x: x, y: y, items: items || [], ai: 'dormant' };
    if (opts) for (var k in opts) o[k] = opts[k];
    return o;
  }

  var CH = [

    /* ============================ CHAPTER 1 ============================ */
    {
      id: 'ch1',
      number: 1,
      name: 'Greywater Burns',
      objective: 'rout',
      objectiveText: 'Defeat all enemies',
      fog: 0,
      map: [
        '############...ffmmm',
        '#__________#..fff..m',
        '#____##____#...f....',
        '#____##____D........',
        '#__________#...hh...',
        '####__######..hhh..f',
        '......,,,,....f.....',
        '~~~~~~====..........',
        '~~~~~~,,,,....ff....',
        '..f...,,,,....f....F',
        '.ff...........fff.v.',
        '..f........hh...ff..',
        '...........hhh..F...',
        '....ff........mmm...'
      ],
      /* player deployment tiles, in priority order */
      starts: [
        { x: 2, y: 3 }, { x: 3, y: 3 }, { x: 2, y: 2 }, { x: 3, y: 2 },
        { x: 8, y: 3 }, { x: 9, y: 3 }, { x: 8, y: 2 }, { x: 9, y: 2 },
        { x: 2, y: 4 }, { x: 9, y: 4 }
      ],
      forced: ['seren', 'dorn', 'mira', 'bram'],
      available: ['seren', 'dorn', 'mira', 'bram'],
      slots: 4,
      /* Six and a boss. This is the tutorial: four level-1 units cannot trade
         with eleven axes, and the chapter has to teach the triangle, not the
         reload button. */
      enemies: [
        e('brigand', 1, 12, 6, ['ironaxe'], { ai: 'aggressive' }),
        e('brigand', 1, 13, 3, ['ironaxe']),
        e('brigand', 2, 15, 8, ['handaxe']),
        e('archer', 1, 19, 9, ['ironbow']),
        e('brigand', 2, 14, 12, ['ironaxe', 'vulnerary']),
        e('brigand', 2, 17, 10, ['ironaxe'])   /* guards the house; no raider in the tutorial */
      ],
      boss: { key: 'gorr', x: 16, y: 12, ai: 'boss' },
      /* recruitable enemies */
      npcs: [
        { id: 'rook', x: 12, y: 9, faction: 'enemy', ai: 'passive', talkWith: ['seren'] }
      ],
      villages: [
        { x: 18, y: 10, event: 'ch1_house' }
      ],
      chests: [],
      reinforcements: [],
      tutorial: true,
      hardExtra: [
        e('brigand', 2, 16, 2, ['ironaxe']),
        e('brigand', 2, 11, 13, ['handaxe'])
      ]
    },

    /* ============================ CHAPTER 2 ============================ */
    {
      id: 'ch2',
      number: 2,
      name: 'Ardwyn Crossing',
      objective: 'seize',
      objectiveText: 'Seize the gate with Seren',
      fog: 0,
      /* The main hall is entered through the gap in the south wall, so the gate
         is always reachable. The door on the west wall gates the treasure
         chamber only — a locked door should cost you loot, never the chapter. */
      map: [
        '..ff....~~....##########',
        '.f......~~....#CC#_____#',
        '........~~....#__#_____#',
        '..v.....~~....D__#__G__#',
        '........~~....#__#_____#',
        '..f.....~~....#CC#_____#',
        '........~~....####..####',
        '..ff....~~..............',
        '........==..............',
        '...,,,,,==,,,,..........',
        '...,....~~....ff........',
        '...,....~~....f.........',
        '...,....~~.....hh.......',
        '...,...........hhh......',
        '...,......f....hh..v....',
        '...,.....ff.............',
        '..ff.....f.......ff..R..',
        'mmm.............mmmmmmmm'
      ],
      starts: [
        { x: 1, y: 14 }, { x: 2, y: 14 }, { x: 1, y: 15 }, { x: 2, y: 15 },
        { x: 1, y: 13 }, { x: 2, y: 13 }, { x: 0, y: 14 }, { x: 0, y: 15 },
        { x: 4, y: 14 }, { x: 4, y: 15 }, { x: 3, y: 16 }, { x: 4, y: 16 }
      ],
      forced: ['seren'],
      available: ['seren', 'dorn', 'mira', 'bram', 'rook', 'edran'],
      joins: [{ id: 'edran', x: 5, y: 13 }],
      slots: 6,
      enemies: [
        /* bridge guard */
        e('soldier', 3, 10, 7, ['ironlance']),
        e('soldier', 3, 11, 9, ['ironlance']),
        e('archer', 3, 12, 8, ['ironbow']),
        /* fortress garrison, all inside the main hall */
        e('soldier', 4, 19, 2, ['ironlance']),
        e('knight', 4, 21, 2, ['ironlance'], { ai: 'guard' }),
        e('archer', 4, 22, 4, ['ironbow'], { ai: 'guard' }),
        e('mage', 4, 21, 1, ['fire']),
        /* field */
        e('mercenary', 4, 16, 11, ['ironsword']),
        /* village raiders — these move the moment the chapter starts, and the
           two villages are on opposite corners, so you cannot save both without
           splitting the party */
        /* 3 turns from the north village; your fastest unit needs 2 */
        e('brigand', 3, 11, 8, ['ironaxe'], { ai: 'raider', village: { x: 2, y: 3 } }),
        /* 5 turns from the south village; your fastest unit needs 4 */
        e('brigand', 3, 11, 0, ['ironaxe'], { ai: 'raider', village: { x: 19, y: 14 } })
      ],
      boss: { key: 'halvard', x: 20, y: 3, ai: 'boss' },
      npcs: [
        { id: 'cass', x: 14, y: 12, faction: 'enemy', ai: 'dormant', talkWith: ['seren'] }
      ],
      villages: [
        { x: 2, y: 3, event: 'ch2_north' },
        { x: 19, y: 14, event: 'ch2_south' }
      ],
      chests: [
        { x: 15, y: 1, item: 'killeraxe' },
        { x: 16, y: 1, item: 'guidingring' },
        { x: 15, y: 5, item: 'speedwing' },
        { x: 16, y: 5, item: 'silversword' }
      ],
      doors: [{ x: 14, y: 3 }],
      reinforcements: [
        { turn: 5, list: [e('soldier', 4, 23, 8, ['ironlance'], { ai: 'aggressive' }), e('soldier', 4, 23, 9, ['javelin'], { ai: 'aggressive' })] },
        { turn: 8, list: [e('cavalier', 4, 23, 12, ['ironlance'], { ai: 'aggressive' })] }
      ],
      hardExtra: [
        e('soldier', 4, 19, 4, ['ironlance']),
        e('mercenary', 4, 13, 10, ['ironsword']),
        e('soldier', 3, 18, 13, ['javelin'])
      ]
    },

    /* ============================ CHAPTER 3 ============================ */
    {
      id: 'ch3',
      number: 3,
      name: 'The Ashmoor Line',
      objective: 'survive',
      objectiveText: 'Survive 10 turns',
      survive: 10,
      fog: 13,          /* fog applies to columns >= 13 */
      map: [
        'mmm.......ffff........',
        'mm....................',
        'm....hh......ff.......',
        '....hhh...............',
        '.....h................',
        '..f..........,,.......',
        '........FFF...........',
        '........FFF...........',
        '.......hFFFh..........',
        '......hh...hh.........',
        '....ff.......ff.......',
        '...f..................',
        '......ff......ff......',
        '......................',
        'mm......ffff.......mmm',
        'mmmm..............mmmm'
      ],
      starts: [
        { x: 8, y: 6 }, { x: 9, y: 6 }, { x: 10, y: 6 },
        { x: 8, y: 7 }, { x: 9, y: 7 }, { x: 10, y: 7 },
        { x: 8, y: 8 }, { x: 9, y: 8 }, { x: 10, y: 8 },
        { x: 7, y: 8 }, { x: 11, y: 8 }, { x: 9, y: 9 }
      ],
      forced: ['seren', 'ilya'],
      available: ['seren', 'dorn', 'mira', 'bram', 'rook', 'edran', 'nessa', 'cass', 'ilya', 'petra'],
      joins: [{ id: 'ilya', x: 9, y: 9 }, { id: 'petra', x: 8, y: 9 }],
      slots: 8,
      /* spaced out to the map edges: the fort has to be held for ten turns,
         so the first wave must arrive as a wave, not as an opening alpha strike */
      enemies: [
        e('wyvernrider', 6, 1, 1, ['ironlance'], { ai: 'aggressive' }),
        e('wyvernrider', 6, 20, 1, ['ironlance'], { ai: 'aggressive' }),
        e('soldier', 5, 0, 8, ['ironlance'], { ai: 'aggressive' }),
        e('soldier', 5, 21, 8, ['javelin'], { ai: 'aggressive' }),
        e('archer', 5, 2, 14, ['ironbow'], { ai: 'aggressive' }),
        e('mercenary', 5, 19, 13, ['ironsword'], { ai: 'aggressive' })
      ],
      boss: { key: 'sirin', x: 21, y: 2, ai: 'aggressive' },
      npcs: [
        { id: 'garrick', x: 5, y: 14, faction: 'enemy', ai: 'dormant', talkWith: ['seren'] }
      ],
      villages: [],
      chests: [],
      reinforcements: [
        { turn: 3, list: [e('soldier', 5, 0, 5, ['ironlance'], { ai: 'aggressive' }), e('soldier', 5, 21, 10, ['ironlance'], { ai: 'aggressive' })] },
        { turn: 4, list: [e('wyvernrider', 6, 21, 0, ['javelin'], { ai: 'aggressive' })] },
        { turn: 5, list: [e('brigand', 5, 0, 13, ['ironaxe'], { ai: 'aggressive' }), e('archer', 5, 21, 13, ['ironbow'], { ai: 'aggressive' })] },
        { turn: 5, list: [e('wyvernrider', 6, 0, 1, ['ironlance'], { ai: 'aggressive' }), e('mercenary', 6, 21, 6, ['steelsword'], { ai: 'aggressive' })] },
        { turn: 6, list: [e('soldier', 6, 11, 15, ['javelin'], { ai: 'aggressive' })] },
        { turn: 7, list: [e('wyvernrider', 7, 21, 3, ['steellance'], { ai: 'aggressive' }), e('brigand', 6, 0, 10, ['handaxe'], { ai: 'aggressive' })] },
        { turn: 8, list: [e('cavalier', 6, 4, 15, ['ironlance'], { ai: 'aggressive' })] },
        { turn: 9, list: [e('wyvernrider', 7, 0, 3, ['javelin'], { ai: 'aggressive' })] }
      ],
      hardExtra: [
        e('wyvernrider', 7, 15, 3, ['javelin'], { ai: 'aggressive' }),
        e('archer', 6, 6, 3, ['steelbow'], { ai: 'aggressive' }),
        e('soldier', 6, 13, 13, ['ironlance'], { ai: 'aggressive' }),
        e('mercenary', 6, 3, 10, ['ironsword'], { ai: 'aggressive' })
      ]
    }
  ];

  FE.CHAPTERS = CH;

  /* parse a chapter map into a tile grid */
  FE.parseMap = function (rows) {
    var h = rows.length, w = rows[0].length, grid = [], y, x;
    for (y = 0; y < h; y++) {
      if (rows[y].length !== w) {
        throw new Error('map row ' + y + ' is ' + rows[y].length + ' wide, expected ' + w);
      }
      grid[y] = [];
      for (x = 0; x < w; x++) {
        var ch = rows[y][x];
        var key = LEGEND[ch];
        if (!key) throw new Error('unknown map char "' + ch + '" at ' + x + ',' + y);
        grid[y][x] = key;
      }
    }
    return { w: w, h: h, tiles: grid };
  };

})(window.FE = window.FE || {});
