/* ------------------------------------------------------------------
   STORY TEXT — first pass, entirely rewritable.
   Nothing in the engine depends on any string in this file.
------------------------------------------------------------------ */
(function (FE) {
  'use strict';

  FE.STORY = {
    title: 'THE SUNDERED CROWN',
    subtitle: 'A tactics campaign in the Aurelund marches',

    intro: [
      { who: '', text: 'AURELUND. Three generations after a war nobody won.' },
      { who: '', text: 'The old crown of Estrel was broken into three pieces and divided among the three powers, so that no one king could be crowned, and no one king could march.' },
      { who: '', text: 'Varn has quietly gathered two of the three.' },
      { who: '', text: 'The last piece rests in the reliquary at Greywater, on a quiet border that has been quiet for forty years.' },
      { who: '', text: 'It stops being quiet tonight.' }
    ],

    chapters: {
      ch1: {
        name: 'Greywater Burns',
        pre: [
          { who: 'Alaric', text: 'Seren. The household guard is at muster and the outer yard is already alight. Those are not bandits — bandits do not come for a reliquary.' },
          { who: 'Seren', text: 'Then we hold the stair with what we have.' },
          { who: 'Alaric', text: 'No. You go. Dorn, Bram — take her out through the west gate and do not stop for me.' },
          { who: 'Dorn', text: '...My lord.' },
          { who: 'Seren', text: 'Father —' },
          { who: 'Alaric', text: 'Go, girl. Somebody has to still be a Valehart in the morning.' }
        ],
        post: [
          { who: 'Seren', text: 'He had my father’s signet. A brigand chief out of Caldmark, carrying a Valehart seal.' },
          { who: 'Dorn', text: 'Somebody paid him to be here. Somebody who knew the guard would be at muster.' },
          { who: 'Mira', text: 'And the reliquary?' },
          { who: 'Seren', text: 'Empty. They were three hours ahead of us.' },
          { who: 'Rook', text: 'East, if you’re asking. Everything out of Greywater goes east over Ardwyn Crossing. Not that I’d know.' }
        ],
        objectiveText: 'Defeat every enemy on the field.'
      },
      ch2: {
        name: 'Ardwyn Crossing',
        pre: [
          { who: 'Edran', text: 'Far as the bridge and no further. Those are Varn regulars on the gate, not hired knives — they’re not pretending anymore.' },
          { who: 'Seren', text: 'Captain Coyle. My father’s contract with your company —' },
          { who: 'Edran', text: 'Is unfulfilled. I know. That’s why I’m still standing here and not three counties south.' },
          { who: 'Halvard', text: 'The crossing is Imperial ground as of dawn. Step onto it and I will treat you as I am ordered to.' }
        ],
        post: [
          { who: 'Seren', text: 'Imperial ground. As of dawn. On a border Varn signed forty years ago.' },
          { who: 'Edran', text: 'Somebody opened that gate from your side, my lady. Regulars don’t cross a treaty line on a whim.' },
          { who: 'Seren', text: 'Then we find out who. East, and keep off the roads.' }
        ],
        objectiveText: 'Move Seren onto the gate to seize it.'
      },
      ch3: {
        name: 'The Ashmoor Line',
        pre: [
          { who: 'Ilya', text: 'Wyverns. Varn’s southern flight, and we are in the open on a moor.' },
          { who: 'Seren', text: 'How long until your relief column?' },
          { who: 'Ilya', text: 'Ten turns of the glass. Hold the old signal fort and they will find us. Fail to hold it and they will find pieces.' },
          { who: 'Sirin', text: 'Hold your line if you like. I have until the tenth bell and no longer.' }
        ],
        post: [
          { who: 'Ilya', text: 'She broke off. She had us and she broke off.' },
          { who: 'Seren', text: 'She had orders and a clock. That is not a raid, Ilya. That is a campaign with a schedule.' },
          { who: 'Dorn', text: 'Then somebody wrote the schedule. We should like to meet them.' }
        ],
        objectiveText: 'Survive 10 turns. Do not let Seren fall.'
      }
    },

    /* Talk conversations: keyed "speakerId>targetId" */
    talks: {
      'seren>rook': [
        { who: 'Seren', text: 'You are not swinging at me.' },
        { who: 'Rook', text: 'Observant. No. Gorr pays in promises and I’ve stopped eating those.' },
        { who: 'Seren', text: 'And what do I pay in?' },
        { who: 'Rook', text: 'Nothing yet. But your house has a reliquary, and I have a very particular set of hands. Point me at a locked thing.' },
        { who: 'Seren', text: '...Get behind Dorn.' }
      ],
      'seren>cass': [
        { who: 'Cass', text: 'Stop. You’re the Valehart girl.' },
        { who: 'Seren', text: 'I am.' },
        { who: 'Cass', text: 'Then Varn is paying me to kill the last person in Aurelund who has a reason to fight them. That’s poor accounting.' },
        { who: 'Seren', text: 'What is your name?' },
        { who: 'Cass', text: 'Cass. That’s all of it you get for now.' }
      ],
      'seren>garrick': [
        { who: 'Garrick', text: 'Caldmark doesn’t fight children.' },
        { who: 'Seren', text: 'Caldmark took Varn’s coin.' },
        { who: 'Garrick', text: 'Caldmark took Varn’s coin and then Caldmark watched what the coin was for. I gave it back this morning. Loudly.' },
        { who: 'Seren', text: 'Then pick a side of the fort and stand on it.' }
      ],
      'bram>nessa': [
        { who: 'Bram', text: 'You’re the poacher. We’ve been looking for you for six years.' },
        { who: 'Nessa', text: 'You’ve been looking badly.' }
      ]
    },

    villages: {
      ch2_north: {
        lines: [
          { who: 'Villager', text: 'Take it, my lady \u2014 my brother\u2019s, from the old war. It bites through plate. You will want it before you reach that gate.' }
        ],
        gift: 'armorslayer', gold: 0
      },
      ch2_south: {
        lines: [
          { who: 'Nessa', text: 'You’re the Valehart heir, and you’re standing in my house.' },
          { who: 'Seren', text: 'You’ve been stealing my family’s deer.' },
          { who: 'Nessa', text: 'Six years. Want them back, or want somebody who can put an arrow through a wyvern’s eye at forty paces?' }
        ],
        recruit: 'nessa'
      },
      ch1_house: {
        lines: [{ who: 'Steward', text: 'The strongbox, my lady — it is all we saved. Go, before they come round the stable.' }],
        gold: 2000
      }
    },

    gameOver: {
      lord: 'Seren has fallen. The Valehart line ends on the Greywater road.',
      objective: 'The line did not hold.'
    }
  };

  /* story items, registered alongside the regular item table so the
     inventory, drop and convoy code can treat them identically */
  FE.EXTRA_ITEMS = {
    valesignet: { name: 'Valehart Signet', type: 'item', uses: 1, price: 0, use: 'none', key: 'valesignet', mt: 0, hit: 0, crit: 0, wt: 0, rng: [0, 0], story: true, desc: 'Your father’s seal, taken off a Caldmark brigand. Somebody gave this to him.' }
  };
  Object.keys(FE.EXTRA_ITEMS).forEach(function (k) {
    if (!FE.WEAPONS[k]) FE.WEAPONS[k] = FE.EXTRA_ITEMS[k];
  });

})(window.FE = window.FE || {});
