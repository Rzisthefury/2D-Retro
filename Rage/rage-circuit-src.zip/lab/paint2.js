// ============================================================ DESIGN LAB
// Alternative body construction. Same skeleton, same palette pipeline,
// different SHAPES. Style ids: A current, B tapered, C constructed, D realistic, E rendered.

// proportion sets: swapped into RIG before solving
const PROPS = {
  A: { thigh: 14, shin: 14, torso: 21, ua: 11, fa: 11, neck: 3, headR: 7 },
  B: { thigh: 14, shin: 14, torso: 21, ua: 11, fa: 11, neck: 3, headR: 7 },
  C: { thigh: 15, shin: 14.5, torso: 20.5, ua: 11.5, fa: 11.5, neck: 3.5, headR: 6.6 },
  D: { thigh: 17.5, shin: 16.5, torso: 19.5, ua: 12.5, fa: 12.5, neck: 4.5, headR: 5.7 },
  E: { thigh: 15, shin: 14.5, torso: 20.5, ua: 11.5, fa: 11.5, neck: 3.5, headR: 6.6 },
  S: { thigh: 15, shin: 14.5, torso: 20.5, ua: 11.5, fa: 11.5, neck: 3.5, headR: 7 },
  T: { thigh: 17.5, shin: 16.5, torso: 19.5, ua: 12.5, fa: 12.5, neck: 4.5, headR: 7 },
};
const RIG0 = Object.assign({}, RIG);
function withProps(style, fn) {
  const p = PROPS[style] || PROPS.A;
  Object.assign(RIG, { thigh: p.thigh, shin: p.shin, torso: p.torso, ua: p.ua, fa: p.fa, neck: p.neck });
  const r = fn(p);
  Object.assign(RIG, RIG0);
  return r;
}

// ---------------------------------------------------------- shape helpers
const nrm = (a, b) => { const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1; return [dx / l, dy / l]; };
const perp = d => [-d[1], d[0]];

// a limb segment that TAPERS from w0 to w1, with a rolled lit edge
function taper(g, look, a, b, w0, w1, mat, back, bulge = 0) {
  const d = nrm(a, b);
  let n = perp(d);
  if (n[0] * LIGHT[0] + n[1] * LIGHT[1] < 0) n = [-n[0], -n[1]];
  const t0 = back ? 1 : 0;
  const A0 = add2(a, n, w0 / 2), A1 = add2(a, n, -w0 / 2);
  const B0 = add2(b, n, w1 / 2), B1 = add2(b, n, -w1 / 2);
  // belly of the muscle: push the midpoint out
  const m = lp(a, b, 0.42), wm = (w0 + w1) / 2 + bulge;
  const M0 = add2(m, n, wm / 2), M1 = add2(m, n, -wm / 2);
  poly(g, [A0, M0, B0, B1, M1, A1], col(look, mat, t0 + 2));
  // lit half
  poly(g, [A0, M0, B0, add2(b, n, w1 * 0.02), add2(m, n, wm * 0.04), add2(a, n, w0 * 0.02)], col(look, mat, t0 + 1));
  // highlight strip
  const hi = [add2(a, n, w0 * 0.34), add2(m, n, wm * 0.36), add2(b, n, w1 * 0.32)];
  if (Math.min(w0, w1) > 3) segLine(g, hi[0], hi[2], Math.max(1, Math.min(w0, w1) * 0.22), col(look, mat, t0));
}
// rounded joint so segments read as one limb
function joint(g, look, p, r, mat, back) {
  const t0 = back ? 1 : 0;
  disc(g, p, r, col(look, mat, t0 + 2));
  disc(g, add2(p, LIGHT, r * 0.22), r * 0.74, col(look, mat, t0 + 1));
}
// hand: an oval along the forearm, thumb nub, not a ball
function hand2(g, look, A, r, mat, back) {
  const d = nrm(A.el, A.hd);
  let n = perp(d);
  if (n[0] * LIGHT[0] + n[1] * LIGHT[1] < 0) n = [-n[0], -n[1]];
  const t0 = back ? 1 : 0;
  const tip = add2(A.hd, d, r * 0.95), root = add2(A.hd, d, -r * 0.8);
  poly(g, [add2(root, n, r * 0.78), add2(tip, n, r * 0.52), add2(tip, n, -r * 0.52), add2(root, n, -r * 0.78)], col(look, mat, t0 + 2));
  poly(g, [add2(root, n, r * 0.78), add2(tip, n, r * 0.52), add2(tip, n, r * 0.02), add2(root, n, r * 0.06)], col(look, mat, t0 + 1));
  // knuckle line + thumb
  segLine(g, add2(tip, n, r * 0.4), add2(tip, n, -r * 0.4), 0.9, col(look, mat, t0 + 2));
  disc(g, add2(add2(A.hd, n, -r * 0.5), d, r * 0.1), r * 0.34, col(look, mat, t0 + 1));
}
// boot: a wedge with a sole, not a stroke
function boot2(g, look, an, ft, w, back, heel) {
  const d = nrm(an, ft);
  let n = perp(d);
  if (n[0] * LIGHT[0] + n[1] * LIGHT[1] < 0) n = [-n[0], -n[1]];
  const t0 = back ? 1 : 0;
  const back0 = add2(an, d, -w * 0.42);
  const toe = add2(ft, d, w * 0.1);
  poly(g, [add2(back0, n, w * 0.60), add2(toe, n, w * 0.30), add2(toe, n, -w * 0.34), add2(back0, n, -w * 0.52)], col(look, 'boots', t0 + 2));
  poly(g, [add2(back0, n, w * 0.60), add2(toe, n, w * 0.30), add2(toe, n, w * 0.02), add2(back0, n, w * 0.10)], col(look, 'boots', t0 + 1));
  // sole
  segLine(g, add2(back0, n, -w * 0.44), add2(toe, n, -w * 0.30), Math.max(1, w * 0.2), col(look, 'boots', 3));
  if (heel) segLine(g, add2(back0, n, -w * 0.2), add2(back0, n, -w * 0.5), Math.max(1, w * 0.22), col(look, 'boots', 3));
}

// ---------------------------------------------------------- arm / leg
function armV(g, look, A, back, s, style) {
  const gr = look.girth || 1, ar = look.arms || 1, fem = look.fem;
  const bulk = 1 + (gr - 1) * 0.45;
  const k = (fem ? 0.84 : 1) * bulk * ar * s;
  // shoulder -> elbow -> wrist, narrowing
  const heavy = (look.girth || 1) > 1.1;
  const wSh = (heavy ? 7.2 : 6.6) * k, wEl = (heavy ? 5.2 : 5.0) * k, wWr = (heavy ? 3.8 : 3.9) * k;
  const sl = look.sleeve || 'short';
  const upMat = sl === 'none' ? 'skin' : 'top';
  const loMat = sl === 'long' ? 'top' : 'skin';
  const t0 = back ? 1 : 0;
  taper(g, look, A.sh, A.el, wSh, wEl, upMat, back, fem ? 0.5 * k : 1.3 * k);   // biceps belly
  joint(g, look, A.el, wEl * 0.48, loMat, back);
  taper(g, look, A.el, A.hd, wEl * 0.94, wWr, loMat, back, fem ? 0.4 * k : 1.0 * k);  // forearm belly
  if (look.gloves && loMat === 'skin') {
    // glove is a cuff at the wrist, not the whole forearm
    taper(g, look, lp(A.el, A.hd, 0.74), A.hd, wWr * 1.22, wWr * 1.08, 'gloves', back, 0);
  }
  if (sl === 'short') {
    const cuff = lp(A.sh, A.el, 0.46);
    taper(g, look, A.sh, cuff, wSh + 1.1 * k, wEl + 1.2 * k, 'top', back, 0);
    segLine(g, add2(cuff, perp(nrm(A.sh, A.el)), wEl * 0.6), add2(cuff, perp(nrm(A.sh, A.el)), -wEl * 0.6), 1, col(look, 'top', t0 + 2));
  } else if (sl === 'elbow' && look.cuffs) {
    const cuff = lp(A.sh, A.el, 0.9);
    taper(g, look, lp(A.sh, A.el, 0.55), cuff, wSh * 0.98 + 1.1 * k, wEl + 1.3 * k, 'top', back, 0);
  }
  // deltoid cap
  if (style !== 'B') joint(g, look, A.sh, wSh * 0.56, sl === 'none' ? 'skin' : 'top', back);
  if (look.robot) disc(g, A.el, wEl * 0.5, col(look, 'hair', back ? 3 : 2));
  hand2(g, look, A, (look.fist || 3.0) * Math.pow(s, 0.72) * ar * 1.02, look.gloves ? 'gloves' : 'skin', back);
}
function legV(g, look, Lg, back, s, style) {
  const gr = look.girth || 1, fem = look.fem;
  const k = s * gr;
  const wHip = 8.6 * k * (fem ? 0.86 : 1), wKn = 5.8 * k * (fem ? 0.82 : 1), wAn = 4.2 * k * (fem ? 0.78 : 1);
  const bare = look.bare === 'legs' || look.shorts;
  const thighMat = bare ? 'skin' : 'pants';
  const shinMat = bare ? 'skin' : 'pants';
  taper(g, look, Lg.hp, Lg.kn, wHip, wKn, thighMat, back, fem ? 0.8 * k : 1.5 * k);   // quad belly
  if (look.shorts) taper(g, look, Lg.hp, lp(Lg.hp, Lg.kn, 0.38), wHip + 1.1 * k, wKn + 1.5 * k, 'pants', back, 0);
  joint(g, look, Lg.kn, wKn * 0.5, shinMat, back);
  // calf: belly high on the shin
  taper(g, look, Lg.kn, Lg.an, wKn * 0.96, wAn, shinMat, back, fem ? 0.9 * k : 1.6 * k);
  const bootTop = look.tallBoots ? 0.06 : 0.62;
  taper(g, look, lp(Lg.kn, Lg.an, bootTop), Lg.an, (look.tallBoots ? wKn * 0.98 : wAn * 1.35) + 0.7 * k, wAn + 0.8 * k, 'boots', back, 0);
  if (look.tallBoots) segLine(g, lp(Lg.kn, Lg.an, 0.04), lp(Lg.kn, Lg.an, 0.14), wKn + 1.4 * k, col(look, 'boots', back ? 1 : 0));
  boot2(g, look, Lg.an, Lg.ft, 6.4 * k * (fem ? 0.82 : 1), back, style === 'D' || style === 'C' || style === 'E');
  if (look.robot) disc(g, Lg.kn, wKn * 0.55, col(look, 'hair', back ? 3 : 2));
}

// ---------------------------------------------------------- torso
function torsoV(g, look, J, s, style) {
  const gr = look.girth || 1, fem = look.fem;
  const hip = J.hip, sh = J.sh, u = J.up, n = [-u[1], u[0]];
  const Lt = Math.hypot(sh[0] - hip[0], sh[1] - hip[1]);
  const P = (t, k) => [hip[0] + u[0] * Lt * t + n[0] * k, hip[1] + u[1] * Lt * t + n[1] * k];
  const g0 = s * gr;
  const belly = (look.belly || 0) * s * 0.42;
  // real silhouette: pelvis -> waist pinch -> ribcage flare -> deltoids -> trap slope
  const hipW = (fem ? 6.9 : 6.0) * g0;
  const waistW = (fem ? 4.2 : 5.0) * g0 + belly;
  const ribW = (fem ? 5.9 : 7.4) * g0 + belly * 0.7;
  const chestW = (fem ? 6.6 : 8.4) * g0;
  const shW = (fem ? 7.0 : 9.6) * g0;
  const front = [
    P(-0.04, hipW * 0.86), P(0.10, hipW), P(0.30, waistW * 1.06), P(0.44, waistW),
    P(0.62, ribW), P(0.80, chestW), P(0.94, shW * 0.92), P(1.03, shW * 0.72), P(1.10, shW * 0.34),
  ];
  const backS = [
    P(1.10, -shW * 0.36), P(1.03, -shW * 0.76), P(0.94, -shW * 0.96), P(0.78, -chestW * 0.96),
    P(0.60, -ribW * 0.98), P(0.44, -waistW * 1.02), P(0.30, -waistW * 1.1), P(0.10, -hipW * 0.98), P(-0.04, -hipW * 0.84),
  ];
  const outline = front.concat(backS);
  const baseMat = look.bare === 'chest' ? 'skin' : 'top';
  const t0 = 0;
  poly(g, outline, col(look, baseMat, 2));
  // lit volume: shifted inward toward the light
  const litInner = outline.map(p => [p[0] * 0.76 + sh[0] * 0.12 + LIGHT[0] * 1.1, p[1] * 0.76 + sh[1] * 0.12 + LIGHT[1] * 1.1]);
  poly(g, litInner, col(look, baseMat, 1));
  if (style === 'E') {
    const core = outline.map(p => [p[0] * 0.52 + sh[0] * 0.2 + LIGHT[0] * 2.0, p[1] * 0.52 + sh[1] * 0.2 + LIGHT[1] * 2.0]);
    poly(g, core, col(look, baseMat, 0));
  }
  // anatomy lines
  if (!fem) {
    segLine(g, P(0.86, chestW * 0.12), P(0.86, -chestW * 0.12), 1.1 * g0, col(look, baseMat, 2));  // sternum
    segLine(g, P(0.80, chestW * 0.82), P(0.90, chestW * 0.2), 1, col(look, baseMat, 2));           // pec
    for (let i = 0; i < 2; i++) segLine(g, P(0.52 - i * 0.14, waistW * 0.55), P(0.52 - i * 0.14, -waistW * 0.55), 0.9, col(look, baseMat, 2));
  } else {
    segLine(g, P(0.78, chestW * 0.86), P(0.86, chestW * 0.2), 1, col(look, baseMat, 2));
    disc(g, P(0.80, chestW * 0.52), 1.5 * g0, col(look, baseMat, 1));
  }
  segLine(g, P(0.92, -chestW * 0.5), P(0.62, -ribW * 0.9), 1, col(look, baseMat, 2));  // lat
  // trapezius into the neck
  poly(g, [P(1.00, shW * 0.58), P(1.13, shW * 0.20), P(1.13, -shW * 0.22), P(1.00, -shW * 0.62)], col(look, baseMat, 1));
  return { P, shW, chestW, waistW, hipW, g0 };
}
// clothing layers reuse the real painter's ideas but sit on the new silhouette
function clothesV(g, look, T, s) {
  const { P, shW, chestW, waistW, hipW, g0 } = T;
  const fem = look.fem;
  if (look.tank) {
    poly(g, [P(1.04, shW * 0.9), P(1.14, shW * 0.3), P(0.96, shW * 0.42), P(0.90, shW * 0.86)], col(look, 'skin', 1));
    poly(g, [P(1.04, -shW * 0.92), P(1.14, -shW * 0.32), P(0.96, -shW * 0.46), P(0.90, -shW * 0.9)], col(look, 'skin', 2));
  }
  if (look.crop) {
    poly(g, [P(0.04, hipW * 0.98), P(0.30, waistW * 1.06), P(0.46, waistW), P(0.46, -waistW), P(0.30, -waistW * 1.1), P(0.04, -hipW * 0.96)], col(look, 'skin', 1));
    segLine(g, P(0.24, waistW * 0.5), P(0.38, waistW * 0.5), 0.8, col(look, 'skin', 2));
  }
  if (look.jacket && look.inner) {
    const lo = look.crop ? 0.46 : 0.06;
    const pan = [P(lo, waistW * 0.86), P(0.66, ribW_(T) * 0.9), P(0.88, chestW * 0.86), P(1.04, shW * 0.4), P(1.04, shW * 0.02), P(lo, waistW * 0.18)];
    poly(g, pan, col(look, 'inner', 2));
    poly(g, pan.map(p => [p[0] - 0.5, p[1] - 0.6]), col(look, 'inner', 1));
    segLine(g, P(1.02, shW * 0.46), P(0.66, chestW * 0.96), 1.3, col(look, 'top', 0));
  } else if (look.vest && look.inner) {
    poly(g, [P(0.08, waistW * 0.9), P(0.80, chestW * 0.86), P(1.02, shW * 0.36), P(0.08, waistW * 0.2)], col(look, 'inner', 1));
  } else if (look.corset || look.leotard) {
    poly(g, [P(0.18, waistW * 0.92), P(0.74, chestW * 0.9), P(0.74, chestW * 0.26), P(0.18, waistW * 0.26)], col(look, 'inner', 1));
    for (let k = 0; k < 3; k++) segLine(g, P(0.3 + k * 0.14, waistW * 0.32), P(0.3 + k * 0.14, waistW * 0.82), 0.8, col(look, 'inner', 3));
  }
  if (look.stripe) segLine(g, P(0.56, -chestW * 0.92), P(0.56, chestW * 0.92), 2.1 * g0, col(look, 'stripe', 1));
  if (look.chain) {
    g.strokeStyle = FLAT.gold; g.lineWidth = 1.1;
    g.beginPath(); g.moveTo(...P(1.0, chestW * 0.6)); g.quadraticCurveTo(...P(0.72, chestW * 0.74), ...P(0.76, chestW * 0.06)); g.stroke();
  }
  if (look.robot) {
    poly(g, [P(0.5, waistW * 0.9), P(0.86, chestW * 0.8), P(0.86, chestW * 0.1), P(0.5, waistW * 0.1)], col(look, 'inner', 1));
    disc(g, P(0.70, chestW * 0.46), 1.4 * g0, FLAT.glow);
  }
  // belt sits on the pelvis, follows the hip line
  const bm = look.P.belt ? 'belt' : 'acc';
  poly(g, [P(0.02, hipW * 0.96), P(0.14, hipW * 1.0), P(0.14, -hipW * 0.98), P(0.02, -hipW * 0.92)], col(look, bm, 1));
  segLine(g, P(0.14, hipW * 0.98), P(0.14, -hipW * 0.96), 0.9, col(look, bm, 2));
  if (!fem) disc(g, P(0.08, hipW * 0.5), 1.4, FLAT.gold);
  if (look.spikes) for (let k = 0; k < 3; k++) disc(g, P(1.06, -shW * (0.84 - k * 0.28)), 0.9, look.P.metal[0]);
}
function ribW_(T) { return (T.chestW + T.waistW) / 2; }

// ---------------------------------------------------------- head
// constructed skull + jaw + hair mass, instead of a flat pasted stamp
function headV(g, look, J, s, style) {
  const hr = J.hr, fem = look.fem;
  const a = J.headA * DEG;
  g.save();
  g.translate(J.head[0], J.head[1]);
  g.rotate(a);
  const SK = 'skin', HA = 'hair';
  const rx = hr * (fem ? 0.86 : 0.92), ry = hr * 1.02;
  // --- skull mass
  g.fillStyle = col(look, SK, 2);
  g.beginPath(); g.ellipse(0, -hr * 0.12, rx, ry, 0, 0, 7); g.fill();
  // --- jaw: cheekbone -> chin, angular for men, tapered for women
  const chin = [rx * (fem ? 0.30 : 0.34), ry * (fem ? 0.90 : 0.86)];
  const jawF = [rx * (fem ? 0.80 : 0.92), ry * 0.18];
  const jawB = [-rx * 0.72, ry * 0.30];
  poly(g, [jawB, jawF, [chin[0], chin[1]], [-rx * 0.20, ry * 0.94], [-rx * 0.66, ry * 0.52]], col(look, SK, 2));
  // --- lit side of the face (light comes from upper-front)
  poly(g, [[0, -ry * 0.95], [rx * 0.88, -ry * 0.2], jawF, [chin[0], chin[1]], [rx * 0.06, ry * 0.8], [0, 0]], col(look, SK, 1));
  g.beginPath(); g.ellipse(rx * 0.12, -hr * 0.3, rx * 0.66, ry * 0.62, 0, 0, 7);
  g.fillStyle = col(look, SK, 1); g.fill();
  if (style === 'E') { g.fillStyle = col(look, SK, 0); g.beginPath(); g.ellipse(rx * 0.24, -hr * 0.45, rx * 0.34, ry * 0.3, 0, 0, 7); g.fill(); }
  // --- brow ridge and eye socket shadow
  segLine(g, [rx * 0.18, -ry * 0.28], [rx * 0.92, -ry * 0.18], hr * 0.16, col(look, SK, 2));
  // --- nose wedge
  poly(g, [[rx * 0.72, -ry * 0.14], [rx * 1.04, ry * 0.10], [rx * 0.66, ry * 0.14]], col(look, SK, 1));
  segLine(g, [rx * 1.02, ry * 0.10], [rx * 0.70, ry * 0.15], 0.9, col(look, SK, 2));
  // --- eye
  const ex = rx * 0.60, ey = -ry * 0.06;
  g.fillStyle = FLAT.eyeW; g.fillRect(ex - 0.2, ey - 1.1, 2.6, 2.0);
  g.fillStyle = FLAT.pupil; g.fillRect(ex + 1.0, ey - 1.0, 1.5, 1.9);
  segLine(g, [ex - 0.6, ey - 1.8], [ex + 2.6, ey - 1.6], 1.0, col(look, HA, 3));
  // --- mouth + jaw shadow
  segLine(g, [rx * 0.56, ry * 0.46], [rx * 0.84, ry * 0.44], 0.9, fem && look.lip ? look.lip : col(look, SK, 3));
  segLine(g, [-rx * 0.05, ry * 0.62], [rx * 0.40, ry * 0.78], 0.8, col(look, SK, 3));
  // --- ear
  disc(g, [-rx * 0.30, ry * 0.02], hr * 0.20, col(look, SK, 2));
  // --- hair as a MASS with a silhouette, not a flat cap
  const H = look.head || 'clean';
  const bald = H === 'bald' || H === 'shades';
  const helm = H === 'robot' || H === 'helm' || H === 'hardhat' || H === 'masked';
  if (helm) {
    g.fillStyle = col(look, 'acc', 2);
    g.beginPath(); g.ellipse(0, -hr * 0.16, rx * 1.10, ry * 1.06, 0, 0, 7); g.fill();
    g.fillStyle = col(look, 'acc', 1);
    g.beginPath(); g.ellipse(rx * 0.1, -hr * 0.42, rx * 0.86, ry * 0.7, 0, 0, 7); g.fill();
    g.fillStyle = OUTLINE; g.fillRect(rx * 0.1, -ry * 0.22, rx * 1.05, ry * 0.36);
    g.fillStyle = FLAT.glow; g.fillRect(rx * 0.22, -ry * 0.16, rx * 0.84, ry * 0.2);
  } else if (!bald) {
    const long = H === 'anita' || H === 'bob' || H === 'pony' || H === 'bandana';
    const spiky = H === 'mohawk' || H === 'spiky';
    g.fillStyle = col(look, HA, 2);
    g.beginPath(); g.ellipse(-rx * 0.10, -hr * 0.72, rx * 1.04, ry * 0.60, 0, 0, 7); g.fill();
    // fringe: only the top of the brow, so the face still reads
    poly(g, [[-rx * 1.00, -ry * 0.50], [rx * 0.24, -ry * 1.02], [rx * 0.96, -ry * 0.52], [rx * 0.52, -ry * 0.58], [rx * 0.02, -ry * 0.80], [-rx * 0.58, -ry * 0.44]], col(look, HA, 2));
    // lit top
    poly(g, [[-rx * 0.82, -ry * 0.70], [rx * 0.02, -ry * 1.10], [rx * 0.76, -ry * 0.64], [rx * 0.08, -ry * 0.90], [-rx * 0.48, -ry * 0.66]], col(look, HA, 1));
    segLine(g, [-rx * 0.38, -ry * 0.92], [rx * 0.24, -ry * 0.98], 1.0, col(look, HA, 0));
    if (spiky) for (let k = 0; k < 4; k++) {
      const t = -0.6 + k * 0.42;
      poly(g, [[rx * t, -ry * 0.86], [rx * (t + 0.14), -ry * 1.5], [rx * (t + 0.3), -ry * 0.84]], col(look, HA, 1));
    }
    if (long) {
      poly(g, [[-rx * 0.95, -ry * 0.5], [-rx * 1.15, ry * 1.6], [-rx * 0.3, ry * 1.7], [-rx * 0.36, ry * 0.1]], col(look, HA, 2));
      poly(g, [[-rx * 0.95, -ry * 0.5], [-rx * 1.05, ry * 1.2], [-rx * 0.72, ry * 1.3], [-rx * 0.62, -ry * 0.2]], col(look, HA, 1));
    } else {
      poly(g, [[-rx * 0.96, -ry * 0.44], [-rx * 1.02, ry * 0.42], [-rx * 0.54, ry * 0.38], [-rx * 0.5, -ry * 0.3]], col(look, HA, 2));
    }
    if (look.acc && (H === 'band' || H === 'bandana' || H === 'cap' || H === 'goggles')) {
      poly(g, [[-rx * 1.0, -ry * 0.42], [rx * 0.98, -ry * 0.36], [rx * 0.94, -ry * 0.62], [-rx * 1.0, -ry * 0.68]], col(look, 'acc', 1));
    }
  } else {
    // bald: shine on the crown
    g.fillStyle = col(look, SK, 0);
    g.beginPath(); g.ellipse(rx * 0.1, -ry * 0.62, rx * 0.44, ry * 0.2, 0, 0, 7); g.fill();
    if (H === 'shades') { g.fillStyle = OUTLINE; g.fillRect(rx * 0.1, -ry * 0.28, rx * 1.0, ry * 0.30); }
  }
  g.restore();
}

// ---------------------------------------------------------- assembly
function paintFigureV(g, look, J, weapon, style) {
  const s = J.s;
  if (style === 'A') return paintFigure(g, look, J, weapon);
  armV(g, look, J.a1, true, s, style);
  legV(g, look, J.l1, true, s, style);
  const T = torsoV(g, look, J, s, style);
  legV(g, look, J.l2, false, s, style);
  if (look.skirt) paintSkirt(g, look, J, s);
  clothesV(g, look, T, s);
  // neck: a real column into the jaw
  const nk = (look.fem ? 3.6 : 4.8) * s * (look.girth || 1);
  taper(g, look, lp(J.sh, J.neck, 0.1), lp(J.neck, J.head, 0.42), nk * 1.06, nk * 0.9, 'skin', false, 0);
  if (style === 'B' || style === 'S' || style === 'T') paintStamp(g, look, look.head, Math.round(J.head[0]), Math.round(J.head[1]), J.hs);
  else headV(g, look, J, s, style);
  const wt = weapon && weaponTip(J, look, weapon);
  if (wt) {
    seg3(g, look, wt.b, wt.e, wt.G.w * s * 0.8, wt.G.mat, false);
    if (wt.G.grip) segLine(g, wt.b, lp(wt.b, wt.e, 0.35), wt.G.w * s, col(look, 'wood', 2));
  }
  armV(g, look, J.a2, false, s, style);
}
function getFrameV(look, poseName, style, weapon) {
  const key = 'V' + style + '|' + look.id + '|' + poseName + '|' + (weapon || '');
  let f = FRAMES.get(key);
  if (f) return f;
  const HP = HEAD_PROP;
  HEAD_PROP = style !== 'A';          // the fix is part of the rebuild
  const r = withProps(style, (p) => {
    const saved = look.headR;
    look.headR = p.headR;
    const J = solvePose(POSES[poseName] || POSES.idle, look);
    const bb = figureBBox(look, J, weapon);
    f = bakeGeneric(look, [bb[0] - 3, bb[1] - 3, bb[2] + 3, bb[3] + 3], gg => {
      gg.translate(0, J.snap); gg.rotate(J.rot * DEG);
      paintFigureV(gg, look, J, weapon, style);
    });
    look.headR = saved;
    f.J = J;
    FRAMES.set(key, f);
    return f;
  });
  HEAD_PROP = HP;
  return r;
}
function drawFigureV(x, y, facing, poseName, look, style, o = {}) {
  const f = getFrameV(look, poseName, style, o.weapon);
  blitFrame(f, x, y, facing, o);
  return f;
}
window.__lab = { drawFigureV, getFrameV, PROPS };
