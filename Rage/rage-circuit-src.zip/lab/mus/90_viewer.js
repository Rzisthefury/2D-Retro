// ============================================================ the music picker
// Four bands playing the same scene. The still behind each player is the
// actual stage 1 background at the actual game resolution, so the track can be
// judged against what will be on screen while it plays.
const OPTIONS = [
  { k: 'M1', song: S1_ROCK, still: 'el',
    tag: 'GUITAR LED',
    pitch: 'A rock band playing a fight scene. Overdriven guitar carries the tune over palm-muted eighths and a picked bass.',
    notes: [
      'Lead guitar has the melody the whole way through, with a clean guitar harmonising a third under it in the chorus',
      'Organ sits underneath holding the chords - you feel it more than hear it',
      'Breakdown at 0:50 drops to clean guitar and a bell arpeggio before the last chorus',
      'The most direct of the four, and the closest to Streets of Rage 3',
    ] },
  { k: 'M2', song: S1_FUSION, still: 'el',
    tag: 'KEYS LED',
    pitch: 'Electric piano and a chorused clean guitar trade the melody over a walking bass and a lighter kit. Seventh chords throughout.',
    notes: [
      'Slowest and warmest of the four at 126 - swung sixteenths rather than straight',
      'Rhodes comps the chords and answers the lead line in the second half of each phrase',
      'Ride cymbal takes over from hats when the chorus arrives, which opens the track up',
      'Closest to what Streets of Rage 2 actually sounded like',
    ] },
  { k: 'M3', song: S1_SYNTH, still: 'el',
    tag: 'SYNTH LED',
    pitch: 'Analog pads and a running arpeggio carry the harmony; the guitar plays a counter-line instead of the tune. Big sub, gated snare.',
    notes: [
      'Sixteenth-note arpeggio runs under everything - the motion comes from that, not from the drums',
      'Melody is on a bright poly synth with the guitar answering it an octave down',
      'Straight time, no swing, deep kick - driving without ever being techno',
      'The one that would sit most comfortably next to the neon of stage 2',
    ] },
  { k: 'M4', song: S1_HEAVY, still: 'el',
    tag: 'RIFF LED',
    pitch: 'Two detuned guitars playing the riff itself, organ stabs filling underneath, and a kit that leans on the backbeat instead of marching.',
    notes: [
      'Fastest at 150, power chords with no thirds, fuzz rather than crunch',
      'Lead is doubled an octave up in the chorus - two guitars in harmony, not one',
      'Ghost notes on the snare and a swung feel give it a groove the others do not have',
      'This kit is the one that would carry the drum and bass stage best',
    ] },
];

// ---- transport -----------------------------------------------------------
let started = false, playing = null, raf = 0;
function ensureAudio() {
  if (started) return;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  initBand(new Ctx());
  started = true;
}
function stopAll() {
  Band.stop();
  playing = null;
  document.querySelectorAll('.card').forEach(c => c.classList.remove('playing'));
  document.querySelectorAll('.play').forEach(b => { b.textContent = 'Play'; });
  cancelAnimationFrame(raf);
  document.querySelectorAll('.bar i').forEach(b => { b.style.width = '0%'; });
  document.querySelectorAll('.pos').forEach(p => { p.textContent = '0:00'; });
}
function toggle(opt, card) {
  ensureAudio();
  if (AC.state !== 'running') AC.resume();
  if (playing === opt.k) { stopAll(); return; }
  stopAll();
  playing = opt.k;
  card.classList.add('playing');
  card.querySelector('.play').textContent = 'Stop';
  Band.play(opt.k, { [opt.k]: opt.song });
  const t0 = AC.currentTime;
  const total = songSeconds(opt.song);
  const bar = card.querySelector('.bar i'), pos = card.querySelector('.pos');
  const tick = () => {
    if (playing !== opt.k) return;
    const el = (AC.currentTime - t0) % total;
    bar.style.width = (el / total * 100).toFixed(1) + '%';
    pos.textContent = fmtTime(el);
    raf = requestAnimationFrame(tick);
  };
  tick();
}
const fmtTime = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');

// ---- picks ---------------------------------------------------------------
const PICK_KEY = 'rc_mus_picks_s1';
let picks = {};
try { picks = JSON.parse(localStorage.getItem(PICK_KEY) || '{}'); } catch (e) { picks = {}; }
function savePicks() { try { localStorage.setItem(PICK_KEY, JSON.stringify(picks)); } catch (e) {} }
function refresh() {
  document.querySelectorAll('.card').forEach(c => c.classList.toggle('picked', picks.s1 === c.dataset.k));
  document.querySelectorAll('.pick').forEach(b => {
    b.textContent = picks.s1 === b.closest('.card').dataset.k ? 'Picked' : 'Pick this';
  });
  const s = document.getElementById('summary');
  if (!picks.s1) { s.textContent = 'Pick one and this line becomes the message to send back.'; return; }
  const o = OPTIONS.find(x => x.k === picks.s1);
  s.textContent = picks.s1 + ' \u2014 ' + o.song.name;
}

// ---- build the page ------------------------------------------------------
function buildPage() {
  const wrap = document.getElementById('cards');
  for (const opt of OPTIONS) {
    const total = songSeconds(prepSong(opt.song));
    const card = document.createElement('section');
    card.className = 'card'; card.dataset.k = opt.k;
    card.innerHTML =
      '<div class="screen"><img alt="Stage 1 background" src="' + STILLS[opt.still] + '">' +
        '<span class="tag">' + opt.tag + '</span>' +
      '</div>' +
      '<div class="body">' +
        '<div class="titlerow">' +
          '<h3><span class="key">' + opt.k + '</span>' + opt.song.name + '</h3>' +
          '<button class="pick" type="button">Pick this</button>' +
        '</div>' +
        '<p class="pitch">' + opt.pitch + '</p>' +
        '<ul class="notes">' + opt.notes.map(n => '<li>' + n + '</li>').join('') + '</ul>' +
        '<div class="transport">' +
          '<button class="play" type="button">Play</button>' +
          '<div class="bar"><i></i></div>' +
          '<span class="pos">0:00</span><span class="sep">/</span><span class="len">' + fmtTime(total) + '</span>' +
        '</div>' +
        '<p class="meta">' + opt.song.bpm + ' bpm \u00b7 ' + opt.song._bars + ' bars before it repeats \u00b7 A minor</p>' +
      '</div>';
    card.querySelector('.play').addEventListener('click', () => toggle(opt, card));
    card.querySelector('.pick').addEventListener('click', () => {
      picks.s1 = picks.s1 === opt.k ? undefined : opt.k;
      if (!picks.s1) delete picks.s1;
      savePicks(); refresh();
    });
    wrap.appendChild(card);
  }
  refresh();
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') stopAll(); });
buildPage();
