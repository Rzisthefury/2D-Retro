const OPTIONS = [
  { k: 'F1', song: S6_CAST, still: 'cast', tag: 'HOT',
    pitch: 'Heat rather than weight. Fast, bright, the most aggressive guitar in the game so far, over scaffold metal with a furnace roaring underneath it.',
    notes: [
      'C minor - the highest key in the run, which puts the melody up where heat lives instead of down where weight does',
      'The tune starts high and falls, which nothing else in the soundtrack does',
      'Written for the cast house; it would make the molten river feel like the danger it is',
    ] },
  { k: 'F2', song: S6_LINE, still: 'line', tag: 'MECHANICAL',
    pitch: 'Written for the welding arms. Everything sits exactly on the grid - no swing, no human timing anywhere - and the melody is a repeating cell that steps rather than a tune that goes somewhere.',
    notes: [
      'The kick never moves off the beat and the metal never moves off the off-beat. Deliberately inhuman',
      'The only thing in it that bends a note is the guitar, and it only turns up to do that',
      'Cold and blue where F1 is orange - it belongs to the robot line specifically',
    ] },
  { k: 'F3', song: S6_POUR, still: 'torpedo', tag: 'MASS',
    pitch: 'The torpedo yard, and the weight of what they move around in it. Half time at 132 so it drags, furnace roaring long underneath, metal ringing a very long way off.',
    notes: [
      'A handful of notes and a great deal of nothing - the sparsest melody in the game',
      'Mass and heat rather than impact; it is not the pile driver from stage 3 again',
      'The slowest thing here and the one that would make the yard feel enormous',
    ] },
  { k: 'F4', song: S6_HAZE, still: 'cast', tag: 'WIDE',
    pitch: 'The wildcard: the works at the end of a shift. Everything still glowing, nothing still running. Wide, shimmering and almost beautiful, with the furnace breathing rather than roaring.',
    notes: [
      'The calm option, which has now won twice - stage 3 and stage 5 both went this way',
      'Struck metal rings for over a second here, so it reads as distance rather than rhythm',
      'Would work on any of the three rooms, which none of the other three really would',
    ] },
];
const SCENES = [
  { id: 's6a', label: 'Cast House' },
  { id: 's6b', label: 'The Line' },
  { id: 's6c', label: 'Torpedo' },
];

let started = false, playing = null, raf = 0;
function ensureAudio() {
  if (started) return;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  initBand(new Ctx());
  started = true;
}
function stopAll() {
  Band.stop(); playing = null;
  document.querySelectorAll('.card').forEach(c => c.classList.remove('playing'));
  document.querySelectorAll('.play').forEach(b => { b.textContent = 'Play'; });
  cancelAnimationFrame(raf);
  document.querySelectorAll('.bar i').forEach(b => { b.style.width = '0%'; });
  document.querySelectorAll('.pos').forEach(p => { p.textContent = '0:00'; });
}
function toggle(opt, card) {
  ensureAudio();
  if (AC.state !== 'running') AC.resume();
  if (playing === opt.k) { stopAll(); return; }
  stopAll();
  playing = opt.k;
  card.classList.add('playing');
  card.querySelector('.play').textContent = 'Stop';
  Band.play(opt.k, { [opt.k]: opt.song });
  const t0 = AC.currentTime, total = songSeconds(opt.song);
  const bar = card.querySelector('.bar i'), pos = card.querySelector('.pos');
  const tick = () => {
    if (playing !== opt.k) return;
    const el = (AC.currentTime - t0) % total;
    bar.style.width = (el / total * 100).toFixed(1) + '%';
    pos.textContent = fmtTime(el);
    raf = requestAnimationFrame(tick);
  };
  tick();
}
const fmtTime = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');

const PICK_KEY = 'rc_mus_picks_s6';
let picks = {};
try { picks = JSON.parse(localStorage.getItem(PICK_KEY) || '{}'); } catch (e) { picks = {}; }
function savePicks() { try { localStorage.setItem(PICK_KEY, JSON.stringify(picks)); } catch (e) {} }
function refresh() {
  document.querySelectorAll('.card').forEach(c => {
    const k = c.dataset.k;
    const mine = SCENES.filter(s => picks[s.id] === k);
    c.classList.toggle('picked', mine.length > 0);
    c.querySelectorAll('.pick').forEach(b => {
      const on = picks[b.dataset.scene] === k;
      b.classList.toggle('on', on);
      b.textContent = (on ? '\u2713 ' : '') + b.dataset.label;
    });
  });
  const s = document.getElementById('summary');
  const parts = SCENES.filter(x => picks[x.id]).map(x => {
    const o = OPTIONS.find(y => y.k === picks[x.id]);
    return x.label + ': ' + picks[x.id] + ' \u2014 ' + o.song.name;
  });
  s.textContent = parts.length ? parts.join('   \u00b7   ')
    : 'Pick one for each scene and this line becomes the message to send back.';
}

function buildPage() {
  const wrap = document.getElementById('cards');
  for (const opt of OPTIONS) {
    const total = songSeconds(prepSong(opt.song));
    const card = document.createElement('section');
    card.className = 'card'; card.dataset.k = opt.k;
    card.innerHTML =
      '<div class="screen"><img alt="Stage 2 background" src="' + STILLS[opt.still] + '">' +
        '<span class="tag">' + opt.tag + '</span>' +
      '</div>' +
      '<div class="body">' +
        '<div class="titlerow">' +
          '<h3><span class="key">' + opt.k + '</span>' + opt.song.name + '</h3>' +
          '<div class="picks">' + SCENES.map(s =>
            '<button class="pick" type="button" data-scene="' + s.id + '" data-label="' + s.label + '">' + s.label + '</button>'
          ).join('') + '</div>' +
        '</div>' +
        '<p class="pitch">' + opt.pitch + '</p>' +
        '<ul class="notes">' + opt.notes.map(n => '<li>' + n + '</li>').join('') + '</ul>' +
        '<div class="transport">' +
          '<button class="play" type="button">Play</button>' +
          '<div class="bar"><i></i></div>' +
          '<span class="pos">0:00</span><span class="sep">/</span><span class="len">' + fmtTime(total) + '</span>' +
        '</div>' +
        '<p class="meta">' + opt.song.bpm + ' bpm \u00b7 ' + opt.song._bars + ' bars before it repeats \u00b7 C minor</p>' +
      '</div>';
    card.querySelector('.play').addEventListener('click', () => toggle(opt, card));
    card.querySelectorAll('.pick').forEach(b => b.addEventListener('click', () => {
      const sc = b.dataset.scene;
      if (picks[sc] === opt.k) delete picks[sc]; else picks[sc] = opt.k;
      savePicks(); refresh();
    }));
    wrap.appendChild(card);
  }
  refresh();
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') stopAll(); });
buildPage();
