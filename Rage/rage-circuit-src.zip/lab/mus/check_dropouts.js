// Why does a track seem to STOP for a few seconds mid-fight?
//
// The offline render only shows the level dipping, never going silent, so the
// question is what the arrangement is actually doing bar by bar. This walks a
// song's form the same way the live player does and counts how many voices
// fire in each bar, split by lane, plus the section's gain. A bar with almost
// nothing in it is a bar that vanishes under combat SFX - which is what a
// player hears as the music cutting out.
//
// Run it with no arguments to check every track; name tracks to look at just
// those. Exits non-zero if any looping track has a passage over 2 seconds where
// both the beat and the tune collapse, or if any form section names a pattern
// the song does not define. Run it after touching any song, before rendering.
//
//   node check_dropouts.js              every track, pass/fail
//   node check_dropouts.js boss boss3   just these two, with the bar-by-bar
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');

const FILES = ['00_eng.js', '01_seq.js', '04_stage1.js', '06_stage2.js', '08_stage3.js',
               '10_stage4.js', '12_stage5.js', '14_stage6.js', '16_stage7.js', '18_stage8.js',
               '19_front.js', '20_cues.js'];

(async () => {
  const ALL = ['stage1a', 'stage1b', 'boss', 'stage2a', 'stage2b', 'boss2',
    'stage3a', 'stage3b', 'boss3', 'stage4a', 'stage4b', 'boss4',
    'stage5a', 'stage5b', 'boss5', 'stage6a', 'stage6b', 'stage6c', 'boss6',
    'stage7a', 'stage7b', 'stage7c', 'boss7', 'stage8a', 'stage8b', 'stage8c',
    'boss8', 'boss8x', 'title', 'menu', 'shop', 'training', 'ending',
    'cue_unit9', 'cue_roof'];
  const args = process.argv.slice(2);
  const want = args.length ? args : ALL;
  const quiet = !args.length;          // the full sweep prints only failures
  let fails = 0;
  const src = FILES.map(f => fs.readFileSync(path.join(__dirname, f), 'utf8')).join('\n');
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.goto('about:blank');
  // top-level `const` lives in script scope, not on window, so the song table
  // has to be built inside the same script tag that declares the songs.
  const expose = `
  window.__SONGS = { stage1a: T_stage1a, stage1b: T_stage1b, boss: T_boss1,
    stage2a: T_stage2a, stage2b: T_stage2b, boss2: T_boss2,
    stage3a: T_stage3a, stage3b: T_stage3b, boss3: T_boss3,
    stage4a: T_stage4a, stage4b: T_stage4b, boss4: T_boss4,
    stage5a: T_stage5a, stage5b: T_stage5b, boss5: T_boss5,
    stage6a: T_stage6a, stage6b: T_stage6b, stage6c: T_stage6c, boss6: T_boss6,
    stage7a: T_stage7a, stage7b: T_stage7b, stage7c: T_stage7c, boss7: T_boss7,
    stage8a: T_stage8a, stage8b: T_stage8b, stage8c: T_stage8c, boss8: T_boss8, boss8x: T_boss8x,
    title: T_title, menu: T_menu, shop: T_shop, training: T_training, ending: T_ending,
    cue_unit9: C_unit9, cue_roof: C_roof };
  window.__Kit = Kit; window.__Gtr = Gtr; window.__Keys = Keys; window.__Bass = Bass; window.__initBand = initBand; window.__prepSong = prepSong; window.__stepEvents = stepEvents;`;
  await page.addScriptTag({ content: src + expose });

  const out = await page.evaluate(async (names) => {
    const SR = 8000;
    const res = [];
    for (const name of names) {
      const S = window.__SONGS[name];
      if (!S) { res.push({ name, missing: true }); continue; }
      const ctx = new OfflineAudioContext(2, SR * 2, SR);
      window.__initBand(ctx);
      window.__prepSong(S);
      // Count what each bar actually contains, split three ways, because that
      // is what decides whether a bar reads as the music stopping:
      //   kit    - is there still a beat?
      //   melody - is there still a tune (guitar, keys, lead, arp)?
      //   bass   - is there still a bottom end?
      // A bar with all three is never a dropout however sparse it looks next
      // to the fullest bar in the track, and a bar missing the beat or the
      // tune is a dropout however many notes it has.
      let tally = null;
      const tag = (obj, k) => { for (const fn of Object.keys(obj)) {
        const o = obj[fn]; if (typeof o !== 'function') continue;
        obj[fn] = function (...a) { if (tally) tally[k]++; return o.apply(obj, a); };
      } };
      tag(window.__Kit, 'kit'); tag(window.__Gtr, 'melody');
      tag(window.__Keys, 'melody'); tag(window.__Bass, 'bass');
      const spb = 60 / S.bpm / 4;
      const bars = [];
      let err = null;
      const from = S._loopFrom || 0;
      let sec = from, secBar = 0, t = 0;
      const loopBars = S.form.slice(from).reduce((n, F) => n + F.bars, 0);
      const introBars = S._bars - loopBars;
      for (let b = 0; b < loopBars; b++) {
        const F = S.form[sec];
        tally = { kit: 0, melody: 0, bass: 0 };
        try {
          for (let step = 0; step < 16; step++) { window.__stepEvents(S, sec, secBar, step, t, spb); t += spb; }
        } catch (e) { err = `bar ${b} sec ${sec}: ${e.message}`; break; }
        bars.push({ b, sec, gain: F.gain === undefined ? 1 : F.gain,
                    kit: tally.kit, melody: tally.melody, bass: tally.bass,
                    nodes: tally.kit + tally.melody + tally.bass,
                    lanes: ['drums', 'bass', 'gtr', 'keys', 'lead', 'harm', 'arp'].filter(k => F[k]).join('+') });
        secBar++;
        if (secBar >= F.bars) { secBar = 0; sec++; if (sec >= S.form.length) sec = from; }
      }
      tally = null;
      // A form section naming a pattern the song does not define produces a
      // silent lane and no error at all. Catch it here.
      const TABLES = { drums: 'drums', breaks: 'breaks', bass: 'bass', gtr: 'gtr',
                       keys: 'keys', lead: 'leads', harm: 'leads', arp: 'arps' };
      const bad = [];
      S.form.forEach((F, i) => {
        for (const key in TABLES) {
          const want = F[key];
          if (!want) continue;
          const table = S[TABLES[key]] || {};
          if (!(want in table)) bad.push(`sec${i} ${key}:'${want}' is not in ${TABLES[key]}`);
        }
      });
      res.push({ name, bpm: S.bpm, barSecs: 16 * spb, totalBars: S._bars, loopBars, introBars, bars, err, bad });
    }
    return res;
  }, want);

  for (const r of out) {
    if (r.missing) { console.log(`\n${r.name}: NOT FOUND`); continue; }
    if (!quiet) console.log(`\n=== ${r.name}  ${r.bpm}bpm  ${r.totalBars} bars  ${r.barSecs.toFixed(2)}s/bar` +
      `  intro ${(r.introBars * r.barSecs).toFixed(1)}s (once)  loop ${(r.loopBars * r.barSecs).toFixed(1)}s`);
    if (r.err) { console.log(`${r.name}: THREW: ${r.err}`); fails++; }
    for (const b of r.bad || []) { console.log(`${r.name}: BAD PATTERN NAME: ${b}   (this lane plays nothing)`); fails++; }
    const peak = Math.max(...r.bars.map(x => x.nodes));
    // THE RULE, and it has to be RELATIVE to the track's own texture. A player
    // hears the music stop because it was fuller a moment ago - so what counts
    // is a collapse against this track's norm, not an absolute floor. The
    // Birthing Floor runs on six kit hits a bar from end to end and never
    // sounds like it stopped; stage 1's boss fell to a quarter of its own norm
    // with no melody at all, and that is what got noticed.
    //
    // A bar is a dropout when the beat AND the tune go at the same time. Losing
    // the beat alone is a drum-and-bass drop, which is the whole point of stage
    // 5. Losing the tune alone is a breakdown you can still follow.
    const med = k => { const v = r.bars.map(x => x[k]).sort((a, b) => a - b); return v[Math.floor(v.length / 2)] || 0; };
    const mKit = med('kit'), mTop = med('melody') + med('bass');
    const dropout = x =>
      (mKit > 4 && x.kit === 0) ||                                        // no beat at all
      (x.kit < mKit * 0.35 && x.melody + x.bass < mTop * 0.6) ||          // both collapse together
      (x.melody === 0 && x.bass <= 2);                                    // nothing pitched left
    let runStart = null;
    for (let i = 0; i <= r.bars.length; i++) {
      const x = r.bars[i];
      const thin = x && dropout(x);
      if (thin && runStart === null) runStart = i;
      if (!thin && runStart !== null) {
        const secs = (i - runStart) * r.barSecs;
        const over = secs >= 2 && !/^cue_/.test(r.name);
        if (over) fails++;
        if (over || !quiet) {
          console.log(`${quiet ? r.name + ': ' : '  '}HOLE in loop: bars ${runStart}-${i - 1}` +
            `  ${(runStart * r.barSecs).toFixed(1)}s into the loop  lasts ${secs.toFixed(1)}s` +
            (over ? '   <<< over 2s, will read as the music stopping' : ''));
        }
        runStart = null;
      }
    }
    if (quiet) continue;
    for (const x of r.bars) {
      const frac = x.nodes / peak;
      console.log(`  bar ${String(x.b).padStart(2)} sec${x.sec} g${x.gain}` +
        ` kit${String(x.kit).padStart(3)} mel${String(x.melody).padStart(3)} bass${String(x.bass).padStart(3)}` +
        ` ${'#'.repeat(Math.round(frac * 24)).padEnd(24)} ${x.lanes}`);
    }
  }
  if (errs.length) { console.log('\nPAGE ERRORS:\n' + errs.join('\n')); fails++; }
  await browser.close();
  console.log(fails ? `\n${fails} PROBLEM${fails > 1 ? 'S' : ''} - fix before rendering`
                    : `\nall ${want.length} tracks clean: no dropouts, no bad pattern names`);
  process.exit(fails ? 1 : 0);
})();
