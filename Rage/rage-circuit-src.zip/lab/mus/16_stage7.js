// ============================================================ STAGE 7, final
// G3 CHILLER won, so the lab is played by the refrigeration plant: filtered
// bass with the bottom octave missing, tremolo-picked guitar, saw stabs, and a
// tune that falls the whole way down while every other stage in the game
// climbs. The palette does not move between these four - same voices, same
// waves, same drive, same hook - only tempo, density and tone.
//
// THE HOOK, unchanged in all four (degrees above D5):
//     12 10 8 7 5 3 2 0 | 12 10 8 7 5 | 19 17 15 14 12 10 8 7 | 5 3 2 0
//
// ONE THING IS ARRANGED ACROSS THE STAGE RATHER THAN WITHIN A TRACK.
// Chiller's whole character is the hole where the bottom octave should be, and
// it measured 19.2% low end against a game that runs 21-47%. On one track that
// reads as deliberate. On four it reads as a stage that sounds broken next to
// the six before it. So the hole is the stage's ARC instead of its constant:
//
//   7A CLEAN CORRIDOR  - no bottom at all. The room where everything seems
//                        clean and there is nothing underneath it.
//   7B THE COLD STORE  - the plant as picked. Still hollow.
//   7C THE BIRTHING FLOOR - the bottom finally arrives, because this is the
//                        room where you find out what is actually under it.
//   BOSS 7             - UNIT-8. Full weight, and the thing in front of you.
//
// That is a density and tone change, not a palette change: same pick bass, just
// with the sub layer faded up as the stage goes down.

// ---- 7A: THE CLEAN CORRIDOR -----------------------------------------------
// Fluorescent, near-white, glass windows into rooms marked NO ENTRY and WASH.
// The plant is running somewhere behind the walls rather than in here, so this
// is Chiller heard through a building: slower, thinner, more space around it,
// and absolutely nothing holding up the bottom.
const T_stage7a = {
  name: 'The Clean Corridor', bpm: 140, key: 62, lkey: 74, swing: 0, echo: 1.2, level: 0.94,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3500, gain: -4 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: false },
    hiss: { vol: 0.10, f0: 3600, f1: 1600 }, clank: { ring: 0.10, pitch: 620, vol: 0.4 },
    // the hollowest thing in the game, on purpose and only here
    bass: { vol: 0.30, bright: 3000, close: 700 },
    gtr:  { vol: 0.15, drive: 'crunch', tone: 3400, send: 0.28, echo: 0.18 },
    keys: { vol: 0.06, bright: 4200, wave: 'sawtooth' },
    lead: { vol: 0.28, bright: 4400, send: 0.30, echo: 0.22, wave: 'sawtooth' },
    harm: { vol: 0.12, drive: 'crunch', tone: 3200, send: 0.26, echo: 0.14 },
    arp:  { vol: 0.065, wave: 'triangle', tone: 3800, echo: 0.24 },
  },
  chords: {
    main: [[0, 'm'], [5, 'm'], [-2, 'M'], [0, 'm']],
    lift: [[-2, 'M'], [3, 'M'], [5, 'm'], [0, 'm']],
    turn: [[5, 'm'], [-2, 'M'], [3, 'M'], [0, 'm']],
  },
  drums: {
    intro: { h: '..x...x...x...x.', a: 'X...............' },
    main: {
      k: ['X..X....X.......', 'X..X....X.......'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...x.', '..x...x...x...xo'],
      m: ['..............x.', '................'],
    },
    push: {
      k: ['X..X....X..X....', 'X..X....X..X....'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'x.x.x.x.x.x.x.x.',
      m: ['......x.......x.', '......x.......x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X..X............', h: '........x.......', a: '........X.......' },
    fill: { k: 'X..X....X..X....', s: '....X.......X.Xx', m: '..........x...x.' },
  },
  bass: {
    main: [P('0 . . . . . 0 . 0 . . . . . 0 .'), P('0 . . . . . 0 . 0 . . . . . 10 .')],
    run:  [P('0 . 0 . 5 . 0 . 7 . 5 . 0 . 3 .'), P('0 . 5 . 0 . 7 . 0 . 3 . 5 . 0 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    trem: [P('0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0'), P('0 0 0 0 0 0 0 0 5 5 5 5 5 5 5 5')],
    stab: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    pulse: [P('0 . . . 0 . . . 0 . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('12 . 10 . 8 . 7 . 5 . 3 . 2 . 0 .'),
        P('12 . 10 . 8 . 7 . 5 . . . . . . .'),
        P('19 . 17 . 15 . 14 . 12 . 10 . 8 . 7 .'),
        P('5 . 3 . 2 . 0 . . . . . . . . .')],
    B: [P('24 . 22 . 20 . 19 . 17 . . . 19 . . .'),
        P('22 . 20 . 19 . 17 . 15 . . . . . . .'),
        P('24 . 22 . 21 . 19 . 17 . 15 . 14 . 12 .'),
        P('14 . 12 . 10 . . . . . . . . . . .')],
    C: [P('12 . . . 10 . . . 8 . . . 7 . . .'),
        P('12 . . . 10 . . . 8 . . . . . . .'),
        P('19 . . . 17 . . . 15 . . . 14 . . .'),
        P('5 . . . 2 . . . 0 . . . . . . .')],
    Bh: [P('19 . 17 . 15 . 14 . 12 . 10 . 9 . 7 .'),
         P('19 . 17 . 15 . 14 . 12 . . . . . . .'),
         P('24 . 22 . 20 . 19 . 17 . 15 . 14 . 12 .'),
         P('12 . 10 . 9 . 7 . . . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', keys: 'pulse', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'run', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'run', gtr: 'stab', keys: 'pulse', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'run', gtr: 'stab' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'run', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A' },
  ],
};

// ---- 7B: THE COLD STORE ---------------------------------------------------
// Chiller as it played in the picker. You are standing inside the plant now,
// so this is the fastest and busiest of the four and the only one that is
// exactly what you heard.
const T_stage7b = {
  name: 'The Cold Store', bpm: 152, key: 62, lkey: 74, swing: 0, echo: 1.1, level: 0.94,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3500, gain: -3.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: false },
    hiss: { vol: 0.12, f0: 3400, f1: 1400 }, clank: { ring: 0.10, pitch: 620, vol: 0.5 },
    bass: { vol: 0.32, bright: 2800, close: 620 },
    gtr:  { vol: 0.17, drive: 'crunch', tone: 3400, send: 0.22, echo: 0.14 },
    keys: { vol: 0.06, bright: 4200, wave: 'sawtooth' },
    lead: { vol: 0.28, bright: 4600, send: 0.24, echo: 0.18, wave: 'sawtooth' },
    harm: { vol: 0.13, drive: 'crunch', tone: 3200, send: 0.22, echo: 0.12 },
    arp:  { vol: 0.065, wave: 'triangle', tone: 3800, echo: 0.20 },
  },
  chords: {
    main: [[0, 'm'], [5, 'm'], [-2, 'M'], [0, 'm']],
    lift: [[-2, 'M'], [3, 'M'], [5, 'm'], [0, 'm']],
    turn: [[5, 'm'], [-2, 'M'], [3, 'M'], [0, 'm']],
  },
  drums: {
    intro: { h: 'x.x.x.x.x.x.x.x.', a: 'X.......x.......' },
    main: {
      k: ['X..X....X.......', 'X..X....X..X....'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'x.x.x.x.x.x.x.x.',
      m: ['......x.......x.', '......x.......x.'],
    },
    push: {
      k: ['X..X....X..X....', 'X..X....X..X..x.'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'xxxxxxxxxxxxxxxx',
      m: ['......x.......x.', '......x...x...x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X..X............', h: '........x.......', a: '........X.......' },
    fill: { k: 'X..X....X..X....', s: '....X...x...X.Xx', m: '..........x...x.' },
  },
  bass: {
    main: [P('0 . 0 . . . 0 . 0 . 0 . . . 0 .'), P('0 . 0 . . . 0 . 0 . 0 . . . 10 .')],
    run:  [P('0 . 0 . 5 . 0 . 7 . 5 . 0 . 3 .'), P('0 . 5 . 0 . 7 . 0 . 3 . 5 . 0 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    trem: [P('0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0'), P('0 0 0 0 0 0 0 0 5 5 5 5 5 5 5 5')],
    stab: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    pulse: [P('0 . . . 0 . . . 0 . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('12 . 10 . 8 . 7 . 5 . 3 . 2 . 0 .'),
        P('12 . 10 . 8 . 7 . 5 . . . . . . .'),
        P('19 . 17 . 15 . 14 . 12 . 10 . 8 . 7 .'),
        P('5 . 3 . 2 . 0 . . . . . . . . .')],
    B: [P('24 . 22 . 20 . 19 . 17 . . . 19 . . .'),
        P('22 . 20 . 19 . 17 . 15 . . . . . . .'),
        P('24 . 22 . 21 . 19 . 17 . 15 . 14 . 12 .'),
        P('14 . 12 . 10 . . . . . . . . . . .')],
    C: [P('12 . . . 10 . . . 8 . . . 7 . . .'),
        P('12 . . . 10 . . . 8 . . . . . . .'),
        P('19 . . . 17 . . . 15 . . . 14 . . .'),
        P('5 . . . 2 . . . 0 . . . . . . .')],
    Bh: [P('19 . 17 . 15 . 14 . 12 . 10 . 9 . 7 .'),
         P('19 . 17 . 15 . 14 . 12 . . . . . . .'),
         P('24 . 22 . 20 . 19 . 17 . 15 . 14 . 12 .'),
         P('12 . 10 . 9 . 7 . . . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.82 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'trem', keys: 'pulse', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'run', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'run', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'run', gtr: 'stab', keys: 'pulse', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'run', gtr: 'stab' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'run', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A' },
  ],
};

// ---- 7C: THE BIRTHING FLOOR -----------------------------------------------
// Near black. Tanks lit violet with shapes floating in them, one of them marked
// REJECT, and UNIT-9 awake in its capsule watching you go past. This is where
// the bottom octave finally turns up - sub at 0.7 under the same pick bass -
// because it is the room that explains the other two. Slower, darker, and the
// tremolo guitar drops to held notes, so the shivering stops and you are just
// left in there with it.
const T_stage7c = {
  name: 'The Birthing Floor', bpm: 128, key: 62, lkey: 74, swing: 0, echo: 1.5, level: 0.92,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3200, gain: -5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    hiss: { vol: 0.11, f0: 2400, f1: 800 }, clank: { ring: 0.55, pitch: 460, vol: 0.45 },
    // the weight arrives. Same voice as the other three, sub faded up.
    bass: { vol: 0.34, bright: 2000, close: 380, sub: 0.7 },
    gtr:  { vol: 0.15, drive: 'crunch', tone: 3000, send: 0.34, echo: 0.24 },
    keys: { vol: 0.07, bright: 3400, wave: 'sawtooth' },
    lead: { vol: 0.29, bright: 4000, send: 0.36, echo: 0.26, wave: 'sawtooth' },
    harm: { vol: 0.12, drive: 'crunch', tone: 2900, send: 0.30, echo: 0.18 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3200, echo: 0.30 },
  },
  chords: {
    main: [[0, 'm'], [5, 'm'], [-2, 'M'], [0, 'm']],
    lift: [[-2, 'M'], [3, 'M'], [5, 'm'], [0, 'm']],
    turn: [[5, 'm'], [-2, 'M'], [3, 'M'], [0, 'm']],
  },
  // Peak note, since I chased this for several renders: no song-level setting
  // gets this track to zero clipped samples, because `level` feeds the BUS
  // COMPRESSOR rather than the output. Lowering it gives the compressor less
  // to work on and the peaks come through MORE intact (0.88 measured worse
  // than 0.92); raising it is worse again. 0.92 is the floor of that curve.
  // What is left is one sample in 2.2 million, and it exists only in the WAV -
  // the game's audio path is float the whole way and never quantises, so
  // nothing in the game clips. The mp3 gets a 0.5dB pad so the listening copy
  // is clean too.
  //
  // The heartbeat kick is 'X..x' here rather than 'X..X' everywhere else on
  // the stage, and it is the one thing that stops this track clipping. Two
  // beats 117ms apart is fine with the normal kick; this is the only track
  // using the DEEP one, which rings for 400ms at 36Hz, so the second beat was
  // landing on top of the first one's body and the pair of them summed over
  // the ceiling. Softening the second is also just how a heartbeat goes.
  drums: {
    intro: { a: 'X...............', m: '........o.......' },
    main: {
      k: ['X..x............', 'X..x........X...'],
      s: ['............X...', '............X...'],
      h: ['..x.......x.....', '..x.......x...x.'],
      m: ['........o.......', '................'],
      a: ['................', 'x...............'],
    },
    push: {
      k: ['X..x....X.......', 'X..x....X..X....'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...x.', '..x...x...x...xo'],
      m: ['........o.......', '....o.......o...'],
      c: ['X...............', '................'],
    },
    half: { k: 'X..x............', a: '........X.......', m: '........o.......' },
    fill: { k: 'X..x....x.......', s: '....X.......X.Xx', m: '..........o.....', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . 0 .'), P('0 . . . . . . . 0 . . . . . 10 .')],
    run:  [P('0 . . . 5 . . . 7 . . . 5 . 3 .'), P('0 . . . 7 . . . 0 . . . 3 . 5 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    // no tremolo down here. The shivering stops and it just sits on the note.
    hold: [P('0 . . . . . . . . . . . . . . .'), P('0 . . . . . . . 5 . . . . . . .')],
    stab: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    pulse: [P('0 . . . . . . . 0 . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('12 . 10 . 8 . 7 . 5 . 3 . 2 . 0 .'),
        P('12 . 10 . 8 . 7 . 5 . . . . . . .'),
        P('19 . 17 . 15 . 14 . 12 . 10 . 8 . 7 .'),
        P('5 . 3 . 2 . 0 . . . . . . . . .')],
    B: [P('24 . 22 . 20 . 19 . 17 . . . 19 . . .'),
        P('22 . 20 . 19 . 17 . 15 . . . . . . .'),
        P('24 . 22 . 21 . 19 . 17 . 15 . 14 . 12 .'),
        P('14 . 12 . 10 . . . . . . . . . . .')],
    C: [P('12 . . . 10 . . . 8 . . . 7 . . .'),
        P('12 . . . 10 . . . 8 . . . . . . .'),
        P('19 . . . 17 . . . 15 . . . 14 . . .'),
        P('5 . . . 2 . . . 0 . . . . . . .')],
    Bh: [P('19 . 17 . 15 . 14 . 12 . 10 . 9 . 7 .'),
         P('19 . 17 . 15 . 14 . 12 . . . . . . .'),
         P('24 . 22 . 20 . 19 . 17 . 15 . 14 . 12 .'),
         P('12 . 10 . 9 . 7 . . . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'hold', keys: 'pulse', arp: 'slow' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'run', gtr: 'hold', keys: 'pulse', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'run', gtr: 'hold', keys: 'pulse', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'run', gtr: 'stab', keys: 'pulse', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'run', gtr: 'stab' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'run', gtr: 'hold', keys: 'pulse', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'hold', keys: 'pulse', arp: 'run', lead: 'A' },
  ],
};

// ---- BOSS 7: UNIT-8 "WARDEN" ----------------------------------------------
// It sights down your lane before it fires. A stripe lights up on the row you
// are standing in, and then the beam comes. So the music has a TELL in it: the
// `tell` guitar part is a figure that CLIMBS - 0, 5, 7, 12 - and it is the only
// rising line anywhere on this stage, against a hook that falls the whole way
// down every single time. Four notes up, then the thing lands. Once you have
// heard it twice you know what the climb means, which is exactly the deal the
// fight is making with you.
//
// It is also the prototype they kept, and the reason the capsule on the floor
// behind you has a 9 on it. The tune does not gloat about that - it is the
// stage's tune, the same falling line as the corridor and the cold store,
// because Unit-8 is not a visitor to this building. It is what the building is.
const T_boss7 = {
  name: 'Unit-8 "Warden"', bpm: 158, key: 62, lkey: 74, swing: 0, echo: 1.0, level: 0.86,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3400, gain: -3 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    hiss: { vol: 0.13, f0: 3000, f1: 900 }, clank: { ring: 0.16, pitch: 560, vol: 0.5 },
    // full weight. Whatever else is true of it, it is standing right there.
    bass: { vol: 0.34, bright: 2400, close: 420, sub: 0.85 },
    gtr:  { vol: 0.20, drive: 'hot', tone: 3000, send: 0.20, echo: 0.12 },
    keys: { vol: 0.06, bright: 4000, wave: 'sawtooth' },
    lead: { vol: 0.30, bright: 4800, send: 0.24, echo: 0.18, wave: 'sawtooth' },
    harm: { vol: 0.19, drive: 'crunch', tone: 3200, wide: true, send: 0.22, echo: 0.12 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3800, echo: 0.18 },
  },
  chords: {
    main: [[0, 'm'], [5, 'm'], [-2, 'M'], [0, 'm']],
    // the sighting chords: fifths, no third, nothing to feel about it
    hard: [[0, '5'], [0, '5'], [-2, '5'], [5, '5']],
    turn: [[5, 'm'], [-2, 'M'], [3, 'M'], [0, 'm']],
  },
  drums: {
    intro: { h: 'x.x.x.x.x.x.x.x.', a: 'X.......X.......', m: '........x.......' },
    main: {
      k: ['X..X....X.......', 'X..X....X..X....'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'x.x.x.x.x.x.x.x.',
      m: ['......x.......x.', '......x.......x.'],
    },
    // the tell bar: air swelling under a climbing figure, then it fires
    aim: {
      k: ['X..X....X..X....', 'X..X....X..X....'],
      s: ['....X.......X...', '....X.......X..X'],
      h: 'xxxxxxxxxxxxxxxx',
      m: ['......x.......x.', '......x...x...x.'],
      a: ['X.......X.......', 'X.......X...x...'],
      c: ['X...............', '................'],
    },
    half: { k: 'X..X............', h: '........x.......', a: '........X.......' },
    fill: { k: 'X..X....X..X....', s: '....X...X...X.XX', m: '......x...x...x.', a: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 . . . 0 . 0 . 0 . . . 0 .'), P('0 . 0 . . . 0 . 0 . 0 . . . -2 .')],
    run:  [P('0 . 0 . 5 . 0 . 7 . 5 . 0 . 3 .'), P('0 . 5 . 0 . 7 . 0 . 3 . 5 . -2 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    // THE TELL. The only line on this stage that goes up.
    tell: [P('0 . . . 5 . . . 7 . . . 12 . . .'), P('0 . . . 5 . . . 7 . . . 12 . 12 .')],
    trem: [P('0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0'), P('0 0 0 0 0 0 0 0 5 5 5 5 5 5 5 5')],
    stab: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    pulse: [P('0 . . . 0 . . . 0 . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('12 . 10 . 8 . 7 . 5 . 3 . 2 . 0 .'),
        P('12 . 10 . 8 . 7 . 5 . . . . . . .'),
        P('19 . 17 . 15 . 14 . 12 . 10 . 8 . 7 .'),
        P('5 . 3 . 2 . 0 . . . . . . . . .')],
    B: [P('24 . 22 . 20 . 19 . 17 . . . 19 . . .'),
        P('22 . 20 . 19 . 17 . 15 . . . . . . .'),
        P('24 . 22 . 21 . 19 . 17 . 15 . 14 . 12 .'),
        P('14 . 12 . 10 . . . . . . . . . . .')],
    C: [P('12 . . . 10 . . . 8 . . . 7 . . .'),
        P('12 . . . 10 . . . 8 . . . . . . .'),
        P('19 . . . 17 . . . 15 . . . 14 . . .'),
        P('5 . . . 2 . . . 0 . . . . . . .')],
    Bh: [P('19 . 17 . 15 . 14 . 12 . 10 . 9 . 7 .'),
         P('19 . 17 . 15 . 14 . 12 . . . . . . .'),
         P('24 . 22 . 20 . 19 . 17 . 15 . 14 . 12 .'),
         P('12 . 10 . 9 . 7 . . . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 2, chords: 'hard', drums: 'intro', bass: 'soft', gtr: 'tell', keys: 'hold', gain: 0.84 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'trem', keys: 'pulse', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'run', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'hard', drums: 'aim', bass: 'run', gtr: 'tell', keys: 'pulse', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'aim', bass: 'run', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'hard', drums: 'fill', bass: 'run', gtr: 'tell' },
    // two bars where it stops and looks at you
    { bars: 2, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'hard', drums: 'aim', bass: 'run', gtr: 'tell', keys: 'pulse', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A', harm: 'Bh' },
  ],
};

const STAGE7_TRACKS = { S7A: T_stage7a, S7B: T_stage7b, S7C: T_stage7c, B7: T_boss7 };
