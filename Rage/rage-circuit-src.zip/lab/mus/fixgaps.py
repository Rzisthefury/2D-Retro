# One-shot edit that removed the dropout holes from the soundtrack.
#
# Every track was written off the same nine-section template, and the template
# had two faults for a loop that plays under a fight:
#   * section 0 is a sparse intro - fine once, but the form looped back to it
#     every 40-60 seconds, so the "intro" kept coming back as a hole
#   * section 6 is a turnaround with the drums on half time and one bass note,
#     which under combat SFX is not a breakdown, it is silence
#
# Fix: loopFrom so the intro plays once, and a real kit and bassline under the
# turnaround. The turnaround keeps what makes it a turnaround - its own chord
# run, its clean guitar, its gain dip - and loses only the emptiness.
#
# Kept in the repo as the record of what changed and why.
import io, re, sys

D = '/home/claude/rage/lab/mus/'

# track -> (file, const name)
WHERE = {}
for f, names in [
    ('04_stage1.js', ['T_stage1a', 'T_stage1b', 'T_boss1']),
    ('06_stage2.js', ['T_stage2a', 'T_stage2b', 'T_boss2']),
    ('08_stage3.js', ['T_stage3a', 'T_stage3b', 'T_boss3']),
    ('10_stage4.js', ['T_stage4a', 'T_stage4b', 'T_boss4']),
    ('12_stage5.js', ['T_stage5a', 'T_stage5b', 'T_boss5']),
    ('14_stage6.js', ['T_stage6a', 'T_stage6b', 'T_stage6c', 'T_boss6']),
    ('16_stage7.js', ['T_stage7a', 'T_stage7b', 'T_stage7c', 'T_boss7']),
    ('18_stage8.js', ['T_stage8a', 'T_stage8b', 'T_stage8c', 'T_boss8', 'T_boss8x']),
    ('19_front.js',  ['T_title', 'T_ending']),
]:
    for n in names:
        WHERE[n] = f

# Tracks whose section 0 is an intro: play it once, then loop past it.
LOOPFROM = list(WHERE.keys())

# Which bassline replaces the single held note under the turnaround. Every
# track's own busiest-but-steady pattern, so the palette does not change.
TURN_BASS = {
    'T_stage2b': 'four',      # this one has no 'main'
}
# The boss themes whose turnaround had no melody at all - the reason stage 1's
# boss was the one that got noticed. The song's own riff carries it instead.
BOSS_RIFF = ['T_boss1', 'T_boss2', 'T_boss3', 'T_boss4']
# The drum-and-bass stage keeps its drop, but the bass keeps moving under it.
DNB_BASS = {'T_stage5a': 'stab', 'T_stage5b': 'roll', 'T_boss5': 'grind'}


def block(src, name):
    """The text of `const <name> = { ... };`"""
    m = re.search(r'^const %s = \{' % re.escape(name), src, re.M)
    if not m:
        sys.exit('no block for ' + name)
    end = src.index('\n};', m.start()) + 3
    return m.start(), end, src[m.start():end]


changes = []
for name, fname in WHERE.items():
    path = D + fname
    src = io.open(path, encoding='utf-8').read()
    a, b, blk = block(src, name)
    orig = blk

    # ---- loopFrom -------------------------------------------------------
    if name in LOOPFROM and 'loopFrom' not in blk:
        m = re.search(r'^(  name: .*?)$', blk, re.M)
        if not m:
            sys.exit('no name line in ' + name)
        blk = blk[:m.end()] + '\n  loopFrom: 1,              // the intro plays once, not every time round' + blk[m.end():]
        changes.append((name, 'loopFrom 1'))

    # ---- the turnaround gets a kit and a bassline ------------------------
    lines = blk.split('\n')
    for i, ln in enumerate(lines):
        if "drums: 'half'" in ln:
            new = ln.replace("drums: 'half'", "drums: 'main'")
            nb = TURN_BASS.get(name, 'main')
            new = new.replace("bass: 'soft'", "bass: '%s'" % nb)
            if name in BOSS_RIFF:
                new = new.replace("gtr: 'ring'", "gtr: 'riff'").replace("gtrStyle: 'power', ", "")
            lines[i] = new
            changes.append((name, 'turnaround: half->main kit, bass->%s%s'
                            % (nb, ', gtr->riff' if name in BOSS_RIFF else '')))
        elif "breaks: 'drop'" in ln and name in DNB_BASS:
            lines[i] = ln.replace("bass: 'main'", "bass: '%s'" % DNB_BASS[name])
            changes.append((name, 'drop keeps the bass moving (%s)' % DNB_BASS[name]))
    blk = '\n'.join(lines)

    if blk != orig:
        io.open(path, 'w', encoding='utf-8').write(src[:a] + blk + src[b:])

for n, c in changes:
    print('%-12s %s' % (n, c))
print('\n%d edits across %d tracks' % (len(changes), len(set(n for n, _ in changes))))
