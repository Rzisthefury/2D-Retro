const OPTIONS = [
  { k: 'R1', song: S4_SHED, still: 'shed', tag: 'PATIENT',
    pitch: 'The shed. Enormous, empty and in no hurry: a riff that starts as machinery idling over a long reverb and slowly works out that it is a song.',
    notes: [
      'Opens with air and one bell and nothing else - it takes 30 seconds to become a track',
      'New in the kit for this stage: brake release and steam, which the roundhouse uses more than anything else',
      'The biggest reverb in the game, because the room is the size of the room',
    ] },
  { k: 'R2', song: S4_JOINTS, still: 'bridge', tag: 'RELENTLESS',
    pitch: 'Built on the train itself. The da-DUM da-DUM of bogies crossing rail joints runs the whole length of the track and never breaks; everything else is arranged around it.',
    notes: [
      'The joint pattern does not stop once - not even in the breakdown, because you are still on the train',
      'Fastest of the four at 152 and the most single-minded thing in the game',
      'Would make the bridge run feel like it cannot be got off',
    ] },
  { k: 'R3', song: S4_NIGHT, still: 'bridge', tag: 'WIDE',
    pitch: 'Stars above, water below, and the bridge structure strobing past. Fast arpeggio for the motion, wide pads for the air, and lines long enough that it feels like gliding rather than running.',
    notes: [
      'Same family as the Glass Floor, so stages 3 and 4 would rhyme if you wanted that',
      'Rail joints are in here too, but as texture under the pads rather than the engine',
      'The only one of the four that is beautiful rather than heavy',
    ] },
  { k: 'R4', song: S4_COUPLER, still: 'shed', tag: 'SWAGGER',
    pitch: 'Gauge Hollis swings a coupler like a club, and this is his reading of the stage: heavy swung blues-rock with a walk to it.',
    notes: [
      'Hard swing at 118 - slower than it feels, and the only track in the game with a shuffle',
      'Organ comping under a dirty guitar, bass walking the whole way',
      'The most human of the four; the yard as a place men work rather than a machine',
    ] },
];
const SCENES = [
  { id: 's4a', label: 'Roundhouse' },
  { id: 's4b', label: 'Bridge' },
];

let started = false, playing = null, raf = 0;
function ensureAudio() {
  if (started) return;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  initBand(new Ctx());
  started = true;
}
function stopAll() {
  Band.stop(); playing = null;
  document.querySelectorAll('.card').forEach(c => c.classList.remove('playing'));
  document.querySelectorAll('.play').forEach(b => { b.textContent = 'Play'; });
  cancelAnimationFrame(raf);
  document.querySelectorAll('.bar i').forEach(b => { b.style.width = '0%'; });
  document.querySelectorAll('.pos').forEach(p => { p.textContent = '0:00'; });
}
function toggle(opt, card) {
  ensureAudio();
  if (AC.state !== 'running') AC.resume();
  if (playing === opt.k) { stopAll(); return; }
  stopAll();
  playing = opt.k;
  card.classList.add('playing');
  card.querySelector('.play').textContent = 'Stop';
  Band.play(opt.k, { [opt.k]: opt.song });
  const t0 = AC.currentTime, total = songSeconds(opt.song);
  const bar = card.querySelector('.bar i'), pos = card.querySelector('.pos');
  const tick = () => {
    if (playing !== opt.k) return;
    const el = (AC.currentTime - t0) % total;
    bar.style.width = (el / total * 100).toFixed(1) + '%';
    pos.textContent = fmtTime(el);
    raf = requestAnimationFrame(tick);
  };
  tick();
}
const fmtTime = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');

const PICK_KEY = 'rc_mus_picks_s4';
let picks = {};
try { picks = JSON.parse(localStorage.getItem(PICK_KEY) || '{}'); } catch (e) { picks = {}; }
function savePicks() { try { localStorage.setItem(PICK_KEY, JSON.stringify(picks)); } catch (e) {} }
function refresh() {
  document.querySelectorAll('.card').forEach(c => {
    const k = c.dataset.k;
    const mine = SCENES.filter(s => picks[s.id] === k);
    c.classList.toggle('picked', mine.length > 0);
    c.querySelectorAll('.pick').forEach(b => {
      const on = picks[b.dataset.scene] === k;
      b.classList.toggle('on', on);
      b.textContent = (on ? '\u2713 ' : '') + b.dataset.label;
    });
  });
  const s = document.getElementById('summary');
  const parts = SCENES.filter(x => picks[x.id]).map(x => {
    const o = OPTIONS.find(y => y.k === picks[x.id]);
    return x.label + ': ' + picks[x.id] + ' \u2014 ' + o.song.name;
  });
  s.textContent = parts.length ? parts.join('   \u00b7   ')
    : 'Pick one for each scene and this line becomes the message to send back.';
}

function buildPage() {
  const wrap = document.getElementById('cards');
  for (const opt of OPTIONS) {
    const total = songSeconds(prepSong(opt.song));
    const card = document.createElement('section');
    card.className = 'card'; card.dataset.k = opt.k;
    card.innerHTML =
      '<div class="screen"><img alt="Stage 2 background" src="' + STILLS[opt.still] + '">' +
        '<span class="tag">' + opt.tag + '</span>' +
      '</div>' +
      '<div class="body">' +
        '<div class="titlerow">' +
          '<h3><span class="key">' + opt.k + '</span>' + opt.song.name + '</h3>' +
          '<div class="picks">' + SCENES.map(s =>
            '<button class="pick" type="button" data-scene="' + s.id + '" data-label="' + s.label + '">' + s.label + '</button>'
          ).join('') + '</div>' +
        '</div>' +
        '<p class="pitch">' + opt.pitch + '</p>' +
        '<ul class="notes">' + opt.notes.map(n => '<li>' + n + '</li>').join('') + '</ul>' +
        '<div class="transport">' +
          '<button class="play" type="button">Play</button>' +
          '<div class="bar"><i></i></div>' +
          '<span class="pos">0:00</span><span class="sep">/</span><span class="len">' + fmtTime(total) + '</span>' +
        '</div>' +
        '<p class="meta">' + opt.song.bpm + ' bpm \u00b7 ' + opt.song._bars + ' bars before it repeats \u00b7 Ab minor</p>' +
      '</div>';
    card.querySelector('.play').addEventListener('click', () => toggle(opt, card));
    card.querySelectorAll('.pick').forEach(b => b.addEventListener('click', () => {
      const sc = b.dataset.scene;
      if (picks[sc] === opt.k) delete picks[sc]; else picks[sc] = opt.k;
      savePicks(); refresh();
    }));
    wrap.appendChild(card);
  }
  refresh();
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') stopAll(); });
buildPage();
