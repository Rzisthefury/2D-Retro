// ============================================================ ONE-SHOT CUES
// Two moments in the game that are not loops. Each plays once, over the top of
// whatever is happening, and then the normal music comes back (or the ending
// starts). They are short on purpose - a cue that outstays the moment stops
// being a cue and becomes a track that interrupted the fight.
//
// The sequencer loops its form forever, so the game side plays these with
// BAND.cue(), which schedules exactly one pass and then restores.

// ---- UNIT-9 FREED ---------------------------------------------------------
// The capsule on the Birthing Floor breaks and it walks out on its own feet.
// About seven seconds.
//
// This uses G4's idea - the stage 7 option that was not picked. Its hook was
// the only one in the game that ENDED HIGHER THAN IT STARTED, and I said at the
// time it was the odd one out on purpose. As a stage track it would have played
// for four minutes before the capsule ever broke, which spends it. Here it is
// the thing itself: eight seconds, once, as the lid comes off.
//
// D minor, stage 7's key, so it sits inside the room it happens in rather than
// arriving from somewhere else.
const C_unit9 = {
  name: 'Unit-9 Freed', bpm: 132, key: 62, lkey: 74, swing: 0, echo: 1.4, level: 0.94,
  // First render came out at 27% midrange and 5.1% above 2.5kHz, well over
  // anything else in the game. A cue that bright does not read as hopeful, it
  // reads as an alarm - and it has to sit inside the Birthing Floor's mix, not
  // jump out of it.
  tone: { freq: 3500, gain: -4.5 },
  bassVoice: 'pick', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    hiss: { vol: 0.14, f0: 2600, f1: 700 },
    bass: { vol: 0.36, bright: 2200, close: 300, sub: 0.9 },
    gtr:  { vol: 0.14, tone: 3600, send: 0.36, echo: 0.22 },
    keys: { vol: 0.09, open: true, att: 0.5 },
    lead: { vol: 0.28, drive: 'clean', tone: 3200, send: 0.34, echo: 0.22, vib: 8 },
    harm: { vol: 0.13, drive: 'crunch', tone: 3000, send: 0.24, echo: 0.14 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3200, echo: 0.28 },
  },
  chords: {
    open: [[0, 'm'], [-4, 'M'], [3, 'M'], [-2, 'M']],
    up: [[3, 'M'], [-2, 'M'], [-4, 'M9'], [3, 'M7']],
  },
  drums: {
    // the lid comes off on beat one and the kit does not arrive until bar two
    lid: { a: 'X...............', c: 'X...............', k: 'X...............' },
    walk: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.x.x.x.x.x.x.x.'],
      c: ['X...............', '................'],
    },
  },
  bass: {
    rise: [P('0 . . . . . . . 5 . . . 8 . . .'), P('0 . . . 5 . . . 8 . . . 12 . . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('0 . . . . . . . 8 . . . . . . .'), P('5 . . . . . . . 12 . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // it never comes back down
    A: [P('0 . . . 5 . . . 8 . . . 12 . . .'),
        P('10 . . . 12 . . . 15 . . . 17 . . .')],
    Bh: [P('5 . . . 8 . . . 12 . . . 15 . . .'),
         P('15 . . . 17 . . . 19 . . . 20 . . .')],
  },
  arps: { rise: { notes: [0, 1, 2, 3], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 1, chords: 'open', drums: 'lid', bass: 'soft', gtr: 'hold', keys: 'hold', gain: 0.80 },
    { bars: 2, chords: 'open', drums: 'walk', bass: 'rise', gtr: 'ring', keys: 'hold', arp: 'rise', lead: 'A', harm: 'Bh' },
    { bars: 1, chords: 'up', drums: 'walk', bass: 'rise', gtr: 'ring', keys: 'hold', arp: 'rise', gain: 0.88 },
  ],
};

// ---- DRAY GOES OFF THE ROOF -----------------------------------------------
// About five seconds, and it is the only piece of music in the game that is
// meant to sound like something STOPPING. The Warlord Frame's tune is playing
// and it comes apart: the fifths slide down a semitone at a time, the kit drops
// out from underneath, and the last bar is one held guitar note with nothing
// under it at all. Then the ending track starts.
//
// A minor, stage 8's key, so it is the same room the fight was in.
const C_roof = {
  name: 'Off The Roof', bpm: 150, key: 57, lkey: 69, swing: 0, echo: 1.5, level: 0.90,
  tone: { freq: 3300, gain: -3 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    clank: { ring: 0.9, pitch: 380, vol: 0.5 },
    bass: { vol: 0.32, bright: 2200, close: 300, sub: 0.4 },
    gtr:  { vol: 0.20, drive: 'hot', tone: 3200 },
    keys: { vol: 0.09, tone: 2900 },
    lead: { vol: 0.32, drive: 'hot', tone: 3600, send: 0.40, echo: 0.26 },
    harm: { vol: 0.16, drive: 'crunch', tone: 3300, send: 0.34, echo: 0.20 },
    arp:  { vol: 0.05, wave: 'triangle', tone: 3400, echo: 0.30 },
  },
  chords: {
    // down a semitone at a time. The frame coming apart, in the harmony.
    fall: [[0, '5'], [-1, '5'], [-2, '5'], [-4, 'M']],
    gone: [[-4, 'M9'], [-4, 'M9'], [-4, 'M9'], [-4, 'M9']],
  },
  drums: {
    break: {
      k: ['X...X...X.......', 'X.......x.......'],
      s: ['....X.......X...', '....X...........'],
      h: ['x.x.x.x.x.x.....', 'x.x.............'],
      m: ['..............X.', '................'],
      c: ['X...............', '................'],
    },
    // nothing left but the air off the roof
    empty: { a: 'X...............' },
  },
  bass: {
    slide: [P('0 . 0 . -1 . -1 . -2 . -2 . -4 . . .'), P('-4 . . . . . . . . . . . . . . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    grind: [P('0 . 0 . -1 . -1 . -2 . . . -4 . . .')],
    last: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('12 . . . 10 . . . 7 . . . 5 . . .'),
        P('3 . . . . . . . . . . . . . . .')],
    // one note, held, with nothing underneath it
    last: [P('0 . . . . . . . . . . . . . . .')],
    Bh: [P('7 . . . 5 . . . 3 . . . 0 . . .'),
         P('-4 . . . . . . . . . . . . . . .')],
  },
  arps: { slow: { notes: [0, 2], chordal: true, rate: 4, voice: 'pluck' } },
  form: [
    { bars: 2, chords: 'fall', drums: 'break', bass: 'slide', gtr: 'grind', keys: 'hold', lead: 'A', harm: 'Bh' },
    { bars: 2, chords: 'gone', drums: 'empty', bass: 'soft', gtr: 'last', gtrStyle: 'sustain', keys: 'hold', lead: 'last', arp: 'slow', gain: 0.70 },
  ],
};

const CUE_TRACKS = { cue_unit9: C_unit9, cue_roof: C_roof };
