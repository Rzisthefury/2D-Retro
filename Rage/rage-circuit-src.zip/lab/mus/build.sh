#!/bin/sh
# Assemble the music picker. Everything is inline: the synth engine, the
# sequencer, the four songs and the stage stills as data URIs, so the page is
# self-contained and works with no network.
cd "$(dirname "$0")"
if [ ! -f 03_stills.js ]; then echo "run stills.js first"; exit 1; fi
{ cat head.html; cat body.html; echo '<script>';
  cat 00_eng.js 01_seq.js 02_s1.js 03_stills.js 90_viewer.js;
  echo '</script>'; } > picker-mus.html
wc -c picker-mus.html
