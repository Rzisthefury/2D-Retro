// ============================================================ STAGE 3 options
// THE TOWER. Ground Level is a building site at dusk - cranes overhead, an
// excavator, SYNDICATE DEVELOPMENTS on the hoarding, churned mud. The Glass
// Floor is forty storeys up in the unfinished curtain wall with the sunset
// coming through it. Both scenes drop girders on you, and the boss is a mech.
//
// So the through-line for stage 3 is machinery: something mechanical and
// interlocking in the percussion that the other stages have not had. The kit
// gains struck metal for it, and one option is built on a pile driver.
//
// Bb minor - a semitone above stage 1, which reads as a lift in tension, and
// it keeps the bass at 58Hz where it is still audible on small speakers.

// ---- T1: GROUNDWORKS ------------------------------------------------------
// Industrial guitar. A palm-muted riff locked to scaffold-pole percussion, so
// the band and the site are playing the same rhythm.
const S3_GROUND = {
  name: 'Groundworks', bpm: 144, key: 58, lkey: 70, swing: 0.05, level: 0.93,
  tone: { freq: 3200, gain: -2 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true }, clank: { ring: 0.28 },
    bass: { vol: 0.34, bright: 2600, close: 330 },
    gtr:  { vol: 0.22, drive: 'hot', tone: 2500 },
    keys: { vol: 0.06, tone: 2200 },
    lead: { vol: 0.34, drive: 'crunch', tone: 3500, send: 0.22, echo: 0.12 },
    harm: { vol: 0.19, drive: 'crunch', tone: 2900, send: 0.18, echo: 0.10 },
    arp:  { vol: 0.05 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [-4, 'M'], [-2, 'M']],
    lift: [[-4, 'M'], [-2, 'M'], [0, 'm'], [-5, 'M']],
    turn: [[0, 'm'], [5, 'm'], [-2, 'M'], [-4, 'M']],
  },
  drums: {
    intro: { k: 'X.......X.......', m: '....x.......x...', h: 'x.x.x.x.x.x.x.x.' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.xox.x.x.xox.x.'],
      m: ['..x.......x.....', '..x...o...x...o.'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X.-.'],
      h: 'xxxxxxxxxxxxxxxx',
      m: ['..x...X...x...o.', '..X.......x.o.x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', m: '........X.......' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', m: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 12 . 0 . 10 0 . 0 12 . 7 . 5'), P('0 . 0 . 12 . 0 . 0 . . 10 . 7 . 5')],
    drive: [P('0 0 . 0 12 . 0 0 . 12 . 0 10 . 7 .'), P('0 . 12 0 . 10 . 0 0 . 0 12 . 10 . 7')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 0 . 5 3'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 3 . 0')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . 3 . 5 . 3 . . 0 . 10 . . .'),
        P('7 . . 5 . 3 . . 5 . . . . . . .'),
        P('0 . . 3 . 5 . 7 . . 10 . 7 . 5 .'),
        P('3 . . . 5 . 3 . 0 . . . . . . .')],
    B: [P('12 . . 15 . 14 . 12 . . 10 . . . 12 .'),
        P('10 . . 7 . 10 . . 12 . . . . . . .'),
        P('15 . . 17 . 15 . 14 . . 12 . 10 . 12 .'),
        P('14 . . . 12 . 10 . 7 . . . . . . .')],
    C: [P('0 . . . 3 . . . 5 . . . 3 . . .'),
        P('0 . . . . . 10 . 7 . . . . . . .'),
        P('5 . . . 7 . . . 10 . . . 7 . . .'),
        P('5 . . . 3 . . . 0 . . . . . . .')],
    Bh: [P('15 . . 19 . 17 . 15 . . 14 . . . 15 .'),
         P('14 . . 12 . 14 . . 15 . . . . . . .'),
         P('19 . . 20 . 19 . 17 . . 15 . 14 . 15 .'),
         P('17 . . . 15 . 14 . 12 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'hold' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', lead: 'C', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'hold' },
  ],
};

// ---- T2: PILE DRIVER ------------------------------------------------------
// Built around an actual machine. Something enormous lands on beat one and
// everything else is syncopated around the gap it leaves. Half-time, a lot of
// air, and the most menacing thing in the game so far.
const S3_PILE = {
  name: 'Pile Driver', bpm: 92, key: 58, lkey: 70, swing: 0, level: 0.90,
  tone: { freq: 3000, gain: -2.5 },
  bassVoice: 'sub', gtrStyle: 'chug', keyStyle: 'pad', leadStyle: 'lead', harmStyle: 'stab',
  band: {
    kick: { deep: true }, snare: { fat: true }, clank: { ring: 0.55 },
    bass: { vol: 0.30, harm: 0.28 },
    gtr:  { vol: 0.21, drive: 'hot', tone: 2800 },
    keys: { vol: 0.09, open: false, att: 0.8 },
    lead: { vol: 0.38, drive: 'crunch', tone: 3500, wide: true, send: 0.34, echo: 0.22 },
    harm: { vol: 0.18, bright: 4200, send: 0.34, echo: 0.28 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3200, echo: 0.34 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [-1, 'M'], [-3, 'M']],
    lift: [[-3, 'M'], [-1, 'M'], [0, 'm'], [0, 'm']],
    turn: [[0, 'm'], [-4, 'M'], [-1, 'M'], [0, 'm']],
  },
  drums: {
    // the driver lands on one and nothing argues with it
    intro: { d: 'X...............', m: '........o.......' },
    main: {
      d: ['X...............', 'X...............'],
      k: ['........X.......', '........X...x...'],
      s: ['................', '............X...'],
      m: ['....x.......o...', '....x...o...x.o.'],
      h: ['..x...x...x...x.', '..x...x...x...xo'],
    },
    push: {
      d: ['X...............', '................'],
      k: ['........X.......', 'X...x...X.......'],
      s: ['............X...', '....X.......X...'],
      m: ['....x...o...x...', '..x.x...o.x...o.'],
      h: 'x.x.x.x.x.x.x.x.',
    },
    half: { d: 'X...............', m: '........o.......' },
    fill: { k: 'X.......x...x...', s: '....X...x...X.Xx', m: '..............X.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . . . 0 . . . 10 . . .'), P('0 . . . . . . . 0 . . . 0 . 10 .')],
    roll: [P('0 . . 0 . . . 10 0 . . 0 . 10 . 7'), P('0 . . 0 . 10 . . 0 . . 7 . 5 . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    grind: [P('. . . . 0 . . . . . . . 0 . . .'), P('. . . . 0 . . . 0 . . . . . 0 .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('. . . . 0 . . . 3 . . . . . . .'),
        P('. . . . 5 . . 3 . . 0 . . . . .'),
        P('. . . . 7 . . . 10 . . . . . . .'),
        P('. . . . 7 . . 5 . . 3 . . . . .')],
    B: [P('12 . . . . . 10 . 12 . . . . . . .'),
        P('15 . . . 14 . . . 12 . . . . . . .'),
        P('10 . . . . . 12 . 15 . . . . . . .'),
        P('14 . . . 12 . . . 10 . . . . . . .')],
    C: [P('0 . . . . . . . . . . . . . . .'),
        P('3 . . . . . . . 0 . . . . . . .'),
        P('5 . . . . . . . . . . . . . . .'),
        P('3 . . . . . . . 0 . . . . . . .')],
    Bh: [P('19 . . . . . 17 . 19 . . . . . . .'),
         P('22 . . . 20 . . . 19 . . . . . . .'),
         P('17 . . . . . 19 . 22 . . . . . . .'),
         P('20 . . . 19 . . . 17 . . . . . . .')],
  },
  arps: { slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'grind', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'grind', keys: 'hold', lead: 'A', arp: 'slow' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'roll', gtr: 'grind', keys: 'hold', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'roll', gtr: 'grind', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'roll', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'roll', gtr: 'grind', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'grind', keys: 'hold', lead: 'A', arp: 'slow' },
  ],
};

// ---- T3: SUNSET STEEL -----------------------------------------------------
// The glass-floor reading. Forty storeys up with the sunset coming through the
// curtain wall, and for about a minute nobody is trying to kill you. Wide pads,
// a long-lined melody, guitar playing harmonics rather than chords. The metal
// is still there - it is just a long way below.
const S3_SUNSET = {
  name: 'Sunset Steel', bpm: 116, key: 58, lkey: 70, swing: 0, echo: 1.5, level: 0.92,
  tone: { freq: 3200, gain: -3 },
  bassVoice: 'syn', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'lead', harmStyle: 'stab',
  band: {
    kick: { deep: true }, snare: { fat: true }, clank: { ring: 0.8 },
    bass: { vol: 0.40, bright: 1300, close: 200, sub: 1.0 },
    gtr:  { vol: 0.12, tone: 4000, send: 0.48, echo: 0.36 },
    keys: { vol: 0.12, open: true, att: 0.9 },
    lead: { vol: 0.22, drive: 'clean', tone: 3300, send: 0.42, echo: 0.30, vib: 10 },
    harm: { vol: 0.095, bright: 3600, send: 0.38, echo: 0.30 },
    arp:  { vol: 0.075, wave: 'sine', tone: 3200, echo: 0.42 },
  },
  chords: {
    main: [[0, 'm9'], [-4, 'M9'], [-2, 'M'], [3, 'M7']],
    lift: [[-4, 'M9'], [-2, 'M'], [0, 'm9'], [5, 'm7']],
    turn: [[3, 'M7'], [-2, 'M'], [5, 'm7'], [0, 'm9']],
  },
  drums: {
    intro: { m: '........o.......', h: '..x...x...x...x.' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...xo', '..x...x...x...x.'],
      m: ['................', '............o...'],
    },
    push: {
      k: ['X.......X.......', 'X...x...X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'],
    },
    half: { k: 'X...............', m: '........o.......', h: '............o...' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . 10 .'), P('0 . . . . . . . 0 . . . 7 . . .')],
    oct:  [P('0 . . 12 . . 0 . 0 . . 12 . . 10 .'), P('0 . . 12 . . 0 . 0 . . 7 . . 5 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('12 . . . . . . . . . . . . . . .'), P('7 . . . . . . . . . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // long lines, a lot of air, the way a sunset actually goes
    A: [P('7 . . . . . 10 . . . . . 12 . . .'),
        P('10 . . . . . 7 . . . . . . . . .'),
        P('12 . . . . . 14 . . . . . 15 . . .'),
        P('14 . . . . . 12 . . . . . . . . .')],
    B: [P('19 . . . . . 17 . . . 15 . . . 17 .'),
        P('15 . . . . . 14 . . . . . 12 . . .'),
        P('17 . . . . . 19 . . . 22 . . . 19 .'),
        P('17 . . . 15 . . . 14 . . . . . . .')],
    C: [P('0 . . . . . . . . . . . 3 . . .'),
        P('5 . . . . . . . . . . . . . . .'),
        P('7 . . . . . . . . . . . 10 . . .'),
        P('7 . . . . . . . 5 . . . . . . .')],
    Bh: [P('12 . . . . . 10 . . . 7 . . . 10 .'),
         P('7 . . . . . 5 . . . . . 3 . . .'),
         P('10 . . . . . 12 . . . 15 . . . 12 .'),
         P('10 . . . 7 . . . 5 . . . . . . .')],
  },
  arps: {
    slow: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    still: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'still', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'oct', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'oct', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', keys: 'hold', arp: 'slow', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'oct', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'still', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'A' },
  ],
};

// ---- T4: NIGHT SHIFT ------------------------------------------------------
// The site is still working. This one is about the people rather than the
// plant: an organ groove, a bass that walks, a busy kit, and metal only where
// a real crew would actually be hitting something. Human, not mechanical.
const S3_SHIFT = {
  name: 'Night Shift', bpm: 138, key: 58, lkey: 70, swing: 0.16, level: 0.88,
  tone: { freq: 3400, gain: -1.5 },
  bassVoice: 'pick', gtrStyle: 'clean', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'ep',
  band: {
    kick: {}, snare: { fat: false }, clank: { ring: 0.22 },
    bass: { vol: 0.42, bright: 1800, close: 240 },
    gtr:  { vol: 0.12, tone: 3800, send: 0.34, echo: 0.20 },
    keys: { vol: 0.080, tone: 2500, bars: [[1, 1.0], [2, 0.5], [3, 0.3], [4, 0.18]] },
    lead: { vol: 0.29, drive: 'crunch', tone: 3400, send: 0.26, echo: 0.16 },
    harm: { vol: 0.11, bite: 1.8 },
    arp:  { vol: 0.06, wave: 'triangle' },
  },
  chords: {
    main: [[0, 'm7'], [5, 'm7'], [-2, '7'], [0, 'm7']],
    lift: [[-4, 'M7'], [-2, '7'], [0, 'm7'], [5, 'm7']],
    turn: [[3, 'M7'], [-4, 'M7'], [5, 'm7'], [-2, '7']],
  },
  drums: {
    intro: { k: 'X.....x.........', s: '............-...', h: '..x...x...x...x.' },
    main: {
      k: ['X.....x.....x...', 'X.......x.x.....'],
      s: ['....X...-...X.-.', '....X.-.....X...'],
      h: ['x.xox.x.x.xox.x.', 'x.x.x.xox.x.x.xo'],
      m: ['................', '..........x.....'],
    },
    ride: {
      k: ['X.....x...x.....', 'X.......x.....x.'],
      s: ['....X.......X.-.', '....X.-.....X...'],
      r: ['x.x.X.x.x.x.X.x.', 'x.x.x.x.X.x.x.x.'],
      m: ['..........o.....', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '......o.......o.' },
    fill: { k: 'X.......x.......', s: '....X.-.x.X.x.Xx', t: '..........o.-...', m: 'X...............' },
  },
  bass: {
    main: [P('0 . . 12 . . 10 . 7 . . 0 . 3 . 5'), P('0 . 10 . 12 . . 7 . . 5 . 3 . 2 .')],
    walk: [P('0 . 2 . 3 . 5 . 7 . 5 . 3 . 2 .'), P('0 . 12 . 10 . 7 . 5 . 3 . 2 . 0 .')],
    soft: [P('0 . . . . . . 12 . . . . . . . .')],
  },
  gtr: {
    comp: [P('. . 0 . . . 0 . . . . 0 . . 0 .'), P('. . 0 . . 0 . . . . 0 . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    comp: [P('0 . . . . 0 . . . 0 . . . . 0 .'), P('0 . . 0 . . . 0 . . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('0 . 3 . 5 . . 7 . 5 . 3 . . 2 .'),
        P('3 . . 5 . 7 . . 10 . . . . . . .'),
        P('12 . 10 . 7 . . 10 . 7 . 5 . . 3 .'),
        P('5 . . . 3 . 2 . 0 . . . . . . .')],
    B: [P('14 . . 12 . 10 . . 12 . . . . . . .'),
        P('10 . . 12 . 14 . . 15 . 14 . 12 . . .'),
        P('17 . . 15 . 14 . . 12 . . 10 . . 12 .'),
        P('14 . . . . . 12 . . . . . . . . .')],
    C: [P('7 . . . 10 . . . 12 . . . 10 . . .'),
        P('7 . . . 5 . . . 3 . . . . . . .'),
        P('10 . . . 12 . . . 14 . . . 12 . . .'),
        P('10 . . . . . 7 . . . . . . . . .')],
    Ah: [P('. . 0 . 0 . . 3 . 0 . 0 . . 10 .'),
         P('0 . . 0 . 3 . . 5 . . . . . . .'),
         P('7 . 5 . 3 . . 5 . 3 . 0 . . 10 .'),
         P('0 . . . 10 . 10 . 7 . . . . . . .')],
  },
  arps: { soft: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'soft', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'comp', keys: 'comp' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'comp', keys: 'comp', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'ride', bass: 'walk', gtr: 'comp', keys: 'comp', lead: 'A', harm: 'Ah' },
    { bars: 4, chords: 'main', drums: 'ride', bass: 'walk', keys: 'comp', lead: 'B', arp: 'soft' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'walk', keys: 'comp' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'soft', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'ride', bass: 'walk', gtr: 'comp', keys: 'comp', lead: 'B', harm: 'Ah' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'comp', keys: 'comp', lead: 'A' },
  ],
};

const S3_OPTIONS = { T1: S3_GROUND, T2: S3_PILE, T3: S3_SUNSET, T4: S3_SHIFT };
