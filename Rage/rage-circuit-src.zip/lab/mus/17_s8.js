// ============================================================ STAGE 8 options
// TOWER TOP. The last stage, three rooms, and the only one where the game is
// already quoting itself before the music gets there:
//   THE BLACKOUT LOBBY - power out, emergency exits glowing green, and the
//                        whole lit city still visible through the glass behind
//                        it. Dark, quiet, and enormous.
//   THE MODEL ROOM     - a private museum. Vitrines under little gold picture
//                        lights, each holding a scale model of a piece of the
//                        city he owns. Big Brick is waiting in here, and then
//                        the Voss twins, and the game plays their old themes
//                        while they fight you.
//   THE HELIPAD        - night, heavy rain, a windsock, and the roof he does
//                        not get off.
//
// A MINOR - stage 1's key, for the only time since stage 1. Seven stages have
// each had their own and the eighth goes back to the first, because the game
// ends where it started: same key, top of the tower instead of under the El.
//
// The Model Room and the Helipad ALREADY reuse boss, boss2 and boss3 for the
// rematches, so stage 8 is structurally about the past turning up again. These
// four take that seriously rather than working against it.
//
// Targets before writing: mid 12-20%, sub 24-36%, himid under 3.2%, and the
// top/bass ratio inside what the twenty-three settled tracks do.

// ---- K1: THE LAST FLOOR ---------------------------------------------------
// The one that is made of the rest of the game. Its hook RISES IN LEAPS the
// way stage 1's did and then FALLS IN STEPS the way stage 7's does - the two
// halves of the soundtrack in one tune, which is a thing you can only do on
// the last stage and only once. Full band, nothing held back: overdriven lead,
// organ underneath, picked bass, and the kit playing properly.
const S8_LAST = {
  name: 'The Last Floor', bpm: 148, key: 57, lkey: 69, swing: 0.04, echo: 1.2, level: 0.92,
  tone: { freq: 3400, gain: -2.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.34, bright: 2300, close: 330 },
    gtr:  { vol: 0.20, drive: 'hot', tone: 2800 },
    keys: { vol: 0.085, tone: 2800 },
    lead: { vol: 0.32, drive: 'crunch', tone: 3300, send: 0.26, echo: 0.16 },
    harm: { vol: 0.18, drive: 'crunch', tone: 3100, send: 0.22, echo: 0.12 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3400, echo: 0.22 },
  },
  chords: {
    main: [[0, 'm'], [-4, 'M'], [-2, 'M'], [0, 'm']],
    lift: [[-4, 'M'], [3, 'M'], [-2, 'M'], [0, 'm']],
    turn: [[5, 'm'], [3, 'M'], [-4, 'M'], [-2, 'M']],
  },
  drums: {
    intro: { k: 'X.......X.......', h: 'x.x.x.x.x.x.x.x.', c: 'X...............' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.xox.x.x.xox.x.'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X.-.'],
      h: 'xxxxxxxxxxxxxxxx',
      r: ['x.x.x.x.x.x.x.x.', 'X.x.x.x.x.x.x.x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '........o.......' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 . . . 0 . 0 . . . 7 . 5 .'), P('0 . 0 . . . 0 . 0 . . . 10 . 7 .')],
    drive: [P('0 . 0 7 . 0 . 5 0 . 0 7 . 5 . 3'), P('0 . 7 0 . 5 . 0 0 . 0 10 . 7 . 5')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 0 . 5 3'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 3 . 0')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // up in fourths and fifths, down by step. Both halves of the game.
    A: [P('0 . . . 5 . . . 10 . . . 12 . . .'),
        P('10 . 8 . 7 . 5 . 3 . . . 0 . . .'),
        P('0 . . . 7 . . . 12 . . . 15 . . .'),
        P('14 . 12 . 10 . 7 . 5 . . . 0 . . .')],
    B: [P('19 . . . 22 . . . 24 . . . 22 . 19 .'),
        P('20 . 19 . 17 . 15 . 12 . . . . . . .'),
        P('19 . . . 24 . . . 27 . . . 24 . 22 .'),
        P('22 . 20 . 19 . 15 . 12 . . . . . . .')],
    C: [P('0 . . . . . . . 5 . . . . . . .'),
        P('10 . . . . . . . 7 . . . . . . .'),
        P('0 . . . . . . . 7 . . . . . . .'),
        P('12 . . . . . . . 10 . . . . . . .')],
    Bh: [P('12 . . . 17 . . . 19 . . . 17 . 15 .'),
         P('15 . 14 . 12 . 10 . 7 . . . . . . .'),
         P('12 . . . 19 . . . 22 . . . 19 . 17 .'),
         P('17 . 15 . 14 . 10 . 7 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', keys: 'hold', gain: 0.84 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- K2: UNDER GLASS ------------------------------------------------------
// Written for the Model Room, which is a private museum of the city he bought.
// So this is the villain's own taste in music: hushed, wide, unhurried, and
// expensive. The tune is sparse and sits high, built on the sixth and the
// ninth - the intervals that sound like money - and the whole track is
// RESTRAINED, which after seven stages of shouting is the most unsettling
// thing available. The slowest track in the game at 104.
const S8_GLASS = {
  name: 'Under Glass', bpm: 104, key: 57, lkey: 69, swing: 0, echo: 1.6, level: 0.92,
  tone: { freq: 3200, gain: -3.5 },
  bassVoice: 'sub', gtrStyle: 'clean', keyStyle: 'ep', leadStyle: 'lead', harmStyle: 'stab',
  band: {
    kick: { deep: true }, snare: { fat: true },
    clank: { ring: 0.8, pitch: 700, vol: 0.35 },
    bass: { vol: 0.30, harm: 0.20 },
    gtr:  { vol: 0.14, tone: 4000, send: 0.48, echo: 0.34 },
    keys: { vol: 0.125, tone: 3000 },
    lead: { vol: 0.28, drive: 'clean', tone: 3000, send: 0.44, echo: 0.28, vib: 7 },
    harm: { vol: 0.10, bright: 3400, send: 0.40, echo: 0.30 },
    arp:  { vol: 0.075, wave: 'sine', tone: 3000, echo: 0.40 },
  },
  chords: {
    // major sevenths and ninths throughout: nothing here is ever in a hurry
    main: [[0, 'm9'], [-4, 'M9'], [3, 'M7'], [-2, 'M']],
    lift: [[3, 'M7'], [-2, 'M'], [5, 'm7'], [0, 'm9']],
    turn: [[5, 'm7'], [-4, 'M9'], [-2, 'M'], [0, 'm9']],
  },
  drums: {
    intro: { m: '........o.......', h: '..x.......x.....' },
    main: {
      k: ['X.......X.......', 'X.......X.......'],
      s: ['............X...', '............X...'],
      h: ['..x.......x.....', '..x.......x...x.'],
      m: ['........o.......', '................'],
    },
    push: {
      k: ['X.......X.......', 'X.....x.X.......'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...x.', '..x...x...x...xo'],
      m: ['........o.......', '....o...........'],
    },
    half: { k: 'X...............', m: '........o.......' },
    fill: { k: 'X.......x.......', s: '....X.......X.Xx', m: '..........o.....', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . . .'), P('0 . . . . . . . -4 . . . . . . .')],
    walk: [P('0 . . . . . . . 7 . . . . . 5 .'), P('0 . . . . . -4 . . . -2 . . . . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('0 . . . . . . . . . . . . . . .'), P('7 . . . . . . . . . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // the sixth and the ninth, and a great deal of nothing around them
    A: [P('12 . . . . . 14 . . . . . 9 . . .'),
        P('. . . . 12 . . . . . . . . . . .'),
        P('14 . . . . . 17 . . . . . 21 . . .'),
        P('19 . . . . . 14 . . . . . 12 . . .')],
    B: [P('21 . . . . . 24 . . . 26 . . . 24 .'),
        P('21 . . . . . 19 . . . . . 17 . . .'),
        P('24 . . . . . 26 . . . 29 . . . 26 .'),
        P('24 . . . . . 21 . . . . . 19 . . .')],
    C: [P('12 . . . . . . . . . . . 14 . . .'),
        P('9 . . . . . . . . . . . . . . .'),
        P('14 . . . . . . . . . . . 17 . . .'),
        P('12 . . . . . . . . . . . . . . .')],
    Bh: [P('17 . . . . . 19 . . . 21 . . . 19 .'),
         P('17 . . . . . 14 . . . . . 12 . . .'),
         P('19 . . . . . 21 . . . 24 . . . 21 .'),
         P('19 . . . . . 17 . . . . . 14 . . .')],
  },
  arps: { still: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'still', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'still' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'walk', gtr: 'ring', keys: 'hold', arp: 'still', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'walk', gtr: 'ring', keys: 'hold', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', keys: 'hold', arp: 'still', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'walk', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'still', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', gtr: 'ring', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'still', lead: 'A' },
  ],
};

// ---- K3: STORM PAD --------------------------------------------------------
// The roof, in the rain. Fastest thing in the game at 160, and the rain is
// literally in the arrangement: a sixteenth-note figure that never stops for
// the entire track, with everything else played over the top of it. The tune
// CIRCLES inside a fifth and never leaves - nothing else in the soundtrack
// stays in one place like that - because you are not going anywhere either.
// This is the last roof and there is nothing above it.
const S8_STORM = {
  name: 'Storm Pad', bpm: 160, key: 57, lkey: 69, swing: 0, echo: 1.3, level: 0.92,
  tone: { freq: 3400, gain: -2.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: false },
    hiss: { vol: 0.10, f0: 5000, f1: 2200 },
    bass: { vol: 0.34, bright: 2400, close: 300 },
    gtr:  { vol: 0.19, drive: 'hot', tone: 2900 },
    keys: { vol: 0.10, open: true, att: 0.6 },
    lead: { vol: 0.31, bright: 4800, send: 0.34, echo: 0.24, wave: 'sawtooth' },
    harm: { vol: 0.16, drive: 'crunch', tone: 3100, send: 0.26, echo: 0.14 },
    // the rain. It runs the whole track and never lets up.
    arp:  { vol: 0.09, wave: 'triangle', tone: 4200, echo: 0.34 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [-2, 'M'], [-4, 'M']],
    lift: [[-2, 'M'], [-4, 'M'], [5, 'm'], [0, 'm']],
    turn: [[5, 'm'], [3, 'M'], [-2, 'M'], [0, 'm']],
  },
  drums: {
    intro: { h: 'x.x.x.x.x.x.x.x.', a: 'X...............' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.x.x.x.x.x.x.x.',
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X...'],
      h: 'xxxxxxxxxxxxxxxx',
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', a: '........X.......' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 . . . 0 . 0 . 0 . . . 0 .'), P('0 . 0 . . . 0 . 0 . 0 . . . -2 .')],
    drive: [P('0 . 0 . 7 . 0 . 5 . 0 . 7 . 5 .'), P('0 . 7 . 0 . 5 . 0 . -2 . 0 . -4 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 0 . 0 0 . 0 . 0 .'), P('0 . 0 0 . 0 . 5 . 0 0 . 0 . 3 .')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // circles inside a fifth. Never leaves, because neither do you.
    A: [P('7 . 5 . 7 . 8 . 7 . 5 . 3 . 5 .'),
        P('7 . 8 . 7 . 5 . 3 . 5 . 7 . . .'),
        P('10 . 8 . 10 . 12 . 10 . 8 . 7 . 8 .'),
        P('10 . 8 . 7 . 5 . 7 . . . 5 . . .')],
    B: [P('19 . 17 . 19 . 20 . 19 . 17 . 15 . 17 .'),
        P('19 . 20 . 19 . 17 . 15 . . . . . . .'),
        P('22 . 20 . 22 . 24 . 22 . 20 . 19 . 20 .'),
        P('22 . 20 . 19 . 17 . 19 . . . . . . .')],
    C: [P('7 . . . 5 . . . 7 . . . 8 . . .'),
        P('7 . . . 5 . . . 3 . . . . . . .'),
        P('10 . . . 8 . . . 10 . . . 12 . . .'),
        P('10 . . . 8 . . . 7 . . . . . . .')],
    Bh: [P('12 . 10 . 12 . 15 . 12 . 10 . 8 . 10 .'),
         P('12 . 15 . 12 . 10 . 8 . . . . . . .'),
         P('15 . 12 . 15 . 17 . 15 . 12 . 10 . 12 .'),
         P('15 . 12 . 10 . 8 . 10 . . . . . . .')],
  },
  arps: {
    rain: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'rain', gain: 0.82 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'rain' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'rain', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'rain', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', arp: 'rain', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'rain', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'rain', lead: 'A' },
  ],
};

// ---- K4: GOES OFF THE ROOF ------------------------------------------------
// The ending of this game is one line: DRAY GOES OFF THE ROOF WITHOUT HIS
// HELICOPTER. This is that line as a piece of music. It is the only hook in
// the soundtrack that lands on the MAJOR THIRD - eight stages of minor keys and
// the last tune in the game resolves upward into the major - and the only one
// that sounds like winning rather than like fighting. Twin guitars in harmony
// the whole way, organ underneath, and a kit that is celebrating.
//
// Unit-9's theme on stage 7 was hopeful. This one is not hopeful. It is done.
const S8_ROOF = {
  name: 'Goes Off The Roof', bpm: 142, key: 57, lkey: 69, swing: 0.03, echo: 1.2, level: 0.92,
  tone: { freq: 3400, gain: -2.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.34, bright: 2400, close: 340 },
    gtr:  { vol: 0.19, drive: 'crunch', tone: 3000 },
    keys: { vol: 0.10, tone: 3000 },
    lead: { vol: 0.31, drive: 'crunch', tone: 3400, send: 0.30, echo: 0.18 },
    // the second guitar is not answering the first, it is beside it the whole
    // way. Nobody finishes this one on their own.
    harm: { vol: 0.19, drive: 'crunch', tone: 3200, send: 0.26, echo: 0.14 },
    arp:  { vol: 0.075, wave: 'triangle', tone: 3600, echo: 0.24 },
  },
  chords: {
    // it keeps arriving on the major. That is the whole argument.
    main: [[0, 'm'], [-4, 'M'], [3, 'M'], [-2, 'M']],
    lift: [[3, 'M'], [-2, 'M'], [-4, 'M'], [0, 'm']],
    turn: [[5, 'm'], [3, 'M7'], [-4, 'M9'], [-2, 'M']],
  },
  drums: {
    intro: { k: 'X.......X.......', h: 'x.x.x.x.x.x.x.x.', c: 'X...............' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.xox.x.x.xox.x.'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X.-.'],
      h: 'x.xox.x.x.xox.x.',
      r: ['X.x.x.x.X.x.x.x.', 'X.x.x.x.X.x.x.x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '........o.......' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . 0 . 0 . . . 8 . 7 .'), P('0 . . . . . 0 . 0 . . . 7 . 5 .')],
    drive: [P('0 . 0 7 . 0 . 8 0 . 0 12 . 8 . 7'), P('0 . 7 0 . 8 . 0 0 . 0 7 . 5 . 3')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 4 . 0 0 . 0 . 7 4'), P('0 . 0 0 . 0 . 0 . 4 . 7 . 4 . 0')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // 16 is the major third, an octave up. No other tune in the game goes there.
    A: [P('0 . . . 7 . . . 12 . . . 16 . . .'),
        P('14 . . . 12 . . . 7 . . . . . . .'),
        P('7 . . . 12 . . . 16 . . . 19 . . .'),
        P('16 . . . 14 . . . 12 . . . . . . .')],
    B: [P('19 . . . 24 . . . 28 . . . 26 . 24 .'),
        P('26 . . . 24 . . . 19 . . . . . . .'),
        P('24 . . . 28 . . . 31 . . . 28 . 26 .'),
        P('28 . . . 26 . . . 24 . . . . . . .')],
    C: [P('0 . . . . . . . 7 . . . . . . .'),
        P('12 . . . . . . . . . . . . . . .'),
        P('7 . . . . . . . 12 . . . . . . .'),
        P('16 . . . . . . . . . . . . . . .')],
    // a third above, the whole way through
    Bh: [P('4 . . . 12 . . . 16 . . . 19 . . .'),
         P('19 . . . 16 . . . 12 . . . . . . .'),
         P('12 . . . 16 . . . 19 . . . 24 . . .'),
         P('19 . . . 19 . . . 16 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', keys: 'hold', gain: 0.84 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
  ],
};

const S8_OPTIONS = { K1: S8_LAST, K2: S8_GLASS, K3: S8_STORM, K4: S8_ROOF };
