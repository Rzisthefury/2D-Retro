// ============================================================ STAGE 8, final
// K1 THE LAST FLOOR won, so the game ends with the band it started with: picked
// bass, overdriven guitar carrying the tune, organ underneath, a real kit, and
// A minor - stage 1's key, for the only time since stage 1.
//
// THE HOOK, unchanged in all five (degrees above A5):
//     0 5 10 12 | 10 8 7 5 3 0 | 0 7 12 15 | 14 12 10 7 5 0
// It rises in leaps the way stage 1's did and falls in steps the way stage 7's
// does. Both halves of the soundtrack in one tune.
//
// FIVE TRACKS, because the last stage needs them:
//   8A THE BLACKOUT LOBBY - the power is out. The band plays with the lights
//                           off, and the city is still lit behind the glass.
//   8B THE MODEL ROOM     - quiet, and the old faces are waiting in it.
//   8C THE HELIPAD        - rain, and the walk to the last fight.
//   BOSS 8   MARQUESS DRAY     - he bought the city. Controlled, fast, precise.
//   BOSS 8X  DRAY // WARLORD FRAME - something worse stands up in the suit.
//
// The tempo climbs across the whole stage and never comes back down:
// 132 -> 140 -> 152 -> 158 -> 164. Nothing else in the game does that, and it
// is the only structural trick available to say "this is the end" without
// changing the band.

// ---- 8A: THE BLACKOUT LOBBY -----------------------------------------------
// Power out, emergency exits glowing green, and the whole lit city still there
// through the glass - visible and completely out of reach. So this is the
// quietest the band gets: organ forward, guitar right back, the kit playing
// around the beat rather than on it, and a great deal of room.
const T_stage8a = {
  name: 'The Blackout Lobby', bpm: 132, key: 57, lkey: 69, swing: 0.04, echo: 1.4, level: 0.92,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3300, gain: -3.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    bass: { vol: 0.34, bright: 2000, close: 300 },
    gtr:  { vol: 0.14, drive: 'crunch', tone: 2700, send: 0.30, echo: 0.20 },
    keys: { vol: 0.115, tone: 2700 },
    lead: { vol: 0.29, drive: 'clean', tone: 3100, send: 0.40, echo: 0.26, vib: 8 },
    harm: { vol: 0.13, drive: 'crunch', tone: 2900, send: 0.32, echo: 0.18 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3200, echo: 0.30 },
  },
  chords: {
    main: [[0, 'm'], [-4, 'M'], [-2, 'M'], [0, 'm']],
    lift: [[-4, 'M'], [3, 'M'], [-2, 'M'], [0, 'm']],
    turn: [[5, 'm'], [3, 'M'], [-4, 'M'], [-2, 'M']],
  },
  drums: {
    intro: { h: '..x...x...x...x.', k: 'X...............' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...xo', '..x...x...x...x.'],
    },
    push: {
      k: ['X.......X.....x.', 'X.....x.X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.x.x.x.x.x.x.x.', c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '........o.......' },
    fill: { k: 'X.......x.......', s: '....X.......X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . 0 . 0 . . . 7 . 5 .'), P('0 . . . . . 0 . 0 . . . 10 . 7 .')],
    drive: [P('0 . 0 7 . 0 . 5 0 . 0 7 . 5 . 3'), P('0 . 7 0 . 5 . 0 0 . 0 10 . 7 . 5')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    ring: [P('0 . . . . . . . 7 . . . . . . .'), P('0 . . . . . . . 5 . . . . . . .')],
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 0 . 5 3'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 3 . 0')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . . 5 . . . 10 . . . 12 . . .'),
        P('10 . 8 . 7 . 5 . 3 . . . 0 . . .'),
        P('0 . . . 7 . . . 12 . . . 15 . . .'),
        P('14 . 12 . 10 . 7 . 5 . . . 0 . . .')],
    B: [P('19 . . . 22 . . . 24 . . . 22 . 19 .'),
        P('20 . 19 . 17 . 15 . 12 . . . . . . .'),
        P('19 . . . 24 . . . 27 . . . 24 . 22 .'),
        P('22 . 20 . 19 . 15 . 12 . . . . . . .')],
    C: [P('0 . . . . . . . 5 . . . . . . .'),
        P('10 . . . . . . . 7 . . . . . . .'),
        P('0 . . . . . . . 7 . . . . . . .'),
        P('12 . . . . . . . 10 . . . . . . .')],
    Bh: [P('12 . . . 17 . . . 19 . . . 17 . 15 .'),
         P('15 . 14 . 12 . 10 . 7 . . . . . . .'),
         P('12 . . . 19 . . . 22 . . . 19 . 17 .'),
         P('17 . 15 . 14 . 10 . 7 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'hold', gtrStyle: 'clean', keys: 'hold', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'riff' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'hold', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- 8B: THE MODEL ROOM ---------------------------------------------------
// His private museum of the city he owns, and the old faces are waiting in it.
// Still the same band, playing quietly in a room where you are not supposed to
// raise your voice - clean guitar, organ holding, ride instead of hats. It is
// deliberately the most COMPOSED thing on the stage, because ninety seconds
// after it starts Big Brick's theme kicks the door in and the contrast is the
// whole effect.
const T_stage8b = {
  name: 'The Model Room', bpm: 140, key: 57, lkey: 69, swing: 0.04, echo: 1.3, level: 0.92,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3400, gain: -3 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    clank: { ring: 0.7, pitch: 720, vol: 0.3 },
    bass: { vol: 0.34, bright: 2200, close: 320 },
    gtr:  { vol: 0.16, drive: 'crunch', tone: 3000, send: 0.26, echo: 0.16 },
    keys: { vol: 0.105, tone: 2900 },
    lead: { vol: 0.30, drive: 'crunch', tone: 3200, send: 0.32, echo: 0.20 },
    harm: { vol: 0.15, drive: 'crunch', tone: 3000, send: 0.26, echo: 0.14 },
    arp:  { vol: 0.075, wave: 'triangle', tone: 3400, echo: 0.26 },
  },
  chords: {
    main: [[0, 'm'], [-4, 'M'], [-2, 'M'], [0, 'm']],
    lift: [[-4, 'M'], [3, 'M'], [-2, 'M'], [0, 'm']],
    turn: [[5, 'm'], [3, 'M'], [-4, 'M'], [-2, 'M']],
  },
  drums: {
    intro: { r: 'x.x.x.x.x.x.x.x.', m: '........o.......' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      r: ['x.x.x.x.x.x.x.x.', 'X.x.x.x.x.x.x.x.'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X...'],
      h: 'x.x.x.x.x.x.x.x.',
      r: ['X.x.x.x.X.x.x.x.', 'X.x.x.x.X.x.x.x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', m: '........o.......' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . 0 . 0 . . . 7 . 5 .'), P('0 . . . . . 0 . 0 . . . 10 . 7 .')],
    drive: [P('0 . 0 7 . 0 . 5 0 . 0 7 . 5 . 3'), P('0 . 7 0 . 5 . 0 0 . 0 10 . 7 . 5')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    ring: [P('0 . . . . . . . 7 . . . . . . .'), P('0 . . . . . . . 5 . . . . . . .')],
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 0 . 5 3'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 3 . 0')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . . 5 . . . 10 . . . 12 . . .'),
        P('10 . 8 . 7 . 5 . 3 . . . 0 . . .'),
        P('0 . . . 7 . . . 12 . . . 15 . . .'),
        P('14 . 12 . 10 . 7 . 5 . . . 0 . . .')],
    B: [P('19 . . . 22 . . . 24 . . . 22 . 19 .'),
        P('20 . 19 . 17 . 15 . 12 . . . . . . .'),
        P('19 . . . 24 . . . 27 . . . 24 . 22 .'),
        P('22 . 20 . 19 . 15 . 12 . . . . . . .')],
    C: [P('0 . . . . . . . 5 . . . . . . .'),
        P('10 . . . . . . . 7 . . . . . . .'),
        P('0 . . . . . . . 7 . . . . . . .'),
        P('12 . . . . . . . 10 . . . . . . .')],
    Bh: [P('12 . . . 17 . . . 19 . . . 17 . 15 .'),
         P('15 . 14 . 12 . 10 . 7 . . . . . . .'),
         P('12 . . . 19 . . . 22 . . . 19 . 17 .'),
         P('17 . 15 . 14 . 10 . 7 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'hold', gtrStyle: 'clean', keys: 'hold', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'riff' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'hold', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- 8C: THE HELIPAD ------------------------------------------------------
// Out of the building and into the rain. The band finally plays the tune the
// way it has been waiting to be played all stage - full, fast, and wet. There
// is a rain figure running under it that none of the indoor tracks have, and
// the reverb is the only genuinely outdoor-sounding thing on the stage.
const T_stage8c = {
  name: 'The Helipad', bpm: 152, key: 57, lkey: 69, swing: 0.03, echo: 1.3, level: 0.92,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3400, gain: -2.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    hiss: { vol: 0.09, f0: 5200, f1: 2400 },
    bass: { vol: 0.34, bright: 2400, close: 340 },
    gtr:  { vol: 0.20, drive: 'hot', tone: 2900 },
    keys: { vol: 0.09, tone: 2900 },
    lead: { vol: 0.32, drive: 'crunch', tone: 3300, send: 0.34, echo: 0.22 },
    harm: { vol: 0.18, drive: 'crunch', tone: 3100, send: 0.28, echo: 0.16 },
    // the rain, and the only track on the stage that has it
    arp:  { vol: 0.085, wave: 'triangle', tone: 4000, echo: 0.32 },
  },
  chords: {
    main: [[0, 'm'], [-4, 'M'], [-2, 'M'], [0, 'm']],
    lift: [[-4, 'M'], [3, 'M'], [-2, 'M'], [0, 'm']],
    turn: [[5, 'm'], [3, 'M'], [-4, 'M'], [-2, 'M']],
  },
  drums: {
    intro: { h: 'x.x.x.x.x.x.x.x.', a: 'X...............', c: 'X...............' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.xox.x.x.xox.x.'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X.-.'],
      h: 'xxxxxxxxxxxxxxxx',
      r: ['x.x.x.x.x.x.x.x.', 'X.x.x.x.x.x.x.x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', a: '........X.......' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 . . . 0 . 0 . . . 7 . 5 .'), P('0 . 0 . . . 0 . 0 . . . 10 . 7 .')],
    drive: [P('0 . 0 7 . 0 . 5 0 . 0 7 . 5 . 3'), P('0 . 7 0 . 5 . 0 0 . 0 10 . 7 . 5')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 0 . 5 3'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 3 . 0')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . . 5 . . . 10 . . . 12 . . .'),
        P('10 . 8 . 7 . 5 . 3 . . . 0 . . .'),
        P('0 . . . 7 . . . 12 . . . 15 . . .'),
        P('14 . 12 . 10 . 7 . 5 . . . 0 . . .')],
    B: [P('19 . . . 22 . . . 24 . . . 22 . 19 .'),
        P('20 . 19 . 17 . 15 . 12 . . . . . . .'),
        P('19 . . . 24 . . . 27 . . . 24 . 22 .'),
        P('22 . 20 . 19 . 15 . 12 . . . . . . .')],
    C: [P('0 . . . . . . . 5 . . . . . . .'),
        P('10 . . . . . . . 7 . . . . . . .'),
        P('0 . . . . . . . 7 . . . . . . .'),
        P('12 . . . . . . . 10 . . . . . . .')],
    Bh: [P('12 . . . 17 . . . 19 . . . 17 . 15 .'),
         P('15 . 14 . 12 . 10 . 7 . . . . . . .'),
         P('12 . . . 19 . . . 22 . . . 19 . 17 .'),
         P('17 . 15 . 14 . 10 . 7 . . . . . . .')],
  },
  arps: {
    rain: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', keys: 'hold', arp: 'rain', gain: 0.82 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'rain' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'rain', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'rain', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', arp: 'rain', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'rain', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'rain', lead: 'A' },
  ],
};

// ---- BOSS 8: MARQUESS DRAY ------------------------------------------------
// He bought the city and keeps it under glass on his own floor, and he fights
// with a cane. So he does not get a heavy theme - he gets a CONTROLLED one.
// Fast, precise, swung, and never louder than it needs to be: the bass walks
// instead of pounding, the guitar answers the lead rather than grinding under
// it, and the drums play the ride. He is not exerting himself and the music
// knows it.
const T_boss8 = {
  name: 'Marquess Dray', bpm: 158, key: 57, lkey: 69, swing: 0.06, echo: 1.1, level: 0.90,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3400, gain: -2.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: false },
    clank: { ring: 0.5, pitch: 780, vol: 0.35 },
    bass: { vol: 0.34, bright: 2500, close: 360 },
    gtr:  { vol: 0.17, drive: 'crunch', tone: 3100, send: 0.20, echo: 0.12 },
    keys: { vol: 0.095, tone: 3000 },
    lead: { vol: 0.32, drive: 'crunch', tone: 3400, send: 0.28, echo: 0.20 },
    harm: { vol: 0.17, drive: 'crunch', tone: 3200, send: 0.24, echo: 0.14 },
    arp:  { vol: 0.08, wave: 'triangle', tone: 3800, echo: 0.26 },
  },
  chords: {
    main: [[0, 'm'], [-4, 'M'], [-2, 'M'], [0, 'm']],
    // his chords: sixths and sevenths. Even the harmony is well dressed.
    poise: [[0, 'm6'], [-4, 'M7'], [-2, 'M'], [5, 'm7']],
    turn: [[5, 'm7'], [3, 'M7'], [-4, 'M9'], [-2, 'M']],
  },
  drums: {
    intro: { r: 'X.x.x.x.X.x.x.x.', m: '........o.......' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X.......'],
      s: ['....X.......X...', '....X.......X..-'],
      r: ['X.x.x.x.X.x.x.x.', 'X.x.x.xoX.x.x.x.'],
    },
    press: {
      k: ['X...x...X.....x.', 'X.....x.X.x.x...'],
      s: ['....X.......X..-', '....X...-...X..x'],
      h: 'x.xox.x.x.xox.x.',
      r: ['X.x.x.x.X.x.x.x.', 'X.x.x.x.X.x.x.x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........-.......', m: '........o.......' },
    fill: { k: 'X.......x.......', s: '....X..-x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . 7 . . 0 . 0 . . 5 . . 3 .'), P('0 . . 7 . . 0 . 0 . . 10 . . 7 .')],
    walk: [P('0 . 3 . 5 . 7 . 8 . 7 . 5 . 3 .'), P('0 . 5 . 7 . 10 . 7 . 5 . 3 . 0 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    riff: [P('. . 0 . . . 0 . . . 0 . . . 3 .'), P('. . 0 . . . 3 . . . 0 . . . 5 .')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . . 5 . . . 10 . . . 12 . . .'),
        P('10 . 8 . 7 . 5 . 3 . . . 0 . . .'),
        P('0 . . . 7 . . . 12 . . . 15 . . .'),
        P('14 . 12 . 10 . 7 . 5 . . . 0 . . .')],
    B: [P('19 . . . 22 . . . 24 . . . 22 . 19 .'),
        P('20 . 19 . 17 . 15 . 12 . . . . . . .'),
        P('19 . . . 24 . . . 27 . . . 24 . 22 .'),
        P('22 . 20 . 19 . 15 . 12 . . . . . . .')],
    C: [P('0 . . . . . . . 5 . . . . . . .'),
        P('10 . . . . . . . 7 . . . . . . .'),
        P('0 . . . . . . . 7 . . . . . . .'),
        P('12 . . . . . . . 10 . . . . . . .')],
    Bh: [P('12 . . . 17 . . . 19 . . . 17 . 15 .'),
         P('15 . 14 . 12 . 10 . 7 . . . . . . .'),
         P('12 . . . 19 . . . 22 . . . 19 . 17 .'),
         P('17 . 15 . 14 . 10 . 7 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 2, chords: 'poise', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', gain: 0.82 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'walk', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'poise', drums: 'press', bass: 'walk', gtr: 'riff', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'press', bass: 'walk', gtr: 'stabs', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'walk', gtr: 'stabs' },
    { bars: 2, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'poise', drums: 'press', bass: 'walk', gtr: 'riff', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
  ],
};

// ---- BOSS 8X: DRAY // WARLORD FRAME ---------------------------------------
// "WHEN HIS SUIT GOES DOWN, SOMETHING WORSE STANDS UP IN IT." This is the last
// fight in the game and it is the heaviest thing in it: fuzz on both guitars,
// power chords with no thirds anywhere, the kick doubled, and the poise gone
// completely. Everything that made Dray's theme well-mannered is stripped out
// and what is left underneath is the same tune played by something that does
// not have manners.
//
// Fastest track in the game at 164, which is the top of the climb that started
// at 132 in the lobby. Nothing after this.
const T_boss8x = {
  name: 'Dray // Warlord Frame', bpm: 164, key: 57, lkey: 69, swing: 0, echo: 1.0, level: 0.86,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3300, gain: -1 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  // First pass measured 4.6% midrange against a game whose floor is 8.4%, with
  // sub and bass together taking 82% of the spectrum. Two fuzz guitars voiced
  // at 2600, a deep kick and a sub layer, all chasing the word HEAVIEST - and
  // between them they swallowed the tune whole. The level check passed it,
  // because the levels were never the problem: fuzz at 2600 removes everything
  // above it no matter how loud you set it. Heavy is a thing you hear the
  // melody through, not instead of.
  band: {
    kick: {}, snare: { fat: true },
    clank: { ring: 0.18, pitch: 420, vol: 0.45 },
    bass: { vol: 0.28, bright: 2400, close: 320, sub: 0.25 },
    gtr:  { vol: 0.19, drive: 'hot', tone: 3400 },
    keys: { vol: 0.075, tone: 3000 },
    lead: { vol: 0.38, drive: 'hot', tone: 3900, wide: true, send: 0.24, echo: 0.14 },
    harm: { vol: 0.22, drive: 'hot', tone: 3700, wide: true, send: 0.20, echo: 0.10 },
    arp:  { vol: 0.065, wave: 'triangle', tone: 3600, echo: 0.16 },
  },
  chords: {
    // no thirds left anywhere. There is nothing to feel about this one.
    main: [[0, '5'], [-4, '5'], [-2, '5'], [0, '5']],
    hard: [[0, '5'], [0, '5'], [-1, '5'], [-2, '5']],
    turn: [[5, 'm'], [3, 'M'], [-4, 'M'], [0, 'm']],
  },
  drums: {
    intro: { k: 'X...X...X...X...', c: 'X...............', m: '........X.......' },
    main: {
      k: ['X...X...X.....x.', 'X...X.x.X...x...'],
      s: ['....X.......X...', '....X.......X..X'],
      h: 'x.x.x.x.x.x.x.x.',
      m: ['......x.......x.', '......x.......x.'],
    },
    press: {
      k: ['X...X...X...X...', 'X...X...X.x.X...'],
      s: ['....X.......X..X', '....X...X...X.X.'],
      h: 'xxxxxxxxxxxxxxxx',
      m: ['......x...x...x.', '..x...x...x...x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X.......X.......', s: '........X.......', m: '........X.......' },
    fill: { k: 'X...X...X...X...', s: '....X...X.X.X.XX', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . -2 .'), P('0 . 0 . 0 . 0 . 0 . 0 . -4 . -1 .')],
    grind: [P('0 . 0 0 . 0 . -1 0 . 0 0 . -2 . -4'), P('0 . 0 -1 . 0 . -2 0 . 0 0 . -4 . 0')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 0 . 0 0 . 0 . -1 0'), P('0 . 0 0 . 0 . -2 . 0 0 . 0 . -4 .')],
    stabs: [P('0 . . . 0 . . . 0 . . . 0 . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // the same tune. It was always this underneath.
    A: [P('0 . . . 5 . . . 10 . . . 12 . . .'),
        P('10 . 8 . 7 . 5 . 3 . . . 0 . . .'),
        P('0 . . . 7 . . . 12 . . . 15 . . .'),
        P('14 . 12 . 10 . 7 . 5 . . . 0 . . .')],
    B: [P('19 . . . 22 . . . 24 . . . 22 . 19 .'),
        P('20 . 19 . 17 . 15 . 12 . . . . . . .'),
        P('19 . . . 24 . . . 27 . . . 24 . 22 .'),
        P('22 . 20 . 19 . 15 . 12 . . . . . . .')],
    C: [P('0 . . . . . . . 5 . . . . . . .'),
        P('10 . . . . . . . 7 . . . . . . .'),
        P('0 . . . . . . . 7 . . . . . . .'),
        P('12 . . . . . . . 10 . . . . . . .')],
    // the second guitar stops harmonising and starts doubling. Two of it now.
    Bh: [P('0 . . . 5 . . . 10 . . . 12 . . .'),
         P('10 . 8 . 7 . 5 . 3 . . . 0 . . .'),
         P('12 . . . 19 . . . 24 . . . 27 . . .'),
         P('26 . 24 . 22 . 19 . 17 . . . 12 . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 2, chords: 'hard', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', keys: 'hold', gain: 0.86 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'grind', gtr: 'riff', keys: 'hold', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'hard', drums: 'press', bass: 'grind', gtr: 'riff', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'press', bass: 'grind', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'hard', drums: 'fill', bass: 'grind', gtr: 'stabs', gtrStyle: 'power' },
    // two bars near the end where the fuzz drops out and you hear the tune
    // clean for the last time in the game
    { bars: 2, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'hard', drums: 'press', bass: 'grind', gtr: 'riff', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
  ],
};

const STAGE8_TRACKS = { S8A: T_stage8a, S8B: T_stage8b, S8C: T_stage8c, B8: T_boss8, B8X: T_boss8x };
