const OPTIONS = [
  { k: 'H1', song: S5_TUNNEL, still: 'roadtun', tag: 'DRUM & BASS',
    pitch: 'The article itself. A chopped break at 174 that never plays the same bar twice, a Reese bass you feel rather than hear, and half-time drops where the floor goes for four bars.',
    notes: [
      'The break is four bars long and every one is different - that is the whole trick of the genre',
      'Drops to half time at 0:35 and stays there long enough to be uncomfortable',
      'Written for the tunnel: enclosed, rolling, no daylight in it',
    ] },
  { k: 'H2', song: S5_SUNRISE, still: 'dawnroad', tag: 'LIQUID',
    pitch: 'The dawn reading, and the melodic end of the same music. The break still rolls at 174 but the bass is warm rather than growling and the lines are long enough to watch the sun come up to.',
    notes: [
      'Same tempo as H1, completely different temperature - this is the one that fits the board run',
      'Widest pads in the game over the fastest drums in the game, which is the trick liquid runs on',
      'The most melodic thing I have written for this soundtrack',
    ] },
  { k: 'H3', song: S5_DARK, still: 'roadtun', tag: 'HALF-TIME',
    pitch: 'The dark end. Half time over the same 174 grid, so it feels like 87 until the break arrives and doubles it underneath you. Mostly space and sub.',
    notes: [
      'Starts at half speed and switches to full at 0:22 without changing tempo - one trick, used once',
      'The nastiest track in the game; more Vex than highway',
      'Sparse by design, so it has the least going on of the four',
    ] },
  { k: 'H4', song: S5_ROCK, still: 'dawnroad', tag: 'NOT D&B',
    pitch: 'The one that is not drum and bass, in case you would rather keep the break for a single scene. Big-beat rock at 160: guitars over a breakbeat rather than a straight rock kit.',
    notes: [
      'The kick moves around instead of sitting on the beat, so it still drives like the highway',
      'Closest to stages 1 and 4 in character - it would make stage 5 continuous rather than a departure',
      'Here mainly so the break does not have to cover both scenes if you do not want it to',
    ] },
];
const SCENES = [
  { id: 's5a', label: 'Underpass' },
  { id: 's5b', label: 'Fast Lane' },
];

let started = false, playing = null, raf = 0;
function ensureAudio() {
  if (started) return;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  initBand(new Ctx());
  started = true;
}
function stopAll() {
  Band.stop(); playing = null;
  document.querySelectorAll('.card').forEach(c => c.classList.remove('playing'));
  document.querySelectorAll('.play').forEach(b => { b.textContent = 'Play'; });
  cancelAnimationFrame(raf);
  document.querySelectorAll('.bar i').forEach(b => { b.style.width = '0%'; });
  document.querySelectorAll('.pos').forEach(p => { p.textContent = '0:00'; });
}
function toggle(opt, card) {
  ensureAudio();
  if (AC.state !== 'running') AC.resume();
  if (playing === opt.k) { stopAll(); return; }
  stopAll();
  playing = opt.k;
  card.classList.add('playing');
  card.querySelector('.play').textContent = 'Stop';
  Band.play(opt.k, { [opt.k]: opt.song });
  const t0 = AC.currentTime, total = songSeconds(opt.song);
  const bar = card.querySelector('.bar i'), pos = card.querySelector('.pos');
  const tick = () => {
    if (playing !== opt.k) return;
    const el = (AC.currentTime - t0) % total;
    bar.style.width = (el / total * 100).toFixed(1) + '%';
    pos.textContent = fmtTime(el);
    raf = requestAnimationFrame(tick);
  };
  tick();
}
const fmtTime = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');

const PICK_KEY = 'rc_mus_picks_s5';
let picks = {};
try { picks = JSON.parse(localStorage.getItem(PICK_KEY) || '{}'); } catch (e) { picks = {}; }
function savePicks() { try { localStorage.setItem(PICK_KEY, JSON.stringify(picks)); } catch (e) {} }
function refresh() {
  document.querySelectorAll('.card').forEach(c => {
    const k = c.dataset.k;
    const mine = SCENES.filter(s => picks[s.id] === k);
    c.classList.toggle('picked', mine.length > 0);
    c.querySelectorAll('.pick').forEach(b => {
      const on = picks[b.dataset.scene] === k;
      b.classList.toggle('on', on);
      b.textContent = (on ? '\u2713 ' : '') + b.dataset.label;
    });
  });
  const s = document.getElementById('summary');
  const parts = SCENES.filter(x => picks[x.id]).map(x => {
    const o = OPTIONS.find(y => y.k === picks[x.id]);
    return x.label + ': ' + picks[x.id] + ' \u2014 ' + o.song.name;
  });
  s.textContent = parts.length ? parts.join('   \u00b7   ')
    : 'Pick one for each scene and this line becomes the message to send back.';
}

function buildPage() {
  const wrap = document.getElementById('cards');
  for (const opt of OPTIONS) {
    const total = songSeconds(prepSong(opt.song));
    const card = document.createElement('section');
    card.className = 'card'; card.dataset.k = opt.k;
    card.innerHTML =
      '<div class="screen"><img alt="Stage 2 background" src="' + STILLS[opt.still] + '">' +
        '<span class="tag">' + opt.tag + '</span>' +
      '</div>' +
      '<div class="body">' +
        '<div class="titlerow">' +
          '<h3><span class="key">' + opt.k + '</span>' + opt.song.name + '</h3>' +
          '<div class="picks">' + SCENES.map(s =>
            '<button class="pick" type="button" data-scene="' + s.id + '" data-label="' + s.label + '">' + s.label + '</button>'
          ).join('') + '</div>' +
        '</div>' +
        '<p class="pitch">' + opt.pitch + '</p>' +
        '<ul class="notes">' + opt.notes.map(n => '<li>' + n + '</li>').join('') + '</ul>' +
        '<div class="transport">' +
          '<button class="play" type="button">Play</button>' +
          '<div class="bar"><i></i></div>' +
          '<span class="pos">0:00</span><span class="sep">/</span><span class="len">' + fmtTime(total) + '</span>' +
        '</div>' +
        '<p class="meta">' + opt.song.bpm + ' bpm \u00b7 ' + opt.song._bars + ' bars before it repeats \u00b7 F minor</p>' +
      '</div>';
    card.querySelector('.play').addEventListener('click', () => toggle(opt, card));
    card.querySelectorAll('.pick').forEach(b => b.addEventListener('click', () => {
      const sc = b.dataset.scene;
      if (picks[sc] === opt.k) delete picks[sc]; else picks[sc] = opt.k;
      savePicks(); refresh();
    }));
    wrap.appendChild(card);
  }
  refresh();
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') stopAll(); });
buildPage();
