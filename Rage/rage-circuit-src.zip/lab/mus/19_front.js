// ====================================================== FRONT-END + ENDING
// The five tracks that are not a stage: title, menu, shop, training, ending.
// All in A minor, the frame the game opens and closes in, and all in the house
// band so nothing anywhere is left sounding like the old engine.
//
// THE ENDING gets the idea from K4 "Goes Off The Roof" - the stage 8 option
// that was not picked. Its hook landed on the MAJOR THIRD, and eight stages of
// minor keys resolving upward is exactly right for the ending text and exactly
// wrong for a stage you have to fight through. The idea was too good to lose
// and the ending is where it actually belongs.

// ---- TITLE ----------------------------------------------------------------
// Short, loud, and over in twenty seconds. A title screen is a promise about
// what the next hour sounds like, so this is the whole band with the lead
// guitar out front and nothing clever going on.
const T_title = {
  name: 'Rage Circuit', bpm: 150, key: 57, lkey: 69, swing: 0.04, echo: 1.2, level: 0.92,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3400, gain: -2.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.34, bright: 2400, close: 340 },
    gtr:  { vol: 0.20, drive: 'hot', tone: 2900 },
    keys: { vol: 0.09, tone: 2900 },
    lead: { vol: 0.34, drive: 'crunch', tone: 3400, send: 0.26, echo: 0.16 },
    harm: { vol: 0.18, drive: 'crunch', tone: 3200, send: 0.22, echo: 0.12 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3600, echo: 0.22 },
  },
  chords: {
    main: [[0, 'm'], [-4, 'M'], [-2, 'M'], [0, 'm']],
    lift: [[-4, 'M'], [3, 'M'], [-2, 'M'], [0, 'm']],
  },
  drums: {
    hit: { k: 'X.......X.......', c: 'X...............', h: 'x.x.x.x.x.x.x.x.' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.xox.x.x.xox.x.'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X.-.'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 . . . 0 . 0 . . . 7 . 5 .'), P('0 . 0 . . . 0 . 0 . . . 10 . 7 .')],
    drive: [P('0 . 0 7 . 0 . 5 0 . 0 7 . 5 . 3'), P('0 . 7 0 . 5 . 0 0 . 0 10 . 7 . 5')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 0 . 5 3'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 3 . 0')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . 3 . 5 . . 7 . . . 5 . 3 .'),
        P('7 . . 5 . 3 . . 0 . . . . . . .'),
        P('0 . . 5 . 7 . . 10 . . . 12 . . .'),
        P('10 . . 7 . 5 . . 3 . . . 0 . . .')],
    Bh: [P('12 . . 15 . 17 . . 19 . . . 17 . 15 .'),
         P('19 . . 17 . 15 . . 12 . . . . . . .'),
         P('12 . . 17 . 19 . . 22 . . . 24 . . .'),
         P('22 . . 19 . 17 . . 15 . . . 12 . . .')],
  },
  arps: { run: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 2, chords: 'main', drums: 'hit', bass: 'soft', gtr: 'ring', gtrStyle: 'power', keys: 'hold', gain: 0.86 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', lead: 'A', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'riff' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
  ],
};

// ---- MENU -----------------------------------------------------------------
// This one plays while somebody reads a move list, so it is built to be
// ignored: no lead line at all, just the band holding a groove. The only track
// in the set with no melody in it, on purpose.
const T_menu = {
  name: 'Menu', bpm: 112, key: 57, lkey: 69, swing: 0.06, echo: 1.4, level: 0.90,
  // Having no melody is the idea; having nothing above 2.5kHz was an accident.
  // With no lead line the clean guitar and the bell arp ARE the top of this
  // track, so they carry it and the shelf comes back up.
  tone: { freq: 3300, gain: -1 },
  bassVoice: 'pick', gtrStyle: 'clean', keyStyle: 'ep', leadStyle: 'lead', harmStyle: 'clean',
  band: {
    kick: {}, snare: { fat: false },
    bass: { vol: 0.32, bright: 2000, close: 300 },
    gtr:  { vol: 0.17, tone: 4400, send: 0.44, echo: 0.30 },
    keys: { vol: 0.13, tone: 3600, bite: 2.2 },
    lead: { vol: 0.24, drive: 'clean', tone: 3000, send: 0.40, echo: 0.28 },
    harm: { vol: 0.09, tone: 3600, send: 0.40, echo: 0.28 },
    // Lifting the shelf 3dB moved this track 0.3% and no further, which is the
    // answer to a question I had asked wrong: electric piano, bell plucks and
    // a chorused clean guitar are all sine and triangle voices, and no EQ
    // creates harmonics that were never generated. The arp becomes a sawtooth
    // stab so there is something up there to lift in the first place.
    arp:  { vol: 0.085, wave: 'sawtooth', tone: 4200, echo: 0.34, voice: 'stab' },
  },
  chords: {
    main: [[0, 'm9'], [-4, 'M9'], [-2, 'M'], [5, 'm7']],
    lift: [[3, 'M7'], [-2, 'M'], [0, 'm9'], [0, 'm9']],
  },
  drums: {
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...xo', '..x...x...x...x.'],
    },
    easy: {
      k: ['X.......X.......', 'X.......X.......'],
      s: ['............X...', '............X...'],
      h: ['..x.......x.....', '..x.......x...x.'],
    },
  },
  bass: {
    main: [P('0 . . . . . 0 . 0 . . . 7 . 5 .'), P('0 . . . . . 0 . 0 . . . 10 . 7 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    ring: [P('0 . . . . . . . 7 . . . . . . .'), P('0 . . . . . . . 5 . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {},
  arps: { slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'stab' } },
  form: [
    { bars: 4, chords: 'main', drums: 'easy', bass: 'soft', gtr: 'ring', keys: 'hold', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', drums: 'easy', bass: 'soft', gtr: 'ring', keys: 'hold', arp: 'slow', gain: 0.84 },
  ],
};

// ---- SHOP -----------------------------------------------------------------
// Somebody is spending money they earned by hitting people. Swung, warm, a
// little pleased with itself - electric piano out front and the guitar
// comping behind it rather than the other way round.
const T_shop = {
  name: 'Shop', bpm: 126, key: 57, lkey: 69, swing: 0.12, echo: 1.3, level: 0.90,
  // The electric piano is an FM sine voice - warm, and almost nothing above
  // 2.5kHz. Leading with it is right for a shop and left the whole track
  // muffled, so the shelf comes up and the bell arp does the sparkle.
  tone: { freq: 3400, gain: -0.5 },
  bassVoice: 'pick', gtrStyle: 'clean', keyStyle: 'ep', leadStyle: 'ep', harmStyle: 'clean',
  band: {
    kick: {}, snare: { fat: false },
    bass: { vol: 0.32, bright: 2200, close: 320 },
    gtr:  { vol: 0.17, tone: 4600, send: 0.36, echo: 0.22 },
    keys: { vol: 0.115, tone: 3800, bite: 2.6 },
    lead: { vol: 0.28, tone: 4200, bite: 3.0, send: 0.32, echo: 0.20 },
    harm: { vol: 0.10, tone: 4200, send: 0.34, echo: 0.22 },
    arp:  { vol: 0.085, wave: 'sawtooth', tone: 4400, echo: 0.26, voice: 'stab' },
  },
  chords: {
    main: [[0, 'm7'], [5, 'm7'], [-2, '7'], [-4, 'M7']],
    lift: [[-4, 'M7'], [3, 'M7'], [5, 'm7'], [0, 'm7']],
  },
  drums: {
    main: {
      k: ['X.....x.X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X..-'],
      r: ['X.x.x.x.X.x.x.x.', 'X.x.x.xoX.x.x.x.'],
    },
    easy: {
      k: ['X.......X.......', 'X.......X.......'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...x.', '..x...x...x...xo'],
    },
  },
  bass: {
    walk: [P('0 . . 3 . . 5 . 7 . . 5 . . 3 .'), P('0 . . 5 . . 7 . 10 . . 7 . . 5 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: { comp: [P('. . 0 . . . 0 . . . 0 . . . 0 .')] },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . 5 . 7 . . 5 . . . 3 . . .'),
        P('5 . . 3 . 0 . . . . . . . . . .'),
        P('7 . . 10 . 12 . . 10 . . . 7 . . .'),
        P('5 . . 3 . 5 . . 0 . . . . . . .')],
  },
  arps: { slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'stab' } },
  form: [
    { bars: 4, chords: 'main', drums: 'easy', bass: 'soft', gtr: 'comp', keys: 'hold', arp: 'slow', gain: 0.82 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'walk', gtr: 'comp', keys: 'hold', arp: 'slow', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'walk', gtr: 'comp', keys: 'hold', lead: 'A' },
    { bars: 4, chords: 'main', drums: 'easy', bass: 'walk', gtr: 'comp', keys: 'hold', arp: 'slow' },
  ],
};

// ---- TRAINING -------------------------------------------------------------
// A practice room. Steady, even, no surprises and no arrangement tricks -
// something you can hear a hundred times while you learn a combo and never
// once notice. The kick is straight fours and stays there.
const T_training = {
  name: 'Training Room', bpm: 134, key: 57, lkey: 69, swing: 0, echo: 1.1, level: 0.90,
  tone: { freq: 3400, gain: -1.5 },
  bassVoice: 'syn', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: false },
    // kick on every quarter landing on the syn bass's sine sub is what put
    // this one over the ceiling; the sub comes down and takes the clip with it
    bass: { vol: 0.33, bright: 2000, close: 280, sub: 0.55 },
    gtr:  { vol: 0.15, drive: 'crunch', tone: 3400 },
    keys: { vol: 0.075, bright: 4400, wave: 'sawtooth' },
    lead: { vol: 0.28, bright: 5000, send: 0.26, echo: 0.20, wave: 'sawtooth' },
    harm: { vol: 0.11, drive: 'crunch', tone: 3200, send: 0.22, echo: 0.12 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3600, echo: 0.22 },
  },
  chords: {
    main: [[0, 'm'], [-2, 'M'], [-4, 'M'], [0, 'm']],
    lift: [[-4, 'M'], [-2, 'M'], [0, 'm'], [0, 'm']],
  },
  drums: {
    main: {
      k: ['X...X...X...X...', 'X...X...X...X...'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'x.x.x.x.x.x.x.x.',
    },
    open: {
      k: ['X...X...X...X...', 'X...X...X...X...'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['x.x.x.x.x.x.x.xo', 'x.x.x.x.x.x.x.x.'],
    },
  },
  bass: {
    main: [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . 0 .'), P('0 . 0 . 0 . 0 . 0 . 0 . 7 . 5 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: { riff: [P('0 . . . 0 . . . 0 . . . 0 . . .')] },
  keys: { pulse: [P('0 . . . 0 . . . 0 . . . 0 . . .')] },
  leads: {
    A: [P('0 . . . 3 . . . 5 . . . 3 . . .'),
        P('7 . . . 5 . . . 3 . . . 0 . . .'),
        P('0 . . . 5 . . . 7 . . . 10 . . .'),
        P('7 . . . 5 . . . 3 . . . 0 . . .')],
  },
  arps: { run: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'pulse', arp: 'run', gain: 0.84 },
    { bars: 4, chords: 'main', drums: 'open', bass: 'main', gtr: 'riff', keys: 'pulse', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', keys: 'pulse', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'main', drums: 'open', bass: 'main', gtr: 'riff', keys: 'pulse', arp: 'run' },
  ],
};

// ---- ENDING ---------------------------------------------------------------
// This runs under the ending text, so it is the longest and the only track in
// the game that is allowed to simply arrive somewhere and stay.
//
// It uses K4's idea: the hook climbs a fourth, a fifth and an octave and lands
// on 16 - the MAJOR third, an octave up - and the progression keeps arriving
// on major chords underneath it. Eight stages in minor and the last thing you
// hear resolves. Twin guitars in harmony the whole way, because none of the
// endings have the player finishing it on their own.
const T_ending = {
  name: 'The Circuit Is Open', bpm: 128, key: 57, lkey: 69, swing: 0.03, echo: 1.5, level: 0.90,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3400, gain: -2.5 },
  bassVoice: 'pick', gtrStyle: 'clean', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.33, bright: 2300, close: 330 },
    gtr:  { vol: 0.17, tone: 4000, send: 0.40, echo: 0.26 },
    keys: { vol: 0.105, tone: 3000 },
    lead: { vol: 0.32, drive: 'crunch', tone: 3400, send: 0.34, echo: 0.22 },
    harm: { vol: 0.19, drive: 'crunch', tone: 3200, send: 0.30, echo: 0.18 },
    arp:  { vol: 0.08, wave: 'triangle', tone: 3600, echo: 0.28 },
  },
  chords: {
    // it keeps landing on the major. That is the whole argument of the track.
    main: [[0, 'm'], [-4, 'M'], [3, 'M'], [-2, 'M']],
    lift: [[3, 'M'], [-2, 'M'], [-4, 'M9'], [0, 'm']],
    open: [[-4, 'M9'], [3, 'M7'], [-2, 'M'], [3, 'M7']],
  },
  drums: {
    intro: { h: '..x...x...x...x.', k: 'X...............' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...xo', '..x...x...x...x.'],
    },
    full: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.xox.x.x.xox.x.',
      r: ['X.x.x.x.X.x.x.x.', 'X.x.x.x.X.x.x.x.'],
      c: ['X...............', '................'],
    },
    easy: { k: 'X.......X.......', s: '....X.......X...', h: '..x.......x.....' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . 0 . 0 . . . 8 . 7 .'), P('0 . . . . . 0 . 0 . . . 7 . 5 .')],
    lift: [P('0 . . 7 . . 0 . 8 . . 7 . . 12 .'), P('0 . . 8 . . 7 . 0 . . 12 . . 7 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    ring: [P('0 . . . . . . . 7 . . . . . . .'), P('0 . . . . . . . 4 . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // up a fourth, up a fifth, up an octave, and it lands on the major third
    A: [P('0 . . . 7 . . . 12 . . . 16 . . .'),
        P('14 . . . 12 . . . 7 . . . . . . .'),
        P('7 . . . 12 . . . 16 . . . 19 . . .'),
        P('16 . . . 14 . . . 12 . . . . . . .')],
    B: [P('19 . . . 24 . . . 28 . . . 26 . 24 .'),
        P('26 . . . 24 . . . 19 . . . . . . .'),
        P('24 . . . 28 . . . 31 . . . 28 . 26 .'),
        P('28 . . . 26 . . . 24 . . . . . . .')],
    C: [P('0 . . . . . . . 7 . . . . . . .'),
        P('12 . . . . . . . . . . . . . . .'),
        P('7 . . . . . . . 12 . . . . . . .'),
        P('16 . . . . . . . . . . . . . . .')],
    Bh: [P('4 . . . 12 . . . 16 . . . 19 . . .'),
         P('19 . . . 16 . . . 12 . . . . . . .'),
         P('12 . . . 16 . . . 19 . . . 24 . . .'),
         P('19 . . . 19 . . . 16 . . . . . . .')],
  },
  arps: {
    rise: { notes: [0, 1, 2, 3], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'hold', keys: 'hold', arp: 'slow', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'easy', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'rise' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'rise', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'lift', gtr: 'ring', keys: 'hold', arp: 'rise', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'open', drums: 'full', bass: 'lift', gtr: 'ring', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'lift', gtr: 'ring' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.82 },
    { bars: 4, chords: 'lift', drums: 'full', bass: 'lift', gtr: 'ring', keys: 'hold', arp: 'rise', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'open', drums: 'easy', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'slow', gain: 0.80 },
  ],
};

const FRONT_TRACKS = { title: T_title, menu: T_menu, shop: T_shop, training: T_training, ending: T_ending };
