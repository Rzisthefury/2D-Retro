// ============================================================ stage 2 picker
// Same four tracks, two jobs. The Strip has a street and a loading dock behind
// the club, and stage 1 showed those can want different treatments - so every
// card can be picked for either scene, or for both.
const OPTIONS = [
  { k: 'N1', song: S2_NEON, still: 'canyon', tag: 'SYNTH LED',
    pitch: 'The rooftops carried on down into the street. Arpeggio bouncing off the wet road on a long delay, poly-synth melody, guitar answering underneath.',
    notes: [
      'The natural continuation of what you picked for the rooftops - same band, new tune',
      'Long echo on the arpeggio and the guitar, which is what all that standing water is for',
      'Down in the dock it would read as the street noise following you inside',
    ] },
  { k: 'N2', song: S2_MARKET, still: 'canyon', tag: 'EXOTIC',
    pitch: 'The signs on that street say NOODLE, HOTEL, KTV. This one takes the hint and builds the melody on a flattened second - the interval that makes a tune sound like somewhere else.',
    notes: [
      'Tremolo-picked clean guitar and electric piano; the kit plays rims and toms instead of a backbeat',
      'Swung, 134bpm, and the only track in the game that is not plainly western',
      'The mellowest of the four by some way - more atmosphere than drive',
    ] },
  { k: 'N3', song: S2_BLEED, still: 'basement', tag: 'DIEGETIC',
    pitch: 'Written for the loading dock: what you hear is the club PA through a wall. It opens muffled and sub-heavy, and every time the arrangement lifts the doors open further.',
    notes: [
      'Starts filtered with just the kick coming through, then the real kit and guitar cut in over the top',
      'Sub bass rather than picked - the thing you feel through the floor when you stand near a stack',
      'The only track where the music is coming from somewhere in the scene rather than over it',
    ] },
  { k: 'N4', song: S2_ROCK, still: 'canyon', tag: 'GUITAR LED',
    pitch: 'The band from Under the El, further into the night and less polite. Twin guitars in harmony rather than one lead, organ underneath, and a bass that never stops moving.',
    notes: [
      'Fastest at 146, and the only one where two guitars carry the tune together',
      'Closest in character to what you picked for the street in stage 1, so the two would sit together',
      'Would make the dock feel like a fight rather than a club',
    ] },
];
const SCENES = [
  { id: 's2a', label: 'Canyon' },
  { id: 's2b', label: 'Basement' },
];

let started = false, playing = null, raf = 0;
function ensureAudio() {
  if (started) return;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  initBand(new Ctx());
  started = true;
}
function stopAll() {
  Band.stop(); playing = null;
  document.querySelectorAll('.card').forEach(c => c.classList.remove('playing'));
  document.querySelectorAll('.play').forEach(b => { b.textContent = 'Play'; });
  cancelAnimationFrame(raf);
  document.querySelectorAll('.bar i').forEach(b => { b.style.width = '0%'; });
  document.querySelectorAll('.pos').forEach(p => { p.textContent = '0:00'; });
}
function toggle(opt, card) {
  ensureAudio();
  if (AC.state !== 'running') AC.resume();
  if (playing === opt.k) { stopAll(); return; }
  stopAll();
  playing = opt.k;
  card.classList.add('playing');
  card.querySelector('.play').textContent = 'Stop';
  Band.play(opt.k, { [opt.k]: opt.song });
  const t0 = AC.currentTime, total = songSeconds(opt.song);
  const bar = card.querySelector('.bar i'), pos = card.querySelector('.pos');
  const tick = () => {
    if (playing !== opt.k) return;
    const el = (AC.currentTime - t0) % total;
    bar.style.width = (el / total * 100).toFixed(1) + '%';
    pos.textContent = fmtTime(el);
    raf = requestAnimationFrame(tick);
  };
  tick();
}
const fmtTime = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');

const PICK_KEY = 'rc_mus_picks_s2';
let picks = {};
try { picks = JSON.parse(localStorage.getItem(PICK_KEY) || '{}'); } catch (e) { picks = {}; }
function savePicks() { try { localStorage.setItem(PICK_KEY, JSON.stringify(picks)); } catch (e) {} }
function refresh() {
  document.querySelectorAll('.card').forEach(c => {
    const k = c.dataset.k;
    const mine = SCENES.filter(s => picks[s.id] === k);
    c.classList.toggle('picked', mine.length > 0);
    c.querySelectorAll('.pick').forEach(b => {
      const on = picks[b.dataset.scene] === k;
      b.classList.toggle('on', on);
      b.textContent = (on ? '\u2713 ' : '') + b.dataset.label;
    });
  });
  const s = document.getElementById('summary');
  const parts = SCENES.filter(x => picks[x.id]).map(x => {
    const o = OPTIONS.find(y => y.k === picks[x.id]);
    return x.label + ': ' + picks[x.id] + ' \u2014 ' + o.song.name;
  });
  s.textContent = parts.length ? parts.join('   \u00b7   ')
    : 'Pick one for each scene and this line becomes the message to send back.';
}

function buildPage() {
  const wrap = document.getElementById('cards');
  for (const opt of OPTIONS) {
    const total = songSeconds(prepSong(opt.song));
    const card = document.createElement('section');
    card.className = 'card'; card.dataset.k = opt.k;
    card.innerHTML =
      '<div class="screen"><img alt="Stage 2 background" src="' + STILLS[opt.still] + '">' +
        '<span class="tag">' + opt.tag + '</span>' +
      '</div>' +
      '<div class="body">' +
        '<div class="titlerow">' +
          '<h3><span class="key">' + opt.k + '</span>' + opt.song.name + '</h3>' +
          '<div class="picks">' + SCENES.map(s =>
            '<button class="pick" type="button" data-scene="' + s.id + '" data-label="' + s.label + '">' + s.label + '</button>'
          ).join('') + '</div>' +
        '</div>' +
        '<p class="pitch">' + opt.pitch + '</p>' +
        '<ul class="notes">' + opt.notes.map(n => '<li>' + n + '</li>').join('') + '</ul>' +
        '<div class="transport">' +
          '<button class="play" type="button">Play</button>' +
          '<div class="bar"><i></i></div>' +
          '<span class="pos">0:00</span><span class="sep">/</span><span class="len">' + fmtTime(total) + '</span>' +
        '</div>' +
        '<p class="meta">' + opt.song.bpm + ' bpm \u00b7 ' + opt.song._bars + ' bars before it repeats \u00b7 G minor</p>' +
      '</div>';
    card.querySelector('.play').addEventListener('click', () => toggle(opt, card));
    card.querySelectorAll('.pick').forEach(b => b.addEventListener('click', () => {
      const sc = b.dataset.scene;
      if (picks[sc] === opt.k) delete picks[sc]; else picks[sc] = opt.k;
      savePicks(); refresh();
    }));
    wrap.appendChild(card);
  }
  refresh();
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') stopAll(); });
buildPage();
