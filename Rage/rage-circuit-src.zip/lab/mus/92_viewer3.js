const OPTIONS = [
  { k: 'T1', song: S3_GROUND, still: 'found', tag: 'INDUSTRIAL',
    pitch: 'Industrial guitar. A palm-muted riff locked to scaffold-pole percussion, so the band and the site are playing the same rhythm.',
    notes: [
      'New in the kit for this stage: struck metal, tuned so it rings without ever being a note',
      'Closest in character to Under the El, so it would sit naturally after stages 1 and 2',
      'The most straightforward of the four and the safest bet for the ground',
    ] },
  { k: 'T2', song: S3_PILE, still: 'found', tag: 'MACHINERY',
    pitch: 'Built around an actual machine. Something enormous lands on beat one and everything else is syncopated around the gap it leaves.',
    notes: [
      '92bpm, half-time, and by a distance the slowest and heaviest thing in the game',
      'The pile driver hit is its own voice - a sub thud, a body, and the metal ringing off it',
      'Menacing rather than energetic; it would make the falling girders feel deliberate',
    ] },
  { k: 'T3', song: S3_SUNSET, still: 'glass', tag: 'WIDE',
    pitch: 'The glass-floor reading. Forty storeys up with the sunset coming through the curtain wall, and for about a minute nobody is trying to kill you.',
    notes: [
      'Long lines with a lot of air between them - the melody moves about a third as fast as anything else here',
      'Guitar plays ringing harmonics rather than chords; the metal is still there, just a long way below',
      'The calmest track in the game so far, and the biggest contrast with the ground floor',
    ] },
  { k: 'T4', song: S3_SHIFT, still: 'found', tag: 'GROOVE',
    pitch: 'The site is still working. This one is about the crew rather than the plant: an organ groove, a bass that walks, and metal only where somebody would actually be hitting something.',
    notes: [
      'Swung sixteenths at 138, ride cymbal taking over in the choruses',
      'Human rather than mechanical - the one reading where the tower is a job, not a threat',
      'Shares an idiom with stage 2\'s Night Market but with far more drive',
    ] },
];
const SCENES = [
  { id: 's3a', label: 'Ground' },
  { id: 's3b', label: 'Glass' },
];

let started = false, playing = null, raf = 0;
function ensureAudio() {
  if (started) return;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  initBand(new Ctx());
  started = true;
}
function stopAll() {
  Band.stop(); playing = null;
  document.querySelectorAll('.card').forEach(c => c.classList.remove('playing'));
  document.querySelectorAll('.play').forEach(b => { b.textContent = 'Play'; });
  cancelAnimationFrame(raf);
  document.querySelectorAll('.bar i').forEach(b => { b.style.width = '0%'; });
  document.querySelectorAll('.pos').forEach(p => { p.textContent = '0:00'; });
}
function toggle(opt, card) {
  ensureAudio();
  if (AC.state !== 'running') AC.resume();
  if (playing === opt.k) { stopAll(); return; }
  stopAll();
  playing = opt.k;
  card.classList.add('playing');
  card.querySelector('.play').textContent = 'Stop';
  Band.play(opt.k, { [opt.k]: opt.song });
  const t0 = AC.currentTime, total = songSeconds(opt.song);
  const bar = card.querySelector('.bar i'), pos = card.querySelector('.pos');
  const tick = () => {
    if (playing !== opt.k) return;
    const el = (AC.currentTime - t0) % total;
    bar.style.width = (el / total * 100).toFixed(1) + '%';
    pos.textContent = fmtTime(el);
    raf = requestAnimationFrame(tick);
  };
  tick();
}
const fmtTime = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');

const PICK_KEY = 'rc_mus_picks_s3';
let picks = {};
try { picks = JSON.parse(localStorage.getItem(PICK_KEY) || '{}'); } catch (e) { picks = {}; }
function savePicks() { try { localStorage.setItem(PICK_KEY, JSON.stringify(picks)); } catch (e) {} }
function refresh() {
  document.querySelectorAll('.card').forEach(c => {
    const k = c.dataset.k;
    const mine = SCENES.filter(s => picks[s.id] === k);
    c.classList.toggle('picked', mine.length > 0);
    c.querySelectorAll('.pick').forEach(b => {
      const on = picks[b.dataset.scene] === k;
      b.classList.toggle('on', on);
      b.textContent = (on ? '\u2713 ' : '') + b.dataset.label;
    });
  });
  const s = document.getElementById('summary');
  const parts = SCENES.filter(x => picks[x.id]).map(x => {
    const o = OPTIONS.find(y => y.k === picks[x.id]);
    return x.label + ': ' + picks[x.id] + ' \u2014 ' + o.song.name;
  });
  s.textContent = parts.length ? parts.join('   \u00b7   ')
    : 'Pick one for each scene and this line becomes the message to send back.';
}

function buildPage() {
  const wrap = document.getElementById('cards');
  for (const opt of OPTIONS) {
    const total = songSeconds(prepSong(opt.song));
    const card = document.createElement('section');
    card.className = 'card'; card.dataset.k = opt.k;
    card.innerHTML =
      '<div class="screen"><img alt="Stage 2 background" src="' + STILLS[opt.still] + '">' +
        '<span class="tag">' + opt.tag + '</span>' +
      '</div>' +
      '<div class="body">' +
        '<div class="titlerow">' +
          '<h3><span class="key">' + opt.k + '</span>' + opt.song.name + '</h3>' +
          '<div class="picks">' + SCENES.map(s =>
            '<button class="pick" type="button" data-scene="' + s.id + '" data-label="' + s.label + '">' + s.label + '</button>'
          ).join('') + '</div>' +
        '</div>' +
        '<p class="pitch">' + opt.pitch + '</p>' +
        '<ul class="notes">' + opt.notes.map(n => '<li>' + n + '</li>').join('') + '</ul>' +
        '<div class="transport">' +
          '<button class="play" type="button">Play</button>' +
          '<div class="bar"><i></i></div>' +
          '<span class="pos">0:00</span><span class="sep">/</span><span class="len">' + fmtTime(total) + '</span>' +
        '</div>' +
        '<p class="meta">' + opt.song.bpm + ' bpm \u00b7 ' + opt.song._bars + ' bars before it repeats \u00b7 Bb minor</p>' +
      '</div>';
    card.querySelector('.play').addEventListener('click', () => toggle(opt, card));
    card.querySelectorAll('.pick').forEach(b => b.addEventListener('click', () => {
      const sc = b.dataset.scene;
      if (picks[sc] === opt.k) delete picks[sc]; else picks[sc] = opt.k;
      savePicks(); refresh();
    }));
    wrap.appendChild(card);
  }
  refresh();
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') stopAll(); });
buildPage();
