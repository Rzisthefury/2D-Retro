// Compare a song's voice levels against the SETTLED tracks before rendering it.
// Four times now I have written a track to a concept word - bright, hot, calm,
// hopeful - translated that into pushing the top and thinning the bottom, and
// only found out at the measuring stage seven minutes per track later. The
// numbers that matter are knowable before any audio exists, so check them here.
const fs = require('fs'), path = require('path');
global.P = s => s.trim().split(/\s+/).map(x => x === '.' ? null : (x === '-' ? '-' : +x));
const D = __dirname + '/';
const SETTLED = ['04_stage1.js','06_stage2.js','08_stage3.js','10_stage4.js','12_stage5.js','14_stage6.js','16_stage7.js','18_stage8.js'];
eval(SETTLED.map(f => fs.readFileSync(D+f,'utf8')).join('\n').replace(/^const (T_\w+)/gm,'global.$1'));
const ref = [];
for (const k of Object.keys(global)) if (/^T_/.test(k)) ref.push(global[k]);

const VOICES = ['bass','gtr','keys','lead','harm','arp'];
const med = a => { const s = a.slice().sort((x,y)=>x-y); return s[Math.floor(s.length/2)]; };
const stats = {};
for (const v of VOICES) {
  const vals = ref.map(s => s.band && s.band[v] && s.band[v].vol).filter(x => x !== undefined);
  stats[v] = { med: med(vals), lo: Math.min(...vals), hi: Math.max(...vals) };
}
const toneG = ref.map(s => (s.tone && s.tone.gain) || 0);
stats.tone = { med: med(toneG), lo: Math.min(...toneG), hi: Math.max(...toneG) };

// "top weight": everything that lives above the bass, over the bass itself.
// On the settled tracks this lands in a narrow band; a long way above it has
// meant a track that measured far too bright every single time.
const topw = s => {
  const b = s.band || {}, g = v => (b[v] && b[v].vol) || 0;
  return (g('lead')+g('harm')+g('keys')+g('arp')+g('gtr')) / Math.max(0.01, g('bass'));
};
const tws = ref.map(topw);
stats.topWeight = { med: med(tws), lo: Math.min(...tws), hi: Math.max(...tws) };

// The level check alone let the Warlord Frame through at 4.6% midrange, because
// its levels were fine - it was voiced at fuzz/2600 on both guitars, and a
// waveshaper that steep into a filter that low removes the melody's whole band
// however loud you set it. So check the TONE of the drive voices too: where the
// amp filter sits, and how hard it is being driven.
const DRIVE_RANK = { clean: 0, crunch: 1, hot: 2, fuzz: 3 };
function driveStats(list) {
  const out = { tone: [], rank: [] };
  for (const S of list) for (const v of ['gtr', 'lead', 'harm']) {
    const b = S.band && S.band[v]; if (!b) continue;
    if (b.tone) out.tone.push(b.tone);
    if (b.drive) out.rank.push(DRIVE_RANK[b.drive] === undefined ? 1 : DRIVE_RANK[b.drive]);
  }
  return out;
}
const dref = driveStats(ref);
const minTone = Math.min(...dref.tone);
const maxRank = Math.max(...dref.rank);

const file = process.argv[2], names = process.argv.slice(3);
eval(fs.readFileSync(D+file,'utf8').replace(/^const (S7_\w+|S8_\w+|T_\w+|C_\w+)/gm,'global.$1'));
console.log('settled reference (' + ref.length + ' tracks)');
for (const v of VOICES) console.log('   ' + v.padEnd(6) + 'median ' + stats[v].med.toFixed(3) + '   range ' + stats[v].lo.toFixed(3) + ' - ' + stats[v].hi.toFixed(3));
console.log('   ' + 'tone'.padEnd(6) + 'median ' + stats.tone.med.toFixed(1) + 'dB  range ' + stats.tone.lo.toFixed(1) + ' - ' + stats.tone.hi.toFixed(1));
console.log('   ' + 'TOP/BASS'.padEnd(9) + 'median ' + stats.topWeight.med.toFixed(2) + '   range ' + stats.topWeight.lo.toFixed(2) + ' - ' + stats.topWeight.hi.toFixed(2));
console.log('');
for (const n of names) {
  const S = eval(n);
  const flags = [];
  for (const v of VOICES) {
    const val = S.band && S.band[v] && S.band[v].vol;
    if (val === undefined) continue;
    if (val > stats[v].hi) flags.push(v + ' ' + val.toFixed(3) + ' ABOVE settled max ' + stats[v].hi.toFixed(3));
    else if (val < stats[v].lo) flags.push(v + ' ' + val.toFixed(3) + ' below settled min ' + stats[v].lo.toFixed(3));
  }
  const tw = topw(S);
  if (tw > stats.topWeight.hi) flags.push('TOP/BASS ' + tw.toFixed(2) + ' ABOVE settled max ' + stats.topWeight.hi.toFixed(2) + '  <-- this is the one that has burned me every time');
  const tg = (S.tone && S.tone.gain) || 0;
  if (tg > stats.tone.hi) flags.push('tone ' + tg.toFixed(1) + 'dB brighter than any settled track');
  // the check that would have caught the Warlord Frame before it rendered
  let dark = 0;
  for (const v of ['gtr', 'lead', 'harm']) {
    const b = S.band && S.band[v]; if (!b) continue;
    if (b.tone && b.tone < minTone) flags.push(v + ' voiced at ' + b.tone + 'Hz, below anything settled (' + minTone + 'Hz)');
    if (b.tone && b.tone <= 3000 && DRIVE_RANK[b.drive] >= 2) dark++;
  }
  if (dark >= 2) flags.push(dark + ' drive voices are both hard-driven AND filtered at or under 3kHz - that combination is what buried the melody on the first Warlord Frame');
  console.log((S.name || n).padEnd(22) + 'top/bass ' + tw.toFixed(2) + '   ' + (flags.length ? '' : 'OK'));
  for (const f of flags) console.log('    ! ' + f);
}
