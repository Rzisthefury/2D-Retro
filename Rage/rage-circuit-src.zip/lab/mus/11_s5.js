// ============================================================ STAGE 5 options
// HIGHWAY HEAT, and the stage that was earmarked for drum and bass from the
// start. The Underpass is a road tunnel - tiled walls, sodium strips, extractor
// fans, an SOS phone. Fast Lane is dawn on an elevated highway with the sun
// coming up behind the skyline, and it is the board run: the camera pulls you
// forward whether you like it or not.
//
// So the arc is enclosed and humming, then wide open and bright - which is
// exactly the shape a drum and bass track wants anyway.
//
// F minor: the deepest key in the game, bass at 44Hz, because the whole point
// of this stage is the bottom end.

// ---- H1: THE UNDERPASS ----------------------------------------------------
// Drum and bass proper. A chopped break at 174 that never plays the same bar
// twice, a Reese bass you feel in your chest, and half-time drops where the
// whole thing falls through the floor for two bars.
const S5_TUNNEL = {
  name: 'The Underpass', bpm: 174, key: 53, lkey: 65, swing: 0, level: 0.94,
  tone: { freq: 3400, gain: -0.5 },
  bassVoice: 'reese', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    bass: { vol: 0.22, bright: 900, sweep: 440 },
    gtr:  { vol: 0.11, tone: 3800, send: 0.44, echo: 0.30 },
    keys: { vol: 0.085, open: false, att: 0.6 },
    lead: { vol: 0.32, bright: 5800, send: 0.34, echo: 0.30, wave: 'sawtooth' },
    harm: { vol: 0.19, drive: 'crunch', tone: 3400, send: 0.30, echo: 0.20 },
    arp:  { vol: 0.105, wave: 'triangle', tone: 4200, echo: 0.36 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [-4, 'M'], [-2, 'M']],
    lift: [[-4, 'M'], [-2, 'M'], [0, 'm'], [3, 'M']],
    turn: [[5, 'm'], [-2, 'M'], [0, 'm'], [0, 'm']],
  },
  // the break: four bars, no two the same, which is the whole trick
  breaks: {
    roll: ['k.h.s.hk..hks.h.', 'k.h.s.h.k.hks.g.', '..hks.h.k.h.s.hk', 'k.h.s.hks.h.sgsg'],
    busy: ['k.hks.hk.ghks.h.', 'kghks.h.k.hks.hk', 'k.h.sghk..hks.hk', 'kgh.s.hksghkskgk'],
    // half time: everything falls through the floor
    drop: ['k.......s.......', '........s.......', 'k.......s......k', '........s...g.g.'],
    intro: ['k...............', 'k.......s.......', 'k.h.....s.......', 'k.h.s.h.s.h.sghk'],
  },
  drums: {},
  bass: {
    // long Reese notes under a fast break: that contrast IS drum and bass
    main: [P('0 . . . . . . . 0 . . . . . . .'), P('0 . . . . . . . 10 . . . . . . .')],
    stab: [P('0 . . 0 . . . 0 . . 0 . . . 10 .'), P('0 . . 0 . . 10 . . . 0 . . 7 . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    stab: [P('. . . . 0 . . . . . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . . 3 . . . 7 . . . 5 . . .'),
        P('3 . . . 0 . . . . . . . . . . .'),
        P('7 . . . 8 . . . 12 . . . 10 . . .'),
        P('8 . . . 7 . . . 5 . . . . . . .')],
    B: [P('12 . . 15 . 17 . . 15 . . . 12 . . .'),
        P('10 . . 12 . 10 . . 8 . . . . . . .'),
        P('15 . . 17 . 19 . . 17 . . . 15 . 12 .'),
        P('12 . . . 10 . . . 8 . . . . . . .')],
    C: [P('0 . . . . . . . 3 . . . . . . .'),
        P('7 . . . . . . . 5 . . . . . . .'),
        P('8 . . . . . . . 12 . . . . . . .'),
        P('10 . . . . . . . . . . . . . . .')],
    Bh: [P('7 . . 8 . 12 . . 8 . . . 7 . . .'),
         P('5 . . 7 . 5 . . 3 . . . . . . .'),
         P('8 . . 12 . 15 . . 12 . . . 8 . 7 .'),
         P('7 . . . 5 . . . 3 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', breaks: 'intro', bass: 'soft', keys: 'hold', gain: 0.82 },
    { bars: 4, chords: 'main', breaks: 'roll', bass: 'main', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', breaks: 'roll', bass: 'stab', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', breaks: 'busy', bass: 'stab', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', breaks: 'busy', bass: 'stab', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'B' },
    // the floor goes
    { bars: 4, chords: 'turn', breaks: 'drop', bass: 'main', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', breaks: 'busy', bass: 'stab', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', breaks: 'roll', bass: 'main', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- H2: SUNRISE ROLL -----------------------------------------------------
// The dawn reading, and the liquid end of the same music: the break still
// rolls at 174 but the bass is warm instead of growling, the pads are wide
// open and the melody has lines long enough to watch the sun come up to.
const S5_SUNRISE = {
  name: 'Sunrise Roll', bpm: 174, key: 53, lkey: 65, swing: 0, echo: 1.5, level: 0.94,
  tone: { freq: 3600, gain: 0 },
  bassVoice: 'sub', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'clean',
  band: {
    bass: { vol: 0.25, harm: 0.32 },
    gtr:  { vol: 0.13, tone: 4400, send: 0.50, echo: 0.36 },
    keys: { vol: 0.135, open: true, att: 0.9 },
    lead: { vol: 0.34, bright: 6000, send: 0.40, echo: 0.34, wave: 'sawtooth' },
    harm: { vol: 0.16, tone: 4600, send: 0.44, echo: 0.30 },
    arp:  { vol: 0.125, wave: 'triangle', tone: 4400, echo: 0.44 },
  },
  chords: {
    main: [[0, 'm9'], [3, 'M7'], [-4, 'M9'], [-2, 'M']],
    lift: [[-4, 'M9'], [-2, 'M'], [5, 'm7'], [0, 'm9']],
    turn: [[3, 'M7'], [5, 'm7'], [-2, 'M'], [0, 'm9']],
  },
  breaks: {
    roll: ['k.h.s.h.k.h.s.h.', 'k.h.s.h.k.hks.h.', 'k.h.s.h.k.h.s.hk', 'k.h.s.h.kgh.s.g.'],
    open: ['k.h.s.h.k.h.s.h.', '..h.s.h.k.h.s.h.', 'k.h.s.h.k.h.s.hk', 'k.hgs.h.k.h.sgh.'],
    drop: ['k.......s.......', '........s.......', 'k.......s.......', '........s...g...'],
    intro: ['................', 'k.......s.......', 'k.h.....s.......', 'k.h.s.h.k.h.s.h.'],
  },
  drums: {},
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . . .'), P('0 . . . . . . . 7 . . . . . . .')],
    roll: [P('0 . . 0 . . . 0 . . 0 . . . 10 .'), P('0 . . 0 . . 7 . . . 0 . . 5 . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('12 . . . . . . . . . . . . . . .'), P('7 . . . . . . . . . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('7 . . . . . 10 . . . . . 12 . . .'),
        P('10 . . . . . 7 . . . . . . . . .'),
        P('12 . . . . . 14 . . . . . 15 . . .'),
        P('12 . . . . . 10 . . . . . . . . .')],
    B: [P('19 . . . 17 . . . 15 . . 17 . . . .'),
        P('15 . . . 14 . . . 12 . . . . . . .'),
        P('17 . . . 19 . . . 22 . . 19 . . . .'),
        P('17 . . . 15 . . . 12 . . . . . . .')],
    C: [P('0 . . . . . . . . . . . 3 . . .'),
        P('7 . . . . . . . . . . . . . . .'),
        P('10 . . . . . . . . . . . 12 . . .'),
        P('10 . . . . . . . 7 . . . . . . .')],
    Bh: [P('12 . . . 10 . . . 7 . . 10 . . . .'),
         P('7 . . . 5 . . . 3 . . . . . . .'),
         P('10 . . . 12 . . . 15 . . 12 . . . .'),
         P('10 . . . 7 . . . 5 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', breaks: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', breaks: 'open', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', breaks: 'roll', bass: 'roll', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', breaks: 'roll', bass: 'roll', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', breaks: 'roll', bass: 'roll', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'turn', breaks: 'drop', bass: 'main', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', breaks: 'roll', bass: 'roll', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', breaks: 'open', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- H3: TUNNEL VISION ----------------------------------------------------
// The dark end. Half-time over the same 174 grid, so it feels like 87 until
// the break arrives and doubles it. Sparse, mostly space and sub, with the
// extractor fans breathing in the gaps. Something is hunting this cargo and
// it is not you.
const S5_DARK = {
  name: 'Tunnel Vision', bpm: 174, key: 53, lkey: 65, swing: 0, level: 1.04,
  tone: { freq: 3200, gain: -1.5 },
  bassVoice: 'reese', gtrStyle: 'chug', keyStyle: 'pad', leadStyle: 'lead', harmStyle: 'stab',
  band: {
    bass: { vol: 0.24, bright: 760, sweep: 380 },
    gtr:  { vol: 0.16, drive: 'hot', tone: 2600 },
    keys: { vol: 0.08, open: false, att: 1.0 },
    lead: { vol: 0.36, drive: 'crunch', tone: 3500, wide: true, send: 0.40, echo: 0.26 },
    harm: { vol: 0.16, bright: 4400, send: 0.36, echo: 0.30 },
    arp:  { vol: 0.06, wave: 'triangle', tone: 2800, echo: 0.40 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [-1, 'M'], [0, 'm']],
    lift: [[-1, 'M'], [-3, 'M'], [0, 'm'], [0, 'm']],
    turn: [[0, 'm'], [-4, 'M'], [-1, 'M'], [0, 'm']],
  },
  breaks: {
    // half-time: kick on one, snare on nine, and a great deal of nothing
    half: ['k.......s.......', '........s.......', 'k.......s.......', 'k...g...s.....g.'],
    step: ['k.....g.s.......', '........s...k...', 'k.....g.s.......', 'k.g.....s...gkg.'],
    // and then it doubles
    full: ['k.hks.hk..hks.h.', 'kghks.h.k.hks.hk', 'k.h.sghk..hks.hk', 'kgh.s.hksghkskgk'],
    intro: ['k...............', '................', 'k.......s.......', '................'],
  },
  drums: {},
  bass: {
    main: [P('0 . . . . . . . . . . . . . . .'), P('0 . . . . . . . -1 . . . . . . .')],
    push: [P('0 . . 0 . . . . 0 . . . . . -1 .'), P('0 . . 0 . . -1 . . . 0 . . . . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    grind: [P('. . . . . . . . 0 . . . . . . .'), P('. . . . 0 . . . . . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . . . . . . 3 . . . . . . .'),
        P('. . . . . . . . 0 . . . . . . .'),
        P('7 . . . . . . . 5 . . . . . . .'),
        P('3 . . . . . . . 0 . . . . . . .')],
    B: [P('12 . . . 11 . . . 12 . . . . . . .'),
        P('8 . . . 7 . . . 5 . . . . . . .'),
        P('15 . . . 12 . . . 11 . . . 12 . . .'),
        P('10 . . . 8 . . . 7 . . . . . . .')],
    C: [P('0 . . . . . . . . . . . . . . .'),
        P('. . . . . . . . 3 . . . . . . .'),
        P('. . . . . . . . . . . . . . . .'),
        P('0 . . . . . . . . . . . . . . .')],
    Bh: [P('19 . . . 18 . . . 19 . . . . . . .'),
         P('15 . . . 14 . . . 12 . . . . . . .'),
         P('22 . . . 19 . . . 18 . . . 19 . . .'),
         P('17 . . . 15 . . . 14 . . . . . . .')],
  },
  arps: { slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', breaks: 'intro', bass: 'soft', keys: 'hold', gain: 0.8 },
    { bars: 4, chords: 'main', breaks: 'half', bass: 'main', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', breaks: 'step', bass: 'main', gtr: 'grind', keys: 'hold', lead: 'A' },
    // it doubles
    { bars: 4, chords: 'lift', breaks: 'full', bass: 'push', gtr: 'grind', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', breaks: 'full', bass: 'push', gtr: 'grind', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'turn', breaks: 'half', bass: 'main', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', breaks: 'full', bass: 'push', gtr: 'grind', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', breaks: 'step', bass: 'main', gtr: 'grind', keys: 'hold', lead: 'A' },
  ],
};

// ---- H4: OVERPASS ---------------------------------------------------------
// The one that is not drum and bass, in case you would rather keep the break
// for a single scene. Big-beat rock at 160: guitars over a breakbeat rather
// than a straight rock kit, so it still moves like the highway.
const S5_ROCK = {
  name: 'Overpass', bpm: 160, key: 53, lkey: 65, swing: 0.06, level: 0.91,
  tone: { freq: 3200, gain: -2 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.34, bright: 2500, close: 330 },
    gtr:  { vol: 0.21, drive: 'hot', tone: 2600 },
    keys: { vol: 0.06, tone: 2300 },
    lead: { vol: 0.34, drive: 'crunch', tone: 3600, send: 0.24, echo: 0.16 },
    harm: { vol: 0.19, drive: 'crunch', tone: 3000, send: 0.18, echo: 0.10 },
    arp:  { vol: 0.055 },
  },
  chords: {
    main: [[0, 'm'], [-2, 'M'], [-4, 'M'], [0, 'm']],
    lift: [[-4, 'M'], [3, 'M'], [-2, 'M'], [0, 'm']],
    turn: [[5, 'm'], [-2, 'M'], [-4, 'M'], [0, 'm']],
  },
  drums: {
    intro: { k: 'X.......X.......', s: '....X.......X...', h: 'x.x.x.x.x.x.x.x.' },
    // a breakbeat rather than a rock beat: the kick moves around
    main: {
      k: ['X.....x...x.....', 'X.......x.x.....'],
      s: ['....X.-.....X...', '....X.......X.-x'],
      h: ['x.x.x.xox.x.x.xo', 'x.xox.x.x.x.x.x.'],
    },
    push: {
      k: ['X.....x...x.x...', 'X...x...x.....x.'],
      s: ['....X.-.-...X..x', '....X..x....X.Xx'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '....o.......o...' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 . 12 . 0 . 0 . . 10 . 7 . 5'), P('0 . . 0 . . 12 . 0 . . 7 . . 10 .')],
    drive: [P('0 . 0 12 . 0 . 7 0 . 0 12 . 10 . 7'), P('0 0 . 12 . 0 10 . 0 . 12 . 10 . 7 .')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 0 . 0 0 . 0 . 3 5'), P('0 . 0 0 . 0 . 0 . 0 . 5 . 3 . 0')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . 3 . 7 . 5 . . 3 . 0 . . .'),
        P('7 . . 8 . 12 . . 10 . . . . . . .'),
        P('0 . . 3 . 7 . 8 . . 10 . 8 . 7 .'),
        P('5 . . . 3 . 0 . . . . . . . . .')],
    B: [P('12 . . 15 . 17 . . 15 . 12 . . . 10 .'),
        P('12 . . 10 . 8 . . 7 . . . . . . .'),
        P('15 . . 17 . 19 . . 20 . 19 . 17 . 15 .'),
        P('12 . . . 15 . . . 12 . . . . . . .')],
    C: [P('0 . . . 3 . . . 7 . . . 5 . . .'),
        P('3 . . . 0 . . . . . . . . . . .'),
        P('7 . . . 8 . . . 12 . . . 8 . . .'),
        P('7 . . . 5 . . . 3 . . . . . . .')],
    Bh: [P('15 . . 19 . 20 . . 19 . 15 . . . 12 .'),
         P('15 . . 12 . 12 . . 10 . . . . . . .'),
         P('19 . . 20 . 22 . . 24 . 22 . 20 . 19 .'),
         P('15 . . . 19 . . . 15 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'hold' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', lead: 'C', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'hold' },
  ],
};

const S5_OPTIONS = { H1: S5_TUNNEL, H2: S5_SUNRISE, H3: S5_DARK, H4: S5_ROCK };
