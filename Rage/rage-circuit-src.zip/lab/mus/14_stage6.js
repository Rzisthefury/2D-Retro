// ============================================================ STAGE 6, final
// F2 ROBOT LINE won, so the whole of Syndicate Works is played by a sequencer.
// That is the one decision, and everything below follows from it: the palette
// does not change between the four tracks - same saw lead, same filtered syn
// bass with its sine sub, same stab keys, same struck metal instead of a ride,
// same guitar kept back for the one thing a machine cannot do. What changes is
// tempo, density and tone, exactly as it has for stages 2 through 5.
//
// THE HOOK, unchanged in all four (degrees above C5):
//     0 3 0 3 | 5 3 5 3 | 7 10 7 10 | 12 10 7 3 0
// A two-note cell that steps up a rung at a time and then falls off the top.
// It is the only melody in the game built from a repeating cell rather than a
// phrase, which is the point - a machine does not phrase.
//
//   6A THE CAST HOUSE   - the line running hot. Same sequencer, and a furnace
//                         breathing underneath it that nothing else has.
//   6B THE LINE         - F2 as you heard it. Level trimmed so the one clipped
//                         sample is gone for real rather than at encode.
//   6C THE TORPEDO YARD - the same sequence at rest. Slow, dark, huge room,
//                         and the metal ringing for over a second.
//   BOSS 6              - Slag. The machine catches fire.
//
// Mix targets set before writing: mid 14-22%, sub under 34%, lead 0.30-0.36,
// bass 0.28-0.36. Stage 6 is meant to be hot rather than heavy, so the bottom
// end stays lighter here than anywhere since stage 1.

// ---- 6A: THE CAST HOUSE ---------------------------------------------------
// A river of molten metal on the floor and ladle cars on rails over it. Faster
// than the line and a good deal hotter, but still on the grid: the kick never
// moves. The heat is in the furnace hiss and the long ring off the scaffold,
// not in a looser feel.
const T_stage6a = {
  name: 'The Cast House', bpm: 152, key: 60, lkey: 72, swing: 0, level: 0.88,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3300, gain: -2 },
  bassVoice: 'syn', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: false },
    clank: { ring: 0.26 }, hiss: { vol: 0.11, f0: 1100, f1: 300 },
    bass: { vol: 0.34, bright: 1900, close: 250, sub: 0.75 },
    gtr:  { vol: 0.17, drive: 'hot', tone: 3000 },
    keys: { vol: 0.065, bright: 4200, wave: 'sawtooth' },
    lead: { vol: 0.32, bright: 4800, send: 0.22, echo: 0.18, wave: 'sawtooth' },
    harm: { vol: 0.15, drive: 'crunch', tone: 3100, send: 0.18, echo: 0.10 },
    arp:  { vol: 0.075, wave: 'triangle', tone: 3900, echo: 0.18 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [3, 'M'], [-2, 'M']],
    lift: [[3, 'M'], [-2, 'M'], [0, 'm'], [0, 'm']],
    turn: [[5, 'm'], [3, 'M'], [-2, 'M'], [0, 'm']],
  },
  drums: {
    intro: { m: 'x...x...x...x...', a: 'X...............', h: 'x.x.x.x.x.x.x.x.' },
    main: {
      k: ['X.......X.......', 'X.......X.......'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'x.x.x.x.x.x.x.x.',
      m: ['..x...x...x...x.', '..x...x...x...x.'],
      a: ['................', 'x...............'],
    },
    push: {
      k: ['X...X...X...X...', 'X...X...X...X...'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'xxxxxxxxxxxxxxxx',
      m: ['x.x.x.x.x.x.x.x.', 'x.x.x.x.x.x.x.x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X.......X.......', m: '....x.......x...', a: '........X.......' },
    fill: { k: 'X...X...X...X...', s: '....X...X...X.XX', m: 'x.x.x.x.x.x.xxxx' },
  },
  bass: {
    main: [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . 0 .'), P('0 . 0 . 0 . 0 . 0 . 0 . 10 . 10 .')],
    step: [P('0 . 0 . 3 . 3 . 5 . 5 . 7 . 7 .'), P('0 . 0 . 10 . 10 . 7 . 7 . 5 . 3 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    // the bend, same as the line - it is the only human thing in the works
    human: [P('. . . . . . . . 0 . . . . . 3 .'), P('. . . . . . . . 3 . . . . . 0 .')],
    riff: [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . 0 .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    pulse: [P('0 . . . 0 . . . 0 . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('0 . 3 . 0 . 3 . 0 . 3 . 0 . 3 .'),
        P('5 . 3 . 5 . 3 . 5 . 3 . 5 . 3 .'),
        P('7 . 10 . 7 . 10 . 7 . 10 . 7 . 10 .'),
        P('12 . 10 . 7 . 3 . 0 . . . . . . .')],
    B: [P('19 . 17 . 19 . 22 . 19 . . . 17 . . .'),
        P('15 . 17 . 15 . 12 . 10 . . . . . . .'),
        P('19 . 22 . 24 . 22 . 19 . 17 . 19 . . .'),
        P('17 . 15 . 12 . . . . . . . . . . .')],
    C: [P('0 . . . 3 . . . 0 . . . 3 . . .'),
        P('5 . . . 3 . . . 5 . . . 3 . . .'),
        P('7 . . . 10 . . . 7 . . . 10 . . .'),
        P('3 . . . 0 . . . . . . . . . . .')],
    Bh: [P('15 . 12 . 15 . 17 . 15 . . . 12 . . .'),
         P('12 . 12 . 10 . 7 . 5 . . . . . . .'),
         P('15 . 17 . 19 . 17 . 15 . 12 . 15 . . .'),
         P('12 . 10 . 7 . . . . . . . . . . .')],
  },
  arps: {
    seq:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.82 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', keys: 'pulse', arp: 'seq' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'step', keys: 'pulse', arp: 'seq', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'step', gtr: 'human', keys: 'pulse', arp: 'seq', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'step', gtr: 'riff', keys: 'pulse', arp: 'seq', lead: 'B' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'step', keys: 'pulse' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'step', gtr: 'riff', keys: 'pulse', arp: 'seq', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'human', keys: 'pulse', arp: 'seq', lead: 'A' },
  ],
};

// ---- 6B: THE LINE ---------------------------------------------------------
// F2 exactly as it played in the picker, with one fix: at level 0.92 it clipped
// a single sample, which I covered with 0.3dB at encode. 0.88 removes it from
// the render instead, which is where it should have been removed.
const T_stage6b = {
  name: 'The Line', bpm: 144, key: 60, lkey: 72, swing: 0, level: 0.88,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3300, gain: -2.5 },
  bassVoice: 'syn', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: false },
    clank: { ring: 0.07 },
    bass: { vol: 0.38, bright: 1700, close: 230 },
    gtr:  { vol: 0.16, drive: 'hot', tone: 3000 },
    keys: { vol: 0.065, bright: 4000, wave: 'sawtooth' },
    lead: { vol: 0.30, bright: 4600, send: 0.24, echo: 0.22, wave: 'sawtooth' },
    harm: { vol: 0.14, drive: 'crunch', tone: 3000, send: 0.20, echo: 0.12 },
    arp:  { vol: 0.075, wave: 'triangle', tone: 3800, echo: 0.20 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [3, 'M'], [-2, 'M']],
    lift: [[3, 'M'], [-2, 'M'], [0, 'm'], [0, 'm']],
    turn: [[5, 'm'], [3, 'M'], [-2, 'M'], [0, 'm']],
  },
  drums: {
    intro: { m: 'x...x...x...x...', h: 'x.x.x.x.x.x.x.x.' },
    main: {
      k: ['X.......X.......', 'X.......X.......'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'x.x.x.x.x.x.x.x.',
      m: ['..x...x...x...x.', '..x...x...x...x.'],
    },
    push: {
      k: ['X...X...X...X...', 'X...X...X...X...'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'xxxxxxxxxxxxxxxx',
      m: ['x.x.x.x.x.x.x.x.', 'x.x.x.x.x.x.x.x.'],
    },
    half: { k: 'X.......X.......', m: '....x.......x...' },
    fill: { k: 'X...X...X...X...', s: '....X...X...X.XX', m: 'x.x.x.x.x.x.xxxx' },
  },
  bass: {
    main: [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . 0 .'), P('0 . 0 . 0 . 0 . 0 . 0 . 10 . 10 .')],
    step: [P('0 . 0 . 3 . 3 . 5 . 5 . 7 . 7 .'), P('0 . 0 . 10 . 10 . 7 . 7 . 5 . 3 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    human: [P('. . . . . . . . 0 . . . . . 3 .'), P('. . . . . . . . 3 . . . . . 0 .')],
    riff: [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . 0 .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    pulse: [P('0 . . . 0 . . . 0 . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('0 . 3 . 0 . 3 . 0 . 3 . 0 . 3 .'),
        P('5 . 3 . 5 . 3 . 5 . 3 . 5 . 3 .'),
        P('7 . 10 . 7 . 10 . 7 . 10 . 7 . 10 .'),
        P('12 . 10 . 7 . 3 . 0 . . . . . . .')],
    B: [P('19 . 17 . 19 . 22 . 19 . . . 17 . . .'),
        P('15 . 17 . 15 . 12 . 10 . . . . . . .'),
        P('19 . 22 . 24 . 22 . 19 . 17 . 19 . . .'),
        P('17 . 15 . 12 . . . . . . . . . . .')],
    C: [P('0 . . . 3 . . . 0 . . . 3 . . .'),
        P('5 . . . 3 . . . 5 . . . 3 . . .'),
        P('7 . . . 10 . . . 7 . . . 10 . . .'),
        P('3 . . . 0 . . . . . . . . . . .')],
    Bh: [P('15 . 12 . 15 . 17 . 15 . . . 12 . . .'),
         P('12 . 12 . 10 . 7 . 5 . . . . . . .'),
         P('15 . 17 . 19 . 17 . 15 . 12 . 15 . . .'),
         P('12 . 10 . 7 . . . . . . . . . . .')],
  },
  arps: {
    seq:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.82 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', keys: 'pulse', arp: 'seq' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'step', keys: 'pulse', arp: 'seq', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'step', gtr: 'human', keys: 'pulse', arp: 'seq', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'step', gtr: 'human', keys: 'pulse', arp: 'seq', lead: 'B' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'step', keys: 'pulse' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'step', gtr: 'human', keys: 'pulse', arp: 'seq', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', keys: 'pulse', arp: 'seq', lead: 'A' },
  ],
};

// ---- 6C: THE TORPEDO YARD -------------------------------------------------
// Ladle vessels the size of houses, in the dark, glowing at the ends. The
// sequence is still running - it never stops in this building - but down here
// it is two rungs of the ladder every other bar instead of eight. Slow, long
// room, metal ringing for well over a second. The bass sub is pulled back to
// 0.6 deliberately: this is the biggest-sounding room in the game and the
// temptation is to fill it from the bottom, which buries the tune every time.
const T_stage6c = {
  name: 'The Torpedo Yard', bpm: 116, key: 60, lkey: 72, swing: 0, echo: 1.5, level: 0.90,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3200, gain: -4 },
  bassVoice: 'syn', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    clank: { ring: 1.1 }, hiss: { vol: 0.12, f0: 900, f1: 240 },
    // First pass here pulled the sub back to 0.6 and pushed the lead to 0.34,
    // on the theory that a big room wants filling from the top rather than the
    // bottom. It came out the BRIGHTEST track on the stage - 23% mid against
    // the line's 15% - which is exactly backwards for the darkest room in the
    // building, and it walked the palette away from what was picked. The bass
    // sits where the line's does now and the lead is quieter than anywhere
    // else on the stage, because down here it has the whole bar to itself.
    bass: { vol: 0.38, bright: 1600, close: 225, sub: 0.9 },
    gtr:  { vol: 0.14, drive: 'crunch', tone: 3200, send: 0.24, echo: 0.20 },
    keys: { vol: 0.06, bright: 3600, wave: 'sawtooth' },
    lead: { vol: 0.28, bright: 4200, send: 0.34, echo: 0.26, wave: 'sawtooth' },
    harm: { vol: 0.12, drive: 'crunch', tone: 3000, send: 0.30, echo: 0.20 },
    arp:  { vol: 0.065, wave: 'triangle', tone: 3600, echo: 0.30 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [3, 'M'], [-2, 'M']],
    lift: [[3, 'M'], [-2, 'M'], [0, 'm'], [0, 'm']],
    turn: [[5, 'm'], [3, 'M'], [-2, 'M'], [0, 'm']],
  },
  drums: {
    intro: { a: 'X...............', m: '........x.......' },
    main: {
      k: ['X.......X.......', 'X.......X.......'],
      s: ['............X...', '............X...'],
      h: ['..x...x...x...x.', '..x...x...x...x.'],
      m: ['....x...........', '....x.......x...'],
      a: ['................', 'x...............'],
    },
    push: {
      k: ['X.......X.......', 'X.......X.......'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'x.x.x.x.x.x.x.x.',
      m: ['....x.......x...', '....x.......x...'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', m: '........x.......', a: '........x.......' },
    fill: { k: 'X.......X.......', s: '....X.......X.XX', m: 'x...x...x...x...' },
  },
  bass: {
    main: [P('0 . . . 0 . . . 0 . . . 0 . . .'), P('0 . . . 0 . . . 0 . . . 10 . . .')],
    step: [P('0 . . . 0 . . . 3 . . . 3 . . .'), P('0 . . . 0 . . . 10 . . . 7 . . .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    human: [P('. . . . . . . . 0 . . . . . 3 .'), P('. . . . . . . . 3 . . . . . 0 .')],
    grind: [P('. . . . 0 . . . . . . . 0 . . .'), P('. . . . 0 . . . 0 . . . . . 0 .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    pulse: [P('0 . . . . . . . 0 . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    // The same ladder, one rung per half bar - but offset two sixteenths, so
    // every note arrives behind the kick instead of on it. Not a human dragging:
    // a sequencer whose start point is set late, which is what a building this
    // size does to anything running through it. It also keeps the yard clear of
    // the rooftops in stage 1 - on the beat this shape landed half its notes in
    // the same slots as that tune, and off the beat it shares none of them.
    A: [P('. . 0 . . . 3 . . . 0 . . . 3 .'),
        P('. . 5 . . . 3 . . . 5 . . . 3 .'),
        P('. . 7 . . . 10 . . . 7 . . . 10 .'),
        P('. . 12 . . . 10 . . 7 . . 3 . 0 .')],
    B: [P('. . 19 . . . 17 . . . 19 . 22 . 19 .'),
        P('. . 15 . . . 17 . . . 15 . 12 . 10 .'),
        P('. . 19 . . . 22 . . . 24 . 22 . 19 .'),
        P('. . 17 . . . 15 . . . 12 . . . . .')],
    C: [P('. . 0 . . . . . . . 3 . . . . .'),
        P('. . 5 . . . . . . . 3 . . . . .'),
        P('. . 7 . . . . . . . 10 . . . . .'),
        P('. . 3 . . . . . . . 0 . . . . .')],
    Bh: [P('. . 15 . . . 12 . . . 15 . 17 . 15 .'),
         P('. . 12 . . . 12 . . . 10 . 7 . 5 .'),
         P('. . 15 . . . 17 . . . 19 . 17 . 15 .'),
         P('. . 12 . . . 10 . . . 7 . . . . .')],
  },
  arps: {
    seq:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', keys: 'pulse', arp: 'slow' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'step', keys: 'pulse', arp: 'seq', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'step', gtr: 'grind', keys: 'pulse', arp: 'seq', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'step', gtr: 'grind', keys: 'pulse', arp: 'seq', lead: 'B' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'step', keys: 'pulse' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'step', gtr: 'human', keys: 'pulse', arp: 'seq', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'grind', keys: 'pulse', arp: 'seq', lead: 'A' },
  ],
};

// ---- BOSS 6: SLAG ---------------------------------------------------------
// Everything he touches catches fire, and his slam leaves pools of it burning
// on the floor. So this is the line with the fire in it: the furnace hiss stops
// being a background swell and starts landing on beats, the guitar comes
// forward with the hot drive it has been holding back all stage, and the metal
// gets hit twice as often. The sequence itself does not panic - it is still
// dead on the grid, still the same ladder - because the machine is not the one
// who is angry. It just keeps running while he burns.
const T_boss6 = {
  name: 'Slag', bpm: 150, key: 60, lkey: 72, swing: 0, level: 0.84,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3300, gain: -2.5 },
  bassVoice: 'syn', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    // The metal was a cowbell solo. Three things were wrong with it and all
    // three are fixed here: 520Hz is where a cowbell lives, so it drops to 300
    // and reads as a plate; a 0.35s ring on sixteenths piles every hit on top
    // of the last two, so it drops to 0.10; and it was at full velocity, so it
    // comes down to 0.45. The fire is carried by the hiss now, which is what
    // should have been burning all along.
    clank: { ring: 0.10, pitch: 300, vol: 0.45 },
    hiss: { vol: 0.19, f0: 1600, f1: 340, dur: 0.6 },
    bass: { vol: 0.34, bright: 1600, close: 220, sub: 0.8 },
    gtr:  { vol: 0.21, drive: 'hot', tone: 2800 },
    keys: { vol: 0.06, bright: 3800, wave: 'sawtooth' },
    lead: { vol: 0.32, bright: 5000, send: 0.22, echo: 0.18, wave: 'sawtooth' },
    harm: { vol: 0.21, drive: 'hot', tone: 3100, wide: true, send: 0.20, echo: 0.10 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3800, echo: 0.18 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [3, 'M'], [-2, 'M']],
    // the fire chords: fifths with no third in them at all
    hard: [[0, '5'], [0, '5'], [3, '5'], [-1, '5']],
    turn: [[5, 'm'], [3, 'M'], [-2, 'M'], [0, 'm']],
  },
  drums: {
    intro: { k: 'X...............', a: 'X.......x.......', m: '........x.......' },
    main: {
      k: ['X.......X.......', 'X.......X.......'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'x.x.x.x.x.x.x.x.',
      m: ['....o.......x...', '....o.......x...'],
      a: ['........x.......', 'x.......x.......'],
    },
    burn: {
      k: ['X...X...X...X...', 'X...X...X...X...'],
      s: ['....X.......X...', '....X.......X..X'],
      h: 'xxxxxxxxxxxxxxxx',
      // was every sixteenth. Now the plate lands on the half bar and once
      // between, so it punctuates the fire instead of playing over it.
      m: ['o.......x.......', 'o.......x...o...'],
      a: ['X...x...X...x...', 'X...x...X.x.x...'],
      c: ['X...............', '................'],
    },
    half: { k: 'X.......X.......', m: '....x.......x...', a: '........X.......' },
    fill: { k: 'X...X...X...X...', s: '....X...X...X.XX', m: 'o.......o...o...', a: 'X.......x...x...' },
  },
  bass: {
    main: [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . 0 .'), P('0 . 0 . 0 . 0 . 0 . 0 . -1 . -1 .')],
    step: [P('0 . 0 . 3 . 3 . 5 . 5 . 7 . 7 .'), P('0 . 0 . 10 . 10 . 7 . 7 . 3 . -1 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    // it stops holding back. The chug is on every eighth from here on.
    burn: [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . 0 .'), P('0 . 0 . 0 . 0 . 0 . 0 . 0 . -1 .')],
    human: [P('. . . . . . . . 0 . . . . . 3 .'), P('. . . . . . . . 3 . . . . . 0 .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    pulse: [P('0 . . . 0 . . . 0 . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    // his theme is the works' theme, note for note. The machine does not care
    // which of you wins.
    A: [P('0 . 3 . 0 . 3 . 0 . 3 . 0 . 3 .'),
        P('5 . 3 . 5 . 3 . 5 . 3 . 5 . 3 .'),
        P('7 . 10 . 7 . 10 . 7 . 10 . 7 . 10 .'),
        P('12 . 10 . 7 . 3 . 0 . . . . . . .')],
    B: [P('19 . 17 . 19 . 22 . 19 . . . 17 . . .'),
        P('15 . 17 . 15 . 12 . 10 . . . . . . .'),
        P('19 . 22 . 24 . 22 . 19 . 17 . 19 . . .'),
        P('17 . 15 . 12 . . . . . . . . . . .')],
    C: [P('0 . . . 3 . . . 0 . . . 3 . . .'),
        P('5 . . . 3 . . . 5 . . . 3 . . .'),
        P('7 . . . 10 . . . 7 . . . 10 . . .'),
        P('3 . . . 0 . . . . . . . . . . .')],
    // the guitar is the part of him that is on fire
    Bh: [P('12 . 15 . 12 . 15 . 12 . 15 . 12 . 15 .'),
         P('17 . 15 . 17 . 15 . 17 . 15 . 17 . 15 .'),
         P('19 . 22 . 19 . 22 . 19 . 22 . 19 . 22 .'),
         P('24 . 22 . 19 . 15 . 12 . . . -1 . . .')],
  },
  arps: {
    seq:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 2, chords: 'hard', drums: 'intro', bass: 'soft', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'burn', keys: 'pulse', arp: 'seq' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'step', gtr: 'burn', keys: 'pulse', arp: 'seq', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'hard', drums: 'burn', bass: 'step', gtr: 'burn', keys: 'pulse', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'burn', bass: 'step', gtr: 'burn', keys: 'pulse', arp: 'seq', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'hard', drums: 'fill', bass: 'step', gtr: 'burn' },
    // two bars where the fire is out and the conveyor is all that is left
    { bars: 2, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'hard', drums: 'burn', bass: 'step', gtr: 'burn', keys: 'pulse', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'human', keys: 'pulse', arp: 'seq', lead: 'A', harm: 'Bh' },
  ],
};

const STAGE6_TRACKS = { S6A: T_stage6a, S6B: T_stage6b, S6C: T_stage6c, B6: T_boss6 };
