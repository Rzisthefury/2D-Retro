// ============================================================ STAGE 2, final
// One theme, three arrangements - the model stage 1 settled on.
//
//   THE HOOK, in degrees above the lead key (G4):
//     7 5 7 10 12 | 10 7 5 | 7 10 12 14 12 | 10 7 5
//
//   2A NEON CANYON - N1 as you heard it. Synths over a wet street.
//   2B THE BASEMENT - the same tune coming out of the PA stacks on the
//                     loading dock. Opens muffled with only the kick through
//                     the wall, and opens up as the doors do.
//   BOSS 2         - Ruby and Onyx are twins, so two leads trade the hook
//                    between them rather than one playing it.

// ---- 2A: NEON CANYON ------------------------------------------------------
const T_stage2a = {
  name: 'Neon Canyon', bpm: 128, key: 55, lkey: 67, swing: 0, echo: 1.5, level: 0.94,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3400, gain: -1.5 },
  bassVoice: 'syn', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    bass: { vol: 0.36, bright: 1400, close: 210, sub: 1.0 },
    gtr:  { vol: 0.14, tone: 4400, send: 0.42, echo: 0.34 },
    keys: { vol: 0.10, open: true, att: 0.6 },
    lead: { vol: 0.23, bright: 5800, send: 0.32, echo: 0.30, wave: 'sawtooth' },
    harm: { vol: 0.15, drive: 'crunch', tone: 3200, send: 0.30, echo: 0.20 },
    arp:  { vol: 0.105, wave: 'triangle', tone: 4000, echo: 0.36 },
  },
  chords: {
    main: [[0, 'm'], [-4, 'M'], [3, 'M'], [-2, 'M']],
    lift: [[3, 'M'], [-2, 'M'], [0, 'm'], [-4, 'M']],
    turn: [[5, 'm'], [3, 'M'], [-4, 'M'], [-2, 'M']],
  },
  drums: {
    intro: { k: 'X.......X.......', h: '..x...x...x...x.' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...xo', '..x...x...x...x.'],
    },
    push: {
      k: ['X.......X.......', 'X...x...X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '............o...' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . 0 . . . 0 . . . 0 . 0 .'), P('0 . . . 0 . . . 0 . . 0 . 0 . 0')],
    oct:  [P('0 . 12 . 0 . 12 . 0 . 12 . 0 . 12 .'), P('0 . 12 . 0 . 12 . 0 . 12 . 10 . 7 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    answer: [P('. . . . . . . . 7 . 5 . . . 3 .'), P('. . . . . . . . 5 . 3 . . . 0 .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('7 . . . 5 . 7 . . . 10 . . . 12 .'),
        P('10 . . . 7 . . . 5 . . . . . . .'),
        P('7 . . . 10 . 12 . . . 14 . . . 12 .'),
        P('10 . . . 7 . 5 . . . . . . . . .')],
    B: [P('15 . . 14 . 12 . . 14 . . . 15 . . .'),
        P('12 . . 10 . 12 . . 7 . . . . . . .'),
        P('15 . . 17 . 19 . . 17 . . . 15 . 14 .'),
        P('12 . . . 14 . . . 10 . . . . . . .')],
    C: [P('0 . . . . . 3 . . . 7 . . . . .'),
        P('5 . . . . . 3 . . . 0 . . . . .'),
        P('7 . . . . . 10 . . . 12 . . . . .'),
        P('10 . . . . . 7 . . . . . . . . .')],
    Bh: [P('7 . . 5 . 3 . . 5 . . . 7 . . .'),
         P('3 . . 2 . 3 . . 0 . . . . . . .'),
         P('7 . . 10 . 12 . . 10 . . . 7 . 5 .'),
         P('3 . . . 5 . . . 2 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'oct', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'B' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'oct', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- 2B: THE BASEMENT -----------------------------------------------------
// The same tune, but you are behind the club now, standing in front of the
// stacks. It starts as the canyon theme heard through a wall - kick only, sub
// bass, everything above 2.8k taken off - and the doors open in stages.
const T_stage2b = {
  name: 'The Basement', bpm: 124, key: 55, lkey: 67, swing: 0, level: 0.82,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 2800, gain: -2 },
  bassVoice: 'sub', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.33, harm: 0.22 },
    gtr:  { vol: 0.16, tone: 4000, send: 0.40, echo: 0.26 },
    keys: { vol: 0.095, open: false, att: 0.7 },
    lead: { vol: 0.30, bright: 4400, send: 0.34, echo: 0.24, wave: 'sawtooth' },
    harm: { vol: 0.21, drive: 'crunch', tone: 3200, send: 0.26, echo: 0.14 },
    arp:  { vol: 0.10, wave: 'triangle', tone: 3400, echo: 0.34 },
  },
  chords: {
    main: [[0, 'm7'], [-4, 'M'], [3, 'M7'], [-2, 'M']],
    lift: [[3, 'M7'], [-2, 'M'], [0, 'm7'], [-4, 'M']],
    turn: [[5, 'm7'], [3, 'M7'], [-4, 'M'], [-2, 'M']],
  },
  drums: {
    muf:  { k: 'X...X...X...X...', h: '................' },
    main: { k: ['X...X...X...X...', 'X...X...X...X..x'],
            s: ['....-.......-...', '....-.......-..-'],
            h: ['..x...x...x...x.', '..x...x...x...xo'] },
    open: { k: ['X...X...X...X...', 'X...X...X.x.X...'],
            s: ['....X.......X...', '....X.......X..x'],
            h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'] },
    half: { k: 'X.......X.......', s: '........-.......', h: '............o...' },
    fill: { k: 'X...X...x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    four: [P('0 . . . 0 . . . 0 . . . 0 . . .'), P('0 . . . 0 . . . 0 . . . 0 . 10 .')],
    roll: [P('0 . . 0 . . 0 . 0 . . 0 . 10 . 7'), P('0 . . 0 . 0 . . 0 . . 10 . 7 . 5')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    stab: [P('. . . . 0 . . . . . . . 0 . . .'), P('. . . . 0 . . . 0 . . . . . . .')],
    chug: [P('0 . 0 0 . 0 . 0 . 0 0 . 0 . 3 5')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // THE HOOK - the canyon's A phrase, note for note, slowed by the tempo
    A: [P('7 . . . 5 . 7 . . . 10 . . . 12 .'),
        P('10 . . . 7 . . . 5 . . . . . . .'),
        P('7 . . . 10 . 12 . . . 14 . . . 12 .'),
        P('10 . . . 7 . 5 . . . . . . . . .')],
    // the canyon's chorus, held longer - there is more room down here
    B: [P('15 . . . 14 . 12 . 14 . . . 15 . . .'),
        P('12 . . . 10 . 12 . 7 . . . . . . .'),
        P('15 . . . 17 . 19 . 17 . . . 15 . 14 .'),
        P('12 . . . 14 . . . 10 . . . . . . .')],
    // through the wall: only the strong beats of the hook get through
    C: [P('7 . . . . . . . . . . . . . . .'),
        P('10 . . . . . . . 5 . . . . . . .'),
        P('7 . . . . . . . 12 . . . . . . .'),
        P('10 . . . . . . . . . . . . . . .')],
    // the guitar under the synth, an octave down
    Ag: [P('-5 . . . -7 . -5 . . . -2 . . . 0 .'),
         P('-2 . . . -5 . . . -7 . . . . . . .'),
         P('-5 . . . -2 . 0 . . . 2 . . . 0 .'),
         P('-2 . . . -5 . -7 . . . . . . . . .')],
    Bh: [P('7 . . . 10 . 8 . 7 . . . 5 . . .'),
         P('7 . . . 5 . 3 . 0 . . . . . . .'),
         P('10 . . . 12 . 14 . 12 . . . 10 . . .'),
         P('8 . . . 7 . 5 . 7 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    // through the wall: the hook is in there, but only the strong beats of it
    { bars: 4, chords: 'main', drums: 'muf', bass: 'four', keys: 'hold', lead: 'C', gain: 0.74 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'four', keys: 'hold', arp: 'slow', gain: 0.88 },
    // the doors open and it is plainly the canyon theme
    { bars: 4, chords: 'main', drums: 'main', bass: 'roll', keys: 'hold', arp: 'run', lead: 'A', harm: 'Ag', harmStyle: 'clean' },
    { bars: 4, chords: 'lift', drums: 'open', bass: 'roll', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'open', bass: 'roll', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'B' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'roll', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'four', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.74 },
    // the run-up to the twins: the guitar takes it, same as the rooftops did
    { bars: 4, chords: 'main', drums: 'open', bass: 'roll', gtr: 'chug', gtrStyle: 'chug',
      keys: 'hold', arp: 'run', lead: 'A', leadStyle: 'lead' },
    { bars: 4, chords: 'lift', drums: 'open', bass: 'roll', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
  ],
};

// ---- BOSS 2: RUBY & ONYX -------------------------------------------------
// There are two of them and they never attack at the same time - one cartwheels
// in while the other flips out. So the theme is two leads trading the hook a
// bar at a time rather than one playing it, and they only land together in the
// chorus. 160bpm, and the arpeggio keeps it belonging to stage 2.
const T_boss2 = {
  name: 'Ruby & Onyx', bpm: 160, key: 55, lkey: 67, swing: 0.04, level: 0.92,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3100, gain: -3 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'stab',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.32, bright: 2700, close: 360 },
    gtr:  { vol: 0.19, drive: 'hot', tone: 3000 },
    keys: { vol: 0.06, tone: 2300, bars: [[1, 1], [2, 0.7], [3, 0.4], [4, 0.2]] },
    lead: { vol: 0.36, drive: 'hot', tone: 3500, wide: true, send: 0.20, echo: 0.12 },
    harm: { vol: 0.28, bright: 5200, send: 0.26, echo: 0.20, wave: 'sawtooth' },
    arp:  { vol: 0.08, wave: 'triangle', tone: 3800, echo: 0.26 },
  },
  chords: {
    main: [[0, 'm'], [3, 'M'], [-2, 'M'], [-5, 'M']],
    hard: [[0, '5'], [-2, '5'], [3, '5'], [-5, 'M']],
    turn: [[5, 'm'], [3, 'M'], [0, 'm'], [0, 'm']],
  },
  drums: {
    intro: { k: 'X..x....X.......', s: '............X...', h: 'xxxxxxxxxxxxxxxx', c: 'X...............' },
    main: {
      k: ['X..x....X...x...', 'X..x..x.X.......'],
      s: ['....X.-.....X...', '....X.......X.-x'],
      h: ['x.x.x.x.x.x.x.x.', 'x.xox.x.x.x.x.xo'],
    },
    push: {
      k: ['X..x..x.X..x....', 'X..x....X..x..x.'],
      s: ['....X.-.-...X..x', '....X..x....X.Xx'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    half: { k: 'X.......x.......', s: '........X.......', t: '............x.o-' },
    fill: { k: 'X.......x...x...', s: '....X..xX.x.X.Xx', t: '..........o.-.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 12 . 0 . 10 0 . 0 12 . 7 . 5'), P('0 . 0 12 . 0 10 . 0 . 12 . 10 7 5 3')],
    grind: [P('0 0 . 0 12 . 0 0 . 12 . 0 10 . 7 .'), P('0 . 12 0 . 10 . 0 0 . 0 12 . 10 . 7')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 5 . 3 .'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 7 . 5')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    stab: [P('. . . 0 . . 0 . . . . 0 . . . .'), P('. . 0 . . . . 0 . . 0 . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    // RUBY takes bars 1 and 3 and is silent through 2 and 4
    A: [P('7 . 5 . 7 . 10 . 12 . 10 . 7 . 5 .'),
        P('. . . . . . . . . . . . . . . .'),
        P('7 . 10 . 12 . 14 . 12 . 10 . 7 . . .'),
        P('. . . . . . . . . . . . . . . .')],
    // ONYX answers in the bars Ruby leaves empty, a fourth up
    Ao: [P('. . . . . . . . . . . . . . . .'),
         P('12 . 10 . 12 . 15 . 17 . 15 . 12 . 10 .'),
         P('. . . . . . . . . . . . . . . .'),
         P('14 . 12 . 10 . 12 . 15 . . . 12 . 10 .')],
    // the chorus is the only place they play together
    B: [P('15 . . 14 . 12 . . 14 . . . 15 . . .'),
        P('12 . . 10 . 12 . . 7 . . . . . . .'),
        P('15 . . 17 . 19 . . 17 . . . 15 . 14 .'),
        P('12 . . . 14 . . . 10 . . . . . . .')],
    Bo: [P('19 . . 17 . 15 . . 17 . . . 19 . . .'),
         P('15 . . 14 . 15 . . 12 . . . . . . .'),
         P('19 . . 22 . 24 . . 22 . . . 19 . 17 .'),
         P('15 . . . 17 . . . 14 . . . . . . .')],
  },
  arps: { run: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 2, chords: 'hard', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', arp: 'run', keys: 'stab' },
    // the twins start trading
    { bars: 4, chords: 'main', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'A', harm: 'Ao', arp: 'run', keys: 'stab' },
    { bars: 4, chords: 'hard', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'A', harm: 'Ao', keys: 'stab' },
    // and land together
    { bars: 4, chords: 'main', drums: 'push', bass: 'grind', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bo', arp: 'run' },
    { bars: 1, chords: 'hard', drums: 'fill', bass: 'grind', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 2, chords: 'turn', drums: 'main', bass: 'main', gtr: 'riff', arp: 'run', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'hard', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'B', harm: 'Bo', keys: 'stab' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', harm: 'Ao', arp: 'run', keys: 'stab' },
  ],
};

const STAGE2_TRACKS = { S2A: T_stage2a, S2B: T_stage2b, B2: T_boss2 };
