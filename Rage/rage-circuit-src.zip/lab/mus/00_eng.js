// ============================================================ THE BAND
// Everything here is generated at runtime - the game ships as one HTML file
// with no audio assets, so every instrument is oscillators, filters and
// shaped noise. The goal is a synthesized ROCK BAND rather than a chiptune:
// an overdriven guitar carrying tunes, keys underneath, and a kit that swings
// instead of marching.
let AC = null, master = null, musBus = null, sfxBus = null;
let noiseBuf = null, verb = null, verbSend = null, dly = null, dlySend = null;
let SHAPE_SOFT = null, SHAPE_HOT = null, SHAPE_FUZZ = null, toneShelf = null;

// ---- distortion ----------------------------------------------------------
// A waveshaper curve is what turns a sawtooth into a guitar. `k` is the drive:
// low is a valve amp on the edge of breakup, high is a fuzz pedal.
function makeCurve(k, n = 2048) {
  const c = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = (i * 2) / n - 1;
    c[i] = ((1 + k) * x) / (1 + k * Math.abs(x));      // classic soft-clip
  }
  return c;
}
// A short exponential noise burst makes a serviceable room. Two of them either
// side of centre gives it width without needing a real impulse response.
function makeVerbIR(seconds = 1.15, decay = 2.4) {
  const n = Math.floor(AC.sampleRate * seconds);
  const buf = AC.createBuffer(2, n, AC.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    for (let i = 0; i < n; i++) {
      const env = Math.pow(1 - i / n, decay);
      d[i] = (Math.random() * 2 - 1) * env * (i < 40 ? i / 40 : 1);
    }
  }
  return buf;
}
// A master soft limiter. The chain used to run the bus compressor straight into
// the output, which left nothing catching a peak: several tracks sit at 0.97-0.98
// and the loop seam - the last bar's ring meeting a full section as the form
// comes round - is enough to tip one over full scale. Rather than trimming every
// track's level (which would make the music quieter, the opposite of what is
// wanted) this leaves everything under 0.9 completely untouched and only bends
// the top, with a hard ceiling it cannot cross.
function makeLimiter() {
  const N = 8192, c = new Float32Array(N);
  const KNEE = 0.9, CEIL = 0.995, SPAN = CEIL - KNEE;
  for (let i = 0; i < N; i++) {
    const x = (i / (N - 1)) * 2 - 1, a = Math.abs(x);
    const y = a <= KNEE ? a : KNEE + SPAN * Math.tanh((a - KNEE) / SPAN);
    c[i] = x < 0 ? -y : y;
  }
  const ws = AC.createWaveShaper();
  ws.curve = c; ws.oversample = '4x';
  return ws;
}
function initBand(ctx) {
  AC = ctx;
  master = AC.createGain(); master.gain.value = 0.68;
  const lim = makeLimiter();
  master.connect(lim); lim.connect(AC.destination);
  musBus = AC.createGain(); musBus.gain.value = 0.9;
  sfxBus = AC.createGain(); sfxBus.gain.value = 1.0;
  // a gentle bus compressor stops the guitar burying the drums on loud bars
  const comp = AC.createDynamicsCompressor();
  comp.threshold.value = -18; comp.knee.value = 26; comp.ratio.value = 4.0;
  comp.attack.value = 0.006; comp.release.value = 0.18;
  // A per-song tone control on the music bus. Some arrangements put a voice
  // up where it bites - a harmony guitar at C7, say - and the fix belongs on
  // the whole track rather than on one instrument, which would change the
  // balance between them.
  toneShelf = AC.createBiquadFilter();
  toneShelf.type = 'highshelf'; toneShelf.frequency.value = 3200; toneShelf.gain.value = 0;
  musBus.connect(toneShelf); toneShelf.connect(comp); comp.connect(master); sfxBus.connect(master);

  const n = AC.sampleRate * 2;
  noiseBuf = AC.createBuffer(1, n, AC.sampleRate);
  const nd = noiseBuf.getChannelData(0);
  for (let i = 0; i < n; i++) nd[i] = Math.random() * 2 - 1;

  SHAPE_SOFT = makeCurve(6); SHAPE_HOT = makeCurve(28); SHAPE_FUZZ = makeCurve(90);

  verb = AC.createConvolver(); verb.buffer = makeVerbIR();
  verbSend = AC.createGain(); verbSend.gain.value = 0.26;
  const verbTone = AC.createBiquadFilter();            // keep the tail off the low end
  verbTone.type = 'highpass'; verbTone.frequency.value = 420;
  verbSend.connect(verb); verb.connect(verbTone); verbTone.connect(musBus);

  dly = AC.createDelay(1.2);
  const fb = AC.createGain(); fb.gain.value = 0.32;
  const dlyTone = AC.createBiquadFilter(); dlyTone.type = 'lowpass'; dlyTone.frequency.value = 2600;
  dlySend = AC.createGain(); dlySend.gain.value = 0.18;
  dlySend.connect(dly); dly.connect(dlyTone); dlyTone.connect(fb); fb.connect(dly); dlyTone.connect(musBus);
  return { master, musBus, sfxBus };
}
function setDelayTime(sec) { if (dly) dly.delayTime.value = Math.min(1.2, sec); }
// dB above `freq`; 0 leaves the track alone.
function setTone(freq, gainDb) {
  if (!toneShelf) return;
  toneShelf.frequency.value = freq || 3200;
  toneShelf.gain.value = gainDb || 0;
}
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);

// A voice's output chain: gain -> [dry to bus] + [sends]. `send` is reverb
// amount 0..1, `echo` is delay amount 0..1.
function outChain(g, send = 0, echo = 0, bus = null) {
  g.connect(bus || musBus);
  if (send > 0) { const s = AC.createGain(); s.gain.value = send; g.connect(s); s.connect(verbSend); }
  if (echo > 0) { const e = AC.createGain(); e.gain.value = echo; g.connect(e); e.connect(dlySend); }
}
// An ADSR-ish gain, expressed in seconds. Exponential ramps only - linear
// ramps to zero click on most browsers.
function adsr(t, dur, peak, a = 0.005, d = 0.06, s = 0.6, r = 0.12) {
  const g = AC.createGain();
  const sus = Math.max(0.0001, peak * s);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t + a);
  g.gain.exponentialRampToValueAtTime(sus, t + a + d);
  g.gain.setValueAtTime(sus, t + Math.max(a + d, dur));
  g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + d, dur) + r);
  return { g, end: t + Math.max(a + d, dur) + r + 0.02 };
}

// ============================================================ the drum kit
// Built to sound hit rather than triggered: every piece has a body and a
// transient, and the velocities vary so a pattern breathes.
const Kit = {
  kick(t, v = 1, opts = {}) {
    const deep = opts.deep, click = opts.click !== false;
    const o = AC.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(deep ? 132 : 168, t);
    o.frequency.exponentialRampToValueAtTime(deep ? 36 : 48, t + (deep ? 0.16 : 0.10));
    const g = AC.createGain();
    g.gain.setValueAtTime(v * (deep ? 1.15 : 1.0), t);
    g.gain.exponentialRampToValueAtTime(0.001, t + (deep ? 0.40 : 0.26));
    o.connect(g); outChain(g, 0.03, 0); o.start(t); o.stop(t + 0.44);
    if (click) {                                        // beater noise, so it cuts through guitar
      const s = AC.createBufferSource(); s.buffer = noiseBuf;
      const f = AC.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 2400; f.Q.value = 1.2;
      const cg = AC.createGain(); cg.gain.setValueAtTime(v * 0.16, t);
      cg.gain.exponentialRampToValueAtTime(0.001, t + 0.03);
      s.connect(f); f.connect(cg); outChain(cg, 0, 0);
      s.start(t, Math.random() * 0.4); s.stop(t + 0.05);
    }
  },
  snare(t, v = 1, opts = {}) {
    const fat = opts.fat, rim = opts.rim;
    if (rim) {                                          // a rimshot: all crack, no body
      const s = AC.createBufferSource(); s.buffer = noiseBuf;
      const f = AC.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 3200; f.Q.value = 3;
      const g = AC.createGain(); g.gain.setValueAtTime(v * 0.42, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
      s.connect(f); f.connect(g); outChain(g, 0.20, 0); s.start(t, Math.random() * 0.4); s.stop(t + 0.07);
      return;
    }
    const s = AC.createBufferSource(); s.buffer = noiseBuf;
    const hp = AC.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = fat ? 380 : 620;
    const bp = AC.createBiquadFilter(); bp.type = 'bandpass';
    bp.frequency.value = fat ? 1500 : 2100; bp.Q.value = 0.55;
    const g = AC.createGain(); g.gain.setValueAtTime(v * (fat ? 0.68 : 0.58), t);
    g.gain.exponentialRampToValueAtTime(0.001, t + (fat ? 0.24 : 0.15));
    s.connect(hp); hp.connect(bp); bp.connect(g); outChain(g, 0.30, 0);
    s.start(t, Math.random() * 0.5); s.stop(t + 0.3);
    for (const [f0, f1, vv] of [[330, 180, 0.34], [190, 130, 0.22]]) {   // two tuned heads
      const o = AC.createOscillator(); o.type = 'triangle';
      o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + 0.07);
      const g2 = AC.createGain(); g2.gain.setValueAtTime(v * vv, t);
      g2.gain.exponentialRampToValueAtTime(0.001, t + 0.11);
      o.connect(g2); outChain(g2, 0.16, 0); o.start(t); o.stop(t + 0.13);
    }
  },
  hat(t, v = 1, open = false) {
    const s = AC.createBufferSource(); s.buffer = noiseBuf;
    const hp = AC.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 7600;
    const pk = AC.createBiquadFilter(); pk.type = 'peaking';
    pk.frequency.value = 11000; pk.gain.value = 5; pk.Q.value = 0.8;
    const dur = open ? 0.26 : 0.035;
    const g = AC.createGain(); g.gain.setValueAtTime(v * (open ? 0.20 : 0.15), t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(hp); hp.connect(pk); pk.connect(g); outChain(g, open ? 0.14 : 0.05, 0);
    s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.03);
  },
  ride(t, v = 1, bell = false) {
    const s = AC.createBufferSource(); s.buffer = noiseBuf;
    const bp = AC.createBiquadFilter(); bp.type = 'bandpass';
    bp.frequency.value = bell ? 5200 : 8200; bp.Q.value = bell ? 6 : 1.4;
    const g = AC.createGain(); g.gain.setValueAtTime(v * (bell ? 0.24 : 0.13), t);
    g.gain.exponentialRampToValueAtTime(0.001, t + (bell ? 0.5 : 0.34));
    s.connect(bp); bp.connect(g); outChain(g, 0.24, 0);
    s.start(t, Math.random() * 0.4); s.stop(t + 0.6);
    if (bell) {                                         // the ping of the bell, a real pitch
      const o = AC.createOscillator(); o.type = 'square'; o.frequency.value = 1180;
      const og = AC.createGain(); og.gain.setValueAtTime(v * 0.05, t);
      og.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
      o.connect(og); outChain(og, 0.3, 0); o.start(t); o.stop(t + 0.34);
    }
  },
  crash(t, v = 1) {
    const s = AC.createBufferSource(); s.buffer = noiseBuf;
    const hp = AC.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 3600;
    const g = AC.createGain(); g.gain.setValueAtTime(v * 0.30, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 1.5);
    s.connect(hp); hp.connect(g); outChain(g, 0.45, 0);
    s.start(t, Math.random() * 0.3); s.stop(t + 1.6);
  },
  tom(t, v = 1, pitch = 160) {
    const o = AC.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(pitch, t); o.frequency.exponentialRampToValueAtTime(pitch * 0.62, t + 0.22);
    const g = AC.createGain(); g.gain.setValueAtTime(v * 0.62, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    o.connect(g); outChain(g, 0.20, 0); o.start(t); o.stop(t + 0.34);
    const s = AC.createBufferSource(); s.buffer = noiseBuf;
    const bp = AC.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = pitch * 6; bp.Q.value = 1;
    const g2 = AC.createGain(); g2.gain.setValueAtTime(v * 0.10, t);
    g2.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
    s.connect(bp); bp.connect(g2); outChain(g2, 0.1, 0); s.start(t, Math.random() * 0.4); s.stop(t + 0.09);
  },
  // Air: a brake release, or steam off a standing loco. Filtered noise with a
  // slow swell and a long tail, so it reads as pressure rather than a hit.
  hiss(t, v = 1, opts = {}) {
    const dur = opts.dur || 0.9;
    const s = AC.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
    const bp = AC.createBiquadFilter(); bp.type = 'bandpass';
    bp.frequency.setValueAtTime(opts.f0 || 2600, t);
    bp.frequency.exponentialRampToValueAtTime(opts.f1 || 900, t + dur);
    bp.Q.value = 0.8;
    const g = AC.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(v * (opts.vol || 0.16), t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(bp); bp.connect(g); outChain(g, 0.36, 0);
    s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05);
  },
  // Struck metal: scaffold pole, skip, girder. Inharmonic partials over a
  // bandpassed noise crack, so it rings without ever being a pitch.
  clank(t, v = 1, opts = {}) {
    const base = opts.pitch || 520, ring = opts.ring || 0.34;
    // vol lets a song pull the metal back without losing it. Needed because at
    // 520Hz with a third of a second of ring this thing IS a cowbell, and on
    // sixteenths it stops being a struck girder and becomes a cowbell solo.
    const vol = opts.vol === undefined ? 1 : opts.vol;
    v *= vol;
    const s = AC.createBufferSource(); s.buffer = noiseBuf;
    const bp = AC.createBiquadFilter(); bp.type = 'bandpass';
    bp.frequency.value = base * 4.2; bp.Q.value = 1.6;
    const g = AC.createGain(); g.gain.setValueAtTime(v * 0.26, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    s.connect(bp); bp.connect(g); outChain(g, 0.28, 0);
    s.start(t, Math.random() * 0.4); s.stop(t + 0.07);
    // deliberately non-integer ratios: a struck bar is not a harmonic series
    for (const [r, lvl] of [[1, 0.30], [2.76, 0.20], [5.40, 0.12], [8.93, 0.07]]) {
      const o = AC.createOscillator(); o.type = 'sine'; o.frequency.value = base * r;
      const og = AC.createGain();
      og.gain.setValueAtTime(v * lvl, t);
      og.gain.exponentialRampToValueAtTime(0.0005, t + ring * (1 - (r / 14)));
      o.connect(og); outChain(og, 0.34, 0); o.start(t); o.stop(t + ring + 0.05);
    }
  },
  // The pile driver: something very heavy falling on something very solid.
  // A sub thud, a body, and the metal ringing off afterwards.
  drop(t, v = 1) {
    const o = AC.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(96, t); o.frequency.exponentialRampToValueAtTime(28, t + 0.3);
    const g = AC.createGain(); g.gain.setValueAtTime(v * 0.82, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.62);
    o.connect(g); outChain(g, 0.05, 0); o.start(t); o.stop(t + 0.7);
    const n = AC.createBufferSource(); n.buffer = noiseBuf;
    const lp = AC.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900;
    const ng = AC.createGain(); ng.gain.setValueAtTime(v * 0.26, t);
    ng.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    n.connect(lp); lp.connect(ng); outChain(ng, 0.2, 0);
    n.start(t, Math.random() * 0.4); n.stop(t + 0.24);
    this.clank(t + 0.02, v * 0.55, { pitch: 300, ring: 0.7 });
  },
  // A sampled-break stand-in for the drum and bass track: the same pieces, but
  // pitched and chopped the way a chopped break behaves.
  breakHit(t, v, kind) {
    if (kind === 'k') return this.kick(t, v * 1.0, { deep: true });
    if (kind === 's') return this.snare(t, v * 0.95, { fat: false });
    if (kind === 'r') return this.snare(t, v * 0.55, { rim: true });
    if (kind === 'g') {                                 // a ghost note on the snare
      const s = AC.createBufferSource(); s.buffer = noiseBuf;
      const bp = AC.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1800; bp.Q.value = 1.1;
      const g = AC.createGain(); g.gain.setValueAtTime(v * 0.13, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
      s.connect(bp); bp.connect(g); outChain(g, 0.12, 0); s.start(t, Math.random() * 0.4); s.stop(t + 0.07);
      return;
    }
    if (kind === 'h') return this.hat(t, v * 0.8, false);
    if (kind === 'o') return this.hat(t, v * 0.8, true);
    if (kind === 't') return this.tom(t, v, 150);
  },
};

// ============================================================ the guitars
// A guitar is a bright, slightly detuned pair of sawtooths through a
// waveshaper, then through an "amp": a resonant lowpass around 3k and a
// highpass at 90 to kill the mud. The pick attack is a short filtered noise
// burst - without it the notes sound blown rather than struck.
function ampChain(drive, tone = 3000, presence = 2.0, lo = 90) {
  const pre = AC.createGain(); pre.gain.value = drive.pre;
  const ws = AC.createWaveShaper(); ws.curve = drive.curve; ws.oversample = '4x';
  const hp = AC.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = lo;
  const cab = AC.createBiquadFilter(); cab.type = 'lowpass';
  cab.frequency.value = tone; cab.Q.value = presence;
  const post = AC.createGain(); post.gain.value = drive.post;
  pre.connect(ws); ws.connect(hp); hp.connect(cab); cab.connect(post);
  return { input: pre, output: post };
}
const DRIVE = {
  clean: () => ({ curve: SHAPE_SOFT, pre: 0.9, post: 0.85 }),
  crunch: () => ({ curve: SHAPE_SOFT, pre: 3.2, post: 0.36 }),
  hot: () => ({ curve: SHAPE_HOT, pre: 5.0, post: 0.22 }),
  fuzz: () => ({ curve: SHAPE_FUZZ, pre: 7.5, post: 0.15 }),
};
// One struck string. `bend` lifts into the note the way a player does.
function pickNoise(t, dest, v) {
  const s = AC.createBufferSource(); s.buffer = noiseBuf;
  const bp = AC.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 2600; bp.Q.value = 0.9;
  const g = AC.createGain(); g.gain.setValueAtTime(v, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.022);
  s.connect(bp); bp.connect(g); g.connect(dest);
  s.start(t, Math.random() * 0.4); s.stop(t + 0.04);
}
const Gtr = {
  // The lead voice: two saws a few cents apart, vibrato that arrives late
  // (players don't shake a note the instant they hit it), amp, verb, echo.
  lead(t, m, dur, o = {}) {
    const drive = (DRIVE[o.drive] || DRIVE.crunch)();
    const amp = ampChain(drive, o.tone || 3200, o.presence || 2.4);
    const env = adsr(t, dur, o.vol || 0.30, 0.006, 0.09, 0.72, o.rel || 0.16);
    amp.output.connect(env.g);
    outChain(env.g, o.send !== undefined ? o.send : 0.24, o.echo !== undefined ? o.echo : 0.14);
    pickNoise(t, amp.input, (o.vol || 0.30) * 0.5);
    const f = mtof(m);
    for (const det of (o.wide ? [-9, 9] : [-5, 5])) {
      const osc = AC.createOscillator(); osc.type = 'sawtooth';
      osc.frequency.value = f; osc.detune.value = det;
      if (o.bend) {                                     // slide up into the note
        osc.frequency.setValueAtTime(f * Math.pow(2, -o.bend / 12), t);
        osc.frequency.exponentialRampToValueAtTime(f, t + 0.055);
      }
      const lfo = AC.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = 5.2;
      const lg = AC.createGain();
      lg.gain.setValueAtTime(0.0001, t);
      lg.gain.setValueAtTime(0.0001, t + Math.min(0.18, dur * 0.45));
      lg.gain.linearRampToValueAtTime(o.vib || 11, t + Math.min(0.34, dur * 0.8));
      lfo.connect(lg); lg.connect(osc.detune);
      osc.connect(amp.input); osc.start(t); osc.stop(env.end); lfo.start(t); lfo.stop(env.end);
    }
  },
  // Palm-muted chug: short, thick, gated. The engine of a rock track.
  chug(t, m, dur, o = {}) {
    const drive = (DRIVE[o.drive] || DRIVE.hot)();
    const amp = ampChain(drive, o.tone || 2100, 1.4, 70);
    const g = AC.createGain();
    g.gain.setValueAtTime(o.vol || 0.24, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + Math.min(dur, 0.16));
    amp.output.connect(g); outChain(g, 0.06, 0);
    pickNoise(t, amp.input, (o.vol || 0.24) * 0.7);
    for (const det of [-6, 6]) {
      const osc = AC.createOscillator(); osc.type = 'sawtooth';
      osc.frequency.value = mtof(m); osc.detune.value = det;
      osc.connect(amp.input); osc.start(t); osc.stop(t + Math.min(dur, 0.2) + 0.02);
    }
  },
  // A power chord: root, fifth, octave. No third, which is why it works under
  // any melody and why every rock record is built out of them.
  power(t, m, dur, o = {}) {
    const drive = (DRIVE[o.drive] || DRIVE.hot)();
    const amp = ampChain(drive, o.tone || 2600, 1.8, 80);
    const env = adsr(t, dur, o.vol || 0.17, 0.008, 0.10, 0.70, 0.14);
    amp.output.connect(env.g); outChain(env.g, o.send !== undefined ? o.send : 0.16, 0);
    pickNoise(t, amp.input, (o.vol || 0.17) * 0.6);
    for (const iv of (o.five === false ? [0, 12] : [0, 7, 12])) {
      for (const det of [-4, 4]) {
        const osc = AC.createOscillator(); osc.type = 'sawtooth';
        osc.frequency.value = mtof(m + iv); osc.detune.value = det;
        osc.connect(amp.input); osc.start(t); osc.stop(env.end);
      }
    }
  },
  // Clean electric through a chorus: two triangles, one slowly drifting.
  clean(t, m, dur, o = {}) {
    const drive = DRIVE.clean();
    const amp = ampChain(drive, o.tone || 4200, 1.0, 120);
    const env = adsr(t, dur, o.vol || 0.17, 0.004, 0.12, 0.55, 0.22);
    amp.output.connect(env.g);
    outChain(env.g, o.send !== undefined ? o.send : 0.34, o.echo !== undefined ? o.echo : 0.18);
    pickNoise(t, amp.input, (o.vol || 0.17) * 0.8);
    for (const [det, rate] of [[-7, 0.6], [7, 0.83]]) {
      const osc = AC.createOscillator(); osc.type = 'triangle';
      osc.frequency.value = mtof(m); osc.detune.value = det;
      const lfo = AC.createOscillator(); lfo.frequency.value = rate;
      const lg = AC.createGain(); lg.gain.value = 6;
      lfo.connect(lg); lg.connect(osc.detune);
      osc.connect(amp.input); osc.start(t); osc.stop(env.end); lfo.start(t); lfo.stop(env.end);
    }
  },
  // A held, feeding-back note for the end of a phrase.
  sustain(t, m, dur, o = {}) {
    const drive = (DRIVE[o.drive] || DRIVE.fuzz)();
    const amp = ampChain(drive, o.tone || 3000, 3.0);
    const env = adsr(t, dur, o.vol || 0.22, 0.02, 0.2, 0.85, 0.5);
    amp.output.connect(env.g); outChain(env.g, 0.40, 0.22);
    for (const det of [-8, 8]) {
      const osc = AC.createOscillator(); osc.type = 'sawtooth';
      osc.frequency.value = mtof(m); osc.detune.value = det;
      const lfo = AC.createOscillator(); lfo.frequency.value = 4.6;
      const lg = AC.createGain();
      lg.gain.setValueAtTime(2, t); lg.gain.linearRampToValueAtTime(26, t + dur * 0.7);
      lfo.connect(lg); lg.connect(osc.detune);
      osc.connect(amp.input); osc.start(t); osc.stop(env.end); lfo.start(t); lfo.stop(env.end);
    }
  },
};

// ============================================================ keys
const Keys = {
  // Rhodes-ish: a sine fundamental with a bell partial that decays much
  // faster. Two-operator FM in all but name, and the cheapest convincing
  // electric piano there is.
  ep(t, m, dur, o = {}) {
    const f = mtof(m);
    const env = adsr(t, dur, o.vol || 0.15, 0.004, 0.5, 0.35, 0.3);
    const tone = AC.createBiquadFilter(); tone.type = 'lowpass'; tone.frequency.value = o.tone || 3400;
    tone.connect(env.g);
    outChain(env.g, o.send !== undefined ? o.send : 0.30, o.echo || 0.08);
    const car = AC.createOscillator(); car.type = 'sine'; car.frequency.value = f;
    const mod = AC.createOscillator(); mod.type = 'sine'; mod.frequency.value = f * 2;
    const mg = AC.createGain();
    mg.gain.setValueAtTime(f * (o.bite || 1.9), t);
    mg.gain.exponentialRampToValueAtTime(f * 0.05, t + 0.35);
    mod.connect(mg); mg.connect(car.frequency);
    car.connect(tone); car.start(t); car.stop(env.end); mod.start(t); mod.stop(env.end);
    const tine = AC.createOscillator(); tine.type = 'sine'; tine.frequency.value = f * 6.02;
    const tg = AC.createGain(); tg.gain.setValueAtTime((o.vol || 0.15) * 0.22, t);
    tg.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
    tine.connect(tg); outChain(tg, 0.3, 0); tine.start(t); tine.stop(t + 0.2);
  },
  // Drawbar organ: sines at harmonic ratios, fast on, fast off, slight chorus.
  organ(t, m, dur, o = {}) {
    const f = mtof(m);
    const env = adsr(t, dur, o.vol || 0.10, 0.012, 0.02, 0.95, 0.06);
    const tone = AC.createBiquadFilter(); tone.type = 'lowpass'; tone.frequency.value = o.tone || 3000;
    tone.connect(env.g); outChain(env.g, o.send !== undefined ? o.send : 0.24, 0);
    const bars = o.bars || [[1, 1.0], [2, 0.55], [3, 0.30], [4, 0.22], [6, 0.12], [8, 0.10]];
    for (const [ratio, lvl] of bars) {
      const osc = AC.createOscillator(); osc.type = 'sine';
      osc.frequency.value = f * ratio; osc.detune.value = (ratio % 2 ? 4 : -4);
      const g = AC.createGain(); g.gain.value = lvl;
      osc.connect(g); g.connect(tone); osc.start(t); osc.stop(env.end);
    }
  },
  // A wide analog pad: several detuned saws under a slow filter sweep.
  pad(t, m, dur, o = {}) {
    const env = adsr(t, dur, o.vol || 0.075, o.att || 0.35, 0.4, 0.85, o.rel || 0.9);
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.Q.value = 1.2;
    f.frequency.setValueAtTime(o.open ? 1400 : 500, t);
    f.frequency.linearRampToValueAtTime(o.open ? 2600 : 1500, t + dur * 0.7);
    f.connect(env.g); outChain(env.g, o.send !== undefined ? o.send : 0.5, 0);
    for (const [iv, det] of [[0, -11], [0, 11], [12, -6], [7, 5]]) {
      const osc = AC.createOscillator(); osc.type = 'sawtooth';
      osc.frequency.value = mtof(m + iv); osc.detune.value = det;
      const g = AC.createGain(); g.gain.value = iv ? 0.4 : 0.8;
      osc.connect(g); g.connect(f); osc.start(t); osc.stop(env.end);
    }
  },
  // Bright poly-synth stab: saws through a snappy filter envelope.
  stab(t, m, dur, o = {}) {
    const env = adsr(t, dur, o.vol || 0.12, 0.006, 0.12, 0.45, 0.14);
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.Q.value = 7;
    f.frequency.setValueAtTime(o.bright || 5200, t);
    f.frequency.exponentialRampToValueAtTime(900, t + Math.max(0.1, dur * 0.8));
    f.connect(env.g); outChain(env.g, o.send !== undefined ? o.send : 0.22, o.echo || 0.10);
    for (const det of [-8, 8]) {
      const osc = AC.createOscillator(); osc.type = o.wave || 'sawtooth';
      osc.frequency.value = mtof(m); osc.detune.value = det;
      osc.connect(f); osc.start(t); osc.stop(env.end);
    }
  },
  // A short bell/pluck for arpeggios.
  pluck(t, m, dur, o = {}) {
    const env = adsr(t, Math.min(dur, 0.3), o.vol || 0.085, 0.003, 0.09, 0.22, 0.12);
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = o.tone || 3600;
    f.connect(env.g); outChain(env.g, o.send !== undefined ? o.send : 0.34, o.echo !== undefined ? o.echo : 0.22);
    const osc = AC.createOscillator(); osc.type = o.wave || 'triangle'; osc.frequency.value = mtof(m);
    const osc2 = AC.createOscillator(); osc2.type = 'sine'; osc2.frequency.value = mtof(m + 12);
    const g2 = AC.createGain(); g2.gain.value = 0.3;
    osc.connect(f); osc2.connect(g2); g2.connect(f);
    osc.start(t); osc.stop(env.end); osc2.start(t); osc2.stop(env.end);
  },
};

// ============================================================ bass
const Bass = {
  // Picked electric bass: saw + square, a filter that closes fast, and a
  // fingernail transient on top.
  pick(t, m, dur, o = {}) {
    const env = adsr(t, dur, o.vol || 0.34, 0.006, 0.12, 0.55, 0.1);
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.Q.value = 4;
    f.frequency.setValueAtTime(o.bright || 2200, t);
    f.frequency.exponentialRampToValueAtTime(o.close || 320, t + Math.max(0.12, dur * 0.7));
    f.connect(env.g); outChain(env.g, 0.04, 0);
    for (const [type, lvl, det] of [['sawtooth', 1, 0], ['square', 0.4, -6]]) {
      const osc = AC.createOscillator(); osc.type = type;
      osc.frequency.value = mtof(m); osc.detune.value = det;
      const g = AC.createGain(); g.gain.value = lvl;
      osc.connect(g); g.connect(f); osc.start(t); osc.stop(env.end);
    }
    const s = AC.createBufferSource(); s.buffer = noiseBuf;
    const bp = AC.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1700; bp.Q.value = 1.2;
    const g = AC.createGain(); g.gain.setValueAtTime((o.vol || 0.34) * 0.16, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.025);
    s.connect(bp); bp.connect(g); outChain(g, 0, 0); s.start(t, Math.random() * 0.4); s.stop(t + 0.04);
    // Optional sine an octave down, OFF by default so no settled track moves.
    // In the low keys this voice never needed one - at A minor its fundamental
    // is already under 80Hz. Up at D it sits right on the line and the whole
    // bassline crosses into the band above, which is how stage 7 came out with
    // a fifth of the low end of every other stage in the game.
    if (o.sub) {
      const sb = AC.createOscillator(); sb.type = 'sine'; sb.frequency.value = mtof(m - 12);
      const sg = AC.createGain(); sg.gain.value = o.sub;
      sb.connect(sg); sg.connect(env.g); sb.start(t); sb.stop(env.end);
    }
  },
  // Pure sub: a sine and nothing else. What drum and bass is actually made of.
  sub(t, m, dur, o = {}) {
    const env = adsr(t, dur, o.vol || 0.42, 0.012, 0.06, 0.9, 0.08);
    outChain(env.g, 0, 0);
    const osc = AC.createOscillator(); osc.type = 'sine'; osc.frequency.value = mtof(m);
    if (o.glide) {
      osc.frequency.setValueAtTime(mtof(m - o.glide), t);
      osc.frequency.exponentialRampToValueAtTime(mtof(m), t + 0.09);
    }
    osc.connect(env.g); osc.start(t); osc.stop(env.end);
    const h = AC.createOscillator(); h.type = 'triangle'; h.frequency.value = mtof(m + 12);
    const hg = AC.createGain(); hg.gain.value = o.harm !== undefined ? o.harm : 0.10;
    h.connect(hg); hg.connect(env.g); h.start(t); h.stop(env.end);
  },
  // Reese: two detuned saws beating against each other through a lowpass.
  reese(t, m, dur, o = {}) {
    const env = adsr(t, dur, o.vol || 0.26, 0.02, 0.1, 0.9, 0.12);
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.Q.value = 3;
    f.frequency.setValueAtTime(o.bright || 700, t);
    f.frequency.linearRampToValueAtTime(o.sweep || 420, t + dur);
    f.connect(env.g); outChain(env.g, 0, 0);
    for (const det of [-16, 14]) {
      const osc = AC.createOscillator(); osc.type = 'sawtooth';
      osc.frequency.value = mtof(m); osc.detune.value = det;
      osc.connect(f); osc.start(t); osc.stop(env.end);
    }
  },
  // Classic synth bass: saw through a resonant envelope. The old engine's voice.
  syn(t, m, dur, o = {}) {
    const env = adsr(t, dur, o.vol || 0.32, 0.005, 0.1, 0.5, 0.08);
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.Q.value = 7;
    f.frequency.setValueAtTime(o.bright || 1800, t);
    f.frequency.exponentialRampToValueAtTime(o.close || 260, t + Math.max(0.1, dur * 0.8));
    f.connect(env.g); outChain(env.g, 0, 0);
    const osc = AC.createOscillator(); osc.type = 'sawtooth'; osc.frequency.value = mtof(m);
    osc.connect(f); osc.start(t); osc.stop(env.end);
    if (o.sub !== false) {          // a sine an octave down, unfiltered - the weight
      const sb = AC.createOscillator(); sb.type = 'sine'; sb.frequency.value = mtof(m - 12);
      const sg = AC.createGain(); sg.gain.value = o.sub === undefined ? 0.85 : o.sub;
      sb.connect(sg); sg.connect(env.g); sb.start(t); sb.stop(env.end);
    }
  },
};
