// Renders the front-end tracks and the one-shot cues.
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
(async () => {
  const which = process.argv[2] || 'all';
  const secs = +(process.argv[3] || 70);
  const sr = +(process.argv[4] || 32000);
  const src = ['00_eng.js', '01_seq.js', '19_front.js', '20_cues.js']
    .map(f => fs.readFileSync(path.join(__dirname, f), 'utf8')).join('\n');
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.goto('about:blank');
  await page.addScriptTag({ content: src });
  const keys = which === 'all' ? ['title','menu','shop','training','ending','cue_unit9','cue_roof'] : [which];
  for (const k of keys) {
    const res = await page.evaluate(async ([key, seconds, SR]) => {
      const S = (typeof FRONT_TRACKS !== 'undefined' && FRONT_TRACKS[key]) || CUE_TRACKS[key];
      prepSong(S);
      const isCue = key.indexOf('cue_') === 0;
      const dur = isCue ? songSeconds(S) + 2.5 : seconds;
      const ctx = new OfflineAudioContext(2, Math.ceil(SR * dur), SR);
      initBand(ctx);
      scheduleSong(S, isCue ? songSeconds(S) - 0.01 : seconds, 0.2);
      const buf = await ctx.startRendering();
      const L = buf.getChannelData(0), R = buf.getChannelData(1);
      let peak = 0, sum = 0, clip = 0;
      for (let i = 0; i < L.length; i++) {
        const v = (L[i] + R[i]) / 2, a = Math.abs(v);
        if (a > peak) peak = a; if (a >= 0.999) clip++; sum += v * v;
      }
      const n = L.length, bytes = 44 + n * 4;
      const ab = new ArrayBuffer(bytes), dv = new DataView(ab);
      const ws = (o, s) => { for (let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
      ws(0,'RIFF'); dv.setUint32(4,bytes-8,true); ws(8,'WAVEfmt ');
      dv.setUint32(16,16,true); dv.setUint16(20,1,true); dv.setUint16(22,2,true);
      dv.setUint32(24,SR,true); dv.setUint32(28,SR*4,true); dv.setUint16(32,4,true); dv.setUint16(34,16,true);
      ws(36,'data'); dv.setUint32(40,n*4,true);
      let o = 44;
      for (let i = 0; i < n; i++) {
        dv.setInt16(o, Math.max(-32768, Math.min(32767, L[i]*32767))|0, true); o += 2;
        dv.setInt16(o, Math.max(-32768, Math.min(32767, R[i]*32767))|0, true); o += 2;
      }
      let bin = ''; const u8 = new Uint8Array(ab);
      for (let i = 0; i < u8.length; i += 8192) bin += String.fromCharCode.apply(null, u8.subarray(i, i+8192));
      return { b64: btoa(bin), peak, rms: Math.sqrt(sum/n), clip, name: S.name, bars: S._bars,
               loop: +songSeconds(S).toFixed(1), bpm: S.bpm };
    }, [k, secs, sr]);
    fs.writeFileSync(path.join(__dirname, `../../shots/mus_${k}.wav`), Buffer.from(res.b64,'base64'));
    console.log(`${k.padEnd(10)} ${res.name.padEnd(20)} bpm ${res.bpm}  length ${res.loop}s (${res.bars} bars)  peak ${res.peak.toFixed(3)}  rms ${res.rms.toFixed(4)}  clipped ${res.clip}`);
  }
  console.log(errs.length ? 'PAGE ERRORS:\n' + errs.slice(0,5).join('\n') : 'no errors');
  await browser.close();
})();
