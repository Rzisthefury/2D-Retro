#!/bin/sh
# Assemble the stage 8 music picker.
cd "$(dirname "$0")"
if [ ! -f 03_stills.js ]; then echo "run stills.js first"; exit 1; fi
{ cat head.html; cat body8.html; echo '<script>';
  cat 00_eng.js 01_seq.js 17_s8.js 03_stills.js 97_viewer8.js;
  echo '</script>'; } > picker-mus8.html
python3 - <<'PY'
import io
p='picker-mus8.html'; s=io.open(p,encoding='utf-8').read()
bad=[(i,repr(c)) for i,c in enumerate(s) if ord(c)>127]
print('non-ascii:', len(bad), bad[:4])
PY
# the two pick buttons need a little room of their own
python3 - <<'PY'
import io
p='picker-mus8.html'; s=io.open(p,encoding='utf-8').read()
s=s.replace("</style>", """.picks{display:flex; gap:7px; flex:none}
.pick{padding:6px 13px; font-size:13px}
.pick.on{background:var(--green); color:#0a1a0d; border-color:var(--green)}
.card.picked .key{background:var(--green)}
</style>""")
io.open(p,'w',encoding='utf-8').write(s)
PY
wc -c picker-mus8.html
