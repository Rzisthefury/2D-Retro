// Render any finished track and measure it, so a change to a song can be
// checked against the numbers the rest of the soundtrack sits at rather than
// against an opinion.
//
//   node verify_mix.js boss              one track
//   node verify_mix.js boss boss5 stage5a
//   node verify_mix.js boss --wav        also write the audio out to listen to
//
// Prints peak, RMS, clipped samples, the six-band spectral split, and the
// per-bar loudness envelope - the envelope is the one that matters after the
// dropout fix, because it shows whether any bar still falls off a cliff.
// Settled range for the soundtrack: sub 21-47%, mid 8-22%, himid 1.1-3.3%.
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');

const FILES = ['00_eng.js', '01_seq.js', '04_stage1.js', '06_stage2.js', '08_stage3.js',
               '10_stage4.js', '12_stage5.js', '14_stage6.js', '16_stage7.js', '18_stage8.js',
               '19_front.js', '20_cues.js'];
const TABLE = `window.__T = { stage1a: T_stage1a, stage1b: T_stage1b, boss: T_boss1,
  stage2a: T_stage2a, stage2b: T_stage2b, boss2: T_boss2,
  stage3a: T_stage3a, stage3b: T_stage3b, boss3: T_boss3,
  stage4a: T_stage4a, stage4b: T_stage4b, boss4: T_boss4,
  stage5a: T_stage5a, stage5b: T_stage5b, boss5: T_boss5,
  stage6a: T_stage6a, stage6b: T_stage6b, stage6c: T_stage6c, boss6: T_boss6,
  stage7a: T_stage7a, stage7b: T_stage7b, stage7c: T_stage7c, boss7: T_boss7,
  stage8a: T_stage8a, stage8b: T_stage8b, stage8c: T_stage8c, boss8: T_boss8, boss8x: T_boss8x,
  title: T_title, menu: T_menu, shop: T_shop, training: T_training, ending: T_ending,
  cue_unit9: C_unit9, cue_roof: C_roof };
window.__prep = prepSong; window.__sched = scheduleSong; window.__init = initBand;
window.__secs = songSeconds;`;

(async () => {
  const args = process.argv.slice(2);
  const wantWav = args.includes('--wav');
  const names = args.filter(a => a[0] !== '-');
  // 16kHz and a single pass of the loop by default: enough for peak, clipping
  // and the per-bar envelope, and about four times quicker than a full-rate
  // render. Pass --hifi for 32kHz and two passes when the spectral split has to
  // be comparable with the numbers the settled tracks were measured at.
  const hifi = args.includes('--hifi');
  const SR = hifi ? 32000 : 16000;
  const LOOPS = hifi ? 2 : 1;
  const src = FILES.map(f => fs.readFileSync(path.join(__dirname, f), 'utf8')).join('\n');
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.goto('about:blank');
  await page.addScriptTag({ content: src + TABLE });

  for (const name of names) {
    const t0 = Date.now();
    const r = await page.evaluate(async ([key, sr, keepWav, loops]) => {
      const S = window.__T[key];
      if (!S) return { missing: true };
      window.__prep(S);
      // render the intro plus two full passes of the loop, so the loop seam and
      // every section inside the loop are both in the measurement
      const barSecs = 16 * (60 / S.bpm / 4);
      const from = S._loopFrom || 0;
      const loopBars = S.form.slice(from).reduce((n, F) => n + F.bars, 0);
      const introSecs = (S._bars - loopBars) * barSecs;
      const dur = introSecs + loopBars * barSecs * loops + 1;
      const ctx = new OfflineAudioContext(2, Math.ceil(sr * dur), sr);
      window.__init(ctx);
      window.__sched(S, dur - 0.4, 0.2);
      const buf = await ctx.startRendering();
      const L = buf.getChannelData(0), R = buf.getChannelData(1);
      let peak = 0, sum = 0, clip = 0;
      const mono = new Float32Array(L.length);
      for (let i = 0; i < L.length; i++) {
        const v = (L[i] + R[i]) / 2; mono[i] = v;
        const a = Math.abs(v); if (a > peak) peak = a; if (a >= 0.999) clip++;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / L.length);
      // per-bar RMS, which is what shows a dropout
      const perBar = [];
      const bs = Math.floor(barSecs * sr);
      for (let i = Math.floor(0.2 * sr); i + bs < mono.length; i += bs) {
        let s2 = 0; for (let j = i; j < i + bs; j++) s2 += mono[j] * mono[j];
        perBar.push(Math.sqrt(s2 / bs));
      }
      // six-band split. A naive DFT here took longer than the render itself, so
      // this is an in-place radix-2 FFT over Hann-windowed blocks.
      const EDGES = [20, 80, 250, 800, 2500, 6000, sr / 2];
      const band = new Array(6).fill(0);
      const N = 2048, HALF = N / 2;
      const re = new Float64Array(N), im = new Float64Array(N);
      const win = new Float64Array(N);
      for (let i = 0; i < N; i++) win[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (N - 1));
      const rev = new Uint16Array(N);
      for (let i = 0, j = 0; i < N; i++) {
        rev[i] = j;
        let m = HALF;
        while (m >= 1 && j >= m) { j -= m; m >>= 1; }
        j += m;
      }
      const fft = () => {
        for (let len = 2; len <= N; len <<= 1) {
          const ang = -2 * Math.PI / len, wr = Math.cos(ang), wi = Math.sin(ang);
          for (let i = 0; i < N; i += len) {
            let cr = 1, ci = 0;
            for (let k = 0; k < len / 2; k++) {
              const ar = re[i + k], ai = im[i + k];
              const br = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci;
              const bi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr;
              re[i + k] = ar + br; im[i + k] = ai + bi;
              re[i + k + len / 2] = ar - br; im[i + k + len / 2] = ai - bi;
              const ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr;
            }
          }
        }
      };
      for (let off = 0; off + N < mono.length; off += N) {
        for (let i = 0; i < N; i++) { re[rev[i]] = mono[off + i] * win[i]; im[rev[i]] = 0; }
        fft();
        for (let k = 1; k < HALF; k++) {
          const f = k * sr / N, p = re[k] * re[k] + im[k] * im[k];
          for (let b = 0; b < 6; b++) if (f >= EDGES[b] && f < EDGES[b + 1]) { band[b] += p; break; }
        }
      }
      const tot = band.reduce((a, b) => a + b, 0) || 1;
      const out = { bpm: S.bpm, dur, loops, introSecs, loopSecs: loopBars * barSecs, barSecs,
                    peak, rms, clip, bands: band.map(b => b / tot * 100), perBar };
      if (keepWav) {
        const n = L.length, bytes = 44 + n * 4;
        const ab = new ArrayBuffer(bytes), dv = new DataView(ab);
        const ws = (o, s) => { for (let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
        ws(0, 'RIFF'); dv.setUint32(4, bytes - 8, true); ws(8, 'WAVEfmt ');
        dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 2, true);
        dv.setUint32(24, sr, true); dv.setUint32(28, sr * 4, true);
        dv.setUint16(32, 4, true); dv.setUint16(34, 16, true);
        ws(36, 'data'); dv.setUint32(40, n * 4, true);
        for (let i = 0; i < n; i++) {
          dv.setInt16(44 + i * 4, Math.max(-1, Math.min(1, L[i])) * 32767, true);
          dv.setInt16(46 + i * 4, Math.max(-1, Math.min(1, R[i])) * 32767, true);
        }
        out.wav = Array.from(new Uint8Array(ab));
      }
      return out;
    }, [name, SR, wantWav, LOOPS]);

    if (r.missing) { console.log(`${name}: not found`); continue; }
    const B = r.bands.map(x => x.toFixed(1) + '%');
    console.log(`\n=== ${name}  ${r.bpm}bpm  rendered ${r.dur.toFixed(1)}s ` +
      `(intro ${r.introSecs.toFixed(1)}s + ${r.loops} x ${r.loopSecs.toFixed(1)}s loop)  [${((Date.now() - t0) / 1000).toFixed(0)}s]`);
    console.log(`  peak ${r.peak.toFixed(3)}  rms ${r.rms.toFixed(4)}  clipped ${r.clip}`);
    console.log(`  sub ${B[0]}  bass ${B[1]}  lowmid ${B[2]}  mid ${B[3]}  himid ${B[4]}  air ${B[5]}`);
    const mx = Math.max(...r.perBar);
    const worst = Math.min(...r.perBar) / mx * 100;
    console.log(`  quietest bar is ${worst.toFixed(0)}% of the loudest` +
      (worst < 30 ? '   <<< still a cliff' : '   (no cliff)'));
    console.log('  per-bar envelope:');
    r.perBar.forEach((v, i) => {
      const f = v / mx;
      console.log(`    bar ${String(i).padStart(2)} ${(f * 100).toFixed(0).padStart(3)}% ${'#'.repeat(Math.round(f * 40))}`);
    });
    if (r.wav) {
      const out = path.join('/mnt/user-data/outputs', name + '-fixed.wav');
      fs.writeFileSync(out, Buffer.from(r.wav));
      console.log('  wrote ' + out);
    }
  }
  if (errs.length) console.log('\nPAGE ERRORS:\n' + errs.join('\n'));
  await browser.close();
})();
