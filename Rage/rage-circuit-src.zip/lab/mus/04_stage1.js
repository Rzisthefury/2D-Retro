// ============================================================ STAGE 1, final
// One theme, three arrangements.
//
//   THE HOOK, in degrees above the lead key (A4):
//     0 3 5 7 . 5 3 0 | 7 5 7 10 | 12 10 7 5 . 7 5 3 | 3 2 0
//
//   1A UNDER THE EL   - the rock band plays it straight, at street level.
//   1B THE ROOFTOPS   - the same tune stretched out over synths and an
//                       arpeggio. You climbed out of the street; the music
//                       opens up with you.
//   BOSS 1            - the hook again, hard. The arpeggio keeps running so
//                       the fight still belongs up on the roof, but the
//                       guitars take the melody back off the synth.

// ---- 1A: UNDER THE EL -----------------------------------------------------
const T_stage1a = {
  name: 'Under the El', bpm: 142, key: 57, lkey: 69, swing: 0.06,
  loopFrom: 1,              // the intro plays once, not every time round
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'clean',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.34, bright: 2400, close: 300 },
    gtr:  { vol: 0.21, drive: 'hot', tone: 2400 },
    keys: { vol: 0.055, tone: 2400 },
    lead: { vol: 0.33, drive: 'crunch', tone: 3800, send: 0.22, echo: 0.14 },
    harm: { vol: 0.12, tone: 3800 },
    arp:  { vol: 0.05 },
  },
  chords: {
    main: [[0, 'm'], [-4, 'M'], [-2, 'M'], [0, 'm']],
    lift: [[-4, 'M'], [-2, 'M'], [0, 'm'], [0, 'm']],
    turn: [[0, 'm'], [3, 'M'], [-2, 'M'], [-5, 'M']],
  },
  drums: {
    intro: { k: 'X.......X.....x.', s: '............X...', h: 'x.x.x.x.x.x.x.xo' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.xox.x.x.xox.x.'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X.-.'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '....o.......o...' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . 0 . . 12 . 0 . . 7 . . 10 .'), P('0 . 0 . 12 . 0 . 0 . . 10 . 7 . 5')],
    drive: [P('0 . 0 12 . 0 . 7 0 . 0 12 . 10 . 7'), P('0 0 . 12 . 0 10 . 0 . 12 . 10 . 7 .')],
    soft: [P('0 . . . . . . . 12 . . . . . . .'), P('0 . . . . . . . 7 . . . . . . .')],
  },
  gtr: {
    chug: [P('0 . 0 0 . 0 . 0 . 0 0 . 0 . 3 5'), P('0 . 0 0 . 0 . 0 . 0 . 3 . 5 . 7')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .'), P('0 . . . . . 0 . 0 . . . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . 3 . 5 . 7 . . 5 . 3 . 0 .'),
        P('7 . . 5 . 7 . 10 . . . . . . . .'),
        P('12 . . 10 . 7 . 5 . . 7 . 5 . 3 .'),
        P('3 . . . 2 . 0 . . . . . . . . .')],
    B: [P('12 . 12 . 15 . 14 . 12 . . . 10 . . .'),
        P('10 . 10 . 12 . 10 . 7 . . . . . . .'),
        P('12 . 12 . 15 . 17 . 19 . . . 17 . 15 .'),
        P('14 . . . 12 . . . 10 . . . . . . .')],
    C: [P('0 . . . 3 . . . 5 . . . 7 . . .'),
        P('5 . . . 3 . . . 0 . . . . . . .'),
        P('7 . . . 10 . . . 12 . . . 10 . . .'),
        P('7 . . . . . 5 . 3 . . . . . . .')],
    Bh: [P('7 . 7 . 10 . 8 . 7 . . . 5 . . .'),
         P('5 . 5 . 7 . 5 . 3 . . . . . . .'),
         P('7 . 7 . 10 . 12 . 15 . . . 12 . 10 .'),
         P('10 . . . 7 . . . 5 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'chug' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'chug', lead: 'A', keys: 'hold' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'chug', lead: 'A', keys: 'hold' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', lead: 'C', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'chug', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'chug', lead: 'A', keys: 'hold' },
  ],
};

// ---- 1B: THE ROOFTOPS -----------------------------------------------------
// The same hook at half the rhythmic density, on a bright poly synth, with the
// sixteenth arpeggio doing the job the palm-mutes were doing. The guitar is
// still in the room - it answers the synth, and it takes over for the last
// section, which is the run-up to the boss.
const T_stage1b = {
  name: 'The Rooftops', bpm: 132, key: 57, lkey: 69, swing: 0,
  loopFrom: 1,              // the intro plays once, not every time round
  bassVoice: 'syn', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    bass: { vol: 0.36, bright: 1500, close: 220, sub: 1.0 },
    gtr:  { vol: 0.135, tone: 4600, send: 0.40, echo: 0.28 },
    keys: { vol: 0.100, open: true, att: 0.5 },
    lead: { vol: 0.23, bright: 6200, send: 0.30, echo: 0.26, wave: 'sawtooth' },
    harm: { vol: 0.16, drive: 'crunch', tone: 3600, send: 0.30, echo: 0.20 },
    arp:  { vol: 0.100, wave: 'triangle', tone: 4200, echo: 0.3 },
  },
  chords: {
    main: [[0, 'm'], [3, 'M'], [-2, 'M'], [5, 'm']],
    lift: [[-4, 'M'], [3, 'M'], [0, 'm'], [-2, 'M']],
    turn: [[5, 'm'], [-2, 'M'], [3, 'M'], [0, 'm']],
  },
  drums: {
    intro: { k: 'X.......X.......', h: '..x...x...x...x.' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...x.', '..x...x...x...xo'],
    },
    push: {
      k: ['X.......X.......', 'X...x...X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '............o...' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . 0 . . . 0 . . . 0 . 0 .'), P('0 . . . 0 . . . 0 . . 0 . 0 . 0')],
    oct:  [P('0 . 12 . 0 . 12 . 0 . 12 . 0 . 12 .'), P('0 . 12 . 0 . 12 . 0 . 12 . 10 . 7 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    // the guitar answers the synth in the gaps the stretched hook leaves
    answer: [P('. . . . . . . . 12 . 10 . . . 7 .'), P('. . . . . . . . 10 . 7 . . . 5 .')],
    chug: [P('0 . 0 0 . 0 . 0 . 0 0 . 0 . 3 5')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // THE HOOK, stretched to half speed - the same notes as 1A's A phrase
    A: [P('0 . . . 3 . . . 5 . . . 7 . . .'),
        P('5 . . . 3 . . . 0 . . . . . . .'),
        P('7 . . . 5 . . . 7 . . . 10 . . .'),
        P('12 . . . 10 . . . 7 . . . . . . .')],
    // 1A's chorus, opened out - longer notes, wider leaps
    B: [P('12 . . . 15 . 14 . 12 . . . 10 . . .'),
        P('10 . . . 12 . 10 . 7 . . . . . . .'),
        P('12 . . . 15 . 17 . 19 . . . 17 . 15 .'),
        P('14 . . . 12 . . . 10 . . . . . . .')],
    // the quiet one: the hook again, one note per bar, nearly still
    C: [P('0 . . . . . . . . . . . . . . .'),
        P('3 . . . . . . . 5 . . . . . . .'),
        P('7 . . . . . . . . . . . 5 . . .'),
        P('3 . . . . . . . 0 . . . . . . .')],
    // the guitar doubling the hook an octave down under the synth
    Ag: [P('. . . . -12 . . . -7 . . . -5 . . .'),
         P('-7 . . . -9 . . . -12 . . . . . . .'),
         P('-5 . . . -7 . . . -5 . . . -2 . . .'),
         P('0 . . . -2 . . . -5 . . . . . . .')],
    Bh: [P('7 . . . 10 . 8 . 7 . . . 5 . . .'),
         P('5 . . . 7 . 5 . 3 . . . . . . .'),
         P('7 . . . 10 . 12 . 15 . . . 12 . 10 .'),
         P('10 . . . 7 . . . 5 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', keys: 'hold', arp: 'run' },
    // the hook arrives on the synth, with the guitar an octave under it
    { bars: 4, chords: 'main', drums: 'main', bass: 'oct', keys: 'hold', arp: 'run', lead: 'A', harm: 'Ag', harmStyle: 'clean' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'oct', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.76 },
    // the run-up to the roof: the guitar takes the hook back off the synth
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'chug', gtrStyle: 'chug', keys: 'hold',
      arp: 'run', lead: 'A', leadStyle: 'lead' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
  ],
};

// ---- BOSS 1: BIG BRICK HARLAN --------------------------------------------
// Fought at the far end of the rooftops, so the arpeggio is still running -
// but this is a fight, and the guitars take the tune back. Same hook, 156bpm,
// and an E major at the end of every turn so it never settles.
const T_boss1 = {
  name: 'Big Brick Harlan', bpm: 156, key: 57, lkey: 69, swing: 0.04,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3000, gain: -4.5 },   // the choruses bit at the top; this takes it off the whole track
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.31, bright: 2800, close: 380 },
    gtr:  { vol: 0.19, drive: 'hot', tone: 3100 },
    keys: { vol: 0.06, tone: 2200, bars: [[1, 1], [2, 0.7], [3, 0.4], [4, 0.2]] },
    lead: { vol: 0.40, drive: 'hot', tone: 3500, wide: true, send: 0.20, echo: 0.10 },
    harm: { vol: 0.21, drive: 'crunch', tone: 2700, wide: true, send: 0.14, echo: 0.08 },
    arp:  { vol: 0.075, wave: 'triangle', tone: 4200, echo: 0.24 },
  },
  chords: {
    // i - bVI - bVII - V: the V is the one that keeps it from resolving
    main: [[0, 'm'], [-4, 'M'], [-2, 'M'], [-5, 'M']],
    hard: [[0, '5'], [-2, '5'], [-4, '5'], [-5, 'M']],
    turn: [[-4, 'M'], [-5, 'M'], [0, 'm'], [0, 'm']],
  },
  drums: {
    intro: { k: 'X..x....X.......', s: '............X...', h: 'xxxxxxxxxxxxxxxx', c: 'X...............' },
    main: {
      k: ['X..x....X...x...', 'X..x..x.X.......'],
      s: ['....X.-.....X...', '....X.......X.-x'],
      h: ['x.x.x.x.x.x.x.x.', 'x.xox.x.x.x.x.xo'],
    },
    push: {
      k: ['X..x..x.X..x....', 'X..x....X..x..x.'],
      s: ['....X.-.-...X..x', '....X..x....X.Xx'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    half: { k: 'X.......x.......', s: '........X.......', t: '............x.o-' },
    fill: { k: 'X.......x...x...', s: '....X..xX.x.X.Xx', t: '..........o.-.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 12 . 0 . 10 0 . 0 12 . 7 . 5'), P('0 . 0 12 . 0 10 . 0 . 12 . 10 7 5 3')],
    grind: [P('0 0 . 0 12 . 0 0 . 12 . 0 10 . 7 .'), P('0 . 12 0 . 10 . 0 0 . 0 12 . 10 . 7')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 5 . 3 .'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 7 . 5')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    stab: [P('. . . 0 . . 0 . . . . 0 . . . .'), P('. . 0 . . . . 0 . . 0 . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    // the hook, but urgent: the same notes packed into half the space
    A: [P('0 3 . 5 . 7 . 5 . 3 . 0 . . 10 .'),
        P('7 . 5 . 7 . 10 . . . 7 . . . . .'),
        P('12 . 10 . 7 . 5 . 7 . 5 . 3 . 2 .'),
        P('3 . . 2 . 0 . . . . . . . . . .')],
    B: [P('12 . 15 . 14 . 12 . 15 . . . 17 . . .'),
        P('12 . 10 . 12 . 10 . 7 . . . . . . .'),
        P('15 . 17 . 19 . 17 . 15 . 17 . 19 . . .'),
        P('20 . . . 19 . 17 . 15 . . . . . . .')],
    // the octave double - two guitars, not one
    Ah: [P('12 15 . 17 . 19 . 17 . 15 . 12 . . 22 .'),
         P('19 . 17 . 19 . 22 . . . 19 . . . . .'),
         P('24 . 22 . 19 . 17 . 19 . 17 . 15 . 14 .'),
         P('15 . . 14 . 12 . . . . . . . . . .')],
    Bh: [P('19 . 22 . 20 . 19 . 22 . . . 24 . . .'),
         P('19 . 17 . 19 . 17 . 15 . . . . . . .'),
         P('22 . 24 . 26 . 24 . 22 . 24 . 26 . . .'),
         P('27 . . . 26 . 24 . 22 . . . . . . .')],
  },
  arps: { run: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 2, chords: 'hard', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', arp: 'run', keys: 'stab' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'A', arp: 'run', keys: 'stab' },
    { bars: 4, chords: 'hard', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'A', harm: 'Ah', keys: 'stab' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'grind', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh', arp: 'run' },
    { bars: 1, chords: 'hard', drums: 'fill', bass: 'grind', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 2, chords: 'turn', drums: 'main', bass: 'main', gtr: 'riff', arp: 'run', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'hard', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'B', harm: 'Bh', keys: 'stab' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', arp: 'run', keys: 'stab' },
  ],
};

const STAGE1_TRACKS = { S1A: T_stage1a, S1B: T_stage1b, B1: T_boss1 };
