// ============================================================ stage 8 picker
// TOWER TOP - the last one. Three rooms, and the game is already quoting
// itself in two of them before the music turns up.
const OPTIONS = [
  { k: 'K1', song: S8_LAST, still: 'blackout', tag: 'THE WHOLE BAND',
    pitch: 'The one that is made of the rest of the game. The hook rises in leaps the way stage 1 did and then falls in steps the way stage 7 does - both halves of the soundtrack in one tune, which you can only do on the last stage and only once.',
    notes: [
      'Full band with nothing held back: overdriven lead, organ underneath, picked bass, the kit playing properly',
      'Closest in character to Under the El, which is the point of it',
      'The safest of the four, in the sense that it is unmistakably the end of THIS game',
    ] },
  { k: 'K2', song: S8_GLASS, still: 'modelroom', tag: 'EXPENSIVE',
    pitch: 'Written for the Model Room, which is a private museum of the city he bought. This is the villain\'s own taste in music: hushed, wide, unhurried and expensive, built on the sixth and the ninth - the intervals that sound like money.',
    notes: [
      'The slowest track in the game at 104, and the most restrained thing in it',
      'After seven stages of shouting, something this composed is the unsettling option',
      'Electric piano and a clean guitar a long way off; the drums barely participate',
    ] },
  { k: 'K3', song: S8_STORM, still: 'stormpad', tag: 'RAIN',
    pitch: 'The roof, in the rain, and the fastest thing in the game at 160. The rain is literally in the arrangement - a sixteenth figure that does not stop once for the entire track, with everything else played over the top of it.',
    notes: [
      'The tune circles inside a fifth and never leaves; nothing else in the game stays in one place like that',
      'Most physical of the four - it would make the helipad feel like weather rather than scenery',
      'Relentless by design, which is either exactly right for a last fight or too much of it',
    ] },
  { k: 'K4', song: S8_ROOF, still: 'stormpad', tag: 'THE ENDING',
    pitch: 'Your ending text is one line: DRAY GOES OFF THE ROOF WITHOUT HIS HELICOPTER. This is that line as music. It is the only hook in the soundtrack that lands on the major third - eight stages of minor keys, and the last tune resolves upward.',
    notes: [
      'Twin guitars in harmony the whole way rather than one under the other',
      'The only track in the game that sounds like winning rather than like fighting',
      'Unit-9 on stage 7 was hopeful. This one is not hopeful, it is done',
    ] },
];
const SCENES = [
  { id: 's8a', label: 'Lobby' },
  { id: 's8b', label: 'Model Room' },
  { id: 's8c', label: 'Helipad' },
];

let started = false, playing = null, raf = 0;
function ensureAudio() {
  if (started) return;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  initBand(new Ctx());
  started = true;
}
function stopAll() {
  Band.stop(); playing = null;
  document.querySelectorAll('.card').forEach(c => c.classList.remove('playing'));
  document.querySelectorAll('.play').forEach(b => { b.textContent = 'Play'; });
  cancelAnimationFrame(raf);
  document.querySelectorAll('.bar i').forEach(b => { b.style.width = '0%'; });
  document.querySelectorAll('.pos').forEach(p => { p.textContent = '0:00'; });
}
function toggle(opt, card) {
  ensureAudio();
  if (AC.state !== 'running') AC.resume();
  if (playing === opt.k) { stopAll(); return; }
  stopAll();
  playing = opt.k;
  card.classList.add('playing');
  card.querySelector('.play').textContent = 'Stop';
  Band.play(opt.k, { [opt.k]: opt.song });
  const t0 = AC.currentTime, total = songSeconds(opt.song);
  const bar = card.querySelector('.bar i'), pos = card.querySelector('.pos');
  const tick = () => {
    if (playing !== opt.k) return;
    const el = (AC.currentTime - t0) % total;
    bar.style.width = (el / total * 100).toFixed(1) + '%';
    pos.textContent = fmtTime(el);
    raf = requestAnimationFrame(tick);
  };
  tick();
}
const fmtTime = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');

const PICK_KEY = 'rc_mus_picks_s8';
let picks = {};
try { picks = JSON.parse(localStorage.getItem(PICK_KEY) || '{}'); } catch (e) { picks = {}; }
function savePicks() { try { localStorage.setItem(PICK_KEY, JSON.stringify(picks)); } catch (e) {} }
function refresh() {
  document.querySelectorAll('.card').forEach(c => {
    const k = c.dataset.k;
    const mine = SCENES.filter(s => picks[s.id] === k);
    c.classList.toggle('picked', mine.length > 0);
    c.querySelectorAll('.pick').forEach(b => {
      const on = picks[b.dataset.scene] === k;
      b.classList.toggle('on', on);
      b.textContent = (on ? '\u2713 ' : '') + b.dataset.label;
    });
  });
  const s = document.getElementById('summary');
  const parts = SCENES.filter(x => picks[x.id]).map(x => {
    const o = OPTIONS.find(y => y.k === picks[x.id]);
    return x.label + ': ' + picks[x.id] + ' \u2014 ' + o.song.name;
  });
  s.textContent = parts.length ? parts.join('   \u00b7   ')
    : 'Pick one for each scene and this line becomes the message to send back.';
}

function buildPage() {
  const wrap = document.getElementById('cards');
  for (const opt of OPTIONS) {
    const total = songSeconds(prepSong(opt.song));
    const card = document.createElement('section');
    card.className = 'card'; card.dataset.k = opt.k;
    card.innerHTML =
      '<div class="screen"><img alt="Stage 8 background" src="' + STILLS[opt.still] + '">' +
        '<span class="tag">' + opt.tag + '</span>' +
      '</div>' +
      '<div class="body">' +
        '<div class="titlerow">' +
          '<h3><span class="key">' + opt.k + '</span>' + opt.song.name + '</h3>' +
          '<div class="picks">' + SCENES.map(s =>
            '<button class="pick" type="button" data-scene="' + s.id + '" data-label="' + s.label + '">' + s.label + '</button>'
          ).join('') + '</div>' +
        '</div>' +
        '<p class="pitch">' + opt.pitch + '</p>' +
        '<ul class="notes">' + opt.notes.map(n => '<li>' + n + '</li>').join('') + '</ul>' +
        '<div class="transport">' +
          '<button class="play" type="button">Play</button>' +
          '<div class="bar"><i></i></div>' +
          '<span class="pos">0:00</span><span class="sep">/</span><span class="len">' + fmtTime(total) + '</span>' +
        '</div>' +
        '<p class="meta">' + opt.song.bpm + ' bpm \u00b7 ' + opt.song._bars + ' bars before it repeats \u00b7 C minor</p>' +
      '</div>';
    card.querySelector('.play').addEventListener('click', () => toggle(opt, card));
    card.querySelectorAll('.pick').forEach(b => b.addEventListener('click', () => {
      const sc = b.dataset.scene;
      if (picks[sc] === opt.k) delete picks[sc]; else picks[sc] = opt.k;
      savePicks(); refresh();
    }));
    wrap.appendChild(card);
  }
  refresh();
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') stopAll(); });
buildPage();
