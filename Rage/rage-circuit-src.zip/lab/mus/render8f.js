// Offline-render every option to a WAV, so the mix can be measured and the
// files can be listened to without opening the picker at all.
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');

(async () => {
  const which = process.argv[2] || 'all';
  const secs = +(process.argv[3] || 75);
  const sr = +(process.argv[4] || 44100);
  const src = ['00_eng.js', '01_seq.js', '18_stage8.js'].map(f => fs.readFileSync(path.join(__dirname, f), 'utf8')).join('\n');
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.goto('about:blank');
  await page.addScriptTag({ content: src });

  const keys = which === 'all' ? ['S8A', 'S8B', 'S8C', 'B8', 'B8X'] : [which];
  for (const k of keys) {
    const res = await page.evaluate(async ([key, seconds, SR]) => {
      const ctx = new OfflineAudioContext(2, Math.ceil(SR * seconds), SR);
      initBand(ctx);
      const S = STAGE8_TRACKS[key];
      scheduleSong(S, seconds, 0.2);
      const buf = await ctx.startRendering();
      const L = buf.getChannelData(0), R = buf.getChannelData(1);
      // measurements: peak, RMS, clipping, and how much the level moves across
      // the track (a flat curve means a loop that never develops)
      let peak = 0, sum = 0, clip = 0;
      const chunks = [], CH = Math.floor(SR * 2);
      let cs = 0, cn = 0;
      for (let i = 0; i < L.length; i++) {
        const v = (L[i] + R[i]) / 2, a = Math.abs(v);
        if (a > peak) peak = a;
        if (a >= 0.999) clip++;
        sum += v * v; cs += v * v; cn++;
        if (cn >= CH) { chunks.push(Math.sqrt(cs / cn)); cs = 0; cn = 0; }
      }
      const rms = Math.sqrt(sum / L.length);
      // pack to 16-bit WAV
      const n = L.length, bytes = 44 + n * 4;
      const ab = new ArrayBuffer(bytes), dv = new DataView(ab);
      const ws = (o, s) => { for (let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
      ws(0, 'RIFF'); dv.setUint32(4, bytes - 8, true); ws(8, 'WAVEfmt ');
      dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 2, true);
      dv.setUint32(24, SR, true); dv.setUint32(28, SR * 4, true);
      dv.setUint16(32, 4, true); dv.setUint16(34, 16, true);
      ws(36, 'data'); dv.setUint32(40, n * 4, true);
      let o = 44;
      for (let i = 0; i < n; i++) {
        dv.setInt16(o, Math.max(-32768, Math.min(32767, L[i] * 32767)) | 0, true); o += 2;
        dv.setInt16(o, Math.max(-32768, Math.min(32767, R[i] * 32767)) | 0, true); o += 2;
      }
      let bin = ''; const u8 = new Uint8Array(ab);
      for (let i = 0; i < u8.length; i += 8192) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 8192));
      return { b64: btoa(bin), peak, rms, clip, chunks, name: S.name, bars: S._bars,
               loop: +(S._bars * 16 * (60 / S.bpm / 4)).toFixed(1), bpm: S.bpm };
    }, [k, secs, sr]);
    fs.writeFileSync(path.join(__dirname, `../../shots/mus_${k}.wav`), Buffer.from(res.b64, 'base64'));
    const spread = Math.max(...res.chunks) / Math.max(1e-6, Math.min(...res.chunks));
    console.log(`${k} ${res.name.padEnd(16)} bpm ${res.bpm}  loop ${res.loop}s (${res.bars} bars)  peak ${res.peak.toFixed(3)}  rms ${res.rms.toFixed(4)}  clipped ${res.clip}  dynamics x${spread.toFixed(2)}`);
    console.log(`   level over time: ${res.chunks.map(c => (c * 100).toFixed(1)).join(' ')}`);
  }
  console.log(errs.length ? 'PAGE ERRORS:\n' + errs.slice(0, 5).join('\n') : 'no errors');
  await browser.close();
})();
