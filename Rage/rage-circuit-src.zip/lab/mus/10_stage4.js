// ============================================================ STAGE 4, final
// R4 won, which is a shuffle at 118 - exactly right for a shed where men work,
// and exactly wrong for the roof of a moving train. So the bridge keeps the
// band and the tune and changes only what it needs to: the tempo, and the fact
// that there are now rail joints underneath it.
//
//   THE HOOK, in degrees above the lead key (Ab4):
//     0 3 5 3 0 10 | 0 3 5 7 5 3 | 5 7 8 7 5 3 | 3 0 10 0
//   The 10 is the flat seventh, and it is what makes the thing a blues.
//
//   4A THE ROUNDHOUSE - R4 as you heard it. Air, organ, a walk.
//   4B THE BRIDGE RUN - the same band at 150 with the joints running under it.
//   BOSS 4            - Gauge Hollis. The shuffle turned nasty.

// ---- 4A: THE ROUNDHOUSE ---------------------------------------------------
const T_stage4a = {
  name: 'The Roundhouse', bpm: 118, key: 56, lkey: 68, swing: 0.22, level: 0.91,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3200, gain: -2 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'organ',
  band: {
    kick: {}, snare: { fat: true },
    clank: { ring: 0.35 }, hiss: { vol: 0.12 },
    bass: { vol: 0.36, bright: 2200, close: 290 },
    gtr:  { vol: 0.22, drive: 'crunch', tone: 2800 },
    keys: { vol: 0.10, tone: 2600, bars: [[1, 1.0], [2, 0.6], [3, 0.5], [4, 0.25], [6, 0.18]] },
    lead: { vol: 0.34, drive: 'hot', tone: 3400, send: 0.26, echo: 0.14, vib: 14 },
    harm: { vol: 0.085, tone: 2400 },
    arp:  { vol: 0.05 },
  },
  chords: {
    main: [[0, 'm7'], [0, 'm7'], [5, 'm7'], [0, 'm7']],
    lift: [[7, '7'], [5, 'm7'], [0, 'm7'], [0, 'm7']],
    turn: [[5, 'm7'], [7, '7'], [0, 'm7'], [-2, 'M']],
  },
  drums: {
    intro: { k: 'X.......x.......', s: '............X...', h: 'x..x..x..x..x..x', m: '........o.......' },
    main: {
      k: ['X.....x.....x...', 'X.......x.x.....'],
      s: ['....X.......X...', '....X.-.....X.-.'],
      h: ['x..x..x..x..x..x', 'x..xo.x..x..xo.x'],
      m: ['................', '..........x.....'],
    },
    push: {
      k: ['X.....x...x.x...', 'X...x...x.....x.'],
      s: ['....X.-.....X..x', '....X..x....X.Xx'],
      h: 'x.xx..x.x.xx..x.',
      m: ['..x.......o.....', '................'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '......o.......o.', a: '........x.......' },
    fill: { k: 'X.......x.......', s: '....X.-.x.X.x.Xx', t: '..........o.-...', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . 0 . 3 . . 5 . . 0 . . 10 .'), P('0 . 0 . . 3 5 . 0 . . 7 . 5 . 3')],
    walk: [P('0 . 3 . 5 . 7 . 8 . 7 . 5 . 3 .'), P('0 . 12 . 10 . 8 . 7 . 5 . 3 . 0 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . . 0 . 3 . . 0 . . 0 . . 10 .'), P('0 . . 0 . 3 . 5 . . 3 . 0 . . .')],
    stabs: [P('. . . 0 . . 0 . . . . 0 . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    comp: [P('. . 0 . . 0 . . . 0 . . . . 0 .'), P('. . 0 . . . 0 . . . . 0 . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('0 . . 3 . 5 . . 3 . 0 . . . 10 .'),
        P('0 . . 3 . 5 . 7 . . 5 . 3 . . .'),
        P('5 . . 7 . 8 . . 7 . 5 . 3 . . .'),
        P('3 . . 0 . . 10 . 0 . . . . . . .')],
    B: [P('12 . . 15 . 12 . . 10 . 12 . . . . .'),
        P('15 . . 12 . 10 . . 8 . . . . . . .'),
        P('12 . . 15 . 17 . . 15 . 12 . 10 . 12 .'),
        P('8 . . 7 . 5 . . 3 . . . . . . .')],
    C: [P('0 . . . 3 . . . 5 . . . 3 . . .'),
        P('0 . . . . . 10 . 0 . . . . . . .'),
        P('5 . . . 7 . . . 8 . . . 7 . . .'),
        P('5 . . . 3 . . . 0 . . . . . . .')],
    Ah: [P('0 . . . . . . . . . . . . . . .'),
         P('0 . . . . . . . . . . . . . . .'),
         P('5 . . . . . . . . . . . . . . .'),
         P('0 . . . . . . . . . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'comp' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'comp', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'walk', gtr: 'riff', keys: 'comp', lead: 'A', harm: 'Ah' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', gtr: 'stabs', gtrStyle: 'power', lead: 'B', keys: 'comp' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'walk', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', lead: 'C', keys: 'hold', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', gtr: 'riff', keys: 'comp', lead: 'B' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', keys: 'comp', lead: 'A' },
  ],
};

// ---- 4B: THE BRIDGE RUN ---------------------------------------------------
// Same band, same tune, 150 instead of 118, and the rail joints running
// underneath the whole way. The swing is tightened rather than dropped - a
// shuffle at this speed is what a train actually sounds like, and it keeps
// the roof plainly the same song as the shed.
const T_stage4b = {
  name: 'The Bridge Run', bpm: 150, key: 56, lkey: 68, swing: 0.13, level: 0.92,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3300, gain: -2 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    clank: { ring: 0.10 },
    bass: { vol: 0.35, bright: 2500, close: 330 },
    gtr:  { vol: 0.21, drive: 'crunch', tone: 2900 },
    keys: { vol: 0.085, tone: 2500, bars: [[1, 1.0], [2, 0.6], [3, 0.4], [4, 0.2]] },
    lead: { vol: 0.34, drive: 'hot', tone: 3500, send: 0.24, echo: 0.14, vib: 12 },
    harm: { vol: 0.19, drive: 'crunch', tone: 3000, send: 0.18, echo: 0.10 },
    arp:  { vol: 0.05 },
  },
  chords: {
    main: [[0, 'm7'], [0, 'm7'], [5, 'm7'], [-2, 'M']],
    lift: [[7, '7'], [5, 'm7'], [0, 'm7'], [0, 'm7']],
    turn: [[5, 'm7'], [7, '7'], [-2, 'M'], [0, 'm7']],
  },
  drums: {
    // the joints arrive and do not leave
    intro: { m: 'xx......xx......', h: 'x.x.x.x.x.x.x.x.' },
    main: {
      k: ['X.....x.....x...', 'X.......x.x.....'],
      s: ['....X.......X...', '....X.-.....X.-.'],
      h: ['x..x..x..x..x..x', 'x..xo.x..x..xo.x'],
      m: ['xx......xx......', 'xx......xx......'],
    },
    push: {
      k: ['X.....x...x.x...', 'X...x...x.....x.'],
      s: ['....X.-.....X..x', '....X..x....X.Xx'],
      h: 'x.xx..x.x.xx..x.',
      m: ['xx......xx......', 'xx..x...xx..x...'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', m: 'xx......xx......' },
    fill: { k: 'X.......x.......', s: '....X.-.x.X.x.Xx', m: 'xx......xx..xxxx', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . 0 . 3 . . 5 . . 0 . . 10 .'), P('0 . 0 . . 3 5 . 0 . . 7 . 5 . 3')],
    walk: [P('0 . 3 . 5 . 7 . 8 . 7 . 5 . 3 .'), P('0 . 12 . 10 . 8 . 7 . 5 . 3 . 0 .')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . . 0 . 3 . . 0 . . 0 . . 10 .'), P('0 . . 0 . 3 . 5 . . 3 . 0 . . .')],
    stabs: [P('. . . 0 . . 0 . . . . 0 . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    comp: [P('. . 0 . . 0 . . . 0 . . . . 0 .'), P('. . 0 . . . 0 . . . . 0 . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    // THE HOOK, note for note - the tempo is doing all the work
    A: [P('0 . . 3 . 5 . . 3 . 0 . . . 10 .'),
        P('0 . . 3 . 5 . 7 . . 5 . 3 . . .'),
        P('5 . . 7 . 8 . . 7 . 5 . 3 . . .'),
        P('3 . . 0 . . 10 . 0 . . . . . . .')],
    B: [P('12 . . 15 . 12 . . 10 . 12 . . . . .'),
        P('15 . . 12 . 10 . . 8 . . . . . . .'),
        P('12 . . 15 . 17 . . 15 . 12 . 10 . 12 .'),
        P('8 . . 7 . 5 . . 3 . . . . . . .')],
    C: [P('0 . . . 3 . . . 5 . . . 3 . . .'),
        P('0 . . . . . 10 . 0 . . . . . . .'),
        P('5 . . . 7 . . . 8 . . . 7 . . .'),
        P('5 . . . 3 . . . 0 . . . . . . .')],
    Bh: [P('15 . . 19 . 15 . . 12 . 15 . . . . .'),
         P('19 . . 15 . 12 . . 10 . . . . . . .'),
         P('15 . . 19 . 20 . . 19 . 15 . 12 . 15 .'),
         P('12 . . 10 . 8 . . 7 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'comp' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'comp', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'walk', gtr: 'riff', keys: 'comp', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'walk', gtr: 'stabs', gtrStyle: 'power' },
    // the joints keep going even here - you cannot get off
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'ring', gtrStyle: 'clean', lead: 'C', keys: 'hold', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', gtr: 'riff', keys: 'comp', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', keys: 'comp', lead: 'A' },
  ],
};

// ---- BOSS 4: GAUGE HOLLIS ------------------------------------------------
// He swings a coupler like a club and he will run the whole length of the roof
// to reach you. The shuffle stays - it is his walk - but it is turned nasty:
// 166, fuzz instead of crunch, and the joints hammering underneath. The organ
// is still there because he is still a man who works here.
const T_boss4 = {
  name: 'Gauge Hollis', bpm: 166, key: 56, lkey: 68, swing: 0.11, level: 0.90,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3000, gain: -3.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    clank: { ring: 0.14 },
    bass: { vol: 0.31, bright: 2800, close: 370 },
    gtr:  { vol: 0.19, drive: 'hot', tone: 3000 },
    keys: { vol: 0.075, tone: 2400, bars: [[1, 1], [2, 0.7], [3, 0.4], [4, 0.2]] },
    lead: { vol: 0.40, drive: 'hot', tone: 3600, wide: true, send: 0.20, echo: 0.10 },
    harm: { vol: 0.22, drive: 'crunch', tone: 3000, wide: true, send: 0.16, echo: 0.08 },
    arp:  { vol: 0.05 },
  },
  chords: {
    main: [[0, 'm7'], [5, 'm7'], [7, '7'], [0, 'm7']],
    hard: [[0, '5'], [0, '5'], [5, '5'], [7, 'M']],
    turn: [[5, 'm7'], [7, '7'], [0, 'm7'], [0, 'm7']],
  },
  drums: {
    intro: { k: 'X..x....X.......', s: '............X...', m: 'xx......xx......', h: 'x..x..x..x..x..x', c: 'X...............' },
    main: {
      k: ['X..x..x.....x...', 'X..x....x.x.....'],
      s: ['....X.-.....X...', '....X.......X.-x'],
      h: ['x..x..x..x..x..x', 'x..xo.x..x..xo.x'],
      m: ['xx......xx......', 'xx......xx....x.'],
    },
    push: {
      k: ['X..x..x...x.x...', 'X..x.x..x.....x.'],
      s: ['....X.-.-...X..x', '....X..x....X.Xx'],
      h: 'x.xx..x.x.xx..x.',
      m: ['xx..x...xx..x...', 'xx......xx..xx..'],
      c: ['X...............', '................'],
    },
    half: { k: 'X.......x.......', s: '........X.......', m: 'xx......xx......' },
    fill: { k: 'X.......x...x...', s: '....X..xX.x.X.Xx', m: 'xx......xx..xxxx', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . 0 . 3 . . 5 . . 0 . . 10 .'), P('0 . 0 . . 3 5 . 0 . . 7 . 5 . 3')],
    grind: [P('0 0 . 0 . 3 0 . 0 . . 0 10 . 7 .'), P('0 . 0 0 . 3 . 5 0 . 0 . 10 . 7 5')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . . 0 . 3 . . 0 . . 0 . 10 . 0'), P('0 . . 0 . 3 . 5 . . 3 . 0 . 10 .')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    stab: [P('. . . 0 . . 0 . . . . 0 . . . .'), P('. . 0 . . . . 0 . . 0 . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    // the hook with the swagger taken out of it and the speed left in
    A: [P('0 . 3 . 5 . 3 . 0 . 10 . 0 . . .'),
        P('0 . 3 . 5 . 7 . 5 . 3 . . . . .'),
        P('5 . 7 . 8 . 7 . 5 . 3 . 0 . 10 .'),
        P('3 . 0 . 10 . 0 . . . . . . . . .')],
    B: [P('12 . 15 . 12 . 10 . 12 . . . 15 . . .'),
        P('15 . 12 . 10 . 8 . 7 . . . . . . .'),
        P('12 . 15 . 17 . 15 . 12 . 10 . 12 . 15 .'),
        P('17 . . 15 . 12 . . 10 . . . . . . .')],
    C: [P('0 . . . 3 . . . 5 . . . 3 . . .'),
        P('0 . . . . . 10 . 0 . . . . . . .'),
        P('5 . . . 7 . . . 8 . . . 7 . . .'),
        P('5 . . . 3 . . . 0 . . . . . . .')],
    Bh: [P('15 . 19 . 15 . 12 . 15 . . . 19 . . .'),
         P('19 . 15 . 12 . 10 . 12 . . . . . . .'),
         P('15 . 19 . 20 . 19 . 15 . 12 . 15 . 19 .'),
         P('20 . . 19 . 15 . . 12 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 2, chords: 'hard', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'stab' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'A', keys: 'stab' },
    { bars: 4, chords: 'hard', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'grind', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'hard', drums: 'fill', bass: 'grind', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 2, chords: 'turn', drums: 'main', bass: 'main', gtr: 'riff', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'hard', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'B', harm: 'Bh', keys: 'stab' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'stab' },
  ],
};

const STAGE4_TRACKS = { S4A: T_stage4a, S4B: T_stage4b, B4: T_boss4 };
