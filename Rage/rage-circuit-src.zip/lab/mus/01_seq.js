// ============================================================ the song format
// A song is sections, not a loop. Each section names which chord run, which
// drum pattern, which bass line, which guitar part and which lead phrase is
// playing, so the arrangement can build, drop out and come back - which is the
// whole difference between a game loop you stop hearing after a minute and one
// you do not.
//
//   chords : named runs of [semitoneOffsetFromKey, quality]
//   drums  : named kits of 16-char-per-bar strings, one per piece
//   bass   : named lines - arrays of bars, each bar 16 slots of scale degrees
//   gtr    : named guitar parts, same shape (used by chug / power / clean)
//   leads  : named melodies - arrays of bars, 16 slots, absolute scale degrees
//   form   : the running order
//
// Velocity comes out of the pattern character: 'X' accents, 'x' is normal,
// 'o' is the open/alternate variant, '-' is a ghost. '.' is a rest.

const CHORD = {
  M:   [0, 4, 7], m:   [0, 3, 7], M7:  [0, 4, 7, 11], m7:  [0, 3, 7, 10],
  7:   [0, 4, 7, 10], sus: [0, 5, 7], dim: [0, 3, 6], m9:  [0, 3, 7, 10, 14],
  M9:  [0, 4, 7, 11, 14], add9: [0, 4, 7, 14], m6: [0, 3, 7, 9], 5: [0, 7],
};
// A chord voiced for keys: spread across an octave and a bit so it does not
// sit in a lump where the bass already is.
function voice(root, quality, spread = 1) {
  const ivs = CHORD[quality] || CHORD.M;
  const out = [root + ivs[0]];
  for (let i = 1; i < ivs.length; i++) out.push(root + ivs[i] + (spread && i === 1 ? 0 : 0));
  return out;
}
const VEL = { X: 1.12, x: 0.88, o: 0.82, '-': 0.35, '+': 1.0 };
function vel(ch) { return VEL[ch] !== undefined ? VEL[ch] : 0.88; }

// Turn "0 . 12 . -5 ." into [0,null,12,null,-5,null] - one entry per 16th.
function P(str) {
  return String(str).trim().split(/\s+/).map(t => (t === '.' ? null : (t === '_' ? '_' : +t)));
}
// How long a note lasts: until the next note or the end of the bar. '_' ties.
function holdLen(bar, i) {
  let n = 1;
  while (i + n < bar.length && (bar[i + n] === null || bar[i + n] === '_') && n < 16) n++;
  return n;
}

// ============================================================ the sequencer
// One function emits every event for one 16th step at an absolute time, and
// both the live player and the offline renderer drive it. That way what you
// hear in the picker is exactly what renders to a file.
function stepEvents(S, sec, barInSec, step, t, spb) {
  const F = S.form[sec];
  if (!F) return;
  const swing = (S.swing || 0) * spb * (step % 2 ? 1 : 0);
  t += swing;
  const chords = S.chords[F.chords] || S.chords.main;
  const absBar = F._barOffset + barInSec;
  const ch = chords[absBar % chords.length];
  const root = S.key + ch[0];
  const qual = ch[1];
  const band = S.band || {};
  // F.gain shapes the arrangement; S.level is the whole song's headroom trim,
  // so a track can be pulled back without re-balancing every instrument in it.
  const gain = (F.gain === undefined ? 1 : F.gain) * (S.level === undefined ? 1 : S.level);

  // ---- drums
  const dk = S.drums[F.drums];
  if (dk) {
    const bar = i => (Array.isArray(dk[i]) ? dk[i][absBar % dk[i].length] : dk[i]);
    const k = bar('k'), s = bar('s'), h = bar('h'), r = bar('r'), c = bar('c'), tm = bar('t');
    const mt = bar('m'), dp = bar('d'), ai = bar('a');
    if (k && k[step] && k[step] !== '.') Kit.kick(t, vel(k[step]) * gain, band.kick || {});
    if (s && s[step] && s[step] !== '.') {
      const cch = s[step];
      Kit.snare(t, vel(cch) * gain, cch === '-' ? { rim: false } : (band.snare || {}));
    }
    if (h && h[step] && h[step] !== '.') Kit.hat(t, vel(h[step]) * gain, h[step] === 'o');
    if (r && r[step] && r[step] !== '.') Kit.ride(t, vel(r[step]) * gain, r[step] === 'X');
    if (c && c[step] && c[step] !== '.') Kit.crash(t, vel(c[step]) * gain);
    if (mt && mt[step] && mt[step] !== '.') {          // struck metal
      const p = { X: 760, x: 520, o: 380, '-': 900 }[mt[step]] || 520;
      Kit.clank(t, vel(mt[step]) * gain, Object.assign({ pitch: p }, band.clank));
    }
    if (dp && dp[step] && dp[step] !== '.') Kit.drop(t, vel(dp[step]) * gain);
    if (ai && ai[step] && ai[step] !== '.') {          // air: brakes, steam
      const long = ai[step] === 'X';
      Kit.hiss(t, vel(ai[step]) * gain, Object.assign({ dur: long ? 1.6 : 0.7 }, band.hiss));
    }
    if (tm && tm[step] && tm[step] !== '.') {
      const p = { X: 190, x: 150, o: 118, '-': 96 }[tm[step]] || 150;
      Kit.tom(t, vel(tm[step]) * gain, p);
    }
  }
  // ---- a chopped break instead of a kit, for the drum and bass track
  const bk = S.breaks && S.breaks[F.breaks];
  if (bk) {
    const line = bk[absBar % bk.length];
    const cch = line[step];
    if (cch && cch !== '.') Kit.breakHit(t, (cch === cch.toUpperCase() ? 1.05 : 0.8) * gain, cch.toLowerCase());
  }
  // ---- bass
  const bl = S.bass[F.bass];
  if (bl) {
    const bar = bl[absBar % bl.length], n = bar[step];
    if (n !== null && n !== '_') {
      const len = holdLen(bar, step) * spb * 0.92;
      const voiceFn = Bass[F.bassVoice || S.bassVoice || 'pick'] || Bass.pick;
      voiceFn.call(Bass, t, root - 24 + n, len, Object.assign({}, band.bass, { vol: (band.bass && band.bass.vol || 0.34) * gain }));
    }
  }
  // ---- rhythm guitar
  const gp = S.gtr && S.gtr[F.gtr];
  if (gp) {
    const bar = gp[absBar % gp.length], n = bar[step];
    if (n !== null && n !== '_') {
      const len = holdLen(bar, step) * spb * 0.9;
      const style = F.gtrStyle || S.gtrStyle || 'chug';
      const o = Object.assign({}, band.gtr);
      o.vol = (band.gtr && band.gtr.vol || 0.22) * gain;
      Gtr[style].call(Gtr, t, root - 12 + n, len, o);
    }
  }
  // ---- keys: a chord on the downbeat, or a rhythmic stab pattern
  if (F.keys) {
    const kp = S.keys && S.keys[F.keys];
    const style = F.keyStyle || S.keyStyle || 'pad';
    if (kp) {
      const bar = kp[absBar % kp.length], n = bar[step];
      if (n !== null && n !== '_') {
        const len = holdLen(bar, step) * spb * 0.95;
        for (const m of voice(root + 12 + n, qual)) {
          Keys[style].call(Keys, t, m, len, Object.assign({}, band.keys,
            { vol: (band.keys && band.keys.vol || 0.10) * gain }));
        }
      }
    } else if (step === 0) {                       // no pattern: hold the chord
      const len = spb * 16 * 0.98;
      for (const m of voice(root + 12, qual)) {
        Keys[style].call(Keys, t, m, len, Object.assign({}, band.keys,
          { vol: (band.keys && band.keys.vol || 0.09) * gain }));
      }
    }
  }
  // ---- arpeggio
  if (F.arp && S.arps && S.arps[F.arp]) {
    const a = S.arps[F.arp];
    if (step % (a.rate || 2) === 0) {
      const idx = (step / (a.rate || 2)) % a.notes.length;
      const ivs = CHORD[qual] || CHORD.M;
      const deg = a.notes[idx];
      const m = root + 24 + (a.chordal ? ivs[deg % ivs.length] + 12 * Math.floor(deg / ivs.length) : deg);
      Keys[a.voice || 'pluck'].call(Keys, t, m, spb * (a.rate || 2) * 1.4,
        Object.assign({}, band.arp, { vol: (band.arp && band.arp.vol || 0.075) * gain }));
    }
  }
  // ---- lead
  if (F.lead && S.leads[F.lead]) {
    const ph = S.leads[F.lead];
    const bar = ph[barInSec % ph.length], n = bar[step];
    if (n !== null && n !== '_') {
      const len = holdLen(bar, step) * spb * 0.94;
      const style = F.leadStyle || S.leadStyle || 'lead';
      const o = Object.assign({}, band.lead);
      o.vol = (band.lead && band.lead.vol || 0.30) * gain;
      if (len > spb * 5) o.bend = 2;                   // slide into the long ones
      const fn = Gtr[style] ? Gtr[style] : Keys[style];
      fn.call(Gtr[style] ? Gtr : Keys, t, S.lkey + n, len, o);
    }
  }
  // ---- a second voice answering the lead
  if (F.harm && S.leads[F.harm]) {
    const ph = S.leads[F.harm];
    const bar = ph[barInSec % ph.length], n = bar[step];
    if (n !== null && n !== '_') {
      const len = holdLen(bar, step) * spb * 0.94;
      const style = F.harmStyle || S.harmStyle || 'clean';
      const o = Object.assign({}, band.harm);
      o.vol = (band.harm && band.harm.vol || 0.15) * gain;
      const fn = Gtr[style] ? Gtr : Keys;
      fn[style].call(fn, t, S.lkey + n, len, o);
    }
  }
}
// Work out where each section starts, so chord runs longer than a section
// still line up.
function prepSong(S) {
  let off = 0;
  for (const F of S.form) { F._barOffset = off; off += F.bars; }
  S._bars = off;
  S.lkey = S.lkey === undefined ? S.key + 24 : S.lkey;
  // Where the form restarts after it has played through once. A track that
  // opens with a sparse intro sets loopFrom past it: an intro that comes back
  // every 45 seconds is not an intro, it is a hole in the music, and under
  // combat SFX the player hears it as the music cutting out. Default 0 keeps
  // the whole form looping, which is right for anything with no intro.
  S._loopFrom = Math.min(Math.max(S.loopFrom || 0, 0), S.form.length - 1);
  return S;
}
function songSeconds(S) { return S._bars * 16 * (60 / S.bpm / 4); }

// ---- the live player -----------------------------------------------------
const Band = {
  song: null, name: null, timer: null, next: 0, step: 0, bar: 0, sec: 0, secBar: 0,
  play(name, songs) {
    if (this.name === name) return;
    this.stop();
    const S = songs[name];
    if (!S || !AC) return;
    this.name = name; this.song = prepSong(S);
    setDelayTime(60 / S.bpm / 2 * (S.echo || 1));
    setTone(S.tone && S.tone.freq, S.tone && S.tone.gain);
    this.next = AC.currentTime + 0.1; this.step = 0; this.bar = 0; this.sec = 0; this.secBar = 0;
    this.timer = setInterval(() => this.tick(), 25);
  },
  stop() { if (this.timer) clearInterval(this.timer); this.timer = null; this.name = null; this.song = null; },
  tick() {
    if (!AC || !this.song || AC.state !== 'running') return;
    const S = this.song, spb = 60 / S.bpm / 4;
    if (this.next < AC.currentTime - 0.3) this.next = AC.currentTime + 0.05;
    while (this.next < AC.currentTime + 0.15) {
      stepEvents(S, this.sec, this.secBar, this.step, this.next, spb);
      this.next += spb; this.step++;
      if (this.step >= 16) {
        this.step = 0; this.secBar++;
        if (this.secBar >= S.form[this.sec].bars) {
          this.secBar = 0; this.sec++;
          if (this.sec >= S.form.length) this.sec = S._loopFrom;
        }
      }
    }
  },
};
// ---- offline render, for writing a track to a file -----------------------
function scheduleSong(S, seconds, startAt = 0) {
  prepSong(S);
  setDelayTime(60 / S.bpm / 2 * (S.echo || 1));
  setTone(S.tone && S.tone.freq, S.tone && S.tone.gain);
  const spb = 60 / S.bpm / 4;
  let t = startAt, sec = 0, secBar = 0, step = 0;
  while (t < startAt + seconds) {
    stepEvents(S, sec, secBar, step, t, spb);
    t += spb; step++;
    if (step >= 16) {
      step = 0; secBar++;
      if (secBar >= S.form[sec].bars) {
        secBar = 0; sec++;
        if (sec >= S.form.length) sec = S._loopFrom;
      }
    }
  }
}
