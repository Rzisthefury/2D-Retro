// ============================================================ STAGE 3, final
// T3 won, which turns stage 3 inside out compared with stage 1 - and for the
// better. There the hard version came first and the calm one was the payoff of
// climbing. Here the tune you picked IS the payoff: down in the mud the same
// melody gets played by the industrial band with metal all over it, and only
// when you reach the glass does it finally get room to breathe.
//
//   THE HOOK, in degrees above the lead key (Bb4):
//     7 10 12 | 10 7 | 12 14 15 | 14 12
//
//   3A GROUND LEVEL  - the hook driven, at 144, with scaffold percussion.
//   3B THE GLASS FLOOR - the hook as you heard it. Long lines, a lot of air.
//   BOSS 3           - the Wrecker MK-II. The metal takes the melody itself,
//                      and when the mech overheats the machinery drops out and
//                      what is left is a man running.

// ---- 3A: GROUND LEVEL -----------------------------------------------------
// Sunset Steel's band, playing Sunset Steel's tune - the same pads, the same
// clean guitar, the same sub. The only difference is pace: 124 instead of 116,
// the arpeggio running sixteenths instead of eighths, the bass moving and the
// kit actually working. It is a fight at ground level, not a view.
//
// There is struck metal in it, but sparse and rung out long - it is a building
// site, and that is scene colour rather than a rhythm part.
const T_stage3a = {
  name: 'Ground Level', bpm: 124, key: 58, lkey: 70, swing: 0, echo: 1.2, level: 0.90,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3200, gain: -2.5 },
  bassVoice: 'syn', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'lead', harmStyle: 'stab',
  band: {
    kick: { deep: true }, snare: { fat: true }, clank: { ring: 0.7 },
    bass: { vol: 0.40, bright: 1500, close: 230, sub: 1.0 },
    gtr:  { vol: 0.14, tone: 4000, send: 0.44, echo: 0.30 },
    keys: { vol: 0.11, open: true, att: 0.7 },
    lead: { vol: 0.24, drive: 'clean', tone: 3400, send: 0.38, echo: 0.26, vib: 10 },
    harm: { vol: 0.11, bright: 3800, send: 0.36, echo: 0.28 },
    arp:  { vol: 0.09, wave: 'triangle', tone: 3400, echo: 0.38 },
  },
  chords: {
    main: [[0, 'm9'], [-4, 'M9'], [-2, 'M'], [3, 'M7']],
    lift: [[-4, 'M9'], [-2, 'M'], [0, 'm9'], [5, 'm7']],
    turn: [[3, 'M7'], [5, 'm7'], [-2, 'M'], [0, 'm9']],
  },
  drums: {
    intro: { m: '........o.......', h: '..x...x...x...x.' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['..x...x...x...xo', 'x.x.x.x.x.x.x.x.'],
      m: ['................', '............o...'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X...'],
      h: 'x.xox.x.x.xox.x.',
      m: ['..........o.....', '................'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', m: '........o.......', h: '............o...' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . 0 . . . 0 . . . 0 . 10 .'), P('0 . . . 0 . . . 0 . . 0 . 7 . .')],
    oct:  [P('0 . 12 . 0 . 12 . 0 . 12 . 0 . 10 .'), P('0 . 12 . 0 . 12 . 0 . 10 . 7 . 5 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('12 . . . . . . . . . . . . . . .'), P('7 . . . . . . . . . . . . . . .')],
    pulse: [P('. . . . 0 . . . . . . . 0 . . .'), P('. . . . 0 . . . 0 . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // THE HOOK at twice the density of the glass floor - same notes, more pulse
    A: [P('7 . . . 10 . . . 12 . . . . . . .'),
        P('10 . . . 7 . . . . . . . . . . .'),
        P('12 . . . 14 . . . 15 . . . . . . .'),
        P('14 . . . 12 . . . . . . . . . . .')],
    B: [P('19 . . . 17 . . 15 . . 17 . . . . .'),
        P('15 . . . 14 . . . 12 . . . . . . .'),
        P('17 . . . 19 . . 22 . . 19 . . . . .'),
        P('17 . . 15 . . 14 . . . . . . . . .')],
    C: [P('7 . . . . . 10 . . . . . 12 . . .'),
        P('10 . . . . . 7 . . . . . . . . .'),
        P('12 . . . . . 14 . . . . . 15 . . .'),
        P('14 . . . . . 12 . . . . . . . . .')],
    Bh: [P('12 . . . 10 . . 7 . . 10 . . . . .'),
         P('7 . . . 5 . . . 3 . . . . . . .'),
         P('10 . . . 12 . . 15 . . 12 . . . . .'),
         P('10 . . 7 . . 5 . . . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'oct', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'oct', gtr: 'pulse', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'pulse', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'oct', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'pulse', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- 3B: THE GLASS FLOOR --------------------------------------------------
const T_stage3b = {
  name: 'The Glass Floor', bpm: 116, key: 58, lkey: 70, swing: 0, echo: 1.5, level: 0.92,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3200, gain: -3 },
  bassVoice: 'syn', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'lead', harmStyle: 'stab',
  band: {
    kick: { deep: true }, snare: { fat: true }, clank: { ring: 0.8 },
    bass: { vol: 0.40, bright: 1300, close: 200, sub: 1.0 },
    gtr:  { vol: 0.12, tone: 4000, send: 0.48, echo: 0.36 },
    keys: { vol: 0.12, open: true, att: 0.9 },
    lead: { vol: 0.22, drive: 'clean', tone: 3300, send: 0.42, echo: 0.30, vib: 10 },
    harm: { vol: 0.095, bright: 3600, send: 0.38, echo: 0.30 },
    arp:  { vol: 0.075, wave: 'sine', tone: 3200, echo: 0.42 },
  },
  chords: {
    main: [[0, 'm9'], [-4, 'M9'], [-2, 'M'], [3, 'M7']],
    lift: [[-4, 'M9'], [-2, 'M'], [0, 'm9'], [5, 'm7']],
    turn: [[3, 'M7'], [-2, 'M'], [5, 'm7'], [0, 'm9']],
  },
  drums: {
    intro: { m: '........o.......', h: '..x...x...x...x.' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...xo', '..x...x...x...x.'],
      m: ['................', '............o...'],
    },
    push: {
      k: ['X.......X.......', 'X...x...X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'],
    },
    half: { k: 'X...............', m: '........o.......', h: '............o...' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . 10 .'), P('0 . . . . . . . 0 . . . 7 . . .')],
    oct:  [P('0 . . 12 . . 0 . 0 . . 12 . . 10 .'), P('0 . . 12 . . 0 . 0 . . 7 . . 5 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('12 . . . . . . . . . . . . . . .'), P('7 . . . . . . . . . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('7 . . . . . 10 . . . . . 12 . . .'),
        P('10 . . . . . 7 . . . . . . . . .'),
        P('12 . . . . . 14 . . . . . 15 . . .'),
        P('14 . . . . . 12 . . . . . . . . .')],
    B: [P('19 . . . . . 17 . . . 15 . . . 17 .'),
        P('15 . . . . . 14 . . . . . 12 . . .'),
        P('17 . . . . . 19 . . . 22 . . . 19 .'),
        P('17 . . . 15 . . . 14 . . . . . . .')],
    C: [P('0 . . . . . . . . . . . 3 . . .'),
        P('5 . . . . . . . . . . . . . . .'),
        P('7 . . . . . . . . . . . 10 . . .'),
        P('7 . . . . . . . 5 . . . . . . .')],
    Bh: [P('12 . . . . . 10 . . . 7 . . . 10 .'),
         P('7 . . . . . 5 . . . . . 3 . . .'),
         P('10 . . . . . 12 . . . 15 . . . 12 .'),
         P('10 . . . 7 . . . 5 . . . . . . .')],
  },
  arps: {
    slow: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    still: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'still', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'oct', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'oct', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', keys: 'hold', arp: 'slow', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'oct', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'still', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'A' },
  ],
};

// ---- BOSS 3: WRECKER MK-II -----------------------------------------------
// You do not beat the mech, you overheat it - and then Rivet bails out and you
// finish the man. The track is built the same way round: the machine has the
// tune for most of it, struck metal carrying the melody itself, and there is
// one section where all the machinery drops out and what is left is small and
// fast and running.
const T_boss3 = {
  name: 'Wrecker MK-II', bpm: 150, key: 58, lkey: 70, swing: 0, level: 0.90,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3000, gain: -3.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true }, clank: { ring: 0.40 },
    bass: { vol: 0.29, bright: 2900, close: 390 },
    gtr:  { vol: 0.175, drive: 'hot', tone: 3200 },
    keys: { vol: 0.06, tone: 2200, bars: [[1, 1], [2, 0.7], [3, 0.4], [4, 0.2]] },
    lead: { vol: 0.42, drive: 'hot', tone: 3700, wide: true, send: 0.20, echo: 0.10 },
    harm: { vol: 0.23, drive: 'crunch', tone: 3000, wide: true, send: 0.16, echo: 0.08 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3400, echo: 0.22 },
  },
  chords: {
    main: [[0, 'm'], [-1, 'M'], [-4, 'M'], [-5, 'M']],
    hard: [[0, '5'], [0, '5'], [-1, '5'], [-5, 'M']],
    turn: [[-4, 'M'], [-5, 'M'], [0, 'm'], [0, 'm']],
  },
  drums: {
    // the mech: metal on every off-beat, like something walking that should not
    intro: { k: 'X.......X.......', m: '..X...X...X...X.', h: 'xxxxxxxxxxxxxxxx', c: 'X...............' },
    mech: {
      k: ['X...x...X.......', 'X.......X...x...'],
      s: ['....X.......X...', '....X.......X.-x'],
      m: ['..x...X...x...X.', '..X...x...X...x.'],
      h: ['x.x.x.x.x.x.x.x.', 'x.xox.x.x.x.x.xo'],
    },
    grind: {
      k: ['X...x...X...x...', 'X..x....X...x..x'],
      s: ['....X.-.....X..x', '....X..x....X.Xx'],
      m: ['..X.x.X...X.x.X.', '..X...X.x.X...X.'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    // the pilot: no metal at all, just a man and a kit
    bail: {
      k: ['X..x..x.X..x..x.', 'X..x....X..x..x.'],
      s: ['....X..x....X..x', '....X.-.x...X.Xx'],
      h: 'x.x.x.x.x.x.x.x.',
    },
    half: { k: 'X.......x.......', m: '........X.......', t: '............x.o-' },
    fill: { k: 'X.......x...x...', s: '....X..xX.x.X.Xx', m: '..........X.-.X.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 12 . 0 . 11 0 . 0 12 . 7 . 5'), P('0 . 0 12 . 0 11 . 0 . 12 . 11 7 5 3')],
    grind: [P('0 0 . 0 12 . 0 0 . 12 . 0 11 . 7 .'), P('0 . 12 0 . 11 . 0 0 . 0 12 . 11 . 7')],
    run:  [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . 0 .'), P('0 . 0 . 0 . 0 . 12 . 12 . 11 . 7 .')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 11 . 0 0 . 0 . 3 0'), P('0 . 0 0 . 0 . 0 . 11 . 0 . 3 . 5')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    stab: [P('. . . 0 . . 0 . . . . 0 . . . .'), P('. . 0 . . . . 0 . . 0 . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('7 . 10 . 12 . 10 . 7 . . . 11 . . .'),
        P('12 . 14 . 15 . 14 . 12 . . . . . . .'),
        P('7 . 10 . 12 . 14 . 15 . 14 . 12 . 10 .'),
        P('11 . . 10 . 7 . . . . . . . . . .')],
    B: [P('15 . 17 . 19 . 17 . 15 . . . 14 . . .'),
        P('12 . 14 . 15 . 14 . 12 . . . . . . .'),
        P('19 . 20 . 22 . 20 . 19 . 17 . 15 . 17 .'),
        P('15 . . 14 . 12 . . 11 . . . . . . .')],
    // the pilot's section: the same hook, smaller and faster, no metal
    C: [P('7 10 12 . 10 7 . . 11 . . . . . . .'),
        P('12 14 15 . 14 12 . . . . . . . . . .'),
        P('7 10 12 14 15 14 12 10 . . 11 . . . . .'),
        P('10 . 7 . . . . . . . . . . . . .')],
    Bh: [P('19 . 22 . 24 . 22 . 19 . . . 17 . . .'),
         P('15 . 17 . 19 . 17 . 15 . . . . . . .'),
         P('22 . 24 . 26 . 24 . 22 . 20 . 19 . 20 .'),
         P('19 . . 17 . 15 . . 14 . . . . . . .')],
  },
  arps: { run: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 2, chords: 'hard', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power' },
    { bars: 4, chords: 'main', drums: 'mech', bass: 'main', gtr: 'riff', keys: 'stab' },
    { bars: 4, chords: 'main', drums: 'grind', bass: 'grind', gtr: 'riff', lead: 'A', keys: 'stab' },
    { bars: 4, chords: 'hard', drums: 'grind', bass: 'grind', gtr: 'riff', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'grind', bass: 'grind', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh', arp: 'run' },
    { bars: 1, chords: 'hard', drums: 'fill', bass: 'grind', gtr: 'stabs', gtrStyle: 'power' },
    // it overheats
    { bars: 2, chords: 'turn', drums: 'mech', bass: 'main', gtr: 'riff', keys: 'hold', gain: 0.8 },
    // and he runs
    { bars: 4, chords: 'main', drums: 'bail', bass: 'run', gtr: 'ring', gtrStyle: 'clean', lead: 'C', arp: 'run', gain: 0.88 },
    { bars: 4, chords: 'hard', drums: 'grind', bass: 'grind', gtr: 'riff', lead: 'B', harm: 'Bh', keys: 'stab' },
    { bars: 4, chords: 'main', drums: 'mech', bass: 'main', gtr: 'riff', lead: 'A', keys: 'stab' },
  ],
};

const STAGE3_TRACKS = { S3A: T_stage3a, S3B: T_stage3b, B3: T_boss3 };
