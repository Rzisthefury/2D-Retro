// ============================================================ STAGE 5, final
// H2 won. One thing had to change first: the melody I wrote for it was eight
// notes out of ten identical to stage 3's, in the same positions. Two stages
// with the same tune is a defect, so stage 5 gets its own - written to keep
// everything that was actually picked here (the liquid feel, the long lines,
// the warm sub under a fast break) and none of stage 3's shape.
//
//   STAGE 3 rose stepwise and stayed up:   7 10 12 | 10 7 | 12 14 15 | 14 12
//   STAGE 5 leans on the fourth and the flat sixth, and comes back down:
//       5 8 7 | 3 5 | 8 12 10 | 8 7 5
//
//   5A THE UNDERPASS - the same tune, enclosed. Lower, darker, busier break.
//   5B FAST LANE     - H2 as you heard it, with the new melody on top.
//   BOSS 5           - Vex. The tune stays beautiful and everything underneath
//                      it turns nasty, because she joins you afterwards.

// ---- 5A: THE UNDERPASS ----------------------------------------------------
const T_stage5a = {
  name: 'The Underpass', bpm: 174, key: 53, lkey: 65, swing: 0, level: 0.94,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3200, gain: -1.5 },
  bassVoice: 'reese', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'clean',
  band: {
    bass: { vol: 0.24, bright: 900, sweep: 420 },
    gtr:  { vol: 0.12, tone: 3800, send: 0.46, echo: 0.32 },
    keys: { vol: 0.105, open: false, att: 0.7 },
    lead: { vol: 0.32, bright: 4000, send: 0.36, echo: 0.30, wave: 'sawtooth' },
    harm: { vol: 0.13, tone: 4000, send: 0.42, echo: 0.28 },
    arp:  { vol: 0.10, wave: 'triangle', tone: 3800, echo: 0.40 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [-4, 'M'], [-2, 'M']],
    lift: [[-4, 'M'], [-2, 'M'], [0, 'm'], [3, 'M']],
    turn: [[5, 'm'], [-2, 'M'], [0, 'm'], [0, 'm']],
  },
  breaks: {
    roll: ['k.h.s.hk..hks.h.', 'k.h.s.h.k.hks.g.', '..hks.h.k.h.s.hk', 'k.h.s.hks.h.sgsg'],
    busy: ['k.hks.hk.ghks.h.', 'kghks.h.k.hks.hk', 'k.h.sghk..hks.hk', 'kgh.s.hksghkskgk'],
    drop: ['k.......s.......', '........s.......', 'k.......s......k', '........s...g.g.'],
    intro: ['k...............', 'k.......s.......', 'k.h.....s.......', 'k.h.s.h.s.h.sghk'],
  },
  drums: {},
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . . .'), P('0 . . . . . . . 10 . . . . . . .')],
    stab: [P('0 . . 0 . . . 0 . . 0 . . . 10 .'), P('0 . . 0 . . 10 . . . 0 . . 7 . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    stab: [P('. . . . 0 . . . . . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // THE HOOK, down an octave - in here it has a low ceiling
    A: [P('5 . . . . . 8 . . . . . 7 . . .'),
        P('3 . . . . . 5 . . . . . . . . .'),
        P('8 . . . . . 12 . . . . . 10 . . .'),
        P('8 . . . . . 7 . . . . . 5 . . .')],
    B: [P('3 . . 5 . 8 . . 7 . . . 5 . . .'),
        P('3 . . 0 . -2 . . -4 . . . . . . .'),
        P('5 . . 8 . 12 . . 10 . . . 8 . 7 .'),
        P('5 . . . 3 . . . 0 . . . . . . .')],
    C: [P('5 . . . . . . . 8 . . . . . . .'),
        P('3 . . . . . . . 5 . . . . . . .'),
        P('8 . . . . . . . 12 . . . . . . .'),
        P('7 . . . . . . . 5 . . . . . . .')],
    Bh: [P('10 . . 12 . 15 . . 14 . . . 12 . . .'),
         P('10 . . 7 . 5 . . 3 . . . . . . .'),
         P('12 . . 15 . 19 . . 17 . . . 15 . 14 .'),
         P('12 . . . 10 . . . 7 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', breaks: 'intro', bass: 'soft', keys: 'hold', gain: 0.82 },
    { bars: 4, chords: 'main', breaks: 'roll', bass: 'main', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', breaks: 'roll', bass: 'stab', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', breaks: 'busy', bass: 'stab', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', breaks: 'busy', bass: 'stab', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'B' },
    { bars: 4, chords: 'turn', breaks: 'drop', bass: 'stab', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', breaks: 'busy', bass: 'stab', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', breaks: 'roll', bass: 'main', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- 5B: FAST LANE --------------------------------------------------------
const T_stage5b = {
  name: 'Fast Lane', bpm: 174, key: 53, lkey: 65, swing: 0, echo: 1.5, level: 0.94,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3600, gain: 0 },
  bassVoice: 'sub', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'clean',
  band: {
    bass: { vol: 0.25, harm: 0.32 },
    gtr:  { vol: 0.13, tone: 4400, send: 0.50, echo: 0.36 },
    keys: { vol: 0.135, open: true, att: 0.9 },
    lead: { vol: 0.34, bright: 6000, send: 0.40, echo: 0.34, wave: 'sawtooth' },
    harm: { vol: 0.16, tone: 4600, send: 0.44, echo: 0.30 },
    arp:  { vol: 0.125, wave: 'triangle', tone: 4400, echo: 0.44 },
  },
  chords: {
    main: [[0, 'm9'], [3, 'M7'], [-4, 'M9'], [-2, 'M']],
    lift: [[-4, 'M9'], [-2, 'M'], [5, 'm7'], [0, 'm9']],
    turn: [[3, 'M7'], [5, 'm7'], [-2, 'M'], [0, 'm9']],
  },
  breaks: {
    roll: ['k.h.s.h.k.h.s.h.', 'k.h.s.h.k.hks.h.', 'k.h.s.h.k.h.s.hk', 'k.h.s.h.kgh.s.g.'],
    open: ['k.h.s.h.k.h.s.h.', '..h.s.h.k.h.s.h.', 'k.h.s.h.k.h.s.hk', 'k.hgs.h.k.h.sgh.'],
    drop: ['k.......s.......', '........s.......', 'k.......s.......', '........s...g...'],
    intro: ['................', 'k.......s.......', 'k.h.....s.......', 'k.h.s.h.k.h.s.h.'],
  },
  drums: {},
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . . .'), P('0 . . . . . . . 7 . . . . . . .')],
    roll: [P('0 . . 0 . . . 0 . . 0 . . . 10 .'), P('0 . . 0 . . 7 . . . 0 . . 5 . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('12 . . . . . . . . . . . . . . .'), P('7 . . . . . . . . . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // THE HOOK: the fourth, the flat sixth, and a fall back down
    A: [P('5 . . . . . 8 . . . . . 7 . . .'),
        P('3 . . . . . 5 . . . . . . . . .'),
        P('8 . . . . . 12 . . . . . 10 . . .'),
        P('8 . . . . . 7 . . . . . 5 . . .')],
    B: [P('15 . . . 17 . . . 19 . . 17 . . . .'),
        P('15 . . . 12 . . . 10 . . . . . . .'),
        P('17 . . . 19 . . . 20 . . 19 . . . .'),
        P('17 . . . 15 . . . 12 . . . . . . .')],
    C: [P('5 . . . . . . . 8 . . . . . . .'),
        P('3 . . . . . . . 5 . . . . . . .'),
        P('8 . . . . . . . 12 . . . . . . .'),
        P('7 . . . . . . . 5 . . . . . . .')],
    Bh: [P('10 . . . 12 . . . 15 . . 12 . . . .'),
         P('10 . . . 8 . . . 7 . . . . . . .'),
         P('12 . . . 15 . . . 17 . . 15 . . . .'),
         P('12 . . . 10 . . . 8 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', breaks: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', breaks: 'open', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', breaks: 'roll', bass: 'roll', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', breaks: 'roll', bass: 'roll', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', breaks: 'roll', bass: 'roll', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'turn', breaks: 'drop', bass: 'roll', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', breaks: 'roll', bass: 'roll', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', breaks: 'open', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- BOSS 5: VEX ---------------------------------------------------------
// She blinks behind you and throws knives, and when you beat her she comes
// over. So her theme does not turn the tune ugly - the melody stays exactly as
// beautiful as it is on the highway, and everything underneath it goes
// vicious: the Reese growls, the break doubles, the pads drop out. What she
// is doing is hostile. What she is is not.
const T_boss5 = {
  name: 'Vex', bpm: 176, key: 53, lkey: 65, swing: 0, level: 0.84,
  loopFrom: 1,              // the intro plays once, not every time round
  tone: { freq: 3400, gain: -1.5 },
  bassVoice: 'reese', gtrStyle: 'chug', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    bass: { vol: 0.26, bright: 700, sweep: 340 },
    gtr:  { vol: 0.17, drive: 'hot', tone: 2800 },
    keys: { vol: 0.085, open: false, att: 0.5 },
    lead: { vol: 0.34, bright: 6000, send: 0.40, echo: 0.32, wave: 'sawtooth' },
    harm: { vol: 0.20, drive: 'crunch', tone: 3400, wide: true, send: 0.24, echo: 0.14 },
    arp:  { vol: 0.10, wave: 'triangle', tone: 4200, echo: 0.40 },
  },
  chords: {
    main: [[0, 'm'], [-1, 'M'], [-4, 'M'], [0, 'm']],
    hard: [[0, '5'], [-1, '5'], [0, '5'], [-4, 'M']],
    turn: [[3, 'M7'], [-2, 'M'], [0, 'm9'], [0, 'm9']],
  },
  breaks: {
    hunt: ['k.hks.hk.ghks.hk', 'kghks.hkk.hks.hk', 'k.h.sghk..hks.hk', 'kghkskhksghkskgk'],
    stalk: ['k.......s...k...', '........s.......', 'k.....g.s...k...', '........s...g.g.'],
    full: ['kghkskhk.ghkskhk', 'kghkskhkkghkskhk', 'k.hkskhk.ghkskhk', 'kghkskgkkghkskgk'],
    intro: ['k...............', '........s.......', 'k.......s.......', 'kghkskhksghkskgk'],
  },
  drums: {},
  bass: {
    main: [P('0 . . . . . . . 0 . . . -1 . . .'), P('0 . . . . . . . -1 . . . . . . .')],
    grind: [P('0 . . 0 . . -1 . 0 . . 0 . -1 . 0'), P('0 . 0 . . -1 . 0 . . 0 . -4 . 0 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    grind: [P('. . . . 0 . . . . . . . 0 . . .'), P('. . . . 0 . . . 0 . . . . . 0 .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // her tune is the highway's tune, note for note. Nothing about the melody
    // knows it is a boss fight.
    A: [P('5 . . . . . 8 . . . . . 7 . . .'),
        P('3 . . . . . 5 . . . . . . . . .'),
        P('8 . . . . . 12 . . . . . 10 . . .'),
        P('8 . . . . . 7 . . . . . 5 . . .')],
    B: [P('15 . . . 17 . . . 19 . . 17 . . . .'),
        P('15 . . . 12 . . . 10 . . . . . . .'),
        P('17 . . . 19 . . . 20 . . 19 . . . .'),
        P('17 . . . 15 . . . 12 . . . . . . .')],
    C: [P('5 . . . . . . . 8 . . . . . . .'),
        P('3 . . . . . . . 5 . . . . . . .'),
        P('8 . . . . . . . 12 . . . . . . .'),
        P('7 . . . . . . . 5 . . . . . . .')],
    // the guitar is the part that is trying to kill you
    Bh: [P('5 . 8 . 7 . 5 . 3 . . . 5 . . .'),
         P('3 . 5 . 3 . 0 . -1 . . . . . . .'),
         P('8 . 12 . 10 . 8 . 7 . . . 8 . 7 .'),
         P('5 . 3 . 0 . -1 . 0 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 2, chords: 'hard', breaks: 'intro', bass: 'soft', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'main', breaks: 'hunt', bass: 'main', gtr: 'grind', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', breaks: 'hunt', bass: 'grind', gtr: 'grind', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'hard', breaks: 'full', bass: 'grind', gtr: 'grind', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', breaks: 'full', bass: 'grind', gtr: 'grind', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    // she stops moving for two bars and you can hear what the tune really is
    { bars: 2, chords: 'turn', breaks: 'stalk', bass: 'main', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'hard', breaks: 'full', bass: 'grind', gtr: 'grind', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'main', breaks: 'hunt', bass: 'main', gtr: 'grind', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
  ],
};

const STAGE5_TRACKS = { S5A: T_stage5a, S5B: T_stage5b, B5: T_boss5 };
