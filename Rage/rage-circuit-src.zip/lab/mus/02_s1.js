// ============================================================ STAGE 1 options
// UNDER THE EL. Four takes on the same scene, each with a different band, so
// picking one settles both this track and the house sound for the other 23.
// Key is A minor throughout: key 57 puts the bass on A1, keys on A4 and the
// lead on A4-E6, which is where a guitar actually lives.

// ---- 1. STREET ROCK -------------------------------------------------------
// An overdriven guitar carries the tune over palm-muted eighths and a picked
// bass. The most straightforward reading: a rock band playing a fight scene.
const S1_ROCK = {
  name: 'Street Rock', bpm: 142, key: 57, lkey: 69, swing: 0.06,
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'clean',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.34, bright: 2400, close: 300 },
    gtr:  { vol: 0.21, drive: 'hot', tone: 2400 },
    keys: { vol: 0.055, tone: 2400 },
    lead: { vol: 0.33, drive: 'crunch', tone: 3800, send: 0.22, echo: 0.14 },
    harm: { vol: 0.12, tone: 3800 },
    arp:  { vol: 0.05 },
  },
  chords: {
    main: [[0, 'm'], [-4, 'M'], [-2, 'M'], [0, 'm']],
    lift: [[-4, 'M'], [-2, 'M'], [0, 'm'], [0, 'm']],
    turn: [[0, 'm'], [3, 'M'], [-2, 'M'], [-5, 'M']],
  },
  drums: {
    intro: { k: 'X.......X.....x.', s: '............X...', h: 'x.x.x.x.x.x.x.xo' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.xox.x.x.xox.x.'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X.-.'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '....o.......o...' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . 0 . . 12 . 0 . . 7 . . 10 .'), P('0 . 0 . 12 . 0 . 0 . . 10 . 7 . 5')],
    drive: [P('0 . 0 12 . 0 . 7 0 . 0 12 . 10 . 7'), P('0 0 . 12 . 0 10 . 0 . 12 . 10 . 7 .')],
    soft: [P('0 . . . . . . . 12 . . . . . . .'), P('0 . . . . . . . 7 . . . . . . .')],
  },
  gtr: {
    chug: [P('0 . 0 0 . 0 . 0 . 0 0 . 0 . 3 5'), P('0 . 0 0 . 0 . 0 . 0 . 3 . 5 . 7')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .'), P('0 . . . . . 0 . 0 . . . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // the hook: rises, answers itself, then falls back where it started
    A: [P('0 . . 3 . 5 . 7 . . 5 . 3 . 0 .'),
        P('7 . . 5 . 7 . 10 . . . . . . . .'),
        P('12 . . 10 . 7 . 5 . . 7 . 5 . 3 .'),
        P('3 . . . 2 . 0 . . . . . . . . .')],
    // the chorus: same shape an octave up, held longer
    B: [P('12 . 12 . 15 . 14 . 12 . . . 10 . . .'),
        P('10 . 10 . 12 . 10 . 7 . . . . . . .'),
        P('12 . 12 . 15 . 17 . 19 . . . 17 . 15 .'),
        P('14 . . . 12 . . . 10 . . . . . . .')],
    // a quiet restatement for the breakdown
    C: [P('0 . . . 3 . . . 5 . . . 7 . . .'),
        P('5 . . . 3 . . . 0 . . . . . . .'),
        P('7 . . . 10 . . . 12 . . . 10 . . .'),
        P('7 . . . . . 5 . 3 . . . . . . .')],
    // the harmony line, a third under the chorus
    Bh: [P('7 . 7 . 10 . 8 . 7 . . . 5 . . .'),
         P('5 . 5 . 7 . 5 . 3 . . . . . . .'),
         P('7 . 7 . 10 . 12 . 15 . . . 12 . 10 .'),
         P('10 . . . 7 . . . 5 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'chug' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'chug', lead: 'A', keys: 'hold' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'chug', lead: 'A', keys: 'hold' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', lead: 'C', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'chug', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'chug', lead: 'A', keys: 'hold' },
  ],
};

// ---- 2. NEON FUSION -------------------------------------------------------
// Electric piano and a clean chorused guitar trade the melody over a rounder
// bass and a lighter kit. Seventh chords throughout - the warmest of the four
// and the closest to what Streets of Rage 2 actually sounded like.
const S1_FUSION = {
  name: 'Neon Fusion', bpm: 126, key: 57, lkey: 69, swing: 0.14,
  bassVoice: 'pick', gtrStyle: 'clean', keyStyle: 'ep', leadStyle: 'clean', harmStyle: 'ep',
  band: {
    kick: {}, snare: { rim: false },
    bass: { vol: 0.32, bright: 1500, close: 260 },
    gtr:  { vol: 0.13, tone: 4000, send: 0.36, echo: 0.20 },
    keys: { vol: 0.115, bite: 2.4, tone: 3600 },
    lead: { vol: 0.21, tone: 4400, send: 0.38, echo: 0.24 },
    harm: { vol: 0.10, bite: 1.6 },
    arp:  { vol: 0.07, wave: 'sine' },
  },
  chords: {
    main: [[0, 'm9'], [5, 'm7'], [-2, '7'], [3, 'M7']],
    turn: [[3, 'M7'], [-4, 'M7'], [-2, '7'], [0, 'm9']],
    lift: [[5, 'm7'], [-2, '7'], [0, 'm9'], [0, 'm9']],
  },
  drums: {
    intro: { k: 'X.......x.......', s: '............-...', h: '..x...x...x...x.' },
    main: {
      k: ['X.....x.....x...', 'X.......x.x.....'],
      s: ['....X.......X...', '....X...-...X.-.'],
      h: ['x.xox.x.x.xox.x.', 'x.x.x.xox.x.x.xo'],
    },
    ride: {
      k: ['X.....x...x.....', 'X.......x.....x.'],
      s: ['....X.......X.-.', '....X.-.....X...'],
      r: ['x.x.X.x.x.x.X.x.', 'x.x.x.x.X.x.x.x.'],
    },
    half: { k: 'X...............', s: '........X.......', h: '......o.......o.' },
    fill: { k: 'X.......x.......', s: '....X.-.x.X.x.Xx', t: '..........o.-...' },
  },
  bass: {
    main: [P('0 . . 12 . . 10 . 7 . . 0 . 3 . 5'), P('0 . 10 . 12 . . 7 . . 5 . 3 . 2 .')],
    walk: [P('0 . 2 . 3 . 5 . 7 . 5 . 3 . 2 .'), P('0 . 12 . 10 . 7 . 5 . 3 . 2 . 0 .')],
    soft: [P('0 . . . . . . 12 . . . . . . . .'), P('0 . . . . . . 7 . . . . . . . .')],
  },
  gtr: {
    comp: [P('. . 0 . . . 0 . . . . 0 . . 0 .'), P('. . 0 . . 0 . . . . 0 . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    comp: [P('0 . . . . 0 . . . 0 . . . . 0 .'), P('0 . . 0 . . . 0 . . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('0 . 3 . 5 . . 7 . 5 . 3 . . 2 .'),
        P('3 . . 5 . 7 . . 10 . . . . . . .'),
        P('12 . 10 . 7 . . 10 . 7 . 5 . . 3 .'),
        P('5 . . . 3 . 2 . 0 . . . . . . .')],
    B: [P('14 . . 12 . 10 . . 12 . . . . . . .'),
        P('10 . . 12 . 14 . . 15 . 14 . 12 . . .'),
        P('17 . . 15 . 14 . . 12 . . 10 . . 12 .'),
        P('14 . . . . . 12 . . . . . . . . .')],
    C: [P('7 . . . 10 . . . 12 . . . 10 . . .'),
        P('7 . . . 5 . . . 3 . . . . . . .'),
        P('10 . . . 12 . . . 14 . . . 12 . . .'),
        P('10 . . . . . 7 . . . . . . . . .')],
    Ah: [P('. . 0 . 0 . . 3 . 0 . 0 . . 10 .'),
         P('0 . . 0 . 3 . . 5 . . . . . . .'),
         P('7 . 5 . 3 . . 5 . 3 . 0 . . 10 .'),
         P('0 . . . 10 . 10 . 7 . . . . . . .')],
  },
  arps: { soft: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'soft', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'comp', keys: 'comp' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'comp', keys: 'comp', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'ride', bass: 'walk', gtr: 'comp', keys: 'comp', lead: 'A', harm: 'Ah' },
    { bars: 4, chords: 'main', drums: 'ride', bass: 'walk', keys: 'comp', lead: 'B', arp: 'soft' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'walk', keys: 'comp' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'soft', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'ride', bass: 'walk', gtr: 'comp', keys: 'comp', lead: 'B', harm: 'Ah' },
    { bars: 4, chords: 'turn', drums: 'main', bass: 'main', gtr: 'comp', keys: 'comp', lead: 'A' },
  ],
};

// ---- 3. SYNTHWAVE DRIVE ---------------------------------------------------
// Analog pads and a running arpeggio carry the harmony; the guitar plays a
// counter-line rather than the tune. Big sub, gated snare, and the melody up
// front on a bright poly synth. Driving without ever being techno.
const S1_SYNTH = {
  name: 'Synthwave Drive', bpm: 132, key: 57, lkey: 69, swing: 0,
  bassVoice: 'syn', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    bass: { vol: 0.36, bright: 1500, close: 220, sub: 1.0 },
    gtr:  { vol: 0.135, tone: 4600, send: 0.40, echo: 0.28 },
    keys: { vol: 0.100, open: true, att: 0.5 },
    lead: { vol: 0.23, bright: 6200, send: 0.30, echo: 0.26, wave: 'sawtooth' },
    harm: { vol: 0.15, drive: 'crunch', tone: 3400, send: 0.30, echo: 0.20 },
    arp:  { vol: 0.100, wave: 'triangle', tone: 4200, echo: 0.3 },
  },
  chords: {
    main: [[0, 'm'], [3, 'M'], [-2, 'M'], [5, 'm']],
    lift: [[-4, 'M'], [3, 'M'], [0, 'm'], [-2, 'M']],
    turn: [[5, 'm'], [-2, 'M'], [3, 'M'], [0, 'm']],
  },
  drums: {
    intro: { k: 'X.......X.......', h: '..x...x...x...x.' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...x.', '..x...x...x...xo'],
    },
    push: {
      k: ['X.......X.......', 'X...x...X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '............o...' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . 0 . . . 0 . . . 0 . 0 .'), P('0 . . . 0 . . . 0 . . 0 . 0 . 0')],
    oct:  [P('0 . 12 . 0 . 12 . 0 . 12 . 0 . 12 .'), P('0 . 12 . 0 . 12 . 0 . 12 . 10 . 7 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    counter: [P('. . . . 12 . 10 . . . . . 7 . . .'), P('. . . . 10 . 7 . . . . . 5 . 3 .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('12 . . . 10 . 12 . . . 15 . 14 . 12 .'),
        P('10 . . . 7 . 10 . . . . . . . . .'),
        P('12 . . . 14 . 15 . . . 17 . . . 15 .'),
        P('14 . . . 12 . 10 . . . . . . . . .')],
    B: [P('19 . . 17 . 15 . . 17 . . . 19 . . .'),
        P('15 . . 14 . 12 . . 10 . . . . . . .'),
        P('19 . . 17 . 19 . . 22 . . . 19 . 17 .'),
        P('15 . . . 17 . . . 12 . . . . . . .')],
    C: [P('0 . . . . . 3 . . . 7 . . . . .'),
        P('5 . . . . . 3 . . . 0 . . . . .'),
        P('7 . . . . . 10 . . . 12 . . . . .'),
        P('10 . . . . . 7 . . . . . . . . .')],
    Bh: [P('12 . . 10 . 7 . . 10 . . . 12 . . .'),
         P('7 . . 5 . 3 . . 0 . . . . . . .'),
         P('12 . . 10 . 12 . . 15 . . . 12 . 10 .'),
         P('7 . . . 10 . . . 5 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.82 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'oct', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'oct', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'counter', keys: 'hold', arp: 'run', lead: 'B' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'oct', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'counter', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- 4. HEAVY GROOVE ------------------------------------------------------
// Two detuned guitars playing the riff itself, organ stabs filling underneath,
// and a kit that leans on the backbeat rather than marching. The dirtiest of
// the four, and the kit closest to what the drum and bass stage will need.
const S1_HEAVY = {
  name: 'Heavy Groove', bpm: 150, key: 57, lkey: 69, swing: 0.10,
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    bass: { vol: 0.36, bright: 2600, close: 340 },
    gtr:  { vol: 0.27, drive: 'fuzz', tone: 2600 },
    keys: { vol: 0.07, tone: 2000, bars: [[1, 1], [2, 0.7], [3, 0.5], [4, 0.2]] },
    lead: { vol: 0.35, drive: 'hot', tone: 3500, wide: true, send: 0.20, echo: 0.10 },
    harm: { vol: 0.20, drive: 'hot', tone: 3200, wide: true, send: 0.16, echo: 0.08 },
    arp:  { vol: 0.05 },
  },
  chords: {
    main: [[0, '5'], [0, '5'], [-4, '5'], [-5, 'M']],
    lift: [[-2, '5'], [-4, '5'], [0, '5'], [0, '5']],
    turn: [[0, 'm'], [-5, 'M'], [-4, 'M'], [-2, 'M']],
  },
  drums: {
    intro: { k: 'X..x....X.......', s: '............X...', h: 'x.x.x.x.x.x.x.x.' },
    main: {
      k: ['X..x....X...x...', 'X..x..x.X.......'],
      s: ['....X.-.....X...', '....X.......X.-x'],
      h: ['x.x.x.xox.x.x.x.', 'x.xox.x.x.x.x.xo'],
    },
    push: {
      k: ['X..x..x.X..x....', 'X..x....X..x..x.'],
      s: ['....X.-.-...X..x', '....X..x....X.Xx'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    half: { k: 'X.......x.......', s: '........X.......', h: '....o.......o...' },
    fill: { k: 'X.......x...x...', s: '....X..xX.x.X.Xx', t: '..........o.-.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 12 . 0 . 10 0 . 0 12 . 7 . 5'), P('0 . 0 12 . 0 10 . 0 . 12 . 10 7 5 3')],
    grind: [P('0 0 . 0 12 . 0 0 . 12 . 0 10 . 7 .'), P('0 . 12 0 . 10 . 0 0 . 0 12 . 10 . 7')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 5 . 3 .'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 7 . 5')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    stab: [P('. . . 0 . . 0 . . . . 0 . . . .'), P('. . 0 . . . . 0 . . 0 . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('0 . 3 . 5 . . 3 . 0 . . 10 . . .'),
        P('0 . 3 . 5 . 7 . . . 5 . 3 . . .'),
        P('7 . 5 . 3 . . 5 . 7 . . 10 . . .'),
        P('12 . . . 10 . 7 . 5 . . . . . . .')],
    B: [P('12 . . 15 . 12 . . 10 . 12 . . . . .'),
        P('12 . . 10 . 7 . . 5 . . . . . . .'),
        P('15 . . 17 . 15 . . 12 . 15 . 17 . . .'),
        P('19 . . . 17 . 15 . 12 . . . . . . .')],
    C: [P('0 . . . . . . . 3 . . . . . . .'),
        P('5 . . . . . 3 . 0 . . . . . . .'),
        P('7 . . . . . . . 10 . . . . . . .'),
        P('7 . . . 5 . . . . . . . . . . .')],
    Bh: [P('19 . . 22 . 19 . . 17 . 19 . . . . .'),
         P('19 . . 17 . 15 . . 12 . . . . . . .'),
         P('22 . . 24 . 22 . . 19 . 22 . 24 . . .'),
         P('26 . . . 24 . 22 . 19 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 0, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'stab' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'A', keys: 'stab' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'grind', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh', keys: 'stab' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'grind', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', lead: 'C', keys: 'hold', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'grind', gtr: 'riff', lead: 'B', harm: 'Bh', keys: 'stab' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'stab' },
  ],
};

const S1_OPTIONS = { M1: S1_ROCK, M2: S1_FUSION, M3: S1_SYNTH, M4: S1_HEAVY };
