// ============================================================ STAGE 6 options
// SYNDICATE WORKS, and the first three-scene stage in this pass. The rooms are
// as different as any in the game:
//   THE CAST HOUSE  - a river of molten metal across the floor, ladle cars on
//                     rails above it, everything orange.
//   THE LINE        - robot welding arms throwing sparks over a conveyor. Cold,
//                     blue, precise, and not remotely human.
//   THE TORPEDO YARD - huge ladle vessels in the dark, glowing at the ends.
//
// After five stages of heavy bottom end this one is meant to be HOT rather
// than heavy, so C minor: the highest key in the run, which puts the melody up
// where heat lives instead of down where weight does.
//
// Mix targets set before writing rather than corrected after: mid 12-20%, sub
// under 35%, lead 0.30-0.36, bass 0.28-0.34.

// ---- F1: THE CAST HOUSE ---------------------------------------------------
// Heat. Fast, bright, and the most aggressive guitar in the game so far, over
// scaffold metal and a furnace roaring underneath it all.
const S6_CAST = {
  name: 'The Cast House', bpm: 158, key: 60, lkey: 72, swing: 0.04, level: 0.99,
  tone: { freq: 3300, gain: -2 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    clank: { ring: 0.20 }, hiss: { vol: 0.10, f0: 900, f1: 260 },
    bass: { vol: 0.32, bright: 2700, close: 360 },
    gtr:  { vol: 0.21, drive: 'hot', tone: 2800 },
    keys: { vol: 0.06, tone: 2400 },
    lead: { vol: 0.34, drive: 'hot', tone: 3600, send: 0.22, echo: 0.12 },
    harm: { vol: 0.20, drive: 'crunch', tone: 3100, send: 0.18, echo: 0.10 },
    arp:  { vol: 0.055 },
  },
  chords: {
    main: [[0, 'm'], [-2, 'M'], [0, 'm'], [-4, 'M']],
    lift: [[-4, 'M'], [-2, 'M'], [3, 'M'], [0, 'm']],
    turn: [[5, 'm'], [-4, 'M'], [-2, 'M'], [0, 'm']],
  },
  drums: {
    intro: { k: 'X.......X.......', m: '....x.......x...', a: 'X...............', h: 'x.x.x.x.x.x.x.x.' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.xox.x.x.xox.x.'],
      m: ['..x.......x.....', '..x...o...x...o.'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X.-.'],
      h: 'xxxxxxxxxxxxxxxx',
      m: ['..x...X...x...o.', '..X.......x.o.x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', a: '........x.......', m: '........X.......' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', m: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 12 . 0 . 10 0 . 0 12 . 7 . 5'), P('0 . 0 . 12 . 0 . 0 . . 10 . 7 . 5')],
    drive: [P('0 0 . 0 12 . 0 0 . 12 . 0 10 . 7 .'), P('0 . 12 0 . 10 . 0 0 . 0 12 . 10 . 7')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 0 . 5 3'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 3 . 0')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // starts high and falls, which no other stage in the game does
    A: [P('12 . . 10 . . 7 . . . 12 . . . 10 .'),
        P('15 . . . 12 . 10 . . . . . . . . .'),
        P('7 . . 10 . 12 . . 15 . . . 17 . . .'),
        P('15 . . 12 . 10 . . . . . . . . . .')],
    B: [P('19 . . 17 . 15 . . 17 . 19 . . . 20 .'),
        P('17 . . 15 . 12 . . 10 . . . . . . .'),
        P('19 . . 22 . 24 . . 22 . 19 . 17 . 19 .'),
        P('20 . . . 17 . 15 . 12 . . . . . . .')],
    C: [P('12 . . . 10 . . . 7 . . . 12 . . .'),
        P('15 . . . 12 . . . 10 . . . . . . .'),
        P('7 . . . 10 . . . 12 . . . 15 . . .'),
        P('12 . . . 10 . . . . . . . . . . .')],
    Bh: [P('15 . . 12 . 10 . . 12 . 15 . . . 17 .'),
         P('12 . . 10 . 7 . . 5 . . . . . . .'),
         P('15 . . 17 . 19 . . 17 . 15 . 12 . 15 .'),
         P('17 . . . 12 . 10 . 7 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'hold' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', lead: 'C', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'hold' },
  ],
};

// ---- F2: ROBOT LINE -------------------------------------------------------
// Written for the welding arms. Everything sits exactly on the grid - no
// swing, no human timing anywhere in it - and the melody is played by a
// sequencer rather than a player. Cold and blue where the cast house is
// orange, and the guitar only appears to do the one thing robots cannot.
const S6_LINE = {
  name: 'Robot Line', bpm: 144, key: 60, lkey: 72, swing: 0, level: 0.92,
  tone: { freq: 3300, gain: -2.5 },
  bassVoice: 'syn', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: false },
    clank: { ring: 0.07 },
    bass: { vol: 0.38, bright: 1700, close: 230 },
    gtr:  { vol: 0.16, drive: 'hot', tone: 3000 },
    keys: { vol: 0.065, bright: 4000, wave: 'sawtooth' },
    lead: { vol: 0.30, bright: 4600, send: 0.24, echo: 0.22, wave: 'sawtooth' },
    harm: { vol: 0.14, drive: 'crunch', tone: 3000, send: 0.20, echo: 0.12 },
    arp:  { vol: 0.075, wave: 'triangle', tone: 3800, echo: 0.20 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [3, 'M'], [-2, 'M']],
    lift: [[3, 'M'], [-2, 'M'], [0, 'm'], [0, 'm']],
    turn: [[5, 'm'], [3, 'M'], [-2, 'M'], [0, 'm']],
  },
  drums: {
    // a machine does not push or drag. Every hit is exactly where it says.
    intro: { m: 'x...x...x...x...', h: 'x.x.x.x.x.x.x.x.' },
    main: {
      k: ['X.......X.......', 'X.......X.......'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'x.x.x.x.x.x.x.x.',
      m: ['..x...x...x...x.', '..x...x...x...x.'],
    },
    push: {
      k: ['X...X...X...X...', 'X...X...X...X...'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'xxxxxxxxxxxxxxxx',
      m: ['x.x.x.x.x.x.x.x.', 'x.x.x.x.x.x.x.x.'],
    },
    half: { k: 'X.......X.......', m: '....x.......x...' },
    fill: { k: 'X...X...X...X...', s: '....X...X...X.XX', m: 'x.x.x.x.x.x.xxxx' },
  },
  bass: {
    main: [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . 0 .'), P('0 . 0 . 0 . 0 . 0 . 0 . 10 . 10 .')],
    step: [P('0 . 0 . 3 . 3 . 5 . 5 . 7 . 7 .'), P('0 . 0 . 10 . 10 . 7 . 7 . 5 . 3 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    // the one thing a robot cannot do: bend a note
    human: [P('. . . . . . . . 0 . . . . . 3 .'), P('. . . . . . . . 3 . . . . . 0 .')],
    riff: [P('0 . 0 . 0 . 0 . 0 . 0 . 0 . 0 .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    pulse: [P('0 . . . 0 . . . 0 . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('0 . 3 . 0 . 3 . 0 . 3 . 0 . 3 .'),
        P('5 . 3 . 5 . 3 . 5 . 3 . 5 . 3 .'),
        P('7 . 10 . 7 . 10 . 7 . 10 . 7 . 10 .'),
        P('12 . 10 . 7 . 3 . 0 . . . . . . .')],
    B: [P('19 . 17 . 19 . 22 . 19 . . . 17 . . .'),
        P('15 . 17 . 15 . 12 . 10 . . . . . . .'),
        P('19 . 22 . 24 . 22 . 19 . 17 . 19 . . .'),
        P('17 . 15 . 12 . . . . . . . . . . .')],
    C: [P('0 . . . 3 . . . 0 . . . 3 . . .'),
        P('5 . . . 3 . . . 5 . . . 3 . . .'),
        P('7 . . . 10 . . . 7 . . . 10 . . .'),
        P('3 . . . 0 . . . . . . . . . . .')],
    Bh: [P('15 . 12 . 15 . 17 . 15 . . . 12 . . .'),
         P('12 . 12 . 10 . 7 . 5 . . . . . . .'),
         P('15 . 17 . 19 . 17 . 15 . 12 . 15 . . .'),
         P('12 . 10 . 7 . . . . . . . . . . .')],
  },
  arps: {
    seq:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.82 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', keys: 'pulse', arp: 'seq' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'step', keys: 'pulse', arp: 'seq', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'step', gtr: 'human', keys: 'pulse', arp: 'seq', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'step', gtr: 'human', keys: 'pulse', arp: 'seq', lead: 'B' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'step', keys: 'pulse' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'step', gtr: 'human', keys: 'pulse', arp: 'seq', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', keys: 'pulse', arp: 'seq', lead: 'A' },
  ],
};

// ---- F3: POUR -------------------------------------------------------------
// The torpedo yard, and the weight of the stuff they move around in it.
// Half-time at 132 so it drags, with the furnace roaring long underneath and
// the metal ringing a very long way off. Not impact like the pile driver was:
// mass, and heat, and no hurry at all.
const S6_POUR = {
  name: 'Pour', bpm: 132, key: 60, lkey: 72, swing: 0, echo: 1.4, level: 0.90,
  tone: { freq: 3100, gain: -2.5 },
  bassVoice: 'sub', gtrStyle: 'chug', keyStyle: 'pad', leadStyle: 'lead', harmStyle: 'stab',
  band: {
    kick: { deep: true }, snare: { fat: true },
    clank: { ring: 1.1 }, hiss: { vol: 0.14, f0: 700, f1: 200 },
    bass: { vol: 0.30, harm: 0.26 },
    gtr:  { vol: 0.19, drive: 'hot', tone: 2500 },
    keys: { vol: 0.10, open: false, att: 1.0 },
    lead: { vol: 0.33, drive: 'crunch', tone: 3400, wide: true, send: 0.42, echo: 0.26 },
    harm: { vol: 0.13, bright: 4200, send: 0.38, echo: 0.30 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3200, echo: 0.40 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [-4, 'M'], [-2, 'M']],
    lift: [[-4, 'M'], [-2, 'M'], [0, 'm'], [3, 'M']],
    turn: [[3, 'M'], [-2, 'M'], [5, 'm'], [0, 'm']],
  },
  drums: {
    intro: { a: 'X...............', m: '........o.......' },
    main: {
      k: ['X.......X.......', 'X.......X.......'],
      s: ['............X...', '............X...'],
      m: ['....o.......x...', '....o...........'],
      h: ['..x...x...x...x.', '..x...x...x...xo'],
      a: ['................', 'x...............'],
    },
    push: {
      k: ['X.......X.....x.', 'X...x...X.......'],
      s: ['............X...', '....-.......X...'],
      m: ['....o...x...o...', '..x.o.......x.o.'],
      h: 'x.x.x.x.x.x.x.x.', c: ['X...............', '................'],
    },
    half: { k: 'X...............', a: '........X.......', m: '........o.......' },
    fill: { k: 'X.......x.......', s: '....X.......X.Xx', m: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . . .'), P('0 . . . . . . . 10 . . . . . . .')],
    roll: [P('0 . . 0 . . . 0 . . 0 . . . 10 .'), P('0 . . 0 . . 10 . . . 0 . . 7 . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    grind: [P('. . . . 0 . . . . . . . 0 . . .'), P('. . . . 0 . . . 0 . . . . . 0 .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . . . . . . 12 . . . . . . .'),
        P('7 . . . . . . . . . . . . . . .'),
        P('15 . . . . . . . 10 . . . . . . .'),
        P('3 . . . . . . . 7 . . . . . . .')],
    B: [P('19 . . . 17 . . . 15 . . . 17 . . .'),
        P('15 . . . 12 . . . 10 . . . . . . .'),
        P('17 . . . 19 . . . 22 . . . 19 . . .'),
        P('17 . . . 15 . . . 12 . . . . . . .')],
    C: [P('0 . . . . . . . . . . . . . . .'),
        P('12 . . . . . . . . . . . . . . .'),
        P('7 . . . . . . . . . . . . . . .'),
        P('3 . . . . . . . . . . . . . . .')],
    Bh: [P('15 . . . 12 . . . 10 . . . 12 . . .'),
         P('10 . . . 7 . . . 5 . . . . . . .'),
         P('12 . . . 15 . . . 17 . . . 15 . . .'),
         P('12 . . . 10 . . . 7 . . . . . . .')],
  },
  arps: { slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'grind', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'roll', gtr: 'grind', keys: 'hold', arp: 'slow', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'roll', gtr: 'grind', keys: 'hold', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'roll', gtr: 'grind', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'roll', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'roll', gtr: 'grind', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'grind', keys: 'hold', lead: 'A', arp: 'slow' },
  ],
};

// ---- F4: HEAT HAZE --------------------------------------------------------
// The wildcard: the works at the end of a shift. Everything still glowing,
// nothing still running. Wide, shimmering, and almost beautiful, with the
// metal ringing a long way off and the furnace breathing rather than roaring.
// The calm option, which has won twice already.
const S6_HAZE = {
  name: 'Heat Haze', bpm: 120, key: 60, lkey: 72, swing: 0, echo: 1.6, level: 0.92,
  tone: { freq: 3200, gain: -3 },
  bassVoice: 'syn', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'lead', harmStyle: 'stab',
  band: {
    kick: { deep: true }, snare: { fat: true },
    clank: { ring: 1.3 }, hiss: { vol: 0.09, f0: 1400, f1: 400 },
    bass: { vol: 0.40, bright: 1400, close: 210, sub: 1.0 },
    gtr:  { vol: 0.14, tone: 4400, send: 0.50, echo: 0.38 },
    keys: { vol: 0.125, open: true, att: 1.0 },
    lead: { vol: 0.24, drive: 'clean', tone: 3000, send: 0.44, echo: 0.32, vib: 10 },
    harm: { vol: 0.09, bright: 3200, send: 0.40, echo: 0.32 },
    arp:  { vol: 0.075, wave: 'sine', tone: 3000, echo: 0.44 },
  },
  chords: {
    main: [[0, 'm9'], [-2, 'M'], [3, 'M7'], [-4, 'M9']],
    lift: [[3, 'M7'], [-4, 'M9'], [5, 'm7'], [0, 'm9']],
    turn: [[5, 'm7'], [-2, 'M'], [-4, 'M9'], [0, 'm9']],
  },
  drums: {
    intro: { a: 'X...............', m: '........o.......' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...xo', '..x...x...x...x.'],
      m: ['................', '............o...'],
    },
    push: {
      k: ['X.......X.......', 'X...x...X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'],
    },
    half: { k: 'X...............', m: '........o.......', a: '........x.......' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . 10 .'), P('0 . . . . . . . 0 . . . 7 . . .')],
    oct:  [P('0 . . 12 . . 0 . 0 . . 12 . . 10 .'), P('0 . . 12 . . 0 . 0 . . 7 . . 5 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('12 . . . . . . . . . . . . . . .'), P('7 . . . . . . . . . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('7 . . . . . 8 . . . . . 10 . . .'),
        P('8 . . . . . 7 . . . . . . . . .'),
        P('10 . . . . . 15 . . . . . 12 . . .'),
        P('10 . . . . . 12 . . . . . 15 . . .')],
    B: [P('19 . . . . . 17 . . . 15 . . . 17 .'),
        P('15 . . . . . 12 . . . . . 10 . . .'),
        P('17 . . . . . 19 . . . 22 . . . 19 .'),
        P('15 . . . 12 . . . 10 . . . . . . .')],
    C: [P('7 . . . . . . . . . . . 8 . . .'),
        P('10 . . . . . . . . . . . . . . .'),
        P('8 . . . . . . . . . . . 10 . . .'),
        P('7 . . . . . . . 5 . . . . . . .')],
    Bh: [P('12 . . . . . 10 . . . 7 . . . 10 .'),
         P('7 . . . . . 5 . . . . . 3 . . .'),
         P('10 . . . . . 12 . . . 15 . . . 12 .'),
         P('10 . . . 7 . . . 5 . . . . . . .')],
  },
  arps: {
    slow: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    still: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'still', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'slow' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'oct', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'oct', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', keys: 'hold', arp: 'slow', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'oct', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'still', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'slow', lead: 'A' },
  ],
};

const S6_OPTIONS = { F1: S6_CAST, F2: S6_LINE, F3: S6_POUR, F4: S6_HAZE };
