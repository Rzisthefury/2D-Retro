// ============================================================ STAGE 4 options
// LAST TRAIN. The Roundhouse is a locomotive shed - two engines standing over
// inspection pits, roof trusses, one lamp, a standpipe. The Bridge Run is on
// top of a moving freight crossing a trestle at night, water underneath and
// the bridge structure flicking past. So the stage goes from completely still
// to not stopping, which is the arc the music should take.
//
// Ab minor: darker than anything so far and it puts the bass at 52Hz, which is
// where a train belongs. The kit gains air - brake release and steam.

// ---- R1: THE ROUNDHOUSE ---------------------------------------------------
// The shed. Enormous, empty and patient: a riff that starts as machinery
// idling over a long reverb and slowly works out that it is a song.
const S4_SHED = {
  name: 'The Roundhouse', bpm: 126, key: 56, lkey: 68, swing: 0.08, level: 0.90,
  tone: { freq: 3200, gain: -2 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    clank: { ring: 0.9 }, hiss: { vol: 0.15, f0: 2200, f1: 700 },
    bass: { vol: 0.34, bright: 2200, close: 280 },
    gtr:  { vol: 0.20, drive: 'hot', tone: 2400 },
    keys: { vol: 0.07, tone: 2100 },
    lead: { vol: 0.32, drive: 'crunch', tone: 3400, send: 0.38, echo: 0.20 },
    harm: { vol: 0.17, drive: 'crunch', tone: 2800, send: 0.30, echo: 0.14 },
    arp:  { vol: 0.055 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm'], [-2, 'M'], [-4, 'M']],
    lift: [[-4, 'M'], [-2, 'M'], [0, 'm'], [-5, 'M']],
    turn: [[0, 'm'], [3, 'M'], [-4, 'M'], [-2, 'M']],
  },
  drums: {
    // the shed breathing: air and one bell, nothing else
    intro: { a: 'X...............', m: '........o.......' },
    idle:  { k: ['X.......X.......', 'X.......X.....x.'],
             m: ['..x.......o.....', '..x.......x.....'],
             a: ['................', '............x...'],
             h: ['..x...x...x...x.', '..x...x...x...xo'] },
    main: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.xox.x.x.xox.x.'],
      m: ['..........x.....', '................'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X.-.'],
      h: 'xxxxxxxxxxxxxxxx',
      m: ['..x...X...x...o.', '................'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', a: '........x.......', m: '........X.......' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . 0 . . 12 . 0 . . 10 . . 7 .'), P('0 . 0 . 12 . 0 . 0 . . 8 . 7 . 5')],
    drive: [P('0 . 0 12 . 0 . 7 0 . 0 12 . 10 . 7'), P('0 0 . 12 . 0 10 . 0 . 12 . 8 . 7 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 0 . 0 . 3 . 0 0 . 0 . 5 3'), P('0 . 0 0 . 0 . 0 . 3 . 5 . 3 . 0')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . . 3 . 5 . . . 3 . 0 . . .'),
        P('7 . . . 5 . 3 . . . . . . . . .'),
        P('0 . . . 3 . 5 . . . 8 . 7 . 5 .'),
        P('3 . . . 5 . 3 . 0 . . . . . . .')],
    B: [P('12 . . 15 . 12 . . 10 . 12 . . . . .'),
        P('10 . . 8 . 7 . . 5 . . . . . . .'),
        P('15 . . 17 . 15 . . 12 . 15 . 17 . . .'),
        P('19 . . . 17 . 15 . 12 . . . . . . .')],
    C: [P('0 . . . . . . . 3 . . . . . . .'),
        P('5 . . . . . 3 . 0 . . . . . . .'),
        P('7 . . . . . . . 8 . . . . . . .'),
        P('7 . . . 5 . . . . . . . . . . .')],
    Bh: [P('15 . . 19 . 15 . . 12 . 15 . . . . .'),
         P('12 . . 10 . 12 . . 8 . . . . . . .'),
         P('19 . . 20 . 19 . . 15 . 19 . 20 . . .'),
         P('22 . . . 20 . 19 . 15 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', gain: 0.75 },
    { bars: 4, chords: 'main', drums: 'idle', bass: 'soft', gtr: 'ring', gtrStyle: 'power', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'hold' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', lead: 'C', arp: 'up', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'idle', bass: 'main', gtr: 'riff', lead: 'A', keys: 'hold' },
  ],
};

// ---- R2: RAIL JOINTS ------------------------------------------------------
// Built on the train itself. The da-DUM da-DUM of bogies crossing rail joints
// runs the whole length of the track and never breaks - everything else is
// arranged around it. The most relentless thing in the game.
const S4_JOINTS = {
  name: 'Rail Joints', bpm: 152, key: 56, lkey: 68, swing: 0, level: 0.97,
  tone: { freq: 3200, gain: -2 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    clank: { ring: 0.10 }, hiss: { vol: 0.13 },
    bass: { vol: 0.34, bright: 2600, close: 340 },
    gtr:  { vol: 0.20, drive: 'hot', tone: 2600 },
    keys: { vol: 0.06, tone: 2300 },
    lead: { vol: 0.34, drive: 'crunch', tone: 3600, send: 0.22, echo: 0.14 },
    harm: { vol: 0.19, drive: 'crunch', tone: 3000, send: 0.18, echo: 0.10 },
    arp:  { vol: 0.055 },
  },
  chords: {
    main: [[0, 'm'], [-2, 'M'], [-4, 'M'], [-5, 'M']],
    lift: [[-4, 'M'], [-5, 'M'], [0, 'm'], [-2, 'M']],
    turn: [[0, 'm'], [5, 'm'], [-2, 'M'], [-4, 'M']],
  },
  drums: {
    // the joints: two hits, a gap, two hits. It does not change all track long.
    intro: { m: 'xx......xx......', h: 'x.x.x.x.x.x.x.x.' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      m: ['xx......xx......', 'xx......xx....x.'],
      h: ['x.x.x.x.x.x.x.xo', 'x.x.x.x.x.x.x.x.'],
    },
    push: {
      k: ['X...x...X.......', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X...'],
      m: ['xx......xx......', 'xx..x...xx..x...'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    half: { m: 'xx......xx......', k: 'X...............', s: '........X.......' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', m: 'xx......xx..xxxx', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 . 0 . 0 . 0 . 0 . 10 . 7 .'), P('0 . 0 . 0 . 10 . 0 . 0 . 8 . 7 .')],
    drive: [P('0 0 . 0 . 0 0 . 0 . 0 0 . 10 . 7'), P('0 . 0 0 . 0 . 10 0 . 0 . 8 . 7 5')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . 0 . 0 . 0 . 0 . 0 . 3 . 5 .'), P('0 . 0 . 0 . 0 . 0 . 3 . 5 . 3 .')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . 3 . 5 . . 7 . 5 . 3 . . .'),
        P('8 . . 7 . 5 . . 3 . . . . . . .'),
        P('0 . . 3 . 5 . 7 . . 8 . 7 . 5 .'),
        P('3 . . . 0 . . . . . . . . . . .')],
    B: [P('12 . . 15 . 17 . . 15 . 12 . . . 10 .'),
        P('12 . . 10 . 8 . . 7 . . . . . . .'),
        P('15 . . 17 . 19 . . 20 . 19 . 17 . 15 .'),
        P('12 . . . 15 . . . 12 . . . . . . .')],
    C: [P('0 . . . 3 . . . 5 . . . 7 . . .'),
        P('5 . . . 3 . . . 0 . . . . . . .'),
        P('7 . . . 8 . . . 12 . . . 8 . . .'),
        P('7 . . . 5 . . . 3 . . . . . . .')],
    Bh: [P('15 . . 19 . 20 . . 19 . 15 . . . 12 .'),
         P('15 . . 12 . 12 . . 10 . . . . . . .'),
         P('19 . . 20 . 22 . . 24 . 22 . 20 . 19 .'),
         P('15 . . . 19 . . . 15 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'hold' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    // even the breakdown keeps the joints going - you are still on the train
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', lead: 'C', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'riff', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', lead: 'A', keys: 'hold' },
  ],
};

// ---- R3: NIGHT FREIGHT ----------------------------------------------------
// The bridge reading. You are on the roof of a moving train crossing a trestle
// at night - stars above, water below, the structure strobing past. Fast
// arpeggio for the motion, wide pads for the air, and a melody with long
// enough lines that it feels like gliding rather than running.
const S4_NIGHT = {
  name: 'Night Freight', bpm: 138, key: 56, lkey: 68, swing: 0, echo: 1.5, level: 0.91,
  tone: { freq: 3400, gain: -2 },
  bassVoice: 'syn', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    clank: { ring: 0.12 }, hiss: { vol: 0.11 },
    bass: { vol: 0.38, bright: 1500, close: 220, sub: 1.0 },
    gtr:  { vol: 0.13, tone: 4200, send: 0.44, echo: 0.32 },
    keys: { vol: 0.105, open: true, att: 0.6 },
    lead: { vol: 0.24, bright: 5600, send: 0.34, echo: 0.28, wave: 'sawtooth' },
    harm: { vol: 0.15, drive: 'crunch', tone: 3200, send: 0.30, echo: 0.20 },
    arp:  { vol: 0.10, wave: 'triangle', tone: 4000, echo: 0.36 },
  },
  chords: {
    main: [[0, 'm'], [3, 'M'], [-2, 'M'], [-4, 'M']],
    lift: [[-4, 'M'], [-2, 'M'], [0, 'm'], [5, 'm']],
    turn: [[5, 'm'], [3, 'M'], [-4, 'M'], [0, 'm']],
  },
  drums: {
    intro: { m: 'xx......xx......', h: '..x...x...x...x.' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...xo', '..x...x...x...x.'],
      m: ['xx......xx......', 'xx......xx......'],
    },
    push: {
      k: ['X.......X.......', 'X...x...X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.xox.x.x.xox.x.',
      m: ['xx......xx......', 'xx......xx....x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', m: 'xx......xx......', h: '............o...' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', m: 'xx......xx..xxxx', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . 0 . . . 0 . . . 0 . 0 .'), P('0 . . . 0 . . . 0 . . 0 . 0 . 0')],
    oct:  [P('0 . 12 . 0 . 12 . 0 . 12 . 0 . 12 .'), P('0 . 12 . 0 . 12 . 0 . 12 . 8 . 7 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    answer: [P('. . . . . . . . 7 . 5 . . . 3 .'), P('. . . . . . . . 5 . 3 . . . 0 .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('7 . . . 8 . . . 12 . . . 10 . . .'),
        P('8 . . . 7 . . . 5 . . . . . . .'),
        P('7 . . . 10 . . . 12 . . . 15 . . .'),
        P('12 . . . 10 . 8 . 7 . . . . . . .')],
    B: [P('15 . . 17 . 19 . . 17 . . . 15 . . .'),
        P('12 . . 15 . 12 . . 10 . . . . . . .'),
        P('19 . . 20 . 22 . . 20 . . . 19 . 17 .'),
        P('15 . . . 17 . . . 12 . . . . . . .')],
    C: [P('0 . . . . . 3 . . . 7 . . . . .'),
        P('5 . . . . . 3 . . . 0 . . . . .'),
        P('7 . . . . . 8 . . . 12 . . . . .'),
        P('10 . . . . . 7 . . . . . . . . .')],
    Bh: [P('7 . . 8 . 12 . . 10 . . . 7 . . .'),
         P('5 . . 7 . 5 . . 3 . . . . . . .'),
         P('12 . . 12 . 15 . . 12 . . . 10 . 8 .'),
         P('7 . . . 8 . . . 5 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'oct', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'B' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'oct', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- R4: COUPLER SWING ----------------------------------------------------
// Gauge Hollis swings a coupler like a club, and this is his reading of the
// stage: heavy swung blues-rock with a swagger to it. Slower than it feels,
// organ underneath, dirty guitar, and a backbeat you could hang a coat on.
const S4_COUPLER = {
  name: 'Coupler Swing', bpm: 118, key: 56, lkey: 68, swing: 0.22, level: 0.91,
  tone: { freq: 3200, gain: -2 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'organ',
  band: {
    kick: {}, snare: { fat: true },
    clank: { ring: 0.35 }, hiss: { vol: 0.12 },
    bass: { vol: 0.36, bright: 2200, close: 290 },
    gtr:  { vol: 0.22, drive: 'crunch', tone: 2800 },
    keys: { vol: 0.10, tone: 2600, bars: [[1, 1.0], [2, 0.6], [3, 0.5], [4, 0.25], [6, 0.18]] },
    lead: { vol: 0.34, drive: 'hot', tone: 3400, send: 0.26, echo: 0.14, vib: 14 },
    harm: { vol: 0.085, tone: 2400 },
    arp:  { vol: 0.05 },
  },
  chords: {
    // a blues shape: i - iv - i - V, and it takes its time getting round
    main: [[0, 'm7'], [0, 'm7'], [5, 'm7'], [0, 'm7']],
    lift: [[7, '7'], [5, 'm7'], [0, 'm7'], [0, 'm7']],
    turn: [[5, 'm7'], [7, '7'], [0, 'm7'], [-2, 'M']],
  },
  drums: {
    intro: { k: 'X.......x.......', s: '............X...', h: 'x..x..x..x..x..x', m: '........o.......' },
    main: {
      k: ['X.....x.....x...', 'X.......x.x.....'],
      s: ['....X.......X...', '....X.-.....X.-.'],
      h: ['x..x..x..x..x..x', 'x..xo.x..x..xo.x'],
      m: ['................', '..........x.....'],
    },
    push: {
      k: ['X.....x...x.x...', 'X...x...x.....x.'],
      s: ['....X.-.....X..x', '....X..x....X.Xx'],
      h: 'x.xx..x.x.xx..x.',
      m: ['..x.......o.....', '................'],
      c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '......o.......o.' },
    fill: { k: 'X.......x.......', s: '....X.-.x.X.x.Xx', t: '..........o.-...', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . 0 . 3 . . 5 . . 0 . . 10 .'), P('0 . 0 . . 3 5 . 0 . . 7 . 5 . 3')],
    walk: [P('0 . 3 . 5 . 7 . 8 . 7 . 5 . 3 .'), P('0 . 12 . 10 . 8 . 7 . 5 . 3 . 0 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    riff: [P('0 . . 0 . 3 . . 0 . . 0 . . 10 .'), P('0 . . 0 . 3 . 5 . . 3 . 0 . . .')],
    stabs: [P('. . . 0 . . 0 . . . . 0 . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    comp: [P('. . 0 . . 0 . . . 0 . . . . 0 .'), P('. . 0 . . . 0 . . . . 0 . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    A: [P('0 . . 3 . 5 . . 3 . 0 . . . 10 .'),
        P('0 . . 3 . 5 . 7 . . 5 . 3 . . .'),
        P('5 . . 7 . 8 . . 7 . 5 . 3 . . .'),
        P('3 . . 0 . . 10 . 0 . . . . . . .')],
    B: [P('12 . . 15 . 12 . . 10 . 12 . . . . .'),
        P('15 . . 12 . 10 . . 8 . . . . . . .'),
        P('12 . . 15 . 17 . . 15 . 12 . 10 . 12 .'),
        P('8 . . 7 . 5 . . 3 . . . . . . .')],
    C: [P('0 . . . 3 . . . 5 . . . 3 . . .'),
        P('0 . . . . . 10 . 0 . . . . . . .'),
        P('5 . . . 7 . . . 8 . . . 7 . . .'),
        P('5 . . . 3 . . . 0 . . . . . . .')],
    Ah: [P('0 . . . . . . . . . . . . . . .'),
         P('0 . . . . . . . . . . . . . . .'),
         P('5 . . . . . . . . . . . . . . .'),
         P('0 . . . . . . . . . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', gtrStyle: 'power', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'comp' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'riff', keys: 'comp', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'walk', gtr: 'riff', keys: 'comp', lead: 'A', harm: 'Ah' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', gtr: 'stabs', gtrStyle: 'power', lead: 'B', keys: 'comp' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'walk', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', lead: 'C', keys: 'hold', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', gtr: 'riff', keys: 'comp', lead: 'B' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'riff', keys: 'comp', lead: 'A' },
  ],
};

const S4_OPTIONS = { R1: S4_SHED, R2: S4_JOINTS, R3: S4_NIGHT, R4: S4_COUPLER };
