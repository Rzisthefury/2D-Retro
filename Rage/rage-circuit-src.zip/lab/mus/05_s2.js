// ============================================================ STAGE 2 options
// THE STRIP. Neon Canyon is a wet night-market street - signs, lanterns,
// puddles throwing the neon back up. The Basement is not a basement at all:
// it is the loading dock behind the club, stacked wall to wall with PA cabs,
// confetti still on the floor and the truck half loaded. So the music has an
// obvious job down there - it is coming out of those speakers.
//
// Stage 2 moves to G minor. Stage 1 was A minor throughout and eight stages in
// one key would wear thin; a whole tone down also puts the bass on G1, which
// is the meatiest part of the range.

// ---- N1: NEON CANYON ------------------------------------------------------
// The rooftops carried on down into the street. Arpeggio bouncing off the wet
// road on a long delay, poly-synth melody, guitar answering underneath.
const S2_NEON = {
  name: 'Neon Canyon', bpm: 128, key: 55, lkey: 67, swing: 0, echo: 1.5, level: 0.94,
  tone: { freq: 3400, gain: -1.5 },
  bassVoice: 'syn', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: { deep: true }, snare: { fat: true },
    bass: { vol: 0.36, bright: 1400, close: 210, sub: 1.0 },
    gtr:  { vol: 0.14, tone: 4400, send: 0.42, echo: 0.34 },
    keys: { vol: 0.10, open: true, att: 0.6 },
    lead: { vol: 0.23, bright: 5800, send: 0.32, echo: 0.30, wave: 'sawtooth' },
    harm: { vol: 0.15, drive: 'crunch', tone: 3200, send: 0.30, echo: 0.20 },
    arp:  { vol: 0.105, wave: 'triangle', tone: 4000, echo: 0.36 },
  },
  chords: {
    main: [[0, 'm'], [-4, 'M'], [3, 'M'], [-2, 'M']],
    lift: [[3, 'M'], [-2, 'M'], [0, 'm'], [-4, 'M']],
    turn: [[5, 'm'], [3, 'M'], [-4, 'M'], [-2, 'M']],
  },
  drums: {
    intro: { k: 'X.......X.......', h: '..x...x...x...x.' },
    main: {
      k: ['X.......X.......', 'X.......X.....x.'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...xo', '..x...x...x...x.'],
    },
    push: {
      k: ['X.......X.......', 'X...x...X.......'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '............o...' },
    fill: { k: 'X.......x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . 0 . . . 0 . . . 0 . 0 .'), P('0 . . . 0 . . . 0 . . 0 . 0 . 0')],
    oct:  [P('0 . 12 . 0 . 12 . 0 . 12 . 0 . 12 .'), P('0 . 12 . 0 . 12 . 0 . 12 . 10 . 7 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    answer: [P('. . . . . . . . 7 . 5 . . . 3 .'), P('. . . . . . . . 5 . 3 . . . 0 .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('7 . . . 5 . 7 . . . 10 . . . 12 .'),
        P('10 . . . 7 . . . 5 . . . . . . .'),
        P('7 . . . 10 . 12 . . . 14 . . . 12 .'),
        P('10 . . . 7 . 5 . . . . . . . . .')],
    B: [P('15 . . 14 . 12 . . 14 . . . 15 . . .'),
        P('12 . . 10 . 12 . . 7 . . . . . . .'),
        P('15 . . 17 . 19 . . 17 . . . 15 . 14 .'),
        P('12 . . . 14 . . . 10 . . . . . . .')],
    C: [P('0 . . . . . 3 . . . 7 . . . . .'),
        P('5 . . . . . 3 . . . 0 . . . . .'),
        P('7 . . . . . 10 . . . 12 . . . . .'),
        P('10 . . . . . 7 . . . . . . . . .')],
    Bh: [P('7 . . 5 . 3 . . 5 . . . 7 . . .'),
         P('3 . . 2 . 3 . . 0 . . . . . . .'),
         P('7 . . 10 . 12 . . 10 . . . 7 . 5 .'),
         P('3 . . . 5 . . . 2 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', keys: 'hold', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'oct', keys: 'hold', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'B' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'oct', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'oct', gtr: 'answer', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- N2: NIGHT MARKET -----------------------------------------------------
// The signs on that street say NOODLE, HOTEL, KTV. This one takes the hint and
// uses a flattened second - the interval that makes a melody sound like a
// different part of the world. Clean tremolo-picked guitar, electric piano,
// and a kit that plays rims and toms instead of a backbeat.
const S2_MARKET = {
  name: 'Night Market', bpm: 134, key: 55, lkey: 67, swing: 0.10, level: 0.94,
  bassVoice: 'pick', gtrStyle: 'clean', keyStyle: 'ep', leadStyle: 'clean', harmStyle: 'ep',
  band: {
    kick: {}, snare: { rim: false },
    bass: { vol: 0.33, bright: 1700, close: 280 },
    gtr:  { vol: 0.115, tone: 4600, send: 0.38, echo: 0.22 },
    keys: { vol: 0.11, bite: 2.2, tone: 3400 },
    lead: { vol: 0.34, tone: 5200, send: 0.36, echo: 0.24 },
    harm: { vol: 0.11, bite: 1.6 },
    arp:  { vol: 0.08, wave: 'triangle' },
  },
  chords: {
    // the flat second is the whole point: Gm going to Ab and back
    main: [[0, 'm'], [1, 'M'], [0, 'm'], [-2, 'M']],
    lift: [[1, 'M'], [0, 'm'], [-4, 'M'], [-2, 'M']],
    turn: [[5, 'm'], [1, 'M'], [0, 'm'], [0, 'm']],
  },
  drums: {
    intro: { k: 'X.......x.......', s: '....-.......-...', h: '..x...x...x...x.' },
    main: {
      k: ['X.....x.....x...', 'X.......x.x.....'],
      s: ['....X...-...X.-.', '....X.-.....X...'],
      h: ['x.xox.x.x.xox.x.', 'x.x.x.xox.x.x.xo'],
      t: ['................', '..............o-'],
    },
    push: {
      k: ['X.....x...x.x...', 'X...x...x.....x.'],
      s: ['....X.-.-...X..x', '....X..x....X.-x'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', t: '............x.o-' },
    fill: { k: 'X.......x.......', s: '....X.-.x.X.x.Xx', t: '..........o.-.x.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . 12 . . 10 . 7 . . 0 . 1 . 3'), P('0 . 10 . 12 . . 7 . . 5 . 3 . 1 .')],
    walk: [P('0 . 1 . 3 . 5 . 7 . 5 . 3 . 1 .'), P('0 . 12 . 10 . 7 . 5 . 3 . 1 . 0 .')],
    soft: [P('0 . . . . . . 12 . . . . . . . .')],
  },
  gtr: {
    // tremolo picking: the same note hammered on every sixteenth
    trem: [P('12 12 12 12 12 12 12 12 13 13 13 13 13 13 13 13'), P('12 12 12 12 12 12 12 12 15 15 15 15 15 15 15 15')],
    comp: [P('. . 0 . . . 0 . . . . 0 . . 0 .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    comp: [P('0 . . . . 0 . . . 0 . . . . 0 .'), P('0 . . 0 . . . 0 . . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    // 0 1 4 5 7 8 - the flat second and the major third together
    A: [P('0 . 1 . 4 . . 5 . 4 . 1 . . 0 .'),
        P('7 . . 5 . 4 . . 1 . . . . . . .'),
        P('8 . 7 . 5 . . 4 . 5 . 7 . . 8 .'),
        P('7 . . . 5 . 4 . 1 . . . . . . .')],
    B: [P('12 . . 13 . 12 . . 8 . . . 7 . . .'),
        P('8 . . 7 . 5 . . 4 . . . . . . .'),
        P('12 . . 13 . 16 . . 17 . 16 . 13 . 12 .'),
        P('13 . . . 12 . 8 . 7 . . . . . . .')],
    C: [P('0 . . . . . 1 . . . 4 . . . . .'),
        P('5 . . . . . 4 . . . 1 . . . . .'),
        P('7 . . . . . 8 . . . 7 . . . . .'),
        P('5 . . . . . 4 . . . . . . . . .')],
    Ah: [P('. . 0 . 0 . . 1 . 0 . 0 . . 8 .'),
         P('4 . . 1 . 0 . . 0 . . . . . . .'),
         P('5 . 4 . 1 . . 0 . 1 . 4 . . 5 .'),
         P('4 . . . 1 . 0 . 0 . . . . . . .')],
  },
  arps: { soft: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'soft', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'comp', keys: 'comp' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'trem', keys: 'comp', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'walk', gtr: 'trem', keys: 'comp', lead: 'A', harm: 'Ah' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', gtr: 'comp', keys: 'comp', lead: 'B', arp: 'soft' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'walk', keys: 'comp' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'soft', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', gtr: 'trem', keys: 'comp', lead: 'B', harm: 'Ah' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'comp', keys: 'comp', lead: 'A' },
  ],
};

// ---- N3: BLEED THROUGH ----------------------------------------------------
// Written for the loading dock: what you hear is the club's PA through a wall.
// It opens muffled and sub-heavy with the melody filtered right down, and
// every time the arrangement lifts, the doors open a bit further - the tone
// control comes up and the real kit and guitar cut in over the top.
const S2_BLEED = {
  name: 'Bleed Through', bpm: 124, key: 55, lkey: 67, swing: 0, level: 0.80,
  tone: { freq: 2800, gain: -2 },
  bassVoice: 'sub', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.33, harm: 0.22 },
    gtr:  { vol: 0.15, tone: 4000, send: 0.40, echo: 0.26 },
    keys: { vol: 0.095, open: false, att: 0.7 },
    lead: { vol: 0.30, bright: 4400, send: 0.34, echo: 0.24, wave: 'sawtooth' },
    harm: { vol: 0.20, drive: 'crunch', tone: 3200, send: 0.26, echo: 0.14 },
    arp:  { vol: 0.10, wave: 'triangle', tone: 3400, echo: 0.34 },
  },
  chords: {
    main: [[0, 'm7'], [-2, 'M'], [3, 'M7'], [-4, 'M']],
    lift: [[-4, 'M'], [3, 'M7'], [0, 'm7'], [-2, 'M']],
    turn: [[5, 'm7'], [-2, 'M'], [0, 'm7'], [0, 'm7']],
  },
  drums: {
    // muffled: kick and almost nothing else, the way it sounds through a door
    muf:  { k: 'X...X...X...X...', h: '................' },
    main: { k: ['X...X...X...X...', 'X...X...X...X..x'],
            s: ['....-.......-...', '....-.......-..-'],
            h: ['..x...x...x...x.', '..x...x...x...xo'] },
    // doors open: the real kit arrives
    open: { k: ['X...X...X...X...', 'X...X...X.x.X...'],
            s: ['....X.......X...', '....X.......X..x'],
            h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'] },
    half: { k: 'X.......X.......', s: '........-.......', h: '............o...' },
    fill: { k: 'X...X...x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    four: [P('0 . . . 0 . . . 0 . . . 0 . . .'), P('0 . . . 0 . . . 0 . . . 0 . 10 .')],
    roll: [P('0 . . 0 . . 0 . 0 . . 0 . 10 . 7'), P('0 . . 0 . 0 . . 0 . . 10 . 7 . 5')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    stab: [P('. . . . 0 . . . . . . . 0 . . .'), P('. . . . 0 . . . 0 . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . . 3 . . . 5 . . . 7 . . .'),
        P('10 . . . 7 . . . 5 . . . 3 . . .'),
        P('7 . . . 10 . . . 12 . . . 10 . . .'),
        P('7 . . . 5 . . . 3 . . . . . . .')],
    B: [P('12 . . . 15 . 14 . 12 . . . 10 . . .'),
        P('12 . . . 10 . 7 . 5 . . . . . . .'),
        P('15 . . . 17 . 19 . 17 . . . 15 . . .'),
        P('14 . . . 12 . 10 . 12 . . . . . . .')],
    C: [P('0 . . . . . . . 3 . . . . . . .'),
        P('5 . . . . . . . 3 . . . . . . .'),
        P('7 . . . . . . . 10 . . . . . . .'),
        P('7 . . . . . . . . . . . . . . .')],
    Bh: [P('7 . . . 10 . 8 . 7 . . . 5 . . .'),
         P('7 . . . 5 . 3 . 0 . . . . . . .'),
         P('10 . . . 12 . 14 . 12 . . . 10 . . .'),
         P('8 . . . 7 . 5 . 7 . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    // through the wall
    { bars: 4, chords: 'main', drums: 'muf', bass: 'four', keys: 'hold', gain: 0.72 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'four', keys: 'hold', arp: 'slow', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'roll', keys: 'hold', arp: 'run', lead: 'A' },
    // the doors open
    { bars: 4, chords: 'lift', drums: 'open', bass: 'roll', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'open', bass: 'roll', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'B' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'roll', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.74 },
    { bars: 4, chords: 'main', drums: 'open', bass: 'roll', gtr: 'stab', keys: 'hold', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'four', keys: 'hold', arp: 'run', lead: 'A' },
  ],
};

// ---- N4: STRIP ROCK -------------------------------------------------------
// The band from Under the El, further into the night and less polite. Twin
// guitars in harmony rather than one lead, organ underneath, and a bass that
// never stops moving.
const S2_ROCK = {
  name: 'Strip Rock', bpm: 146, key: 55, lkey: 67, swing: 0.08, level: 0.94,
  tone: { freq: 3200, gain: -1.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'organ', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    bass: { vol: 0.34, bright: 2500, close: 320 },
    gtr:  { vol: 0.21, drive: 'hot', tone: 2500 },
    keys: { vol: 0.06, tone: 2300 },
    lead: { vol: 0.34, drive: 'crunch', tone: 3600, send: 0.22, echo: 0.14 },
    harm: { vol: 0.20, drive: 'crunch', tone: 2900, send: 0.18, echo: 0.10 },
    arp:  { vol: 0.05 },
  },
  chords: {
    main: [[0, 'm'], [-2, 'M'], [-4, 'M'], [0, 'm']],
    lift: [[-4, 'M'], [3, 'M'], [-2, 'M'], [0, 'm']],
    turn: [[0, 'm'], [5, 'm'], [-2, 'M'], [-5, 'M']],
  },
  drums: {
    intro: { k: 'X.......X.....x.', s: '............X...', h: 'x.x.x.x.x.x.x.xo' },
    main: {
      k: ['X.......X.....x.', 'X.....x.X...x...'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.xox.x.x.xox.x.'],
    },
    push: {
      k: ['X...x...X.....x.', 'X.......X.x.x...'],
      s: ['....X.......X..x', '....X.....x.X.-.'],
      h: 'xxxxxxxxxxxxxxxx', c: ['X...............', '................'],
    },
    half: { k: 'X...............', s: '........X.......', h: '....o.......o...' },
    fill: { k: 'X.......x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . 0 . 12 . 0 . 0 . . 10 . 7 . 5'), P('0 . . 0 . . 12 . 0 . . 7 . . 10 .')],
    drive: [P('0 . 0 12 . 0 . 7 0 . 0 12 . 10 . 7'), P('0 0 . 12 . 0 10 . 0 . 12 . 10 . 7 .')],
    soft: [P('0 . . . . . . . 12 . . . . . . .')],
  },
  gtr: {
    chug: [P('0 . 0 0 . 0 . 0 . 0 0 . 0 . 3 5'), P('0 . 0 0 . 0 . 0 . 0 . 5 . 3 . 0')],
    stabs: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    A: [P('0 . . 3 . 5 . 3 . . 7 . 5 . 3 .'),
        P('5 . . 7 . 10 . . 12 . . . 10 . . .'),
        P('7 . . 5 . 3 . 5 . . 7 . 10 . 12 .'),
        P('10 . . . 7 . 5 . 3 . . . . . . .')],
    B: [P('15 . 14 . 12 . 10 . 12 . . . 15 . . .'),
        P('14 . 12 . 10 . 7 . 5 . . . . . . .'),
        P('15 . 17 . 19 . 17 . 15 . 14 . 12 . 10 .'),
        P('12 . . . 15 . . . 19 . . . . . . .')],
    C: [P('0 . . . 3 . . . 5 . . . 7 . . .'),
        P('5 . . . 3 . . . 0 . . . . . . .'),
        P('7 . . . 10 . . . 12 . . . 10 . . .'),
        P('7 . . . . . 5 . 3 . . . . . . .')],
    // the second guitar, a third above
    Ah: [P('3 . . 7 . 10 . 7 . . 12 . 10 . 7 .'),
         P('10 . . 12 . 15 . . 17 . . . 15 . . .'),
         P('12 . . 10 . 7 . 10 . . 12 . 15 . 17 .'),
         P('15 . . . 12 . 10 . 7 . . . . . . .')],
    Bh: [P('19 . 17 . 15 . 14 . 15 . . . 19 . . .'),
         P('17 . 15 . 14 . 12 . 10 . . . . . . .'),
         P('19 . 22 . 24 . 22 . 19 . 17 . 15 . 14 .'),
         P('15 . . . 19 . . . 22 . . . . . . .')],
  },
  arps: { up: { notes: [0, 1, 2, 1], chordal: true, rate: 2, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', gtr: 'ring', keys: 'hold', gain: 0.85 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'chug' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'chug', lead: 'A', keys: 'hold' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'drive', gtr: 'chug', lead: 'A', harm: 'Ah' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'stabs', gtrStyle: 'power', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'drive', gtr: 'stabs', gtrStyle: 'power' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', lead: 'C', arp: 'up', gain: 0.8 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'drive', gtr: 'chug', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'chug', lead: 'A', harm: 'Ah' },
  ],
};

const S2_OPTIONS = { N1: S2_NEON, N2: S2_MARKET, N3: S2_BLEED, N4: S2_ROCK };
