// ============================================================ stage 7 picker
// THE LAB, and three rooms that go bright, then cold, then dark. Same four
// tracks offered for all three, as with stage 6.
const OPTIONS = [
  { k: 'G1', song: S7_CLEAN, still: 'corridor', tag: 'BRIGHT',
    pitch: 'The corridor, and the joke is that it is lovely. Built on a stack of fourths with no third anywhere in the tune, so it is neither major nor minor - the sound of a room with no smell.',
    notes: [
      'The only brightly lit room in the game gets the only pretty track in the game',
      'Clean chorused guitar carries the tune, glass bells underneath, and the kit brushes rather than hits',
      'The kick is a heartbeat - two close together, then a gap - which is the thing the works never had',
    ] },
  { k: 'G2', song: S7_SPEC, still: 'coldstore', tag: 'WRONG',
    pitch: 'Written for the cold store once it is clear what those drawers are for. The tune moves in semitones and keeps landing on the natural seventh against a minor chord, which is the interval that will not sit down.',
    notes: [
      'Nothing in the six settled stages moves by semitone; they all move in thirds and fourths',
      'Slowest thing on the stage at 118, electric piano, no drive on anything anywhere',
      'Unsettling rather than aggressive - the only track in the game that is actually uneasy',
    ] },
  { k: 'G3', song: S7_CHILL, still: 'coldstore', tag: 'DRIVING',
    pitch: 'The plant that keeps all this at temperature, and the fastest thing on the stage. Where the works was heavy, this is hollow: the bass is filtered high with the sub taken right out, and there is nothing underneath any of it.',
    notes: [
      'The one track in the game with a hole where the bottom octave should be - cold as an absence',
      'Guitar tremolo-picks instead of chugging, which is what shivering sounds like',
      'The tune falls the whole way down; every other stage in the game climbs',
    ] },
  { k: 'G4', song: S7_UNIT, still: 'birth', tag: 'THE CAPSULE',
    pitch: 'Written for the thing in the capsule. Six stages of music have been angry, cold or both - this is the only hook in the game that ends higher than it starts, and the only one that could be called hopeful.',
    notes: [
      'Guitar and lead carry the tune side by side in harmony rather than one under the other',
      'The only chord progression on the stage that resolves upward into a major chord',
      'The odd one out on purpose, and the one I would put on the Birthing Floor',
    ] },
];
const SCENES = [
  { id: 's7a', label: 'Corridor' },
  { id: 's7b', label: 'Cold Store' },
  { id: 's7c', label: 'Birthing' },
];

let started = false, playing = null, raf = 0;
function ensureAudio() {
  if (started) return;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  initBand(new Ctx());
  started = true;
}
function stopAll() {
  Band.stop(); playing = null;
  document.querySelectorAll('.card').forEach(c => c.classList.remove('playing'));
  document.querySelectorAll('.play').forEach(b => { b.textContent = 'Play'; });
  cancelAnimationFrame(raf);
  document.querySelectorAll('.bar i').forEach(b => { b.style.width = '0%'; });
  document.querySelectorAll('.pos').forEach(p => { p.textContent = '0:00'; });
}
function toggle(opt, card) {
  ensureAudio();
  if (AC.state !== 'running') AC.resume();
  if (playing === opt.k) { stopAll(); return; }
  stopAll();
  playing = opt.k;
  card.classList.add('playing');
  card.querySelector('.play').textContent = 'Stop';
  Band.play(opt.k, { [opt.k]: opt.song });
  const t0 = AC.currentTime, total = songSeconds(opt.song);
  const bar = card.querySelector('.bar i'), pos = card.querySelector('.pos');
  const tick = () => {
    if (playing !== opt.k) return;
    const el = (AC.currentTime - t0) % total;
    bar.style.width = (el / total * 100).toFixed(1) + '%';
    pos.textContent = fmtTime(el);
    raf = requestAnimationFrame(tick);
  };
  tick();
}
const fmtTime = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');

const PICK_KEY = 'rc_mus_picks_s7';
let picks = {};
try { picks = JSON.parse(localStorage.getItem(PICK_KEY) || '{}'); } catch (e) { picks = {}; }
function savePicks() { try { localStorage.setItem(PICK_KEY, JSON.stringify(picks)); } catch (e) {} }
function refresh() {
  document.querySelectorAll('.card').forEach(c => {
    const k = c.dataset.k;
    const mine = SCENES.filter(s => picks[s.id] === k);
    c.classList.toggle('picked', mine.length > 0);
    c.querySelectorAll('.pick').forEach(b => {
      const on = picks[b.dataset.scene] === k;
      b.classList.toggle('on', on);
      b.textContent = (on ? '\u2713 ' : '') + b.dataset.label;
    });
  });
  const s = document.getElementById('summary');
  const parts = SCENES.filter(x => picks[x.id]).map(x => {
    const o = OPTIONS.find(y => y.k === picks[x.id]);
    return x.label + ': ' + picks[x.id] + ' \u2014 ' + o.song.name;
  });
  s.textContent = parts.length ? parts.join('   \u00b7   ')
    : 'Pick one for each scene and this line becomes the message to send back.';
}

function buildPage() {
  const wrap = document.getElementById('cards');
  for (const opt of OPTIONS) {
    const total = songSeconds(prepSong(opt.song));
    const card = document.createElement('section');
    card.className = 'card'; card.dataset.k = opt.k;
    card.innerHTML =
      '<div class="screen"><img alt="Stage 7 background" src="' + STILLS[opt.still] + '">' +
        '<span class="tag">' + opt.tag + '</span>' +
      '</div>' +
      '<div class="body">' +
        '<div class="titlerow">' +
          '<h3><span class="key">' + opt.k + '</span>' + opt.song.name + '</h3>' +
          '<div class="picks">' + SCENES.map(s =>
            '<button class="pick" type="button" data-scene="' + s.id + '" data-label="' + s.label + '">' + s.label + '</button>'
          ).join('') + '</div>' +
        '</div>' +
        '<p class="pitch">' + opt.pitch + '</p>' +
        '<ul class="notes">' + opt.notes.map(n => '<li>' + n + '</li>').join('') + '</ul>' +
        '<div class="transport">' +
          '<button class="play" type="button">Play</button>' +
          '<div class="bar"><i></i></div>' +
          '<span class="pos">0:00</span><span class="sep">/</span><span class="len">' + fmtTime(total) + '</span>' +
        '</div>' +
        '<p class="meta">' + opt.song.bpm + ' bpm \u00b7 ' + opt.song._bars + ' bars before it repeats \u00b7 C minor</p>' +
      '</div>';
    card.querySelector('.play').addEventListener('click', () => toggle(opt, card));
    card.querySelectorAll('.pick').forEach(b => b.addEventListener('click', () => {
      const sc = b.dataset.scene;
      if (picks[sc] === opt.k) delete picks[sc]; else picks[sc] = opt.k;
      savePicks(); refresh();
    }));
    wrap.appendChild(card);
  }
  refresh();
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') stopAll(); });
buildPage();
