// ============================================================ STAGE 7 options
// THE LAB, and the three rooms go bright, then cold, then dark, which is not
// something any other stage does:
//   CLEAN CORRIDOR    - fluorescent, near-white, glass observation windows into
//                       labs marked NO ENTRY and WASH, an airlock at the end.
//                       The first room in the whole game that is brightly lit.
//   THE COLD STORE    - deep navy, frost on everything, wall after wall of
//                       drawers numbered CS-43, CS-44, CHAMBER 7. Drawers that
//                       size hold people.
//   THE BIRTHING FLOOR - near black. Tanks lit violet with shapes floating in
//                       them, one of them marked REJECT, and UNIT-9 awake in a
//                       teal capsule on the right watching you walk past.
//
// D MINOR, the highest key in the game (key 62). Every other stage has sat
// between F and C and leaned on the bottom of the range. The lab gets the
// thinnest, most weightless key available, because it is the one building in
// the game that is trying to seem clean.
//
// The trap here is stage 6. The works was cold and mechanical and so is this,
// and writing the same track twice would be the easiest mistake available. The
// separation is deliberate: the works had no pulse and this place has one. The
// kick in three of these four is a HEARTBEAT - two beats close together and
// then a gap - rather than a machine's even four. They grow people here.
//
// Mix targets set before writing: mid 14-20%, sub 24-34%, lead 0.28-0.34.
// All four hooks were checked against the six settled stages before a single
// bar was written around them: worst match 23%, and 0-12% against each other.

// ---- G1: CLEAN ROOM -------------------------------------------------------
// The corridor, and the joke is that it is lovely. Built on a stack of fourths
// with NO THIRD anywhere in the tune, so it is neither major nor minor - the
// sound of a room with no smell. Clean chorused guitar carries it, glass bells
// underneath, and the kit brushes rather than hits.
const S7_CLEAN = {
  name: 'Clean Room', bpm: 134, key: 62, lkey: 74, swing: 0.05, echo: 1.3, level: 0.94,
  tone: { freq: 3400, gain: -5 },
  bassVoice: 'pick', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'lead', harmStyle: 'clean',
  band: {
    kick: {}, snare: { fat: false },
    hiss: { vol: 0.07, f0: 3000, f1: 1200 },
    // sub: 0.8 is the fix for the whole stage. Without it this measured 7.5%
    // low end against a game that runs 21-47%, and 32% midrange against a game
    // that runs 8-22% - the brightest thing in the soundtrack by half again,
    // written for the room that is merely brightly LIT. Those are not the same
    // thing and I keep treating them as if they were.
    bass: { vol: 0.36, bright: 2200, close: 310, sub: 0.8 },
    gtr:  { vol: 0.14, tone: 4000, send: 0.34, echo: 0.24 },
    keys: { vol: 0.09, open: true, att: 0.9 },
    lead: { vol: 0.27, drive: 'clean', tone: 3200, send: 0.30, echo: 0.20, vib: 9 },
    harm: { vol: 0.095, tone: 3600, send: 0.32, echo: 0.22 },
    arp:  { vol: 0.07, wave: 'sine', tone: 3000, echo: 0.28 },
  },
  chords: {
    // sus and add9 shapes, which have no third in them either
    main: [[0, 'm9'], [-2, 'M9'], [5, 'm7'], [3, 'M7']],
    lift: [[3, 'M7'], [5, 'm7'], [-2, 'M9'], [0, 'm9']],
    turn: [[-4, 'M9'], [3, 'M7'], [5, 'm7'], [0, 'm9']],
  },
  drums: {
    // the heartbeat: two close together, then room
    intro: { h: '..x...x...x...x.', a: 'X...............' },
    main: {
      k: ['X..X....X.......', 'X..X....X..X....'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...xo', '..x...x...x...x.'],
    },
    push: {
      k: ['X..X....X..X....', 'X..X....X..X..x.'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'],
    },
    half: { k: 'X..X............', h: '........x.......', a: '........x.......' },
    fill: { k: 'X..X....x.......', s: '....X...x...X.Xx', t: '..........x.o.-.', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . 10 .'), P('0 . . . . . . . 0 . . . 7 . . .')],
    walk: [P('0 . . 7 . . 0 . 10 . . 7 . . 5 .'), P('0 . . 5 . . 7 . 0 . . 10 . . 7 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('0 . . . . . . . 7 . . . . . . .'), P('0 . . . . . . . 5 . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // fourths stacked: 5 to 9 to 12. No 3 and no 10 anywhere in it.
    A: [P('5 . . . 9 . . . 12 . . . 9 . . .'),
        P('2 . . . 5 . . . 9 . . . . . . .'),
        P('12 . . . 14 . . . 12 . . . 9 . . .'),
        P('5 . . . 2 . . . . . . . . . . .')],
    B: [P('17 . . . 19 . . . 21 . . 19 . . 17 .'),
        P('14 . . . 17 . . . 19 . . . . . . .'),
        P('19 . . . 21 . . . 24 . . 21 . . 19 .'),
        P('17 . . . 14 . . . 12 . . . . . . .')],
    C: [P('5 . . . . . . . 9 . . . . . . .'),
        P('2 . . . . . . . 5 . . . . . . .'),
        P('12 . . . . . . . 9 . . . . . . .'),
        P('7 . . . . . . . 5 . . . . . . .')],
    Bh: [P('12 . . . 14 . . . 17 . . 14 . . 12 .'),
         P('9 . . . 12 . . . 14 . . . . . . .'),
         P('14 . . . 17 . . . 19 . . 17 . . 14 .'),
         P('12 . . . 9 . . . 7 . . . . . . .')],
  },
  arps: {
    glass: { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 2, voice: 'pluck' },
    still: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'still', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'glass' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'walk', gtr: 'ring', keys: 'hold', arp: 'glass', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'walk', gtr: 'ring', keys: 'hold', arp: 'glass', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', keys: 'hold', arp: 'glass', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'walk', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'still', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'walk', gtr: 'ring', keys: 'hold', arp: 'glass', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'glass', lead: 'A' },
  ],
};

// ---- G2: SPECIMEN ---------------------------------------------------------
// Written for the cold store, once it is clear what those drawers are for.
// The tune moves in SEMITONES - nothing in the six settled stages does, they
// all move in thirds and fourths - and it keeps landing on the natural 7th
// against a minor chord, which is the interval that will not sit down. Slow,
// electric piano, no drive on anything.
const S7_SPEC = {
  name: 'Specimen', bpm: 118, key: 62, lkey: 74, swing: 0, echo: 1.6, level: 0.92,
  tone: { freq: 3200, gain: -3 },
  bassVoice: 'sub', gtrStyle: 'clean', keyStyle: 'ep', leadStyle: 'lead', harmStyle: 'stab',
  band: {
    kick: { deep: true }, snare: { fat: true },
    hiss: { vol: 0.10, f0: 2200, f1: 700 }, clank: { ring: 0.9, pitch: 340, vol: 0.5 },
    bass: { vol: 0.30, harm: 0.22 },
    gtr:  { vol: 0.13, tone: 3800, send: 0.50, echo: 0.36 },
    keys: { vol: 0.13, tone: 2800 },
    lead: { vol: 0.30, drive: 'clean', tone: 3000, send: 0.46, echo: 0.30, vib: 7 },
    harm: { vol: 0.10, bright: 3400, send: 0.42, echo: 0.32 },
    arp:  { vol: 0.075, wave: 'sine', tone: 2800, echo: 0.42 },
  },
  chords: {
    main: [[0, 'm'], [0, 'm9'], [-1, 'M7'], [-2, 'M']],
    lift: [[-1, 'M7'], [-2, 'M'], [5, 'm7'], [0, 'm9']],
    turn: [[3, 'M7'], [-1, 'M7'], [-2, 'M'], [0, 'm']],
  },
  drums: {
    intro: { a: 'X...............', m: '........o.......' },
    main: {
      k: ['X..X............', 'X..X........X...'],
      s: ['............X...', '............X...'],
      h: ['..x.......x.....', '..x.......x...x.'],
      m: ['........o.......', '................'],
    },
    push: {
      k: ['X..X....X.......', 'X..X....X..X....'],
      s: ['....X.......X...', '....X.......X...'],
      h: ['..x...x...x...x.', '..x...x...x...xo'],
      m: ['........o.......', '....o...........'],
    },
    half: { k: 'X..X............', a: '........X.......', m: '........o.......' },
    fill: { k: 'X..X....x.......', s: '....X.......X.Xx', m: '..........o.....', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . . .'), P('0 . . . . . . . -1 . . . . . . .')],
    crawl: [P('0 . . . -1 . . . 0 . . . -2 . . .'), P('0 . . . 0 . . . -1 . . . -2 . . .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('0 . . . . . . . . . . . . . . .'), P('-1 . . . . . . . . . . . . . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // semitones, and the natural 7 (11) rubbing on a minor chord
    A: [P('0 . . 1 . . 0 . -1 . . . 0 . . .'),
        P('3 . . 2 . . 0 . . . . . . . . .'),
        P('7 . . 8 . . 7 . 11 . . . 12 . . .'),
        P('11 . . 10 . . 8 . 7 . . . . . . .')],
    B: [P('19 . . 20 . . 19 . 17 . . . 19 . . .'),
        P('15 . . 14 . . 12 . . . . . . . . .'),
        P('19 . . 20 . . 22 . 23 . . . 24 . . .'),
        P('23 . . 22 . . 20 . 19 . . . . . . .')],
    C: [P('0 . . . . . . . 1 . . . . . . .'),
        P('0 . . . . . . . -1 . . . . . . .'),
        P('7 . . . . . . . 8 . . . . . . .'),
        P('7 . . . . . . . . . . . . . . .')],
    Bh: [P('12 . . 13 . . 12 . 11 . . . 12 . . .'),
         P('15 . . 14 . . 12 . . . . . . . . .'),
         P('19 . . 20 . . 19 . 23 . . . 24 . . .'),
         P('23 . . 22 . . 20 . 19 . . . . . . .')],
  },
  arps: { still: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' } },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'still', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'still' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'crawl', gtr: 'ring', keys: 'hold', arp: 'still', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'crawl', gtr: 'ring', keys: 'hold', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'crawl', keys: 'hold', arp: 'still', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'crawl', keys: 'hold' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'still', gain: 0.76 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'crawl', gtr: 'ring', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'still', lead: 'A' },
  ],
};

// ---- G3: CHILLER ----------------------------------------------------------
// The plant that keeps all this at temperature, and the fastest thing on the
// stage. The separation from stage 6 is that the works was HEAVY and this is
// HOLLOW: the bass is filtered high with the sub taken right out, the guitar
// tremolo-picks instead of chugging, and there is nothing underneath any of it.
// Cold as an absence rather than a weight.
const S7_CHILL = {
  name: 'Chiller', bpm: 152, key: 62, lkey: 74, swing: 0, echo: 1.1, level: 0.94,
  tone: { freq: 3500, gain: -3.5 },
  bassVoice: 'pick', gtrStyle: 'chug', keyStyle: 'stab', leadStyle: 'stab', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: false },
    hiss: { vol: 0.12, f0: 3400, f1: 1400 }, clank: { ring: 0.10, pitch: 620, vol: 0.5 },
    // no sub layer at all: this is the only track in the game with a hole
    // where the bottom octave should be, which is the entire point of it
    bass: { vol: 0.32, bright: 2800, close: 620 },
    gtr:  { vol: 0.17, drive: 'crunch', tone: 3400, send: 0.22, echo: 0.14 },
    keys: { vol: 0.06, bright: 4200, wave: 'sawtooth' },
    lead: { vol: 0.28, bright: 4600, send: 0.24, echo: 0.18, wave: 'sawtooth' },
    harm: { vol: 0.13, drive: 'crunch', tone: 3200, send: 0.22, echo: 0.12 },
    arp:  { vol: 0.065, wave: 'triangle', tone: 3800, echo: 0.20 },
  },
  chords: {
    main: [[0, 'm'], [5, 'm'], [-2, 'M'], [0, 'm']],
    lift: [[-2, 'M'], [3, 'M'], [5, 'm'], [0, 'm']],
    turn: [[5, 'm'], [-2, 'M'], [3, 'M'], [0, 'm']],
  },
  drums: {
    intro: { h: 'x.x.x.x.x.x.x.x.', a: 'X.......x.......' },
    main: {
      k: ['X..X....X.......', 'X..X....X..X....'],
      s: ['....X.......X...', '....X.......X...'],
      h: 'x.x.x.x.x.x.x.x.',
      m: ['......x.......x.', '......x.......x.'],
    },
    push: {
      k: ['X..X....X..X....', 'X..X....X..X..x.'],
      s: ['....X.......X...', '....X.......X..x'],
      h: 'xxxxxxxxxxxxxxxx',
      m: ['......x.......x.', '......x...x...x.'],
      c: ['X...............', '................'],
    },
    half: { k: 'X..X............', h: '........x.......', a: '........X.......' },
    fill: { k: 'X..X....X..X....', s: '....X...x...X.Xx', m: '..........x...x.' },
  },
  bass: {
    main: [P('0 . 0 . . . 0 . 0 . 0 . . . 0 .'), P('0 . 0 . . . 0 . 0 . 0 . . . 10 .')],
    run:  [P('0 . 0 . 5 . 0 . 7 . 5 . 0 . 3 .'), P('0 . 5 . 0 . 7 . 0 . 3 . 5 . 0 .')],
    soft: [P('0 . . . . . . . 0 . . . . . . .')],
  },
  gtr: {
    // tremolo: the same note over and over, which is what shivering is
    trem: [P('0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0'), P('0 0 0 0 0 0 0 0 5 5 5 5 5 5 5 5')],
    stab: [P('0 . . . . . 0 . . . 0 . . . . .')],
    ring: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: {
    pulse: [P('0 . . . 0 . . . 0 . . . 0 . . .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  leads: {
    // falls the whole way down. Every other stage in the game climbs.
    A: [P('12 . 10 . 8 . 7 . 5 . 3 . 2 . 0 .'),
        P('12 . 10 . 8 . 7 . 5 . . . . . . .'),
        P('19 . 17 . 15 . 14 . 12 . 10 . 8 . 7 .'),
        P('5 . 3 . 2 . 0 . . . . . . . . .')],
    B: [P('24 . 22 . 20 . 19 . 17 . . . 19 . . .'),
        P('22 . 20 . 19 . 17 . 15 . . . . . . .'),
        P('24 . 22 . 21 . 19 . 17 . 15 . 14 . 12 .'),
        P('14 . 12 . 10 . . . . . . . . . . .')],
    C: [P('12 . . . 10 . . . 8 . . . 7 . . .'),
        P('12 . . . 10 . . . 8 . . . . . . .'),
        P('19 . . . 17 . . . 15 . . . 14 . . .'),
        P('5 . . . 2 . . . 0 . . . . . . .')],
    Bh: [P('19 . 17 . 15 . 14 . 12 . 10 . 9 . 7 .'),
         P('19 . 17 . 15 . 14 . 12 . . . . . . .'),
         P('24 . 22 . 20 . 19 . 17 . 15 . 14 . 12 .'),
         P('12 . 10 . 9 . 7 . . . . . . . . .')],
  },
  arps: {
    run:  { notes: [0, 1, 2, 3, 2, 1], chordal: true, rate: 1, voice: 'pluck' },
    slow: { notes: [0, 2], chordal: true, rate: 2, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.82 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'trem', keys: 'pulse', arp: 'run' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'run', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'run', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'run', gtr: 'stab', keys: 'pulse', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'run', gtr: 'stab' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'ring', gtrStyle: 'clean', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'run', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'trem', keys: 'pulse', arp: 'run', lead: 'A' },
  ],
};

// ---- G4: UNIT-9 -----------------------------------------------------------
// Written for the thing in the capsule, and it is the odd one out on purpose.
// Six stages of music have been angry, cold, or both. This is the only hook in
// the game that ENDS HIGHER THAN IT STARTS - it opens upward through a fourth
// and a sixth and just keeps going - and the only one that could be called
// hopeful. Guitar and lead carry it in harmony rather than one under the other,
// because the point of the room is that you are not alone in it afterwards.
const S7_UNIT = {
  name: 'Unit-9', bpm: 140, key: 62, lkey: 74, swing: 0, echo: 1.4, level: 0.93,
  tone: { freq: 3500, gain: -4.5 },
  bassVoice: 'pick', gtrStyle: 'clean', keyStyle: 'pad', leadStyle: 'lead', harmStyle: 'lead',
  band: {
    kick: {}, snare: { fat: true },
    hiss: { vol: 0.08, f0: 2600, f1: 900 },
    // the harmony line is the whole idea here, so it stays - but two bright
    // melodic lines side by side in the same octave gave this the highest top
    // end of anything in the game. It keeps the idea and loses the glare.
    bass: { vol: 0.36, bright: 2400, close: 310, sub: 0.8 },
    gtr:  { vol: 0.15, tone: 3800, send: 0.28, echo: 0.20 },
    keys: { vol: 0.09, open: true, att: 0.8 },
    lead: { vol: 0.28, drive: 'clean', tone: 3200, send: 0.26, echo: 0.18, vib: 8 },
    harm: { vol: 0.14, drive: 'crunch', tone: 3000, send: 0.20, echo: 0.12 },
    arp:  { vol: 0.07, wave: 'triangle', tone: 3200, echo: 0.24 },
  },
  chords: {
    // the only progression on the stage that resolves upward into a major chord
    main: [[0, 'm'], [-4, 'M'], [3, 'M'], [-2, 'M']],
    lift: [[3, 'M'], [-2, 'M'], [-4, 'M'], [5, 'm']],
    turn: [[5, 'm'], [3, 'M7'], [-2, 'M'], [-4, 'M9']],
  },
  drums: {
    intro: { h: '..x...x...x...x.', a: 'X...............' },
    main: {
      k: ['X..X....X.......', 'X..X....X..X....'],
      s: ['....X.......X...', '....X.......X..x'],
      h: ['x.x.x.x.x.x.x.xo', 'x.x.x.x.x.x.x.x.'],
    },
    push: {
      k: ['X..X....X..X....', 'X..X..x.X..X....'],
      s: ['....X.......X..x', '....X.....x.X...'],
      h: 'x.xox.x.x.xox.x.', c: ['X...............', '................'],
    },
    half: { k: 'X..X............', h: '........x.......', a: '........x.......' },
    fill: { k: 'X..X....x.......', s: '....X...x.x.X.Xx', t: '............x.o-', c: 'X...............' },
  },
  bass: {
    main: [P('0 . . . . . . . 0 . . . . . 8 .'), P('0 . . . . . . . 0 . . . 5 . . .')],
    lift: [P('0 . . 8 . . 0 . 5 . . 8 . . 12 .'), P('0 . . 5 . . 8 . 0 . . 12 . . 8 .')],
    soft: [P('0 . . . . . . . . . . . . . . .')],
  },
  gtr: {
    ring: [P('0 . . . . . . . 8 . . . . . . .'), P('0 . . . . . . . 5 . . . . . . .')],
    push: [P('0 . . 0 . . 0 . . . 0 . . . 0 .')],
    hold: [P('0 . . . . . . . . . . . . . . .')],
  },
  keys: { hold: [P('0 . . . . . . . . . . . . . . .')] },
  leads: {
    // up a fourth, up a sixth, and it never comes back down
    A: [P('0 . . . 5 . . . 8 . . . 12 . . .'),
        P('10 . . . 8 . . . 12 . . . . . . .'),
        P('5 . . . 8 . . . 12 . . . 15 . . .'),
        P('14 . . . 15 . . . 17 . . . . . . .')],
    B: [P('17 . . . 20 . . . 22 . . . 24 . . .'),
        P('22 . . . 20 . . . 17 . . . . . . .'),
        P('20 . . . 22 . . . 24 . . . 27 . . .'),
        P('26 . . . 24 . . . 22 . . . . . . .')],
    C: [P('0 . . . . . . . 5 . . . . . . .'),
        P('8 . . . . . . . . . . . . . . .'),
        P('5 . . . . . . . 12 . . . . . . .'),
        P('15 . . . . . . . . . . . . . . .')],
    // the guitar is not underneath the tune, it is beside it, a third above
    Bh: [P('5 . . . 8 . . . 12 . . . 15 . . .'),
         P('14 . . . 12 . . . 15 . . . . . . .'),
         P('8 . . . 12 . . . 15 . . . 19 . . .'),
         P('17 . . . 19 . . . 20 . . . . . . .')],
  },
  arps: {
    rise: { notes: [0, 1, 2, 3], chordal: true, rate: 2, voice: 'pluck' },
    slow: { notes: [0, 2, 1, 2], chordal: true, rate: 4, voice: 'pluck' },
  },
  form: [
    { bars: 4, chords: 'main', drums: 'intro', bass: 'soft', keys: 'hold', arp: 'slow', gain: 0.80 },
    { bars: 4, chords: 'main', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'rise' },
    { bars: 4, chords: 'main', drums: 'main', bass: 'lift', gtr: 'ring', keys: 'hold', arp: 'rise', lead: 'A' },
    { bars: 4, chords: 'lift', drums: 'push', bass: 'lift', gtr: 'push', keys: 'hold', arp: 'rise', lead: 'A', harm: 'Bh' },
    { bars: 4, chords: 'main', drums: 'push', bass: 'lift', gtr: 'push', keys: 'hold', lead: 'B', harm: 'Bh' },
    { bars: 1, chords: 'main', drums: 'fill', bass: 'lift', gtr: 'push' },
    { bars: 4, chords: 'turn', drums: 'half', bass: 'soft', gtr: 'hold', keys: 'hold', lead: 'C', arp: 'slow', gain: 0.78 },
    { bars: 4, chords: 'main', drums: 'push', bass: 'lift', gtr: 'ring', keys: 'hold', arp: 'rise', lead: 'B', harm: 'Bh' },
    { bars: 4, chords: 'lift', drums: 'main', bass: 'main', gtr: 'ring', keys: 'hold', arp: 'rise', lead: 'A' },
  ],
};

const S7_OPTIONS = { G1: S7_CLEAN, G2: S7_SPEC, G3: S7_CHILL, G4: S7_UNIT };
