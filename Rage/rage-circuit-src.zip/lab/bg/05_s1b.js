// ============================================================ STAGE 1-B options
// Four takes on the second half of stage 1.

// ---- B1: SERVICE ALLEY ----------------------------------------------------
// The current idea, done properly: a brick canyon where every wall has had a
// different life, and the fight ends in a floodlit lot.
function s1b_alley(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0a0714'; f.fillRect(0, 0, L.far.width, H);
  stars(f, L, R, r, 40, 40);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  const lot = len - 520;
  // the walls: brick, stucco and concrete in turn, each aged its own way
  let x = 0, kind = 0;
  while (x < lot) {
    const bw = r(112, 176);
    if (kind % 3 === 0) brick(n, x, 0, bw, WALK + 8, pick2(R, ['#4e2226', '#3e242c', '#583030']), R, { course: 5, bw: 12 });
    else if (kind % 3 === 1) stucco(n, x, 0, bw, WALK + 8, pick2(R, ['#4a4438', '#3e4046', '#524438']), R);
    else concrete(n, x, 0, bw, WALK + 8, '#3a3842', R);
    if (R() < 0.45) ghostSign(n, x + 12, 18, bw - 24, 34, pick2(R, ['LAUNDRY', 'COAL', 'PRINTERS', 'ICE CO', 'TAILOR']), R);
    // a standpipe, a soil stack and a run of conduit - every wall differently placed
    n.fillStyle = '#4a4e58'; n.fillRect(x + r(12, bw - 24), 0, 4, WALK);
    n.fillStyle = '#39414e'; n.fillRect(x + r(20, bw - 40), 0, 6, WALK);
    n.fillStyle = '#5a6068'; n.fillRect(x, r(48, 76), bw, 3);
    for (let k = 0; k < bw; k += 26) { n.fillStyle = '#2a2e36'; n.fillRect(x + k, r(48, 76) - 1, 5, 5); }
    // barred windows high up, a couple lit from inside
    for (let k = 0; k < 3; k++) if (R() < 0.6) {
      const wx = x + 16 + k * (bw - 32) / 3, wy = r(24, 66);
      n.fillStyle = '#100c16'; n.fillRect(wx - 2, wy - 2, 22, 22);
      n.fillStyle = R() < 0.4 ? '#c8a850' : '#1a1622'; n.fillRect(wx, wy, 18, 18);
      for (let b = 0; b < 18; b += 4) { n.fillStyle = '#100c16'; n.fillRect(wx + b, wy, 1.5, 18); }
    }
    // a back door: some with a light and steam, some boarded
    if (R() < 0.7) {
      const dx = x + r(24, bw - 46);
      if (R() < 0.7) { doorway(n, dx, WALK - 48, 24, 48, R, { col: '#2a3a3a' });
        n.fillStyle = '#3a3a44'; n.fillRect(dx - 3, WALK, 30, 4); }      // the step
      else { n.fillStyle = '#241c22'; n.fillRect(dx, WALK - 46, 24, 46);
        for (let b = 0; b < 3; b++) { n.fillStyle = '#6a5a44';
          n.save(); n.translate(dx + 12, WALK - 34 + b * 13); n.rotate((R() - 0.5) * 0.3);
          n.fillRect(-15, -2.5, 30, 5); n.restore(); } }
    }
    if (R() < 0.45) fireEscape(n, x + r(12, bw - 34), 14, 22, 3, R);
    graffiti(n, x + r(10, bw - 60), r(96, 128), R, 46);
    x += bw; kind++;
  }
  // the lot: floodlit, fenced, the city glowing behind it
  n.fillStyle = '#0c0a18'; n.fillRect(lot, 0, L.near.width - lot, WALK + 8);
  for (let bx = lot; bx < L.near.width; bx += r(22, 44)) { const bh = r(30, 82);
    n.fillStyle = '#1a1630'; n.fillRect(bx, 110 - bh, r(16, 36), bh + 40); }
  for (let k = 0; k < 70; k++) { n.fillStyle = '#d8b050'; n.fillRect(r(lot, L.near.width), r(40, 110), 1, 1); }
  for (let xx = lot + 60; xx < L.near.width; xx += 200) {
    n.fillStyle = '#16121c'; n.fillRect(xx, 20, 3, 122); n.fillRect(xx - 8, 18, 19, 5);
    n.fillStyle = '#fff8d0'; n.fillRect(xx - 7, 22, 17, 2);
    n.fillStyle = 'rgba(255,248,208,0.08)';
    n.beginPath(); n.moveTo(xx - 7, 24); n.lineTo(xx - 60, 240); n.lineTo(xx + 64, 240); n.lineTo(xx + 10, 24); n.fill();
  }
  n.strokeStyle = 'rgba(160,160,180,0.42)'; n.lineWidth = 1;
  for (let xx = lot; xx < L.near.width + 100; xx += 6) {
    n.beginPath(); n.moveTo(xx, 90); n.lineTo(xx + 50, WALK + 8); n.stroke();
    n.beginPath(); n.moveTo(xx, 90); n.lineTo(xx - 50, WALK + 8); n.stroke();
  }
  n.fillStyle = '#6a6a78'; n.fillRect(lot, 88, L.near.width - lot, 3);
  for (let xx = lot; xx < L.near.width; xx += 60) n.fillRect(xx, 88, 3, 60);
  // ground: cracked asphalt, then the lot's concrete
  n.fillStyle = '#2e2a30'; n.fillRect(0, WALK + 8, lot, 240 - WALK - 8);
  for (let k = 0; k < 700; k++) { n.fillStyle = R() < 0.5 ? '#36323a' : '#26222a'; n.fillRect(r(0, lot), r(WALK + 10, 240), 2, 1); }
  n.strokeStyle = 'rgba(0,0,0,0.35)'; n.lineWidth = 1;
  for (let k = 0; k < 14; k++) { let cx = r(0, lot), cy = r(WALK + 14, 236);
    n.beginPath(); n.moveTo(cx, cy); for (let i = 0; i < 4; i++) { cx += r(6, 18); cy += r(-7, 7); n.lineTo(cx, cy); } n.stroke(); }
  n.fillStyle = '#1e1a22'; n.fillRect(0, WALK + 8, lot, 3);
  // the floor of an alley: oil, litter, fag ends, a dropped crate slat
  for (let k = 0; k < lot / 160; k++) { n.fillStyle = 'rgba(0,0,0,0.30)';
    n.beginPath(); n.ellipse(r(0, lot), r(WALK + 20, 234), 14 + R() * 18, 5 + R() * 5, 0, 0, 7); n.fill(); }
  for (let k = 0; k < lot / 26; k++) {
    n.fillStyle = pick2(R, ['rgba(214,206,186,0.45)', 'rgba(170,160,140,0.4)', 'rgba(140,160,170,0.35)', 'rgba(180,120,90,0.35)']);
    n.save(); n.translate(r(0, lot), r(WALK + 14, 236)); n.rotate(R() * 3);
    n.fillRect(0, 0, 3 + R() * 6, 2 + R() * 2); n.restore();
  }
  for (let k = 0; k < lot / 70; k++) { n.fillStyle = '#6a5a3a';
    n.save(); n.translate(r(0, lot), r(WALK + 18, 234)); n.rotate(R() * 3);
    n.fillRect(0, 0, 12 + R() * 10, 3); n.restore(); }
  n.fillStyle = '#34343c'; n.fillRect(lot, WALK + 8, L.near.width - lot, 240 - WALK - 8);
  n.fillStyle = '#e8e8e0'; for (let xx = lot + 30; xx < L.near.width; xx += 70) n.fillRect(xx, 160, 2, 70);
  puddles(n, R, L.near.width, 170, 235, 12);
  // the clutter that makes it an alley you have walked down
  let ci = 0;
  const props = [
    (x) => dumpster(n, x, WALK + 50, R),
    (x) => { crates(n, x, WALK + 50, R, 4); },
    (x) => { trashBags(n, x, WALK + 50, R, 5); pigeon(n, x + 4, WALK + 36, R); },
    (x) => { n.fillStyle = '#3a3a44'; n.fillRect(x, WALK + 22, 22, 28);   // stacked pallets
             for (let k = 0; k < 4; k++) { n.fillStyle = '#6a5a3a'; n.fillRect(x, WALK + 24 + k * 7, 22, 4); } },
    (x) => { n.fillStyle = '#2a2a32'; n.beginPath(); n.ellipse(x, WALK + 48, 11, 13, 0, 0, 7); n.fill();
             n.fillStyle = '#3a3a46'; n.beginPath(); n.ellipse(x, WALK + 36, 11, 4, 0, 0, 7); n.fill(); },
  ];
  for (let px_ = 40; px_ < lot - 20; px_ += 62 + R() * 46) { props[ci % props.length](px_); ci++; }
}

// ---- B2: LOADING DOCKS ----------------------------------------------------
// Behind the shops: roll-up doors at different heights, bays, a truck half
// backed in, and a turntable yard at the end.
function s1b_docks(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#080614'; f.fillRect(0, 0, L.far.width, H);
  stars(f, L, R, r, 50, 46);
  skyline(f, L, R, r, 100, '#120e22', '#c8a048', 20, 56);
  m.fillStyle = '#141222'; m.fillRect(0, 44, L.mid.width, 106);
  for (let x = 0; x < L.mid.width; x += 90) { m.fillStyle = '#1c1930'; m.fillRect(x, 44, 84, 106);
    for (let k = 0; k < 8; k++) if (R() < 0.4) { m.fillStyle = '#d8c070'; m.fillRect(x + 8 + R() * 66, 52 + R() * 80, 4, 5); } }
  const yard = len - 460;
  // the dock wall: a long low shed face, bays punched into it
  concrete(n, 0, 0, yard, WALK + 6, '#3e414c', R);
  n.fillStyle = '#2a2d36'; n.fillRect(0, 0, yard, 16);
  for (let k = 0; k < yard; k += 74) { n.fillStyle = '#4a4e5a'; n.fillRect(k, 14, 60, 4);   // canopy over the bays
    n.fillStyle = '#20232b'; n.fillRect(k, 18, 60, 3); }
  let x = 10, bay = 0;
  while (x < yard - 60) {
    const bw = 58 + R() * 30, bh = 62 + R() * 22, top = WALK + 6 - bh;
    n.fillStyle = '#16181f'; n.fillRect(x - 3, top - 3, bw + 6, bh + 3);
    const open = R() < 0.4;
    if (open) {
      n.fillStyle = '#0c0d12'; n.fillRect(x, top, bw, bh);
      n.fillStyle = 'rgba(255,220,140,0.13)'; n.fillRect(x, top + bh * 0.3, bw, bh * 0.7);
      for (let k = 0; k < 3; k++) if (R() < 0.7) {            // pallets inside
        n.fillStyle = '#5a4a30'; n.fillRect(x + 6 + k * (bw - 16) / 3, top + bh - 22, 14, 20);
        n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 6 + k * (bw - 16) / 3, top + bh - 14, 14, 2); }
      n.fillStyle = '#39414e'; n.fillRect(x, top, bw, 10);     // the rolled-up shutter
      for (let k = top + 1; k < top + 10; k += 2) { n.fillStyle = '#4e5a6a'; n.fillRect(x, k, bw, 1); }
    } else {
      const c = pick2(R, ['#8a5a20', '#2a5a6a', '#6a2a2a', '#4a5a3a', '#5a5a64']);
      n.fillStyle = c; n.fillRect(x, top, bw, bh);
      for (let k = top; k < top + bh; k += 5) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x, k, bw, 1.5); }
      n.fillStyle = 'rgba(255,255,255,0.08)'; n.fillRect(x, top, bw, 2);
      if (R() < 0.5) graffiti(n, x + 6, top + bh * 0.6, R, bw - 14);
      n.fillStyle = '#e8e0d0'; ptext(n, String(bay + 1), x + bw / 2 - 2, top + 6, '#e8e0d0');
    }
    n.fillStyle = '#24262e'; n.fillRect(x - 4, WALK + 6, bw + 8, 5);      // dock bumpers
    n.fillStyle = '#16181e'; n.fillRect(x - 2, WALK + 8, 8, 8); n.fillRect(x + bw - 6, WALK + 8, 8, 8);
    if (R() < 0.5) { n.fillStyle = '#ffe08a'; n.fillRect(x + bw / 2 - 5, top - 9, 10, 3);
      n.fillStyle = 'rgba(255,224,138,0.10)'; n.fillRect(x - 8, top - 6, bw + 16, 60); }
    x += bw + 22 + R() * 30; bay++;
  }
  // a box truck reversed into one bay, the cab jutting into the alley
  const tx = Math.min(yard - 210, 420);
  n.fillStyle = '#12121a'; n.fillRect(tx, WALK - 54, 130, 60);
  n.fillStyle = '#8a8e9a'; n.fillRect(tx + 2, WALK - 52, 126, 56);
  n.fillStyle = '#6a6e7a'; n.fillRect(tx + 2, WALK - 52, 126, 4);
  n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(tx + 2, WALK - 8, 126, 12);
  ptext(n, 'HALLOWAY', tx + 24, WALK - 34, '#2a3a5a', 2);
  ptext(n, 'HAULAGE', tx + 34, WALK - 20, '#8a2a3a');
  n.fillStyle = '#12121a'; n.fillRect(tx + 128, WALK - 42, 40, 48);
  n.fillStyle = '#7a2a30'; n.fillRect(tx + 130, WALK - 40, 36, 44);
  n.fillStyle = '#2a3a4a'; n.fillRect(tx + 136, WALK - 36, 24, 14);
  n.fillStyle = '#12121a'; n.beginPath(); n.arc(tx + 30, WALK + 8, 8, 0, 7); n.arc(tx + 148, WALK + 8, 8, 0, 7); n.fill();
  // the yard: a turntable, stacked containers, floodlight masts
  n.fillStyle = '#0d0c16'; n.fillRect(yard, 0, L.near.width - yard, WALK + 6);
  for (let cx = yard + 20; cx < L.near.width; cx += 92) {
    for (let s = 0; s < 2; s++) { const c = pick2(R, ['#2a6a8a', '#8a3a2a', '#3a7a3a', '#8a7a2a']);
      n.fillStyle = c; n.fillRect(cx, 62 + s * 40, 84, 38);
      for (let k = cx + 3; k < cx + 84; k += 7) { n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(k, 64 + s * 40, 2, 34); }
      n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(cx, 62 + s * 40, 84, 2); }
  }
  for (let xx = yard + 50; xx < L.near.width; xx += 190) {
    n.fillStyle = '#16141c'; n.fillRect(xx, 10, 4, 136); n.fillRect(xx - 10, 8, 24, 5);
    n.fillStyle = '#fff8d0'; n.fillRect(xx - 9, 13, 10, 3); n.fillRect(xx + 4, 13, 8, 3);
    n.fillStyle = 'rgba(255,248,208,0.08)';
    n.beginPath(); n.moveTo(xx - 9, 16); n.lineTo(xx - 70, 240); n.lineTo(xx + 74, 240); n.lineTo(xx + 12, 16); n.fill();
  }
  n.fillStyle = '#33323c'; n.fillRect(0, WALK + 6, L.near.width, 240 - WALK - 6);
  for (let k = 0; k < 800; k++) { n.fillStyle = R() < 0.5 ? '#3b3a46' : '#2a2934'; n.fillRect(r(0, L.near.width), r(WALK + 8, 240), 3, 1); }
  n.fillStyle = '#1e1d26'; n.fillRect(0, WALK + 6, L.near.width, 3);
  // yard floor: tyre tracks off every bay, spilled grit, painted bay numbers
  for (let k = 0; k < L.near.width / 90; k++) {
    const tx2 = r(0, L.near.width);
    n.fillStyle = 'rgba(0,0,0,0.22)';
    for (const off of [0, 9]) n.fillRect(tx2 + off, WALK + 10, 4, 40 + R() * 40);
  }
  for (let k = 0; k < L.near.width / 22; k++) {
    n.fillStyle = pick2(R, ['rgba(200,194,176,0.4)', 'rgba(160,150,132,0.35)', 'rgba(130,150,160,0.3)']);
    n.save(); n.translate(r(0, L.near.width), r(WALK + 12, 236)); n.rotate(R() * 3);
    n.fillRect(0, 0, 3 + R() * 6, 2); n.restore();
  }
  for (let k = 0; k < L.near.width / 200; k++) { n.fillStyle = 'rgba(0,0,0,0.30)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(WALK + 24, 232), 16 + R() * 18, 5 + R() * 5, 0, 0, 7); n.fill(); }
  for (let k = 0; k < L.near.width; k += 16) { n.fillStyle = (k / 16) % 2 ? '#c8b830' : '#2a2934'; n.fillRect(k, 186, 16, 3); }
  puddles(n, R, L.near.width, 190, 236, 14, 'rgba(130,150,200,0.18)');
  let ci = 0;
  const props = [(x) => crates(n, x, WALK + 52, R, 4), (x) => dumpster(n, x, WALK + 52, R),
    (x) => { n.fillStyle = '#e88a20'; for (let k = 0; k < 3; k++) { n.beginPath();
      n.moveTo(x + k * 16, WALK + 52); n.lineTo(x + 6 + k * 16, WALK + 34); n.lineTo(x + 12 + k * 16, WALK + 52); n.fill();
      n.fillStyle = '#fff'; n.fillRect(x + 4 + k * 16, WALK + 42, 5, 2); n.fillStyle = '#e88a20'; } },
    (x) => { n.fillStyle = '#5a4a30'; for (let k = 0; k < 5; k++) n.fillRect(x, WALK + 50 - k * 5, 30, 4); }];
  for (let px_ = 50; px_ < L.near.width - 40; px_ += 78 + R() * 54) { props[ci % props.length](px_); ci++; }
}

// ---- B3: THE SUBWAY CUT ---------------------------------------------------
// The alley drops into the underground: stairs, a tiled mezzanine, then the
// platform itself with a train waiting and the tunnel mouth behind the boss.
function s1b_subway(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#07060e'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  const stair = 300, plat = 620;
  // the street end: night sky over a stair head
  skyGrad(f, L, [[0, '#07051a'], [0.7, '#241640'], [1, '#4a2044']]);
  stars(f, L, R, r, 40, 50);
  skyline(f, L, R, r, 120, '#120e22', '#d8a048', 24, 66);
  brick(n, 0, 0, stair, WALK + 6, '#44262a', R, { course: 5, bw: 12 });
  graffiti(n, 40, 100, R, 70);
  // the stair head, railings and the glow coming up out of it
  n.fillStyle = '#0a0a10'; n.fillRect(stair - 120, 46, 130, WALK - 40);
  n.fillStyle = '#2a7a4a'; n.fillRect(stair - 130, 34, 150, 14);
  ptext(n, 'SUBWAY', stair - 104, 37, '#e8f0e8', 2);
  n.fillStyle = '#16141c';
  n.fillRect(stair - 124, 48, 3, 96); n.fillRect(stair + 8, 48, 3, 96);
  for (let k = 0; k < 96; k += 9) n.fillRect(stair - 124, 48 + k, 135, 2);
  n.fillStyle = 'rgba(200,220,160,0.10)'; n.fillRect(stair - 120, 60, 128, 86);
  // the mezzanine and platform: white tile, steel columns, a mosaic name panel
  n.fillStyle = '#18202a'; n.fillRect(stair, 0, L.near.width - stair, WALK + 6);
  for (let ty = 8; ty < WALK; ty += 11) for (let tx2 = stair; tx2 < L.near.width; tx2 += 15) {
    n.fillStyle = (Math.round(ty / 11) + Math.round(tx2 / 15)) % 2 ? '#c8cdc4' : '#bcc2b8';
    n.fillRect(tx2, ty, 14, 10);
  }
  n.fillStyle = 'rgba(0,0,0,0.18)'; n.fillRect(stair, 0, L.near.width - stair, WALK + 6);
  n.fillStyle = '#2a3038'; n.fillRect(stair, 0, L.near.width - stair, 22);
  for (let xx = stair + 20; xx < L.near.width; xx += 64) {            // ceiling lights
    n.fillStyle = '#e8f4ff'; n.fillRect(xx, 14, 30, 4);
    n.fillStyle = 'rgba(210,240,255,0.10)'; n.fillRect(xx - 8, 18, 46, 46);
  }
  // mosaic station name, repeated properly the way a real platform does
  for (let xx = stair + 60; xx < L.near.width; xx += 300) {
    n.fillStyle = '#16323a'; n.fillRect(xx, 52, 110, 30);
    n.fillStyle = '#d8b040'; n.fillRect(xx + 3, 55, 104, 24);
    n.fillStyle = '#16323a'; n.fillRect(xx + 6, 58, 98, 18);
    ptext(n, 'CANAL ST', xx + 16, 62, '#e8e0c8', 2);
  }
  for (let xx = stair + 40; xx < L.near.width; xx += 108) {           // steel columns
    n.fillStyle = '#2a3a42'; n.fillRect(xx, 0, 12, WALK + 6);
    n.fillStyle = '#3e525c'; n.fillRect(xx + 2, 0, 4, WALK + 6);
    n.fillStyle = 'rgba(0,0,0,0.38)'; n.fillRect(xx + 9, 0, 3, WALK + 6);
    for (let k = 18; k < WALK; k += 20) { n.fillStyle = '#5a7080'; n.fillRect(xx + 1, k, 2, 2); n.fillRect(xx + 8, k, 2, 2); }
  }
  // the train standing at the platform behind the fight
  n.fillStyle = '#0a0c10'; n.fillRect(plat, 58, L.near.width - plat, 86);
  n.fillStyle = '#5a6470'; n.fillRect(plat + 6, 64, L.near.width - plat, 78);
  n.fillStyle = '#39414e'; n.fillRect(plat + 6, 64, L.near.width - plat, 6);
  n.fillStyle = '#c83030'; n.fillRect(plat + 6, 96, L.near.width - plat, 4);
  for (let k = plat + 18; k < L.near.width; k += 56) {
    n.fillStyle = '#0e1620'; n.fillRect(k, 74, 20, 20);
    n.fillStyle = '#8ad0e8'; n.fillRect(k + 1, 75, 18, 18);
    if (R() < 0.6) { n.fillStyle = 'rgba(0,0,0,0.5)'; n.fillRect(k + 6, 80, 7, 13);
      n.beginPath(); n.arc(k + 9.5, 79, 3, 0, 7); n.fill(); }
    n.fillStyle = '#2a3038'; n.fillRect(k + 24, 70, 22, 72);          // the doors
    n.fillStyle = '#8ad0e8'; n.fillRect(k + 26, 76, 8, 18); n.fillRect(k + 36, 76, 8, 18);
  }
  // the floor: platform edge with tactile strip, then the track well
  n.fillStyle = '#4a4e56'; n.fillRect(0, WALK + 6, L.near.width, 240 - WALK - 6);
  for (let k = 0; k < 500; k++) { n.fillStyle = R() < 0.5 ? '#545862' : '#3e424a'; n.fillRect(r(0, L.near.width), r(WALK + 8, 240), 3, 1); }
  n.fillStyle = '#2e3238'; n.fillRect(0, WALK + 6, L.near.width, 3);
  n.fillStyle = '#d8d030'; n.fillRect(stair, 228, L.near.width - stair, 5);
  for (let k = stair; k < L.near.width; k += 6) { n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(k, 229, 3, 3); }
  // benches, bins, a busker's case and a rat
  let ci = 0;
  const props = [
    (x) => { n.fillStyle = '#5a3a24'; n.fillRect(x, WALK + 30, 46, 5); n.fillRect(x, WALK + 20, 46, 4);
             n.fillStyle = '#2a2a32'; n.fillRect(x + 3, WALK + 22, 3, 24); n.fillRect(x + 40, WALK + 22, 3, 24); },
    (x) => { n.fillStyle = '#2a3038'; n.fillRect(x, WALK + 18, 20, 28);
             n.fillStyle = '#3e4650'; n.fillRect(x + 1, WALK + 18, 18, 4); trashBags(n, x + 22, WALK + 46, R, 1); },
    (x) => { n.fillStyle = '#3a2a1a'; n.fillRect(x, WALK + 36, 26, 10);
             n.fillStyle = '#c8a040'; n.fillRect(x + 4, WALK + 38, 6, 4); n.fillRect(x + 14, WALK + 39, 5, 3); },
    (x) => { n.fillStyle = '#4a4a52'; n.beginPath(); n.ellipse(x, WALK + 43, 5, 2.4, 0, 0, 7); n.fill();
             n.fillRect(x + 4, WALK + 42, 7, 1); },
  ];
  for (let px_ = stair + 60; px_ < L.near.width - 40; px_ += 150 + R() * 90) { props[ci % props.length](px_); ci++; }
}

// ---- B4: THE ROOFTOPS -----------------------------------------------------
// The wildcard: the alley goes up instead of along. Tar roofs, water towers,
// laundry lines and the whole skyline behind you.
function s1b_roofs(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#050418'], [0.42, '#291646'], [0.78, '#7a2a52'], [1, '#c85a48']]);
  stars(f, L, R, r, 70, 60);
  f.fillStyle = '#e8e2c8'; f.beginPath(); f.arc(340, 34, 13, 0, 7); f.fill();
  f.fillStyle = '#291646'; f.beginPath(); f.arc(346, 30, 12, 0, 7); f.fill();
  skyline(f, L, R, r, 150, '#100c24', '#e8c860', 50, 132);
  // mid: the next rank of roofs, close enough to see their water tanks
  for (let x = 0; x < L.mid.width; x += r(70, 130)) {
    const h = r(30, 78);
    m.fillStyle = '#1a1430'; m.fillRect(x, 150 - h, 118, h + 20);
    m.fillStyle = '#241c42'; m.fillRect(x, 150 - h, 118, 4);
    for (let k = 0; k < 5; k++) if (R() < 0.5) { m.fillStyle = '#d8b050'; m.fillRect(x + 8 + R() * 100, 150 - h + 10 + R() * (h - 14), 3, 4); }
    if (R() < 0.6) { const tx = x + 20 + R() * 70;
      m.fillStyle = '#2a2030'; m.fillRect(tx, 150 - h - 20, 17, 14);
      m.beginPath(); m.moveTo(tx - 2, 150 - h - 20); m.lineTo(tx + 8.5, 150 - h - 28); m.lineTo(tx + 19, 150 - h - 20); m.fill();
      m.fillRect(tx + 2, 150 - h - 6, 2, 6); m.fillRect(tx + 13, 150 - h - 6, 2, 6); }
  }
  // near: the roof you fight on, stepping up and down between blocks
  let x = 0;
  while (x < L.near.width) {
    const bw = r(150, 260), lift = r(-8, 10);
    const top = WALK + lift;
    n.fillStyle = '#2a2430'; n.fillRect(x, top, bw, 240 - top);       // tar
    for (let k = 0; k < bw * 1.4; k++) { n.fillStyle = R() < 0.5 ? '#332c3a' : '#241f2b'; n.fillRect(x + R() * bw, top + 4 + R() * (236 - top), 3, 1); }
    for (let sy = top + 12; sy < 240; sy += 17) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(x, sy, bw, 2); }  // rolled seams
    n.fillStyle = '#4a4254'; n.fillRect(x, top - 12, bw, 13);          // parapet
    n.fillStyle = '#5e5668'; n.fillRect(x, top - 12, bw, 3);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x, top + 1, bw, 3);
    if (R() < 0.6) { n.fillStyle = '#2a2430'; n.fillRect(x + bw - 4, top - 12, 5, 250 - top); }  // party wall between roofs
    // what lives on a roof
    const put = [];
    if (R() < 0.75) put.push(() => {                                   // water tower
      const tx = x + 20 + R() * (bw - 70);
      n.fillStyle = '#16121c'; n.fillRect(tx + 3, top - 8, 3, 12); n.fillRect(tx + 34, top - 8, 3, 12);
      n.fillStyle = '#3a2a20'; n.fillRect(tx, top - 44, 40, 38);
      for (let k = 0; k < 40; k += 5) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(tx + k, top - 44, 1.5, 38); }
      n.fillStyle = '#5a4432'; n.fillRect(tx, top - 34, 40, 2); n.fillRect(tx, top - 20, 40, 2);
      n.fillStyle = '#2a2028'; n.beginPath(); n.moveTo(tx - 3, top - 44); n.lineTo(tx + 20, top - 60); n.lineTo(tx + 43, top - 44); n.fill();
    });
    if (R() < 0.7) put.push(() => {                                    // AC plant
      const ax = x + 20 + R() * (bw - 60);
      n.fillStyle = '#1e1c26'; n.fillRect(ax, top - 26, 48, 27);
      n.fillStyle = '#2e2c3a'; n.fillRect(ax + 2, top - 24, 44, 23);
      n.fillStyle = '#16141c'; n.beginPath(); n.arc(ax + 24, top - 12, 10, 0, 7); n.fill();
      for (let k = 0; k < 4; k++) { n.fillStyle = '#4a4858'; n.save(); n.translate(ax + 24, top - 12);
        n.rotate(k * 0.78); n.fillRect(-1.5, -9, 3, 18); n.restore(); }
    });
    if (R() < 0.6) put.push(() => {                                    // pigeon coop
      const cx = x + 20 + R() * (bw - 50);
      n.fillStyle = '#5a4a32'; n.fillRect(cx, top - 24, 40, 25);
      n.fillStyle = '#3a2e1e'; n.fillRect(cx, top - 28, 44, 5);
      for (let k = 0; k < 40; k += 4) { n.fillStyle = 'rgba(0,0,0,0.4)'; n.fillRect(cx + k, top - 20, 1, 16); }
      for (let k = 0; k < 3; k++) pigeon(n, cx + 6 + k * 14, top - 29, R);
    });
    if (R() < 0.5) put.push(() => {                                    // laundry on a line
      const lx = x + 16 + R() * (bw - 90);
      n.fillStyle = '#16121c'; n.fillRect(lx, top - 34, 2, 35); n.fillRect(lx + 76, top - 34, 2, 35);
      n.strokeStyle = 'rgba(200,200,210,0.5)'; n.lineWidth = 1;
      n.beginPath(); n.moveTo(lx, top - 32); n.quadraticCurveTo(lx + 38, top - 22, lx + 76, top - 32); n.stroke();
      for (let k = 0; k < 5; k++) { n.fillStyle = pick2(R, ['#d8d0c0', '#8ab8d8', '#d88a9a', '#e8d070', '#a8c8a0']);
        n.fillRect(lx + 8 + k * 13, top - 30 + Math.sin(k) * 2 + k, 9, 12); }
    });
    if (R() < 0.45) put.push(() => {                                   // satellite dishes
      const dx = x + 20 + R() * (bw - 40);
      for (let k = 0; k < 2; k++) { n.fillStyle = '#c8c4cc';
        n.beginPath(); n.ellipse(dx + k * 18, top - 14, 8, 9, 0.4, 0, 7); n.fill();
        n.fillStyle = '#16141c'; n.fillRect(dx + k * 18 - 1, top - 8, 2, 9); n.fillRect(dx + k * 18 - 4, top, 8, 2); }
    });
    put.forEach(fn => fn());
    if (R() < 0.6) { const sx = x + 30 + R() * (bw - 60);              // stair bulkhead with a lit door
      n.fillStyle = '#382f40'; n.fillRect(sx, top - 40, 34, 41);
      n.fillStyle = '#463c50'; n.fillRect(sx - 2, top - 44, 38, 5);
      doorway(n, sx + 9, top - 28, 16, 29, R, { col: '#2a3a3a', light: false });
      n.fillStyle = '#e8c860'; n.fillRect(sx + 11, top - 26, 12, 4);
      n.fillStyle = 'rgba(232,200,96,0.10)'; n.fillRect(sx + 4, top - 24, 26, 24); }
    x += bw;
  }
  // the pipes and vents underfoot, and a skylight or two you can see down into
  for (let px_ = 60; px_ < L.near.width; px_ += 130 + R() * 80) {
    if (R() < 0.5) { n.fillStyle = '#2a2a32'; n.fillRect(px_, 196, 34, 6);
      n.fillStyle = '#3a3a46'; n.fillRect(px_, 196, 34, 2);
      n.fillStyle = '#20202a'; n.fillRect(px_ - 3, 194, 5, 10); n.fillRect(px_ + 32, 194, 5, 10); }
    else { n.fillStyle = '#16141c'; n.fillRect(px_, 190, 30, 16);
      n.fillStyle = 'rgba(255,220,140,0.30)'; n.fillRect(px_ + 2, 192, 26, 12);
      for (let k = 0; k < 30; k += 7) { n.fillStyle = '#16141c'; n.fillRect(px_ + k, 190, 2, 16); } }
  }
  for (let k = 0; k < 24; k++) pigeon(n, r(0, L.near.width), r(200, 236), R);
}
