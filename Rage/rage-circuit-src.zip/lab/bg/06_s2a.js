// ============================================================ STAGE 2-A options
// Four takes on the nightlife strip outside the club.

// ---- nightlife building types, built from the same primitives ----
function bldgClubFront(g, x, w, R) {
  const top = 10;
  g.fillStyle = '#140c1c'; g.fillRect(x, top, w, GROUND - top);
  g.fillStyle = '#1e1228'; for (let y = top + 4; y < GROUND; y += 8) g.fillRect(x, y, w, 1);
  cornice(g, x, top, w, '#2a1a30', 5);
  // marquee with chasing bulbs and the night's name
  const mx = x + 10, mw = w - 20, my = top + 14;
  g.fillStyle = '#0a0610'; g.fillRect(mx, my, mw, 34);
  const nc = pick2(R, ['#ff2a8a', '#4ae8ff', '#e8ff4a', '#8a6aff']);
  g.strokeStyle = nc; g.lineWidth = 2; g.strokeRect(mx + 2, my + 2, mw - 4, 30);
  for (let k = mx + 4; k < mx + mw - 4; k += 8) {
    g.fillStyle = (Math.round(k / 8) % 2) ? '#ffe08a' : '#ff8ac8';
    g.fillRect(k, my - 3, 3, 3); g.fillRect(k, my + 33, 3, 3);
  }
  const name = pick2(R, ['VELVET', 'THE PIT', 'SAINTS', 'LUX', 'BASEMENT', 'RUBY ROOM']);
  neonText(g, name, mx + mw / 2 - tw(name, 2) / 2, my + 12, nc, 2);
  // doors, rope line and a bouncer's podium
  const dx = x + w / 2;
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x, GROUND - 56, w, 56);
  g.fillStyle = '#2a0a1a'; g.fillRect(dx - 26, GROUND - 52, 52, 52);
  g.fillStyle = '#4a1028'; g.fillRect(dx - 24, GROUND - 50, 22, 48); g.fillRect(dx + 2, GROUND - 50, 22, 48);
  g.fillStyle = '#e8c860'; g.fillRect(dx - 4, GROUND - 28, 2, 10); g.fillRect(dx + 2, GROUND - 28, 2, 10);
  g.fillStyle = 'rgba(255,90,180,0.16)'; g.fillRect(dx - 26, GROUND - 52, 52, 52);
  for (const sx of [dx - 54, dx - 30, dx + 30, dx + 54]) {
    g.fillStyle = '#c8a040'; g.fillRect(sx, GROUND - 22, 3, 22);
    g.fillStyle = '#e8c860'; g.fillRect(sx - 2, GROUND - 25, 7, 4);
  }
  g.strokeStyle = '#a01838'; g.lineWidth = 2.5;
  g.beginPath(); g.moveTo(dx - 52, GROUND - 18); g.quadraticCurveTo(dx - 41, GROUND - 8, dx - 29, GROUND - 18); g.stroke();
  g.beginPath(); g.moveTo(dx + 32, GROUND - 18); g.quadraticCurveTo(dx + 43, GROUND - 8, dx + 55, GROUND - 18); g.stroke();
  // poster cases either side
  for (const px_ of [x + 6, x + w - 26]) {
    g.fillStyle = '#16121c'; g.fillRect(px_, GROUND - 46, 20, 30);
    g.fillStyle = pick2(R, ['#8a2a5a', '#2a4a8a', '#6a2a6a', '#1a6a6a']); g.fillRect(px_ + 1, GROUND - 45, 18, 28);
    g.fillStyle = 'rgba(255,255,255,0.14)'; g.fillRect(px_ + 3, GROUND - 42, 14, 12);
    ptext(g, 'FRI', px_ + 4, GROUND - 26, '#f0e0b0');
  }
}
function bldgTattoo(g, x, w, R) {
  const top = 30 + R() * 12;
  brick(g, x, top, w, GROUND - top, '#3e2a3a', R, { course: 5, bw: 11 });
  cornice(g, x, top, w, '#2a1e2a', 4);
  windowGrid(g, x + 6, top + 10, w - 12, 30, 2, 1, R, { litRate: 0.3 });
  g.fillStyle = '#16121c'; g.fillRect(x + 4, GROUND - 52, w - 8, 52);
  shopWindow(g, x + 8, GROUND - 44, w * 0.52, 34, R, { inner: '#2a1a2a' });
  // flash sheets in the window
  for (let k = 0; k < 6; k++) { g.fillStyle = pick2(R, ['#c83050', '#e8d040', '#40a0c8', '#e8e8e8']);
    g.fillRect(x + 12 + (k % 3) * 13, GROUND - 40 + Math.floor(k / 3) * 15, 10, 12); }
  doorway(g, x + w * 0.68, GROUND - 44, 18, 44, R, { col: '#2a1a2a' });
  const word = pick2(R, ['TATTOO', 'INK', 'PIERCE']);
  neonText(g, word, x + w / 2 - tw(word) / 2, GROUND - 60, '#4ae8ff');
  // a neon needle-and-rose sign hanging out over the pavement
  g.fillStyle = '#16121c'; g.fillRect(x + w - 16, GROUND - 78, 3, 18);
  g.save(); g.shadowColor = '#ff3a6a'; g.shadowBlur = 7; g.fillStyle = '#ff3a6a';
  g.beginPath(); g.arc(x + w - 26, GROUND - 62, 7, 0, 7); g.fill();
  g.fillRect(x + w - 28, GROUND - 56, 4, 10); g.restore();
}
function bldgPawn(g, x, w, R) {
  const top = 34 + R() * 10;
  stucco(g, x, top, w, GROUND - top, '#4a4438', R);
  cornice(g, x, top, w, '#2e2a22', 4);
  windowGrid(g, x + 6, top + 10, w - 12, 26, 2, 1, R, { litRate: 0.25 });
  g.fillStyle = '#16121c'; g.fillRect(x + 4, GROUND - 50, w - 8, 50);
  shopWindow(g, x + 8, GROUND - 42, w - 34, 32, R, { inner: '#3a3020' });
  // guitars, rings and a television behind the grille
  for (let k = 0; k < 4; k++) { g.fillStyle = pick2(R, ['#c8a040', '#8a5a2a', '#c0c8d0', '#6a3a2a']);
    g.fillRect(x + 14 + k * 14, GROUND - 36, 8, 18); }
  for (let gx2 = x + 8; gx2 < x + w - 26; gx2 += 5) { g.fillStyle = 'rgba(20,16,28,0.7)'; g.fillRect(gx2, GROUND - 42, 1.5, 32); }
  doorway(g, x + w - 24, GROUND - 42, 16, 42, R, { col: '#3a2418' });
  neonText(g, 'PAWN', x + 10, GROUND - 58, '#ffe04a');
  // the three balls
  for (let k = 0; k < 3; k++) { g.fillStyle = '#d8b040';
    g.beginPath(); g.arc(x + w - 30 + (k - 1) * 9, GROUND - 60 + (k === 1 ? 5 : 0), 4, 0, 7); g.fill(); }
}
function bldgArcade(g, x, w, R) {
  const top = 22;
  g.fillStyle = '#1a1226'; g.fillRect(x, top, w, GROUND - top);
  cornice(g, x, top, w, '#2a1a3a', 5);
  // a wall of glowing cabinets seen through an open front
  g.fillStyle = '#0a0812'; g.fillRect(x + 4, GROUND - 74, w - 8, 74);
  for (let k = 0; k < Math.floor((w - 16) / 22); k++) {
    const cx = x + 10 + k * 22;
    g.fillStyle = pick2(R, ['#2a2a4a', '#4a2a3a', '#2a4a3a', '#3a2a5a']);
    g.fillRect(cx, GROUND - 58, 17, 58);
    g.fillStyle = '#0c0a14'; g.fillRect(cx + 2, GROUND - 52, 13, 14);
    g.fillStyle = pick2(R, ['#4ae8ff', '#ff4a8a', '#e8ff4a', '#8a6aff']); g.fillRect(cx + 3, GROUND - 51, 11, 12);
    g.fillStyle = 'rgba(255,255,255,0.18)'; g.fillRect(cx, GROUND - 58, 17, 3);
    g.fillStyle = '#16141c'; g.fillRect(cx + 4, GROUND - 34, 9, 4);
  }
  g.fillStyle = 'rgba(120,80,220,0.10)'; g.fillRect(x + 4, GROUND - 74, w - 8, 74);
  const word = 'ARCADE';
  g.fillStyle = '#0c0a12'; g.fillRect(x + 6, GROUND - 92, w - 12, 16);
  neonText(g, word, x + w / 2 - tw(word, 2) / 2, GROUND - 90, '#ff4ab0', 2);
  for (let k = x + 8; k < x + w - 8; k += 7) { g.fillStyle = (Math.round(k / 7) % 2) ? '#ffe08a' : '#2a2030';
    g.fillRect(k, GROUND - 96, 3, 3); }
}
function bldgLiquor(g, x, w, R) {
  const top = 40 + R() * 10;
  brick(g, x, top, w, GROUND - top, '#4a3a2e', R, { course: 5, bw: 12 });
  g.fillStyle = '#16121c'; g.fillRect(x + 4, GROUND - 48, w - 8, 48);
  shopWindow(g, x + 8, GROUND - 40, w * 0.5, 30, R, { inner: '#2a2a1a' });
  for (let k = 0; k < 8; k++) { g.fillStyle = pick2(R, ['#3a8a3a', '#8a3a2a', '#c8c060', '#6a8ab8']);
    g.fillRect(x + 12 + (k % 4) * 9, GROUND - 34 + Math.floor(k / 4) * 13, 5, 11); }
  doorway(g, x + w * 0.66, GROUND - 40, 17, 40, R);
  neonText(g, 'LIQUOR', x + 10, GROUND - 56, '#ff8a2a');
  neonText(g, 'OPEN 24', x + 10, GROUND - 46, '#4ae8ff');
  awning(g, x + 4, GROUND - 66, w - 8, R, ['#7a1a2a', '#e8e0d0']);
}
const NIGHT_BUILDINGS = [
  { f: bldgClubFront, w: [150, 200] }, { f: bldgTattoo, w: [104, 134] },
  { f: bldgPawn, w: [110, 140] },      { f: bldgArcade, w: [130, 176] },
  { f: bldgLiquor, w: [100, 130] },    { f: bldgTheatre, w: [150, 190] },
  { f: bldgDiner, w: [112, 144] },     { f: bldgTenement, w: [120, 160] },
];

// ---- A1: NEON MILE --------------------------------------------------------
function s2a_mile(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#07041a'], [0.5, '#2e0d3e'], [1, '#7a1f4a']]);
  stars(f, L, R, r, 50, 56);
  skyline(f, L, R, r, 130, '#160e26', '#e8b050', 40, 100);
  // mid: the rest of the strip running away, all sign and no building
  for (let x = 0; x < L.mid.width;) {
    const bw = r(44, 84), bh = r(60, 116);
    m.fillStyle = '#20122e'; m.fillRect(x, 136 - bh, bw, bh + 10);
    for (let k = 0; k < 4; k++) if (R() < 0.7) {
      const c = pick2(R, ['#ff2a8a', '#4ae8ff', '#ffe02a', '#8a2aff', '#2aff8a']);
      m.save(); m.shadowColor = c; m.shadowBlur = 5; m.fillStyle = c;
      m.fillRect(x + 5 + R() * (bw - 26), 136 - bh + 10 + k * 22, 14 + R() * 12, 4); m.restore();
    }
    x += bw + r(3, 14);
  }
  blockRun(n, 0, len - 300, R, r, NIGHT_BUILDINGS);
  // the club the stage is named for: the whole end of the strip
  const c0 = len - 300;
  n.fillStyle = '#140818'; n.fillRect(c0, 0, L.near.width - c0, GROUND);
  n.fillStyle = '#1e0c22'; for (let y = 4; y < GROUND; y += 8) n.fillRect(c0, y, L.near.width - c0, 1);
  const cw = L.near.width - c0;
  n.fillStyle = '#0a0610'; n.fillRect(c0 + 40, 44, cw - 80, 46);
  n.strokeStyle = '#ff2a8a'; n.lineWidth = 2; n.strokeRect(c0 + 42, 46, cw - 84, 42);
  for (let k = c0 + 44; k < c0 + cw - 44; k += 8) { n.fillStyle = (Math.round(k / 8) % 2) ? '#ffe08a' : '#ff8ac8';
    n.fillRect(k, 40, 3, 3); n.fillRect(k, 89, 3, 3); }
  neonText(n, 'CLUB VELVET', c0 + cw / 2 - tw('CLUB VELVET', 3) / 2, 56, '#ff4ab0', 3);
  n.fillStyle = '#2a0a1a'; n.fillRect(c0 + cw / 2 - 34, GROUND - 60, 68, 60);
  n.fillStyle = '#4a1028'; n.fillRect(c0 + cw / 2 - 31, GROUND - 57, 29, 57); n.fillRect(c0 + cw / 2 + 2, GROUND - 57, 29, 57);
  n.fillStyle = 'rgba(255,90,180,0.18)'; n.fillRect(c0 + cw / 2 - 34, GROUND - 60, 68, 60);
  neonText(n, 'VIP', c0 + 30, GROUND - 76, '#ffe04a');
  neonText(n, 'LIVE DJ', c0 + cw - 76, GROUND - 76, '#4ae8ff');
  paveAndRoad(n, L, R, r, { pave: '#4c4356', pave2: '#564c62', road: '#25222e', lineCol: '#d8a838' });
  // wet tarmac holding all that sign: the thing that makes a strip a strip
  for (let k = 0; k < L.near.width / 26; k++) {
    n.fillStyle = pick2(R, ['rgba(255,42,138,0.13)', 'rgba(74,232,255,0.12)', 'rgba(232,224,42,0.10)', 'rgba(138,42,255,0.11)']);
    n.fillRect(r(0, L.near.width), ROAD + 2, 10 + R() * 18, 24 + R() * 16);
  }
  puddles(n, R, L.near.width, ROAD + 6, 236, 22, 'rgba(180,120,220,0.20)');
  puddles(n, R, L.near.width, WALK + 10, CURB - 6, 12, 'rgba(120,180,230,0.14)');
  // the queue barrier running most of the block, taxis waiting at the kerb
  for (let x = 40; x < L.near.width - 60; x += 26) {
    if ((x / 26) % 9 > 6) continue;
    n.fillStyle = '#c8a040'; n.fillRect(x, CURB - 26, 3, 26);
    n.fillStyle = '#e8c860'; n.fillRect(x - 2, CURB - 29, 7, 4);
    n.strokeStyle = '#a01838'; n.lineWidth = 2;
    n.beginPath(); n.moveTo(x + 3, CURB - 22); n.quadraticCurveTo(x + 14, CURB - 12, x + 26, CURB - 22); n.stroke();
  }
  let pi = 0;
  const props = [(x) => streetLamp(n, x, WALK + 2, R, 96, '#ffd0e8'), (x) => newsBox(n, x, WALK + 50, R),
    (x) => hydrant(n, x, WALK + 50), (x) => trashBags(n, x, WALK + 50, R, 3), (x) => g_phonebooth(n, x, WALK + 50, R)];
  for (let x = 74; x < L.near.width - 40; x += 112 + R() * 60) { props[pi % props.length](x); pi++; }
  for (let x = 130; x < L.near.width - 90; x += 250 + R() * 90) parkedCar(n, x, 236, R, '#d8a020');
}

// ---- A2: THE BOARDWALK ----------------------------------------------------
// The strip is out over the water: amusements, a wheel turning behind, the
// black sea beyond the rail and planks underfoot.
function s2a_boardwalk(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#04061c'], [0.46, '#1a1442'], [0.82, '#4a2050'], [1, '#8a3a4a']]);
  stars(f, L, R, r, 90, 70);
  f.fillStyle = '#e8e2c8'; f.beginPath(); f.arc(120, 40, 14, 0, 7); f.fill();
  f.fillStyle = '#1a1442'; f.beginPath(); f.arc(126, 36, 13, 0, 7); f.fill();
  // the sea: a dark band with a moon road running across it
  f.fillStyle = '#0a1028'; f.fillRect(0, 96, L.far.width, 60);
  for (let k = 0; k < L.far.width * 1.1; k++) {
    const yy = 96 + R() * 58;
    f.fillStyle = R() < 0.25 ? 'rgba(180,200,240,0.28)' : 'rgba(40,60,110,0.5)';
    f.fillRect(r(0, L.far.width), yy, 4 + R() * 9, 1);
  }
  for (let k = 0; k < 90; k++) { f.fillStyle = 'rgba(232,226,200,0.24)';
    f.fillRect(120 + r(-16, 16), 98 + r(0, 56), 5 + R() * 8, 1); }
  // mid: the big wheel and a coaster silhouette
  const wx = L.mid.width * 0.3, wy = 78, wr = 56;
  m.strokeStyle = '#2a1e3a'; m.lineWidth = 3;
  m.beginPath(); m.arc(wx, wy, wr, 0, 7); m.stroke();
  m.beginPath(); m.arc(wx, wy, wr - 10, 0, 7); m.stroke();
  for (let k = 0; k < 16; k++) {
    const a = k * Math.PI / 8;
    m.strokeStyle = '#2a1e3a'; m.lineWidth = 2;
    m.beginPath(); m.moveTo(wx, wy); m.lineTo(wx + Math.cos(a) * wr, wy + Math.sin(a) * wr); m.stroke();
    const c = ['#ff4a8a', '#4ae8ff', '#ffe04a'][k % 3];
    m.save(); m.shadowColor = c; m.shadowBlur = 6; m.fillStyle = c;
    m.fillRect(wx + Math.cos(a) * wr - 3, wy + Math.sin(a) * wr - 3, 6, 6); m.restore();
    m.fillStyle = '#1e1630'; m.fillRect(wx + Math.cos(a) * (wr - 10) - 4, wy + Math.sin(a) * (wr - 10), 8, 7);
  }
  m.fillStyle = '#1e1630';
  m.beginPath(); m.moveTo(wx - 22, 150); m.lineTo(wx - 3, wy); m.lineTo(wx + 3, wy); m.lineTo(wx + 22, 150); m.fill();
  let cx2 = L.mid.width * 0.62, cy = 110;
  m.strokeStyle = '#241a34'; m.lineWidth = 3; m.beginPath(); m.moveTo(cx2, cy);
  for (let k = 0; k < 10; k++) { cx2 += 34; cy += (k % 2 ? 1 : -1) * (18 + R() * 16); m.lineTo(cx2, cy); }
  m.stroke();
  for (let x = L.mid.width * 0.62; x < L.mid.width; x += 30) { m.fillStyle = '#1c1428'; m.fillRect(x, 108, 3, 44); }
  // near: the amusements down one side of the boardwalk
  let x = 0;
  const kinds = ['arcade', 'ring', 'food', 'coaster', 'freak'];
  let ki = 0;
  while (x < len - 300) {
    const bw = 110 + R() * 60;
    const top = GROUND - 78 - R() * 16;
    const kind = kinds[ki % kinds.length]; ki++;
    n.fillStyle = '#1c1428'; n.fillRect(x, top, bw, GROUND - top);
    n.fillStyle = '#261a34'; n.fillRect(x, top, bw, 4);
    // striped valance along the front of every stall
    const c = pick2(R, ['#c8303a', '#2a7a5a', '#d8a020', '#3a4a9a', '#8a2a6a']);
    for (let k = 0; k < bw; k += 8) { n.fillStyle = (Math.round(k / 8) % 2) ? c : '#e8e0d0'; n.fillRect(x + k, top + 4, 8, 9); }
    for (let k = 0; k < bw; k += 8) { n.fillStyle = (Math.round(k / 8) % 2) ? c : '#e8e0d0';
      n.beginPath(); n.arc(x + k + 4, top + 14, 4, 0, Math.PI); n.fill(); }
    for (let k = x + 6; k < x + bw - 4; k += 10) { n.fillStyle = (Math.round(k / 10) % 2) ? '#ffe08a' : '#ff8ac8'; n.fillRect(k, top - 4, 3, 3); }
    const inner = top + 20;
    n.fillStyle = '#0c0812'; n.fillRect(x + 5, inner, bw - 10, GROUND - inner - 4);
    if (kind === 'arcade') {
      for (let k = 0; k < Math.floor((bw - 20) / 20); k++) { const cx3 = x + 10 + k * 20;
        n.fillStyle = pick2(R, ['#2a2a4a', '#4a2a3a', '#2a4a3a']); n.fillRect(cx3, GROUND - 48, 15, 44);
        n.fillStyle = pick2(R, ['#4ae8ff', '#ff4a8a', '#e8ff4a']); n.fillRect(cx3 + 2, GROUND - 44, 11, 11); }
      neonText(n, 'PENNY', x + bw / 2 - tw('PENNY') / 2, inner + 4, '#4ae8ff');
    } else if (kind === 'ring') {
      for (let k = 0; k < 12; k++) { n.strokeStyle = pick2(R, ['#e8d040', '#e84a8a', '#4ae8ff']); n.lineWidth = 2;
        n.beginPath(); n.arc(x + 16 + (k % 6) * 17, inner + 16 + Math.floor(k / 6) * 20, 6, 0, 7); n.stroke(); }
      for (let k = 0; k < 5; k++) { n.fillStyle = pick2(R, ['#e8a0b0', '#a0d0e8', '#e8d8a0']);
        n.fillRect(x + 14 + k * 20, GROUND - 26, 11, 20);
        n.beginPath(); n.arc(x + 19.5 + k * 20, GROUND - 28, 5, 0, 7); n.fill(); }
      neonText(n, 'RINGS', x + bw / 2 - tw('RINGS') / 2, inner + 4, '#ffe04a');
    } else if (kind === 'food') {
      n.fillStyle = '#e8c878'; n.fillRect(x + 8, inner + 6, bw - 16, GROUND - inner - 14);
      n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x + 8, GROUND - 24, bw - 16, 20);
      for (let k = 0; k < 3; k++) { n.fillStyle = '#c8302a'; n.fillRect(x + 18 + k * 24, GROUND - 40, 14, 16);
        n.fillStyle = '#e8e0d0'; n.fillRect(x + 20 + k * 24, GROUND - 38, 10, 4); }
      neonText(n, pick2(R, ['HOT DOGS', 'CANDY', 'FUNNEL']), x + 12, inner + 4, '#ff8a2a');
    } else if (kind === 'coaster') {
      n.fillStyle = '#1a2436'; n.fillRect(x + 6, inner, bw - 12, GROUND - inner - 4);
      n.strokeStyle = '#3a5a7a'; n.lineWidth = 2;
      n.beginPath(); n.moveTo(x + 8, GROUND - 14); n.lineTo(x + bw / 2, inner + 8); n.lineTo(x + bw - 8, GROUND - 14); n.stroke();
      neonText(n, 'THE DROP', x + bw / 2 - tw('THE DROP') / 2, inner + 4, '#ff4a4a');
    } else {
      n.fillStyle = pick2(R, ['#3a1a4a', '#1a3a4a']); n.fillRect(x + 6, inner, bw - 12, GROUND - inner - 4);
      for (let k = 0; k < 3; k++) { n.fillStyle = '#e8d8c0'; n.fillRect(x + 14 + k * 30, inner + 12, 22, 34);
        n.fillStyle = '#2a1a2a'; n.fillRect(x + 17 + k * 30, inner + 16, 16, 20); }
      neonText(n, 'ODDITIES', x + bw / 2 - tw('ODDITIES') / 2, inner + 4, '#8a6aff');
    }
    x += bw + 14;
  }
  // the pavilion at the end: the club, out over the water
  const p0 = len - 300;
  n.fillStyle = '#160e24'; n.fillRect(p0, 0, L.near.width - p0, GROUND);
  const pw = L.near.width - p0;
  n.fillStyle = '#241634'; n.fillRect(p0 + 10, 36, pw - 20, GROUND - 36);
  n.fillStyle = '#301c44';
  n.beginPath(); n.moveTo(p0 + 4, 36); n.lineTo(p0 + pw / 2, 6); n.lineTo(p0 + pw - 4, 36); n.fill();
  for (let k = 0; k < 9; k++) { n.fillStyle = (k % 2) ? '#ff2a8a' : '#ffe08a'; n.fillRect(p0 + 16 + k * (pw - 32) / 9, 30, 4, 4); }
  neonText(n, 'PALACE PIER', p0 + pw / 2 - tw('PALACE PIER', 2) / 2, 48, '#4ae8ff', 2);
  n.fillStyle = '#2a0a1a'; n.fillRect(p0 + pw / 2 - 30, GROUND - 56, 60, 56);
  n.fillStyle = 'rgba(255,90,180,0.18)'; n.fillRect(p0 + pw / 2 - 30, GROUND - 56, 60, 56);
  // the deck: planks, a rail over the sea, lamp standards
  n.fillStyle = '#5a4432'; n.fillRect(0, WALK, L.near.width, 240 - WALK);
  for (let px_ = 0; px_ < L.near.width; px_ += 13) {
    n.fillStyle = R() < 0.5 ? '#634b37' : '#513c2c'; n.fillRect(px_, WALK, 12, 240 - WALK);
    n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(px_ + 12, WALK, 1.5, 240 - WALK);
    for (let k = 0; k < 4; k++) { n.fillStyle = 'rgba(0,0,0,0.18)'; n.fillRect(px_ + 2, WALK + 18 + k * 22 + R() * 8, 9, 1); }
    n.fillStyle = '#3a2c20'; n.fillRect(px_ + 2, WALK + 6, 2, 2); n.fillRect(px_ + 9, WALK + 6, 2, 2);
  }
  n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(0, WALK, L.near.width, 4);
  for (let k = 0; k < L.near.width / 30; k++) { n.fillStyle = 'rgba(0,0,0,0.16)';
    n.fillRect(r(0, L.near.width), r(WALK + 10, 236), 14 + R() * 24, 4 + R() * 6); }
  n.fillStyle = '#e8e0d0'; n.fillRect(0, 232, L.near.width, 3);
  for (let x2 = 0; x2 < L.near.width; x2 += 26) { n.fillStyle = '#c8c0b0'; n.fillRect(x2, 235, 3, 5); }
  for (let x2 = 60; x2 < L.near.width; x2 += 190) {
    n.fillStyle = '#e8e0d0'; n.fillRect(x2, WALK - 64, 4, 64);
    n.fillStyle = '#16121c'; n.fillRect(x2 - 4, WALK - 2, 12, 3);
    n.save(); n.shadowColor = '#ffe8b0'; n.shadowBlur = 9; n.fillStyle = '#fff4c8';
    n.beginPath(); n.arc(x2 + 2, WALK - 68, 6, 0, 7); n.fill(); n.restore();
    n.fillStyle = 'rgba(255,244,200,0.08)';
    n.beginPath(); n.moveTo(x2 - 4, WALK - 62); n.lineTo(x2 - 40, 240); n.lineTo(x2 + 46, 240); n.lineTo(x2 + 10, WALK - 62); n.fill();
  }
  for (let k = 0; k < 20; k++) pigeon(n, r(0, L.near.width), r(200, 234), R, '#8a8a94');
}

// ---- A3: THE NEON CANYON --------------------------------------------------
// Signs stacked four deep over a street narrow enough to touch both sides, a
// gate you fight under, and tiled eaves above the shopfronts.
function s2a_canyon(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#08040e'], [0.6, '#2a0a22'], [1, '#5a1230']]);
  stars(f, L, R, r, 30, 40);
  f.fillStyle = '#12081a'; f.fillRect(0, 100, L.far.width, 56);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 54) {
    m.fillStyle = '#1a0c1e'; m.fillRect(x, 0, 50, 150);
    for (let k = 0; k < 6; k++) if (R() < 0.55) {
      const c = pick2(R, ['#ff2a6a', '#2affc8', '#ffd82a', '#6a8aff', '#ff8a2a']);
      m.save(); m.shadowColor = c; m.shadowBlur = 5; m.fillStyle = c;
      if (R() < 0.5) m.fillRect(x + 4 + R() * 30, 12 + k * 23, 16 + R() * 16, 4);
      else m.fillRect(x + 6 + R() * 34, 10 + k * 23, 5, 16);
      m.restore();
    }
  }
  // near: shopfronts under deep tiled eaves, then sign after sign over them
  let x = 0;
  while (x < len - 320) {
    const bw = 96 + R() * 44;
    const wall = pick2(R, ['#3a1c22', '#2e222c', '#402828', '#28242e']);
    n.fillStyle = wall; n.fillRect(x, 0, bw, GROUND);
    for (let k = 0; k < 30; k++) { n.fillStyle = 'rgba(0,0,0,0.10)'; n.fillRect(x + R() * bw, R() * GROUND, 6 + R() * 18, 3 + R() * 8); }
    // tiled eave, the thing that says this is not the same street as stage 1
    for (let ey = 26; ey < 100; ey += 36) {
      n.fillStyle = '#2a1a1e'; n.fillRect(x - 3, ey, bw + 6, 4);
      for (let tx = x - 3; tx < x + bw + 3; tx += 7) {
        n.fillStyle = pick2(R, ['#5a2a28', '#4a2422', '#63302c']);
        n.beginPath(); n.moveTo(tx, ey); n.lineTo(tx + 3.5, ey - 5); n.lineTo(tx + 7, ey); n.fill();
      }
      n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x - 3, ey + 4, bw + 6, 2);
    }
    // the shopfront: warm, open and full of the trade it does
    n.fillStyle = '#16101a'; n.fillRect(x + 3, GROUND - 56, bw - 6, 56);
    n.fillStyle = pick2(R, ['#e8c878', '#d8a850', '#c8d8a0']); n.fillRect(x + 6, GROUND - 50, bw - 12, 44);
    n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x + 6, GROUND - 50, bw - 12, 6);
    const trade = Math.floor(R() * 4);
    if (trade === 0) {                                  // kitchen: hanging meat and a steamer stack
      for (let k = 0; k < 5; k++) { n.fillStyle = '#a8461f'; n.fillRect(x + 12 + k * 13, GROUND - 46, 7, 15);
        n.fillStyle = '#7d3216'; n.fillRect(x + 14 + k * 13, GROUND - 48, 2, 3); }
      n.fillStyle = '#b8bcc4'; for (let k = 0; k < 4; k++) n.fillRect(x + bw - 34, GROUND - 26 - k * 6, 24, 5);
      n.fillStyle = 'rgba(240,240,250,0.18)'; n.fillRect(x + bw - 36, GROUND - 40, 28, 14);
    } else if (trade === 1) {                           // dry goods: crates and sacks out front
      for (let k = 0; k < 4; k++) { n.fillStyle = pick2(R, ['#8a6a40', '#6a4a2a']);
        n.fillRect(x + 10 + k * 16, GROUND - 26, 14, 16);
        n.fillStyle = pick2(R, ['#c8703a', '#8aa83a', '#d8b83a']); n.fillRect(x + 12 + k * 16, GROUND - 29, 10, 4); }
      n.fillStyle = '#7a6a4a'; n.fillRect(x + bw - 30, GROUND - 30, 18, 20);
    } else if (trade === 2) {                           // barber / parlour: chairs and a mirror wall
      n.fillStyle = 'rgba(210,235,245,0.22)'; n.fillRect(x + 10, GROUND - 44, bw - 20, 20);
      for (let k = 0; k < 3; k++) { n.fillStyle = '#2a2a34'; n.fillRect(x + 16 + k * 22, GROUND - 24, 12, 14);
        n.fillStyle = '#5a2a2a'; n.fillRect(x + 16 + k * 22, GROUND - 28, 12, 5); }
    } else {                                            // counter with a queue at it
      n.fillStyle = '#6a4a2a'; n.fillRect(x + 8, GROUND - 24, bw - 16, 5);
      n.fillStyle = '#4a3220'; n.fillRect(x + 8, GROUND - 19, bw - 16, 9);
      for (let k = 0; k < 6; k++) { n.fillStyle = pick2(R, ['#d8d0c0', '#c8b8a0']);
        n.fillRect(x + 12 + k * 12, GROUND - 29, 7, 5); }
    }
    for (let k = 0; k < 4; k++) if (R() < 0.6) {        // somebody inside, cut out against the warm light
      const sx2 = x + 12 + k * (bw - 24) / 4;
      n.fillStyle = 'rgba(0,0,0,0.5)';
      n.fillRect(sx2, GROUND - 32, 6, 26); n.beginPath(); n.arc(sx2 + 3, GROUND - 34, 3.4, 0, 7); n.fill();
    }
    n.fillStyle = 'rgba(255,220,150,0.12)'; n.fillRect(x + 6, GROUND - 50, bw - 12, 44);
    // a noren curtain across the top of the opening, and the doorway beside it
    for (let k = 0; k < bw - 12; k += 9) { n.fillStyle = pick2(R, ['#1e3a5a', '#5a1e2a', '#2a4a36']);
      n.fillRect(x + 6 + k, GROUND - 50, 8, 10); }
    n.fillStyle = '#2a1a1e'; n.fillRect(x + 3, GROUND - 56, bw - 6, 5);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 3, GROUND - 8, bw - 6, 8);
    x += bw;
  }
  // the gate across the street, and the club behind it
  const g0 = len - 320, gw = L.near.width - g0;
  n.fillStyle = '#180a1c'; n.fillRect(g0, 0, gw, GROUND);
  for (let k = 0; k < 40; k++) { n.fillStyle = pick2(R, ['#ff2a6a', '#ffd82a', '#2affc8']);
    n.fillRect(g0 + R() * gw, 20 + R() * 100, 3, 3); }
  n.fillStyle = '#7a1a28'; n.fillRect(g0 + 28, 30, 16, GROUND - 30); n.fillRect(g0 + gw - 44, 30, 16, GROUND - 30);
  n.fillStyle = '#9a2a34'; n.fillRect(g0 + 30, 30, 5, GROUND - 30); n.fillRect(g0 + gw - 42, 30, 5, GROUND - 30);
  n.fillStyle = '#7a1a28'; n.fillRect(g0 + 20, 22, gw - 40, 12);
  for (let tx = g0 + 14; tx < g0 + gw - 14; tx += 8) { n.fillStyle = '#c8a030';
    n.beginPath(); n.moveTo(tx, 22); n.lineTo(tx + 4, 14); n.lineTo(tx + 8, 22); n.fill(); }
  n.fillStyle = '#c8a030'; n.fillRect(g0 + 14, 34, gw - 28, 3);
  neonText(n, 'CLUB VELVET', g0 + gw / 2 - tw('CLUB VELVET', 2) / 2, 42, '#ffd82a', 2);
  n.fillStyle = '#2a0a1a'; n.fillRect(g0 + gw / 2 - 30, GROUND - 58, 60, 58);
  n.fillStyle = 'rgba(255,42,106,0.20)'; n.fillRect(g0 + gw / 2 - 30, GROUND - 58, 60, 58);
  // the ground: tight wet setts, no kerb, no carriageway
  n.fillStyle = '#2f2830'; n.fillRect(0, WALK, L.near.width, 240 - WALK);
  for (let sy = WALK; sy < 240; sy += 9) for (let sx2 = 0; sx2 < L.near.width; sx2 += 12) {
    const t2 = R();
    n.fillStyle = t2 < 0.33 ? '#342d36' : t2 < 0.66 ? '#2d262e' : '#393240';
    n.fillRect(sx2 + ((Math.round(sy / 9)) % 2) * 6, sy, 11, 8);
    if (t2 > 0.94) { n.fillStyle = 'rgba(255,255,255,0.05)'; n.fillRect(sx2 + ((Math.round(sy / 9)) % 2) * 6, sy, 11, 2); }
  }
  n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(0, WALK, L.near.width, 3);
  n.fillStyle = '#20242e'; n.fillRect(L.near.width * 0, 214, L.near.width, 6);      // the drain channel
  for (let k = 0; k < L.near.width; k += 6) { n.fillStyle = '#2e3440'; n.fillRect(k, 215, 3, 4); }
  puddles(n, R, L.near.width, WALK + 10, 236, 40, 'rgba(255,120,180,0.13)');
  puddles(n, R, L.near.width, WALK + 10, 236, 24, 'rgba(90,200,220,0.12)');
  // THE signs: hung right across the street, four deep, overlapping
  for (let x2 = 10; x2 < L.near.width; x2 += 34 + R() * 26) {
    const c = pick2(R, ['#ff2a6a', '#2affc8', '#ffd82a', '#6a8aff', '#ff8a2a', '#ff2aff']);
    const kind = Math.floor(R() * 3);
    n.fillStyle = '#0e0810';
    if (kind === 0) {                                   // vertical blade
      const h = 44 + R() * 34, y0 = 6 + R() * 20;
      n.fillRect(x2, y0, 15, h);
      n.save(); n.shadowColor = c; n.shadowBlur = 8; n.fillStyle = c;
      for (let k = 0; k < Math.floor(h / 11); k++) n.fillRect(x2 + 4, y0 + 5 + k * 11, 7, 7);
      n.restore();
      n.fillStyle = '#2a2430'; n.fillRect(x2 + 4, y0 - 6, 7, 6);
    } else if (kind === 1) {                            // horizontal box
      const w2 = 40 + R() * 40, y0 = 12 + R() * 60;
      n.fillRect(x2, y0, w2, 16);
      n.save(); n.shadowColor = c; n.shadowBlur = 8; n.strokeStyle = c; n.lineWidth = 2;
      n.strokeRect(x2 + 3, y0 + 3, w2 - 6, 10); n.restore();
      neonText(n, pick2(R, ['BAR', 'KTV', 'NOODLE', 'PARLOUR', 'HOTEL']), x2 + 6, y0 + 5, c);
    } else {                                            // a hanging lantern cluster
      const y0 = 14 + R() * 30;
      n.fillStyle = '#2a1a22'; n.fillRect(x2 + 6, 0, 2, y0);
      for (let k = 0; k < 3; k++) {
        n.save(); n.shadowColor = '#ff5a3a'; n.shadowBlur = 8; n.fillStyle = pick2(R, ['#ff5a3a', '#ffb83a']);
        n.beginPath(); n.ellipse(x2 + 7, y0 + 10 + k * 17, 6, 8, 0, 0, 7); n.fill(); n.restore();
        n.fillStyle = '#c89030'; n.fillRect(x2 + 6, y0 + 1 + k * 17, 2, 3);
      }
    }
  }
  // the cables it all hangs from
  n.strokeStyle = 'rgba(30,24,36,0.9)'; n.lineWidth = 1;
  for (let x2 = 0; x2 < L.near.width; x2 += 80) {
    n.beginPath(); n.moveTo(x2, 8 + R() * 8); n.quadraticCurveTo(x2 + 40, 20 + R() * 10, x2 + 80, 8 + R() * 8); n.stroke();
  }
}

// ---- A4: THE CAR PARK -----------------------------------------------------
// The wildcard. The party is four levels up a multi-storey: ranks of parked
// cars, painted level numbers, a rig in one bay and the city through the sides.
function s2a_carpark(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#080614'; f.fillRect(0, 0, L.far.width, H);
  skyGrad(f, L, [[0, '#07051a'], [0.65, '#241640'], [1, '#4a2044']]);
  stars(f, L, R, r, 60, 60);
  skyline(f, L, R, r, 116, '#140e24', '#d8a848', 30, 84);
  // mid: the city seen through the open side of the deck, banded by the edges
  for (let x = 0; x < L.mid.width;) {
    const bw = r(40, 80), bh = r(40, 92);
    m.fillStyle = '#1c1630'; m.fillRect(x, 130 - bh, bw, bh + 20);
    for (let wy = 130 - bh + 6; wy < 126; wy += 9) for (let wx = x + 4; wx < x + bw - 5; wx += 8)
      if (R() < 0.3) { m.fillStyle = '#d8b050'; m.fillRect(wx, wy, 4, 5); }
    x += bw + r(4, 16);
  }
  // near: the deck. A slab above, a slab below, columns, and the open edge.
  concrete(n, 0, 0, L.near.width, 34, '#43424e', R);
  n.fillStyle = '#2e2d38'; n.fillRect(0, 34, L.near.width, 6);
  n.fillStyle = 'rgba(0,0,0,0.45)'; n.fillRect(0, 40, L.near.width, 5);
  // strip lights on the soffit, every bay
  for (let x = 24; x < L.near.width; x += 72) {
    n.fillStyle = '#20202a'; n.fillRect(x, 30, 40, 5);
    n.fillStyle = R() < 0.08 ? '#4a4a58' : '#e8f0ff'; n.fillRect(x + 2, 31, 36, 3);
    n.fillStyle = 'rgba(220,235,255,0.10)'; n.fillRect(x - 10, 35, 60, 60);
  }
  // the parapet wall along the open edge, city visible over it
  n.fillStyle = '#4a4956'; n.fillRect(0, 96, L.near.width, 22);
  n.fillStyle = '#585765'; n.fillRect(0, 96, L.near.width, 3);
  n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(0, 115, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 44) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(x, 96, 2, 22); }
  // columns with painted level numbers
  for (let x = 40; x < L.near.width; x += 190) {
    concrete(n, x, 40, 30, GROUND - 40, '#4e4d5a', R);
    n.fillStyle = '#c83a28'; n.fillRect(x + 2, 60, 26, 26);
    ptext(n, String(3 + Math.floor(x / 190) % 2), x + 11, 68, '#f0e8e0', 2);
    for (let k = 0; k < 16; k += 5) { n.fillStyle = (Math.round(k / 5) % 2) ? '#e8c020' : '#2a2a32'; n.fillRect(x, GROUND - 16 + 0, 30, 5); }
  }
  // ranks of parked cars along the back, nose-in
  for (let x = 8; x < len - 300; x += 62) {
    const c = pick2(R, ['#7a2a30', '#2a4a6a', '#3a3a42', '#6a6a58', '#2a5a4a', '#8a7a30', '#4a2a5a']);
    const y0 = 118;
    n.fillStyle = '#0e0c14'; n.fillRect(x, y0, 56, 24);
    n.fillStyle = c; n.fillRect(x + 1, y0 + 1, 54, 21);
    n.fillStyle = 'rgba(255,255,255,0.12)'; n.fillRect(x + 1, y0 + 1, 54, 2);
    n.fillStyle = '#1e2a3a'; n.fillRect(x + 7, y0 + 4, 42, 8);
    n.fillStyle = 'rgba(160,200,255,0.18)'; n.fillRect(x + 9, y0 + 5, 14, 6);
    n.fillStyle = '#c83030'; n.fillRect(x + 4, y0 + 16, 7, 4); n.fillRect(x + 45, y0 + 16, 7, 4);
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x - 2, y0 + 22, 60, 4);
    n.fillStyle = '#e8e8e0'; n.fillRect(x + 58, y0 - 2, 2, 26);      // bay line
  }
  // the rig: the party lives in three bays with the sound system in them
  const r0 = len - 300, rw = L.near.width - r0;
  n.fillStyle = '#140c1c'; n.fillRect(r0, 40, rw, GROUND - 40);
  for (let k = 0; k < 3; k++) {
    const sx2 = r0 + 24 + k * 90;
    for (let s = 0; s < 3; s++) {
      n.fillStyle = '#0a0a0e'; n.fillRect(sx2, 72 + s * 24, 40, 23);
      n.fillStyle = '#26262e'; n.beginPath(); n.arc(sx2 + 20, 83 + s * 24, 8, 0, 7); n.fill();
      n.fillStyle = '#0e0e12'; n.beginPath(); n.arc(sx2 + 20, 83 + s * 24, 4, 0, 7); n.fill();
    }
  }
  n.fillStyle = '#2a2a34'; n.fillRect(r0 + 10, 44, rw - 20, 5);
  for (let k = 0; k < 7; k++) {
    const lx = r0 + 20 + k * (rw - 40) / 7;
    n.fillStyle = '#16161e'; n.fillRect(lx, 49, 9, 10);
    const c = pick2(R, ['#ff2a6a', '#2ad8ff', '#ffe02a', '#8a2aff']);
    n.save(); n.shadowColor = c; n.shadowBlur = 8; n.fillStyle = c; n.fillRect(lx + 1, 58, 7, 3); n.restore();
    n.fillStyle = `rgba(${c === '#2ad8ff' ? '42,216,255' : '255,42,106'},0.07)`;
    n.beginPath(); n.moveTo(lx + 1, 61); n.lineTo(lx - 30, 240); n.lineTo(lx + 40, 240); n.lineTo(lx + 8, 61); n.fill();
  }
  neonText(n, 'LEVEL 4', r0 + 20, 126, '#ff2a6a', 2);
  // the deck floor: painted bays, tyre marks, oil, a ramp arrow
  n.fillStyle = '#3c3b46'; n.fillRect(0, WALK + 2, L.near.width, 240 - WALK - 2);
  for (let k = 0; k < L.near.width * 1.4; k++) { n.fillStyle = R() < 0.5 ? '#454450' : '#34333e';
    n.fillRect(r(0, L.near.width), r(WALK + 4, 240), 3, 1); }
  n.fillStyle = '#2c2b36'; n.fillRect(0, WALK + 2, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 62) { n.fillStyle = 'rgba(232,232,224,0.55)'; n.fillRect(x, WALK + 6, 3, 44); }
  for (let k = 0; k < L.near.width / 130; k++) { n.fillStyle = 'rgba(0,0,0,0.26)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(200, 234), 14 + R() * 16, 4 + R() * 4, 0, 0, 7); n.fill(); }
  for (let x = 120; x < L.near.width; x += 420) {
    n.fillStyle = 'rgba(232,200,60,0.75)';
    n.fillRect(x, 218, 44, 5);
    n.beginPath(); n.moveTo(x + 44, 210); n.lineTo(x + 62, 220.5); n.lineTo(x + 44, 231); n.fill();
    ptext(n, 'UP', x + 8, 205, 'rgba(232,200,60,0.75)');
  }
}
