// ============================================================ STAGE 6 shared
// The Syndicate works. Every scene carries the falling-beams hazard, so all
// twelve options need something overhead; the Foundry also needs a hole in the
// floor, and Slag is a fire boss, so heat belongs everywhere.

function heatWash(n, L, y0, y1, col = 'rgba(255,140,40,0.10)') {
  const g = n.createLinearGradient(0, y0, 0, y1);
  g.addColorStop(0, col); g.addColorStop(1, 'rgba(255,120,20,0)');
  n.fillStyle = g; n.fillRect(0, y0, L.near.width, y1 - y0);
}
function gantry(n, L, R, y, col = '#39414e', hi = '#4e5a6a') {
  n.fillStyle = col; n.fillRect(0, y, L.near.width, 12);
  n.fillStyle = hi; n.fillRect(0, y, L.near.width, 3);
  n.strokeStyle = col; n.lineWidth = 3;
  for (let x = 0; x < L.near.width; x += 30) {
    n.beginPath(); n.moveTo(x, y + 12); n.lineTo(x + 15, y + 26); n.lineTo(x + 30, y + 12); n.stroke();
  }
  n.fillStyle = col; n.fillRect(0, y + 26, L.near.width, 7);
  n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(0, y + 33, L.near.width, 4);
  for (let x = 6; x < L.near.width; x += 14) { n.fillStyle = hi; n.fillRect(x, y + 4, 2, 2); }
}
function pipeRun(n, L, R, ys, cool) {
  for (const py of ys) {
    n.fillStyle = cool ? '#39414e' : '#4a3028'; n.fillRect(0, py, L.near.width, 9);
    n.fillStyle = cool ? '#4e5a6a' : '#5e3c30'; n.fillRect(0, py, L.near.width, 2);
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(0, py + 7, L.near.width, 2);
    for (let x = 0; x < L.near.width; x += 130) { n.fillStyle = '#20242c'; n.fillRect(x, py - 2, 8, 13); }
    for (let x = 60; x < L.near.width; x += 260) {                       // a valve wheel on the run
      n.fillStyle = '#2a2e36'; n.fillRect(x, py - 8, 5, 8);
      n.strokeStyle = '#5a6270'; n.lineWidth = 2;
      n.beginPath(); n.arc(x + 2.5, py - 11, 6, 0, 7); n.stroke();
    }
  }
}
function plateFloor(n, L, R, r, top, a, b, c, diamond) {
  n.fillStyle = a; n.fillRect(0, top, L.near.width, 240 - top);
  for (let k = 0; k < L.near.width * 1.3; k++) { n.fillStyle = R() < 0.5 ? b : c;
    n.fillRect(r(0, L.near.width), r(top + 2, 240), 3, 1); }
  for (let x = 0; x < L.near.width; x += 46) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x, top, 2, 240 - top); }
  for (let y = top + 22; y < 240; y += 24) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(0, y, L.near.width, 2); }
  if (diamond) for (let y = top + 6; y < 240; y += 10) for (let x = (Math.round(y / 10) % 2) * 6; x < L.near.width; x += 12) {
    n.fillStyle = 'rgba(255,255,255,0.045)'; n.fillRect(x, y, 5, 3);
  }
  n.fillStyle = c; n.fillRect(0, top, L.near.width, 3);
}
// (the yard-ballast helper, needed by the torpedo option)
function ballast(n, L, R, r, base, a, b, c) {
  n.fillStyle = a; n.fillRect(0, base, L.near.width, 240 - base);
  for (let k = 0; k < L.near.width * 2.2; k++) { n.fillStyle = R() < 0.5 ? b : c;
    n.fillRect(r(0, L.near.width), r(base + 2, 240), 2, 2); }
  n.fillStyle = c; n.fillRect(0, base, L.near.width, 3);
}
function grating(n, L, top, h, a = '#2a3038', b = '#3e4650') {
  n.fillStyle = a; n.fillRect(0, top, L.near.width, h);
  for (let x = 0; x < L.near.width; x += 7) { n.fillStyle = b; n.fillRect(x, top, 4, h);
    n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(x + 4, top, 3, h); }
  for (let y = top; y < top + h; y += 16) { n.fillStyle = '#4e5a6a'; n.fillRect(0, y, L.near.width, 2); }
}
function moltenRun(n, L, R, r, x0, x1, y, h) {
  n.fillStyle = '#1a0e0a'; n.fillRect(x0, y - 3, x1 - x0, h + 6);
  const g = n.createLinearGradient(0, y, 0, y + h);
  g.addColorStop(0, '#fff0a0'); g.addColorStop(0.35, '#ffb020'); g.addColorStop(0.75, '#e0500c'); g.addColorStop(1, '#a01e04');
  n.fillStyle = g; n.fillRect(x0, y, x1 - x0, h);
  for (let k = 0; k < (x1 - x0) / 6; k++) { n.fillStyle = 'rgba(0,0,0,0.20)';
    n.fillRect(r(x0, x1), y + r(0, h), 4 + R() * 10, 2); }
  for (let k = 0; k < (x1 - x0) / 14; k++) { n.fillStyle = 'rgba(255,255,220,0.55)';
    n.fillRect(r(x0, x1), y + r(1, h - 2), 3 + R() * 7, 1); }
  n.fillStyle = 'rgba(255,150,40,0.16)'; n.fillRect(x0 - 16, y - 40, x1 - x0 + 32, h + 46);
}

// ============================================================ 6-A: THE FOUNDRY
// ---- A1: THE CAST HOUSE ---------------------------------------------------
function s6a_casthouse(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#1a0c08'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 130) {
    const g = f.createLinearGradient(0, 0, 0, 150);
    g.addColorStop(0, '#2a1008'); g.addColorStop(0.7, '#6a2008'); g.addColorStop(1, '#e06a10');
    f.fillStyle = g; f.fillRect(x, 30, 108, 120);
    f.fillStyle = '#140804'; f.fillRect(x + 108, 0, 22, 150);
  }
  // mid: the furnace stack itself, with its gas offtakes and stove line
  m.fillStyle = '#2a1a16'; m.fillRect(L.mid.width * 0.34, 0, 150, 150);
  m.fillStyle = '#3a241e'; m.fillRect(L.mid.width * 0.34 + 8, 0, 26, 150);
  for (let k = 0; k < 5; k++) { m.fillStyle = '#1e1310'; m.fillRect(L.mid.width * 0.34, 20 + k * 30, 150, 7); }
  for (let x = 0; x < L.mid.width; x += 260) {
    m.fillStyle = '#241713'; m.fillRect(x, 26, 44, 124);
    m.fillStyle = '#31201a'; m.fillRect(x + 4, 26, 12, 124);
    m.beginPath(); m.moveTo(x - 4, 26); m.lineTo(x + 22, 8); m.lineTo(x + 48, 26); m.fill();
  }
  for (let y = 0; y < 48; y += 16) { m.fillStyle = '#2a1e1a'; m.fillRect(0, y, L.mid.width, 6);
    m.fillStyle = '#3c2a24'; m.fillRect(0, y, L.mid.width, 1); }
  // near: the cast house. Gantry over, pipes, the tap hole and the runner.
  gantry(n, L, R, 40, '#3a2620', '#54372c');
  pipeRun(n, L, R, [80, 98], false);
  for (let x = 0; x < L.near.width; x += 176) {
    n.fillStyle = '#2e1c14'; n.fillRect(x, 0, 42, 150);
    n.fillStyle = '#40261c'; n.fillRect(x + 3, 0, 11, 150);
    n.fillStyle = 'rgba(0,0,0,0.38)'; n.fillRect(x + 38, 0, 5, 150);
    n.fillStyle = '#ff8a10'; n.fillRect(x + 12, 118, 18, 5);
    n.fillStyle = 'rgba(255,138,16,0.14)';
    n.beginPath(); n.moveTo(x + 12, 123); n.lineTo(x - 20, 240); n.lineTo(x + 62, 240); n.lineTo(x + 30, 123); n.fill();
  }
  // the tap hole, with iron running out of it down a sand runner
  const t0 = 240;
  n.fillStyle = '#2a1410'; n.fillRect(t0 - 40, 96, 120, 54);
  n.fillStyle = '#3a1c16'; n.fillRect(t0 - 34, 100, 108, 46);
  n.fillStyle = '#0e0604'; n.beginPath(); n.arc(t0 + 20, 126, 15, 0, 7); n.fill();
  n.save(); n.shadowColor = '#ffd060'; n.shadowBlur = 16;
  n.fillStyle = '#fff0a0'; n.beginPath(); n.arc(t0 + 20, 126, 9, 0, 7); n.fill(); n.restore();
  moltenRun(n, L, R, r, 0, len - 300, 158, 13);
  // ladle cars on their rails behind the runner
  for (let x = 120; x < len - 320; x += 300) {
    n.fillStyle = '#1a1014'; n.fillRect(x, 106, 108, 40);
    n.fillStyle = '#3a2a2a'; n.fillRect(x + 4, 108, 100, 36);
    n.fillStyle = '#4a3636'; n.fillRect(x + 4, 108, 100, 4);
    n.fillStyle = '#ffb020'; n.fillRect(x + 14, 102, 80, 6);
    n.fillStyle = 'rgba(255,176,32,0.16)'; n.fillRect(x - 4, 92, 118, 24);
    n.fillStyle = '#16121a'; n.beginPath(); n.arc(x + 22, 146, 7, 0, 7); n.arc(x + 86, 146, 7, 0, 7); n.fill();
  }
  // the pouring bay at the end: the arena
  const a0 = len - 300;
  n.fillStyle = '#1e0f0b'; n.fillRect(a0, 0, L.near.width - a0, 150);
  n.fillStyle = '#2e1a14'; n.fillRect(a0 + 20, 30, L.near.width - a0 - 40, 116);
  for (let k = 0; k < 40; k++) { n.fillStyle = 'rgba(255,150,40,0.10)';
    n.fillRect(r(a0, L.near.width), r(40, 140), 10 + R() * 22, 5); }
  n.fillStyle = '#2a2028'; n.fillRect(a0 + 60, 18, 120, 56);
  n.fillStyle = '#3a2c30'; n.fillRect(a0 + 60, 18, 120, 5);
  n.fillStyle = '#ffb020'; n.fillRect(a0 + 74, 72, 92, 7);
  n.fillStyle = 'rgba(255,176,32,0.20)'; n.fillRect(a0 + 50, 78, 140, 62);
  plateFloor(n, L, R, r, 176, '#3a2a22', '#463229', '#241810', false);
  for (let k = 0; k < 26; k++) { n.fillStyle = 'rgba(255,140,30,0.16)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(188, 234), 10 + R() * 20, 3 + R() * 4, 0, 0, 7); n.fill(); }
  heatWash(n, L, 150, 240, 'rgba(255,140,40,0.13)');
  L.heat = 1;
}

// ---- A2: THE ROLLING MILL -------------------------------------------------
function s6a_mill(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#140e10'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 90) { f.fillStyle = '#1c1418'; f.fillRect(x, 24, 78, 126);
    f.fillStyle = '#251b20'; f.fillRect(x + 6, 32, 30, 40); }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let y = 0; y < 60; y += 18) { m.fillStyle = '#22191e'; m.fillRect(0, y, L.mid.width, 7);
    m.fillStyle = '#31252b'; m.fillRect(0, y, L.mid.width, 2); }
  for (let x = 0; x < L.mid.width; x += 190) { m.fillStyle = '#1e1519'; m.fillRect(x, 58, 22, 92); }
  gantry(n, L, R, 30, '#2f3640', '#454f5c');
  pipeRun(n, L, R, [76], true);
  // the roller table: the slab runs the whole length, glowing
  const TABLE = 128;
  n.fillStyle = '#20252c'; n.fillRect(0, TABLE, L.near.width, 26);
  for (let x = 0; x < L.near.width; x += 15) {
    n.fillStyle = '#39414e'; n.beginPath(); n.ellipse(x + 7, TABLE + 13, 7, 12, 0, 0, 7); n.fill();
    n.fillStyle = '#4e5a6a'; n.beginPath(); n.ellipse(x + 7, TABLE + 9, 6, 8, 0, 0, 7); n.fill();
  }
  moltenRun(n, L, R, r, 0, len - 300, TABLE + 4, 14);
  n.fillStyle = 'rgba(255,170,60,0.22)'; n.fillRect(0, TABLE - 40, L.near.width, 46);
  // the mill stands, straddling the table every so often
  for (let x = 140; x < len - 320; x += 340) {
    n.fillStyle = '#242b34'; n.fillRect(x, 54, 34, 110); n.fillRect(x + 96, 54, 34, 110);
    n.fillStyle = '#323b47'; n.fillRect(x + 4, 54, 10, 110); n.fillRect(x + 100, 54, 10, 110);
    n.fillStyle = '#1c2229'; n.fillRect(x, 54, 130, 22);
    n.fillStyle = '#2e3742'; n.fillRect(x, 54, 130, 4);
    n.fillStyle = '#4e5a6a'; n.fillRect(x + 30, 100, 70, 12);            // the work rolls
    n.fillStyle = '#5e6c7e'; n.fillRect(x + 30, 100, 70, 3);
    n.fillStyle = '#4e5a6a'; n.fillRect(x + 30, 146, 70, 12);
    n.fillStyle = '#e8c020'; n.fillRect(x + 36, 80, 58, 8);
    ptext(n, 'F' + (2 + Math.floor(x / 340)), x + 56, 81, '#1a1a1e', 1);
    // water sprays hissing onto the slab
    for (let k = 0; k < 8; k++) { n.fillStyle = 'rgba(200,230,255,0.30)';
      n.fillRect(x + 32 + k * 9, 114, 2, 16); }
    n.fillStyle = 'rgba(230,240,255,0.16)'; n.fillRect(x + 24, 112, 84, 26);
  }
  for (let k = 0; k < L.near.width / 24; k++) {                         // scale flying off
    n.fillStyle = pick2(R, ['#ffb020', '#ff7a10', '#e8e0d0']);
    n.fillRect(r(0, L.near.width), r(TABLE - 20, TABLE + 30), 2, 2);
  }
  // the coil box at the end
  const a0 = len - 300;
  n.fillStyle = '#191f26'; n.fillRect(a0, 30, L.near.width - a0, 130);
  n.fillStyle = '#242c36'; n.fillRect(a0 + 16, 46, L.near.width - a0 - 32, 110);
  for (let k = 0; k < 3; k++) {
    const cx = a0 + 70 + k * 96;
    n.fillStyle = '#5a4a3a'; n.beginPath(); n.ellipse(cx, 104, 34, 34, 0, 0, 7); n.fill();
    for (let s = 0; s < 8; s++) { n.strokeStyle = s % 2 ? '#6a5a46' : '#4e4034'; n.lineWidth = 2;
      n.beginPath(); n.arc(cx, 104, 6 + s * 3.6, 0, 7); n.stroke(); }
    n.fillStyle = '#2a2228'; n.beginPath(); n.arc(cx, 104, 7, 0, 7); n.fill();
  }
  plateFloor(n, L, R, r, 170, '#2f343d', '#39404a', '#22262d', true);
  heatWash(n, L, 150, 240, 'rgba(255,150,50,0.10)');
  L.heat = 1;
}

// ---- A3: THE ARC FURNACE --------------------------------------------------
function s6a_arc(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0c0e14'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 110) { f.fillStyle = '#141820'; f.fillRect(x, 20, 96, 130);
    f.fillStyle = 'rgba(150,200,255,0.05)'; f.fillRect(x + 10, 34, 40, 50); }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 170) {                          // the fume ducting
    m.fillStyle = '#1b222c'; m.fillRect(x, 16, 150, 20);
    m.fillStyle = '#28323f'; m.fillRect(x, 16, 150, 3);
    m.fillStyle = '#1b222c'; m.fillRect(x + 60, 36, 26, 114);
  }
  gantry(n, L, R, 26, '#2a323c', '#3e4a58');
  // the charging crane with a scrap bucket on it
  for (let x = 200; x < L.near.width; x += 560) {
    n.fillStyle = '#39414e'; n.fillRect(x, 60, 52, 16);
    n.fillStyle = '#4e5a6a'; n.fillRect(x + 2, 62, 48, 4);
    n.fillStyle = '#2a2e36'; n.fillRect(x + 12, 76, 3, 24); n.fillRect(x + 38, 76, 3, 24);
    n.fillStyle = '#4a3a2e'; n.fillRect(x + 2, 100, 48, 34);
    n.fillStyle = '#5c493a'; n.fillRect(x + 2, 100, 48, 3);
    for (let k = 0; k < 16; k++) { n.fillStyle = pick2(R, ['#6a6a72', '#8a5a3a', '#4a4a56']);
      n.save(); n.translate(x + 8 + R() * 36, 96 + R() * 8); n.rotate(R() * 3);
      n.fillRect(0, 0, 8 + R() * 8, 3); n.restore(); }
  }
  // the furnace shell, with the electrodes down through the roof and arc light
  const F0 = 380;
  n.fillStyle = '#20262e'; n.fillRect(F0, 56, 220, 96);
  n.fillStyle = '#2c3540'; n.fillRect(F0, 56, 220, 6);
  for (let k = 0; k < 220; k += 26) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(F0 + k, 62, 3, 90); }
  for (let k = 0; k < 3; k++) {
    const ex = F0 + 60 + k * 50;
    n.fillStyle = '#39414e'; n.fillRect(ex, 0, 13, 56);
    n.fillStyle = '#4e5a6a'; n.fillRect(ex + 1, 0, 4, 56);
    n.fillStyle = '#2a2e36'; n.fillRect(ex - 4, 30, 21, 8);
  }
  n.save(); n.shadowColor = '#cfe8ff'; n.shadowBlur = 22;
  n.fillStyle = '#eaf6ff'; n.fillRect(F0 + 56, 50, 106, 10); n.restore();
  n.fillStyle = 'rgba(190,225,255,0.18)'; n.fillRect(F0 - 40, 40, 300, 112);
  for (let k = 0; k < 40; k++) { n.fillStyle = '#ffd88a'; n.fillRect(F0 + 40 + R() * 140, 46 + R() * 60, 2, 2); }
  // the slag pot on the tapping side
  n.fillStyle = '#2a2228'; n.fillRect(F0 + 250, 104, 74, 46);
  n.fillStyle = '#3a2e34'; n.fillRect(F0 + 250, 104, 74, 4);
  moltenRun(n, L, R, r, F0 + 256, F0 + 318, 100, 8);
  for (let x = 0; x < L.near.width; x += 200) {                         // the water-cooled panels behind
    n.fillStyle = '#1b222c'; n.fillRect(x, 90, 40, 62);
    for (let k = 0; k < 62; k += 8) { n.fillStyle = '#28323f'; n.fillRect(x + 2, 90 + k, 36, 4); }
  }
  plateFloor(n, L, R, r, 168, '#2a2f37', '#333943', '#1f2329', true);
  for (let k = 0; k < L.near.width / 60; k++) { n.fillStyle = 'rgba(190,225,255,0.07)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(180, 232), 14 + R() * 18, 4 + R() * 4, 0, 0, 7); n.fill(); }
  heatWash(n, L, 150, 240, 'rgba(160,210,255,0.07)');
  L.arc = 1;
}

// ---- A4: THE COKE OVENS ---------------------------------------------------
function s6a_coke(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#16100c'; f.fillRect(0, 0, L.far.width, H);
  f.fillStyle = 'rgba(200,170,120,0.14)'; f.fillRect(0, 40, L.far.width, 110);
  for (let x = 0; x < L.far.width; x += 60) { f.fillStyle = '#1e1610'; f.fillRect(x, 60, 48, 90);
    if (R() < 0.5) { f.fillStyle = '#c8a040'; f.fillRect(x + 10 + R() * 26, 70 + R() * 60, 3, 3); } }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 40) {                           // the oven tops, flaming
    m.fillStyle = '#241a12'; m.fillRect(x, 60, 36, 90);
    m.fillStyle = '#2f231a'; m.fillRect(x, 60, 36, 4);
    if (R() < 0.5) { m.save(); m.shadowColor = '#d8e060'; m.shadowBlur = 8;
      m.fillStyle = '#e8f070'; m.fillRect(x + 14, 50, 6, 12); m.restore(); }
  }
  // near: the battery. Oven door after oven door, each one different.
  n.fillStyle = '#1e1610'; n.fillRect(0, 0, L.near.width, 150);
  n.fillStyle = '#2a1e16'; n.fillRect(0, 26, L.near.width, 12);
  gantry(n, L, R, 0, '#2a1e16', '#3c2c20');
  let x = 0, oi = 0;
  while (x < len - 300) {
    const ow = 62;
    n.fillStyle = '#332419'; n.fillRect(x, 44, ow - 4, 106);
    n.fillStyle = '#42301f'; n.fillRect(x + 2, 44, 6, 106);
    n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(x + ow - 10, 44, 6, 106);
    n.fillStyle = '#20160f'; n.fillRect(x + 10, 56, ow - 26, 88);      // the door
    for (let k = 0; k < 88; k += 11) { n.fillStyle = '#2b1e14'; n.fillRect(x + 10, 56 + k, ow - 26, 4); }
    n.fillStyle = '#4a3420'; n.fillRect(x + 12, 92, ow - 30, 7);
    n.fillStyle = '#5c4229'; n.fillRect(x + 12, 92, ow - 30, 2);
    ptext(n, String(oi + 11), x + 20, 66, '#8a6a44', 1);
    if (oi % 4 === 1) {                                                 // one door leaking fire
      n.save(); n.shadowColor = '#ffb020'; n.shadowBlur = 12;
      n.fillStyle = '#ffd060'; n.fillRect(x + 10, 130, ow - 26, 6); n.restore();
      n.fillStyle = 'rgba(255,176,32,0.16)'; n.fillRect(x - 6, 120, ow + 8, 30);
      for (let k = 0; k < 8; k++) { n.fillStyle = pick2(R, ['#ffd060', '#ff8a10']);
        n.fillRect(x + 14 + R() * (ow - 34), 118 + R() * 14, 3, 4); }
    }
    x += ow; oi++;
  }
  // the pusher machine on its rails, and the quench car at the end
  const p0 = 300;
  n.fillStyle = '#1a1e24'; n.fillRect(p0, 62, 150, 88);
  n.fillStyle = '#2f3640'; n.fillRect(p0 + 4, 66, 142, 80);
  n.fillStyle = '#3e4854'; n.fillRect(p0 + 4, 66, 142, 4);
  n.fillStyle = '#e8c020'; n.fillRect(p0 + 10, 82, 40, 10);
  ptext(n, 'PUSH', p0 + 14, 83, '#1a1a1e', 1);
  n.fillStyle = '#1e242c'; n.fillRect(p0 + 60, 92, 84, 22);
  n.fillStyle = '#39414e'; n.fillRect(p0 + 146, 100, 60, 8);
  n.fillStyle = '#16181f'; n.beginPath(); n.arc(p0 + 26, 150, 9, 0, 7); n.arc(p0 + 124, 150, 9, 0, 7); n.fill();
  const a0 = len - 300;
  n.fillStyle = '#140e0a'; n.fillRect(a0, 0, L.near.width - a0, 150);
  n.fillStyle = '#2a2028'; n.fillRect(a0 + 30, 78, L.near.width - a0 - 60, 72);
  moltenRun(n, L, R, r, a0 + 36, L.near.width - 36, 70, 12);
  n.fillStyle = 'rgba(230,240,255,0.16)'; n.fillRect(a0 + 10, 40, L.near.width - a0 - 20, 110);
  plateFloor(n, L, R, r, 172, '#241b14', '#2e231a', '#18110c', false);
  for (let k = 0; k < L.near.width / 3; k++) { n.fillStyle = R() < 0.5 ? '#141010' : '#221a16';   // coal dust
    n.fillRect(r(0, L.near.width), r(176, 238), 3, 2); }
  heatWash(n, L, 150, 240, 'rgba(255,170,60,0.08)');
  L.coalDust = 1;
}

// ============================================================ 6-B: ASSEMBLY LINE
// ---- B1: THE LINE ---------------------------------------------------------
function s6b_line(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0c0e16'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 120) {
    const g = f.createLinearGradient(0, 0, 0, 150);
    g.addColorStop(0, '#12161f'); g.addColorStop(1, '#1c2430');
    f.fillStyle = g; f.fillRect(x, 40, 100, 110);
    f.fillStyle = '#080a10'; f.fillRect(x + 100, 0, 20, 150);
  }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 150) {                    // the next line over
    m.fillStyle = '#141b26'; m.fillRect(x, 84, 140, 14);
    m.fillStyle = '#1e2836'; m.fillRect(x, 84, 140, 3);
    for (let k = 0; k < 6; k++) { m.fillStyle = '#26303e'; m.fillRect(x + 10 + k * 22, 70, 14, 14); }
  }
  gantry(n, L, R, 20, '#2a323c', '#3e4a58');
  pipeRun(n, L, R, [62], true);
  for (let x = 0; x < L.near.width; x += 178) {
    n.fillStyle = '#1c2230'; n.fillRect(x, 0, 40, 150);
    n.fillStyle = '#2a3546'; n.fillRect(x + 3, 0, 10, 150);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 36, 0, 5, 150);
    n.fillStyle = '#2ad0f0'; n.fillRect(x + 12, 96, 16, 4);
    n.fillStyle = 'rgba(42,208,240,0.10)';
    n.beginPath(); n.moveTo(x + 12, 100); n.lineTo(x - 18, 240); n.lineTo(x + 58, 240); n.lineTo(x + 28, 100); n.fill();
  }
  // the conveyor, carrying half-built units, and the arms working on them
  const CONV = 104;
  n.fillStyle = '#2e3a4a'; n.fillRect(0, CONV, L.near.width, 14);
  n.fillStyle = '#48586c'; n.fillRect(0, CONV, L.near.width, 2);
  for (let k = 0; k < L.near.width; k += 10) { n.fillStyle = '#1a222c'; n.fillRect(k, CONV + 2, 4, 10); }
  n.fillStyle = '#1a222c'; n.fillRect(0, CONV + 14, L.near.width, 5);
  for (let x = 20; x < L.near.width; x += 84) {                   // the units on it
    n.fillStyle = '#39414e'; n.fillRect(x, CONV - 26, 34, 26);
    n.fillStyle = '#4e5a6a'; n.fillRect(x + 2, CONV - 24, 30, 5);
    n.fillStyle = '#1c2029'; n.fillRect(x + 6, CONV - 18, 22, 10);
    const lit = R() < 0.5;
    n.fillStyle = lit ? '#e8283a' : '#2a3038'; n.fillRect(x + 9, CONV - 15, 5, 4);
    n.fillStyle = lit ? '#e8283a' : '#2a3038'; n.fillRect(x + 20, CONV - 15, 5, 4);
    n.fillStyle = '#2a3038'; n.fillRect(x + 4, CONV - 6, 8, 6); n.fillRect(x + 22, CONV - 6, 8, 6);
  }
  for (let x = 60; x < len - 320; x += 150) {                     // ceiling arms reaching down
    n.fillStyle = '#2a3442'; n.fillRect(x, 30, 12, 32);
    n.fillStyle = '#3e4c5e'; n.fillRect(x - 5, 58, 22, 12);
    n.save(); n.translate(x + 6, 68); n.rotate(0.5 + (x % 5) * 0.16);
    n.fillStyle = '#4a5a6e'; n.fillRect(-4, 0, 8, 34);
    n.fillStyle = '#5e7186'; n.fillRect(-4, 0, 3, 34);
    n.fillStyle = '#2a3442'; n.fillRect(-6, 30, 12, 8);
    n.save(); n.shadowColor = '#8ef0ff'; n.shadowBlur = 10;
    n.fillStyle = '#d8f8ff'; n.fillRect(-2, 38, 4, 5); n.restore();
    n.restore();
    for (let k = 0; k < 6; k++) { n.fillStyle = pick2(R, ['#ffd060', '#8ef0ff', '#ffffff']);
      n.fillRect(x + (R() - 0.5) * 26, 96 + R() * 18, 2, 2); }
  }
  for (let x = 40; x < L.near.width; x += 300) {                  // andon light and a parts bin
    n.fillStyle = '#1a222c'; n.fillRect(x, 40, 12, 34);
    for (let k = 0; k < 3; k++) { n.fillStyle = k === 1 ? '#e8c020' : (k === 0 ? '#3a1a1a' : '#1a3a1a');
      n.beginPath(); n.arc(x + 6, 48 + k * 10, 4, 0, 7); n.fill(); }
    n.fillStyle = '#3a4250'; n.fillRect(x + 30, 122, 54, 28);
    n.fillStyle = '#4c5666'; n.fillRect(x + 30, 122, 54, 3);
    for (let k = 0; k < 5; k++) { n.fillStyle = pick2(R, ['#6a7484', '#8a5a3a', '#4a5a6a']);
      n.fillRect(x + 34 + k * 10, 116 + R() * 6, 7, 7); }
  }
  const a0 = len - 320;
  n.fillStyle = '#141a24'; n.fillRect(a0, 0, L.near.width - a0, 150);
  n.fillStyle = '#1e2836'; n.fillRect(a0 + 20, 40, L.near.width - a0 - 40, 110);
  for (let k = 0; k < 4; k++) { n.fillStyle = '#26303e'; n.fillRect(a0 + 40 + k * 70, 60, 50, 86);
    n.fillStyle = '#2ad0f0'; n.fillRect(a0 + 46 + k * 70, 66, 38, 4);
    n.fillStyle = 'rgba(42,208,240,0.09)'; n.fillRect(a0 + 40 + k * 70, 70, 50, 76); }
  neonText(n, 'FINAL ASSEMBLY', a0 + 46, 24, '#2ad0f0', 2);
  plateFloor(n, L, R, r, 166, '#2a3140', '#333c4c', '#1c222c', true);
  for (let x = 0; x < L.near.width; x += 120) { n.fillStyle = 'rgba(232,200,60,0.40)'; n.fillRect(x, 224, 60, 3); }
}

// ---- B2: THE BODY SHOP ----------------------------------------------------
function s6b_bodyshop(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0d1018'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 74) { f.fillStyle = '#141a24'; f.fillRect(x, 28, 62, 122);
    if (R() < 0.4) { f.fillStyle = 'rgba(180,230,255,0.06)'; f.fillRect(x + 8, 40, 40, 44); } }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 90) { m.fillStyle = '#161d28'; m.fillRect(x, 96, 80, 54);
    m.fillStyle = '#212b38'; m.fillRect(x, 96, 80, 3); }
  // the overhead monorail: shells hanging over the fight
  n.fillStyle = '#20262e'; n.fillRect(0, 26, L.near.width, 10);
  n.fillStyle = '#39414e'; n.fillRect(0, 26, L.near.width, 3);
  n.fillStyle = '#12161c'; n.fillRect(0, 36, L.near.width, 5);
  for (let x = 0; x < L.near.width; x += 120) {
    n.fillStyle = '#20262e'; n.fillRect(x, 0, 10, 26);
    n.strokeStyle = '#20262e'; n.lineWidth = 3;
    n.beginPath(); n.moveTo(x + 5, 8); n.lineTo(x + 58, 20); n.stroke();
  }
  for (let x = 30; x < L.near.width; x += 160) {                  // the carriers and their shells
    n.fillStyle = '#2f3843'; n.fillRect(x, 40, 26, 12);
    n.fillStyle = '#4a5462'; n.fillRect(x + 2, 42, 22, 4);
    n.fillStyle = '#2a2e36'; n.fillRect(x + 6, 52, 3, 18); n.fillRect(x + 17, 52, 3, 18);
    const c = pick2(R, ['#5a2a30', '#2a4a6a', '#3a4a3a', '#6a6a58', '#4a3a5a']);
    n.fillStyle = '#12161c'; n.fillRect(x - 24, 70, 74, 34);
    n.fillStyle = c; n.fillRect(x - 22, 72, 70, 30);
    n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(x - 22, 72, 70, 3);
    n.fillStyle = '#0e1116'; n.fillRect(x - 14, 76, 22, 14); n.fillRect(x + 14, 76, 22, 14);
    n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(x - 22, 96, 70, 6);
  }
  // the welding robots either side of the line, throwing sparks
  for (let x = 70; x < len - 320; x += 130) {
    const base = 150;
    n.fillStyle = '#e8a020'; n.fillRect(x, base - 42, 22, 42);
    n.fillStyle = '#f0b840'; n.fillRect(x + 2, base - 42, 6, 42);
    n.fillStyle = '#2a2e36'; n.fillRect(x - 3, base - 46, 28, 6);
    n.save(); n.translate(x + 11, base - 44); n.rotate(-0.7 + (x % 4) * 0.2);
    n.fillStyle = '#e8a020'; n.fillRect(-5, -38, 10, 38);
    n.fillStyle = '#b87a10'; n.fillRect(2, -38, 3, 38);
    n.fillStyle = '#2a2e36'; n.fillRect(-6, -46, 12, 10);
    n.restore();
    if (R() < 0.7) {
      n.save(); n.shadowColor = '#cfe8ff'; n.shadowBlur = 14; n.fillStyle = '#eaf6ff';
      n.fillRect(x + 4, base - 96, 5, 5); n.restore();
      n.fillStyle = 'rgba(190,225,255,0.14)'; n.beginPath(); n.arc(x + 6, base - 94, 28, 0, 7); n.fill();
      for (let k = 0; k < 12; k++) { n.fillStyle = pick2(R, ['#ffd88a', '#fff2c0', '#ff9a30']);
        n.fillRect(x + 6 + (R() - 0.5) * 40, base - 94 + R() * 44, 2, 2); }
    }
  }
  for (let x = 20; x < L.near.width; x += 200) {                  // the jigs standing on the floor
    n.fillStyle = '#39414e'; n.fillRect(x, 118, 64, 6);
    n.fillStyle = '#2a2e36'; n.fillRect(x + 6, 124, 5, 26); n.fillRect(x + 52, 124, 5, 26);
    n.fillStyle = '#e8c020'; n.fillRect(x, 114, 64, 4);
  }
  const a0 = len - 320;
  n.fillStyle = '#121820'; n.fillRect(a0, 0, L.near.width - a0, 150);
  for (let k = 0; k < 3; k++) { n.fillStyle = '#1c2430'; n.fillRect(a0 + 30 + k * 96, 52, 76, 98);
    n.fillStyle = '#2ad0f0'; n.fillRect(a0 + 36 + k * 96, 58, 64, 4);
    n.fillStyle = 'rgba(42,208,240,0.08)'; n.fillRect(a0 + 30 + k * 96, 62, 76, 88); }
  neonText(n, 'BODY SHOP 2', a0 + 50, 24, '#2ad0f0', 2);
  plateFloor(n, L, R, r, 158, '#2c333f', '#353e4b', '#1e242c', true);
  for (let x = 0; x < L.near.width; x += 16) { n.fillStyle = (Math.round(x / 16) % 2) ? '#e8c020' : '#1e242c';
    n.fillRect(x, 164, 16, 3); }
  for (let k = 0; k < L.near.width / 40; k++) { n.fillStyle = 'rgba(190,225,255,0.05)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(180, 232), 16 + R() * 16, 4, 0, 0, 7); n.fill(); }
}

// ---- B3: THE PACKING HALL -------------------------------------------------
function s6b_packing(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#161a20'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 84) { f.fillStyle = '#1d222a'; f.fillRect(x, 24, 72, 126);
    f.fillStyle = '#252c36'; f.fillRect(x, 24, 72, 4); }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 130) {                    // racking, stacked to the roof
    for (let s = 0; s < 4; s++) { m.fillStyle = '#2a3038'; m.fillRect(x, 40 + s * 28, 120, 5);
      for (let k = 0; k < 4; k++) if (R() < 0.75) { m.fillStyle = pick2(R, ['#8a6a40', '#7a5a34', '#94764a']);
        m.fillRect(x + 4 + k * 30, 22 + s * 28, 26, 18); } }
    m.fillStyle = '#39414e'; m.fillRect(x, 20, 6, 130); m.fillRect(x + 116, 20, 6, 130);
  }
  // the roof: light strips end to end, which is what a packing hall is
  n.fillStyle = '#1a1f26'; n.fillRect(0, 0, L.near.width, 22);
  for (let x = 12; x < L.near.width; x += 70) { n.fillStyle = '#e8f4ff'; n.fillRect(x, 8, 44, 6);
    n.fillStyle = 'rgba(220,240,255,0.10)'; n.fillRect(x - 12, 14, 68, 56); }
  gantry(n, L, R, 22, '#2f3640', '#454f5c');
  // the spiral conveyor bringing boxes down, then the palletiser
  for (let x = 100; x < len - 320; x += 330) {
    n.fillStyle = '#2f3a4a'; n.fillRect(x, 64, 130, 12);
    n.fillStyle = '#48586c'; n.fillRect(x, 64, 130, 2);
    for (let k = 0; k < 130; k += 11) { n.fillStyle = '#1a222c'; n.fillRect(x + k, 66, 5, 8); }
    for (let k = 0; k < 5; k++) { n.fillStyle = pick2(R, ['#a8814e', '#9a7444', '#b48c58']);
      n.fillRect(x + 8 + k * 26, 48, 20, 16);
      n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x + 8 + k * 26, 56, 20, 2);
      n.fillStyle = '#e8e0d0'; n.fillRect(x + 12 + k * 26, 51, 8, 4); }
    n.fillStyle = '#2a3038'; n.fillRect(x + 126, 76, 10, 44);
    n.fillStyle = '#e8a020'; n.fillRect(x + 118, 118, 26, 32);
    n.fillStyle = '#2a2e36'; n.fillRect(x + 122, 122, 18, 10);
  }
  for (let x = 40; x < L.near.width; x += 190) {                  // pallets stacked and wrapped
    const hgt = 2 + Math.floor(R() * 3);
    for (let s = 0; s < hgt; s++) {
      const cy = 150 - (s + 1) * 26;
      n.fillStyle = '#7a5a34'; n.fillRect(x, cy + 20, 74, 6);
      for (let k = 0; k < 74; k += 10) { n.fillStyle = '#8c6a40'; n.fillRect(x + k, cy + 20, 6, 6); }
      for (let k = 0; k < 3; k++) { n.fillStyle = pick2(R, ['#a8814e', '#9a7444', '#b48c58']);
        n.fillRect(x + 2 + k * 24, cy, 22, 20);
        n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(x + 2 + k * 24, cy + 9, 22, 2); }
      n.fillStyle = 'rgba(210,225,240,0.20)'; n.fillRect(x, cy, 74, 20);
    }
  }
  const a0 = len - 320;
  n.fillStyle = '#171c24'; n.fillRect(a0, 0, L.near.width - a0, 150);
  n.fillStyle = '#242c38'; n.fillRect(a0 + 24, 44, L.near.width - a0 - 48, 106);
  for (let k = 0; k < 3; k++) { n.fillStyle = '#1a2029'; n.fillRect(a0 + 44 + k * 84, 62, 64, 52);
    n.fillStyle = 'rgba(200,235,255,0.20)'; n.fillRect(a0 + 48 + k * 84, 66, 56, 44);
    n.fillStyle = k === 1 ? '#3ae05a' : '#e8c020'; n.fillRect(a0 + 68 + k * 84, 118, 16, 6); }
  neonText(n, 'QC / DESPATCH', a0 + 50, 24, '#3ae05a', 2);
  plateFloor(n, L, R, r, 168, '#333a44', '#3d4550', '#252b33', false);
  for (let x = 0; x < L.near.width; x += 130) {                   // painted aisle markings
    n.fillStyle = 'rgba(232,200,60,0.5)'; n.fillRect(x, 182, 70, 3);
    n.fillStyle = 'rgba(232,232,224,0.32)'; n.fillRect(x + 20, 210, 3, 30);
  }
}

// ---- B4: THE TEST CELLS ---------------------------------------------------
// The wildcard: a row of armoured glass cells with finished units running in.
function s6b_cells(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#080b12'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 110) { m.fillStyle = '#0e131c'; m.fillRect(x, 30, 96, 120);
    m.fillStyle = 'rgba(80,140,190,0.06)'; m.fillRect(x + 8, 40, 80, 70); }
  // the observation gantry running over the top of the cells
  n.fillStyle = '#1c232e'; n.fillRect(0, 24, L.near.width, 14);
  n.fillStyle = '#2e3948'; n.fillRect(0, 24, L.near.width, 3);
  grating(n, L, 38, 10, '#232b36', '#333d4c');
  for (let x = 0; x < L.near.width; x += 44) { n.fillStyle = '#39414e'; n.fillRect(x, 10, 3, 14); }
  n.fillStyle = '#c8302a'; n.fillRect(0, 8, L.near.width, 2);
  let x = 0, ci = 0;
  while (x < len - 320) {
    const cw = 138;
    // the cell: a concrete box with an armoured window and a blast door
    n.fillStyle = '#1b222c'; n.fillRect(x, 48, cw - 6, 102);
    concrete(n, x + 4, 52, cw - 14, 94, '#33404e', R);
    n.fillStyle = '#0d131b'; n.fillRect(x + 16, 62, cw - 42, 62);
    const kind = ci % 4;
    const glow = ['#2ad0f0', '#ff8a30', '#3ae05a', '#e8283a'][kind];
    n.fillStyle = 'rgba(10,16,24,0.9)'; n.fillRect(x + 19, 65, cw - 48, 56);
    n.save(); n.shadowColor = glow; n.shadowBlur = 10;
    n.fillStyle = glow; n.fillRect(x + 24, 68, cw - 58, 3); n.restore();
    n.fillStyle = `rgba(${kind === 1 ? '255,138,48' : kind === 3 ? '232,40,58' : kind === 2 ? '58,224,90' : '42,208,240'},0.14)`;
    n.fillRect(x + 19, 65, cw - 48, 56);
    // the unit inside, mid-test
    n.fillStyle = 'rgba(0,0,0,0.75)';
    const ux = x + 40 + (ci % 3) * 18;
    n.fillRect(ux, 88, 16, 30);
    n.fillRect(ux - 5, 92, 5, 18); n.fillRect(ux + 16, 92, 5, 18);
    n.beginPath(); n.arc(ux + 8, 84, 8, 0, 7); n.fill();
    n.fillStyle = glow; n.fillRect(ux + 3, 82, 4, 3); n.fillRect(ux + 10, 82, 4, 3);
    // the glass: reflections and a spiderweb crack in one of them
    n.fillStyle = 'rgba(210,235,255,0.10)';
    n.beginPath(); n.moveTo(x + 19, 121); n.lineTo(x + 54, 65); n.lineTo(x + 70, 65); n.lineTo(x + 35, 121); n.fill();
    n.fillStyle = '#39414e'; n.fillRect(x + 16, 62, cw - 42, 4); n.fillRect(x + 16, 120, cw - 42, 4);
    if (ci % 5 === 3) { n.strokeStyle = 'rgba(235,245,255,0.55)'; n.lineWidth = 1;
      for (let k = 0; k < 9; k++) { n.beginPath(); n.moveTo(x + 60, 92);
        n.lineTo(x + 60 + Math.cos(k) * 26, 92 + Math.sin(k) * 22); n.stroke(); } }
    // the blast door and the beacon beside it
    n.fillStyle = '#2a323e'; n.fillRect(x + cw - 34, 62, 24, 84);
    for (let k = 0; k < 84; k += 12) { n.fillStyle = '#374252'; n.fillRect(x + cw - 34, 62 + k, 24, 4); }
    n.fillStyle = '#e8c020'; n.fillRect(x + cw - 34, 62, 24, 4);
    for (let k = 0; k < 24; k += 8) { n.fillStyle = '#1a1a1e'; n.fillRect(x + cw - 34 + k, 62, 4, 4); }
    n.fillStyle = '#1a1f28'; n.fillRect(x + cw - 42, 70, 8, 12);
    n.fillStyle = ci % 2 ? '#e8283a' : '#3a2028';
    n.beginPath(); n.arc(x + cw - 38, 74, 3.5, 0, 7); n.fill();
    ptext(n, 'CELL ' + (ci + 1), x + 20, 132, '#7a8a9a', 1);
    x += cw; ci++;
  }
  const a0 = len - 320;
  n.fillStyle = '#0c1118'; n.fillRect(a0, 0, L.near.width - a0, 150);
  concrete(n, a0 + 10, 44, L.near.width - a0 - 20, 106, '#2d3a48', R);
  n.fillStyle = '#0d131b'; n.fillRect(a0 + 40, 60, L.near.width - a0 - 80, 74);
  n.save(); n.shadowColor = '#e8283a'; n.shadowBlur = 14;
  n.fillStyle = '#e8283a'; n.fillRect(a0 + 50, 66, L.near.width - a0 - 100, 4); n.restore();
  n.fillStyle = 'rgba(232,40,58,0.13)'; n.fillRect(a0 + 40, 60, L.near.width - a0 - 80, 74);
  neonText(n, 'CELL 9 - DO NOT ENTER', a0 + 40, 26, '#e8283a', 2);
  plateFloor(n, L, R, r, 164, '#262f3a', '#2f3945', '#1a2027', true);
  for (let x2 = 0; x2 < L.near.width; x2 += 138) {                // the safety line outside each door
    for (let k = 0; k < 138; k += 14) { n.fillStyle = (Math.round(k / 14) % 2) ? '#e8c020' : '#1a2027';
      n.fillRect(x2 + k, 176, 14, 3); }
  }
  L.beacon = 1;
}

// ============================================================ 6-C: THE CRUCIBLE
// Slag's arena. Currently this scene reuses the Foundry's background outright,
// so all four of these are new ground.

// ---- C1: THE LADLE PIT ----------------------------------------------------
function s6c_ladlepit(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#1a0a06'; f.fillRect(0, 0, L.far.width, H);
  f.fillStyle = 'rgba(255,140,40,0.10)'; f.fillRect(0, 60, L.far.width, 90);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 120) { m.fillStyle = '#26150f'; m.fillRect(x, 40, 104, 110);
    m.fillStyle = '#321d14'; m.fillRect(x, 40, 104, 4); }
  // near: refractory brick walls on both sides of a sunken pit
  for (let x = 0; x < L.near.width; x += 90) {
    for (let by = 16; by < 150; by += 9) for (let bx = 0; bx < 90; bx += 18) {
      const t2 = R();
      n.fillStyle = t2 < 0.12 ? '#6a3a20' : t2 < 0.55 ? '#8a5a34' : '#7a4a2a';
      n.fillRect(x + bx + ((Math.round(by / 9)) % 2) * 9, by, 17, 8);
    }
    n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x + 88, 16, 2, 134);
  }
  for (let k = 0; k < L.near.width / 10; k++) { n.fillStyle = 'rgba(30,14,6,0.30)';   // scorch up the brick
    n.fillRect(r(0, L.near.width), r(90, 150), 14 + R() * 30, 8 + R() * 18); }
  gantry(n, L, R, 0, '#2a1a14', '#3e2a1e');
  // the ladle, tipping, with the pour coming down into the pit
  const px0 = len - 300;
  for (let x = 120; x < L.near.width; x += 430) {
    n.fillStyle = '#2a2028'; n.fillRect(x, 34, 96, 58);
    n.fillStyle = '#3a2c30'; n.fillRect(x, 34, 96, 5);
    for (let k = 0; k < 96; k += 16) { n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x + k, 39, 3, 53); }
    n.fillStyle = '#4a3a3a'; n.fillRect(x - 8, 44, 8, 18); n.fillRect(x + 96, 44, 8, 18);
    n.save(); n.shadowColor = '#ffb020'; n.shadowBlur = 14;
    n.fillStyle = '#ffd060'; n.fillRect(x + 20, 88, 56, 8); n.restore();
    // the stream, falling
    const g = n.createLinearGradient(0, 96, 0, 172);
    g.addColorStop(0, '#fff0a0'); g.addColorStop(0.5, '#ffb020'); g.addColorStop(1, '#e0500c');
    n.fillStyle = g; n.fillRect(x + 42, 96, 13, 78);
    n.fillStyle = 'rgba(255,255,220,0.55)'; n.fillRect(x + 46, 96, 4, 78);
    n.fillStyle = 'rgba(255,150,40,0.18)'; n.fillRect(x + 12, 90, 74, 90);
    for (let k = 0; k < 20; k++) { n.fillStyle = pick2(R, ['#ffd060', '#fff0a0', '#ff8a10']);
      n.fillRect(x + 48 + (R() - 0.5) * 60, 150 + R() * 36, 2, 2); }
  }
  // the pit floor: scorched plate with cooled splash frozen on it
  plateFloor(n, L, R, r, 168, '#33251d', '#3d2d22', '#1f1610', false);
  for (let k = 0; k < L.near.width / 40; k++) { n.fillStyle = pick2(R, ['#5a4a42', '#6a5248', '#4a3a34']);
    n.beginPath(); n.ellipse(r(0, L.near.width), r(180, 234), 8 + R() * 16, 3 + R() * 4, 0, 0, 7); n.fill(); }
  for (let k = 0; k < 22; k++) { n.fillStyle = 'rgba(255,150,40,0.20)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(182, 232), 10 + R() * 18, 3 + R() * 4, 0, 0, 7); n.fill(); }
  n.fillStyle = '#2a2028'; n.fillRect(px0, 168, L.near.width - px0, 3);
  heatWash(n, L, 150, 240, 'rgba(255,140,40,0.16)');
  L.heat = 1; L.embers = 1;
}

// ---- C2: THE TORPEDO YARD -------------------------------------------------
function s6c_torpedo(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#100a10'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 100) { f.fillStyle = '#171020'; f.fillRect(x, 30, 84, 120);
    if (R() < 0.5) { f.fillStyle = '#c8a040'; f.fillRect(x + 12 + R() * 56, 44 + R() * 80, 3, 3); } }
  f.fillStyle = 'rgba(255,150,60,0.08)'; f.fillRect(0, 90, L.far.width, 60);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 150) {                    // more torpedo cars, further off
    m.fillStyle = '#1e1a24'; m.beginPath(); m.ellipse(x + 62, 122, 62, 18, 0, 0, 7); m.fill();
    m.save(); m.shadowColor = '#ff8a20'; m.shadowBlur = 10; m.fillStyle = '#ffb040';
    m.fillRect(x + 118, 116, 8, 7); m.restore();
  }
  gantry(n, L, R, 18, '#2a2630', '#3e3846');
  pipeRun(n, L, R, [60], true);
  // the cars themselves: long cigars on bogies, glowing at the mouth
  let x = -40;
  while (x < len - 280) {
    const w2 = 250;
    n.fillStyle = '#161219'; n.beginPath(); n.ellipse(x + w2 / 2, 116, w2 / 2, 30, 0, 0, 7); n.fill();
    const g = n.createLinearGradient(0, 88, 0, 146);
    g.addColorStop(0, '#4a4450'); g.addColorStop(0.35, '#38333f'); g.addColorStop(1, '#221e28');
    n.fillStyle = g; n.beginPath(); n.ellipse(x + w2 / 2, 116, w2 / 2 - 4, 27, 0, 0, 7); n.fill();
    for (let k = 0; k < w2; k += 34) { n.fillStyle = 'rgba(0,0,0,0.22)';
      n.fillRect(x + k, 94, 3, 44); }
    n.fillStyle = 'rgba(255,255,255,0.10)'; n.beginPath(); n.ellipse(x + w2 / 2, 100, w2 / 2 - 24, 7, 0, 0, 7); n.fill();
    // the charging mouth on top, glowing
    n.fillStyle = '#1a1620'; n.fillRect(x + w2 / 2 - 26, 84, 52, 12);
    n.save(); n.shadowColor = '#ffb020'; n.shadowBlur = 14;
    n.fillStyle = '#ffd060'; n.fillRect(x + w2 / 2 - 20, 82, 40, 6); n.restore();
    n.fillStyle = 'rgba(255,176,32,0.16)'; n.fillRect(x + w2 / 2 - 50, 66, 100, 40);
    // the end spout, dribbling
    n.fillStyle = '#2a2430'; n.fillRect(x + w2 - 26, 106, 30, 16);
    n.save(); n.shadowColor = '#ff8a20'; n.shadowBlur = 10;
    n.fillStyle = '#ffb040'; n.fillRect(x + w2 - 2, 110, 8, 7); n.restore();
    // the bogies underneath
    for (const bx of [x + 40, x + w2 - 70]) {
      n.fillStyle = '#16141c'; n.fillRect(bx, 140, 40, 10);
      for (const wx of [bx + 8, bx + 30]) { n.fillStyle = '#26242c'; n.beginPath(); n.arc(wx, 152, 7, 0, 7); n.fill();
        n.fillStyle = '#3c3a46'; n.beginPath(); n.arc(wx, 152, 3, 0, 7); n.fill(); }
    }
    x += w2 + 18;
  }
  ballast(n, L, R, r, 158, '#2c2830', '#3a343e', '#201c26');
  railPair(n, L, R, 186, '#3a3028', '#8a8a96', '#c8c8d4');
  railPair(n, L, R, 220, '#3a3028', '#8a8a96', '#c8c8d4');
  for (let k = 0; k < 20; k++) { n.fillStyle = 'rgba(255,150,40,0.14)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(170, 232), 12 + R() * 18, 4, 0, 0, 7); n.fill(); }
  heatWash(n, L, 150, 240, 'rgba(255,140,40,0.09)');
  L.heat = 1;
}

// ---- C3: THE QUENCH TANK --------------------------------------------------
function s6c_quench(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0d1116'; f.fillRect(0, 0, L.far.width, H);
  f.fillStyle = 'rgba(210,225,240,0.10)'; f.fillRect(0, 50, L.far.width, 100);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 120) { m.fillStyle = '#161d24'; m.fillRect(x, 36, 104, 114);
    m.fillStyle = 'rgba(220,235,250,0.06)'; m.fillRect(x + 10, 48, 60, 40); }
  gantry(n, L, R, 14, '#2f3640', '#454f5c');
  // the crane carrying a red-hot part down towards the water
  for (let x = 160; x < L.near.width; x += 520) {
    n.fillStyle = '#39414e'; n.fillRect(x, 52, 56, 16);
    n.fillStyle = '#4e5a6a'; n.fillRect(x + 2, 54, 52, 4);
    n.fillStyle = '#2a2e36'; n.fillRect(x + 26, 68, 3, 26);
    n.save(); n.shadowColor = '#ff8a20'; n.shadowBlur = 16;
    n.fillStyle = '#ffb040'; n.fillRect(x + 8, 94, 40, 18); n.restore();
    n.fillStyle = 'rgba(255,150,40,0.18)'; n.fillRect(x - 10, 86, 76, 40);
    for (let k = 0; k < 10; k++) { n.fillStyle = '#ffd060'; n.fillRect(x + 10 + R() * 36, 112 + R() * 14, 2, 2); }
  }
  // the tank: a big steel box of water, steaming, with a grated walkway round it
  const TANK = 118;
  n.fillStyle = '#20262e'; n.fillRect(0, TANK, L.near.width, 14);
  n.fillStyle = '#39414e'; n.fillRect(0, TANK, L.near.width, 3);
  const g = n.createLinearGradient(0, TANK + 14, 0, 172);
  g.addColorStop(0, '#2a5a6e'); g.addColorStop(0.5, '#1b3f52'); g.addColorStop(1, '#122b3a');
  n.fillStyle = g; n.fillRect(0, TANK + 14, L.near.width, 40);
  for (let k = 0; k < L.near.width * 0.8; k++) { n.fillStyle = R() < 0.3 ? 'rgba(180,220,240,0.20)' : 'rgba(20,50,70,0.5)';
    n.fillRect(r(0, L.near.width), TANK + 16 + R() * 36, 6 + R() * 12, 1); }
  for (let x = 0; x < L.near.width; x += 180) {                    // heat shimmering off the surface
    n.fillStyle = 'rgba(255,170,90,0.12)';
    n.beginPath(); n.ellipse(x, TANK + 30, 48, 12, 0, 0, 7); n.fill();
  }
  n.fillStyle = '#2f3640'; n.fillRect(0, 168, L.near.width, 8);
  n.fillStyle = '#454f5c'; n.fillRect(0, 168, L.near.width, 2);
  for (let x = 0; x < L.near.width; x += 60) { n.fillStyle = '#39414e'; n.fillRect(x, 132, 5, 40); }
  grating(n, L, 176, 64);
  n.fillStyle = '#c8b030'; n.fillRect(0, 176, L.near.width, 3);
  n.fillStyle = '#39414e'; n.fillRect(0, 236, L.near.width, 4);
  for (let x = 0; x < L.near.width; x += 90) { n.fillStyle = '#c8302a'; n.fillRect(x, 236, 14, 4); }
  const a0 = len - 300;
  n.fillStyle = '#141b22'; n.fillRect(a0, 0, L.near.width - a0, 118);
  n.fillStyle = '#1e2730'; n.fillRect(a0 + 20, 36, L.near.width - a0 - 40, 82);
  neonText(n, 'QUENCH 2', a0 + 50, 22, '#8ef0ff', 2);
  L.steamWall = 1;
}

// ---- C4: THE SLAG BANK ----------------------------------------------------
// The wildcard: the fight is on a bank above a slag dump, with a pot tipping a
// river of molten slag down the slope below you.
function s6c_slagbank(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const sky = f.createLinearGradient(0, 0, 0, 150);
  sky.addColorStop(0, '#0a0610'); sky.addColorStop(0.5, '#3a1210'); sky.addColorStop(1, '#8a2e0c');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  for (let i = 0; i < 30; i++) { f.fillStyle = 'rgba(255,255,255,0.3)'; f.fillRect(r(0, L.far.width), r(0, 40), 1, 1); }
  for (let x = 0; x < L.far.width; x += 70) {                      // the works on the skyline
    const h = 30 + R() * 60;
    f.fillStyle = '#1a0e0c'; f.fillRect(x, 110 - h, 40, h + 40);
    if (R() < 0.5) { f.fillStyle = '#2a1410'; f.fillRect(x + 10, 110 - h - 24, 14, 24); }
    if (R() < 0.35) { f.save(); f.shadowColor = '#ff8a20'; f.shadowBlur = 8;
      f.fillStyle = '#ffb040'; f.fillRect(x + 12, 110 - h - 28, 10, 5); f.restore(); }
  }
  // mid: the dump itself, a long glowing scar down the far slope
  m.fillStyle = '#1e120e'; m.fillRect(0, 96, L.mid.width, 54);
  for (let x = 0; x < L.mid.width; x += 40) { const h = 12 + R() * 26;
    m.fillStyle = '#2a1a14'; m.beginPath(); m.moveTo(x, 150); m.lineTo(x + 20, 150 - h); m.lineTo(x + 42, 150); m.fill(); }
  for (let k = 0; k < L.mid.width / 3; k++) {
    const gx = r(0, L.mid.width), gy = r(106, 148);
    m.fillStyle = pick2(R, ['rgba(255,150,40,0.35)', 'rgba(255,90,20,0.30)', 'rgba(255,220,120,0.22)']);
    m.fillRect(gx, gy, 5 + R() * 9, 2);
  }
  // near: the pot tipping over the edge, and the bank you fight on
  for (let x = 90; x < len - 280; x += 380) {
    n.fillStyle = '#16141c'; n.fillRect(x, 60, 108, 46);
    n.fillStyle = '#2f2830'; n.fillRect(x + 3, 63, 102, 40);
    n.fillStyle = '#3d353e'; n.fillRect(x + 3, 63, 102, 4);
    for (let k = 0; k < 102; k += 18) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x + 3 + k, 67, 3, 36); }
    n.fillStyle = '#4a4048'; n.fillRect(x - 8, 72, 10, 20); n.fillRect(x + 106, 72, 10, 20);
    n.save(); n.shadowColor = '#ff8a20'; n.shadowBlur = 16;
    n.fillStyle = '#ffd060'; n.fillRect(x + 84, 100, 26, 8); n.restore();
    // the slag running down the slope
    const g = n.createLinearGradient(0, 106, 0, 150);
    g.addColorStop(0, '#fff0a0'); g.addColorStop(0.4, '#ff9a20'); g.addColorStop(1, '#a8260a');
    n.fillStyle = g;
    n.beginPath(); n.moveTo(x + 86, 106); n.lineTo(x + 112, 106);
    n.lineTo(x + 160, 150); n.lineTo(x + 116, 150); n.fill();
    n.fillStyle = 'rgba(255,255,220,0.40)';
    n.beginPath(); n.moveTo(x + 92, 106); n.lineTo(x + 100, 106); n.lineTo(x + 134, 150); n.lineTo(x + 122, 150); n.fill();
    n.fillStyle = 'rgba(255,140,30,0.22)'; n.fillRect(x + 60, 92, 130, 60);
    for (let k = 0; k < 26; k++) { n.fillStyle = pick2(R, ['#ffd060', '#fff0a0', '#ff8a10']);
      n.fillRect(x + 100 + R() * 60, 108 + R() * 44, 2, 2); }
  }
  // the crest of the bank, with rail and a tipping dock along it
  n.fillStyle = '#241810'; n.fillRect(0, 150, L.near.width, 90);
  for (let k = 0; k < L.near.width * 1.6; k++) { n.fillStyle = R() < 0.5 ? '#2e1f15' : '#1c130d';
    n.fillRect(r(0, L.near.width), r(152, 240), 3, 2); }
  for (let k = 0; k < L.near.width / 26; k++) { n.fillStyle = pick2(R, ['#4a3a34', '#5a4840', '#3a2d28']);
    n.fillRect(r(0, L.near.width), r(156, 236), 5 + R() * 9, 4); }
  for (let k = 0; k < L.near.width / 34; k++) { n.fillStyle = 'rgba(255,140,30,0.18)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(158, 234), 7 + R() * 14, 3, 0, 0, 7); n.fill(); }
  n.fillStyle = '#1a1008'; n.fillRect(0, 150, L.near.width, 4);
  railPair(n, L, R, 172, '#33251b', '#8a8a96', '#c8c8d4');
  for (let x = 0; x < L.near.width; x += 120) {                    // the kerb along the tipping edge
    n.fillStyle = '#4a4048'; n.fillRect(x, 142, 110, 9);
    n.fillStyle = '#5c5058'; n.fillRect(x, 142, 110, 2);
    n.fillStyle = 'rgba(255,140,30,0.20)'; n.fillRect(x, 151, 110, 5);
  }
  heatWash(n, L, 140, 240, 'rgba(255,120,30,0.14)');
  L.heat = 1; L.embers = 1;
}
