// ============================================================ the picker (stage 7)
const SECTIONS = [
  { id: 'A', stage: '7-A', now: 'CLEAN CORRIDOR', len: 1500, options: [
    { k: 'A1', name: 'The Clean Corridor', f: s7a_corridor,
      pitch: 'What the name promises, built properly: a pharmaceutical-grade corridor, and the brightest background in the game.',
      notes: ['Gasketed panel walls, glazed bays through to four differently-lit labs, pressure doors with interlock lights every 430 units',
              'A torn cable tray overhead is the reason the wires bite, instead of them appearing from nowhere',
              'Coming straight off the foundry it is a hard cut from orange to white - the biggest tonal jolt in the run'] },
    { k: 'A2', name: 'The Server Spine', f: s7a_servers,
      pitch: 'The lab\'s data floor. A cold aisle between rack rows, thousands of little lights, raised floor lifted open.',
      notes: ['Blinking LED columns the whole length, blue one side and green the other, receding four layers deep',
              'Floor panels lifted out with the looms exposed - the hazard is literally lying there',
              'The darkest of the four, and the only one where the background is doing the twinkling rather than the lights'] },
    { k: 'A3', name: 'The Growth Gallery', f: s7a_growth,
      pitch: 'A working wall of culture tanks with the feed plant serving them. Green, wet, and wrong.',
      notes: ['Tanks of three sizes in a repeating rhythm, one in four emptied and stencilled EMPTY in red',
              'Feed lines drop into every tank from a header overhead; culture control desks between the banks',
              'Makes the Specimen Wing read as the next step up rather than a separate idea'] },
    { k: 'A4', name: 'The Service Crawl', f: s7a_crawl,
      pitch: 'The wildcard: you never reach the clean side. This is the plant space behind it.',
      notes: ['A supply trunk right over your head with flexible take-offs peeling into rooms you cannot get to',
              'Emergency lighting only - amber pools every 150 units and deep shadow between them',
              'You see the clean rooms lit from inside through small panes, which makes arriving in the Specimen Wing land much harder'] },
  ] },
  { id: 'B', stage: '7-B', now: 'SPECIMEN WING', len: 1280, options: [
    { k: 'B1', name: 'The Specimen Wing', f: s7b_wing,
      pitch: 'The name taken at its word: a two-storey gallery of person-sized capsules, numbered, one of them burst.',
      notes: ['A service catwalk runs overhead with the upper storey\'s capsules visible over its handrail',
              'Every fifth capsule has gone - glass out, fluid down the wall, the number stencilled in red',
              'Teal and cold rather than the green of 7-A3, so the two do not collide if you pick both'] },
    { k: 'B2', name: 'The Gene Deck', f: s7b_gene,
      pitch: 'A working wet lab rather than a menagerie. Benches, fume hoods, centrifuges, somebody\'s working on the wall.',
      notes: ['Hood sashes at three different heights with real glassware inside, instrument stacks between them',
              'Whiteboards covered in working behind, and a hazard-banded autoclave twice down the run',
              'The least supernatural option - the horror is that it all looks completely routine'] },
    { k: 'B3', name: 'The Cold Store', f: s7b_cold,
      pitch: 'Cryogenic storage. Frost on every surface, vapour pouring off the dewars and rolling along the floor.',
      notes: ['Banks of numbered drawers with frost on every lip, one drawer in four pulled out and empty',
              'Standing LN2 dewars breathing vapour that pools around your feet - the pit reads as an open cryo well',
              'The coldest-looking scene in the game and the strongest contrast with stage 6'] },
    { k: 'B4', name: 'The Ward', f: s7b_ward,
      pitch: 'The wildcard, with no science-fiction in it at all: a hospital ward, beds made, monitors running, nobody in any of them.',
      notes: ['Bay after bay with a bed, a trace still moving on the monitor, a drip stand, and restraints left undone',
              'Curtain rails overhead, a nurses\' station with the lights on, paper dropped on the floor',
              'One fluorescent tube in six has failed and flickers - the most unsettling of the twelve by a distance'] },
  ] },
  { id: 'C', stage: '7-C', now: 'THE VAULT', len: 1220, options: [
    { k: 'C1', name: 'The Vault', f: s7c_vault,
      pitch: 'A buried strongroom. A door a metre thick stood open at the head of it, numbered cases to the ceiling.',
      notes: ['A crane runway beam the whole length overhead - honest structure for the falling hazard to come off',
              'Tiered racking with cases, some slots empty, and downlights throwing gold pools every 260 units',
              'A lit plinth at mid-scene where the Unit-9 capsule sits, so the objective is the obvious thing in the room'] },
    { k: 'C2', name: 'The Core', f: s7c_core,
      pitch: 'The biggest object in the game: a containment core running the whole scene, ring-lit, with coolant trunks feeding it.',
      notes: ['The core is shaded as one enormous cylinder with binding rings and lit inspection ports every 116 units',
              'Coolant trunks and elbows overhead, a handrail along the deck edge, a control island at mid-scene',
              'Deep blue throughout, with the capsule berth beside the island as the one warm thing on screen'] },
    { k: 'C3', name: 'The Archive', f: s7c_archive,
      pitch: 'Automated storage: a wall of black slots to the ceiling and a retrieval arm that travels the scene picking cases out.',
      notes: ['The only option where the set itself moves - the arm runs the length on its rail, stops, and picks',
              'Red index lights on every occupied slot, empty slots lit red from inside, index terminals between stacks',
              'Nearly monochrome, so the gold-lit Unit-9 slot is the only colour in the scene'] },
    { k: 'C4', name: 'The Birthing Floor', f: s7c_birth,
      pitch: 'The wildcard, and the one that says out loud what the stage opening only implies.',
      notes: ['A line of upright capsules with part-finished bodies standing in them, umbilicals dropping from a header',
              'One in four empty with the hatch stood open, one in four stencilled REJECT in red',
              'At mid-scene one capsule is closed, finished and lit gold: UNIT 9 - COMPLETE. The strongest story beat of the twelve'] },
  ] },
];

const BUILT = new Map();
const ORDER = [];
function build(opt, len) {
  if (BUILT.has(opt.k)) { touch(opt.k); return BUILT.get(opt.k); }
  const R = mulberry(opt.k.charCodeAt(0) * 7919 + opt.k.charCodeAt(1) * 131 + len);
  const r = (a, b) => a + R() * (b - a);
  const L = {
    far: mkCanvas(Math.ceil(W + len * 0.25) + 20, H),
    mid: mkCanvas(Math.ceil(W + len * 0.55) + 20, H),
    near: mkCanvas(len + W, H),
  };
  opt.f(L, R, r, len);
  BUILT.set(opt.k, L); ORDER.push(opt.k);
  while (ORDER.length > 6) { const dead = ORDER.shift(); if (dead !== opt.k) BUILT.delete(dead); }
  return L;
}
function touch(k) { const i = ORDER.indexOf(k); if (i >= 0) { ORDER.splice(i, 1); ORDER.push(k); } }

// ---- live overlays -------------------------------------------------------
// A lab is never quite still: the tubes hum and the brightness breathes. Kept
// well under the level that would read as a flash.
function drawLabHum(g, t) {
  const k = 0.012 + Math.abs(Math.sin(t / 96)) * 0.012;
  g.fillStyle = `rgba(210,230,245,${k})`; g.fillRect(0, 34, W, 116);
}
// Status LEDs turning over across the rack faces.
function drawBlink(g, t, cam) {
  for (let i = 0; i < 46; i++) {
    const seed = i * 167;
    const wx = (seed * 29) % 1900;
    const x = wx - cam * 1.0;
    if (x < -8 || x > W + 8) continue;
    const y = 96 + (seed % 46);
    const on = ((Math.floor(t / (8 + (i % 5) * 5)) + i) % 3) === 0;
    if (!on) continue;
    g.fillStyle = i % 3 ? 'rgba(90,208,106,0.75)' : 'rgba(74,192,232,0.75)';
    g.fillRect(x, y, 2, 2);
  }
}
// Bubbles rising inside the tanks. The pitch is the tank spacing of whichever
// option asked for them, so the columns line up with the glass.
function drawBubbles(g, t, cam, pitch) {
  const first = Math.floor(cam / pitch) - 1;
  for (let i = first; i < first + Math.ceil(W / pitch) + 2; i++) {
    const bx = i * pitch - cam;
    if (bx < -pitch || bx > W + pitch) continue;
    for (let k = 0; k < 5; k++) {
      const seed = i * 53 + k * 29;
      const life = (t * (0.5 + (seed % 4) * 0.18) + seed * 7) % 62;
      const y = 142 - life;
      if (y < 86) continue;
      g.fillStyle = `rgba(226,255,244,${0.10 + (1 - life / 62) * 0.22})`;
      g.fillRect(bx + 26 + (seed % 38) + Math.sin(life / 7 + k) * 2, y, 2, 2);
    }
  }
}
// Emergency lighting: an amber wash that lifts and settles rather than blinks.
function drawEmerg(g, t) {
  const k = 0.020 + Math.abs(Math.sin(t / 58)) * 0.026;
  g.fillStyle = `rgba(232,160,48,${k})`; g.fillRect(0, 34, W, 206);
}
// Water finding its way out of a badly-lagged pipe.
function drawCrawlDrip(g, t, cam) {
  for (let i = 0; i < 6; i++) {
    const seed = i * 211;
    const wx = (seed * 41) % 1900;
    const x = wx - cam;
    if (x < -6 || x > W + 6) continue;
    const life = (t * 1.6 + seed) % 150;
    if (life > 62) continue;
    g.fillStyle = 'rgba(180,210,230,0.45)';
    g.fillRect(x, 112 + life * 0.62, 1, 3);
    if (life > 55) { g.fillStyle = 'rgba(180,210,230,0.18)';
      g.beginPath(); g.ellipse(x, 152, 4 + (life - 55), 2, 0, 0, 7); g.fill(); }
  }
}
// Cryogenic vapour: heavy, so it rolls along the floor rather than rising.
function drawCryo(g, t, cam) {
  for (let i = 0; i < 16; i++) {
    const seed = i * 149;
    const x = ((seed * 37 + t * (0.28 + (i % 4) * 0.16)) % (W + 220)) - 110;
    const y = 190 + ((seed % 42)) + Math.sin(t / 70 + i) * 4;
    g.fillStyle = `rgba(214,240,255,${0.035 + (i % 3) * 0.016})`;
    g.beginPath(); g.ellipse(x, y, 40 + (i % 5) * 26, 7 + (i % 3) * 5, 0, 0, 7); g.fill();
  }
  g.fillStyle = 'rgba(190,225,255,0.035)'; g.fillRect(0, 34, W, 206);
}
// One tube in six has failed. Deliberately soft - a dip in brightness with an
// occasional blink, never a strobe.
function drawFlickerTube(g, t, cam) {
  const period = 132, ph = t % period;
  const on = ph < 96 ? 1 : (ph % 7 < 3 ? 0.25 : 0.85);
  g.fillStyle = `rgba(200,224,204,${0.030 * on})`; g.fillRect(0, 34, W, 206);
  const wx = 560 - cam * 1.0;
  if (wx > -90 && wx < W + 90 && ph >= 96) {
    g.fillStyle = `rgba(210,232,214,${0.06 * (1 - on)})`;
    g.fillRect(wx - 60, 48, 120, 100);
  }
}
// Dust hanging in the downlights, the way it does in a room nobody goes into.
function drawDustMotes(g, t, cam) {
  for (let i = 0; i < 30; i++) {
    const seed = i * 173;
    const wx = (seed * 31) % 1700;
    const x = wx - cam + Math.sin(t / 90 + i) * 5;
    if (x < -4 || x > W + 4) continue;
    const y = 86 + ((seed % 120) + t * 0.10) % 120;
    g.fillStyle = `rgba(240,228,190,${0.10 + (i % 3) * 0.05})`;
    g.fillRect(x, y, 1, 1);
  }
}
// The core breathing: a slow lift in blue across the mid band.
function drawCorePulse(g, t) {
  const k = 0.020 + Math.pow(Math.abs(Math.sin(t / 120)), 2) * 0.045;
  const gr = g.createLinearGradient(0, 40, 0, 150);
  gr.addColorStop(0, `rgba(110,180,255,${k * 0.5})`);
  gr.addColorStop(0.5, `rgba(130,200,255,${k})`);
  gr.addColorStop(1, `rgba(60,120,200,${k * 0.4})`);
  g.fillStyle = gr; g.fillRect(0, 40, W, 110);
}
// The retrieval arm: travels the rail, stops at a slot, reaches in, moves on.
function drawCraneArm(g, t, cam, len) {
  const span = len + 200;
  const cycle = (t * 0.55) % span;
  const x = cycle - cam;
  if (x < -70 || x > W + 70) return;
  const dwell = Math.max(0, Math.sin(t / 40));            // the reach in and out
  g.fillStyle = '#2a2536'; g.fillRect(x - 16, 44, 32, 14);
  g.fillStyle = '#3a3448'; g.fillRect(x - 16, 44, 32, 3);
  g.fillStyle = 'rgba(232,40,58,0.85)'; g.fillRect(x - 12, 48, 3, 3);
  g.fillStyle = '#211d2b'; g.fillRect(x - 5, 58, 10, 30);
  g.fillStyle = '#2f2a3c'; g.fillRect(x - 5, 58, 3, 30);
  const reach = 10 + dwell * 22;
  g.fillStyle = '#2a2536'; g.fillRect(x - 3, 88, 6, reach);
  g.fillStyle = '#3a3448'; g.fillRect(x - 9, 88 + reach, 18, 5);
  g.fillStyle = '#16131d'; g.fillRect(x - 7, 93 + reach, 14, 9);   // the case it is holding
  g.fillStyle = 'rgba(232,40,58,0.45)'; g.fillRect(x - 5, 96 + reach, 6, 2);
  g.fillStyle = 'rgba(0,0,0,0.25)';
  g.beginPath(); g.ellipse(x, 168, 14, 4, 0, 0, 7); g.fill();
}

const VIEWS = [];
let playing = true, speed = 1, cam = 0, frames = 0, maxLen = 1500;
function makeView(card, opt, len) {
  const cv = card.querySelector('canvas');
  cv.width = W * PX; cv.height = H * PX;
  const g = cv.getContext('2d');
  g.imageSmoothingEnabled = false;
  const v = { cv, g, opt, len, live: false };
  VIEWS.push(v);
  const io = new IntersectionObserver(es => { es.forEach(e => { v.live = e.isIntersecting; }); }, { rootMargin: '200px' });
  io.observe(cv);
  return v;
}
function paint(v) {
  const { g, opt, len } = v;
  const L = build(opt, len);
  g.setTransform(PX, 0, 0, PX, 0, 0);
  const c = Math.min(cam, len - W);
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  g.drawImage(L.far, -Math.round(c * 0.25), 0, L.far.width, L.far.height);
  g.drawImage(L.mid, -Math.round(c * 0.55), 0, L.mid.width, L.mid.height);
  g.drawImage(L.near, -Math.round(c), 0, L.near.width, L.near.height);
  if (L.corePulse) drawCorePulse(g, frames);
  if (L.bubbles) drawBubbles(g, frames, c, L.bubbles);
  if (L.blink) drawBlink(g, frames, c);
  if (L.craneArm) drawCraneArm(g, frames, c, len);
  if (L.cryo) drawCryo(g, frames, c);
  if (L.crawlDrip) drawCrawlDrip(g, frames, c);
  if (L.dustMotes) drawDustMotes(g, frames, c);
  if (L.emerg) drawEmerg(g, frames);
  if (L.flickerTube) drawFlickerTube(g, frames, c);
  if (L.labHum) drawLabHum(g, frames);
  if (BAND.checked) {
    g.fillStyle = 'rgba(74,192,232,0.10)'; g.fillRect(0, 150, W, 80);
    g.fillStyle = 'rgba(74,192,232,0.5)'; g.fillRect(0, 150, W, 1); g.fillRect(0, 229, W, 1);
    ptext(g, 'WALKABLE BAND', 6, 152, 'rgba(180,230,255,0.75)');
    g.fillStyle = 'rgba(232,40,58,0.35)'; g.fillRect(0, 0, W, 34);
    ptext(g, 'HUD', 6, 12, 'rgba(255,200,205,0.75)');
  }
  ptext(g, opt.k, 5, 5, 'rgba(255,255,255,0.28)', 2);
}
function frame() {
  if (playing) { cam += 0.9 * speed; frames += speed; if (cam > maxLen - W) cam = 0; SCRUB.value = String(Math.round(cam)); }
  for (const v of VIEWS) if (v.live) paint(v);
  requestAnimationFrame(frame);
}
