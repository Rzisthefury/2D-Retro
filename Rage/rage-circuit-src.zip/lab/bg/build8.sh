#!/bin/sh
# Assemble the stage 8 concept picker. Stage 8 uses none of the city toolkit,
# so only the core font/canvas helpers and the tower toolkit go in.
cd "$(dirname "$0")"
{ cat head3.html; cat body8.html; echo '<script>';
  cat 00_core.js 19_s8.js 20_s8a.js 21_s8b.js 22_s8c.js 98_viewer8.js 91_ui.js;
  echo '</script>'; } > picker8.html
# stage 8 gets its own pick key, so stage 7's choices do not show as pre-picked
sed -i "s/rc_bg_picks_v1/rc_bg_picks_s8/" picker8.html
wc -c picker8.html
