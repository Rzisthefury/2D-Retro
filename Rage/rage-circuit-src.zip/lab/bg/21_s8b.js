// ======================================================= 8-B  EXECUTIVE FLOOR
// The rematch gauntlet: Big Brick, then Ruby & Onyx, then up to the roof. It
// currently shares the Atrium's background outright, so all four of these are
// replacing nothing. The fight happens in a place that has never seen one.

// ---- B1  The Executive Floor ---------------------------------------------
// Panelled corridor of corner offices, art on the walls, a boardroom behind
// glass, and the city running past every opening.
function s8b_exec(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  f.fillStyle = '#0a0812'; f.fillRect(0, 0, W1, H);
  for (let k = 0; k < W1 * 0.5; k++) { f.fillStyle = 'rgba(226,190,96,0.16)'; f.fillRect(r(0, W1), r(50, 148), 1, 1); }
  // mid: the offices behind the corridor wall, each lit differently
  m.fillStyle = '#0d0a16'; m.fillRect(0, 34, WM, 116);
  for (let x = 0; x < WM; x += 104) {
    const tone = ['rgba(255,228,170,0.16)', 'rgba(255,208,140,0.10)', 'rgba(150,190,240,0.09)', 'rgba(255,228,170,0.05)'][((x / 104) | 0) % 4];
    m.fillStyle = tone; m.fillRect(x + 6, 46, 92, 92);
    cityPlate(m, x + 14, 52, 76, 60, R, r, '#0a0916');
    m.fillStyle = 'rgba(150,190,255,0.06)'; m.fillRect(x + 14, 52, 76, 60);
    m.fillStyle = '#1e1728'; m.fillRect(x + 98, 34, 8, 116);
    m.fillStyle = '#2f2438'; m.fillRect(x + 98, 34, 2, 116);
    // somebody's desk silhouetted against their own window
    m.fillStyle = 'rgba(12,8,16,0.75)'; m.fillRect(x + 20, 96, 56, 5);
    m.fillRect(x + 24, 101, 4, 12); m.fillRect(x + 68, 101, 4, 12);
    m.fillStyle = 'rgba(12,8,16,0.85)'; m.fillRect(x + 46, 82, 16, 14);
  }
  const LNear = { near: { width: W2 } };
  // near: the corridor itself
  n.fillStyle = '#1a1208'; n.fillRect(0, 34, W2, 12);              // coffered ceiling
  for (let x = 0; x < W2; x += 64) { n.fillStyle = '#2a1c0e'; n.fillRect(x, 34, 6, 12); }
  n.fillStyle = '#4a3418'; n.fillRect(0, 44, W2, 3);
  for (let x = 30; x < W2; x += 128) {                             // warm downlights
    n.fillStyle = '#ffe0a0'; n.fillRect(x, 46, 10, 3);
    const g = n.createLinearGradient(0, 48, 0, FLOOR8);
    g.addColorStop(0, 'rgba(255,214,140,0.17)'); g.addColorStop(1, 'rgba(255,214,140,0)');
    n.fillStyle = g; n.beginPath(); n.moveTo(x - 4, 48); n.lineTo(x + 14, 48);
    n.lineTo(x + 36, FLOOR8); n.lineTo(x - 26, FLOOR8); n.fill();
  }
  for (let x = 0; x < W2; x += 208) {                              // panelled piers between openings
    woodPanel(n, x, 48, 74, 100, R, r);
    const ai = ((x / 208) | 0) % 4;
    if (ai === 3) {                                               // one pier in four carries a trophy shelf
      n.fillStyle = '#2a1c0e'; n.fillRect(x + 12, 96, 50, 4);
      n.fillStyle = '#4a3418'; n.fillRect(x + 12, 96, 50, 1);
      for (let k = 0; k < 3; k++) {
        n.fillStyle = '#c8a24c'; n.fillRect(x + 18 + k * 16, 84, 6, 12);
        n.fillStyle = '#e8c878'; n.fillRect(x + 18 + k * 16, 84, 2, 12);
        n.fillStyle = '#8a6a28'; n.fillRect(x + 16 + k * 16, 92, 10, 4);
      }
      const tg2 = n.createLinearGradient(0, 74, 0, 104);
      tg2.addColorStop(0, 'rgba(255,214,140,0.20)'); tg2.addColorStop(1, 'rgba(255,214,140,0)');
      n.fillStyle = tg2; n.fillRect(x + 8, 74, 58, 30);
    } else {
      artFrame(n, x + 16, 62 + ai * 4, 42, 34 - ai * 3, R, r, ['#2a1a30', '#1c2a34', '#301e14'][ai]);
    }
    n.fillStyle = '#2a1c0e'; n.fillRect(x + 74, 48, 6, 100);       // reveal into the office beyond
    n.fillStyle = '#573a1c'; n.fillRect(x + 74, 48, 2, 100);
  }
  for (let x = 80; x < W2; x += 208) {                             // the openings: door + sidelight
    n.fillStyle = '#120c06'; n.fillRect(x + 6, 62, 40, 86);
    n.fillStyle = '#3c2814'; n.fillRect(x + 6, 62, 40, 4);
    n.fillStyle = '#4e3418'; n.fillRect(x + 8, 66, 36, 82);        // the door leaf
    n.fillStyle = '#301f0e'; n.fillRect(x + 8, 66, 3, 82);
    n.fillStyle = '#c8a24c'; n.fillRect(x + 38, 104, 5, 3);        // handle
    n.fillStyle = '#c8a24c'; n.fillRect(x + 14, 74, 24, 8);        // brass nameplate
    n.fillStyle = '#1a1208'; n.fillRect(x + 16, 76, 20, 4);
    n.fillStyle = 'rgba(255,228,170,0.13)'; n.fillRect(x + 52, 66, 12, 82);  // light through the sidelight
  }
  for (let x = 150; x < W2; x += 416) {                            // a credenza with a lamp
    n.fillStyle = '#2e1e0e'; n.fillRect(x, 120, 62, 28);
    n.fillStyle = '#48301a'; n.fillRect(x, 120, 62, 3);
    n.fillStyle = '#1c1208'; n.fillRect(x + 6, 126, 22, 16); n.fillRect(x + 34, 126, 22, 16);
    n.fillStyle = '#c8a24c'; n.fillRect(x + 24, 106, 14, 4);
    n.fillStyle = '#e8c878'; n.fillRect(x + 28, 110, 6, 10);
    const g = n.createRadialGradient(x + 31, 110, 0, x + 31, 110, 40);
    g.addColorStop(0, 'rgba(255,214,140,0.24)'); g.addColorStop(1, 'rgba(255,214,140,0)');
    n.fillStyle = g; n.fillRect(x - 10, 74, 84, 76);
  }
  // the boardroom: one long glazed wall late in the scene
  const bx = Math.min(1080, len - 300);
  n.fillStyle = '#231608'; n.fillRect(bx - 8, 48, 236, 100);
  glassPod(n, bx, 54, 220, 88, R, r, 'rgba(255,220,160,0.08)', '#4a3218');
  n.fillStyle = '#3a2410'; n.fillRect(bx + 22, 116, 176, 6);       // the table inside
  n.fillStyle = '#5c3a18'; n.fillRect(bx + 22, 116, 176, 2);
  for (let k = 0; k < 8; k++) { n.fillStyle = '#20150a'; n.fillRect(bx + 30 + k * 22, 104, 12, 14); }
  n.fillStyle = 'rgba(255,214,140,0.20)'; n.fillRect(bx + 20, 62, 180, 3);
  ptext(n, 'BOARD', bx + 96, 82, 'rgba(255,224,180,0.35)');
  carpetFloor(n, LNear, R, r, FLOOR8, '#2a1b2a', 'rgba(180,140,120,0.10)', '#4a2c22');
  for (let x = 30; x < W2; x += 128) { n.fillStyle = 'rgba(255,214,140,0.07)'; n.fillRect(x - 24, FLOOR8, 62, 90); }
  L.execDust = true;
  return L;
}

// ---- B2  The Boardroom ----------------------------------------------------
// One room, the whole scene. A table you could land a plane on, the board
// looking down off the wall, and the city on three sides.
function s8b_board(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  f.fillStyle = '#070610'; f.fillRect(0, 0, W1, H);
  for (let k = 0; k < W1 * 0.8; k++) {
    f.fillStyle = R() < 0.6 ? 'rgba(226,190,96,0.55)' : 'rgba(112,168,232,0.5)';
    f.fillRect(r(0, W1), r(60, 150), 1, 1);
  }
  // mid: an unbroken wall of glass - this room is the top of the building
  curtainWall(m, { near: { width: WM } }, 0, WM, 38, 106, R, r, { bay: 96, frame: '#2b2118', hi: '#4e3a22', transom: false });
  m.fillStyle = 'rgba(255,214,140,0.05)'; m.fillRect(0, 38, WM, 106);
  const LNear = { near: { width: W2 } };
  // near: coffered ceiling with a lighting trough down the centre
  n.fillStyle = '#17100a'; n.fillRect(0, 34, W2, 14);
  for (let x = 0; x < W2; x += 58) {
    n.fillStyle = '#251910'; n.fillRect(x, 34, 50, 12);
    n.fillStyle = '#3a2614'; n.fillRect(x, 34, 50, 2);
  }
  n.fillStyle = '#c8a24c'; n.fillRect(0, 46, W2, 2);
  n.fillStyle = 'rgba(255,220,150,0.5)'; n.fillRect(0, 48, W2, 1);
  const tr = n.createLinearGradient(0, 49, 0, 120);
  tr.addColorStop(0, 'rgba(255,214,140,0.16)'); tr.addColorStop(1, 'rgba(255,214,140,0)');
  n.fillStyle = tr; n.fillRect(0, 49, W2, 71);
  for (let x = 60; x < W2; x += 240) {                       // pendant fittings over the table
    n.fillStyle = '#2a1c0e'; n.fillRect(x, 48, 2, 14);
    n.fillStyle = '#c8a24c'; n.fillRect(x - 16, 62, 34, 5);
    n.fillStyle = '#ffe6b0'; n.fillRect(x - 14, 67, 30, 2);
    const g = n.createRadialGradient(x, 68, 0, x, 68, 54);
    g.addColorStop(0, 'rgba(255,220,150,0.22)'); g.addColorStop(1, 'rgba(255,220,150,0)');
    n.fillStyle = g; n.fillRect(x - 54, 14, 108, 108);
  }
  // the portrait wall: the board, in oils, looking down at the fight
  for (let x = 24; x < W2; x += 168) {
    const i = (x / 168) | 0, wide = i % 3 === 1;
    const fw = wide ? 68 : 54, fh = wide ? 48 : 56, fy = wide ? 70 : 64;
    artFrame(n, x, fy, fw, fh, R, r, ['#241624', '#1a2028', '#2a1c16'][i % 3]);
    const cx = x + fw / 2;
    n.fillStyle = 'rgba(28,18,28,0.85)';                     // a suggestion of a sitter in each
    n.beginPath(); n.ellipse(cx, fy + 18, 10, 12, 0, 0, 7); n.fill();
    n.fillRect(cx - 15, fy + 30, 30, fh - 30);
    n.fillStyle = 'rgba(210,190,220,0.15)'; n.beginPath(); n.ellipse(cx, fy + 16, 7, 9, 0, 0, 7); n.fill();
    if (i % 4 === 2) { n.fillStyle = 'rgba(230,214,200,0.20)'; n.fillRect(cx - 4, fy + 30, 8, 14); }  // a shirt front
    if (i % 5 === 3) { n.fillStyle = 'rgba(180,150,120,0.30)'; n.fillRect(cx - 10, fy + 8, 20, 6); }  // somebody's hair
    n.fillStyle = 'rgba(200,162,76,0.55)'; n.fillRect(cx - 13, fy + fh + 2, 26, 3);   // the brass plaque
  }
  // the table: the whole length of the scene, seen from slightly above
  n.fillStyle = '#1c1208'; n.fillRect(0, 118, W2, 30);
  const tg = n.createLinearGradient(0, 118, 0, 148);
  tg.addColorStop(0, '#5c3c1c'); tg.addColorStop(0.3, '#402810'); tg.addColorStop(1, '#2a1a0a');
  n.fillStyle = tg; n.fillRect(0, 118, W2, 30);
  n.fillStyle = '#7a5228'; n.fillRect(0, 118, W2, 3);
  for (let k = 0; k < W2 * 0.7; k++) {                       // figuring in the veneer
    n.fillStyle = R() < 0.5 ? 'rgba(0,0,0,0.16)' : 'rgba(255,208,150,0.07)';
    n.fillRect(r(0, W2), r(121, 146), 6 + R() * 18, 1);
  }
  for (let x = 60; x < W2; x += 240) {                       // the pendants reflected in it
    n.fillStyle = 'rgba(255,220,150,0.13)'; n.fillRect(x - 22, 120, 44, 26);
  }
  for (let x = 14; x < W2; x += 54) {                        // chairs down the far side
    n.fillStyle = '#16100a'; n.fillRect(x, 96, 26, 24);
    n.fillStyle = '#241708'; n.fillRect(x + 2, 98, 22, 20);
    n.fillStyle = '#3a2410'; n.fillRect(x + 2, 98, 22, 2);
    n.fillStyle = 'rgba(232,240,255,0.30)'; n.fillRect(x + 30, 112, 6, 7);  // a glass by each place
    n.fillStyle = 'rgba(255,255,255,0.35)'; n.fillRect(x + 31, 112, 1, 7);
    n.fillStyle = '#c8c0a8'; n.fillRect(x + 6, 114, 14, 5);                 // a folder
    n.fillStyle = '#8a1a2a'; n.fillRect(x + 6, 114, 14, 1);
  }
  // the head of the table: Dray's chair, empty, with the crest behind it
  const hx = Math.min(1150, len - 260);
  woodPanel(n, hx - 84, 48, 168, 72, R, r, '#2e1c10', '#4a2f18', '#1a0e06', 42);
  n.fillStyle = '#0e0a14'; n.fillRect(hx - 60, 54, 120, 62);
  n.fillStyle = '#c8a24c'; n.fillRect(hx - 62, 52, 124, 2); n.fillRect(hx - 62, 116, 124, 2);
  n.fillStyle = '#8a1a2a'; n.beginPath(); n.moveTo(hx, 58); n.lineTo(hx + 40, 82);
  n.lineTo(hx + 24, 116); n.lineTo(hx - 24, 116); n.lineTo(hx - 40, 82); n.fill();
  n.fillStyle = '#f2c94c'; n.beginPath(); n.moveTo(hx, 66); n.lineTo(hx + 30, 84);
  n.lineTo(hx + 18, 110); n.lineTo(hx - 18, 110); n.lineTo(hx - 30, 84); n.fill();
  n.fillStyle = '#8a1a2a'; n.fillRect(hx - 5, 78, 10, 26); n.fillRect(hx - 15, 86, 30, 8);
  n.fillStyle = '#100a06'; n.fillRect(hx - 22, 88, 44, 32);   // the high-backed chair
  n.fillStyle = '#1e1208'; n.fillRect(hx - 20, 90, 40, 28);
  n.fillStyle = '#c8a24c'; n.fillRect(hx - 20, 90, 40, 2);
  carpetFloor(n, LNear, R, r, FLOOR8, '#241626', 'rgba(190,150,110,0.10)', '#5a3a1c');
  n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(0, FLOOR8, W2, 12);   // the table's shadow on the carpet
  L.boardDust = true;
  return L;
}

// ---- B3  The Model Room ---------------------------------------------------
// Dray's collection floor. The city he bought, in miniature, under glass - and
// you walk the length of it past every place you have already fought through.
function s8b_model(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  f.fillStyle = '#080610'; f.fillRect(0, 0, W1, H);
  for (let k = 0; k < W1 * 0.4; k++) { f.fillStyle = 'rgba(200,170,110,0.13)'; f.fillRect(r(0, W1), r(40, 148), 1, 1); }
  // mid: a gallery wall - drawings, deeds and maps, lit from above
  m.fillStyle = '#120e1c'; m.fillRect(0, 34, WM, 116);
  m.fillStyle = '#1c1628'; m.fillRect(0, 34, WM, 4);
  for (let x = 0; x < WM; x += 134) {
    const h = 40 + ((x * 13) % 22), y = 52 + ((x * 7) % 10);
    m.fillStyle = '#4a3a18'; m.fillRect(x + 6, y - 2, 62, h + 4);
    m.fillStyle = '#6e6650'; m.fillRect(x + 9, y, 56, h);       // a drawing, not a painting - and kept dim
    m.fillStyle = 'rgba(30,26,20,0.55)';
    for (let k = 0; k < 16; k++) m.fillRect(x + 12 + R() * 48, y + 4 + R() * (h - 8), 2 + R() * 22, 1);
    m.fillStyle = 'rgba(140,26,42,0.35)'; m.fillRect(x + 12, y + h - 8, 14, 4);
    m.fillStyle = 'rgba(255,224,170,0.06)'; m.fillRect(x + 4, y - 6, 66, h + 10);
  }
  const LNear = { near: { width: W2 } };
  n.fillStyle = '#0e0b18'; n.fillRect(0, 34, W2, 12);
  for (let x = 0; x < W2; x += 92) {                          // track lighting the whole length
    n.fillStyle = '#211c30'; n.fillRect(x, 42, 76, 4);
    n.fillStyle = '#c8a24c'; n.fillRect(x + 10, 46, 8, 5); n.fillRect(x + 48, 46, 8, 5);
    for (const lx of [x + 14, x + 52]) {
      const g = n.createLinearGradient(0, 50, 0, 140);
      g.addColorStop(0, 'rgba(255,224,170,0.19)'); g.addColorStop(1, 'rgba(255,224,170,0)');
      n.fillStyle = g; n.beginPath(); n.moveTo(lx - 5, 50); n.lineTo(lx + 5, 50);
      n.lineTo(lx + 26, 140); n.lineTo(lx - 26, 140); n.fill();
    }
  }
  // the vitrines: seven cases, each holding a place from earlier in the game
  const CASES = [
    { t: 'UNDER THE EL', kind: 'el' }, { t: 'THE STRIP', kind: 'neon' },
    { t: 'TOWER SITE', kind: 'frame' }, { t: 'RAIL YARD', kind: 'yard' },
    { t: 'THE INTERCHANGE', kind: 'road' }, { t: 'THE WORKS', kind: 'works' },
    { t: 'SITE 7', kind: 'lab' },
  ];
  for (let i = 0; i < 9; i++) {
    const cx = 90 + i * 180, c = CASES[i % CASES.length];
    if (cx > W2 - 40) break;
    n.fillStyle = '#17121f'; n.fillRect(cx - 62, 112, 124, 36);          // the plinth
    n.fillStyle = '#241d30'; n.fillRect(cx - 62, 112, 124, 3);
    n.fillStyle = '#c8a24c'; n.fillRect(cx - 62, 115, 124, 1);
    n.fillStyle = 'rgba(200,162,76,0.45)'; n.fillRect(cx - 26, 128, 52, 4);
    n.fillStyle = '#0e0b18'; n.fillRect(cx - 24, 129, 48, 2);
    n.fillStyle = '#0c0a14'; n.fillRect(cx - 58, 62, 116, 50);           // the case interior
    modelCity(n, cx, 62, 116, 50, c.kind, R, r);
    n.fillStyle = 'rgba(170,210,255,0.08)'; n.fillRect(cx - 58, 62, 116, 50);   // the glass over it
    n.fillStyle = 'rgba(210,235,255,0.10)';
    n.beginPath(); n.moveTo(cx - 58, 112); n.lineTo(cx - 14, 62); n.lineTo(cx + 2, 62); n.lineTo(cx - 42, 112); n.fill();
    n.fillStyle = '#3a3350'; n.fillRect(cx - 61, 59, 122, 4);
    n.fillStyle = '#4e4668'; n.fillRect(cx - 61, 59, 122, 1);
    n.fillStyle = '#3a3350'; n.fillRect(cx - 61, 62, 3, 50); n.fillRect(cx + 58, 62, 3, 50);
  }
  // the centrepiece: the tower itself, taller than the rest, lit gold
  const tx = Math.min(1060, len - 320);
  n.fillStyle = '#1a1424'; n.fillRect(tx - 46, 100, 92, 48);
  n.fillStyle = '#292038'; n.fillRect(tx - 46, 100, 92, 3);
  n.fillStyle = '#f2c94c'; n.fillRect(tx - 46, 103, 92, 1);
  n.fillStyle = '#0b0912'; n.fillRect(tx - 40, 48, 80, 52);
  for (let k = 0; k < 5; k++) {                                        // the model tower stepping up
    const tw2 = 30 - k * 4;
    n.fillStyle = k === 4 ? '#c8a24c' : '#4a4266';
    n.fillRect(tx - tw2 / 2, 96 - k * 11, tw2, 11);
    n.fillStyle = k === 4 ? '#f2d878' : '#5e5480'; n.fillRect(tx - tw2 / 2, 96 - k * 11, tw2, 2);
    n.fillStyle = 'rgba(0,0,0,0.3)'; n.fillRect(tx + tw2 / 2 - 4, 96 - k * 11, 4, 11);
  }
  n.fillStyle = '#ff3a3a'; n.fillRect(tx - 1, 38, 3, 3);
  const tg = n.createRadialGradient(tx, 70, 0, tx, 70, 64);
  tg.addColorStop(0, 'rgba(242,201,76,0.22)'); tg.addColorStop(1, 'rgba(242,201,76,0)');
  n.fillStyle = tg; n.fillRect(tx - 64, 34, 128, 114);
  n.fillStyle = 'rgba(170,210,255,0.07)'; n.fillRect(tx - 40, 48, 80, 52);
  n.fillStyle = '#f2c94c'; n.fillRect(tx - 34, 126, 68, 6);
  ptext(n, 'PHASE TWO', tx - 30, 127, '#0e0b18');
  stoneFloor(n, LNear, R, r, FLOOR8, '#191426', 'rgba(150,130,180,0.08)', '#2a2140', 70);
  for (let i = 0; i < 9; i++) {                                        // each case glowing onto the floor
    const cx = 90 + i * 180; if (cx > W2 - 40) break;
    const g = n.createLinearGradient(0, FLOOR8, 0, 220);
    g.addColorStop(0, 'rgba(170,210,255,0.09)'); g.addColorStop(1, 'rgba(170,210,255,0)');
    n.fillStyle = g; n.fillRect(cx - 62, FLOOR8, 124, 72);
  }
  n.fillStyle = '#c8a24c'; n.fillRect(0, FLOOR8, W2, 1);
  L.caseGlint = true;
  return L;
}
// The contents of one vitrine: a little piece of a place you have been.
function modelCity(g, cx, y, w, h, kind, R, r) {
  const base = y + h - 6;
  g.fillStyle = '#15121e'; g.fillRect(cx - w / 2 + 3, base, w - 6, 6);
  if (kind === 'el') {
    for (let x = cx - w / 2 + 6; x < cx + w / 2 - 6; x += 9) {
      const bh = 10 + ((x * 7) % 18);
      g.fillStyle = '#3a3450'; g.fillRect(x, base - bh, 8, bh);
      for (let k = 0; k < 3; k++) { g.fillStyle = 'rgba(242,201,76,0.6)'; g.fillRect(x + 2 + (k % 2) * 4, base - bh + 3 + k * 5, 1, 1); }
    }
    g.fillStyle = '#5a4e30'; g.fillRect(cx - w / 2 + 4, base - 24, w - 8, 3);   // the viaduct
    for (let x = cx - w / 2 + 8; x < cx + w / 2 - 6; x += 16) g.fillRect(x, base - 21, 3, 21);
  } else if (kind === 'neon') {
    for (let x = cx - w / 2 + 6; x < cx + w / 2 - 6; x += 11) {
      const bh = 12 + ((x * 11) % 22);
      g.fillStyle = '#332c48'; g.fillRect(x, base - bh, 10, bh);
      g.fillStyle = ['#e8283a', '#4ac0e8', '#c86aff'][((x / 11) | 0) % 3];
      g.fillRect(x + 1, base - bh + 3, 8, 2); g.fillRect(x + 3, base - bh + 8, 2, 6);
    }
  } else if (kind === 'frame') {
    for (let k = 0; k < 6; k++) { g.fillStyle = '#5a5060'; g.fillRect(cx - 22 + k * 9, base - 34, 3, 34); }
    for (let k = 0; k < 5; k++) { g.fillStyle = '#4a4250'; g.fillRect(cx - 24, base - 32 + k * 7, 50, 2); }
    g.fillStyle = '#e8a030'; g.fillRect(cx + 26, base - 42, 3, 42);              // the crane
    g.fillStyle = '#e8a030'; g.fillRect(cx - 4, base - 42, 34, 2);
  } else if (kind === 'yard') {
    for (let k = 0; k < 4; k++) { g.fillStyle = '#2e2a3a'; g.fillRect(cx - w / 2 + 6, base - 6 - k * 7, w - 12, 2); }
    for (let x = cx - 30; x < cx + 26; x += 14) { g.fillStyle = '#4a4258'; g.fillRect(x, base - 20, 12, 8); }
    g.fillStyle = '#8a3030'; g.fillRect(cx - 34, base - 21, 18, 9);
  } else if (kind === 'road') {
    g.strokeStyle = '#4a4458'; g.lineWidth = 4;
    g.beginPath(); g.moveTo(cx - w / 2 + 4, base - 8); g.quadraticCurveTo(cx, base - 34, cx + w / 2 - 4, base - 12); g.stroke();
    g.strokeStyle = '#3a3448'; g.lineWidth = 3;
    g.beginPath(); g.moveTo(cx - w / 2 + 4, base - 22); g.quadraticCurveTo(cx + 6, base - 4, cx + w / 2 - 4, base - 26); g.stroke();
    for (let k = 0; k < 7; k++) { g.fillStyle = 'rgba(248,170,80,0.7)'; g.fillRect(cx - 24 + k * 8, base - 14 - (k % 3) * 5, 2, 1); }
  } else if (kind === 'works') {
    g.fillStyle = '#332c3a'; g.fillRect(cx - w / 2 + 6, base - 22, w - 12, 22);
    for (let k = 0; k < 3; k++) { g.fillStyle = '#2a2430'; g.fillRect(cx - 26 + k * 20, base - 34, 9, 12); }
    g.fillStyle = 'rgba(232,120,40,0.65)'; g.fillRect(cx - 20, base - 12, 40, 4);
    for (let k = 0; k < 3; k++) { g.fillStyle = 'rgba(255,160,60,0.45)'; g.fillRect(cx - 24 + k * 20, base - 38, 5, 5); }
  } else {
    g.fillStyle = '#20263a'; g.fillRect(cx - w / 2 + 6, base - 26, w - 12, 26);
    for (let k = 0; k < 6; k++) { g.fillStyle = 'rgba(90,208,180,0.55)'; g.fillRect(cx - 26 + k * 10, base - 22, 5, 14); }
    g.fillStyle = '#2e3850'; g.fillRect(cx - w / 2 + 6, base - 28, w - 12, 3);
  }
}

// ---- B4  The Sky Lounge ---------------------------------------------------
// The wildcard: not an office at all. The private floor - a bar, a pool, a
// piano, and the inner circle drinking while the city goes down.
function s8b_lounge(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  f.fillStyle = '#0a0614'; f.fillRect(0, 0, W1, H);
  for (let k = 0; k < W1 * 0.9; k++) {
    f.fillStyle = R() < 0.55 ? 'rgba(232,196,104,0.6)' : 'rgba(200,106,255,0.4)';
    f.fillRect(r(0, W1), r(52, 150), 1, 1);
  }
  // mid: floor-to-ceiling glass, no transoms - nothing between you and the drop
  curtainWall(m, { near: { width: WM } }, 0, WM, 36, 112, R, r, { bay: 110, frame: '#241a30', hi: '#463358', transom: false });
  m.fillStyle = 'rgba(200,106,255,0.05)'; m.fillRect(0, 36, WM, 112);
  const LNear = { near: { width: W2 } };
  // near: a dropped ceiling with a cove that washes the whole room purple
  n.fillStyle = '#150e20'; n.fillRect(0, 34, W2, 16);
  n.fillStyle = '#2a1c3e'; n.fillRect(0, 48, W2, 3);
  n.fillStyle = '#c86aff'; n.fillRect(0, 51, W2, 1);
  const cove = n.createLinearGradient(0, 52, 0, 132);
  cove.addColorStop(0, 'rgba(200,106,255,0.16)'); cove.addColorStop(1, 'rgba(200,106,255,0)');
  n.fillStyle = cove; n.fillRect(0, 52, W2, 80);
  for (let x = 44; x < W2; x += 156) {                        // hanging globes
    n.fillStyle = '#2a1c3e'; n.fillRect(x, 52, 1, 16);
    n.fillStyle = '#ffd8a0'; n.beginPath(); n.arc(x, 72, 5, 0, 7); n.fill();
    const g = n.createRadialGradient(x, 72, 0, x, 72, 40);
    g.addColorStop(0, 'rgba(255,216,160,0.26)'); g.addColorStop(1, 'rgba(255,216,160,0)');
    n.fillStyle = g; n.fillRect(x - 40, 32, 80, 80);
  }
  // the back bar: bottles lit from behind, the whole early length
  n.fillStyle = '#1a1026'; n.fillRect(0, 76, 520, 46);
  n.fillStyle = '#2a1a3c'; n.fillRect(0, 76, 520, 3);
  for (let sh = 0; sh < 3; sh++) {                            // three shelves, each its own stock
    const sy = 92 + sh * 12;
    n.fillStyle = '#2a1a3c'; n.fillRect(0, sy + 9, 520, 2);
    for (let x = 6; x < 514; x += 6 + (sh % 2)) {
      if (((x * 13 + sh * 7) % 17) < 3) continue;             // gaps, where somebody took one
      const bh = 6 + ((x * 5 + sh * 11) % 7);
      n.fillStyle = ['rgba(232,196,104,0.80)', 'rgba(90,208,180,0.65)', 'rgba(232,58,74,0.62)',
                     'rgba(200,106,255,0.62)', 'rgba(240,240,255,0.55)'][((x / 6 + sh) | 0) % 5];
      n.fillRect(x, sy + 9 - bh, 4, bh);
      n.fillStyle = 'rgba(255,255,255,0.38)'; n.fillRect(x, sy + 9 - bh, 1, bh);
    }
  }
  n.fillStyle = 'rgba(255,240,200,0.10)'; n.fillRect(0, 78, 520, 42);
  n.fillStyle = '#2e1e40'; n.fillRect(0, 118, 520, 4);
  n.fillStyle = '#c8a24c'; n.fillRect(0, 118, 520, 1);
  n.fillStyle = '#231631'; n.fillRect(0, 122, 520, 26);       // the bar counter
  n.fillStyle = '#3a2650'; n.fillRect(0, 122, 520, 3);
  for (let x = 30; x < 500; x += 62) {                        // stools, glasses left on the top
    n.fillStyle = '#1a1024'; n.fillRect(x, 130, 4, 18);
    n.fillStyle = '#2e1e40'; n.fillRect(x - 7, 126, 18, 5);
    n.fillStyle = 'rgba(232,240,255,0.32)'; n.fillRect(x + 20, 114, 6, 8);
    n.fillStyle = 'rgba(242,201,76,0.45)'; n.fillRect(x + 20, 118, 6, 4);
  }
  // the pool: a lit lane of water along the back, mid-scene
  const px0 = 600, pw = 300;
  n.fillStyle = '#0a1e2a'; n.fillRect(px0, 104, pw, 44);
  const wg = n.createLinearGradient(0, 104, 0, 148);
  wg.addColorStop(0, 'rgba(74,192,232,0.42)'); wg.addColorStop(1, 'rgba(20,90,140,0.7)');
  n.fillStyle = wg; n.fillRect(px0, 104, pw, 44);
  for (let k = 0; k < pw * 0.7; k++) { n.fillStyle = 'rgba(200,244,255,0.18)'; n.fillRect(r(px0, px0 + pw), r(106, 146), 5 + R() * 11, 1); }
  for (let x = px0 + 24; x < px0 + pw; x += 60) {             // underwater lights
    const g = n.createRadialGradient(x, 132, 0, x, 132, 26);
    g.addColorStop(0, 'rgba(160,240,255,0.32)'); g.addColorStop(1, 'rgba(160,240,255,0)');
    n.fillStyle = g; n.fillRect(x - 26, 106, 52, 42);
  }
  n.fillStyle = '#3a3048'; n.fillRect(px0 - 5, 100, pw + 10, 5);
  n.fillStyle = '#54486a'; n.fillRect(px0 - 5, 100, pw + 10, 1);
  n.fillStyle = '#3a3048'; n.fillRect(px0 - 5, 144, pw + 10, 4);
  for (let x = px0 + 10; x < px0 + pw; x += 74) {             // loungers standing on the pool surround
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x - 2, 99, 36, 2);
    n.fillStyle = '#2a2436'; n.fillRect(x + 3, 92, 3, 8); n.fillRect(x + 25, 92, 3, 8);
    n.fillStyle = '#d8d2c0'; n.fillRect(x, 88, 31, 5);
    n.fillStyle = '#efe9d8'; n.fillRect(x, 88, 31, 2);
    n.fillStyle = '#c8c0aa'; n.beginPath();                    // the raised back
    n.moveTo(x + 22, 88); n.lineTo(x + 32, 76); n.lineTo(x + 36, 79); n.lineTo(x + 30, 90); n.fill();
    n.fillStyle = 'rgba(232,240,255,0.30)'; n.fillRect(x + 38, 82, 5, 7);   // a glass on the deck beside it
  }
  // the piano, late in the scene, with a spot on it
  const gx = Math.min(1060, len - 300);
  n.fillStyle = '#0d0a14'; n.fillRect(gx - 4, 104, 128, 44);
  n.fillStyle = '#171020'; n.beginPath();
  n.moveTo(gx, 124); n.lineTo(gx + 96, 112); n.lineTo(gx + 124, 124); n.lineTo(gx + 110, 140); n.lineTo(gx + 8, 140); n.fill();
  n.fillStyle = '#2a2038'; n.beginPath();
  n.moveTo(gx, 124); n.lineTo(gx + 96, 112); n.lineTo(gx + 100, 116); n.lineTo(gx + 4, 128); n.fill();
  n.fillStyle = '#100b18'; n.beginPath();                      // the raised lid
  n.moveTo(gx + 14, 112); n.lineTo(gx + 92, 84); n.lineTo(gx + 104, 92); n.lineTo(gx + 30, 118); n.fill();
  n.fillStyle = '#2e2440'; n.beginPath();
  n.moveTo(gx + 14, 112); n.lineTo(gx + 92, 84); n.lineTo(gx + 95, 87); n.lineTo(gx + 18, 115); n.fill();
  n.fillStyle = '#e8e4f0'; n.fillRect(gx + 10, 126, 60, 5);    // keys
  for (let k = 0; k < 14; k++) { n.fillStyle = '#100b18'; n.fillRect(gx + 13 + k * 4.2, 126, 2, 3); }
  const sg = n.createLinearGradient(0, 52, 0, 148);
  sg.addColorStop(0, 'rgba(255,224,170,0.16)'); sg.addColorStop(1, 'rgba(255,224,170,0.02)');
  n.fillStyle = sg; n.beginPath(); n.moveTo(gx + 50, 52); n.lineTo(gx + 70, 52);
  n.lineTo(gx + 124, 148); n.lineTo(gx - 6, 148); n.fill();
  stoneFloor(n, LNear, R, r, FLOOR8, '#1a1228', 'rgba(200,150,220,0.08)', '#2c1e42', 58);
  const pg = n.createLinearGradient(0, FLOOR8, 0, 230);
  pg.addColorStop(0, 'rgba(74,192,232,0.13)'); pg.addColorStop(1, 'rgba(74,192,232,0)');
  n.fillStyle = pg; n.fillRect(px0 - 20, FLOOR8, pw + 40, 82);
  n.fillStyle = '#c86aff'; n.fillRect(0, FLOOR8, W2, 1);
  L.poolCaustics = true; L.loungeHum = true;
  return L;
}
