// ============================================================ STAGE 5-A options
// The approach to the highway. No hazards in this scene - but five separate
// car events drive through it, so every option needs a lane for traffic.

function asphalt(n, L, R, r, top, a, b, c, opts = {}) {
  n.fillStyle = a; n.fillRect(0, top, L.near.width, 240 - top);
  for (let k = 0; k < L.near.width * 1.5; k++) { n.fillStyle = R() < 0.5 ? b : c;
    n.fillRect(r(0, L.near.width), r(top + 1, 240), 3, 1); }
  for (let k = 0; k < L.near.width / 170; k++) {                      // patched repairs
    n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(r(0, L.near.width), r(top + 4, 232), 34 + R() * 60, 9 + R() * 12); }
  for (const ty of [top + 26, top + 62]) for (let x = 0; x < L.near.width; x += 2) {
    if (R() < 0.5) { n.fillStyle = 'rgba(255,255,255,0.025)'; n.fillRect(x, ty, 2, 6); }
  }
  n.fillStyle = opts.edge || '#3a3a44'; n.fillRect(0, top, L.near.width, 2);
}
function laneMarks(n, L, ys, col = '#e8e4c8', dash = 28, gap = 26) {
  for (const ly of ys) for (let x = 0; x < L.near.width; x += dash + gap) { n.fillStyle = col; n.fillRect(x, ly, dash, 3); }
}
function guardrail(n, L, R, y, opts = {}) {
  n.fillStyle = opts.dark || '#3a3e48'; n.fillRect(0, y + 6, L.near.width, 4);
  n.fillStyle = '#8a8e9a'; n.fillRect(0, y, L.near.width, 7);
  n.fillStyle = '#c8ccd8'; n.fillRect(0, y, L.near.width, 2);
  n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(0, y + 5, L.near.width, 2);
  for (let x = 0; x < L.near.width; x += 34) {
    n.fillStyle = '#4a4e5a'; n.fillRect(x, y + 7, 5, 15);
    if (R() < 0.07) { n.fillStyle = '#6a6e7a'; n.fillRect(x - 6, y - 2, 20, 10); }   // a bent length
  }
  for (let x = 12; x < L.near.width; x += 68) { n.fillStyle = '#e8342a'; n.fillRect(x, y + 1, 3, 3); }  // reflectors
}

// ---- A1: THE INTERCHANGE --------------------------------------------------
function s5a_interchange(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  nightSky(f, L, R, r, '#06040e', '#181038', '#4a2050');
  skyline(f, L, R, r, 124, '#0e0a20', '#d8b050', 22, 68);
  // mid: the ramps of the interchange, curving away at two levels
  m.strokeStyle = '#241c34'; m.lineWidth = 16;
  m.beginPath(); m.moveTo(-20, 118); m.quadraticCurveTo(L.mid.width * 0.4, 52, L.mid.width + 20, 92); m.stroke();
  m.strokeStyle = '#2f2644'; m.lineWidth = 3;
  m.beginPath(); m.moveTo(-20, 111); m.quadraticCurveTo(L.mid.width * 0.4, 45, L.mid.width + 20, 85); m.stroke();
  for (let x = 0; x < L.mid.width; x += 116) {                        // the piers holding it up
    const yy = 118 - Math.sin((x / L.mid.width) * Math.PI) * 56;
    m.fillStyle = '#1e1830'; m.fillRect(x, yy + 8, 16, 150 - yy);
    m.fillStyle = '#28203c'; m.fillRect(x + 2, yy + 8, 5, 150 - yy);
  }
  for (let x = 40; x < L.mid.width; x += 190) {                       // lamps along the ramp
    const yy = 118 - Math.sin((x / L.mid.width) * Math.PI) * 56;
    m.fillStyle = '#14101e'; m.fillRect(x, yy - 28, 3, 28); m.fillRect(x, yy - 28, 16, 3);
    m.fillStyle = '#ffe8a0'; m.fillRect(x + 11, yy - 25, 7, 3);
  }
  // near: sound wall, gantries, guardrail, then the carriageway
  for (let x = 0; x < L.near.width; x += 46) {
    n.fillStyle = (Math.round(x / 46) % 2) ? '#221c34' : '#1c1730'; n.fillRect(x, 86, 46, 48);
    n.fillStyle = 'rgba(255,255,255,0.05)'; n.fillRect(x, 86, 46, 2);
    n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x + 44, 86, 2, 48);
  }
  for (let x = 60; x < L.near.width; x += 420) graffiti(n, x, 116, R, 90);
  // sign gantry with a real exit board on it
  for (let x = 220; x < L.near.width; x += 560) {
    n.fillStyle = '#16141c'; n.fillRect(x, 40, 300, 7);
    for (let k = 0; k < 300; k += 20) { n.strokeStyle = '#16141c'; n.lineWidth = 2;
      n.beginPath(); n.moveTo(x + k, 47); n.lineTo(x + k + 10, 60); n.lineTo(x + k + 20, 47); n.stroke(); }
    n.fillStyle = '#16141c'; n.fillRect(x - 5, 40, 9, 94); n.fillRect(x + 296, 40, 9, 94);
    n.fillStyle = '#1a5a34'; n.fillRect(x + 40, 56, 130, 40);
    n.fillStyle = '#2a7a4a'; n.fillRect(x + 40, 56, 130, 2);
    ptext(n, 'EXIT 14', x + 52, 62, '#e8f0e8', 1);
    ptext(n, 'DOCKS', x + 52, 74, '#e8f0e8', 1);
    n.fillStyle = '#e8f0e8'; n.fillRect(x + 140, 66, 18, 4);
    n.beginPath(); n.moveTo(x + 158, 60); n.lineTo(x + 170, 68); n.lineTo(x + 158, 76); n.fill();
    n.fillStyle = '#1a3a7a'; n.fillRect(x + 186, 56, 92, 40);
    ptext(n, 'CITY', x + 200, 62, '#e8f0e8', 1);
    ptext(n, 'CENTRE', x + 196, 74, '#e8f0e8', 1);
    for (let k = 0; k < 4; k++) { n.fillStyle = '#fff4c0'; n.fillRect(x + 60 + k * 62, 50, 9, 3);
      n.fillStyle = 'rgba(255,244,192,0.08)'; n.fillRect(x + 50 + k * 62, 53, 30, 46); }
  }
  for (let x = 90; x < L.near.width; x += 210) {                      // lamp columns
    n.fillStyle = '#14101e'; n.fillRect(x, 48, 5, 86);
    n.beginPath(); n.moveTo(x, 48); n.quadraticCurveTo(x + 4, 40, x + 18, 42);
    n.lineWidth = 4; n.strokeStyle = '#14101e'; n.stroke();
    n.fillStyle = '#ffe8a0'; n.fillRect(x + 16, 41, 11, 4);
    n.fillStyle = 'rgba(255,232,160,0.09)';
    n.beginPath(); n.moveTo(x + 16, 45); n.lineTo(x - 16, 240); n.lineTo(x + 58, 240); n.lineTo(x + 27, 45); n.fill();
  }
  guardrail(n, L, R, 134);
  asphalt(n, L, R, r, 150, '#26262c', '#2e2e36', '#1e1e24');
  laneMarks(n, L, [188, 220]);
  n.fillStyle = '#e8c020'; n.fillRect(0, 236, L.near.width, 3);
  n.fillStyle = '#e8e4c8'; n.fillRect(0, 152, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 30) { n.fillStyle = '#e8342a'; n.fillRect(x, 150, 3, 2); }
  // a broken-down car on the hard shoulder, cones and a closed lane
  for (let x = 380; x < L.near.width - 200; x += 900) {
    parkedCar(n, x, 178, R, '#5a5a64');
    n.fillStyle = '#e8b020'; n.fillRect(x - 36, 162, 5, 5); n.fillRect(x + 32, 162, 5, 5);
    for (let k = 0; k < 6; k++) { const cx = x + 44 + k * 26;
      n.fillStyle = '#e88a20'; n.beginPath(); n.moveTo(cx - 6, 180); n.lineTo(cx, 164); n.lineTo(cx + 6, 180); n.fill();
      n.fillStyle = '#fff'; n.fillRect(cx - 3, 170, 6, 3); }
  }
}

// ---- A2: THE TOLL PLAZA ---------------------------------------------------
function s5a_toll(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  nightSky(f, L, R, r, '#05040f', '#14102e', '#3c1e46');
  skyline(f, L, R, r, 118, '#0c0a1c', '#c8a048', 18, 52);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 60) {                          // the queue of traffic beyond
    if (R() < 0.6) { const c = pick2(R, ['#5a2a30', '#2a4a6a', '#3a3a42', '#6a6a58']);
      m.fillStyle = '#0e0c14'; m.fillRect(x, 118, 48, 16);
      m.fillStyle = c; m.fillRect(x + 1, 119, 46, 14);
      m.fillStyle = '#c83030'; m.fillRect(x + 1, 124, 5, 4); m.fillRect(x + 42, 124, 5, 4);
      m.fillStyle = 'rgba(200,60,60,0.14)'; m.fillRect(x - 6, 120, 60, 14); }
  }
  // near: the canopy over the plaza, then booth after booth
  n.fillStyle = '#1e222c'; n.fillRect(0, 36, L.near.width, 26);
  n.fillStyle = '#2b313d'; n.fillRect(0, 36, L.near.width, 4);
  n.fillStyle = 'rgba(0,0,0,0.42)'; n.fillRect(0, 62, L.near.width, 6);
  for (let x = 0; x < L.near.width; x += 18) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(x, 40, 4, 22); }
  let x = 0, bi = 0;
  while (x < len - 300) {
    const bw = 118;
    // the lane signal hanging off the canopy: green arrow or red cross
    const open = bi % 3 !== 1;
    n.fillStyle = '#12141a'; n.fillRect(x + 30, 66, 34, 30);
    n.fillStyle = '#080a0e'; n.fillRect(x + 33, 69, 28, 24);
    if (open) { n.save(); n.shadowColor = '#3ae05a'; n.shadowBlur = 8; n.fillStyle = '#3ae05a';
      n.fillRect(x + 45, 74, 5, 9);
      n.beginPath(); n.moveTo(x + 40, 83); n.lineTo(x + 47.5, 91); n.lineTo(x + 55, 83); n.fill(); n.restore(); }
    else { n.save(); n.shadowColor = '#e02a3a'; n.shadowBlur = 8; n.fillStyle = '#e02a3a';
      n.save(); n.translate(x + 47, 81); n.rotate(0.78); n.fillRect(-11, -2.5, 22, 5); n.fillRect(-2.5, -11, 5, 22); n.restore();
      n.restore(); }
    // the booth: a glass box on an island, with somebody in it
    n.fillStyle = '#16181f'; n.fillRect(x, 96, 40, 52);
    n.fillStyle = '#c8cad2'; n.fillRect(x + 2, 98, 36, 48);
    n.fillStyle = '#1e2a3a'; n.fillRect(x + 5, 102, 30, 24);
    n.fillStyle = 'rgba(190,225,255,0.30)'; n.fillRect(x + 6, 103, 12, 22);
    if (open) { n.fillStyle = 'rgba(0,0,0,0.55)'; n.fillRect(x + 20, 110, 8, 16);
      n.beginPath(); n.arc(x + 24, 108, 4, 0, 7); n.fill(); }
    n.fillStyle = '#e8c020'; n.fillRect(x + 2, 140, 36, 6);
    for (let k = 0; k < 36; k += 10) { n.fillStyle = '#1a1a1e'; n.fillRect(x + 2 + k, 140, 5, 6); }
    n.fillStyle = '#16181f'; n.fillRect(x - 4, 146, 48, 4);
    ptext(n, open ? 'CASH' : 'CLOSED', x + 6, 130, open ? '#1a2a1a' : '#6a1a1a', 1);
    // the barrier arm across the lane
    n.fillStyle = '#39414e'; n.fillRect(x + 40, 116, 6, 14);
    if (open) { n.fillStyle = '#39414e'; n.fillRect(x + 43, 112, 4, 24); }
    else { for (let k = 0; k < 66; k += 11) { n.fillStyle = (Math.round(k / 11) % 2) ? '#e8342a' : '#e8e8e0';
      n.fillRect(x + 46 + k, 122, 11, 6); } }
    x += bw; bi++;
  }
  // the admin building at the end: the arena
  const a0 = len - 300;
  n.fillStyle = '#16181f'; n.fillRect(a0, 60, L.near.width - a0, 88);
  n.fillStyle = '#3a4250'; n.fillRect(a0 + 10, 66, L.near.width - a0 - 20, 82);
  for (let k = a0 + 20; k < L.near.width - 20; k += 40) { n.fillStyle = '#1e2a3a'; n.fillRect(k, 78, 26, 24);
    n.fillStyle = R() < 0.5 ? '#e8c860' : '#26303e'; n.fillRect(k + 1, 79, 24, 22); }
  n.fillStyle = '#e8c020'; n.fillRect(a0 + 10, 62, L.near.width - a0 - 20, 6);
  ptext(n, 'HARBOUR TOLL AUTHORITY', a0 + 40, 108, '#c8ccd8', 1);
  asphalt(n, L, R, r, 150, '#2a2a30', '#32323a', '#222228');
  // the lane channels: painted islands, arrows and worn stop lines
  for (let px_ = 0; px_ < L.near.width; px_ += 118) {
    n.fillStyle = 'rgba(232,232,224,0.55)'; n.fillRect(px_ + 44, 150, 4, 90);
    n.fillStyle = 'rgba(232,200,60,0.40)'; n.fillRect(px_ + 50, 150, 3, 90);
    n.fillStyle = 'rgba(232,232,224,0.45)'; n.fillRect(px_ + 60, 196, 44, 4);
    n.fillStyle = 'rgba(232,232,224,0.35)';
    n.beginPath(); n.moveTo(px_ + 78, 218); n.lineTo(px_ + 86, 206); n.lineTo(px_ + 94, 218); n.fill();
    n.fillRect(px_ + 83, 216, 6, 14);
  }
  for (let k = 0; k < L.near.width / 200; k++) { n.fillStyle = 'rgba(0,0,0,0.26)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(180, 232), 14 + R() * 16, 4 + R() * 4, 0, 0, 7); n.fill(); }
}

// ---- A3: THE TUNNEL -------------------------------------------------------
function s5a_tunnel(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#07070a'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  // the opposite bore, seen through the piers between the carriageways
  for (let x = 0; x < L.mid.width; x += 56) {
    m.fillStyle = '#101218'; m.fillRect(x, 52, 44, 92);
    m.fillStyle = '#171a22'; m.fillRect(x + 4, 56, 36, 42);
    if (R() < 0.3) { m.fillStyle = '#e8c860'; m.fillRect(x + 12 + R() * 20, 104, 5, 3); }
  }
  // near: the bore. Tiled walls, a haunch above, and the sodium ribbon.
  n.fillStyle = '#14161c'; n.fillRect(0, 0, L.near.width, 150);
  n.fillStyle = '#1c2029'; n.fillRect(0, 34, L.near.width, 8);
  for (let ty = 42; ty < 128; ty += 11) for (let tx = 0; tx < L.near.width; tx += 15) {
    const t2 = R();
    n.fillStyle = t2 < 0.06 ? '#6a6e62' : t2 < 0.5 ? '#c3c7b8' : '#b7bcad';
    n.fillRect(tx, ty, 14, 10);
  }
  n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(0, 42, L.near.width, 86);
  for (let k = 0; k < L.near.width / 10; k++) { n.fillStyle = 'rgba(40,34,26,0.35)';   // grime up the tiles
    n.fillRect(r(0, L.near.width), r(96, 128), 12 + R() * 26, 6 + R() * 14); }
  n.fillStyle = '#2a2e36'; n.fillRect(0, 128, L.near.width, 8);
  n.fillStyle = '#3a404a'; n.fillRect(0, 128, L.near.width, 2);
  // the light ribbon, running the whole length just under the haunch
  n.fillStyle = '#1a1e26'; n.fillRect(0, 44, L.near.width, 9);
  for (let x = 0; x < L.near.width; x += 44) {
    const dead = R() < 0.08;
    n.fillStyle = dead ? '#3a3a40' : '#ffca6a'; n.fillRect(x + 3, 46, 36, 5);
    if (!dead) { n.fillStyle = 'rgba(255,202,106,0.10)'; n.fillRect(x - 6, 51, 56, 80); }
  }
  // ventilation fans and emergency niches let into the wall
  for (let x = 120; x < L.near.width; x += 300) {
    n.fillStyle = '#1a1e26'; n.fillRect(x, 56, 44, 44);
    n.fillStyle = '#242a34'; n.fillRect(x + 3, 59, 38, 38);
    n.fillStyle = '#12151b'; n.beginPath(); n.arc(x + 22, 78, 16, 0, 7); n.fill();
    for (let k = 0; k < 5; k++) { n.fillStyle = '#39414e'; n.save(); n.translate(x + 22, 78);
      n.rotate(k * 0.63); n.fillRect(-2, -15, 4, 30); n.restore(); }
    n.fillStyle = '#4a5260'; n.beginPath(); n.arc(x + 22, 78, 4, 0, 7); n.fill();
  }
  for (let x = 260; x < L.near.width; x += 300) {
    n.fillStyle = '#0e1016'; n.fillRect(x, 84, 30, 44);
    n.fillStyle = '#c8302a'; n.fillRect(x + 2, 86, 26, 14);
    ptext(n, 'SOS', x + 7, 89, '#f0e8e0', 1);
    n.fillStyle = '#2a2e36'; n.fillRect(x + 6, 104, 18, 22);
    n.fillStyle = '#e8c020'; n.fillRect(x + 9, 108, 12, 9);
  }
  // the service walkway along the wall, then the carriageway
  n.fillStyle = '#4a4e58'; n.fillRect(0, 136, L.near.width, 14);
  n.fillStyle = '#5a5f6a'; n.fillRect(0, 136, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 34) { n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x, 138, 2, 12); }
  n.fillStyle = '#c8b030'; n.fillRect(0, 148, L.near.width, 3);
  asphalt(n, L, R, r, 151, '#24242a', '#2c2c34', '#1c1c22');
  laneMarks(n, L, [190, 222], 'rgba(232,228,200,0.85)');
  n.fillStyle = 'rgba(255,202,106,0.05)'; n.fillRect(0, 151, L.near.width, 89);
  for (let x = 0; x < L.near.width; x += 40) { n.fillStyle = 'rgba(255,202,106,0.10)';
    n.beginPath(); n.ellipse(x, 186, 26, 30, 0, 0, 7); n.fill(); }
  L.tunnelHum = 1;
}

// ---- A4: THE STORM DRAIN --------------------------------------------------
// The wildcard: the chase drops into a concrete flood channel. Sloped walls,
// a trickle down the middle, graffiti end to end, bridges crossing over.
function s5a_drain(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  nightSky(f, L, R, r, '#06060f', '#161634', '#3e2a4a');
  skyline(f, L, R, r, 96, '#100e20', '#c8a048', 14, 44);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 9) {                          // chain-link along the top
    m.strokeStyle = 'rgba(150,155,175,0.22)'; m.lineWidth = 1;
    m.beginPath(); m.moveTo(x, 84); m.lineTo(x + 40, 124); m.stroke();
    m.beginPath(); m.moveTo(x, 84); m.lineTo(x - 40, 124); m.stroke();
  }
  for (let x = 0; x < L.mid.width; x += 90) { m.fillStyle = '#6a6a78'; m.fillRect(x, 80, 4, 46); }
  m.fillStyle = '#5a5f66'; m.fillRect(0, 124, L.mid.width, 6);
  // near: the channel. A sloped wall the full height, then the flat invert.
  const LIP = 58, TOE = 150;
  n.fillStyle = '#5c6068'; n.fillRect(0, LIP, L.near.width, 8);
  n.fillStyle = '#6e737c'; n.fillRect(0, LIP, L.near.width, 2);
  // the slope, drawn as banded courses so it reads as raked back
  for (let k = 0; k < 10; k++) {
    const y0 = LIP + 8 + k * ((TOE - LIP - 8) / 10);
    const t2 = k / 10;
    n.fillStyle = `rgb(${Math.round(92 - t2 * 26)},${Math.round(96 - t2 * 26)},${Math.round(104 - t2 * 28)})`;
    n.fillRect(0, y0, L.near.width, (TOE - LIP - 8) / 10 + 1);
  }
  for (let x = 0; x < L.near.width; x += 62) {                        // the expansion joints
    n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(x, LIP + 8, 2, TOE - LIP - 8);
    n.fillStyle = 'rgba(255,255,255,0.05)'; n.fillRect(x + 2, LIP + 8, 1, TOE - LIP - 8);
  }
  for (let k = 0; k < L.near.width / 9; k++) { n.fillStyle = 'rgba(0,0,0,0.10)';      // staining
    n.fillRect(r(0, L.near.width), r(LIP + 10, TOE), 8 + R() * 26, 4 + R() * 16); }
  // graffiti end to end - the whole point of a channel like this
  for (let x = 10; x < L.near.width; x += 90 + R() * 70) {
    const big = R() < 0.4;
    if (big) {
      const w2 = 90 + R() * 70, y0 = LIP + 26 + R() * 44;
      n.fillStyle = pick2(R, ['#e84a8a', '#4ae88a', '#e8e84a', '#8ab8ff', '#ff8a2a', '#c86aff']);
      n.globalAlpha = 0.85;
      for (let k = 0; k < 5; k++) { n.save(); n.translate(x + k * (w2 / 5), y0); n.rotate((R() - 0.5) * 0.3);
        n.fillRect(0, 0, w2 / 6, 26 + R() * 14); n.restore(); }
      n.globalAlpha = 1;
      n.fillStyle = 'rgba(0,0,0,0.45)';
      for (let k = 0; k < 5; k++) { n.save(); n.translate(x + 3 + k * (w2 / 5), y0 + 3); n.rotate((R() - 0.5) * 0.3);
        n.fillRect(0, 0, w2 / 6, 5); n.restore(); }
    } else graffiti(n, x, LIP + 30 + R() * 60, R, 50 + R() * 40);
  }
  // outfall pipes let into the slope, dribbling
  for (let x = 140; x < L.near.width; x += 340) {
    n.fillStyle = '#1e2026'; n.beginPath(); n.arc(x, TOE - 22, 17, Math.PI, 0); n.fill();
    n.fillRect(x - 17, TOE - 22, 34, 22);
    n.fillStyle = '#0e1014'; n.beginPath(); n.arc(x, TOE - 22, 13, Math.PI, 0); n.fill();
    n.fillRect(x - 13, TOE - 22, 26, 22);
    n.fillStyle = 'rgba(120,150,190,0.30)'; n.fillRect(x - 4, TOE - 12, 8, 14);
    n.fillStyle = 'rgba(120,150,190,0.20)';
    n.beginPath(); n.ellipse(x, TOE + 14, 22, 6, 0, 0, 7); n.fill();
  }
  // a road bridge crossing over, twice
  for (let x = 420; x < L.near.width - 200; x += 820) {
    n.fillStyle = '#20222a'; n.fillRect(x, 0, 150, 46);
    n.fillStyle = '#2c2f39'; n.fillRect(x, 40, 150, 8);
    n.fillStyle = '#3a3e48'; n.fillRect(x, 40, 150, 2);
    n.fillStyle = 'rgba(0,0,0,0.42)'; n.fillRect(x, 48, 150, 10);
    n.fillStyle = '#20222a'; n.fillRect(x - 10, 46, 22, TOE - 46); n.fillRect(x + 138, 46, 22, TOE - 46);
    graffiti(n, x + 20, 80, R, 100);
  }
  // the invert: the flat bottom you fight on, with the low-flow channel in it
  n.fillStyle = '#4e525a'; n.fillRect(0, TOE, L.near.width, 240 - TOE);
  for (let k = 0; k < L.near.width * 1.4; k++) { n.fillStyle = R() < 0.5 ? '#565a63' : '#44484f';
    n.fillRect(r(0, L.near.width), r(TOE + 2, 240), 3, 1); }
  for (let x = 0; x < L.near.width; x += 62) { n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x, TOE, 2, 240 - TOE); }
  n.fillStyle = '#3a3e46'; n.fillRect(0, TOE, L.near.width, 3);
  n.fillStyle = '#3e434b'; n.fillRect(0, 210, L.near.width, 22);
  n.fillStyle = 'rgba(120,150,190,0.30)'; n.fillRect(0, 214, L.near.width, 14);
  for (let k = 0; k < L.near.width / 4; k++) { n.fillStyle = 'rgba(190,215,240,0.16)';
    n.fillRect(r(0, L.near.width), 214 + R() * 14, 5 + R() * 10, 1); }
  for (let k = 0; k < L.near.width / 60; k++) {                       // silt and rubbish in the channel
    n.fillStyle = pick2(R, ['#5a5a4a', '#3a4a3a', '#6a5a4a']);
    n.fillRect(r(0, L.near.width), r(TOE + 6, 208), 8 + R() * 16, 4); }
  for (let k = 0; k < 16; k++) { n.fillStyle = '#2f4a2e';
    const wx = r(0, L.near.width); for (let b = 0; b < 3; b++) n.fillRect(wx + (R() - 0.5) * 6, 208 - b * 4, 3, 4); }
}
