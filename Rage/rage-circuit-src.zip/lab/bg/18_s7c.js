// ============================================================ 7-C options
// 1220 units, the falling hazard every 420 frames, and the Unit-9 capsule at
// x=700 - the breakable that decides the best ending. All four need honest
// structure overhead for things to fall off, and all four need a place at
// mid-scene where one object can be the obvious thing in the room.

// ---- C1: THE VAULT --------------------------------------------------------
// The name taken at its word: a buried strongroom. A door a metre thick stood
// open at the head of it, tiered racks of numbered cases running away, and one
// plinth under a downlight at the middle of the floor.
function s7c_vault(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#16161c'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 64) {                     // poured concrete, lift lines and all
    f.fillStyle = '#212128'; f.fillRect(x, 34, 58, 114);
    f.fillStyle = '#2e2e38'; f.fillRect(x, 34, 58, 2);
    f.fillStyle = 'rgba(0,0,0,0.22)'; f.fillRect(x + 58, 34, 6, 114);
    for (let k = 0; k < 5; k++) { f.fillStyle = 'rgba(0,0,0,0.26)'; f.fillRect(x + 6 + k * 11, 60, 3, 3); }
    for (let k = 0; k < 7; k++) { f.fillStyle = 'rgba(255,255,255,0.03)';
      f.fillRect(x + 4 + (k * 17) % 50, 40 + (k * 23) % 100, 12, 4); }
  }
  // mid: the deep racking, receding, every case numbered
  m.fillStyle = '#191921'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 74) {
    m.fillStyle = '#23232d'; m.fillRect(x, 44, 66, 104);
    for (let row = 0; row < 6; row++) {
      m.fillStyle = '#2e2e3a'; m.fillRect(x + 2, 48 + row * 17, 62, 3);
      for (let c = 0; c < 4; c++) {
        m.fillStyle = ((x + row + c) % 5) ? '#2a2a36' : '#34343f';
        m.fillRect(x + 4 + c * 15, 51 + row * 17, 13, 13);
        m.fillStyle = 'rgba(232,201,76,0.22)'; m.fillRect(x + 6 + c * 15, 54 + row * 17, 7, 1);
      }
    }
  }
  m.fillStyle = 'rgba(10,10,14,0.30)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  // near: the slab and the crane beam it all hangs off - the falling hazard
  ceilingSlab(n, L, 34, 16, '#141419', '#212129', '#0a0a0d');
  n.fillStyle = '#23232d'; n.fillRect(0, 50, W2, 11);             // the runway beam
  n.fillStyle = '#34343f'; n.fillRect(0, 50, W2, 3);
  n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(0, 59, W2, 3);
  for (let x = 0; x < W2; x += 46) {                              // the web of the beam
    n.strokeStyle = '#1c1c25'; n.lineWidth = 3;
    n.beginPath(); n.moveTo(x, 61); n.lineTo(x + 23, 74); n.lineTo(x + 46, 61); n.stroke();
  }
  n.fillStyle = '#1a1a22'; n.fillRect(0, 74, W2, 6);
  for (let x = 110; x < W2; x += 260) {                           // downlights hung off it
    n.fillStyle = '#26262f'; n.fillRect(x, 80, 18, 8);
    n.save(); n.shadowColor = '#f2c94c'; n.shadowBlur = 14; n.fillStyle = '#fff0c0';
    n.fillRect(x + 3, 87, 12, 3); n.restore();
    const lg = n.createLinearGradient(0, 90, 0, 150);
    lg.addColorStop(0, 'rgba(242,201,76,0.16)'); lg.addColorStop(1, 'rgba(242,201,76,0)');
    n.fillStyle = lg;
    n.beginPath(); n.moveTo(x - 2, 90); n.lineTo(x + 20, 90); n.lineTo(x + 46, 150); n.lineTo(x - 28, 150); n.fill();
    floorGlow(n, L, x + 9, LAB_TOP, 86, 'rgba(242,201,76,0.22)');
  }
  // the door: at the head of the scene, a metre of steel swung open
  n.fillStyle = '#0d0d11'; n.fillRect(0, 60, 168, 88);           // the opening, black beyond the frame
  n.fillStyle = '#2b2b35'; n.fillRect(0, 60, 22, 88);            // the jamb
  n.fillStyle = '#3d3d4a'; n.fillRect(0, 60, 22, 3);
  n.fillStyle = '#242430'; n.fillRect(0, 56, 176, 6);            // the head of the frame
  n.fillStyle = '#3d3d4a'; n.fillRect(0, 56, 176, 2);
  // the leaf itself: a metre of steel swung into the room
  const DX = 112, DY = 104, DR = 42;
  n.fillStyle = 'rgba(0,0,0,0.45)'; n.beginPath(); n.ellipse(DX + 6, DY + 4, DR, DR, 0, 0, 7); n.fill();
  const dg = n.createLinearGradient(DX - DR, DY - DR, DX + DR, DY + DR);
  dg.addColorStop(0, '#5a5a6a'); dg.addColorStop(0.45, '#3a3a48'); dg.addColorStop(1, '#22222c');
  n.fillStyle = dg; n.beginPath(); n.arc(DX, DY, DR, 0, 7); n.fill();
  n.strokeStyle = '#6a6a7c'; n.lineWidth = 2; n.beginPath(); n.arc(DX, DY, DR - 4, 0, 7); n.stroke();
  n.strokeStyle = '#1a1a22'; n.lineWidth = 2; n.beginPath(); n.arc(DX, DY, DR - 12, 0, 7); n.stroke();
  for (let k = 0; k < 12; k++) {                                  // the locking bolts round the rim
    const a = k * 0.524;
    n.fillStyle = '#6a6a7c'; n.fillRect(DX + Math.cos(a) * (DR - 8) - 2, DY + Math.sin(a) * (DR - 8) - 2, 5, 5);
  }
  n.strokeStyle = '#8a8a9c'; n.lineWidth = 3;                     // the handwheel
  n.beginPath(); n.arc(DX, DY, 15, 0, 7); n.stroke();
  for (let k = 0; k < 4; k++) {
    const a = k * 0.785 + 0.4;
    n.beginPath(); n.moveTo(DX, DY); n.lineTo(DX + Math.cos(a) * 15, DY + Math.sin(a) * 15); n.stroke();
  }
  n.fillStyle = '#9a9aac'; n.beginPath(); n.arc(DX, DY, 5, 0, 7); n.fill();
  n.fillStyle = '#1a1a22'; n.fillRect(DX + DR - 6, DY - 8, 14, 16);   // the hinge side, into the jamb
  hazardBand(n, 22, 138, 90, 10);
  ptext(n, 'VAULT', 40, 44, 'rgba(232,201,76,0.70)');
  for (let x = 160; x < W2; x += 132) {                           // the near racking you fight between
    n.fillStyle = '#101017'; n.fillRect(x, 84, 122, 64);
    n.fillStyle = '#1b1b24'; n.fillRect(x, 84, 122, 3);
    for (let row = 0; row < 3; row++) {
      n.fillStyle = '#1e1e28'; n.fillRect(x + 2, 88 + row * 20, 118, 4);
      for (let c = 0; c < 5; c++) {
        const empty = ((x / 132 | 0) + row + c) % 7 === 0;
        n.fillStyle = empty ? '#07070a' : '#191922';
        n.fillRect(x + 5 + c * 23, 92 + row * 20, 20, 16);
        if (!empty) {
          n.fillStyle = '#23232e'; n.fillRect(x + 5 + c * 23, 92 + row * 20, 20, 3);
          n.fillStyle = 'rgba(232,201,76,0.30)'; n.fillRect(x + 8 + c * 23, 97 + row * 20, 11, 2);
        }
      }
    }
    ptext(n, 'R' + String(10 + (x / 132 | 0)), x + 4, 78, 'rgba(180,170,140,0.45)');
    n.fillStyle = '#191921'; n.fillRect(x + 122, 80, 10, 68);
  }
  // the plinth at mid-scene: where the one capsule that matters sits
  const P = Math.min(700, len - 300);
  n.fillStyle = '#0b0b0f'; n.fillRect(P - 96, 62, 192, 86);
  n.fillStyle = '#1e1e27'; n.fillRect(P - 96, 62, 192, 3);
  n.fillStyle = '#1c1c25'; n.fillRect(P - 44, 128, 88, 20);       // the plinth
  n.fillStyle = '#33333f'; n.fillRect(P - 44, 128, 88, 3);
  hazardBand(n, P - 44, 142, 88, 6);
  const vc = n.createLinearGradient(P - 26, 74, P - 26, 128);     // the capsule standing on it
  vc.addColorStop(0, 'rgba(255,238,178,0.88)'); vc.addColorStop(0.5, 'rgba(226,176,58,0.78)');
  vc.addColorStop(1, 'rgba(78,52,12,0.82)');
  n.save(); n.shadowColor = '#f2c94c'; n.shadowBlur = 24;
  n.fillStyle = vc; n.fillRect(P - 26, 74, 52, 54); n.restore();
  n.fillStyle = 'rgba(18,12,4,0.55)';
  n.beginPath(); n.ellipse(P, 88, 9, 8, 0, 0, 7); n.fill();
  n.fillRect(P - 11, 95, 22, 22); n.fillRect(P - 19, 97, 7, 18); n.fillRect(P + 12, 97, 7, 18);
  n.fillStyle = 'rgba(255,255,255,0.16)'; n.fillRect(P - 23, 76, 5, 48);
  n.fillStyle = '#2b2b36'; n.fillRect(P - 32, 70, 64, 6);
  n.fillStyle = '#44444f'; n.fillRect(P - 32, 70, 64, 2);
  ptext(n, 'UNIT 9', P - tw('UNIT 9') / 2, 60, 'rgba(242,201,76,0.85)');
  floorGlow(n, L, P, LAB_TOP, 130, 'rgba(242,201,76,0.13)');
  epoxyFloor(n, L, R, r, LAB_TOP, '#1d1d24', 'rgba(170,158,120,0.16)', '#3a3a46');
  floorMark(n, 0, 198, W2, 32, 'rgba(232,201,76,0.22)');
  for (let x = 0; x < W2; x += 300) ptext(n, 'KEEP CLEAR', x + 50, 204, 'rgba(232,201,76,0.22)');
  n.fillStyle = 'rgba(0,0,0,0.18)'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  L.dustMotes = 1;
}

// ---- C2: THE CORE ---------------------------------------------------------
// The biggest thing in the game: a containment core going through the whole
// scene, ring-lit, with catwalks spiralling round it and coolant trunks feeding
// in. Everything else in the room is scale reference for it.
function s7c_core(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#05080f'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 58) {                     // the far shell of the chamber, curved
    const g = f.createLinearGradient(0, 34, 0, 148);
    g.addColorStop(0, '#0a1120'); g.addColorStop(0.6, '#16223c'); g.addColorStop(1, '#0a1120');
    f.fillStyle = g; f.fillRect(x, 34, 52, 114);
    f.fillStyle = 'rgba(80,150,230,0.10)'; f.fillRect(x, 84, 52, 3);
  }
  // mid: the core itself, one cylinder the whole length, banded and lit
  m.fillStyle = '#070c16'; m.fillRect(0, 34, L.mid.width, 114);
  const cg = m.createLinearGradient(0, 40, 0, 148);
  cg.addColorStop(0, '#16233a'); cg.addColorStop(0.24, '#41639a');
  cg.addColorStop(0.46, '#86b4e8'); cg.addColorStop(0.62, '#4e73aa');
  cg.addColorStop(0.82, '#26374f'); cg.addColorStop(1, '#0c1522');
  m.fillStyle = cg; m.fillRect(0, 40, L.mid.width, 108);
  for (let y = 46; y < 146; y += 24) {                            // the binding rings
    m.fillStyle = 'rgba(0,0,0,0.30)'; m.fillRect(0, y, L.mid.width, 5);
    m.fillStyle = 'rgba(180,220,255,0.16)'; m.fillRect(0, y, L.mid.width, 1);
  }
  for (let x = 0; x < L.mid.width; x += 116) {                    // the inspection ports, lit from within
    m.save(); m.shadowColor = '#7fc4ff'; m.shadowBlur = 12;
    m.fillStyle = '#bfe4ff'; m.beginPath(); m.arc(x + 30, 92, 8, 0, 7); m.fill(); m.restore();
    m.strokeStyle = '#26364f'; m.lineWidth = 3; m.beginPath(); m.arc(x + 30, 92, 12, 0, 7); m.stroke();
    ptext(m, 'S' + String(4 + (x / 116 | 0)), x + 52, 88, 'rgba(160,205,245,0.45)');
  }
  m.fillStyle = 'rgba(6,12,22,0.12)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  // near: kept deliberately thin. Everything lives above y=74 or below y=128,
  // so the core itself is visible through the whole middle of the frame.
  ceilingSlab(n, L, 34, 12, '#0e1622', '#1b2a3e', '#070c14');
  n.fillStyle = '#1b3050'; n.fillRect(0, 46, W2, 13);            // the one coolant trunk
  n.fillStyle = '#2c4a76'; n.fillRect(0, 46, W2, 2);
  n.fillStyle = 'rgba(0,0,0,0.38)'; n.fillRect(0, 57, W2, 2);
  for (let x = 0; x < W2; x += 124) {
    n.fillStyle = '#0d1728'; n.fillRect(x, 43, 10, 19);
    n.save(); n.shadowColor = '#4ac0e8'; n.shadowBlur = 7; n.fillStyle = '#4ac0e8';
    n.fillRect(x + 3, 50, 4, 4); n.restore();
  }
  cableTray(n, L, R, 62, '#16243a', false);
  for (let x = 90; x < W2; x += 310) {                            // elbows dropping away into the core
    n.fillStyle = '#1b3050';
    n.beginPath(); n.moveTo(x, 59); n.quadraticCurveTo(x + 30, 62, x + 32, 74);
    n.lineTo(x + 46, 74); n.quadraticCurveTo(x + 44, 50, x + 4, 46); n.fill();
    n.fillStyle = 'rgba(120,190,255,0.10)'; n.fillRect(x + 30, 70, 18, 10);
  }
  // the deck you stand on: a handrail and an edge, both above the walkable band
  n.fillStyle = '#132133'; n.fillRect(0, 126, W2, 4);
  n.fillStyle = '#2c4a76'; n.fillRect(0, 126, W2, 1);
  for (let x = 0; x < W2; x += 38) { n.fillStyle = '#132133'; n.fillRect(x, 130, 4, 12); }
  n.fillStyle = '#152438'; n.fillRect(0, 140, W2, 8);
  n.fillStyle = '#27405e'; n.fillRect(0, 140, W2, 2);
  n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(0, 146, W2, 2);
  // the control island at mid-scene, and the capsule berth beside it
  const P = Math.min(700, len - 300);
  n.fillStyle = '#0b1420'; n.fillRect(P - 108, 86, 90, 40);
  n.fillStyle = '#17273c'; n.fillRect(P - 104, 90, 82, 36);
  n.fillStyle = '#23405f'; n.fillRect(P - 104, 90, 82, 3);
  for (let k = 0; k < 3; k++) {
    n.fillStyle = '#040a12'; n.fillRect(P - 98 + k * 26, 96, 20, 16);
    n.fillStyle = 'rgba(120,200,255,0.55)'; n.fillRect(P - 96 + k * 26, 98, 16, 2);
    n.fillStyle = 'rgba(120,200,255,0.22)'; n.fillRect(P - 96 + k * 26, 103, 10, 2);
  }
  ptext(n, 'CORE CTRL', P - 102, 116, 'rgba(150,205,245,0.55)');
  // the berth: the one warm thing in a blue room, and where the capsule sits
  n.fillStyle = '#0a1018'; n.fillRect(P + 4, 70, 92, 70);
  n.fillStyle = '#131f30'; n.fillRect(P + 10, 74, 80, 66);
  n.fillStyle = '#23405f'; n.fillRect(P + 10, 74, 80, 3);
  hazardBand(n, P + 4, 64, 92, 7);
  const cap = n.createLinearGradient(P + 28, 82, P + 28, 136);
  cap.addColorStop(0, 'rgba(255,236,172,0.85)'); cap.addColorStop(0.5, 'rgba(226,176,60,0.75)');
  cap.addColorStop(1, 'rgba(84,56,14,0.80)');
  n.save(); n.shadowColor = '#f2c94c'; n.shadowBlur = 20;
  n.fillStyle = cap; n.fillRect(P + 28, 82, 44, 54); n.restore();
  n.fillStyle = 'rgba(18,12,4,0.55)';
  n.beginPath(); n.ellipse(P + 50, 94, 8, 7, 0, 0, 7); n.fill();
  n.fillRect(P + 41, 100, 18, 20); n.fillRect(P + 34, 102, 6, 16); n.fillRect(P + 60, 102, 6, 16);
  n.fillStyle = 'rgba(255,255,255,0.14)'; n.fillRect(P + 31, 84, 4, 48);
  ptext(n, 'BERTH 9', P + 26, 138, 'rgba(242,201,76,0.70)');
  floorGlow(n, L, P + 48, LAB_TOP, 110, 'rgba(242,201,76,0.10)');
  tileFloor(n, L, R, r, LAB_TOP, '#0d1622', '#152234', '#101a28', 30);
  for (let x = 0; x < W2; x += 140) floorGlow(n, L, x + 70, LAB_TOP, 120, 'rgba(90,170,240,0.07)');
  n.fillStyle = 'rgba(10,22,40,0.24)'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  L.corePulse = 1; L.labHum = 1;
}

// ---- C3: THE ARCHIVE ------------------------------------------------------
// Automated storage: a wall of black slots to the ceiling and a retrieval arm
// on a rail that travels the length of the scene picking cases out of it. The
// most mechanical option, and the only one where the set itself moves.
function s7c_archive(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#08070a'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 18) {                     // slots going back forever
    for (let y = 38; y < 148; y += 12) {
      f.fillStyle = ((x + y) % 5) ? '#0d0c11' : '#131119';
      f.fillRect(x, y, 15, 9);
      if (((x * 3 + y) % 13) === 0) { f.fillStyle = 'rgba(232,40,58,0.35)'; f.fillRect(x + 12, y + 3, 2, 2); }
    }
  }
  // mid: the same wall, one step closer, with aisle lighting raking across it
  m.fillStyle = '#0a090d'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 30) {
    for (let y = 40; y < 148; y += 19) {
      const empty = ((x / 30 | 0) * 7 + y) % 11 < 2;
      m.fillStyle = empty ? '#050408' : '#14121b';
      m.fillRect(x, y, 26, 16);
      if (!empty) {
        m.fillStyle = '#1d1a26'; m.fillRect(x, y, 26, 2);
        m.fillStyle = 'rgba(232,40,58,0.28)'; m.fillRect(x + 3, y + 5, 8, 2);
        ptext(m, String((x / 30 | 0) % 10) + String((y / 19 | 0) % 10), x + 14, y + 4, 'rgba(180,170,190,0.25)');
      }
    }
  }
  m.fillStyle = 'rgba(6,5,9,0.38)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  ceilingSlab(n, L, 34, 13, '#100e14', '#1b1822', '#08070a');
  n.fillStyle = '#1d1a26'; n.fillRect(0, 47, W2, 9);              // the crane rail the arm rides
  n.fillStyle = '#2d2938'; n.fillRect(0, 47, W2, 2);
  n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(0, 54, W2, 3);
  for (let x = 0; x < W2; x += 40) { n.fillStyle = '#141119'; n.fillRect(x, 57, 6, 9); }
  n.fillStyle = '#17141d'; n.fillRect(0, 64, W2, 5);
  cableTray(n, L, R, 72, '#1a1721', false);
  for (let x = 0; x < W2; x += 120) {                             // the near slot wall, waist to head height
    n.fillStyle = '#0b0a0e'; n.fillRect(x, 84, 114, 64);
    for (let row = 0; row < 3; row++) for (let c = 0; c < 4; c++) {
      const sx = x + 4 + c * 28, sy = 88 + row * 21;
      const empty = ((x / 120 | 0) * 5 + row * 3 + c) % 9 < 2;
      n.fillStyle = empty ? '#040308' : '#16131d';
      n.fillRect(sx, sy, 25, 18);
      if (!empty) {
        n.fillStyle = '#211d2b'; n.fillRect(sx, sy, 25, 3);
        n.fillStyle = 'rgba(232,40,58,0.45)'; n.fillRect(sx + 3, sy + 6, 7, 2);
        ptext(n, String(100 + (x / 120 | 0) * 12 + row * 4 + c), sx + 12, sy + 5, 'rgba(190,182,200,0.38)');
      } else {
        n.fillStyle = 'rgba(232,40,58,0.10)'; n.fillRect(sx, sy, 25, 18);
      }
    }
    n.fillStyle = '#15121b'; n.fillRect(x + 114, 80, 6, 68);
    n.fillStyle = '#231f2d'; n.fillRect(x + 114, 80, 2, 68);
  }
  for (let x = 260; x < W2 - 180; x += 470) {                     // index terminals between the stacks
    n.fillStyle = '#100d15'; n.fillRect(x, 96, 74, 52);
    n.fillStyle = '#1c1825'; n.fillRect(x, 96, 74, 3);
    n.fillStyle = '#030208'; n.fillRect(x + 8, 102, 58, 26);
    for (let k = 0; k < 6; k++) { n.fillStyle = 'rgba(232,40,58,0.45)'; n.fillRect(x + 12, 106 + k * 4, 22 + (k * 9) % 34, 2); }
    ptext(n, 'INDEX', x + 10, 134, 'rgba(210,150,160,0.50)');
  }
  // the one slot that is lit differently: the capsule's berth
  const P = Math.min(700, len - 300);
  n.fillStyle = '#07060a'; n.fillRect(P - 60, 80, 120, 68);
  n.fillStyle = '#1a1622'; n.fillRect(P - 44, 88, 88, 54);
  n.save(); n.shadowColor = '#f2c94c'; n.shadowBlur = 20;
  n.fillStyle = 'rgba(242,201,76,0.28)'; n.fillRect(P - 32, 96, 64, 40); n.restore();
  n.strokeStyle = '#f2c94c'; n.lineWidth = 2; n.strokeRect(P - 44, 88, 88, 54);
  ptext(n, 'UNIT 9', P - tw('UNIT 9') / 2, 76, 'rgba(242,201,76,0.75)');
  floorGlow(n, L, P, LAB_TOP, 120, 'rgba(242,201,76,0.12)');
  epoxyFloor(n, L, R, r, LAB_TOP, '#0f0d13', 'rgba(150,120,140,0.12)', '#1f1b28');
  n.fillStyle = '#14111a'; n.fillRect(0, 186, W2, 6);             // the arm's floor rail, painted flat
  n.fillStyle = 'rgba(232,40,58,0.16)'; n.fillRect(0, 186, W2, 1);
  for (let x = 0; x < W2; x += 26) { n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, 186, 3, 6); }
  n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  L.craneArm = 1; L.dustMotes = 1;
}

// ---- C4: THE BIRTHING FLOOR -----------------------------------------------
// The wildcard, and the one that says out loud what stage 7's opening text only
// implies. A production line of upright capsules, each with a part-finished
// body standing in it, feeds coming down from a header overhead - and one
// capsule at mid-scene closed, finished and lit gold.
function s7c_birth(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0a0713'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 36) {                     // the line curving away out of sight
    const g = f.createLinearGradient(0, 44, 0, 148);
    g.addColorStop(0, 'rgba(150,110,220,0.26)'); g.addColorStop(1, 'rgba(30,16,60,0.30)');
    f.fillStyle = g; f.fillRect(x + 6, 44, 22, 104);
    f.fillStyle = 'rgba(0,0,0,0.45)'; f.fillRect(x + 12, 70, 10, 52);
  }
  f.fillStyle = 'rgba(10,6,20,0.40)'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = '#0d0918'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 82) {                     // the second rank, three-quarter size
    tank(m, x + 16, 48, 44, 92, R, 'rgba(78,44,140,0.85)', 'rgba(186,148,255,0.85)', { body: R() < 0.8 });
  }
  m.fillStyle = '#131020'; m.fillRect(0, 34, L.mid.width, 12);    // the header they all hang off
  m.fillStyle = '#221a38'; m.fillRect(0, 34, L.mid.width, 2);
  m.fillStyle = 'rgba(10,6,20,0.35)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  // near: the feed header overhead - this is what the falling hazard comes off
  ceilingSlab(n, L, 34, 13, '#140f22', '#221a38', '#0a0714');
  n.fillStyle = '#1b1430'; n.fillRect(0, 47, W2, 12);
  n.fillStyle = '#2d2350'; n.fillRect(0, 47, W2, 3);
  n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(0, 57, W2, 3);
  for (let x = 0; x < W2; x += 96) {                              // umbilicals dropping to each capsule
    for (let k = 0; k < 3; k++) {
      n.strokeStyle = ['#6a4aa8', '#3f7fa8', '#8a5a4a'][k]; n.lineWidth = 3;
      n.beginPath(); n.moveTo(x + 30 + k * 10, 59);
      n.quadraticCurveTo(x + 26 + k * 10, 70, x + 34 + k * 8, 80); n.stroke();
    }
    n.fillStyle = '#100c1c'; n.fillRect(x + 24, 56, 40, 7);
    n.save(); n.shadowColor = '#b894ff'; n.shadowBlur = 8; n.fillStyle = '#b894ff';
    n.fillRect(x + 58, 58, 4, 4); n.restore();
  }
  cableTray(n, L, R, 70, '#1c1530', false);
  for (let x = 0; x < W2; x += 96) {                              // the capsules, part-finished bodies inside
    const stage = (x / 96 | 0) % 4;
    n.fillStyle = '#0a0714'; n.fillRect(x, 80, 90, 68);
    tank(n, x + 18, 82, 54, 66, R, 'rgba(70,40,130,0.92)', 'rgba(198,162,255,0.95)',
      { body: stage !== 0, label: 'U-' + String(30 + (x / 96 | 0)) });
    if (stage === 0) {                                             // an empty one, hatch stood open
      n.fillStyle = '#050310'; n.fillRect(x + 18, 82, 54, 66);
      n.fillStyle = '#1d1636'; n.fillRect(x + 72, 78, 7, 74);
      n.fillStyle = '#2f2554'; n.fillRect(x + 72, 78, 2, 74);
    }
    if (stage === 2) { n.fillStyle = 'rgba(232,40,58,0.16)'; n.fillRect(x + 18, 82, 54, 66);
      ptext(n, 'REJECT', x + 22, 106, 'rgba(232,40,58,0.70)'); }
    n.fillStyle = '#150f26'; n.fillRect(x + 12, 140, 66, 8);      // the carrier it stands on
    n.fillStyle = '#251c42'; n.fillRect(x + 12, 140, 66, 2);
    floorGlow(n, L, x + 45, LAB_TOP, 74, 'rgba(160,120,240,0.09)');
  }
  // mid-scene: the finished one, closed and gold
  const P = Math.min(700, len - 300);
  n.fillStyle = '#07040f'; n.fillRect(P - 70, 68, 140, 80);
  n.fillStyle = '#1c1530'; n.fillRect(P - 44, 70, 88, 78);
  n.fillStyle = '#2d2350'; n.fillRect(P - 44, 70, 88, 3);
  const gg = n.createLinearGradient(P - 32, 76, P - 32, 144);
  gg.addColorStop(0, 'rgba(255,232,160,0.85)'); gg.addColorStop(0.5, 'rgba(228,176,60,0.75)');
  gg.addColorStop(1, 'rgba(90,60,16,0.80)');
  n.save(); n.shadowColor = '#f2c94c'; n.shadowBlur = 22;
  n.fillStyle = gg; n.fillRect(P - 32, 76, 64, 68); n.restore();
  n.fillStyle = 'rgba(20,14,4,0.55)';                              // the shape standing in it
  n.beginPath(); n.ellipse(P, 92, 11, 9, 0, 0, 7); n.fill();
  n.fillRect(P - 12, 100, 24, 26);
  n.fillRect(P - 20, 102, 7, 22); n.fillRect(P + 13, 102, 7, 22);
  n.fillRect(P - 10, 126, 8, 18); n.fillRect(P + 2, 126, 8, 18);
  n.fillStyle = 'rgba(255,255,255,0.14)'; n.fillRect(P - 28, 80, 5, 60);
  hazardBand(n, P - 44, 140, 88, 8);
  ptext(n, 'UNIT 9 - COMPLETE', P - tw('UNIT 9 - COMPLETE') / 2, 62, 'rgba(242,201,76,0.80)');
  floorGlow(n, L, P, LAB_TOP, 140, 'rgba(242,201,76,0.14)');
  epoxyFloor(n, L, R, r, LAB_TOP, '#120d1e', 'rgba(140,110,200,0.16)', '#251c3e');
  n.fillStyle = '#171128'; n.fillRect(0, 190, W2, 5);             // the carrier rail, flat paint on the floor
  for (let x = 0; x < W2; x += 22) { n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, 190, 3, 5); }
  n.fillStyle = 'rgba(12,6,24,0.30)'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  L.bubbles = 96; L.labHum = 1;
}
