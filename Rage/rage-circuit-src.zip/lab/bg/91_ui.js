// ============================================================ page wiring
const PICK_KEY = 'rc_bg_picks_v1';
let picks = {};
try { picks = JSON.parse(localStorage.getItem(PICK_KEY) || '{}'); } catch (e) { picks = {}; }
function savePicks() { try { localStorage.setItem(PICK_KEY, JSON.stringify(picks)); } catch (e) {} }

const root = document.getElementById('sections');
const SCRUB = document.getElementById('scrub');
const BAND = document.getElementById('band');

SECTIONS.forEach(sec => {
  const wrap = document.createElement('section');
  wrap.className = 'sec';
  wrap.innerHTML = `
    <header class="sechead">
      <div>
        <p class="eyebrow">Stage ${sec.stage}</p>
        <h2>${sec.now}</h2>
      </div>
      <p class="secmeta">${sec.len} units long &middot; 4 options &middot; <span class="chosen" data-for="${sec.id}">nothing picked yet</span></p>
    </header>
    <div class="grid"></div>`;
  const grid = wrap.querySelector('.grid');
  sec.options.forEach(opt => {
    const card = document.createElement('article');
    card.className = 'card';
    card.dataset.k = opt.k;
    card.innerHTML = `
      <div class="screen"><canvas></canvas></div>
      <div class="body">
        <div class="titlerow">
          <h3><span class="tag">${opt.k}</span>${opt.name}</h3>
          <button class="pick" type="button" aria-pressed="false">Pick</button>
        </div>
        <p class="pitch">${opt.pitch}</p>
        <ul class="notes">${opt.notes.map(n => `<li>${n}</li>`).join('')}</ul>
      </div>`;
    grid.appendChild(card);
    makeView(card, opt, sec.len);
    card.querySelector('.pick').addEventListener('click', () => {
      picks[sec.id] = picks[sec.id] === opt.k ? null : opt.k;
      savePicks(); refresh();
    });
    card.querySelector('.screen').addEventListener('click', () => {
      card.classList.toggle('big');
    });
  });
  root.appendChild(wrap);
  maxLen = Math.max(maxLen, sec.len);
});

function refresh() {
  document.querySelectorAll('.card').forEach(c => {
    const k = c.dataset.k;
    const on = Object.values(picks).includes(k);
    c.classList.toggle('picked', on);
    const b = c.querySelector('.pick');
    b.textContent = on ? 'Picked' : 'Pick';
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
  });
  document.querySelectorAll('.chosen').forEach(s => {
    const k = picks[s.dataset.for];
    s.textContent = k ? `picked ${k}` : 'nothing picked yet';
    s.classList.toggle('yes', !!k);
  });
  const all = SECTIONS.map(s => picks[s.id]).filter(Boolean);
  document.getElementById('summary').textContent = all.length
    ? `Tell Claude: ${all.join(' and ')}`
    : 'Pick one per section and this line becomes the message to send back.';
}

document.getElementById('play').addEventListener('click', e => {
  playing = !playing;
  e.currentTarget.textContent = playing ? 'Pause' : 'Play';
});
document.getElementById('speed').addEventListener('input', e => {
  speed = Number(e.currentTarget.value);
  document.getElementById('speedval').textContent = speed.toFixed(1) + '×';
});
SCRUB.addEventListener('input', e => { cam = Number(e.currentTarget.value); });
SCRUB.max = String(maxLen - W);
BAND.addEventListener('change', () => {});

refresh();
requestAnimationFrame(frame);
