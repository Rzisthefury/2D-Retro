// ============================================================ concept lab core
// Same world units as the game: 426x240 logical, PX device pixels per unit.
const W = 426, H = 240, PX = 2;   // 854x480 backbuffer, same as the game
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, k) => a + (b - a) * k;

function mulberry(a) {
  return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
function mkCanvas(w, h) {
  const c = document.createElement('canvas');
  c.width = Math.ceil(w * PX); c.height = Math.ceil(h * PX);
  const g = c.getContext('2d');
  g.setTransform(PX, 0, 0, PX, 0, 0);
  g.imageSmoothingEnabled = false;
  g.lineCap = 'round'; g.lineJoin = 'round';
  Object.defineProperty(c, 'width', { value: w, configurable: true });
  Object.defineProperty(c, 'height', { value: h, configurable: true });
  return c;
}
const pick2 = (R, arr) => arr[Math.floor(R() * arr.length)];

// ---- the game's 5x7 pixel font, for signage
const GLYPHS = {
  A:[14,17,17,31,17,17,17],B:[30,17,30,17,17,17,30],C:[14,17,16,16,16,17,14],D:[28,18,17,17,17,18,28],
  E:[31,16,30,16,16,16,31],F:[31,16,30,16,16,16,16],G:[14,17,16,23,17,17,15],H:[17,17,31,17,17,17,17],
  I:[14,4,4,4,4,4,14],J:[7,2,2,2,2,18,12],K:[17,18,20,24,20,18,17],L:[16,16,16,16,16,16,31],
  M:[17,27,21,21,17,17,17],N:[17,25,21,19,17,17,17],O:[14,17,17,17,17,17,14],P:[30,17,17,30,16,16,16],
  Q:[14,17,17,17,21,18,13],R:[30,17,17,30,20,18,17],S:[15,16,16,14,1,1,30],T:[31,4,4,4,4,4,4],
  U:[17,17,17,17,17,17,14],V:[17,17,17,17,17,10,4],W:[17,17,17,21,21,27,17],X:[17,17,10,4,10,17,17],
  Y:[17,17,10,4,4,4,4],Z:[31,1,2,4,8,16,31],
  '0':[14,17,19,21,25,17,14],'1':[4,12,4,4,4,4,14],'2':[14,17,1,2,4,8,31],'3':[31,2,4,2,1,17,14],
  '4':[2,6,10,18,31,2,2],'5':[31,16,30,1,1,17,14],'6':[6,8,16,30,17,17,14],'7':[31,1,2,4,8,8,8],
  '8':[14,17,17,14,17,17,14],'9':[14,17,17,15,1,2,28],
  ' ':[0,0,0,0,0,0,0],'-':[0,0,0,31,0,0,0],'.':[0,0,0,0,0,12,12],'!':[4,4,4,4,4,0,4],
  "'":[4,4,0,0,0,0,0],'&':[12,18,12,25,18,18,13],'/':[1,2,2,4,8,8,16],':':[0,12,12,0,12,12,0],
  '$':[4,15,20,14,5,30,4],'#':[10,31,10,10,31,10,0],'*':[0,10,4,31,4,10,0],'+':[0,4,4,31,4,4,0],
  '"':[10,10,0,0,0,0,0],'?':[14,17,1,6,4,0,4],'%':[17,1,2,4,8,16,17],',':[0,0,0,0,12,4,8],
};
const FONT_KEYS = Object.keys(GLYPHS);
const fontCache = new Map();
function fontAtlas(color) {
  let c = fontCache.get(color);
  if (c) return c;
  c = document.createElement('canvas');
  c.width = FONT_KEYS.length * 6; c.height = 7;
  const g = c.getContext('2d');
  g.fillStyle = color;
  FONT_KEYS.forEach((k, i) => { const rows = GLYPHS[k];
    for (let y = 0; y < 7; y++) for (let x = 0; x < 5; x++) if (rows[y] & (16 >> x)) g.fillRect(i * 6 + x, y, 1, 1); });
  const idx = {}; FONT_KEYS.forEach((k, i) => idx[k] = i);
  c.idx = idx; fontCache.set(color, c);
  return c;
}
// glowing neon text
function neonText(g, word, x, y, c, s = 1) {
  g.save(); g.shadowColor = c; g.shadowBlur = 8 * s;
  ptext(g, word, x, y, c, s);
  g.restore();
}
// glowing neon text (the game's own helper, mirrored here for the lab)
function neonText(g, word, x, y, c, s = 1) {
  g.save(); g.shadowColor = c; g.shadowBlur = 8 * s;
  ptext(g, word, x, y, c, s);
  g.restore();
}

// the game's own night-sky helper (it lives in p6_stage.js, which the lab does
// not bundle), mirrored here so the stage 4 painters can use it
function nightSky(f, L, R, r, a, b, c) {
  const sky = f.createLinearGradient(0, 0, 0, 150);
  sky.addColorStop(0, a); sky.addColorStop(0.7, b); sky.addColorStop(1, c);
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  for (let i = 0; i < 80; i++) { f.fillStyle = R() < 0.3 ? '#fff' : '#8a88b0'; f.fillRect(r(0, L.far.width), r(0, 80), 1, 1); }
}
