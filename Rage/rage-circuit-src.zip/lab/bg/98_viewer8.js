// ============================================================ the picker (stage 8)
const SECTIONS = [
  { id: 'A', stage: '8-A', now: 'THE ATRIUM', len: 1540, options: [
    { k: 'A1', name: 'The Grand Atrium', f: s8a_grand,
      pitch: 'The name done properly: eighty floors of glass over a marble hall, balconies stacked up behind it, and his name on the wall before you have thrown a punch.',
      notes: ['Two mezzanine levels run the whole length with lit offices set back behind them - the building is awake and watching',
              'Marble columns with real uplighting every 232 units, trees and planting between them, a reception bank with the crest over it',
              'The pit is a lightwell straight down through the floor plate to the parking levels, railed on both sides'] },
    { k: 'A2', name: 'The Trading Floor', f: s8a_trading,
      pitch: 'Two in the morning and the money is still moving. Desks, a back wall of screens, glass pods, everything lit blue.',
      notes: ['A data wall the full length: charts running green and red, and a ticker rail under it that never stops',
              'Rows of workstations stepping back into the room, glazed meeting pods, status boards on the columns',
              'The pit is a bay of access floor lifted out for the new riser - the coldest, most corporate of the four'] },
    { k: 'A3', name: 'The Winter Garden', f: s8a_garden,
      pitch: 'The wildcard for this section: the atrium is a conservatory. Glass roof, mature trees indoors, festoon lights, and water.',
      notes: ['A pitched glazed roof on trusses with festoon lamps slung under it - the warmest lighting in the whole game',
              'Full-height trees in the hall every 196 units, benches, ferns, planting at every column',
              'The pit is the deep end of a 380-unit reflecting pool with fountain jets standing in it'] },
    { k: 'A4', name: 'The Blackout Lobby', f: s8a_blackout,
      pitch: 'They cut the power to the lower floors to slow you down. Same hall as A1, nothing on but the emergency fittings.',
      notes: ['The only light inside is green emergency lamps and exit signs; everything bright is the city outside, coming in',
              'Security shutters half-dropped across the openings, reception abandoned mid-shift with a mug still on it',
              'The pit is a lift shaft with the doors levered apart - and the guards carry torches, so the light moves'] },
  ] },
  { id: 'B', stage: '8-B', now: 'EXECUTIVE FLOOR', len: 1420, options: [
    { k: 'B1', name: 'The Executive Floor', f: s8b_exec,
      pitch: 'Wood, brass and deep carpet. A corridor of corner offices with the boardroom glazed at the end of it.',
      notes: ['Panelled piers with lit pictures between every office door, brass nameplates, a credenza with a lamp on it',
              'Each office behind the wall is lit differently and has its own window onto the city, with a desk silhouetted against it',
              'The only carpeted scene in the game - Big Brick going through a door frame here will look like vandalism'] },
    { k: 'B2', name: 'The Boardroom', f: s8b_board,
      pitch: 'One room, the whole scene. A table you could land on, the board looking down off the walls, glass on every side.',
      notes: ['The table runs the full 1420 units with the pendants reflected in it, chairs, folders and a glass at every place',
              'Fourteen oil portraits down the wall with brass plaques - the men who signed for all of it',
              'His chair is at the head with the crest behind it, empty, so the far end of the room is already about him'] },
    { k: 'B3', name: 'The Model Room', f: s8b_model,
      pitch: 'His collection floor: the city he bought, in miniature, under glass. You walk the length of it past every place you have already fought through.',
      notes: ['Nine lit vitrines, each holding one of the earlier stages in model form - the El, the Strip, the rail yard, the interchange, the works, the lab',
              'The centrepiece is a gold-lit model of this tower, twice the height of the others, labelled PHASE TWO',
              'The strongest story beat of the twelve: the whole game laid out as a property portfolio'] },
    { k: 'B4', name: 'The Sky Lounge', f: s8b_lounge,
      pitch: 'The wildcard: not an office at all. The private floor - a back bar, a lit pool, a grand piano, and the inner circle still drinking.',
      notes: ['A 520-unit back bar of bottles lit from behind, stools, glasses left half-finished on the counter',
              'A 300-unit pool with underwater lights that throw moving caustics across the floor and ceiling',
              'Purple cove lighting throughout and a piano under a spot - the most decadent thing in the game'] },
  ] },
  { id: 'C', stage: '8-C', now: 'HELIPAD', len: 1240, options: [
    { k: 'C1', name: 'The Helipad', f: s8c_pad,
      pitch: 'The name done properly: last light, the city a long way down, and his aircraft already on the pad with the rotors turning.',
      notes: ['A real helicopter sitting on the mark in his house colours, rotors and tail rotor both turning',
              'Plant, stair heads and hose reels along the back, perimeter rail and edge lights the whole length',
              'The classic ending - he is thirty seconds from leaving and you are the reason he does not'] },
    { k: 'C2', name: 'The Spire', f: s8c_spire,
      pitch: 'Not a flat roof: the crown of the building. A steel diagrid overhead and the pad cantilevered off the side over nothing.',
      notes: ['The diagrid runs the full length overhead, blue-lit, so the whole scene is framed in structure',
              'The deck is open grating - the city glitters up through the floor you are standing on',
              'The pad is a disc hanging off the end with the void painted under it; the most vertiginous of the twelve'] },
    { k: 'C3', name: 'The Storm', f: s8c_storm,
      pitch: 'The weather turned, which is exactly why he is still here: the aircraft cannot lift. Rain sideways, the city lost in cloud.',
      notes: ['Driving rain, standing water on the deck, puddles catching the sky, and lightning behind the mast',
              'His helicopter is on the pad strapped down with tie-downs - a visible reason the finale happens at all',
              'Windsocks standing straight out, amber edge lights fighting through it; the only weather in the game'] },
    { k: 'C4', name: 'The Topping Out', f: s8c_steel,
      pitch: 'The wildcard, and the one that closes the circle: the crown of the tower is still bare steel. This is the building you first climbed on stage 3.',
      notes: ['Raw frame the whole length - columns, splice plates, cross bracing, tarps lashed on and snapping',
              'A tower crane standing over the far end with its jib right across the top of the screen and the hook hanging',
              'The pad is temporary decking laid over the beams, hazard-banded, with the drop painted under it'] },
  ] },
];

const BUILT = new Map();
const ORDER = [];
function build(opt, len) {
  if (BUILT.has(opt.k)) { touch(opt.k); return BUILT.get(opt.k); }
  const R = mulberry(opt.k.charCodeAt(0) * 7919 + opt.k.charCodeAt(1) * 131 + len);
  const r = (a, b) => a + R() * (b - a);
  const L = {
    far: mkCanvas(Math.ceil(W + len * 0.25) + 20, H),
    mid: mkCanvas(Math.ceil(W + len * 0.55) + 20, H),
    near: mkCanvas(len + W, H),
  };
  opt.f(L, R, r, len);
  BUILT.set(opt.k, L); ORDER.push(opt.k);
  while (ORDER.length > 6) { const dead = ORDER.shift(); if (dead !== opt.k) BUILT.delete(dead); }
  return L;
}
function touch(k) { const i = ORDER.indexOf(k); if (i >= 0) { ORDER.splice(i, 1); ORDER.push(k); } }

// ---- live overlays -------------------------------------------------------
// Dust turning slowly in the downlights of a room that is always heated.
function drawAtriumDust(g, t, cam) {
  for (let i = 0; i < 34; i++) {
    const seed = i * 181;
    const wx = (seed * 27) % 1800;
    const x = wx - cam + Math.sin(t / 110 + i) * 6;
    if (x < -4 || x > W + 4) continue;
    const y = 52 + ((seed % 92) + t * 0.09) % 92;
    g.fillStyle = `rgba(255,230,180,${0.09 + (i % 3) * 0.05})`;
    g.fillRect(x, y, 1, 1);
  }
}
// Monitors turning over across the trading floor.
function drawBlink8(g, t, cam) {
  for (let i = 0; i < 40; i++) {
    const seed = i * 173;
    const x = ((seed * 31) % 1900) - cam;
    if (x < -8 || x > W + 8) continue;
    const y = 96 + (seed % 36);
    if (((Math.floor(t / (10 + (i % 6) * 6)) + i) % 4)) continue;
    g.fillStyle = i % 3 ? 'rgba(90,208,106,0.65)' : 'rgba(232,58,74,0.6)';
    g.fillRect(x, y, 3, 2);
  }
}
// The ticker rail: a band of values sliding along under the data wall. Drawn
// at the mid layer's parallax so it sits on the rail rather than floating.
function drawTickers(g, t, cam) {
  const y = 107, off = (t * 0.9) % 14;
  g.save(); g.beginPath(); g.rect(0, y - 1, W, 6); g.clip();
  for (let x = -14; x < W + 14; x += 14) {
    const i = Math.floor((x + cam * 0.55 + off) / 14);
    g.fillStyle = i % 5 === 0 ? 'rgba(232,58,74,0.75)' : (i % 3 ? 'rgba(242,201,76,0.55)' : 'rgba(90,208,106,0.6)');
    g.fillRect(x - off, y, 8, 4);
  }
  g.restore();
}
// Pollen and dust in the festoon light of a warm glasshouse.
function drawGardenMotes(g, t, cam) {
  for (let i = 0; i < 42; i++) {
    const seed = i * 149;
    const x = ((seed * 37) % 1900) - cam + Math.sin(t / 74 + i) * 9;
    if (x < -4 || x > W + 4) continue;
    const y = 56 + ((seed % 88) + t * 0.07) % 88;
    g.fillStyle = `rgba(230,255,215,${0.08 + (i % 4) * 0.045})`;
    g.fillRect(x, y, 1, 1 + (i % 3 === 0 ? 1 : 0));
  }
}
// Emergency lighting settling and lifting, never blinking.
function drawEmergPulse(g, t) {
  const k = 0.016 + Math.abs(Math.sin(t / 82)) * 0.018;
  g.fillStyle = `rgba(90,208,106,${k})`; g.fillRect(0, 34, W, 206);
}
// Guards sweeping torches across a dead lobby.
function drawTorchBeams(g, t, cam) {
  for (let i = 0; i < 3; i++) {
    const seed = i * 401;
    const home = 280 + i * 520;
    const x = home - cam + Math.sin(t / (150 + i * 40) + seed) * 120;
    if (x < -120 || x > W + 120) continue;
    const a = Math.sin(t / (90 + i * 30) + i) * 0.5;
    g.save(); g.translate(x, 96); g.rotate(a);
    const gr = g.createLinearGradient(0, 0, 130, 0);
    gr.addColorStop(0, 'rgba(255,240,200,0.20)'); gr.addColorStop(1, 'rgba(255,240,200,0)');
    g.fillStyle = gr;
    g.beginPath(); g.moveTo(0, -3); g.lineTo(130, -26); g.lineTo(130, 26); g.lineTo(0, 3); g.fill();
    g.restore();
    g.fillStyle = 'rgba(255,248,220,0.55)'; g.fillRect(x - 1, 95, 3, 3);
  }
}
// The slow settle of a room where nothing has moved in hours.
function drawExecDust(g, t, cam) {
  for (let i = 0; i < 26; i++) {
    const seed = i * 211;
    const x = ((seed * 29) % 1800) - cam + Math.sin(t / 130 + i) * 4;
    if (x < -4 || x > W + 4) continue;
    const y = 54 + ((seed % 84) + t * 0.06) % 84;
    g.fillStyle = `rgba(255,222,170,${0.08 + (i % 3) * 0.05})`;
    g.fillRect(x, y, 1, 1);
  }
}
function drawBoardDust(g, t, cam) {
  drawExecDust(g, t, cam);
  const k = 0.008 + Math.abs(Math.sin(t / 150)) * 0.008;      // the pendants breathing
  g.fillStyle = `rgba(255,214,140,${k})`; g.fillRect(0, 34, W, 116);
}
// A glint travelling across the vitrine glass as you move down the room.
function drawCaseGlint(g, t, cam) {
  for (let i = 0; i < 10; i++) {
    const cx = 90 + i * 180 - cam;
    if (cx < -80 || cx > W + 80) continue;
    const ph = (t / 60 + i * 0.7) % 3;
    if (ph > 1) continue;
    const gx = cx - 58 + ph * 116;
    g.save(); g.beginPath(); g.rect(cx - 58, 62, 116, 50); g.clip();
    const gr = g.createLinearGradient(gx - 16, 0, gx + 16, 0);
    gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(230,245,255,0.13)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(gx - 20, 62, 40, 50);
    g.restore();
  }
}
// Water moving in a lit pool: bands on the ceiling and on the floor.
function drawPoolCaustics(g, t, cam) {
  const px0 = 600 - cam;
  if (px0 > W + 80 || px0 + 300 < -80) return;
  g.save(); g.beginPath(); g.rect(Math.max(0, px0 - 30), 34, 360, 206); g.clip();
  for (let i = 0; i < 12; i++) {
    const a = 0.05 + Math.abs(Math.sin(t / (40 + i * 9) + i)) * 0.06;
    const x = px0 + 14 + i * 24 + Math.sin(t / (55 + i * 7)) * 9;
    g.fillStyle = `rgba(150,230,255,${a})`;
    g.fillRect(x, 34, 12, 22);                                 // on the ceiling
    g.fillRect(x - 6, 150, 20, 76);                            // and on the floor
  }
  g.restore();
}
function drawLoungeHum(g, t) {
  const k = 0.012 + Math.abs(Math.sin(t / 104)) * 0.014;
  g.fillStyle = `rgba(200,106,255,${k})`; g.fillRect(0, 34, W, 206);
}
// The main and tail rotors turning on a machine that is about to leave.
function drawRotor(g, t, cam, pos) {
  const x = pos.x - cam, y = pos.y;
  if (x < -180 || x > W + 180) return;
  const a = t * 0.42;
  g.save(); g.translate(x - 8, y - 12);
  for (let k = 0; k < 2; k++) {
    const ang = a + k * Math.PI, sp = Math.cos(ang);
    g.strokeStyle = `rgba(190,215,235,${0.22 + Math.abs(sp) * 0.30})`;
    g.lineWidth = 3;
    g.beginPath(); g.moveTo(0, 0); g.lineTo(sp * 96, Math.sin(ang) * 5); g.stroke();
  }
  g.strokeStyle = 'rgba(190,215,235,0.10)'; g.lineWidth = 2;
  g.beginPath(); g.ellipse(0, 0, 96, 5, 0, 0, 7); g.stroke();
  g.restore();
  const b = t * 0.9;                                           // tail rotor
  g.save(); g.translate(x + 92, y - 6);
  for (let k = 0; k < 2; k++) {
    const ang = b + k * Math.PI;
    g.strokeStyle = `rgba(190,215,235,${0.18 + Math.abs(Math.cos(ang)) * 0.24})`;
    g.lineWidth = 2;
    g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(ang) * 11, Math.sin(ang) * 11); g.stroke();
  }
  g.restore();
}
// The pad's own lights breathing, plus the beacon strobe.
function drawPadGlow(g, t) {
  const k = 0.012 + Math.abs(Math.sin(t / 88)) * 0.012;
  g.fillStyle = `rgba(120,200,255,${k})`; g.fillRect(0, 140, W, 100);
}
function drawBeaconC1(g, t, cam) {
  const ph = t % 78;
  if (ph > 8) return;
  const a = (1 - ph / 8) * 0.14;
  g.fillStyle = `rgba(255,120,110,${a})`; g.fillRect(0, 34, W, 206);
}
function drawSpireBlink(g, t, cam) {
  for (let i = 0; i < 12; i++) {
    const x = (i * 156) - cam * 1.0;
    if (x < -20 || x > W + 20) continue;
    const on = (Math.floor(t / 34) + i) % 5 === 0;
    if (!on) continue;
    g.fillStyle = 'rgba(160,230,255,0.45)'; g.fillRect(x - 3, 55, 10, 10);
  }
  const k = 0.010 + Math.abs(Math.sin(t / 110)) * 0.012;
  g.fillStyle = `rgba(74,192,232,${k})`; g.fillRect(0, 34, W, 206);
}
// Rain: near streaks moving fast, far ones slow, plus the wash on the lens.
function drawRain(g, t, cam) {
  for (let i = 0; i < 120; i++) {
    const seed = i * 137;
    const depth = (i % 3) + 1;
    const sp = 6 + depth * 4;
    const x = ((seed * 43 + t * (sp * 2.2)) % (W + 260)) - 130;
    const y = ((seed * 17 + t * sp * 3.4) % 240);
    if (y < 34) continue;
    g.fillStyle = `rgba(190,215,250,${0.10 + depth * 0.055})`;
    g.fillRect(x, y, 1 + (depth > 2 ? 1 : 0), 6 + depth * 4);
  }
  for (let i = 0; i < 16; i++) {                               // splashes off the deck
    const seed = i * 223;
    const x = ((seed * 53) % (W + 60)) - 30 + Math.sin(t / 30 + i) * 4;
    const ph = (t * 1.4 + seed) % 46;
    if (ph > 10) continue;
    g.fillStyle = `rgba(200,225,255,${0.20 * (1 - ph / 10)})`;
    g.beginPath(); g.ellipse(x, 168 + (seed % 56), 3 + ph, 1.5, 0, 0, 7); g.fill();
  }
  g.fillStyle = 'rgba(120,150,200,0.045)'; g.fillRect(0, 34, W, 206);
}
// Lightning: rare, bright, and short - the sky goes white and then it is gone.
function drawLightning(g, t) {
  const ph = t % 420;
  if (ph > 16) return;
  const a = ph < 3 ? 0.30 : (ph < 6 ? 0.06 : (ph < 10 ? 0.22 : 0.05));
  g.fillStyle = `rgba(210,228,255,${a})`; g.fillRect(0, 34, W, 206);
}
// Wind moving through a frame that is not clad yet.
function drawCraneSway(g, t, cam) {
  const k = 0.010 + Math.abs(Math.sin(t / 120)) * 0.010;
  g.fillStyle = `rgba(255,190,120,${k})`; g.fillRect(0, 34, W, 116);
  for (let i = 0; i < 5; i++) {                                // grit blowing off the deck
    const seed = i * 311;
    const x = ((seed * 41 + t * 2.4) % (W + 200)) - 100;
    const y = 120 + (seed % 26) + Math.sin(t / 22 + i) * 7;
    g.fillStyle = 'rgba(220,190,140,0.20)'; g.fillRect(x, y, 3, 1);
  }
}
function drawSteelGlint(g, t, cam) {
  for (let i = 0; i < 8; i++) {
    const x = (i * 186 + 30) - cam;
    if (x < -10 || x > W + 10) continue;
    const on = (Math.floor(t / 26) + i * 3) % 7 === 0;
    if (!on) continue;
    g.fillStyle = 'rgba(255,240,200,0.30)'; g.fillRect(x + (i % 3) * 8, 50 + (i % 4) * 14, 3, 3);
  }
}

// ---- the overlay dispatcher, shared by the picker and the contact sheets ---
function s8Overlays(g, L, t, cam, len) {
  if (L.atriumDust) drawAtriumDust(g, t, cam);
  if (L.blink8) drawBlink8(g, t, cam);
  if (L.tickers) drawTickers(g, t, cam);
  if (L.gardenMotes) drawGardenMotes(g, t, cam);
  if (L.emergPulse) drawEmergPulse(g, t);
  if (L.torchBeams) drawTorchBeams(g, t, cam);
  if (L.execDust) drawExecDust(g, t, cam);
  if (L.boardDust) drawBoardDust(g, t, cam);
  if (L.caseGlint) drawCaseGlint(g, t, cam);
  if (L.poolCaustics) drawPoolCaustics(g, t, cam);
  if (L.loungeHum) drawLoungeHum(g, t);
  if (L.rotor) drawRotor(g, t, cam, L.rotor);
  if (L.padGlow) drawPadGlow(g, t);
  if (L.beaconC1) drawBeaconC1(g, t, cam);
  if (L.spireBlink) drawSpireBlink(g, t, cam);
  if (L.rain) drawRain(g, t, cam);
  if (L.lightning) drawLightning(g, t);
  if (L.craneSway) drawCraneSway(g, t, cam);
  if (L.steelGlint) drawSteelGlint(g, t, cam);
}

const VIEWS = [];
let playing = true, speed = 1, cam = 0, frames = 0, maxLen = 1540;
function makeView(card, opt, len) {
  const cv = card.querySelector('canvas');
  cv.width = W * PX; cv.height = H * PX;
  const g = cv.getContext('2d');
  g.imageSmoothingEnabled = false;
  const v = { cv, g, opt, len, live: false };
  VIEWS.push(v);
  const io = new IntersectionObserver(es => { es.forEach(e => { v.live = e.isIntersecting; }); }, { rootMargin: '200px' });
  io.observe(cv);
  return v;
}
function paint(v) {
  const { g, opt, len } = v;
  const L = build(opt, len);
  g.setTransform(PX, 0, 0, PX, 0, 0);
  const c = Math.min(cam, len - W);
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  g.drawImage(L.far, -Math.round(c * 0.25), 0, L.far.width, L.far.height);
  g.drawImage(L.mid, -Math.round(c * 0.55), 0, L.mid.width, L.mid.height);
  g.drawImage(L.near, -Math.round(c), 0, L.near.width, L.near.height);
  s8Overlays(g, L, frames, c, len);
  if (BAND.checked) {
    g.fillStyle = 'rgba(74,192,232,0.10)'; g.fillRect(0, 150, W, 80);
    g.fillStyle = 'rgba(74,192,232,0.5)'; g.fillRect(0, 150, W, 1); g.fillRect(0, 229, W, 1);
    ptext(g, 'WALKABLE BAND', 6, 152, 'rgba(180,230,255,0.75)');
    g.fillStyle = 'rgba(232,40,58,0.35)'; g.fillRect(0, 0, W, 34);
    ptext(g, 'HUD', 6, 12, 'rgba(255,200,205,0.75)');
  }
  ptext(g, opt.k, 5, 5, 'rgba(255,255,255,0.28)', 2);
}
function frame() {
  if (playing) { cam += 0.9 * speed; frames += speed; if (cam > maxLen - W) cam = 0; SCRUB.value = String(Math.round(cam)); }
  for (const v of VIEWS) if (v.live) paint(v);
  requestAnimationFrame(frame);
}
