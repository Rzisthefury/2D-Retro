// ============================================================ STAGE 5-B options
// The board run. The camera pulls you forward on its own, every fighter is on
// a hoverboard, and Vex arrives at the end. Two rules for all four: the world
// has to read as MOVING, and the lower band has to stay quiet enough that a
// board fight is legible on top of it.

// lane markings that streak rather than sit still - drawn short and low
// contrast so they read as speed without fighting the sprites
function rideLanes(n, L, ys, col, dash = 22, gap = 34) {
  for (const ly of ys) for (let x = 0; x < L.near.width; x += dash + gap) {
    n.fillStyle = col; n.fillRect(x, ly, dash, 3);
    n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(x + dash, ly + 1, gap * 0.4, 1);
  }
}

// ---- B1: DAWN HIGHWAY -----------------------------------------------------
function s5b_dawn(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const sky = f.createLinearGradient(0, 0, 0, 150);
  sky.addColorStop(0, '#1a1440'); sky.addColorStop(0.5, '#8a3a6a'); sky.addColorStop(1, '#f0a050');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  f.fillStyle = '#ffe0a0'; f.beginPath(); f.arc(L.far.width * 0.42, 120, 26, 0, 7); f.fill();
  f.fillStyle = 'rgba(255,224,160,0.20)'; f.beginPath(); f.arc(L.far.width * 0.42, 120, 52, 0, 7); f.fill();
  for (let k = 0; k < 12; k++) { f.fillStyle = 'rgba(255,200,170,0.18)'; f.fillRect(r(0, L.far.width), r(30, 100), r(60, 130), 4); }
  skyline(f, L, R, r, 128, '#3a2044', '#ffd890', 24, 74);
  // mid: sound walls and lamp standards whipping past
  for (let x = 0; x < L.mid.width; x += 46) {
    m.fillStyle = (Math.round(x / 46) % 2) ? '#221c34' : '#1c1730'; m.fillRect(x, 96, 46, 54);
    m.fillStyle = 'rgba(255,255,255,0.05)'; m.fillRect(x, 96, 46, 2);
  }
  for (let x = 0; x < L.mid.width; x += 184) {
    m.fillStyle = '#14101e'; m.fillRect(x, 26, 4, 74); m.fillRect(x, 26, 22, 4);
    m.fillStyle = '#ffe8a0'; m.fillRect(x + 16, 30, 8, 3);
    m.fillStyle = 'rgba(255,232,160,0.09)'; m.beginPath(); m.moveTo(x + 16, 33); m.lineTo(x - 20, 150); m.lineTo(x + 60, 150); m.lineTo(x + 24, 33); m.fill();
  }
  L.speed = 1.6;
  // near: the guardrail, then the carriageway with traffic stopped in the far lane
  n.fillStyle = '#2e2036'; n.fillRect(0, 130, L.near.width, 18);
  guardrail(n, L, R, 128);
  asphalt(n, L, R, r, 148, '#26262c', '#2e2e36', '#1e1e24');
  // traffic you weave between - it sits high, in the far lane only
  for (let x = 40; x < L.near.width; x += 210 + R() * 130) {
    const c = pick2(R, ['#7a2a30', '#2a4a6a', '#3a3a42', '#6a6a58', '#2a5a4a']);
    n.fillStyle = '#0e0c14'; n.fillRect(x - 30, 152, 62, 18);
    n.fillStyle = c; n.fillRect(x - 29, 153, 60, 16);
    n.fillStyle = 'rgba(255,255,255,0.12)'; n.fillRect(x - 29, 153, 60, 2);
    n.fillStyle = '#1e2a3a'; n.fillRect(x - 20, 155, 40, 8);
    n.fillStyle = '#c83030'; n.fillRect(x - 30, 162, 6, 4); n.fillRect(x + 25, 162, 6, 4);
    n.fillStyle = 'rgba(200,60,60,0.16)'; n.fillRect(x - 40, 158, 84, 12);
    n.fillStyle = '#0e0c14'; n.fillRect(x - 26, 170, 54, 3);
  }
  rideLanes(n, L, [192, 224], 'rgba(232,228,200,0.75)');
  n.fillStyle = '#e8c020'; n.fillRect(0, 236, L.near.width, 3);
  n.fillStyle = 'rgba(255,190,120,0.07)'; n.fillRect(0, 148, L.near.width, 92);
}

// ---- B2: THE VIADUCT ------------------------------------------------------
// The road is up on piers above the city: gaps in the parapet show the drop,
// and the whole town slides past underneath.
function s5b_viaduct(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const sky = f.createLinearGradient(0, 0, 0, 150);
  sky.addColorStop(0, '#0f1040'); sky.addColorStop(0.45, '#4a2a6a'); sky.addColorStop(1, '#d86a4a');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  for (let i = 0; i < 40; i++) { f.fillStyle = 'rgba(255,255,255,0.4)'; f.fillRect(r(0, L.far.width), r(0, 40), 1, 1); }
  skyline(f, L, R, r, 96, '#241a3c', '#ffd070', 26, 70);
  // the city underneath, a long way down and sliding past fast
  f.fillStyle = '#1e1630'; f.fillRect(0, 96, L.far.width, 144);
  for (let x = 0; x < L.far.width; x += 9) { f.fillStyle = R() < 0.4 ? '#2a2044' : '#181228';
    f.fillRect(x, 96 + R() * 14, 8, 144); }
  for (let k = 0; k < L.far.width * 2; k++) { f.fillStyle = R() < 0.6 ? '#f2d070' : '#7ab8f0';
    f.fillRect(r(0, L.far.width), r(100, 236), 1, 1); }
  // mid: the piers and the deck edge rushing past
  for (let x = 0; x < L.mid.width; x += 120) {
    m.fillStyle = '#231b34'; m.fillRect(x, 108, 26, 42);
    m.fillStyle = '#2d2442'; m.fillRect(x + 2, 108, 8, 42);
    m.fillStyle = '#1a1428'; m.fillRect(x - 8, 100, 42, 10);
  }
  m.fillStyle = '#231b34'; m.fillRect(0, 96, L.mid.width, 12);
  m.fillStyle = '#332948'; m.fillRect(0, 96, L.mid.width, 3);
  L.speed = 1.6;
  // near: the parapet, with gaps you can see straight through
  let x = 0;
  while (x < L.near.width) {
    const w2 = 120 + R() * 60, open = R() < 0.35;
    if (open) {
      n.fillStyle = '#5a5f6a'; n.fillRect(x, 112, w2, 5);
      n.fillStyle = '#6e737e'; n.fillRect(x, 112, w2, 2);
      n.fillStyle = '#5a5f6a'; n.fillRect(x, 140, w2, 6);
      for (let k = 0; k < w2; k += 26) { n.fillStyle = '#4a4e58'; n.fillRect(x + k, 112, 5, 34); }
    } else {
      n.fillStyle = '#4e525c'; n.fillRect(x, 112, w2, 36);
      n.fillStyle = '#5e626e'; n.fillRect(x, 112, w2, 4);
      n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(x, 142, w2, 6);
      for (let k = 0; k < w2; k += 30) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(x + k, 116, 2, 30); }
      if (R() < 0.4) graffiti(n, x + 12, 132, R, w2 - 30);
    }
    x += w2;
  }
  for (let x2 = 70; x2 < L.near.width; x2 += 240) {                   // lamp standards on the parapet
    n.fillStyle = '#14101e'; n.fillRect(x2, 44, 5, 70);
    n.beginPath(); n.moveTo(x2, 44); n.quadraticCurveTo(x2 + 4, 36, x2 + 18, 38);
    n.lineWidth = 4; n.strokeStyle = '#14101e'; n.stroke();
    n.fillStyle = '#ffe8a0'; n.fillRect(x2 + 16, 37, 11, 4);
    n.fillStyle = 'rgba(255,232,160,0.09)';
    n.beginPath(); n.moveTo(x2 + 16, 41); n.lineTo(x2 - 18, 240); n.lineTo(x2 + 60, 240); n.lineTo(x2 + 27, 41); n.fill();
  }
  asphalt(n, L, R, r, 148, '#282830', '#30303a', '#202026');
  rideLanes(n, L, [192, 224], 'rgba(232,228,200,0.70)');
  n.fillStyle = '#e8c020'; n.fillRect(0, 236, L.near.width, 3);
  n.fillStyle = 'rgba(216,106,74,0.06)'; n.fillRect(0, 148, L.near.width, 92);
}

// ---- B3: THE TUNNEL RUN ---------------------------------------------------
// Inside at speed. Light strips strobe past overhead, tiled walls streak, and
// the exit grows as a white mouth at the far end.
function s5b_tunnelrun(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#06070a'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 30) {                        // the bore receding
    const k = (x / L.far.width);
    f.fillStyle = `rgba(${Math.round(20 + k * 12)},${Math.round(22 + k * 12)},${Math.round(28 + k * 14)},1)`;
    f.fillRect(x, 40, 30, 110);
  }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 40) {                        // the ring beams flicking past
    m.fillStyle = '#171a22'; m.fillRect(x, 30, 9, 120);
    m.fillStyle = '#1f242e'; m.fillRect(x, 30, 3, 120);
  }
  m.fillStyle = '#171a22'; m.fillRect(0, 26, L.mid.width, 9);
  L.speed = 2.1;
  // near: the tiled wall and the light ribbon, both streaking
  n.fillStyle = '#12141a'; n.fillRect(0, 0, L.near.width, 148);
  for (let ty = 44; ty < 126; ty += 11) for (let tx = 0; tx < L.near.width; tx += 15) {
    const t2 = R();
    n.fillStyle = t2 < 0.05 ? '#6a6e62' : t2 < 0.5 ? '#bdc1b3' : '#b1b6a8';
    n.fillRect(tx, ty, 14, 10);
  }
  n.fillStyle = 'rgba(0,0,0,0.34)'; n.fillRect(0, 44, L.near.width, 82);
  for (let k = 0; k < L.near.width / 8; k++) { n.fillStyle = 'rgba(40,34,26,0.32)';
    n.fillRect(r(0, L.near.width), r(96, 126), 16 + R() * 34, 6 + R() * 12); }
  // the strip lights: close together, so at speed they read as a strobe
  n.fillStyle = '#181c24'; n.fillRect(0, 34, L.near.width, 10);
  for (let x = 0; x < L.near.width; x += 30) {
    const dead = R() < 0.06;
    n.fillStyle = dead ? '#33363c' : '#fff0c8'; n.fillRect(x + 2, 36, 24, 6);
    if (!dead) { n.fillStyle = 'rgba(255,240,200,0.11)'; n.fillRect(x - 4, 44, 38, 82); }
  }
  n.fillStyle = '#2a2e36'; n.fillRect(0, 126, L.near.width, 8);
  n.fillStyle = '#3a404a'; n.fillRect(0, 126, L.near.width, 2);
  n.fillStyle = '#4a4e58'; n.fillRect(0, 134, L.near.width, 12);
  n.fillStyle = '#c8b030'; n.fillRect(0, 144, L.near.width, 3);
  asphalt(n, L, R, r, 147, '#212127', '#292931', '#19191f');
  rideLanes(n, L, [190, 222], 'rgba(232,228,200,0.80)', 18, 40);
  for (let x = 0; x < L.near.width; x += 30) { n.fillStyle = 'rgba(255,240,200,0.07)';
    n.beginPath(); n.ellipse(x, 184, 20, 30, 0, 0, 7); n.fill(); }
  // the mouth at the end: daylight, growing
  const e0 = len - 300;
  const g = n.createLinearGradient(e0, 0, L.near.width, 0);
  g.addColorStop(0, 'rgba(255,240,210,0)'); g.addColorStop(0.55, 'rgba(255,240,210,0.30)');
  g.addColorStop(1, 'rgba(255,250,235,0.85)');
  n.fillStyle = g; n.fillRect(e0, 34, L.near.width - e0, 206);
  L.tunnelHum = 1;
}

// ---- B4: THE SEA ROAD -----------------------------------------------------
// The wildcard: the road runs along a sea wall at dawn. Waves break over the
// barrier, spray drifts across, and the water takes the whole sunrise.
function s5b_sea(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const sky = f.createLinearGradient(0, 0, 0, 132);
  sky.addColorStop(0, '#16184a'); sky.addColorStop(0.42, '#6a3a72'); sky.addColorStop(0.74, '#e0764a');
  sky.addColorStop(1, '#ffc878');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  for (let i = 0; i < 30; i++) { f.fillStyle = 'rgba(255,255,255,0.35)'; f.fillRect(r(0, L.far.width), r(0, 34), 1, 1); }
  f.fillStyle = '#fff0c0'; f.beginPath(); f.arc(L.far.width * 0.58, 118, 22, 0, 7); f.fill();
  f.fillStyle = 'rgba(255,240,192,0.22)'; f.beginPath(); f.arc(L.far.width * 0.58, 118, 46, 0, 7); f.fill();
  for (let k = 0; k < 10; k++) { f.fillStyle = 'rgba(255,190,150,0.16)'; f.fillRect(r(0, L.far.width), r(40, 106), r(70, 150), 4); }
  // the sea, taking the sunrise
  f.fillStyle = '#16244a'; f.fillRect(0, 130, L.far.width, 110);
  for (let k = 0; k < L.far.width * 2.4; k++) {
    const yy = 130 + R() * 108;
    const warm = Math.abs(r(0, L.far.width) - L.far.width * 0.58) < 90 && R() < 0.5;
    f.fillStyle = warm ? 'rgba(255,200,140,0.30)' : (R() < 0.2 ? 'rgba(150,180,230,0.22)' : 'rgba(18,34,74,0.6)');
    f.fillRect(r(0, L.far.width), yy, 5 + R() * 11, 1);
  }
  for (let k = 0; k < 120; k++) { f.fillStyle = 'rgba(255,214,150,0.28)';
    f.fillRect(L.far.width * 0.58 + r(-24, 24), 132 + r(0, 100), 6 + R() * 9, 1); }
  // mid: the swell, and gulls
  for (let x = 0; x < L.mid.width; x += 36) {
    m.fillStyle = 'rgba(255,255,255,0.14)';
    m.beginPath(); m.ellipse(x, 126 + Math.sin(x * 0.04) * 4, 16, 3, 0, 0, 7); m.fill();
  }
  for (let k = 0; k < 14; k++) {
    const gx = r(0, L.mid.width), gy = r(30, 80);
    m.strokeStyle = 'rgba(240,240,250,0.5)'; m.lineWidth = 1.5;
    m.beginPath(); m.moveTo(gx - 5, gy); m.quadraticCurveTo(gx - 2, gy - 3, gx, gy - 1);
    m.quadraticCurveTo(gx + 2, gy - 3, gx + 5, gy); m.stroke();
  }
  L.speed = 1.4;
  // near: the sea wall, the barrier, and the road
  n.fillStyle = '#4e4a48'; n.fillRect(0, 118, L.near.width, 30);
  for (let x = 0; x < L.near.width; x += 42) {
    n.fillStyle = (Math.round(x / 42) % 2) ? '#565250' : '#4a4644'; n.fillRect(x, 118, 41, 29);
    n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x + 41, 118, 2, 29);
  }
  n.fillStyle = '#5e5a56'; n.fillRect(0, 118, L.near.width, 3);
  for (let k = 0; k < L.near.width / 12; k++) { n.fillStyle = 'rgba(70,90,70,0.22)';     // weed on the wall
    n.fillRect(r(0, L.near.width), r(134, 147), 8 + R() * 16, 4); }
  // waves breaking over it - baked, with the live spray drifting on top
  for (let x = 0; x < L.near.width; x += 150 + R() * 120) {
    n.fillStyle = 'rgba(235,245,255,0.75)';
    n.beginPath(); n.moveTo(x, 122); n.quadraticCurveTo(x + 22, 80, x + 54, 104);
    n.quadraticCurveTo(x + 70, 118, x + 86, 122); n.fill();
    n.fillStyle = 'rgba(255,255,255,0.55)';
    n.beginPath(); n.moveTo(x + 10, 122); n.quadraticCurveTo(x + 28, 96, x + 50, 112); n.fill();
    for (let k = 0; k < 16; k++) { n.fillStyle = 'rgba(255,255,255,0.4)';
      n.fillRect(x + 10 + R() * 70, 86 + R() * 36, 2, 2); }
  }
  // the safety barrier, concrete this time
  for (let x = 0; x < L.near.width; x += 58) {
    n.fillStyle = '#b8b4ac'; n.beginPath();
    n.moveTo(x, 148); n.lineTo(x + 4, 128); n.lineTo(x + 54, 128); n.lineTo(x + 58, 148); n.fill();
    n.fillStyle = '#cdc9c1'; n.fillRect(x + 4, 128, 50, 3);
    n.fillStyle = 'rgba(0,0,0,0.24)'; n.fillRect(x + 56, 128, 3, 20);
    n.fillStyle = '#e8342a'; n.fillRect(x + 26, 132, 4, 4);
  }
  asphalt(n, L, R, r, 148, '#2c2b30', '#343339', '#242329');
  rideLanes(n, L, [192, 224], 'rgba(232,228,200,0.72)');
  n.fillStyle = '#e8c020'; n.fillRect(0, 236, L.near.width, 3);
  n.fillStyle = 'rgba(255,190,120,0.08)'; n.fillRect(0, 148, L.near.width, 92);
  for (let k = 0; k < L.near.width / 90; k++) { n.fillStyle = 'rgba(210,225,240,0.20)';   // salt drying on the tarmac
    n.beginPath(); n.ellipse(r(0, L.near.width), r(158, 232), 16 + R() * 20, 4 + R() * 3, 0, 0, 7); n.fill(); }
  L.spray = 1;
}
