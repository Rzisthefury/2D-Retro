// ============================================================ STAGE 4-A options
// The yard. Needs a hydrant-equivalent, a manhole-equivalent in the floor, and
// somewhere for the rolling-stock "car" event to come through.

function ballast(n, L, R, r, base, a, b, c) {
  n.fillStyle = a; n.fillRect(0, base, L.near.width, 240 - base);
  for (let k = 0; k < L.near.width * 2.2; k++) {
    n.fillStyle = R() < 0.5 ? b : c;
    n.fillRect(r(0, L.near.width), r(base + 2, 240), 2, 2);
  }
  for (let k = 0; k < L.near.width / 60; k++) { n.fillStyle = 'rgba(0,0,0,0.16)';
    n.fillRect(r(0, L.near.width), r(base + 4, 236), 10 + R() * 22, 5); }
  n.fillStyle = c; n.fillRect(0, base, L.near.width, 3);
}
function railPair(n, L, R, ry, sleeper = '#3a3028', rail = '#8a8a96', shine = '#c8c8d4') {
  for (let x = 0; x < L.near.width; x += 22) {
    n.fillStyle = sleeper; n.fillRect(x, ry - 4, 16, 9);
    n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(x, ry + 4, 16, 2);
  }
  n.fillStyle = rail; n.fillRect(0, ry - 5, L.near.width, 2); n.fillRect(0, ry + 4, L.near.width, 2);
  n.fillStyle = shine; n.fillRect(0, ry - 5, L.near.width, 1); n.fillRect(0, ry + 4, L.near.width, 1);
}
// a line of mismatched wagons - the thing a real yard is full of
function wagon(n, x, R, kind) {
  const top = 148 - 64;
  if (kind === 0) {                                     // boxcar
    const body = pick2(R, ['#5a2a24', '#2a4a34', '#3a3a52', '#5a4a24']);
    n.fillStyle = '#0c0a12'; n.fillRect(x - 2, top - 2, 144, 70);
    n.fillStyle = body; n.fillRect(x, top, 140, 64);
    n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(x, top, 140, 4);
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, top + 56, 140, 8);
    for (let k = x + 6; k < x + 136; k += 11) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(k, top + 4, 1, 52); }
    n.fillStyle = '#e8e0c8'; n.fillRect(x + 42, top + 20, 32, 11);
    n.fillStyle = body; n.fillRect(x + 44, top + 22, 28, 7);
    n.fillStyle = 'rgba(0,0,0,0.32)'; n.fillRect(x + 56, top, 28, 64);        // the door
    n.fillStyle = 'rgba(255,255,255,0.07)'; n.fillRect(x + 56, top, 3, 64);
    graffiti(n, x + 14, top + 40, R, 60);
  } else if (kind === 1) {                              // tank wagon
    n.fillStyle = '#16141c'; n.fillRect(x, 148 - 30, 140, 22);
    n.fillStyle = pick2(R, ['#8a8a94', '#6a7a86', '#9a8a70']);
    n.beginPath(); n.ellipse(x + 70, top + 34, 70, 26, 0, 0, 7); n.fill();
    n.fillStyle = 'rgba(255,255,255,0.14)'; n.beginPath(); n.ellipse(x + 70, top + 26, 62, 9, 0, 0, 7); n.fill();
    n.fillStyle = 'rgba(0,0,0,0.26)'; n.beginPath(); n.ellipse(x + 70, top + 46, 64, 9, 0, 0, 7); n.fill();
    n.fillStyle = '#3a3a44'; n.fillRect(x + 56, top + 2, 28, 10);             // the dome
    n.fillStyle = '#4e4e5a'; n.fillRect(x + 58, top, 24, 4);
    n.fillStyle = '#e8c020'; n.fillRect(x + 24, top + 30, 26, 14);            // hazard placard
    n.fillStyle = '#1a1a1e'; n.fillRect(x + 27, top + 33, 20, 8);
    n.fillStyle = '#39414e'; n.fillRect(x + 108, top + 12, 3, 40);            // the end ladder
    for (let k = 0; k < 40; k += 6) n.fillRect(x + 104, top + 14 + k, 11, 2);
  } else if (kind === 2) {                              // open hopper, loaded
    n.fillStyle = '#0c0a12'; n.fillRect(x - 2, top + 8, 144, 60);
    n.fillStyle = pick2(R, ['#6a3a2a', '#3a4a5a', '#4a4a3a']);
    n.beginPath(); n.moveTo(x, top + 10); n.lineTo(x + 140, top + 10);
    n.lineTo(x + 120, top + 64); n.lineTo(x + 20, top + 64); n.fill();
    for (let k = 0; k < 10; k++) { n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x + 8 + k * 13, top + 12, 2, 50); }
    n.fillStyle = pick2(R, ['#3a3a40', '#5a4a38']);                           // the load, heaped
    n.beginPath(); n.moveTo(x + 4, top + 12); n.lineTo(x + 40, top + 2); n.lineTo(x + 100, top + 4);
    n.lineTo(x + 136, top + 12); n.fill();
    for (let k = 0; k < 24; k++) { n.fillStyle = 'rgba(255,255,255,0.06)'; n.fillRect(x + 10 + R() * 120, top + 3 + R() * 9, 3, 2); }
  } else {                                              // flat wagon with a tarped load
    n.fillStyle = '#16141c'; n.fillRect(x, top + 40, 140, 16);
    n.fillStyle = '#3a3a44'; n.fillRect(x + 2, top + 42, 136, 12);
    n.fillStyle = pick2(R, ['#2a5a3a', '#3a3a5a', '#5a4a2a']);
    n.beginPath(); n.moveTo(x + 14, top + 42); n.lineTo(x + 34, top + 12);
    n.lineTo(x + 108, top + 12); n.lineTo(x + 126, top + 42); n.fill();
    n.fillStyle = 'rgba(0,0,0,0.22)';
    for (let k = 0; k < 5; k++) n.fillRect(x + 24 + k * 22, top + 12, 3, 30);
    n.strokeStyle = '#c8b090'; n.lineWidth = 1.5;
    for (let k = 0; k < 4; k++) { n.beginPath(); n.moveTo(x + 18 + k * 26, top + 42); n.lineTo(x + 30 + k * 26, top + 14); n.stroke(); }
  }
  // the running gear: solebar, axleboxes and wheels under everything
  n.fillStyle = '#16141c'; n.fillRect(x + 8, 148, 124, 8);
  for (const wx of [x + 24, x + 46, x + 94, x + 116]) {
    n.fillStyle = '#26242c'; n.beginPath(); n.arc(wx, 154, 6, 0, 7); n.fill();
    n.fillStyle = '#3c3a46'; n.beginPath(); n.arc(wx, 154, 2.4, 0, 7); n.fill();
  }
  n.fillStyle = '#2a2830'; n.fillRect(x - 6, 146, 8, 6); n.fillRect(x + 138, 146, 8, 6);   // couplers
}

// ---- A1: THE YARD ---------------------------------------------------------
function s4a_yard(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  nightSky(f, L, R, r, '#05040f', '#141030', '#3a2048');
  skyline(f, L, R, r, 132, '#100c22', '#d8b050', 26, 78);
  for (let x = 0; x < L.mid.width; x += 160) {          // flood gantries down the yard
    m.fillStyle = '#181428'; m.fillRect(x + 20, 54, 4, 96); m.fillRect(x + 84, 54, 4, 96); m.fillRect(x + 20, 52, 68, 5);
    m.fillStyle = '#fff8d0'; m.fillRect(x + 30, 58, 7, 3); m.fillRect(x + 70, 58, 7, 3);
    m.fillStyle = 'rgba(255,248,208,0.07)';
    m.beginPath(); m.moveTo(x + 30, 61); m.lineTo(x - 14, 150); m.lineTo(x + 84, 150); m.lineTo(x + 77, 61); m.fill();
  }
  for (let x = 60; x < L.mid.width; x += 380) {         // the water crane and a coaling stage
    m.fillStyle = '#1e1a26'; m.fillRect(x, 92, 5, 58); m.fillRect(x - 22, 90, 30, 4);
    m.fillStyle = '#2a2632'; m.fillRect(x - 24, 86, 8, 6);
  }
  // near: a line of mismatched wagons on the back road
  let x = -30, wi = 0;
  while (x < len - 320) { wagon(n, x, R, wi % 4); x += 152 + R() * 40; wi++; }
  // the yard office and a permanent-way hut
  for (let hx = 240; hx < len - 400; hx += 620) {
    n.fillStyle = '#16141c'; n.fillRect(hx, 88, 96, 60);
    n.fillStyle = '#5a4a38'; n.fillRect(hx + 2, 90, 92, 56);
    for (let k = 0; k < 92; k += 7) { n.fillStyle = 'rgba(0,0,0,0.14)'; n.fillRect(hx + 2 + k, 90, 2, 56); }
    n.fillStyle = '#2a2a32'; n.fillRect(hx - 4, 84, 104, 7);
    n.fillStyle = '#e8c860'; n.fillRect(hx + 12, 102, 22, 18);
    n.fillStyle = '#3a2418'; n.fillRect(hx + 56, 108, 20, 38);
    n.fillStyle = '#f2e8a0'; n.fillRect(hx + 40, 96, 8, 4);
  }
  // the train waiting at the far end - the boss arena
  const tx = len - 300;
  n.fillStyle = '#0e0c14'; n.fillRect(tx, 40, L.near.width - tx, 108);
  n.fillStyle = '#3a3a4a'; n.fillRect(tx + 10, 52, L.near.width - tx, 96);
  n.fillStyle = '#f2c020'; n.fillRect(tx + 10, 52, L.near.width - tx, 4);
  for (let k = tx + 24; k < L.near.width; k += 40) {
    n.fillStyle = '#1a2a3a'; n.fillRect(k, 70, 26, 22);
    n.fillStyle = '#6a9ac8'; n.fillRect(k + 2, 72, 22, 18);
    if (R() < 0.5) { n.fillStyle = 'rgba(0,0,0,0.5)'; n.fillRect(k + 8, 76, 8, 14);
      n.beginPath(); n.arc(k + 12, 75, 3.4, 0, 7); n.fill(); }
  }
  ballast(n, L, R, r, 148, '#2c2a30', '#3a3840', '#201e26');
  // four roads of track with real point work between them
  for (const ry of [170, 206]) railPair(n, L, R, ry);
  for (let px_ = 220; px_ < L.near.width; px_ += 520) {  // a turnout: the rails converge
    n.strokeStyle = '#8a8a96'; n.lineWidth = 2;
    n.beginPath(); n.moveTo(px_, 201); n.lineTo(px_ + 120, 175); n.stroke();
    n.beginPath(); n.moveTo(px_, 210); n.lineTo(px_ + 120, 184); n.stroke();
    n.fillStyle = '#4a4450'; n.fillRect(px_ - 26, 196, 22, 14);              // the point motor
    n.fillStyle = '#6a6474'; n.fillRect(px_ - 26, 196, 22, 3);
    n.fillStyle = '#e8c020'; n.fillRect(px_ - 22, 186, 5, 11);               // the lever and target
    n.fillStyle = '#e8e8f0'; n.fillRect(px_ - 26, 182, 13, 5);
  }
  for (let px_ = 300; px_ < L.near.width - 200; px_ += 460) {                 // signal posts
    n.fillStyle = '#16141c'; n.fillRect(px_, 70, 5, 96); n.fillRect(px_ - 6, 62, 17, 26);
    const on = R() < 0.5;
    n.fillStyle = on ? '#3ae05a' : '#e02a3a'; n.beginPath(); n.arc(px_ + 2.5, 70, 4, 0, 7); n.fill();
    n.fillStyle = `rgba(${on ? '58,224,90' : '224,42,58'},0.14)`; n.beginPath(); n.arc(px_ + 2.5, 70, 11, 0, 7); n.fill();
  }
  // yard clutter: sleeper stacks, oil drums, a bogie, rail off the track
  let ci = 0;
  for (let px_ = 90; px_ < L.near.width - 60; px_ += 190 + R() * 90) {
    const kind = ci % 4; ci++;
    if (kind === 0) { for (let k = 0; k < 5; k++) { n.fillStyle = k % 2 ? '#3a3028' : '#463a2e';
      n.fillRect(px_, 224 - k * 5, 54, 5); } }
    else if (kind === 1) { for (let k = 0; k < 3; k++) {
      n.fillStyle = pick2(R, ['#2a5a3a', '#6a3a2a', '#3a4a6a']);
      n.fillRect(px_ + k * 16, 198, 14, 22);
      n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(px_ + k * 16, 198, 14, 2);
      n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(px_ + k * 16, 206, 14, 2); } }
    else if (kind === 2) { n.fillStyle = '#2a2830'; n.fillRect(px_, 206, 48, 10);
      for (const wx of [px_ + 10, px_ + 38]) { n.fillStyle = '#26242c'; n.beginPath(); n.arc(wx, 218, 7, 0, 7); n.fill();
        n.fillStyle = '#3c3a46'; n.beginPath(); n.arc(wx, 218, 3, 0, 7); n.fill(); } }
    else { n.fillStyle = '#6a6a76'; n.save(); n.translate(px_, 222); n.rotate(-0.06);
      n.fillRect(0, 0, 70, 4); n.fillRect(0, -2, 70, 2); n.restore(); }
  }
}

// ---- A2: THE ROUNDHOUSE ---------------------------------------------------
// Inside the engine shed: a turntable, locomotives nose-in around it, smoke
// vents in a curved roof, inspection pits in the floor.
function s4a_roundhouse(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0d0a10'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 120) {          // the far wall of the shed, lost in soot
    m.fillStyle = '#17131a'; m.fillRect(x, 40, 112, 110);
    m.fillStyle = '#1e1920'; m.fillRect(x + 8, 52, 40, 40);
  }
  // near: the roof structure - trusses and smoke vents over every road
  n.fillStyle = '#1a1620'; n.fillRect(0, 0, L.near.width, 150);
  for (let x = 0; x < L.near.width; x += 150) {
    n.fillStyle = '#2a2430'; n.fillRect(x, 0, 6, 150);                       // the column
    n.fillStyle = '#382f40'; n.fillRect(x + 1, 0, 2, 150);
    n.strokeStyle = '#2a2430'; n.lineWidth = 4;                              // the truss
    n.beginPath(); n.moveTo(x, 34); n.lineTo(x + 75, 12); n.lineTo(x + 150, 34); n.stroke();
    n.strokeStyle = '#241f2c'; n.lineWidth = 2;
    for (let k = 0; k < 5; k++) { n.beginPath(); n.moveTo(x + 15 + k * 30, 34); n.lineTo(x + 40 + k * 22, 18); n.stroke(); }
    // the smoke vent, with the night sky showing through it
    n.fillStyle = '#0a0812'; n.fillRect(x + 54, 2, 44, 12);
    for (let k = 0; k < 40; k += 6) { n.fillStyle = '#2a2430'; n.fillRect(x + 56 + k, 2, 3, 12); }
    n.fillStyle = 'rgba(160,180,220,0.06)'; n.fillRect(x + 50, 14, 52, 50);
    // lamps on hooks down the roads
    n.fillStyle = '#16121c'; n.fillRect(x + 72, 34, 2, 14);
    n.fillStyle = '#ffe8a0'; n.beginPath(); n.arc(x + 73, 51, 5, 0, 7); n.fill();
    n.fillStyle = 'rgba(255,232,160,0.10)'; n.beginPath(); n.arc(x + 73, 54, 22, 0, 7); n.fill();
  }
  // the locomotives, nose-in on their roads
  for (let x = 20; x < len - 340; x += 190) {
    const c = pick2(R, ['#1e2a22', '#2a1e1e', '#1e2230', '#2a2418']);
    n.fillStyle = '#0a080e'; n.fillRect(x - 2, 58, 130, 92);
    n.fillStyle = c; n.fillRect(x, 60, 126, 88);
    n.fillStyle = 'rgba(255,255,255,0.07)'; n.fillRect(x, 60, 126, 3);
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, 130, 126, 18);
    n.fillStyle = '#12100f'; n.beginPath(); n.arc(x + 63, 104, 34, 0, 7); n.fill();   // smokebox door
    n.fillStyle = '#26242a'; n.beginPath(); n.arc(x + 63, 104, 30, 0, 7); n.fill();
    n.fillStyle = '#4a4650'; n.beginPath(); n.arc(x + 63, 104, 6, 0, 7); n.fill();
    n.fillStyle = '#6a5a3a'; n.fillRect(x + 60, 96, 6, 16);
    n.fillStyle = '#e8d070'; n.fillRect(x + 50, 70, 26, 10);                          // the lamp
    n.fillStyle = 'rgba(232,208,112,0.14)'; n.fillRect(x + 34, 78, 58, 60);
    n.fillStyle = '#c8302a'; n.fillRect(x + 20, 122, 86, 8);                          // buffer beam
    for (const bx of [x + 14, x + 106]) { n.fillStyle = '#39414e'; n.beginPath(); n.arc(bx, 126, 7, 0, 7); n.fill(); }
    n.fillStyle = '#2a2830'; n.fillRect(x + 16, 138, 94, 10);
  }
  // the turntable at the end: the pit, the deck and its girder
  const t0 = len - 340;
  n.fillStyle = '#100d14'; n.fillRect(t0, 60, L.near.width - t0, 90);
  n.fillStyle = 'rgba(180,200,240,0.05)'; n.fillRect(t0, 60, L.near.width - t0, 60);
  n.fillStyle = '#2a2632'; n.fillRect(t0 + 20, 126, L.near.width - t0 - 40, 24);
  n.fillStyle = '#39414e'; n.fillRect(t0 + 20, 126, L.near.width - t0 - 40, 4);
  n.strokeStyle = '#4a4450'; n.lineWidth = 3;
  n.beginPath(); n.moveTo(t0 + 30, 126); n.lineTo(t0 + 110, 96); n.lineTo(t0 + 190, 126); n.stroke();
  neonText(n, 'SHED 3', t0 + 60, 74, '#e8b020', 2);
  // the floor: oily setts, inspection pits and the rails into every road
  n.fillStyle = '#26232a'; n.fillRect(0, 150, L.near.width, 90);
  for (let y = 150; y < 240; y += 8) for (let x2 = 0; x2 < L.near.width; x2 += 11) {
    n.fillStyle = R() < 0.5 ? '#2c2930' : '#211e26';
    n.fillRect(x2 + ((Math.round(y / 8)) % 2) * 5, y, 10, 7);
  }
  for (let px_ = 40; px_ < L.near.width; px_ += 190) {                        // inspection pits
    n.fillStyle = '#0a090d'; n.fillRect(px_, 180, 96, 24);
    n.fillStyle = '#16141a'; n.fillRect(px_ + 3, 183, 90, 18);
    n.fillStyle = 'rgba(232,208,112,0.10)'; n.fillRect(px_ + 8, 186, 80, 12);
    n.fillStyle = '#4a4450'; n.fillRect(px_, 178, 96, 3); n.fillRect(px_, 203, 96, 3);
  }
  for (const ry of [172, 212]) railPair(n, L, R, ry, '#2a2520', '#7a7a86', '#a8a8b4');
  for (let k = 0; k < L.near.width / 90; k++) { n.fillStyle = 'rgba(0,0,0,0.34)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(158, 234), 16 + R() * 18, 5 + R() * 4, 0, 0, 7); n.fill(); }
  L.steamShed = 1;
}

// ---- A3: THE CUTTING ------------------------------------------------------
// A deep railway cutting: retaining walls either side, a signal gantry across
// the top, and a tunnel mouth at the end for the fight.
function s4a_cutting(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  nightSky(f, L, R, r, '#06050e', '#161232', '#38204a');
  f.fillStyle = '#0c0a18'; f.fillRect(0, 96, L.far.width, 60);
  for (let x = 0; x < L.far.width; x += 40) { const h = 10 + R() * 22;      // rooftops above the cutting
    f.fillStyle = '#151024'; f.fillRect(x, 96 - h, 36, h + 10);
    if (R() < 0.4) { f.fillStyle = '#c8a048'; f.fillRect(x + 8 + R() * 18, 100 - h, 3, 3); } }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  // near: the retaining wall, stepped back in stages, weeds in every joint
  const WALLTOP = 30;
  for (let x = 0; x < L.near.width; x += 96) {
    brick(n, x, WALLTOP, 96, 118, pick2(R, ['#3c2a26', '#33292c', '#412e26']), R, { course: 6, bw: 13 });
    n.fillStyle = '#4a3a30'; n.fillRect(x, WALLTOP, 96, 5);                  // the coping
    n.fillStyle = '#5c4a3c'; n.fillRect(x, WALLTOP, 96, 2);
    // the buttress piers that hold it back
    n.fillStyle = '#332420'; n.fillRect(x + 78, WALLTOP + 5, 18, 113);
    n.fillStyle = '#3f2c27'; n.fillRect(x + 80, WALLTOP + 5, 6, 113);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 94, WALLTOP + 5, 4, 113);
    // drainage weeping down the face, and buddleia growing out of it
    for (let k = 0; k < 3; k++) { const dx = x + 12 + R() * 56;
      n.fillStyle = 'rgba(40,60,45,0.30)'; n.fillRect(dx, WALLTOP + 10 + R() * 40, 5, 60 + R() * 40); }
    for (let k = 0; k < 4; k++) { const wx = x + 8 + R() * 70, wy = WALLTOP + 20 + R() * 90;
      n.fillStyle = '#2f4a2e';
      for (let b = 0; b < 4; b++) n.fillRect(wx + (R() - 0.5) * 8, wy - b * 3, 4, 4);
      if (R() < 0.4) { n.fillStyle = '#6a4a7a'; n.fillRect(wx, wy - 12, 4, 6); } }
    if (R() < 0.35) {                                                        // a relay cabinet on a plinth
      const cx = x + 20 + R() * 40;
      n.fillStyle = '#2a3a32'; n.fillRect(cx, 122, 26, 26);
      n.fillStyle = '#365046'; n.fillRect(cx, 122, 26, 3);
      n.fillStyle = '#1a2620'; n.fillRect(cx + 5, 130, 16, 10);
    }
  }
  // the signal gantry spanning the cutting, and the cable route along the wall
  for (let x = 180; x < L.near.width; x += 520) {
    n.fillStyle = '#16141c'; n.fillRect(x, 6, L.near.width > x + 240 ? 240 : 120, 8);
    n.fillStyle = '#242029'; n.fillRect(x, 6, 240, 2);
    for (let k = 0; k < 240; k += 18) { n.strokeStyle = '#16141c'; n.lineWidth = 2;
      n.beginPath(); n.moveTo(x + k, 14); n.lineTo(x + k + 9, 26); n.lineTo(x + k + 18, 14); n.stroke(); }
    n.fillStyle = '#16141c'; n.fillRect(x - 6, 6, 10, 34); n.fillRect(x + 236, 6, 10, 34);
    for (let s = 0; s < 3; s++) {
      const sx = x + 40 + s * 76;
      n.fillStyle = '#1a1620'; n.fillRect(sx, 26, 18, 30);
      const on = R() < 0.4;
      n.fillStyle = on ? '#3ae05a' : '#e02a3a'; n.beginPath(); n.arc(sx + 9, 36, 5, 0, 7); n.fill();
      n.fillStyle = `rgba(${on ? '58,224,90' : '224,42,58'},0.13)`; n.beginPath(); n.arc(sx + 9, 36, 14, 0, 7); n.fill();
    }
  }
  n.fillStyle = '#2a2a32'; n.fillRect(0, 130, L.near.width, 7);
  for (let x = 0; x < L.near.width; x += 34) { n.fillStyle = '#3a3a46'; n.fillRect(x, 128, 6, 11); }
  // the tunnel mouth: the arena
  const t0 = len - 320;
  n.fillStyle = '#1e1620'; n.fillRect(t0, 0, L.near.width - t0, 150);
  const tw2 = L.near.width - t0;
  n.fillStyle = '#4a3730';
  n.beginPath(); n.moveTo(t0 + 20, 150); n.lineTo(t0 + 20, 66);
  n.arc(t0 + tw2 / 2, 66, tw2 / 2 - 20, Math.PI, 0); n.lineTo(t0 + tw2 - 20, 150); n.fill();
  n.fillStyle = '#080609';
  n.beginPath(); n.moveTo(t0 + 34, 150); n.lineTo(t0 + 34, 70);
  n.arc(t0 + tw2 / 2, 70, tw2 / 2 - 34, Math.PI, 0); n.lineTo(t0 + tw2 - 34, 150); n.fill();
  for (let k = 0; k < 26; k++) {                                              // voussoirs round the arch
    const a = Math.PI + k * Math.PI / 25, rr = tw2 / 2 - 27;
    n.fillStyle = k % 2 ? '#5c4438' : '#4a3730';
    n.fillRect(t0 + tw2 / 2 + Math.cos(a) * rr - 4, 68 + Math.sin(a) * rr - 4, 9, 9);
  }
  n.fillStyle = 'rgba(200,160,90,0.10)'; n.fillRect(t0 + 40, 90, tw2 - 80, 60);
  ballast(n, L, R, r, 148, '#312d2a', '#3f3a36', '#221f1d');
  for (const ry of [176, 212]) railPair(n, L, R, ry, '#33291f', '#8a8a96', '#c8c8d4');
  for (let k = 0; k < L.near.width / 40; k++) { n.fillStyle = '#2f4a2e';      // weeds in the four-foot
    const wx = r(0, L.near.width), wy = r(156, 234);
    for (let b = 0; b < 3; b++) n.fillRect(wx + (R() - 0.5) * 5, wy - b * 3, 3, 3); }
  puddles(n, R, L.near.width, 160, 234, 14, 'rgba(90,120,170,0.20)');
}

// ---- A4: THE CONTAINER TERMINAL -------------------------------------------
// The wildcard: an intermodal yard. Blocks of stacked boxes, a rail-mounted
// gantry straddling overhead, painted lanes and reach stackers.
function s4a_terminal(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  nightSky(f, L, R, r, '#04060f', '#10182e', '#2c3050');
  skyline(f, L, R, r, 128, '#0c1020', '#c8b060', 18, 56);
  for (let x = 0; x < L.far.width; x += 110) {          // ship cranes on the horizon
    f.fillStyle = '#131a2c'; f.fillRect(x, 74, 4, 54); f.fillRect(x - 26, 72, 70, 4); f.fillRect(x + 40, 76, 2, 20);
  }
  // mid: further blocks of containers, stacked four high
  for (let x = 0; x < L.mid.width; x += 74) {
    const hgt = 2 + Math.floor(R() * 3);
    for (let s = 0; s < hgt; s++) {
      m.fillStyle = pick2(R, ['#1e4a5e', '#5e2a22', '#28502e', '#5a4a1e', '#3a3a52']);
      m.fillRect(x, 150 - (s + 1) * 24, 70, 23);
      m.fillStyle = 'rgba(255,255,255,0.07)'; m.fillRect(x, 150 - (s + 1) * 24, 70, 2);
      m.fillStyle = 'rgba(0,0,0,0.28)'; m.fillRect(x, 150 - s * 24 - 3, 70, 3);
    }
  }
  // near: the gantry straddling the whole scene, and the container blocks
  n.fillStyle = '#39414e'; n.fillRect(0, 14, L.near.width, 14);
  n.fillStyle = '#4e5a6a'; n.fillRect(0, 14, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 12) { n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(x, 28, 4, 5); }
  for (let x = 40; x < L.near.width; x += 300) {
    n.fillStyle = '#39414e'; n.fillRect(x, 28, 12, 120);
    n.fillStyle = '#4e5a6a'; n.fillRect(x + 1, 28, 4, 120);
    n.strokeStyle = '#39414e'; n.lineWidth = 3;
    for (let k = 0; k < 120; k += 26) { n.beginPath(); n.moveTo(x + 12, 30 + k); n.lineTo(x + 40, 30 + k + 26); n.stroke(); }
    n.fillStyle = '#2a3038'; n.fillRect(x - 6, 144, 24, 6);
  }
  for (let x = 120; x < L.near.width; x += 420) {        // the spreader, hanging off the trolley
    n.fillStyle = '#2a3038'; n.fillRect(x, 4, 60, 12);
    n.fillStyle = '#e8b020'; n.fillRect(x + 6, 16, 48, 5);
    for (const cx of [x + 10, x + 46]) { n.fillStyle = '#4a5058'; n.fillRect(cx, 21, 3, 30); }
    n.fillStyle = '#e8b020'; n.fillRect(x + 2, 51, 56, 9);
    n.fillStyle = '#8a6a14'; n.fillRect(x + 2, 51, 56, 2);
  }
  let x = 0;
  while (x < len - 330) {
    const bw = 116, hgt = 1 + Math.floor(R() * 3);
    for (let s = 0; s < hgt; s++) {
      const c = pick2(R, ['#1e6a86', '#8a3a2a', '#2a7a44', '#8a6a1e', '#4a4a6a', '#a04a6a']);
      const cy = 148 - (s + 1) * 30;
      n.fillStyle = '#0d1016'; n.fillRect(x - 2, cy - 2, bw + 4, 32);
      n.fillStyle = c; n.fillRect(x, cy, bw, 28);
      for (let k = x + 4; k < x + bw - 3; k += 7) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(k, cy + 2, 3, 24); }
      n.fillStyle = 'rgba(255,255,255,0.12)'; n.fillRect(x, cy, bw, 2);
      n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, cy + 26, bw, 2);
      n.fillStyle = '#16181f';                                              // corner castings
      n.fillRect(x, cy, 7, 6); n.fillRect(x + bw - 7, cy, 7, 6);
      n.fillRect(x, cy + 22, 7, 6); n.fillRect(x + bw - 7, cy + 22, 7, 6);
      if (s === hgt - 1) { n.fillStyle = 'rgba(255,255,255,0.75)';
        ptext(n, pick2(R, ['MAERSK', 'HAPAG', 'EVERG', 'COSCO', 'SYND']), x + 14, cy + 9, 'rgba(255,255,255,0.72)', 1);
        ptext(n, String(Math.floor(R() * 900000) + 100000), x + 14, cy + 18, 'rgba(255,255,255,0.45)', 1); }
      if (R() < 0.25) { n.fillStyle = 'rgba(0,0,0,0.22)';                   // the doors on the end
        n.fillRect(x + bw - 34, cy + 2, 32, 24);
        n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(x + bw - 18, cy + 2, 2, 24); }
    }
    x += bw + 6;
  }
  // the reach stacker and the arena at the end
  const a0 = len - 330;
  n.fillStyle = '#0f131a'; n.fillRect(a0, 40, L.near.width - a0, 108);
  for (let k = 0; k < 70; k++) { n.fillStyle = '#c8b060'; n.fillRect(r(a0, L.near.width), r(50, 120), 1, 1); }
  const sx = a0 + 60;
  n.fillStyle = '#16181f'; n.fillRect(sx, 96, 130, 52);
  n.fillStyle = '#e8a020'; n.fillRect(sx + 2, 98, 126, 48);
  n.fillStyle = '#b87a10'; n.fillRect(sx + 2, 130, 126, 16);
  n.fillStyle = '#1e2a3a'; n.fillRect(sx + 88, 104, 34, 22);
  n.fillStyle = 'rgba(180,220,255,0.25)'; n.fillRect(sx + 91, 106, 14, 18);
  n.strokeStyle = '#c88a10'; n.lineWidth = 11;
  n.beginPath(); n.moveTo(sx + 40, 100); n.lineTo(sx - 46, 48); n.stroke();
  n.strokeStyle = '#e8a020'; n.lineWidth = 7; n.stroke();
  n.fillStyle = '#39414e'; n.fillRect(sx - 60, 42, 26, 14);
  n.fillStyle = '#16181f'; n.beginPath(); n.arc(sx + 26, 148, 13, 0, 7); n.arc(sx + 104, 148, 11, 0, 7); n.fill();
  // the deck: hardstanding with painted lanes and rail let into it
  n.fillStyle = '#34353c'; n.fillRect(0, 148, L.near.width, 92);
  for (let k = 0; k < L.near.width * 1.5; k++) { n.fillStyle = R() < 0.5 ? '#3c3d45' : '#2c2d34';
    n.fillRect(r(0, L.near.width), r(150, 240), 3, 1); }
  for (let px_ = 0; px_ < L.near.width; px_ += 58) { n.fillStyle = 'rgba(0,0,0,0.14)'; n.fillRect(px_, 148, 2, 92); }
  n.fillStyle = '#25262c'; n.fillRect(0, 148, L.near.width, 3);
  for (let px_ = 0; px_ < L.near.width; px_ += 116) { n.fillStyle = 'rgba(232,200,60,0.65)'; n.fillRect(px_, 164, 60, 3); }
  for (let px_ = 0; px_ < L.near.width; px_ += 116) { n.fillStyle = 'rgba(232,232,224,0.40)'; n.fillRect(px_ + 20, 198, 3, 40); }
  railPair(n, L, R, 220, '#2a2a30', '#7a7a86', '#a8a8b4');
  for (let k = 0; k < L.near.width / 150; k++) { n.fillStyle = 'rgba(0,0,0,0.26)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(180, 234), 14 + R() * 16, 4 + R() * 4, 0, 0, 7); n.fill(); }
}
