// ============================================================ STAGE 4-B options
// The moving scene. The far and mid layers wrap and rush past on their own
// (L.speed), the near layer is the train and stays put under your feet, and
// drawSpeedLines streaks over the top. Everything here is built for motion.

// the world rushing past, shared by all four: embankment, poles, wires
function rushingWorld(f, m, L, R, r, opts = {}) {
  nightSky(f, L, R, r, opts.sky0 || '#04030c', opts.sky1 || '#100c28', opts.sky2 || '#2e1a40');
  skyline(f, L, R, r, 150, opts.city || '#0c0a1c', opts.lit || '#c8a048', 24, 70);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 74) {
    m.fillStyle = '#100e1a'; m.fillRect(x, 20, 5, 130);
    m.fillRect(x - 10, 24, 25, 3);
    m.strokeStyle = 'rgba(20,18,30,0.9)'; m.lineWidth = 1;
    m.beginPath(); m.moveTo(x, 28); m.quadraticCurveTo(x + 37, 44, x + 74, 28); m.stroke();
    m.beginPath(); m.moveTo(x, 34); m.quadraticCurveTo(x + 37, 52, x + 74, 34); m.stroke();
    if ((x / 74) % 4 === 0) { m.fillStyle = '#e8e8f0'; m.fillRect(x - 4, 14, 13, 5); }
  }
}
function embankment(n, L, R, r, top, a, b) {
  n.fillStyle = a; n.fillRect(0, top, L.near.width, 150 - top);
  for (let k = 0; k < L.near.width * 1.2; k++) { n.fillStyle = R() < 0.5 ? b : a;
    n.fillRect(r(0, L.near.width), r(top + 2, 148), r(14, 44), 2); }
  for (let x = 0; x < L.near.width; x += 130) { n.fillStyle = '#241f38'; n.fillRect(x, top - 8, 44, 46);
    n.fillStyle = '#2e2846'; n.fillRect(x, top - 8, 44, 2); }
  n.fillStyle = '#1a2030'; n.fillRect(0, 144, L.near.width, 8);
}
// the gap between one vehicle and the next, with the sleepers flashing below
function couplingGap(n, x, w, top) {
  n.fillStyle = '#0a0a10'; n.fillRect(x, top, w, 240 - top);
  for (let k = 0; k < 240 - top; k += 9) { n.fillStyle = 'rgba(70,60,50,0.55)'; n.fillRect(x, top + k, w, 4); }
  n.fillStyle = '#2a2830'; n.fillRect(x - 3, top, 4, 240 - top);
  n.fillStyle = '#2a2830'; n.fillRect(x + w - 1, top, 4, 240 - top);
  n.fillStyle = '#39414e'; n.fillRect(x + w / 2 - 7, top + 8, 14, 16);        // the coupling itself
  n.fillStyle = '#4e5a6a'; n.fillRect(x + w / 2 - 5, top + 10, 10, 4);
  n.strokeStyle = '#2a2830'; n.lineWidth = 2;                                  // the brake pipes
  n.beginPath(); n.moveTo(x + 2, top + 26); n.quadraticCurveTo(x + w / 2, top + 40, x + w - 2, top + 26); n.stroke();
}

// ---- B1: THE ROOF ---------------------------------------------------------
function s4b_roof(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  rushingWorld(f, m, L, R, r);
  L.speed = 1;
  embankment(n, L, R, r, 112, '#0a0818', '#1c1a30');
  // the roof: plates, seams, rivets, vents, hatches and the running board
  n.fillStyle = '#39414e'; n.fillRect(0, 150, L.near.width, 90);
  n.fillStyle = '#2b323d'; n.fillRect(0, 150, L.near.width, 4);
  n.fillStyle = '#48525f'; n.fillRect(0, 232, L.near.width, 8);
  for (let x = 0; x < L.near.width; x += 64) {
    n.fillStyle = '#242a34'; n.fillRect(x, 150, 2, 90);
    n.fillStyle = '#525d6c'; n.fillRect(x + 2, 150, 1, 90);
  }
  for (let y = 162; y < 232; y += 18) { n.fillStyle = 'rgba(0,0,0,0.14)'; n.fillRect(0, y, L.near.width, 2); }
  for (let x = 16; x < L.near.width; x += 32) for (let y = 156; y < 236; y += 24) {
    n.fillStyle = '#6a7484'; n.fillRect(x, y, 2, 2); n.fillStyle = '#20262e'; n.fillRect(x, y + 2, 2, 1);
  }
  // the raised running board down the centre - the safe strip you fight on
  n.fillStyle = '#4e5765'; n.fillRect(0, 184, L.near.width, 24);
  n.fillStyle = '#5f6a79'; n.fillRect(0, 184, L.near.width, 3);
  n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(0, 205, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 13) { n.fillStyle = 'rgba(0,0,0,0.18)'; n.fillRect(x, 187, 3, 18); }
  let pi = 0;
  for (let x = 90; x < L.near.width; x += 150 + R() * 80) {
    const kind = pi % 3; pi++;
    if (kind === 0) { n.fillStyle = '#1c222a'; n.fillRect(x, 160, 32, 18);       // roof vent
      n.fillStyle = '#39414e'; n.fillRect(x + 2, 162, 28, 14);
      n.fillStyle = '#5a6472'; for (let k = 0; k < 4; k++) n.fillRect(x + 4, 164 + k * 3, 24, 1); }
    else if (kind === 1) { n.fillStyle = '#242c36'; n.beginPath(); n.ellipse(x, 218, 17, 7, 0, 0, 7); n.fill();
      n.fillStyle = '#4a5462'; n.beginPath(); n.ellipse(x, 216, 16, 6, 0, 0, 7); n.fill();
      n.fillStyle = '#20262e'; n.fillRect(x - 2, 209, 4, 4); }
    else { n.fillStyle = '#2a323c'; n.fillRect(x, 154, 26, 10);                   // a small skylight, lit
      n.fillStyle = '#e8c878'; n.fillRect(x + 2, 156, 22, 6);
      n.fillStyle = 'rgba(232,200,120,0.14)'; n.fillRect(x - 4, 162, 34, 14); }
  }
  for (let x = 320; x < L.near.width; x += 640) couplingGap(n, x, 22, 150);
}

// ---- B2: THE FLATBEDS -----------------------------------------------------
// A string of flat wagons, each carrying something different. The footing
// changes every wagon and the gaps between them are real.
function s4b_flats(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  rushingWorld(f, m, L, R, r, { sky0: '#05040e', sky1: '#141034', sky2: '#3a1e44' });
  L.speed = 1;
  embankment(n, L, R, r, 112, '#0a0818', '#1c1a30');
  const DECK = 186;
  let x = 0, wi = 0;
  while (x < L.near.width) {
    const ww = 240;
    // the wagon deck: timber planking on a steel frame
    n.fillStyle = '#5a4630'; n.fillRect(x, DECK, ww, 240 - DECK);
    for (let px_ = x; px_ < x + ww; px_ += 12) {
      n.fillStyle = R() < 0.5 ? '#624c34' : '#4f3e2b'; n.fillRect(px_, DECK, 11, 240 - DECK);
      n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(px_ + 11, DECK, 1.5, 240 - DECK);
    }
    n.fillStyle = '#39414e'; n.fillRect(x, DECK - 6, ww, 7);                   // the solebar
    n.fillStyle = '#4e5a6a'; n.fillRect(x, DECK - 6, ww, 2);
    for (let k = 0; k < ww; k += 16) { n.fillStyle = '#6a7484'; n.fillRect(x + k + 3, DECK - 4, 2, 2); }
    n.fillStyle = '#e8c020'; n.fillRect(x, 232, ww, 4);                        // the deck edge stripe
    for (let k = 0; k < ww; k += 16) { n.fillStyle = '#1a1a1e'; n.fillRect(x + k, 232, 8, 4); }
    // the load: different every wagon, and it is what you fight around
    const kind = wi % 4;
    if (kind === 0) {                                                          // timber bundles
      for (let s = 0; s < 2; s++) for (let b = 0; b < 3; b++) {
        const bx = x + 26 + b * 66, by = DECK - 20 - s * 18;
        n.fillStyle = '#7a5a34'; n.fillRect(bx, by, 58, 17);
        for (let k = 0; k < 58; k += 6) { n.fillStyle = pick2(R, ['#8a6a40', '#6a4a2a', '#94764a']);
          n.beginPath(); n.arc(bx + 3 + k, by + 8, 3, 0, 7); n.fill(); }
        n.fillStyle = '#2a2830'; n.fillRect(bx + 12, by, 3, 17); n.fillRect(bx + 44, by, 3, 17);
      }
    } else if (kind === 1) {                                                   // steel coil in cradles
      for (let c = 0; c < 2; c++) {
        const cx = x + 66 + c * 110;
        n.fillStyle = '#2a2830'; n.fillRect(cx - 34, DECK - 8, 68, 9);
        n.fillStyle = '#7a8290'; n.beginPath(); n.ellipse(cx, DECK - 30, 34, 26, 0, 0, 7); n.fill();
        n.fillStyle = '#8f98a6'; n.beginPath(); n.ellipse(cx, DECK - 34, 30, 20, 0, 0, 7); n.fill();
        n.fillStyle = '#2f353f'; n.beginPath(); n.ellipse(cx, DECK - 32, 10, 8, 0, 0, 7); n.fill();
        for (let k = 0; k < 7; k++) { n.fillStyle = 'rgba(0,0,0,0.16)';
          n.beginPath(); n.ellipse(cx, DECK - 32, 13 + k * 3, 10 + k * 2.4, 0, 0, 7); n.stroke(); }
        n.strokeStyle = '#c8b090'; n.lineWidth = 2;
        n.beginPath(); n.moveTo(cx - 36, DECK - 6); n.lineTo(cx, DECK - 56); n.lineTo(cx + 36, DECK - 6); n.stroke();
      }
    } else if (kind === 2) {                                                   // a tarped machine
      n.fillStyle = pick2(R, ['#2a5a3a', '#3a3a5a', '#5a3a2a']);
      n.beginPath(); n.moveTo(x + 30, DECK); n.lineTo(x + 58, DECK - 54);
      n.lineTo(x + 182, DECK - 54); n.lineTo(x + 210, DECK); n.fill();
      n.fillStyle = 'rgba(0,0,0,0.22)';
      for (let k = 0; k < 6; k++) n.fillRect(x + 48 + k * 26, DECK - 54, 4, 54);
      n.fillStyle = 'rgba(255,255,255,0.08)'; n.fillRect(x + 58, DECK - 54, 124, 3);
      n.strokeStyle = '#c8b090'; n.lineWidth = 1.5;
      for (let k = 0; k < 5; k++) { n.beginPath(); n.moveTo(x + 36 + k * 36, DECK);
        n.lineTo(x + 52 + k * 32, DECK - 56); n.stroke(); }
    } else {                                                                    // empty, with stanchions up
      for (let k = 0; k < 8; k++) { n.fillStyle = '#39414e'; n.fillRect(x + 18 + k * 28, DECK - 26, 4, 27);
        n.fillStyle = '#4e5a6a'; n.fillRect(x + 18 + k * 28, DECK - 26, 4, 2); }
      n.fillStyle = '#4a3a28'; n.fillRect(x + 40, DECK - 10, 60, 11);           // a pallet left on it
      for (let k = 0; k < 60; k += 9) { n.fillStyle = '#5c4a34'; n.fillRect(x + 40 + k, DECK - 10, 6, 11); }
    }
    couplingGap(n, x + ww - 14, 20, DECK - 6);
    x += ww; wi++;
  }
}

// ---- B3: THE TANKER TRAIN -------------------------------------------------
// Curved tank tops with a walkway along the spine. Round underfoot, with
// handrails you can be thrown over.
function s4b_tankers(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  rushingWorld(f, m, L, R, r, { sky0: '#06040c', sky1: '#161024', sky2: '#42203a' });
  L.speed = 1;
  embankment(n, L, R, r, 116, '#0a0816', '#1e1a2c');
  let x = 0, wi = 0;
  while (x < L.near.width) {
    const ww = 232, TOP = 158;
    // the barrel, seen from just above: a long cylinder with the light on top
    n.fillStyle = '#16181f'; n.fillRect(x, TOP - 6, ww, 92);
    const c = pick2(R, ['#7a828e', '#6a7682', '#8a8070', '#5f6a74']);
    n.fillStyle = c; n.fillRect(x, TOP, ww, 82);
    n.fillStyle = 'rgba(255,255,255,0.16)'; n.fillRect(x, TOP, ww, 12);
    n.fillStyle = 'rgba(255,255,255,0.08)'; n.fillRect(x, TOP + 12, ww, 8);
    n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x, TOP + 58, ww, 12);
    n.fillStyle = 'rgba(0,0,0,0.34)'; n.fillRect(x, TOP + 70, ww, 12);
    for (let px_ = x; px_ < x + ww; px_ += 58) {                    // the barrel rings
      n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(px_, TOP, 3, 82);
      n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(px_ + 3, TOP, 1.5, 82);
    }
    for (let k = 0; k < 14; k++) { n.fillStyle = 'rgba(160,120,70,0.16)';       // streaked rust
      n.fillRect(x + R() * ww, TOP + 14 + R() * 60, 4 + R() * 12, 3); }
    // the walkway along the spine, which is the actual footing
    n.fillStyle = '#39414e'; n.fillRect(x, 186, ww, 22);
    for (let px_ = x; px_ < x + ww; px_ += 8) { n.fillStyle = '#4b5666'; n.fillRect(px_, 186, 5, 22);
      n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(px_ + 5, 186, 3, 22); }
    n.fillStyle = '#5f6b7c'; n.fillRect(x, 186, ww, 2);
    n.fillStyle = 'rgba(0,0,0,0.32)'; n.fillRect(x, 206, ww, 2);
    // handrails either side of it
    for (const ry of [176, 216]) {
      n.fillStyle = '#c8b030'; n.fillRect(x, ry, ww, 2);
      for (let px_ = x; px_ < x + ww; px_ += 38) { n.fillStyle = '#8a7a20'; n.fillRect(px_, ry, 3, 10); }
    }
    // the dome, the valve gear and the placards
    const dx = x + ww / 2;
    n.fillStyle = '#2a3038'; n.fillRect(dx - 24, TOP - 16, 48, 18);
    n.fillStyle = '#3e4650'; n.fillRect(dx - 22, TOP - 14, 44, 5);
    n.fillStyle = '#5a6470'; n.beginPath(); n.arc(dx, TOP - 18, 8, Math.PI, 0); n.fill();
    n.fillStyle = '#c8302a'; n.fillRect(dx + 12, TOP - 26, 5, 10);
    n.fillStyle = '#e8c020'; n.fillRect(x + 28, TOP + 30, 30, 20);              // hazard placard
    n.fillStyle = '#1a1a1e'; n.fillRect(x + 31, TOP + 33, 24, 14);
    ptext(n, '1203', x + 33, TOP + 37, '#e8c020', 1);
    n.fillStyle = 'rgba(255,255,255,0.65)';
    ptext(n, 'FLAMMABLE', x + ww - 90, TOP + 36, 'rgba(255,255,255,0.55)', 1);
    // the ladder and end platform where one tank meets the next
    n.fillStyle = '#39414e'; n.fillRect(x + ww - 20, 166, 20, 4); n.fillRect(x + ww - 20, 226, 20, 4);
    couplingGap(n, x + ww - 16, 24, 166);
    for (let k = 0; k < 5; k++) { n.fillStyle = '#4e5a6a'; n.fillRect(x + ww - 14, 172 + k * 11, 20, 2); }
    x += ww; wi++;
  }
}

// ---- B4: THE BRIDGE RUN ---------------------------------------------------
// The wildcard: the train is crossing a long girder bridge. The structure
// whips past on both sides, the river is a long way down, and the arena is the
// middle of the span where the steel opens out.
function s4b_bridge(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  nightSky(f, L, R, r, '#04040f', '#121036', '#38224e');
  // far: the far bank and the water, a long way below
  f.fillStyle = '#0c0a1c'; f.fillRect(0, 108, L.far.width, 18);
  for (let x = 0; x < L.far.width; x += 30) { const h = 6 + R() * 18;
    f.fillStyle = '#141028'; f.fillRect(x, 108 - h, 26, h + 12);
    if (R() < 0.45) { f.fillStyle = '#c8a048'; f.fillRect(x + 6 + R() * 14, 112 - h, 2, 2); } }
  f.fillStyle = '#080a1c'; f.fillRect(0, 126, L.far.width, 114);
  for (let k = 0; k < L.far.width * 1.6; k++) {
    f.fillStyle = R() < 0.14 ? 'rgba(170,190,240,0.20)' : 'rgba(22,30,64,0.55)';
    f.fillRect(r(0, L.far.width), r(128, 238), 6 + R() * 12, 1);
  }
  for (let k = 0; k < 120; k++) { f.fillStyle = 'rgba(232,200,120,0.16)';      // the lights' reflection
    f.fillRect(r(0, L.far.width), r(130, 210), 3, 1); }
  // mid: the far truss of the bridge, and the piers going down into the water
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 96) {
    m.fillStyle = '#1c1826'; m.fillRect(x, 46, 6, 104);
    m.strokeStyle = '#1c1826'; m.lineWidth = 4;
    m.beginPath(); m.moveTo(x + 3, 46); m.lineTo(x + 48, 96); m.lineTo(x + 96, 46); m.stroke();
    m.beginPath(); m.moveTo(x + 3, 96); m.lineTo(x + 48, 46); m.stroke();
  }
  m.fillStyle = '#1c1826'; m.fillRect(0, 40, L.mid.width, 8);
  m.fillStyle = '#272132'; m.fillRect(0, 40, L.mid.width, 2);
  L.speed = 1.5;
  // near: the deck you are on, and the near truss whipping past in front
  n.fillStyle = '#2f3641'; n.fillRect(0, 150, L.near.width, 90);
  for (let px_ = 0; px_ < L.near.width; px_ += 14) {                            // the deck: transverse timbers
    n.fillStyle = R() < 0.5 ? '#39414e' : '#333b47'; n.fillRect(px_, 150, 13, 90);
    n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(px_ + 13, 150, 2, 90);
  }
  n.fillStyle = '#242a34'; n.fillRect(0, 150, L.near.width, 4);
  for (const ry of [176, 214]) {                                                // the rails you are walking between
    n.fillStyle = '#8a8a96'; n.fillRect(0, ry, L.near.width, 4);
    n.fillStyle = '#c8c8d4'; n.fillRect(0, ry, L.near.width, 1.5);
    n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(0, ry + 4, L.near.width, 2);
  }
  // the near truss: verticals and diagonals in front of the fight, at speed
  for (let x = 0; x < L.near.width; x += 96) {
    n.fillStyle = '#463229'; n.fillRect(x, 14, 13, 136);
    n.fillStyle = '#5c4234'; n.fillRect(x + 2, 14, 4, 136);
    n.fillStyle = 'rgba(0,0,0,0.38)'; n.fillRect(x + 9, 14, 4, 136);
    n.strokeStyle = '#463229'; n.lineWidth = 9;
    n.beginPath(); n.moveTo(x + 6, 20); n.lineTo(x + 54, 96); n.lineTo(x + 102, 20); n.stroke();
    n.strokeStyle = '#3a2a22'; n.lineWidth = 6;
    n.beginPath(); n.moveTo(x + 6, 96); n.lineTo(x + 54, 20); n.stroke();
    for (let k = 0; k < 130; k += 16) { n.fillStyle = '#7d5c45'; n.fillRect(x + 3, 20 + k, 3, 3); n.fillRect(x + 8, 28 + k, 3, 3); }
    n.fillStyle = '#2a2a32'; n.fillRect(x - 3, 146, 19, 6);                     // the shoe on the deck
  }
  n.fillStyle = '#463229'; n.fillRect(0, 8, L.near.width, 12);                  // the top chord, overhead
  n.fillStyle = '#5c4234'; n.fillRect(0, 8, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 22) { n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(x, 20, 6, 4); }
  // the middle of the span: the steel opens out for the fight
  const a0 = len - 320;
  n.clearRect(a0 + 20, 8, 240, 142);
  n.fillStyle = '#463229'; n.fillRect(a0 + 20, 8, 240, 12);
  n.fillStyle = '#5c4234'; n.fillRect(a0 + 20, 8, 240, 3);
  for (const px_ of [a0 + 20, a0 + 250]) {
    n.fillStyle = '#463229'; n.fillRect(px_, 14, 14, 136);
    n.fillStyle = '#5c4234'; n.fillRect(px_ + 2, 14, 4, 136);
  }
  n.strokeStyle = '#463229'; n.lineWidth = 8;
  n.beginPath(); n.moveTo(a0 + 30, 22); n.lineTo(a0 + 136, 74); n.lineTo(a0 + 250, 22); n.stroke();
  n.fillStyle = '#c8302a'; n.fillRect(a0 + 110, 30, 58, 22);
  ptext(n, 'SPAN 7', a0 + 118, 37, '#f0e8e0', 1);
  n.fillStyle = '#2f3641'; n.fillRect(a0 + 20, 150, 240, 90);
  for (let px_ = a0 + 20; px_ < a0 + 260; px_ += 14) {
    n.fillStyle = R() < 0.5 ? '#39414e' : '#333b47'; n.fillRect(px_, 150, 13, 90);
    n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(px_ + 13, 150, 2, 90);
  }
  for (const ry of [176, 214]) {
    n.fillStyle = '#8a8a96'; n.fillRect(a0 + 20, ry, 240, 4);
    n.fillStyle = '#c8c8d4'; n.fillRect(a0 + 20, ry, 240, 1.5);
  }
}
