// ============================================================ STAGE 3-A options
// Ground level of the Syndicate's site. Every option needs something overhead
// that can credibly drop a girder, and a hole in the floor for the shaft hazard.

function siteDirt(n, L, R, r, base, a, b, c) {
  n.fillStyle = a; n.fillRect(0, base, L.near.width, 240 - base);
  for (let k = 0; k < L.near.width * 1.6; k++) { n.fillStyle = R() < 0.5 ? b : c;
    n.fillRect(r(0, L.near.width), r(base + 2, 240), 2, 1); }
  // tyre ruts churned down the length, and water standing in them
  for (const ry of [base + 26, base + 58]) for (let x = 0; x < L.near.width; x += 3) {
    n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x, ry + Math.sin(x * 0.04) * 3, 3, 7);
  }
  for (let k = 0; k < L.near.width / 120; k++) { n.fillStyle = 'rgba(90,110,130,0.26)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(base + 20, 236), 14 + R() * 22, 4 + R() * 4, 0, 0, 7); n.fill(); }
  n.fillStyle = c; n.fillRect(0, base, L.near.width, 3);
}
function towerCrane(m, x, R, h = 120, col = '#3a1a2a') {
  m.fillStyle = col;
  m.fillRect(x, 150 - h, 7, h);
  for (let k = 0; k < h; k += 11) { m.strokeStyle = col; m.lineWidth = 1.5;
    m.beginPath(); m.moveTo(x, 150 - h + k); m.lineTo(x + 7, 150 - h + k + 11); m.stroke();
    m.beginPath(); m.moveTo(x + 7, 150 - h + k); m.lineTo(x, 150 - h + k + 11); m.stroke(); }
  m.fillRect(x - 46, 150 - h - 8, 150, 4);
  m.fillRect(x - 46, 150 - h - 4, 6, 4);
  for (let k = -44; k < 102; k += 12) { m.strokeStyle = col; m.lineWidth = 1;
    m.beginPath(); m.moveTo(x + k, 150 - h - 4); m.lineTo(x + k + 6, 150 - h - 12); m.lineTo(x + k + 12, 150 - h - 4); m.stroke(); }
  m.fillRect(x - 4, 150 - h - 20, 15, 12);
  m.fillStyle = '#e8c860'; m.fillRect(x - 2, 150 - h - 18, 10, 5);
  // the hook, on its cable, with something on it
  const hx = x + 54;
  m.fillStyle = col; m.fillRect(hx, 150 - h - 4, 1.5, 40);
  m.fillStyle = '#e8b020'; m.fillRect(hx - 6, 150 - h + 36, 13, 7);
}

// ---- A1: THE FOUNDATION ---------------------------------------------------
function s3a_foundation(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const sky = f.createLinearGradient(0, 0, 0, 160);
  sky.addColorStop(0, '#2a1a3a'); sky.addColorStop(0.55, '#a8506a'); sky.addColorStop(1, '#f0a060');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  f.fillStyle = '#ffe0a0'; f.beginPath(); f.arc(330, 96, 16, 0, 7); f.fill();
  for (let k = 0; k < 9; k++) { f.fillStyle = 'rgba(255,220,200,0.18)'; f.fillRect(r(0, L.far.width), r(20, 90), r(40, 90), 3); }
  skyline(f, L, R, r, 140, '#4a2a4a', '#ffd070', 30, 92);
  for (let x = 40; x < L.mid.width; x += 250) towerCrane(m, x, R, 100 + R() * 34);
  // mid: the steel skeletons of the next plots
  for (let x = 0; x < L.mid.width; x += 150) {
    const h = 60 + R() * 54;
    m.strokeStyle = '#5a2a2a'; m.lineWidth = 2;
    for (let yy = 150; yy > 150 - h; yy -= 16) { m.beginPath(); m.moveTo(x, yy); m.lineTo(x + 66, yy); m.stroke(); }
    m.beginPath(); m.moveTo(x, 150); m.lineTo(x, 150 - h); m.moveTo(x + 66, 150); m.lineTo(x + 66, 150 - h); m.stroke();
    for (let yy = 150; yy > 166 - h; yy -= 16) { m.beginPath(); m.moveTo(x, yy); m.lineTo(x + 66, yy - 16); m.stroke(); }
  }
  // near: the hoarding, then everything a live site has standing about
  n.fillStyle = '#2a2430'; n.fillRect(0, 56, L.near.width, 88);
  n.strokeStyle = 'rgba(180,180,190,0.30)'; n.lineWidth = 1;
  for (let x = 0; x < L.near.width + 80; x += 7) {
    n.beginPath(); n.moveTo(x, 56); n.lineTo(x + 70, 142); n.stroke();
    n.beginPath(); n.moveTo(x, 56); n.lineTo(x - 70, 142); n.stroke();
  }
  for (let x = 0; x < L.near.width; x += 120) { n.fillStyle = '#7a7a86'; n.fillRect(x, 52, 3, 92); }
  for (let x = 30; x < L.near.width; x += 400) {
    n.fillStyle = '#1e5a3a'; n.fillRect(x, 66, 150, 52);
    n.fillStyle = '#2a7a4a'; n.fillRect(x, 66, 150, 3);
    ptext(n, 'SYNDICATE', x + 14, 76, '#e8e8e0', 1);
    ptext(n, 'DEVELOPMENTS', x + 14, 88, '#e8b020', 1);
    ptext(n, 'NO ADMITTANCE', x + 14, 104, '#8ab8a0', 1);
  }
  // site huts stacked two high, a concrete pump, rebar cages, a skip
  let si = 0;
  for (let x = 170; x < L.near.width - 120; x += 260) {
    const kind = si % 4; si++;
    if (kind === 0) {                                  // stacked cabins
      for (let s = 0; s < 2; s++) {
        const cy = 142 - 34 - s * 32;
        n.fillStyle = '#16141c'; n.fillRect(x, cy, 118, 33);
        n.fillStyle = pick2(R, ['#8a9aa8', '#c8c0a8', '#6a8a7a']); n.fillRect(x + 2, cy + 2, 114, 29);
        for (let k = 0; k < 114; k += 8) { n.fillStyle = 'rgba(0,0,0,0.12)'; n.fillRect(x + 2 + k, cy + 2, 2, 29); }
        n.fillStyle = '#2a3a4a'; n.fillRect(x + 12, cy + 8, 22, 14); n.fillRect(x + 76, cy + 8, 22, 14);
        n.fillStyle = 'rgba(200,230,255,0.25)'; n.fillRect(x + 13, cy + 9, 20, 12);
        n.fillStyle = '#3a2418'; n.fillRect(x + 48, cy + 6, 16, 25);
      }
      n.fillStyle = '#4a4a54'; n.fillRect(x + 40, 130, 34, 4);        // the stair to the top one
      for (let k = 0; k < 4; k++) n.fillRect(x + 40, 116 + k * 5, 26, 3);
    } else if (kind === 1) {                           // concrete pump with its boom folded
      n.fillStyle = '#16141c'; n.fillRect(x, 108, 104, 34);
      n.fillStyle = '#c8501e'; n.fillRect(x + 2, 110, 100, 30);
      n.fillStyle = '#8a3414'; n.fillRect(x + 2, 128, 100, 12);
      n.fillStyle = '#2a2a32'; n.fillRect(x + 14, 96, 68, 14);
      n.strokeStyle = '#c8501e'; n.lineWidth = 6;
      n.beginPath(); n.moveTo(x + 48, 96); n.lineTo(x + 30, 66); n.lineTo(x + 96, 58); n.stroke();
      n.fillStyle = '#16141c'; n.beginPath(); n.arc(x + 22, 140, 8, 0, 7); n.arc(x + 82, 140, 8, 0, 7); n.fill();
      for (let k = 0; k < 4; k++) { n.fillStyle = (k % 2) ? '#e8c020' : '#1a1a1e'; n.fillRect(x + 2 + k * 25, 136, 25, 4); }
    } else if (kind === 2) {                           // rebar cages and a bundle of bar
      for (let s = 0; s < 3; s++) {
        const cx = x + s * 34;
        n.strokeStyle = '#6a5a4a'; n.lineWidth = 1.5;
        for (let k = 0; k < 5; k++) { n.beginPath(); n.moveTo(cx + k * 6, 100); n.lineTo(cx + k * 6, 142); n.stroke(); }
        for (let k = 0; k < 4; k++) { n.beginPath(); n.moveTo(cx, 104 + k * 11); n.lineTo(cx + 24, 104 + k * 11); n.stroke(); }
      }
      n.fillStyle = '#5a4a3a'; n.fillRect(x - 10, 134, 110, 8);
      for (let k = 0; k < 110; k += 5) { n.fillStyle = '#7a6a56'; n.fillRect(x - 10 + k, 134, 2, 8); }
    } else {                                           // skip full of broken brick
      n.fillStyle = '#16141c'; n.fillRect(x, 112, 116, 30);
      n.fillStyle = '#c8a020'; n.fillRect(x + 2, 114, 112, 26);
      n.fillStyle = '#8a6a14'; n.fillRect(x + 2, 114, 112, 4);
      for (let k = 0; k < 40; k++) { n.fillStyle = pick2(R, ['#8a4a3a', '#6a3a2e', '#a8a09a', '#5a5a52']);
        n.fillRect(x + 6 + R() * 104, 106 + R() * 10, 5, 4); }
    }
  }
  // floodlight masts, the thing that lights a site at night
  for (let x = 90; x < L.near.width; x += 300) {
    n.fillStyle = '#16141c'; n.fillRect(x, 40, 4, 102); n.fillRect(x - 12, 36, 28, 5);
    n.fillStyle = '#fff8d0'; n.fillRect(x - 11, 41, 11, 3); n.fillRect(x + 4, 41, 10, 3);
    n.fillStyle = 'rgba(255,248,208,0.08)';
    n.beginPath(); n.moveTo(x - 11, 44); n.lineTo(x - 74, 240); n.lineTo(x + 78, 240); n.lineTo(x + 14, 44); n.fill();
  }
  siteDirt(n, L, R, r, 142, '#6a4a34', '#7a5a40', '#4a3424');
  // the excavation: the shaft hazard is a real hole with a ladder in it
  for (let x = 60; x < L.near.width; x += 230) {
    n.fillStyle = '#e8d020'; n.beginPath(); n.moveTo(x, 162); n.lineTo(x + 6, 146); n.lineTo(x + 12, 162); n.fill();
    n.fillStyle = '#1a1a1e'; n.fillRect(x + 5, 151, 2, 7); n.fillRect(x + 5, 159, 2, 2);
  }
  for (let x = 0; x < L.near.width; x += 14) { n.fillStyle = (Math.round(x / 14) % 2) ? '#e8b020' : '#1a1a1e'; n.fillRect(x, 232, 14, 4); }
}

// ---- A2: THE DEMOLITION ---------------------------------------------------
// Not going up - coming down. Half a building still standing with its rooms
// opened to the air, a wrecking ball, rubble chutes and dust.
function s3a_demolition(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const sky = f.createLinearGradient(0, 0, 0, 160);
  sky.addColorStop(0, '#3a2438'); sky.addColorStop(0.5, '#8a5a52'); sky.addColorStop(1, '#d8a070');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  f.fillStyle = 'rgba(210,180,150,0.22)'; f.fillRect(0, 70, L.far.width, 90);    // dust haze
  skyline(f, L, R, r, 138, '#4a3a42', '#e8c070', 26, 76);
  for (let x = 80; x < L.mid.width; x += 300) {
    // a crawler crane with the ball on it
    m.fillStyle = '#3a2a28'; m.fillRect(x, 96, 40, 34);
    m.strokeStyle = '#3a2a28'; m.lineWidth = 5;
    m.beginPath(); m.moveTo(x + 20, 100); m.lineTo(x + 96, 28); m.stroke();
    m.strokeStyle = '#2a1e1e'; m.lineWidth = 1;
    m.beginPath(); m.moveTo(x + 96, 28); m.lineTo(x + 104, 74); m.stroke();
    m.fillStyle = '#2a2a30'; m.beginPath(); m.arc(x + 104, 82, 9, 0, 7); m.fill();
    m.fillStyle = '#3e3e46'; m.beginPath(); m.arc(x + 102, 79, 4, 0, 7); m.fill();
    m.fillStyle = '#1a1418'; m.fillRect(x - 4, 126, 52, 10);
  }
  // near: the half-demolished block. Rooms cut open like a doll's house.
  let x = 0, seq = 0;
  while (x < len - 340) {
    const bw = 130 + R() * 60, topFloor = 18 + R() * 16;
    brick(n, x, topFloor, bw, 142 - topFloor, pick2(R, ['#6a3a30', '#5a3a34', '#73412f']), R, { course: 5, bw: 11 });
    // the cut face: floors and party walls exposed, wallpaper still on them
    if (seq % 2 === 0) {
      const cut = x + bw * 0.45;
      n.fillStyle = '#100c12'; n.fillRect(cut, topFloor, bw - (cut - x), 142 - topFloor);
      for (let fl = 0; fl < 4; fl++) {
        const fy = topFloor + 12 + fl * 30;
        if (fy > 138) break;
        n.fillStyle = pick2(R, ['#8a7a5a', '#6a7a8a', '#8a6a6a', '#7a8a6a']);   // wallpaper
        n.fillRect(cut + 4, fy, bw - (cut - x) - 8, 26);
        for (let k = 0; k < 6; k++) { n.fillStyle = 'rgba(0,0,0,0.12)';
          n.fillRect(cut + 8 + k * 14, fy + 2, 5, 22); }
        n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(cut + 4, fy + 20, bw - (cut - x) - 8, 6);
        n.fillStyle = '#c8c0b8'; n.fillRect(cut, fy + 26, bw - (cut - x), 4);   // the slab edge
        n.fillStyle = '#8a8278'; n.fillRect(cut, fy + 30, bw - (cut - x), 2);
        for (let k = 0; k < 5; k++) { n.fillStyle = '#6a6258';                  // rebar poking out
          n.fillRect(cut + 10 + k * 16, fy + 24, 1.5, 9); }
        if (R() < 0.4) {                                                        // a bath or a fireplace left behind
          if (R() < 0.5) { n.fillStyle = '#d8d8d0'; n.fillRect(cut + 14, fy + 12, 26, 12);
            n.fillStyle = '#b8b8b0'; n.fillRect(cut + 14, fy + 12, 26, 3); }
          else { n.fillStyle = '#2a2024'; n.fillRect(cut + 20, fy + 8, 18, 18);
            n.fillStyle = '#12100e'; n.fillRect(cut + 23, fy + 12, 12, 14); }
        }
      }
    } else {
      // still standing: windows blown out, sheeting over some of them
      for (let fl = 0; fl < 4; fl++) {
        const fy = topFloor + 14 + fl * 30;
        if (fy > 132) break;
        for (let k = 0; k < 3; k++) {
          const wx = x + 14 + k * (bw - 34) / 3;
          n.fillStyle = '#100c12'; n.fillRect(wx, fy, 22, 22);
          if (R() < 0.35) { n.fillStyle = 'rgba(210,215,225,0.55)'; n.fillRect(wx - 2, fy - 2, 26, 26);
            for (let b = 0; b < 26; b += 4) { n.fillStyle = 'rgba(160,170,185,0.30)'; n.fillRect(wx - 2, fy - 2 + b, 26, 2); } }
          else { n.fillStyle = '#1a1620'; n.fillRect(wx + 2, fy + 2, 18, 18);
            for (let b = 0; b < 3; b++) { n.fillStyle = '#6a5a44';
              n.save(); n.translate(wx + 11, fy + 6 + b * 7); n.rotate((R() - 0.5) * 0.5); n.fillRect(-11, -1.5, 22, 3); n.restore(); } }
        }
      }
    }
    // the rubble chute bolted down the face
    if (R() < 0.5) {
      const cx = x + 16 + R() * (bw - 50);
      for (let k = 0; k < 5; k++) { n.fillStyle = '#c85a20'; n.fillRect(cx, topFloor + 20 + k * 26, 20, 26);
        n.fillStyle = '#8a3a10'; n.fillRect(cx, topFloor + 20 + k * 26, 20, 4); }
      n.fillStyle = '#c85a20'; n.fillRect(cx - 4, 130, 28, 12);
    }
    x += bw; seq++;
  }
  // the end: the block is gone, just a cleared plot and the ball hanging over it
  const c0 = len - 340;
  n.fillStyle = '#4a3a3e'; n.fillRect(c0, 60, L.near.width - c0, 82);
  for (let bx = c0; bx < L.near.width; bx += 34) { const bh = 24 + R() * 40;
    n.fillStyle = '#3a2e34'; n.fillRect(bx, 142 - bh, 30, bh); }
  n.fillStyle = '#2a2024'; n.fillRect(c0, 40, 6, 102);
  n.strokeStyle = '#2a2024'; n.lineWidth = 4;
  n.beginPath(); n.moveTo(c0 + 3, 44); n.lineTo(c0 + 150, 8); n.stroke();
  n.strokeStyle = '#1a1418'; n.lineWidth = 2;
  n.beginPath(); n.moveTo(c0 + 150, 10); n.lineTo(c0 + 158, 62); n.stroke();
  n.fillStyle = '#26262c'; n.beginPath(); n.arc(c0 + 158, 76, 15, 0, 7); n.fill();
  n.fillStyle = '#3a3a42'; n.beginPath(); n.arc(c0 + 154, 71, 6, 0, 7); n.fill();
  // ground: rubble, brick dust, water in the ruts
  siteDirt(n, L, R, r, 142, '#5a4a48', '#6a5a54', '#3e3232');
  for (let k = 0; k < L.near.width / 3; k++) { n.fillStyle = pick2(R, ['#8a4a3a', '#6a3a2e', '#a8a09a', '#5a5a52', '#c8b8a8']);
    n.fillRect(r(0, L.near.width), r(146, 238), 4, 3); }
  for (let px_ = 40; px_ < L.near.width; px_ += 150 + R() * 90) {   // heaps of spoil
    const hw = 50 + R() * 50;
    n.fillStyle = '#4e4040';
    n.beginPath(); n.moveTo(px_, 200); n.lineTo(px_ + hw / 2, 170 - R() * 14); n.lineTo(px_ + hw, 200); n.fill();
    n.fillStyle = '#5c4c4c';
    n.beginPath(); n.moveTo(px_ + 6, 200); n.lineTo(px_ + hw / 2, 176); n.lineTo(px_ + hw - 10, 200); n.fill();
    for (let k = 0; k < 16; k++) { n.fillStyle = pick2(R, ['#8a4a3a', '#a8a09a', '#6a3a2e']);
      n.fillRect(px_ + 8 + R() * (hw - 16), 178 + R() * 20, 4, 3); }
  }
  for (let x2 = 0; x2 < L.near.width; x2 += 14) { n.fillStyle = (Math.round(x2 / 14) % 2) ? '#e8b020' : '#1a1a1e'; n.fillRect(x2, 232, 14, 4); }
  L.dust = 1;
}

// ---- A3: THE DRY DOCK -----------------------------------------------------
// The yard is on the water: a hull in dock, gantries overhead, chains and
// welding light. The beams hazard becomes dropped hull plate.
function s3a_drydock(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const sky = f.createLinearGradient(0, 0, 0, 150);
  sky.addColorStop(0, '#0e1430'); sky.addColorStop(0.5, '#3a3a68'); sky.addColorStop(1, '#8a6a70');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  stars(f, L, R, r, 40, 44);
  f.fillStyle = '#0c1226'; f.fillRect(0, 104, L.far.width, 46);
  for (let k = 0; k < L.far.width; k++) { f.fillStyle = R() < 0.2 ? 'rgba(170,190,230,0.22)' : 'rgba(30,44,86,0.5)';
    f.fillRect(r(0, L.far.width), 104 + R() * 44, 5 + R() * 8, 1); }
  for (let x = 0; x < L.far.width; x += 90) {                 // cranes across the water
    f.fillStyle = '#16203a'; f.fillRect(x, 66, 4, 40); f.fillRect(x - 18, 64, 52, 4);
    f.fillRect(x + 30, 68, 2, 16);
  }
  // mid: the gantry that runs the length of the dock
  m.fillStyle = '#242a34'; m.fillRect(0, 34, L.mid.width, 12);
  m.fillStyle = '#39414e'; m.fillRect(0, 34, L.mid.width, 3);
  for (let x = 0; x < L.mid.width; x += 10) { m.fillStyle = 'rgba(0,0,0,0.30)'; m.fillRect(x, 37, 3, 9); }
  for (let x = 0; x < L.mid.width; x += 190) {
    m.fillStyle = '#242a34'; m.fillRect(x, 46, 9, 104); m.fillRect(x + 150, 46, 9, 104);
    m.strokeStyle = '#242a34'; m.lineWidth = 3;
    for (let k = 0; k < 104; k += 22) { m.beginPath(); m.moveTo(x + 9, 50 + k); m.lineTo(x + 150, 50 + k + 22); m.stroke(); }
    m.fillStyle = '#2f3846'; m.fillRect(x + 60, 46, 34, 16);
    m.fillStyle = '#e8c860'; m.fillRect(x + 66, 50, 10, 6);
  }
  // near: the hull, plated and part-painted, filling the back of the dock
  n.fillStyle = '#1a2028'; n.fillRect(0, 44, L.near.width, 98);
  const hull = (x0, x1) => {
    n.fillStyle = '#39424e'; n.fillRect(x0, 52, x1 - x0, 90);
    n.fillStyle = '#48525f'; n.fillRect(x0, 52, x1 - x0, 5);
    n.fillStyle = '#8a2a22'; n.fillRect(x0, 118, x1 - x0, 24);            // anti-fouling below the line
    n.fillStyle = '#a8352a'; n.fillRect(x0, 118, x1 - x0, 3);
    for (let px_ = x0; px_ < x1; px_ += 46) for (let py = 54; py < 142; py += 22) {
      n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(px_, py, 45, 1.5); n.fillRect(px_, py, 1.5, 21);
      for (let k = 4; k < 44; k += 8) { n.fillStyle = 'rgba(255,255,255,0.07)'; n.fillRect(px_ + k, py + 2, 2, 2); }
      if (R() < 0.10) { n.fillStyle = 'rgba(200,120,60,0.20)'; n.fillRect(px_ + 4, py + 4, 36, 14); }
    }
    for (let k = 0; k < 5; k++) { const bx = x0 + 30 + k * (x1 - x0 - 60) / 4;  // portholes
      n.fillStyle = '#1a2028'; n.beginPath(); n.arc(bx, 74, 7, 0, 7); n.fill();
      n.fillStyle = '#5a6a7a'; n.beginPath(); n.arc(bx, 74, 5, 0, 7); n.fill(); }
  };
  hull(0, len - 320);
  // staging, ladders and welding light against the hull
  for (let x2 = 40; x2 < len - 340; x2 += 150) {
    n.fillStyle = '#4a4e58'; n.fillRect(x2, 96, 96, 4);
    for (let k = 0; k < 96; k += 12) { n.fillStyle = '#5c616d'; n.fillRect(x2 + k, 96, 3, 4); }
    n.fillStyle = '#39414e'; n.fillRect(x2, 100, 3, 42); n.fillRect(x2 + 92, 100, 3, 42);
    if (R() < 0.6) {
      const wx = x2 + 20 + R() * 50;
      n.save(); n.shadowColor = '#bfe4ff'; n.shadowBlur = 12; n.fillStyle = '#eaf6ff';
      n.fillRect(wx, 88, 4, 4); n.restore();
      n.fillStyle = 'rgba(190,225,255,0.13)'; n.beginPath(); n.arc(wx + 2, 90, 26, 0, 7); n.fill();
      for (let k = 0; k < 7; k++) { n.fillStyle = '#ffd88a'; n.fillRect(wx + (R() - 0.5) * 22, 92 + R() * 26, 1.5, 1.5); }
    }
  }
  // the dock head at the end: caisson gate, bollards, the open sea beyond
  const d0 = len - 320;
  n.fillStyle = '#141a24'; n.fillRect(d0, 44, L.near.width - d0, 98);
  n.fillStyle = '#2f3846'; n.fillRect(d0 + 20, 70, L.near.width - d0 - 40, 72);
  for (let k = 0; k < 72; k += 12) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(d0 + 20, 70 + k, L.near.width - d0 - 40, 2); }
  n.fillStyle = '#e8c020'; n.fillRect(d0 + 20, 66, L.near.width - d0 - 40, 5);
  ptext(n, 'DOCK 4', d0 + 64, 80, '#e8e8e0', 2);
  for (let k = 0; k < 40; k++) { n.fillStyle = 'rgba(160,190,230,0.20)'; n.fillRect(r(d0, L.near.width), r(46, 66), 5, 1); }
  // the dock floor: wet concrete, keel blocks, chains and bollards
  n.fillStyle = '#3e434c'; n.fillRect(0, 142, L.near.width, 98);
  for (let k = 0; k < L.near.width * 1.4; k++) { n.fillStyle = R() < 0.5 ? '#474d57' : '#343942';
    n.fillRect(r(0, L.near.width), r(144, 240), 3, 1); }
  for (let px_ = 0; px_ < L.near.width; px_ += 40) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(px_, 142, 2, 98); }
  n.fillStyle = '#2b3038'; n.fillRect(0, 142, L.near.width, 3);
  puddles(n, R, L.near.width, 150, 236, 26, 'rgba(120,150,200,0.22)');
  for (let px_ = 30; px_ < L.near.width; px_ += 130) {         // keel blocks
    n.fillStyle = '#5a4a3a'; n.fillRect(px_, 150, 30, 14);
    n.fillStyle = '#6a5a46'; n.fillRect(px_, 150, 30, 3);
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(px_, 162, 30, 3);
  }
  for (let px_ = 80; px_ < L.near.width; px_ += 210) {         // bollards and chain
    n.fillStyle = '#2a2e36'; n.fillRect(px_, 196, 14, 18);
    n.beginPath(); n.arc(px_ + 7, 196, 8, Math.PI, 0); n.fill();
    n.strokeStyle = '#4a5058'; n.lineWidth = 3;
    n.beginPath(); n.moveTo(px_ + 7, 200); n.quadraticCurveTo(px_ + 100, 224, px_ + 200, 198); n.stroke();
  }
  for (let x2 = 0; x2 < L.near.width; x2 += 14) { n.fillStyle = (Math.round(x2 / 14) % 2) ? '#e8b020' : '#1a1a1e'; n.fillRect(x2, 232, 14, 4); }
}

// ---- A4: THE BATCHING PLANT -----------------------------------------------
// The wildcard: silos, conveyors and aggregate heaps in an ochre dust haze.
// The hoppers overhead are what drop on you.
function s3a_plant(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const sky = f.createLinearGradient(0, 0, 0, 160);
  sky.addColorStop(0, '#4a3a2a'); sky.addColorStop(0.5, '#a87a4a'); sky.addColorStop(1, '#e8c070');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  f.fillStyle = 'rgba(230,200,150,0.30)'; f.fillRect(0, 60, L.far.width, 100);
  f.fillStyle = '#e8d8a0'; f.beginPath(); f.arc(280, 62, 18, 0, 7); f.fill();
  for (let x = 0; x < L.far.width; x += 60) {                 // spoil ridges on the horizon
    const h = 18 + R() * 22;
    f.fillStyle = '#6a5438';
    f.beginPath(); f.moveTo(x, 142); f.lineTo(x + 30, 142 - h); f.lineTo(x + 62, 142); f.fill();
  }
  // mid: the conveyor climbing across the whole scene
  m.strokeStyle = '#4a3c2c'; m.lineWidth = 9;
  m.beginPath(); m.moveTo(-20, 140); m.lineTo(L.mid.width + 20, 34); m.stroke();
  m.strokeStyle = '#5e4c36'; m.lineWidth = 2;
  m.beginPath(); m.moveTo(-20, 136); m.lineTo(L.mid.width + 20, 30); m.stroke();
  for (let x = 0; x < L.mid.width; x += 44) {
    const yy = 140 - (x / L.mid.width) * 106;
    m.fillStyle = '#3a2f22'; m.fillRect(x, yy + 6, 4, 150 - yy);
  }
  for (let x = 0; x < L.mid.width; x += 170) {                 // silos behind
    m.fillStyle = '#7a6a52'; m.fillRect(x, 44, 46, 106);
    m.fillStyle = '#8a7a60'; m.fillRect(x + 4, 44, 12, 106);
    m.fillStyle = '#5a4c38'; m.fillRect(x, 44, 46, 5);
    m.beginPath(); m.moveTo(x - 4, 44); m.lineTo(x + 23, 28); m.lineTo(x + 50, 44); m.fill();
  }
  // near: the plant itself - silos with hoppers, a mixer, aggregate bays
  let x = 0, si = 0;
  while (x < len - 320) {
    const kind = si % 3; si++;
    if (kind === 0) {                                          // silo bank with discharge hoppers
      const bw = 180;
      for (let s = 0; s < 3; s++) {
        const sx = x + 10 + s * 56;
        n.fillStyle = '#16141c'; n.fillRect(sx - 2, 10, 52, 92);
        n.fillStyle = pick2(R, ['#a8986e', '#98885e', '#b0a078']); n.fillRect(sx, 12, 48, 88);
        n.fillStyle = 'rgba(255,255,255,0.14)'; n.fillRect(sx + 4, 12, 10, 88);
        n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(sx + 40, 12, 8, 88);
        for (let k = 0; k < 88; k += 22) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(sx, 12 + k, 48, 2); }
        ptext(n, String(s + 1), sx + 21, 46, '#5a4c38', 2);
        n.fillStyle = '#5a4c38';                                // the hopper cone under it
        n.beginPath(); n.moveTo(sx, 100); n.lineTo(sx + 48, 100); n.lineTo(sx + 30, 126); n.lineTo(sx + 18, 126); n.fill();
        n.fillStyle = '#3a3026'; n.fillRect(sx + 18, 126, 12, 8);
        n.fillStyle = 'rgba(210,190,150,0.30)'; n.fillRect(sx + 19, 134, 10, 8);
      }
      n.fillStyle = '#4a3c2c'; n.fillRect(x, 102, bw, 5);
      x += bw;
    } else if (kind === 1) {                                   // aggregate bays with heaps in them
      const bw = 210;
      n.fillStyle = '#5a4c38'; n.fillRect(x, 92, bw, 50);
      for (let b = 0; b < 3; b++) {
        const bx = x + 6 + b * 68;
        n.fillStyle = '#4a3e2c'; n.fillRect(bx, 92, 4, 50);
        const c = pick2(R, ['#9a8a6a', '#7a6a52', '#b0a488', '#6a5a46']);
        n.fillStyle = c;
        n.beginPath(); n.moveTo(bx + 4, 142); n.lineTo(bx + 32, 104); n.lineTo(bx + 62, 142); n.fill();
        n.fillStyle = 'rgba(255,255,255,0.09)';
        n.beginPath(); n.moveTo(bx + 18, 124); n.lineTo(bx + 32, 104); n.lineTo(bx + 40, 124); n.fill();
        for (let k = 0; k < 18; k++) { n.fillStyle = 'rgba(0,0,0,0.14)'; n.fillRect(bx + 8 + R() * 50, 112 + R() * 28, 3, 2); }
      }
      n.fillStyle = '#4a3e2c'; n.fillRect(x + bw - 6, 92, 6, 50);
      x += bw;
    } else {                                                   // the mixer house and its stair
      const bw = 150;
      n.fillStyle = '#16141c'; n.fillRect(x, 40, bw, 102);
      n.fillStyle = '#6a5c48'; n.fillRect(x + 2, 42, bw - 4, 98);
      for (let k = 0; k < bw; k += 9) { n.fillStyle = 'rgba(0,0,0,0.14)'; n.fillRect(x + 2 + k, 42, 3, 98); }
      n.fillStyle = '#3a3026'; n.fillRect(x + 20, 62, 44, 34);
      n.fillStyle = '#a89870'; n.fillRect(x + 24, 66, 36, 26);
      n.fillStyle = '#4a3e2c'; n.fillRect(x + bw - 44, 42, 40, 98);
      for (let k = 0; k < 96; k += 8) { n.fillStyle = '#7a6a52'; n.fillRect(x + bw - 42, 44 + k, 36, 3); }
      n.fillStyle = '#e8c020'; n.fillRect(x + 2, 40, bw - 4, 4);
      x += bw;
    }
  }
  // the haul road end: dumper trucks and the weighbridge, where the fight ends
  const h0 = len - 320;
  n.fillStyle = '#6a5438'; n.fillRect(h0, 80, L.near.width - h0, 62);
  for (let k = 0; k < 90; k++) { n.fillStyle = 'rgba(0,0,0,0.10)'; n.fillRect(r(h0, L.near.width), r(82, 140), 8, 4); }
  for (let tx = h0 + 30; tx < L.near.width; tx += 180) {
    n.fillStyle = '#16141c'; n.fillRect(tx, 96, 120, 46);
    n.fillStyle = '#c8a020'; n.fillRect(tx + 2, 98, 74, 42);
    n.fillStyle = '#8a6a14'; n.fillRect(tx + 2, 98, 74, 5);
    for (let k = 0; k < 20; k++) { n.fillStyle = '#7a6a52'; n.fillRect(tx + 8 + R() * 60, 92 + R() * 8, 5, 4); }
    n.fillStyle = '#c85a20'; n.fillRect(tx + 78, 106, 40, 34);
    n.fillStyle = '#1e2a3a'; n.fillRect(tx + 84, 110, 26, 16);
    n.fillStyle = '#16141c'; n.beginPath(); n.arc(tx + 26, 142, 11, 0, 7); n.arc(tx + 96, 142, 11, 0, 7); n.fill();
    n.fillStyle = '#3a3a42'; n.beginPath(); n.arc(tx + 26, 142, 4, 0, 7); n.arc(tx + 96, 142, 4, 0, 7); n.fill();
  }
  siteDirt(n, L, R, r, 142, '#8a6f46', '#9a7f54', '#5e4a2e');
  for (let k = 0; k < L.near.width / 2; k++) { n.fillStyle = pick2(R, ['#a89870', '#7a6a52', '#b8a888']);
    n.fillRect(r(0, L.near.width), r(146, 238), 3, 2); }
  for (let x2 = 0; x2 < L.near.width; x2 += 14) { n.fillStyle = (Math.round(x2 / 14) % 2) ? '#e8b020' : '#1a1a1e'; n.fillRect(x2, 232, 14, 4); }
  L.dust = 1;
}
