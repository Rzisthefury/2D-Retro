// ============================================================ shared ground
function skyGrad(f, L, stops) {
  const sky = f.createLinearGradient(0, 0, 0, 150);
  stops.forEach(([p, c]) => sky.addColorStop(p, c));
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
}
function stars(f, L, R, r, n = 90, top = 74) {
  for (let i = 0; i < n; i++) { f.fillStyle = R() < 0.3 ? '#fff' : '#8a88b0'; f.fillRect(r(0, L.far.width), r(0, top), 1, 1); }
}
function skyline(f, L, R, r, base, col, lit, hMin = 40, hMax = 105) {
  for (let x = 0; x < L.far.width;) {
    const bw = r(18, 46), bh = r(hMin, hMax);
    f.fillStyle = col; f.fillRect(x, base - bh, bw, bh + 22);
    for (let wy = base - bh + 4; wy < base - 4; wy += 6) for (let wx = x + 3; wx < x + bw - 3; wx += 5)
      if (R() < 0.2) { f.fillStyle = R() < 0.7 ? lit : '#80c0e8'; f.fillRect(wx, wy, 2, 2); }
    if (R() < 0.18) { f.fillStyle = '#e8283a'; f.fillRect(x + bw / 2, base - bh - 6, 1, 6); f.fillRect(x + bw / 2 - 1, base - bh - 7, 3, 2); }
    x += bw + r(0, 7);
  }
}
// The pavement, kerb and carriageway. Every street option shares this contract
// so the walkable band never changes.
function paveAndRoad(n, L, R, r, opts = {}) {
  const P = opts.pave || '#4a4556', P2 = opts.pave2 || '#544e62', P3 = opts.pave3 || '#3a3644';
  n.fillStyle = P; n.fillRect(0, WALK, L.near.width, CURB - WALK + 3);
  // flagstones, with a few cracked and a few replaced in a different shade
  for (let y = WALK + 2; y < CURB; y += 13) n.fillStyle = P2, n.fillRect(0, y, L.near.width, 11);
  // individual flags: a few replaced, a few sunken, a few cracked right through
  for (let xx = 0; xx < L.near.width; xx += 26) {
    n.fillStyle = P3; n.fillRect(xx + ((xx / 26) % 2) * 6, WALK, 1, CURB - WALK);
    for (let fy = WALK + 2; fy < CURB; fy += 13) {
      const roll = R();
      if (roll < 0.10) { n.fillStyle = 'rgba(0,0,0,0.15)'; n.fillRect(xx, fy, 25, 11); }
      else if (roll < 0.17) { n.fillStyle = 'rgba(255,255,255,0.055)'; n.fillRect(xx, fy, 25, 11); }
      else if (roll < 0.22) { n.strokeStyle = 'rgba(0,0,0,0.30)'; n.lineWidth = 1;
        n.beginPath(); n.moveTo(xx + 2, fy + R() * 10); n.lineTo(xx + 12, fy + R() * 10); n.lineTo(xx + 23, fy + R() * 10); n.stroke(); }
    }
  }
  // gum, stains and litter - the grain that stops it reading as a flat slab
  for (let k = 0; k < L.near.width / 6; k++) {
    n.fillStyle = 'rgba(0,0,0,0.13)';
    n.beginPath(); n.arc(r(0, L.near.width), r(WALK + 6, CURB - 4), 1 + R() * 1.6, 0, 7); n.fill();
  }
  for (let k = 0; k < L.near.width / 40; k++) {
    n.fillStyle = pick2(R, ['rgba(220,214,196,0.5)', 'rgba(190,180,160,0.45)', 'rgba(150,170,180,0.4)']);
    n.save(); n.translate(r(0, L.near.width), r(WALK + 8, CURB - 6)); n.rotate(R() * 3);
    n.fillRect(0, 0, 3 + R() * 5, 2 + R() * 2); n.restore();
  }
  n.fillStyle = opts.kerbTop || '#3a3448'; n.fillRect(0, WALK, L.near.width, 2);
  // tree pits, grates and manhole covers punched into the pavement
  for (let xx = 40; xx < L.near.width; xx += 150 + R() * 90) {
    if (R() < 0.5) { n.fillStyle = '#231f28'; n.fillRect(xx, CURB - 20, 18, 14);
      for (let k = 0; k < 18; k += 3) { n.fillStyle = '#3a3642'; n.fillRect(xx + k, CURB - 19, 2, 12); } }
    else { n.fillStyle = '#2a2730'; n.beginPath(); n.ellipse(xx, CURB - 12, 9, 4, 0, 0, 7); n.fill();
      n.strokeStyle = '#4a4552'; n.lineWidth = 1; n.beginPath(); n.ellipse(xx, CURB - 12, 9, 4, 0, 0, 7); n.stroke(); }
  }
  n.fillStyle = opts.kerb || '#b8b0c0'; n.fillRect(0, CURB, L.near.width, 3);
  n.fillStyle = '#8a8298'; n.fillRect(0, CURB + 3, L.near.width, 2);
  n.fillStyle = opts.road || '#2a2834'; n.fillRect(0, ROAD, L.near.width, 240 - ROAD);
  for (let k = 0; k < L.near.width * 1.4; k++) { n.fillStyle = R() < 0.5 ? (opts.road2 || '#32303e') : (opts.road3 || '#24222e');
    n.fillRect(r(0, L.near.width), r(ROAD + 1, 240), 2, 1); }
  // worn tyre tracks down the lane, and drain grates at the kerb
  for (const ty of [214, 232]) for (let xx = 0; xx < L.near.width; xx += 2) {
    if (R() < 0.55) { n.fillStyle = 'rgba(255,255,255,0.028)'; n.fillRect(xx, ty, 2, 5); }
  }
  for (let xx = 60; xx < L.near.width; xx += 190 + R() * 120) {
    n.fillStyle = '#1c1a22'; n.fillRect(xx, ROAD + 1, 22, 6);
    for (let k = 0; k < 22; k += 4) { n.fillStyle = '#34323e'; n.fillRect(xx + k, ROAD + 2, 2, 4); }
    n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(xx - 6, ROAD + 5, 34, 4);
  }
  for (let k = 0; k < L.near.width / 260; k++) {                       // oil stains
    n.fillStyle = 'rgba(0,0,0,0.26)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(ROAD + 8, 234), 12 + R() * 16, 4 + R() * 4, 0, 0, 7); n.fill();
  }
  // patched repairs and a worn centre line
  for (let k = 0; k < L.near.width / 200; k++) { n.fillStyle = 'rgba(0,0,0,0.22)';
    n.fillRect(r(0, L.near.width), r(ROAD + 4, 232), 30 + R() * 50, 8 + R() * 10); }
  if (opts.line !== false) { n.fillStyle = opts.lineCol || '#e8c040';
    for (let xx = 0; xx < L.near.width; xx += 40) n.fillRect(xx, 226, 22, 2); }
}
// A crossing: the stripes, a light on the corner and a change of rhythm.
function crossing(n, x, R, opts = {}) {
  n.fillStyle = 'rgba(232,232,224,0.85)';
  for (let k = 0; k < 7; k++) n.fillRect(x + k * 9, ROAD + 4, 6, 240 - ROAD - 6);
  n.fillStyle = opts.kerb || '#b8b0c0'; n.fillRect(x - 6, CURB, 76, 3);
  // dropped kerb and a drain at the corner
  n.fillStyle = '#2a2730'; n.fillRect(x + 66, CURB - 4, 12, 5);
}
