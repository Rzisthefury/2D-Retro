// ============================================================ the picker (stage 2)
const SECTIONS = [
  { id: 'A', stage: '2-A', now: 'THE STRIP', len: 1400, options: [
    { k: 'A1', name: 'Neon Mile', f: s2a_mile,
      pitch: 'A proper entertainment strip: buildings that only exist because of the nightlife.',
      notes: ['Club front with a marquee and rope line, tattoo parlour, pawn shop, penny arcade, liquor store, old theatre - all new building types, none of them shared with stage 1',
              'Wet tarmac holding every sign above it, which is what makes a strip read as a strip',
              'A queue barrier runs most of the block and taxis wait at the kerb; CLUB VELVET takes the whole end'] },
    { k: 'A2', name: 'The Boardwalk', f: s2a_boardwalk,
      pitch: 'The strip is out over the water. Amusements down one side, black sea down the other.',
      notes: ['Penny arcade, ring toss, food stand, a coaster front, a freak show - striped valances and chasing bulbs',
              'A ferris wheel turning behind and a coaster silhouette further out; moonlight on the water',
              'Planks underfoot with a white rail over the drop; the club is a pier pavilion at the end'] },
    { k: 'A3', name: 'The Neon Canyon', f: s2a_canyon,
      pitch: 'A street narrow enough to touch both sides, with signs hung across it four deep.',
      notes: ['Blade signs, light boxes and lantern clusters overlapping overhead on sagging cables - the ceiling is the set piece',
              'Deep tiled eaves over warm open shopfronts, no kerb and no carriageway, just wet setts and a drain channel',
              'A gate spans the street at the end and the club sits behind it'] },
    { k: 'A4', name: 'The Car Park', f: s2a_carpark,
      pitch: 'The wildcard. The party is level four of a multi-storey, and the city is through the open side.',
      notes: ['Slab above, slab below, ranks of parked cars nose-in, painted bay lines and level numbers on the columns',
              'Strip lights on the soffit; the rig and speaker stacks fill three bays at the end',
              'Hard, grey and horizontal - the only stage 2 option that is not built out of neon'] },
  ] },
  { id: 'B', stage: '2-B', now: 'DANCE FLOOR', len: 1200, options: [
    { k: 'B1', name: 'The Main Room', f: s2b_mainroom,
      pitch: 'What you have now, built out properly: lighting truss, balcony crowd, bar, DJ riser, VIP stage.',
      notes: ['A packed balcony looking down on the floor, and a crowd along the bar - the room is full of people',
              'Truss rig across the ceiling with moving heads, speaker stacks, mirror ball over the VIP stage',
              'Keeps the animated light-up floor and the VIP arena exactly where they are now'] },
    { k: 'B2', name: 'The Basement', f: s2b_basement,
      pitch: 'Not a club - a room with a sound system in it. Concrete, scaffold, strobe.',
      notes: ['A wall of speaker cabinets, scaffolding rig, chain-link penning and a van somebody drove inside',
              'Lit by white strobe and one red exit sign instead of colour; the crowd is a silhouette in the dark',
              'Bare slab floor with taped lines, spills and litter'] },
    { k: 'B3', name: 'The Gaming Floor', f: s2b_casino,
      pitch: "The club's respectable face: carpet, brass, green baize and a band on a stage.",
      notes: ['Roulette and card tables with chips, rails and punters crowded round each one',
              'Panelled walls, velvet drapes, chandeliers throwing warm pools down',
              'The boss fight happens in front of a stage with a band playing in silhouette'] },
    { k: 'B4', name: 'The Tank Room', f: s2b_tanks,
      pitch: 'The wildcard. A designer club built around a wall of lit aquaria.',
      notes: ['Every tank a different depth with its own weed, rock and inhabitants - shoals, jellyfish, one big slow thing',
              'Blue-green caustic light over everything and a glass floor lit from underneath',
              'Ends in a curved glass tunnel with jellyfish drifting over the fight'] },
  ] },
];

const BUILT = new Map();
const ORDER = [];
function build(opt, len) {
  if (BUILT.has(opt.k)) { touch(opt.k); return BUILT.get(opt.k); }
  const R = mulberry(opt.k.charCodeAt(0) * 7919 + opt.k.charCodeAt(1) * 131 + len);
  const r = (a, b) => a + R() * (b - a);
  const L = {
    far: mkCanvas(Math.ceil(W + len * 0.25) + 20, H),
    mid: mkCanvas(Math.ceil(W + len * 0.55) + 20, H),
    near: mkCanvas(len + W, H),
  };
  opt.f(L, R, r, len);
  BUILT.set(opt.k, L); ORDER.push(opt.k);
  while (ORDER.length > 6) { const dead = ORDER.shift(); if (dead !== opt.k) BUILT.delete(dead); }
  return L;
}
function touch(k) { const i = ORDER.indexOf(k); if (i >= 0) { ORDER.splice(i, 1); ORDER.push(k); } }

// ---- live overlays -------------------------------------------------------
function drawTiles(g, t, cam) {
  const step = Math.floor(t / 20), tw2 = 30, th = 12;
  for (let row = 0; row < 8; row++) {
    const y = 150 + row * th, off = (row % 2) * (tw2 / 2);
    for (let col = -1; col < W / tw2 + 2; col++) {
      const wx = col * tw2 + off - (cam % tw2);
      const gx = Math.floor((col * tw2 + off + cam) / tw2);
      const on = (gx + row + step) % 3 === 0;
      const cols = ['#ff2a8a', '#2ad8ff', '#ffe02a', '#8a2aff', '#2aff8a', '#ff7a2a'];
      g.fillStyle = on ? cols[(gx * 7 + row * 3 + step) % 6] : '#1a1024';
      g.globalAlpha = on ? 0.34 : 0.9;
      g.fillRect(Math.round(wx) + 1, y + 1, tw2 - 2, th - 2);
    }
  }
  g.globalAlpha = 1;
}
function drawStrobe(g, t) {
  const beat = t % 42;
  if (beat < 3) { g.fillStyle = 'rgba(240,248,255,0.30)'; g.fillRect(0, 0, W, H); }
  else if (beat < 6) { g.fillStyle = 'rgba(240,248,255,0.12)'; g.fillRect(0, 0, W, H); }
  for (let k = 0; k < 4; k++) {
    const a = t * 0.02 + k * 1.6;
    const x = W / 2 + Math.sin(a) * (W / 2 + 40);
    g.fillStyle = k % 2 ? 'rgba(58,255,138,0.06)' : 'rgba(232,244,255,0.05)';
    g.beginPath(); g.moveTo(x, 46); g.lineTo(x - 40, 240); g.lineTo(x + 26, 240); g.lineTo(x + 8, 46); g.fill();
  }
}
function drawHaze(g, t, cam) {
  for (let i = 0; i < 7; i++) {
    const seed = i * 211;
    const x = ((seed * 37 + t * (0.25 + (i % 3) * 0.12)) % (W + 200)) - 100;
    const y = 120 + ((seed % 70));
    g.fillStyle = `rgba(200,210,235,${0.030 + (i % 3) * 0.012})`;
    g.beginPath(); g.ellipse(x, y + Math.sin(t / 60 + i) * 7, 60 + (i % 4) * 22, 16 + (i % 3) * 7, 0, 0, 7); g.fill();
  }
}
function drawCaustic(g, t, cam) {
  g.save(); g.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 16; i++) {
    const seed = i * 149;
    const x = ((seed * 23 - cam * 0.6) % (W + 80) + W + 80) % (W + 80) - 40;
    const y = 152 + (seed % 78);
    const w2 = 12 + Math.abs(Math.sin(t / 34 + i)) * 16;
    g.fillStyle = 'rgba(90,190,235,0.055)';
    g.beginPath(); g.ellipse(x, y, w2, 3 + Math.abs(Math.cos(t / 28 + i)) * 3, i * 0.4, 0, 7); g.fill();
  }
  g.restore();
}

const VIEWS = [];
let playing = true, speed = 1, cam = 0, frames = 0, maxLen = 1400;
function makeView(card, opt, len) {
  const cv = card.querySelector('canvas');
  cv.width = W * PX; cv.height = H * PX;
  const g = cv.getContext('2d');
  g.imageSmoothingEnabled = false;
  const v = { cv, g, opt, len, live: false };
  VIEWS.push(v);
  const io = new IntersectionObserver(es => { es.forEach(e => { v.live = e.isIntersecting; }); }, { rootMargin: '200px' });
  io.observe(cv);
  return v;
}
function paint(v) {
  const { g, opt, len } = v;
  const L = build(opt, len);
  g.setTransform(PX, 0, 0, PX, 0, 0);
  const c = Math.min(cam, len - W);
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  g.drawImage(L.far, -Math.round(c * 0.25), 0, L.far.width, L.far.height);
  g.drawImage(L.mid, -Math.round(c * 0.55), 0, L.mid.width, L.mid.height);
  g.drawImage(L.near, -Math.round(c), 0, L.near.width, L.near.height);
  if (L.tiles) drawTiles(g, frames, c);
  if (L.caustic) drawCaustic(g, frames, c);
  if (L.strobe) drawStrobe(g, frames);
  if (L.haze) drawHaze(g, frames, c);
  if (BAND.checked) {
    g.fillStyle = 'rgba(74,192,232,0.10)'; g.fillRect(0, 150, W, 80);
    g.fillStyle = 'rgba(74,192,232,0.5)'; g.fillRect(0, 150, W, 1); g.fillRect(0, 229, W, 1);
    ptext(g, 'WALKABLE BAND', 6, 152, 'rgba(180,230,255,0.75)');
  }
  ptext(g, opt.k, 5, 5, 'rgba(255,255,255,0.28)', 2);
}
function frame() {
  if (playing) { cam += 0.9 * speed; frames += speed; if (cam > maxLen - W) cam = 0; SCRUB.value = String(Math.round(cam)); }
  for (const v of VIEWS) if (v.live) paint(v);
  requestAnimationFrame(frame);
}
