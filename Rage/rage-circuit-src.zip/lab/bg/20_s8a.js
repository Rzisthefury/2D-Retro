// ============================================================ 8-A  THE ATRIUM
// The way in, at the bottom of the tower. Every option carries an honest hole
// in the floor at roughly mid-scene, because the scene's pit hazard sits there.
const A_PIT = 960;                   // where the pit prop lives

// ---- A1  The Grand Atrium -------------------------------------------------
// The name done properly: eighty floors of glass over a marble hall, mezzanine
// balconies stacked up one side, and a lightwell in the floor at mid-scene.
function s8a_grand(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, W2 = L.near.width, WM = L.mid.width;
  // far: the night outside, seen through the whole height of the wall
  f.fillStyle = '#080714'; f.fillRect(0, 0, W1, H);
  for (let x = 0; x < W1; x += 13) {
    const bh = 20 + ((x * 17) % 62);
    f.fillStyle = ((x / 13) | 0) % 2 ? '#141127' : '#0f0d1e';
    f.fillRect(x, 148 - bh, 12, bh + 6);
  }
  for (let k = 0; k < W1 * 1.1; k++) {
    f.fillStyle = R() < 0.6 ? 'rgba(226,190,96,0.65)' : 'rgba(112,168,232,0.6)';
    f.fillRect(r(0, W1), r(90, 150), 1, 1);
  }
  const hz = f.createLinearGradient(0, 40, 0, 150);
  hz.addColorStop(0, 'rgba(40,30,70,0)'); hz.addColorStop(1, 'rgba(70,50,110,0.35)');
  f.fillStyle = hz; f.fillRect(0, 40, W1, 110);
  // mid: the curtain wall itself, full height, and the mezzanines behind it
  curtainWall(m, { near: { width: WM } }, 0, WM, 36, 112, R, r, { bay: 72, frame: '#241f38', hi: '#3d3658' });
  for (let d = 0; d < 2; d++) {                    // two balcony levels, curving away down the hall
    const by = 60 + d * 34;
    for (let x = 0; x < WM; x += 116) {            // lit rooms behind, each a different warmth
      const tone = ['rgba(255,226,166,0.22)', 'rgba(255,206,140,0.15)', 'rgba(170,205,250,0.13)'][((x / 116) | 0) % 3];
      m.fillStyle = tone; m.fillRect(x + 4, by - 26, 104, 26);
      m.fillStyle = 'rgba(20,14,34,0.75)'; m.fillRect(x + 108, by - 30, 10, 30);
      m.fillStyle = 'rgba(16,11,28,0.70)'; m.fillRect(x + 18, by - 12, 34, 4);   // a desk in each one
      m.fillStyle = 'rgba(16,11,28,0.80)'; m.fillRect(x + 62, by - 20, 11, 20);  // and somebody standing at it
      m.fillStyle = 'rgba(16,11,28,0.70)'; m.beginPath(); m.arc(x + 67, by - 23, 4, 0, 7); m.fill();
    }
    m.fillStyle = '#231d3e'; m.fillRect(0, by, WM, 13);                          // the balcony edge
    m.fillStyle = '#3e3562'; m.fillRect(0, by, WM, 3);
    m.fillStyle = 'rgba(242,201,76,0.55)'; m.fillRect(0, by + 11, WM, 2);        // its lit underside
    const gl = m.createLinearGradient(0, by + 13, 0, by + 34);
    gl.addColorStop(0, 'rgba(242,201,76,0.14)'); gl.addColorStop(1, 'rgba(242,201,76,0)');
    m.fillStyle = gl; m.fillRect(0, by + 13, WM, 21);
    for (let x = 0; x < WM; x += 16) { m.fillStyle = '#4a4070'; m.fillRect(x, by - 11, 2, 11); }
    m.fillStyle = 'rgba(200,225,255,0.07)'; m.fillRect(0, by - 11, WM, 11);
  }
  // near: columns, reception, planting, and the lightwell
  const LNear = { near: { width: W2 } };
  n.fillStyle = '#17132a'; n.fillRect(0, 34, W2, 14);          // the soffit overhead
  n.fillStyle = '#272044'; n.fillRect(0, 46, W2, 3);
  for (let x = 24; x < W2; x += 108) {                          // downlights in the soffit
    n.fillStyle = '#ffe6a8'; n.fillRect(x, 45, 12, 3);
    const g = n.createLinearGradient(0, 48, 0, 150);
    g.addColorStop(0, 'rgba(255,226,160,0.16)'); g.addColorStop(1, 'rgba(255,226,160,0)');
    n.fillStyle = g; n.beginPath(); n.moveTo(x - 4, 48); n.lineTo(x + 16, 48);
    n.lineTo(x + 40, 150); n.lineTo(x - 28, 150); n.fill();
  }
  for (let x = 40; x < W2; x += 232) {                          // marble columns
    n.fillStyle = '#120e24'; n.fillRect(x - 6, 34, 42, 114);
    n.fillStyle = '#4e4578'; n.fillRect(x, 40, 30, 108);
    n.fillStyle = '#7a6fa8'; n.fillRect(x + 3, 40, 10, 108);
    n.fillStyle = '#a094c8'; n.fillRect(x + 5, 40, 4, 108);
    n.fillStyle = 'rgba(0,0,0,0.42)'; n.fillRect(x + 23, 40, 7, 108);
    for (let k = 0; k < 26; k++) {                              // veining down the shaft
      n.strokeStyle = 'rgba(210,200,235,0.20)'; n.lineWidth = 1;
      const vy = 42 + R() * 100;
      n.beginPath(); n.moveTo(x + 2 + R() * 22, vy); n.lineTo(x + 2 + R() * 22, vy + 6 + R() * 12); n.stroke();
    }
    n.fillStyle = '#5c5286'; n.fillRect(x - 8, 36, 46, 9);      // capital
    n.fillStyle = '#8479b0'; n.fillRect(x - 8, 36, 46, 3);
    n.fillStyle = '#4a4270'; n.fillRect(x - 8, 136, 46, 12);    // base
    n.fillStyle = '#6f649a'; n.fillRect(x - 8, 136, 46, 3);
    n.fillStyle = '#f2c94c'; n.fillRect(x - 8, 146, 46, 2);
    n.fillStyle = 'rgba(242,201,76,0.18)';                      // the uplight on it
    n.beginPath(); n.moveTo(x + 2, 136); n.lineTo(x - 6, 50); n.lineTo(x + 36, 50); n.lineTo(x + 28, 136); n.fill();
    n.fillStyle = '#f2c94c'; n.fillRect(x + 6, 132, 18, 3);     // the uplighter itself
    n.fillStyle = '#fff0b8'; n.fillRect(x + 8, 132, 14, 1);
  }
  for (let x = 130; x < W2; x += 232) {                         // planting between them
    planter(n, x, 124, 46, R, r, true);
    planter(n, x + 60, 132, 30, R, r, false);
  }
  // the reception bank, once, near the start
  n.fillStyle = '#251e3e'; n.fillRect(180, 108, 168, 40);
  n.fillStyle = '#3a2f5e'; n.fillRect(180, 108, 168, 5);
  n.fillStyle = '#f2c94c'; n.fillRect(180, 113, 168, 1);
  for (let k = 0; k < 5; k++) { n.fillStyle = 'rgba(120,180,240,0.35)'; n.fillRect(196 + k * 32, 118, 14, 9); }
  n.fillStyle = '#0e0b1a'; n.fillRect(206, 62, 116, 40);        // the company name behind it
  n.fillStyle = '#8a1a2a'; n.fillRect(206, 62, 116, 3);
  ptext(n, 'DRAY', 232, 72, '#f2c94c', 2);
  ptext(n, 'HOLDINGS', 224, 88, 'rgba(242,201,76,0.55)');
  // the lightwell: a hole down to the parking levels, exactly where the pit is
  floorVoid(n, A_PIT - 52, FLOOR8, 104, R, r);
  railing(n, A_PIT - 92, 112, 34);
  railing(n, A_PIT + 60, 112, 34);
  stoneFloor(n, LNear, R, r, FLOOR8, '#2d2650', 'rgba(190,180,235,0.13)', '#463a78', 64);
  for (let x = 40; x < W2; x += 232) { n.fillStyle = 'rgba(242,201,76,0.13)'; n.fillRect(x + 2, 150, 24, 88); }
  n.fillStyle = '#f2c94c'; n.fillRect(0, FLOOR8, W2, 2);
  L.atriumDust = true; L.labHum = false;
  return L;
}

// ---- A2  The Trading Floor ------------------------------------------------
// Two in the morning and the ops floor is still running. Desks, a wall of
// tickers, glazed pods, and an open floor void where the new core is going in.
function s8a_trading(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  f.fillStyle = '#05060e'; f.fillRect(0, 0, W1, H);
  for (let k = 0; k < W1 * 0.5; k++) { f.fillStyle = 'rgba(74,192,232,0.18)'; f.fillRect(r(0, W1), r(40, 148), 1, 1); }
  // mid: the data wall - the whole back of the room is screens
  m.fillStyle = '#080a14'; m.fillRect(0, 34, WM, 116);
  for (let x = 0; x < WM; x += 46) {
    const sy = 44 + ((x * 7) % 3) * 2;
    m.fillStyle = '#0c1020'; m.fillRect(x + 2, sy, 42, 60);
    m.fillStyle = '#141a30'; m.fillRect(x + 2, sy, 42, 2);
    const up = ((x / 46) | 0) % 3 !== 1;
    for (let k = 0; k < 9; k++) {                        // a chart on each one
      const h = 3 + ((x * 3 + k * 11) % 22);
      m.fillStyle = up ? 'rgba(90,208,106,0.55)' : 'rgba(232,58,74,0.55)';
      m.fillRect(x + 5 + k * 4, sy + 54 - h, 3, h);
    }
    for (let k = 0; k < 4; k++) { m.fillStyle = 'rgba(210,230,255,0.28)'; m.fillRect(x + 5, sy + 4 + k * 5, 14 + ((x + k) % 20), 2); }
    m.fillStyle = 'rgba(74,192,232,0.07)'; m.fillRect(x + 2, sy, 42, 60);
  }
  m.fillStyle = '#10131f'; m.fillRect(0, 104, WM, 10);   // the ticker rail under them
  for (let x = 0; x < WM; x += 7) { m.fillStyle = ((x / 7) | 0) % 5 ? 'rgba(242,201,76,0.55)' : 'rgba(232,58,74,0.6)'; m.fillRect(x, 107, 4, 4); }
  const gl = m.createLinearGradient(0, 104, 0, 150);
  gl.addColorStop(0, 'rgba(74,192,232,0.14)'); gl.addColorStop(1, 'rgba(74,192,232,0)');
  m.fillStyle = gl; m.fillRect(0, 104, WM, 46);
  // near: the floor plate itself
  const LNear = { near: { width: W2 } };
  n.fillStyle = '#0e1018'; n.fillRect(0, 34, W2, 12);
  for (let x = 0; x < W2; x += 74) {                     // service grid overhead
    n.fillStyle = '#1a1e2a'; n.fillRect(x, 40, 60, 5);
    n.fillStyle = '#c8e8ff'; n.fillRect(x + 6, 44, 46, 2);
    const g = n.createLinearGradient(0, 46, 0, 112);
    g.addColorStop(0, 'rgba(200,232,255,0.13)'); g.addColorStop(1, 'rgba(200,232,255,0)');
    n.fillStyle = g; n.fillRect(x - 6, 46, 72, 66);
  }
  for (let x = 20; x < W2; x += 168) {                   // rows of desks stepping back
    deskBank(n, x, 92, 132, R, r, '#4ac0e8');
    deskBank(n, x + 26, 116, 124, R, r, '#6ad0a0');
    n.fillStyle = '#20242f'; n.fillRect(x + 4, 132, 132, 3);            // the front worktop, lit edge-on
    n.fillStyle = '#323848'; n.fillRect(x + 4, 132, 132, 1);
    n.fillStyle = 'rgba(74,192,232,0.14)'; n.fillRect(x + 4, 135, 132, 11);
    for (let k = 0; k < 5; k++) {                                        // chairs pushed back from it
      n.fillStyle = '#14161e'; n.fillRect(x + 12 + k * 26, 120, 15, 16);
      n.fillStyle = '#1e2230'; n.fillRect(x + 13 + k * 26, 121, 13, 3);
    }
  }
  for (let x = 96; x < W2; x += 336) glassPod(n, x, 54, 104, 62, R, r);
  for (let x = 250; x < W2; x += 336) {                  // a pillar with a status board on it
    n.fillStyle = '#191c28'; n.fillRect(x, 34, 22, 114);
    n.fillStyle = '#242836'; n.fillRect(x + 2, 34, 6, 114);
    n.fillStyle = '#0b0d16'; n.fillRect(x - 8, 60, 38, 26);
    for (let k = 0; k < 5; k++) { n.fillStyle = k % 2 ? 'rgba(90,208,106,0.6)' : 'rgba(232,58,74,0.6)'; n.fillRect(x - 4, 64 + k * 4, 12 + (k * 5) % 16, 2); }
  }
  // the void: a floor panel bay lifted out for the new riser
  floorVoid(n, A_PIT - 56, FLOOR8, 112, R, r, '#05070c');
  for (let k = 0; k < 4; k++) { n.fillStyle = '#2a3140'; n.fillRect(A_PIT - 50 + k * 28, FLOOR8 - 24, 4, 22); }
  tileLike(n, W2, FLOOR8);
  for (let x = 0; x < W2; x += 74) {                     // the ceiling grid reflected in the floor
    const g = n.createLinearGradient(0, FLOOR8, 0, 226);
    g.addColorStop(0, 'rgba(200,232,255,0.09)'); g.addColorStop(1, 'rgba(200,232,255,0)');
    n.fillStyle = g; n.fillRect(x - 6, FLOOR8, 72, 78);
  }
  for (let x = 40; x < W2; x += 240) {                   // a stencilled aisle the whole length
    n.strokeStyle = 'rgba(74,192,232,0.13)'; n.lineWidth = 2; n.strokeRect(x, 176, 150, 44);
  }
  L.blink8 = true; L.tickers = true;
  return L;
}
// The raised access floor a trading room sits on.
function tileLike(n, W2, top) {
  n.fillStyle = '#161923'; n.fillRect(0, top, W2, 240 - top);
  for (let y = top, row = 0; y < 240; y += 30, row++) {
    for (let x = 0; x < W2; x += 30) {
      n.fillStyle = (row + x / 30) % 2 ? '#1b1f2b' : '#171a25';
      n.fillRect(x + 1, y + 1, 28, 28);
      n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x + 12, y + 3, 6, 1);
    }
  }
  n.fillStyle = 'rgba(74,192,232,0.10)'; n.fillRect(0, top, W2, 2);
}

// ---- A3  The Winter Garden ------------------------------------------------
// The atrium is a conservatory: a glass roof, mature trees in the hall, and a
// long reflecting pool down the middle of it that the pit reads as.
function s8a_garden(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  f.fillStyle = '#0a1218'; f.fillRect(0, 0, W1, H);
  for (let k = 0; k < W1 * 0.6; k++) { f.fillStyle = 'rgba(180,220,200,0.12)'; f.fillRect(r(0, W1), r(36, 148), 1, 1); }
  // mid: the far wall of glass with the city behind it, greened by the planting
  curtainWall(m, { near: { width: WM } }, 0, WM, 40, 104, R, r, { bay: 58, frame: '#1e2c26', hi: '#35503f' });
  m.fillStyle = 'rgba(60,140,90,0.10)'; m.fillRect(0, 40, WM, 104);
  for (let x = 0; x < WM; x += 84) {                    // a canopy of leaves against it
    for (let k = 0; k < 46; k++) {
      const lx = x + R() * 80, ly = 44 + R() * 56;
      m.fillStyle = R() < 0.4 ? 'rgba(28,62,36,0.85)' : 'rgba(40,92,50,0.70)';
      m.fillRect(lx, ly, 5 + R() * 5, 3);
    }
  }
  const LNear = { near: { width: W2 } };
  // near: the glazed roof, seen as a run of trusses and glass overhead
  n.fillStyle = '#0d1512'; n.fillRect(0, 34, W2, 10);
  for (let x = 0; x < W2; x += 56) {
    n.fillStyle = '#25382c'; n.fillRect(x, 34, 4, 26);
    n.strokeStyle = '#25382c'; n.lineWidth = 2;
    n.beginPath(); n.moveTo(x, 58); n.lineTo(x + 28, 40); n.lineTo(x + 56, 58); n.stroke();
    n.fillStyle = 'rgba(150,200,255,0.055)';
    n.beginPath(); n.moveTo(x, 58); n.lineTo(x + 28, 40); n.lineTo(x + 56, 58); n.fill();
  }
  n.fillStyle = '#1a2a20'; n.fillRect(0, 56, W2, 4);
  for (let x = 30; x < W2; x += 118) {                  // festoon lamps slung under the roof
    n.strokeStyle = '#2a3a2e'; n.lineWidth = 1;
    n.beginPath(); n.moveTo(x, 60); n.quadraticCurveTo(x + 59, 78, x + 118, 60); n.stroke();
    for (let k = 1; k < 6; k++) {
      const lx = x + k * 19.6, ly = 60 + Math.sin(k / 6 * 3.14) * 17;
      n.fillStyle = '#ffe0a0'; n.fillRect(lx, ly, 3, 3);
      const g = n.createRadialGradient(lx + 1, ly + 1, 0, lx + 1, ly + 1, 14);
      g.addColorStop(0, 'rgba(255,224,160,0.26)'); g.addColorStop(1, 'rgba(255,224,160,0)');
      n.fillStyle = g; n.fillRect(lx - 13, ly - 13, 28, 28);
    }
  }
  for (let x = 20; x < W2; x += 196) {                  // mature trees in the hall
    const th = 70 + ((x * 7) % 14);
    n.fillStyle = '#1d1712'; n.fillRect(x + 22, FLOOR8 - th, 7, th - 4);
    n.fillStyle = '#2c231a'; n.fillRect(x + 22, FLOOR8 - th, 3, th - 4);
    for (let k = 0; k < 120; k++) {
      const a = R() * 6.28, rr = Math.pow(R(), 0.6) * 38;
      const lx = x + 25 + Math.cos(a) * rr, ly = FLOOR8 - th - 4 + Math.sin(a) * rr * 0.58;
      if (ly > 138 || ly < 46) continue;
      n.fillStyle = R() < 0.32 ? '#1c4426' : (R() < 0.6 ? '#2e6a38' : '#3f8a48');
      n.fillRect(lx, ly, 5, 3);
    }
    planter(n, x + 6, 134, 42, R, r, false);
  }
  for (let x = 120; x < W2; x += 196) {                 // benches and a fern between the trees
    n.fillStyle = '#2a2018'; n.fillRect(x, 130, 44, 4);
    n.fillStyle = '#1a120c'; n.fillRect(x + 4, 134, 4, 12); n.fillRect(x + 36, 134, 4, 12);
    planter(n, x + 58, 132, 26, R, r, false);
  }
  // the reflecting pool - exactly where the pit is, running past it both ways
  const px0 = A_PIT - 190, pw = 380;
  n.fillStyle = '#0d2630'; n.fillRect(px0, FLOOR8 - 24, pw, 24);
  const pgr = n.createLinearGradient(0, FLOOR8 - 24, 0, FLOOR8);
  pgr.addColorStop(0, 'rgba(90,190,190,0.45)'); pgr.addColorStop(1, 'rgba(20,70,80,0.75)');
  n.fillStyle = pgr; n.fillRect(px0, FLOOR8 - 24, pw, 24);
  for (let k = 0; k < pw * 1.1; k++) { n.fillStyle = 'rgba(190,250,240,0.20)'; n.fillRect(r(px0, px0 + pw), r(FLOOR8 - 22, FLOOR8 - 2), 5 + R() * 12, 1); }
  for (let x = px0 + 30; x < px0 + pw; x += 64) {       // lights under the water
    const g = n.createRadialGradient(x, FLOOR8 - 12, 0, x, FLOOR8 - 12, 26);
    g.addColorStop(0, 'rgba(170,250,240,0.28)'); g.addColorStop(1, 'rgba(170,250,240,0)');
    n.fillStyle = g; n.fillRect(x - 26, FLOOR8 - 26, 52, 26);
  }
  n.fillStyle = '#3a4a44'; n.fillRect(px0 - 4, FLOOR8 - 4, pw + 8, 4);
  n.fillStyle = '#56685e'; n.fillRect(px0 - 4, FLOOR8 - 4, pw + 8, 1);
  for (let k = 0; k < 3; k++) {                         // fountain jets standing in it
    const jx = px0 + 70 + k * 120;
    n.fillStyle = 'rgba(200,240,235,0.30)'; n.fillRect(jx, FLOOR8 - 46, 2, 26);
    n.fillStyle = 'rgba(200,240,235,0.16)'; n.fillRect(jx - 1, FLOOR8 - 52, 4, 8);
  }
  floorVoid(n, A_PIT - 52, FLOOR8, 104, R, r, '#06120f');
  stoneFloor(n, LNear, R, r, FLOOR8, '#26332c', 'rgba(200,240,215,0.11)', '#3a4e40', 56);
  for (let x = 30; x < W2; x += 118) {                  // the festoon lamps pooling on the stone
    const g = n.createLinearGradient(0, FLOOR8, 0, 224);
    g.addColorStop(0, 'rgba(255,216,150,0.11)'); g.addColorStop(1, 'rgba(255,216,150,0)');
    n.fillStyle = g; n.fillRect(x - 10, FLOOR8, 138, 76);
  }
  n.fillStyle = '#4a6a52'; n.fillRect(0, FLOOR8, W2, 2);
  L.gardenMotes = true;
  return L;
}

// ---- A4  The Blackout Lobby -----------------------------------------------
// They cut the power to the lower floors to slow you down. Same hall, no
// lights: emergency fittings, half-dropped shutters, and a forced lift shaft.
function s8a_blackout(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  // far: the only bright thing in the scene is the city outside, still lit
  f.fillStyle = '#04040c'; f.fillRect(0, 0, W1, H);
  for (let x = 0; x < W1; x += 15) {
    const bh = 28 + ((x * 23) % 74);
    f.fillStyle = ((x / 15) | 0) % 2 ? '#0f0d1c' : '#0a0916'; f.fillRect(x, 150 - bh, 14, bh + 4);
    for (let k = 0; k < 14; k++) {
      f.fillStyle = R() < 0.55 ? 'rgba(232,196,104,0.80)' : 'rgba(118,172,236,0.75)';
      f.fillRect(x + 1 + R() * 12, 150 - bh + 2 + R() * (bh - 4), 1, 1);
    }
  }
  // mid: the glass wall, with the city blazing through it into a dead room
  curtainWall(m, { near: { width: WM } }, 0, WM, 36, 112, R, r, { bay: 72, frame: '#141222', hi: '#241f38', dark: '#07060f' });
  for (let x = 0; x < WM; x += 72) {                   // light thrown in across the floor
    const g = m.createLinearGradient(0, 100, 0, 150);
    g.addColorStop(0, 'rgba(180,200,255,0.10)'); g.addColorStop(1, 'rgba(180,200,255,0)');
    m.fillStyle = g; m.fillRect(x, 100, 62, 50);
  }
  const LNear = { near: { width: W2 } };
  n.fillStyle = '#0a0812'; n.fillRect(0, 34, W2, 16);
  for (let x = 40; x < W2; x += 232) {                 // the same columns, unlit
    n.fillStyle = '#100d1e'; n.fillRect(x - 5, 34, 40, 114);
    n.fillStyle = '#1d1832'; n.fillRect(x, 40, 30, 108);
    n.fillStyle = '#292342'; n.fillRect(x + 3, 40, 7, 108);
    n.fillStyle = 'rgba(0,0,0,0.45)'; n.fillRect(x + 23, 40, 7, 108);
    n.fillStyle = '#0d0a18'; n.fillRect(x - 7, 36, 44, 8); n.fillRect(x - 7, 138, 44, 10);
  }
  for (let x = 74; x < W2; x += 116) {                 // emergency fittings, green and weak
    n.fillStyle = '#1a2620'; n.fillRect(x, 52, 20, 8);
    n.fillStyle = '#5ad06a'; n.fillRect(x + 2, 55, 16, 3);
    const g = n.createRadialGradient(x + 10, 58, 0, x + 10, 58, 60);
    g.addColorStop(0, 'rgba(90,208,106,0.20)'); g.addColorStop(1, 'rgba(90,208,106,0)');
    n.fillStyle = g; n.fillRect(x - 50, 8, 120, 120);
  }
  for (let x = 160; x < W2; x += 348) {                // running-man exit signs
    n.fillStyle = '#0c1a12'; n.fillRect(x, 64, 26, 12);
    n.fillStyle = '#2aa04a'; n.fillRect(x + 1, 65, 24, 10);
    n.fillStyle = '#d8ffe0'; n.fillRect(x + 6, 67, 4, 6); n.fillRect(x + 13, 68, 8, 2);
  }
  for (let x = 112; x < W2; x += 232) {                // security shutters, half dropped
    const drop = 40 + ((x * 11) % 34);
    n.fillStyle = '#16131f'; n.fillRect(x, 44, 96, drop);
    for (let y = 44; y < 44 + drop; y += 5) { n.fillStyle = ((y / 5) | 0) % 2 ? '#211c2e' : '#191523'; n.fillRect(x, y, 96, 4); }
    n.fillStyle = '#2c2640'; n.fillRect(x, 44 + drop, 96, 4);
    n.fillStyle = 'rgba(0,0,0,0.55)'; n.fillRect(x, 44 + drop + 4, 96, 10);
  }
  // reception, abandoned mid-shift
  n.fillStyle = '#15112a'; n.fillRect(180, 108, 168, 40);
  n.fillStyle = '#221b3e'; n.fillRect(180, 108, 168, 4);
  for (let k = 0; k < 3; k++) { n.fillStyle = 'rgba(74,192,232,0.25)'; n.fillRect(200 + k * 44, 118, 14, 9); }
  n.fillStyle = 'rgba(232,240,255,0.30)'; n.fillRect(262, 112, 10, 7);   // a mug left on it
  n.fillStyle = '#0d0a18'; n.fillRect(206, 62, 116, 40);
  ptext(n, 'DRAY', 232, 72, 'rgba(242,201,76,0.30)', 2);
  // the forced lift shaft, doors levered apart, exactly at the pit
  n.fillStyle = '#100d1c'; n.fillRect(A_PIT - 78, 52, 156, 96);
  n.fillStyle = '#1e1930'; n.fillRect(A_PIT - 78, 52, 156, 5);
  n.fillStyle = '#2b2442'; n.fillRect(A_PIT - 78, 52, 6, 96); n.fillRect(A_PIT + 72, 52, 6, 96);
  n.fillStyle = '#26203c'; n.fillRect(A_PIT - 70, 60, 58, 88);          // the doors, shoved open
  n.fillStyle = '#332b4e'; n.fillRect(A_PIT - 70, 60, 4, 88);
  n.fillStyle = '#26203c'; n.fillRect(A_PIT + 22, 60, 48, 88);
  n.fillStyle = '#332b4e'; n.fillRect(A_PIT + 22, 60, 4, 88);
  n.fillStyle = '#05040a'; n.fillRect(A_PIT - 12, 60, 34, 88);          // the shaft behind them
  n.fillStyle = '#1a1628'; n.fillRect(A_PIT - 6, 60, 4, 88);            // guide rail
  n.fillStyle = 'rgba(90,208,106,0.35)'; n.fillRect(A_PIT + 4, 72, 3, 3);
  floorVoid(n, A_PIT - 52, FLOOR8, 104, R, r, '#030309');
  stoneFloor(n, LNear, R, r, FLOOR8, '#1d1938', 'rgba(150,150,200,0.09)', '#2a2352', 64);
  for (let x = 74; x < W2; x += 116) {                 // the green pools the fittings throw
    const g = n.createLinearGradient(0, FLOOR8, 0, 240);
    g.addColorStop(0, 'rgba(90,208,106,0.10)'); g.addColorStop(1, 'rgba(90,208,106,0)');
    n.fillStyle = g; n.fillRect(x - 40, FLOOR8, 100, 92);
  }
  n.fillStyle = 'rgba(180,200,255,0.07)'; n.fillRect(0, FLOOR8, W2, 92);
  L.torchBeams = true; L.emergPulse = true;
  return L;
}
