// ============================================================ STAGE 1-A options
// Four takes on the opening street. Each paints far / mid / near into L.

// ---- A1: DOWNTOWN CROSSING ------------------------------------------------
// A real block: no two buildings alike, and it changes as you walk - a crossing
// a third of the way in, scaffolding over the pavement, and it opens out at the
// end onto the junction where the fight finishes.
function s1a_crossing(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#07051a'], [0.55, '#2a1242'], [1, '#6a2a52']]);
  stars(f, L, R, r);
  f.fillStyle = '#e8e2c8'; f.beginPath(); f.arc(300, 30, 12, 0, 7); f.fill();
  f.fillStyle = '#2a1242'; f.beginPath(); f.arc(305, 27, 11, 0, 7); f.fill();
  skyline(f, L, R, r, 130, '#140f2a', '#e8c860');
  // mid: taller blocks further down the avenue, with water towers on the roofs
  for (let x = 0; x < L.mid.width;) {
    const bw = r(46, 88), bh = r(66, 124);
    m.fillStyle = '#241c40'; m.fillRect(x, 136 - bh, bw, bh + 10);
    m.fillStyle = '#2e2650'; m.fillRect(x, 136 - bh, bw, 3);
    for (let wy = 136 - bh + 8; wy < 128; wy += 11) for (let wx = x + 5; wx < x + bw - 6; wx += 10) {
      m.fillStyle = R() < 0.3 ? '#d8b050' : '#141028'; m.fillRect(wx, wy, 5, 6);
    }
    if (R() < 0.4) {                                  // water tower
      const tx = x + bw * 0.4;
      m.fillStyle = '#3a2a20'; m.fillRect(tx, 136 - bh - 17, 15, 12);
      m.beginPath(); m.moveTo(tx - 1, 136 - bh - 17); m.lineTo(tx + 7.5, 136 - bh - 23); m.lineTo(tx + 16, 136 - bh - 17); m.fill();
      m.fillRect(tx + 2, 136 - bh - 5, 2, 5); m.fillRect(tx + 11, 136 - bh - 5, 2, 5);
    }
    x += bw + r(4, 20);
  }
  // near: the block itself, with landmarks placed rather than scattered
  const x1 = 470, x2 = len - 430;
  blockRun(n, 0, x1 - 30, R, r);
  // -- the crossing: the block breaks for a side street
  n.clearRect(x1 - 30, 0, 150, GROUND);
  n.fillStyle = '#100c20'; n.fillRect(x1 - 30, 40, 150, GROUND - 40);
  for (let bx = x1 - 26; bx < x1 + 116; bx += 24) {    // the side street receding
    const bh = 40 + R() * 46;
    n.fillStyle = '#1c1636'; n.fillRect(bx, GROUND - 44 - bh, 20, bh + 44);
    for (let k = 0; k < 10; k++) if (R() < 0.4) { n.fillStyle = '#c8a048'; n.fillRect(bx + 3 + R() * 14, GROUND - 42 - R() * bh, 2, 2); }
  }
  n.fillStyle = '#241f2c'; n.fillRect(x1 - 30, GROUND - 6, 150, 6);
  blockRun(n, x1 + 120, x2, R, r);
  // -- the junction the fight ends on: it opens out, lit and empty
  n.fillStyle = '#0d0a18'; n.fillRect(x2, 0, L.near.width - x2, GROUND);
  for (let bx = x2; bx < L.near.width; bx += r(26, 46)) {
    const bh = r(44, 96); n.fillStyle = '#1a1530'; n.fillRect(bx, GROUND - 30 - bh, r(20, 40), bh + 30);
  }
  for (let k = 0; k < 90; k++) { n.fillStyle = '#d8b050'; n.fillRect(r(x2, L.near.width), r(30, 110), 1, 1); }
  paveAndRoad(n, L, R, r);
  crossing(n, x1 + 8, R);
  crossing(n, x2 + 60, R);
  // scaffolding over the pavement for one stretch - you walk under it
  const sc0 = 860, sc1 = 1120;
  if (sc1 < len) {
    n.fillStyle = '#7a6a4a'; n.fillRect(sc0, WALK - 38, sc1 - sc0, 5);
    n.fillStyle = '#5a4a32'; n.fillRect(sc0, WALK - 33, sc1 - sc0, 2);
    for (let px_ = sc0; px_ < sc1; px_ += 42) {
      n.fillStyle = '#6a5a3e'; n.fillRect(px_, WALK - 38, 4, 38);
      n.fillStyle = '#3a3040'; n.fillRect(px_ - 1, WALK - 1, 6, 2);
      for (let k = 0; k < 22; k += 7) { n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(px_ + 4, WALK - 34 + k, 38, 1); }
    }
    for (let px_ = sc0 + 10; px_ < sc1; px_ += 90) { n.fillStyle = '#fff4b0'; n.fillRect(px_, WALK - 32, 7, 3);
      n.fillStyle = 'rgba(255,244,176,0.10)'; n.fillRect(px_ - 10, WALK - 29, 27, 26); }
  }
  // street furniture and clutter, spaced so no two neighbours match
  const props = [
    (x) => streetLamp(n, x, WALK + 2, R),
    (x) => busShelter(n, x, WALK + 46, R),
    (x) => { hydrant(n, x, WALK + 50); pigeon(n, x + 9, WALK + 50, R); },
    (x) => { newsBox(n, x, WALK + 50, R); newsBox(n, x + 15, WALK + 50, R); },
    (x) => trashBags(n, x, WALK + 50, R, 4),
    (x) => { steamGrate(n, x, WALK + 40, 0, R); },
    (x) => { g_mailbox(n, x, WALK + 50, R); },
    (x) => { g_phonebooth(n, x, WALK + 50, R); },
  ];
  let pi = 0;
  for (let x = 60; x < L.near.width - 40; x += 88 + R() * 54) { props[pi % props.length](x); pi += 1 + Math.floor(R() * 2); }
  for (let x = 120; x < L.near.width - 80; x += 190 + R() * 130) parkedCar(n, x, 236, R);
  for (let k = 0; k < 16; k++) pigeon(n, r(0, L.near.width), ROAD + 4 + r(0, 30), R);
}
function g_mailbox(n, x, y, R) {
  n.fillStyle = '#120e16'; n.fillRect(x - 8, y - 24, 17, 24);
  n.fillStyle = '#2a5a8a'; n.fillRect(x - 7, y - 23, 15, 21);
  n.beginPath(); n.arc(x + 0.5, y - 23, 7.5, Math.PI, 0); n.fill();
  n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(x - 5, y - 20, 11, 3);
  n.fillStyle = '#16141c'; n.fillRect(x - 6, y - 2, 3, 2); n.fillRect(x + 4, y - 2, 3, 2);
}
function g_phonebooth(n, x, y, R) {
  n.fillStyle = '#16141c'; n.fillRect(x - 10, y - 46, 21, 46);
  n.fillStyle = '#1e3a5a'; n.fillRect(x - 9, y - 45, 19, 44);
  n.fillStyle = 'rgba(190,225,255,0.20)'; n.fillRect(x - 7, y - 40, 15, 30);
  n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(x - 5, y - 39, 4, 28);
  n.fillStyle = '#e8e8f0'; n.fillRect(x - 9, y - 50, 19, 5);
  ptext(n, 'PHONE', x - 8, y - 49, '#2a3a6a');
  n.fillStyle = '#12101a'; n.fillRect(x + 1, y - 30, 6, 12);
}

// ---- A2: RAIN ON 4TH ------------------------------------------------------
// The same city, soaked. Everything reads through reflection: the road is a
// mirror, the neon bleeds into it, and the far layer is lost in haze.
function s1a_rain(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#0a0c1c'], [0.5, '#1c2140'], [1, '#3a3a5e']]);
  // no stars - overcast. Distant towers half-dissolved in the rain.
  skyline(f, L, R, r, 134, '#141830', '#b8b070', 30, 88);
  f.fillStyle = 'rgba(120,130,170,0.30)'; f.fillRect(0, 60, L.far.width, 100);
  for (let x = 0; x < L.mid.width;) {
    const bw = r(50, 90), bh = r(60, 116);
    m.fillStyle = '#1e2238'; m.fillRect(x, 136 - bh, bw, bh + 10);
    for (let wy = 136 - bh + 8; wy < 128; wy += 11) for (let wx = x + 5; wx < x + bw - 6; wx += 10) {
      m.fillStyle = R() < 0.34 ? '#c8b070' : '#151a2a'; m.fillRect(wx, wy, 5, 6);
    }
    x += bw + r(4, 18);
  }
  m.fillStyle = 'rgba(140,150,190,0.16)'; m.fillRect(0, 0, L.mid.width, 150);
  blockRun(n, 0, len - 380, R, r);
  // the boss end: under a railway bridge, water sheeting off the edge
  const bx0 = len - 380;
  n.fillStyle = '#0e1020'; n.fillRect(bx0, 0, L.near.width - bx0, GROUND);
  n.fillStyle = '#2a3040'; n.fillRect(bx0, 28, L.near.width - bx0, 34);
  n.fillStyle = '#3a4254'; n.fillRect(bx0, 28, L.near.width - bx0, 3);
  for (let k = bx0; k < L.near.width; k += 26) { n.fillStyle = '#1a1e2c'; n.fillRect(k, 62, 14, GROUND - 62); }
  for (let k = bx0; k < L.near.width; k += 7) { n.fillStyle = 'rgba(150,190,230,0.25)'; n.fillRect(k, 62, 1, 14 + R() * 26); }
  paveAndRoad(n, L, R, r, { pave: '#4a4a5c', pave2: '#55566a', pave3: '#3c3c4c',
    road: '#1e2028', road2: '#26283a', road3: '#181a22', lineCol: '#c8a83a' });
  // everything wet: pooled water holding the light
  puddles(n, R, L.near.width, ROAD + 4, 236, 30, 'rgba(120,170,230,0.20)');
  puddles(n, R, L.near.width, WALK + 8, CURB - 6, 16, 'rgba(140,180,230,0.16)');
  let pi = 0;
  const props = [
    (x) => streetLamp(n, x, WALK + 2, R, 100, '#cfe4ff'),
    (x) => busShelter(n, x, WALK + 46, R),
    (x) => hydrant(n, x, WALK + 50),
    (x) => trashBags(n, x, WALK + 50, R, 3),
    (x) => g_phonebooth(n, x, WALK + 50, R),
    (x) => newsBox(n, x, WALK + 50, R),
  ];
  for (let x = 70; x < L.near.width - 40; x += 96 + R() * 60) { props[pi % props.length](x); pi++; }
  for (let x = 150; x < L.near.width - 80; x += 210 + R() * 120) parkedCar(n, x, 236, R);
  // reflected smears of the neon above, stretched down the carriageway
  for (let k = 0; k < L.near.width / 90; k++) {
    const rx = r(0, L.near.width);
    n.fillStyle = pick2(R, ['rgba(255,74,138,0.13)', 'rgba(74,232,255,0.13)', 'rgba(232,255,74,0.10)', 'rgba(255,138,42,0.12)']);
    n.fillRect(rx, ROAD + 2, 12 + R() * 14, 38);
  }
  L.rain = 1;                                          // the viewer draws the downpour
}

// ---- A3: UNDER THE ELEVATED ----------------------------------------------
// The street runs beneath an el line. Steel columns march past in the
// foreground, a train thunders over in the mid layer, and the light is all
// sodium pooling between the girders.
function s1a_elevated(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#08060f'], [0.6, '#241a33'], [1, '#4a2a3e']]);
  stars(f, L, R, r, 60, 60);
  skyline(f, L, R, r, 126, '#120e22', '#d8a048', 30, 80);
  // mid: the deck of the elevated line, and a train crossing it
  m.fillStyle = '#1a1622'; m.fillRect(0, 54, L.mid.width, 22);
  m.fillStyle = '#26202e'; m.fillRect(0, 54, L.mid.width, 3);
  for (let x = 0; x < L.mid.width; x += 12) { m.fillStyle = 'rgba(0,0,0,0.35)'; m.fillRect(x, 57, 2, 19); }
  const tx = L.mid.width * 0.42, tlen = 300;
  for (let k = 0; k < 4; k++) {
    const cx = tx + k * 76;
    m.fillStyle = '#12101a'; m.fillRect(cx, 24, 72, 32);
    m.fillStyle = '#4a5260'; m.fillRect(cx + 1, 26, 70, 28);
    m.fillStyle = '#2a303c'; m.fillRect(cx + 1, 26, 70, 4);
    for (let wx = cx + 5; wx < cx + 66; wx += 15) { m.fillStyle = '#e8d890'; m.fillRect(wx, 32, 11, 12);
      m.fillStyle = 'rgba(0,0,0,0.35)'; m.fillRect(wx + 3, 34, 5, 8); }
  }
  m.fillStyle = 'rgba(255,224,150,0.07)'; m.fillRect(tx - 20, 56, tlen + 40, 94);
  blockRun(n, 0, len - 300, R, r);
  // under the tracks at the end: a wide dark span, the boss arena
  const u0 = len - 300;
  n.fillStyle = '#0c0a14'; n.fillRect(u0, 0, L.near.width - u0, GROUND);
  for (let k = 0; k < 60; k++) { n.fillStyle = '#c8a048'; n.fillRect(r(u0, L.near.width), r(40, 120), 1, 1); }
  paveAndRoad(n, L, R, r, { pave: '#4e4a58', pave2: '#5a5666', road: '#262430', lineCol: '#d8b038' });
  // the structure itself, in front of everything: columns, cross-bracing, deck
  n.fillStyle = '#1a1620'; n.fillRect(0, 26, L.near.width, 14);
  n.fillStyle = '#272230'; n.fillRect(0, 26, L.near.width, 3);
  n.fillStyle = 'rgba(0,0,0,0.45)'; n.fillRect(0, 40, L.near.width, 4);
  for (let x = 20; x < L.near.width; x += 108) {
    n.fillStyle = '#1e1a26'; n.fillRect(x, 40, 9, WALK - 40);
    n.fillStyle = '#2c2636'; n.fillRect(x + 1, 40, 3, WALK - 40);
    n.fillStyle = '#100d16'; n.fillRect(x - 5, WALK - 4, 19, 5);      // base plate
    for (let k = 0; k < 5; k++) { n.fillStyle = '#4a4254'; n.fillRect(x - 3, WALK - 3, 2, 2); n.fillRect(x + 11, WALK - 3, 2, 2); }
    // riveted bracing up to the deck
    n.strokeStyle = '#1e1a26'; n.lineWidth = 4;
    n.beginPath(); n.moveTo(x + 4, 54); n.lineTo(x + 54, 44); n.stroke();
    n.beginPath(); n.moveTo(x + 4, 54); n.lineTo(x - 46, 44); n.stroke();
    for (let k = 0; k < 7; k++) { n.fillStyle = '#4a4254'; n.fillRect(x + 1, 46 + k * 12, 2, 2); n.fillRect(x + 6, 52 + k * 12, 2, 2); }
    // the lamp bolted to every third column, and the pool it throws
    if ((x / 108) % 3 === 0) {
      n.fillStyle = '#ffd68a'; n.fillRect(x - 3, 46, 15, 4);
      n.fillStyle = 'rgba(255,214,138,0.11)';
      n.beginPath(); n.moveTo(x - 3, 50); n.lineTo(x - 40, 240); n.lineTo(x + 50, 240); n.lineTo(x + 12, 50); n.fill();
    }
  }
  let pi = 0;
  const props = [(x) => newsBox(n, x, WALK + 50, R), (x) => trashBags(n, x, WALK + 50, R, 3),
    (x) => hydrant(n, x, WALK + 50), (x) => crates(n, x, WALK + 48, R, 2), (x) => g_mailbox(n, x, WALK + 50, R)];
  for (let x = 70; x < L.near.width - 40; x += 104 + R() * 60) { props[pi % props.length](x); pi++; }
  for (let x = 180; x < L.near.width - 80; x += 240 + R() * 130) parkedCar(n, x, 236, R);
}

// ---- A4: NIGHT MARKET -----------------------------------------------------
// The wildcard. A packed market street under canopies and lanterns: vertical
// signs in two scripts, stalls between you and the shops, steam everywhere.
function s1a_market(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#0c0512'], [0.55, '#3a0f2e'], [1, '#7a1f38']]);
  stars(f, L, R, r, 40, 50);
  skyline(f, L, R, r, 128, '#1a0c1e', '#ffb050', 34, 92);
  for (let x = 0; x < L.mid.width;) {
    const bw = r(40, 76), bh = r(56, 112);
    m.fillStyle = '#2a1228'; m.fillRect(x, 136 - bh, bw, bh + 10);
    for (let wy = 136 - bh + 8; wy < 128; wy += 10) for (let wx = x + 4; wx < x + bw - 6; wx += 9) {
      m.fillStyle = R() < 0.36 ? '#ffc060' : '#1c0e1c'; m.fillRect(wx, wy, 5, 5);
    }
    // vertical signs hanging off the upper floors
    if (R() < 0.6) { const sx = x + bw * 0.7, c = pick2(R, ['#ff3a6a', '#3affc8', '#ffd83a', '#6a8aff']);
      m.fillStyle = '#12081a'; m.fillRect(sx, 136 - bh + 14, 9, 44);
      m.save(); m.shadowColor = c; m.shadowBlur = 5; m.fillStyle = c;
      for (let k = 0; k < 4; k++) m.fillRect(sx + 2, 136 - bh + 18 + k * 10, 5, 6); m.restore(); }
    x += bw + r(2, 12);
  }
  // near: shopfronts, but the street is defined by what is in front of them
  blockRun(n, 0, len - 340, R, r, [
    { f: bldgBodega, w: [92, 124] }, { f: bldgTenement, w: [120, 160] },
    { f: bldgDiner, w: [110, 140] }, { f: bldgBrownstone, w: [110, 140] },
  ]);
  const sq = len - 340;
  n.fillStyle = '#180a1c'; n.fillRect(sq, 0, L.near.width - sq, GROUND);
  for (let bx = sq; bx < L.near.width; bx += 30) { const bh = 50 + R() * 50;
    n.fillStyle = '#2a1030'; n.fillRect(bx, GROUND - 30 - bh, 26, bh + 30); }
  neonText(n, 'MARKET', sq + 80, 40, '#ffd83a', 3);
  paveAndRoad(n, L, R, r, { pave: '#5a4a52', pave2: '#69565f', pave3: '#463940',
    road: '#2e2430', road2: '#382c3a', lineCol: '#e8a030', line: false });
  // the canopy running the whole length, lanterns strung under it
  n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(0, 0, L.near.width, 34);
  for (let x = 0; x < L.near.width; x += 64) {
    const c = pick2(R, ['#b82a3a', '#c87a20', '#2a7a5a', '#8a2a6a']);
    for (let k = 0; k < 64; k += 8) { n.fillStyle = (k / 8) % 2 ? c : '#e8e0d0'; n.fillRect(x + k, 22, 8, 12); }
    n.fillStyle = 'rgba(0,0,0,0.3)'; n.fillRect(x, 33, 64, 2);
    n.fillStyle = '#3a2a30'; n.fillRect(x + 30, 35, 3, 26);
  }
  n.strokeStyle = '#2a1a22'; n.lineWidth = 1;
  for (let x = 0; x < L.near.width; x += 90) { n.beginPath(); n.moveTo(x, 40); n.quadraticCurveTo(x + 45, 52, x + 90, 40); n.stroke(); }
  for (let x = 14; x < L.near.width; x += 30) {
    const ly = 44 + Math.abs(Math.sin(x * 0.035)) * 8;
    const c = pick2(R, ['#ff4a3a', '#ffb83a', '#ff6a8a']);
    n.save(); n.shadowColor = c; n.shadowBlur = 7; n.fillStyle = c;
    n.beginPath(); n.ellipse(x, ly, 5, 7, 0, 0, 7); n.fill(); n.restore();
    n.fillStyle = '#c89030'; n.fillRect(x - 1, ly - 8, 2, 3); n.fillRect(x - 2, ly + 6, 4, 2);
  }
  // the stalls: the thing you actually walk past
  let sx = 30;
  while (sx < L.near.width - 60) {
    const sw = 44 + R() * 26, top = WALK - 44;
    n.fillStyle = '#1a1018'; n.fillRect(sx, top, sw, 5);
    const c = pick2(R, ['#c8303a', '#2a7a5a', '#d8a020', '#3a4a9a']);
    for (let k = 0; k < sw; k += 8) { n.fillStyle = (k / 8) % 2 ? c : '#e8e0d0'; n.fillRect(sx + k, top, 8, 5); }
    n.fillStyle = '#3a2a24'; n.fillRect(sx + 2, top + 5, 2, 30); n.fillRect(sx + sw - 4, top + 5, 2, 30);
    n.fillStyle = '#4a3428'; n.fillRect(sx, top + 33, sw, 4);       // the table
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(sx, top + 37, sw, 7);
    const kind = Math.floor(R() * 3);
    if (kind === 0) for (let k = 0; k < 7; k++) {                    // produce
      n.fillStyle = pick2(R, ['#e8603a', '#d8c030', '#5a9a3a', '#c83050']);
      n.beginPath(); n.arc(sx + 6 + k * (sw - 12) / 6, top + 30, 2.6, 0, 7); n.fill();
    }
    else if (kind === 1) for (let k = 0; k < 4; k++) {               // hanging ducks
      n.fillStyle = '#b8582a'; n.fillRect(sx + 7 + k * 11, top + 8, 6, 13);
      n.fillStyle = '#8a3a1a'; n.fillRect(sx + 9 + k * 11, top + 6, 2, 3);
    }
    else {                                                            // fish on ice
      n.fillStyle = '#c8d8e0'; n.fillRect(sx + 3, top + 26, sw - 6, 7);
      for (let k = 0; k < 5; k++) { n.fillStyle = pick2(R, ['#8a9aa8', '#a8b0b8', '#7a8a9a']);
        n.beginPath(); n.ellipse(sx + 8 + k * (sw - 16) / 4, top + 28, 4, 2, 0.2, 0, 7); n.fill(); }
    }
    n.fillStyle = '#ffe8a0'; n.fillRect(sx + sw / 2 - 4, top + 6, 8, 2);
    n.fillStyle = 'rgba(255,232,160,0.10)'; n.fillRect(sx - 2, top + 8, sw + 4, 30);
    sx += sw + 16 + R() * 40;
  }
  for (let x = 60; x < L.near.width; x += 150 + R() * 90) crates(n, x, WALK + 50, R, 2 + Math.floor(R() * 2));
  for (let k = 0; k < 20; k++) pigeon(n, r(0, L.near.width), ROAD + 6 + r(0, 28), R, '#5a4a4a');
  L.steam = 1;                                         // the viewer adds drifting steam
}
