// ============================================================ STAGE 3-B options
// Thirty storeys up, and the Wrecker MK-II has to fit on it. Every option needs
// open sky above for the beams hazard and a clear arena at the end.

function cityBelow(f, L, R, r, top) {
  f.fillStyle = '#2a1c3c'; f.fillRect(0, top, L.far.width, 240 - top);
  for (let x = 0; x < L.far.width; x += 7) { f.fillStyle = R() < 0.4 ? '#3a2a4e' : '#241a34';
    f.fillRect(x, top + R() * 10, 6, 240 - top); }
  for (let k = 0; k < L.far.width * 2.2; k++) { f.fillStyle = R() < 0.6 ? '#f2d070' : '#7ab8f0';
    f.fillRect(r(0, L.far.width), r(top + 4, 238), 1, 1); }
}
function duskSky(f, L, R, r) {
  const sky = f.createLinearGradient(0, 0, 0, 170);
  sky.addColorStop(0, '#1a1440'); sky.addColorStop(0.42, '#5a2a6a'); sky.addColorStop(0.76, '#e0704a'); sky.addColorStop(1, '#ffc068');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  for (let i = 0; i < 46; i++) { f.fillStyle = 'rgba(255,255,255,0.45)'; f.fillRect(r(0, L.far.width), r(0, 46), 1, 1); }
  for (let k = 0; k < 10; k++) { f.fillStyle = 'rgba(255,200,180,0.16)'; f.fillRect(r(0, L.far.width), r(28, 96), r(50, 110), 4); }
}

// ---- B1: THE OPEN FLOOR ---------------------------------------------------
function s3b_openfloor(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  duskSky(f, L, R, r);
  cityBelow(f, L, R, r, 150);
  for (let x = 0; x < L.far.width; x += 78) { const h = 30 + R() * 56;    // neighbouring towers
    f.fillStyle = '#2a2048'; f.fillRect(x, 150 - h, 40, h);
    for (let k = 0; k < 20; k++) if (R() < 0.35) { f.fillStyle = '#d8b050'; f.fillRect(x + 4 + R() * 32, 150 - h + 4 + R() * (h - 8), 3, 3); } }
  // mid: the floors below this one, seen as a receding stack of slab edges
  for (let y = 0; y < 3; y++) {
    m.fillStyle = '#2a2436'; m.fillRect(0, 96 + y * 20, L.mid.width, 7);
    m.fillStyle = '#3a3448'; m.fillRect(0, 96 + y * 20, L.mid.width, 2);
    for (let x = 0; x < L.mid.width; x += 64) { m.fillStyle = '#1e1a2a'; m.fillRect(x, 103 + y * 20, 9, 13); }
  }
  // near: the columns and the slab above, with netting between them
  const SLAB = 40;
  n.fillStyle = '#4c4e58'; n.fillRect(0, SLAB - 14, L.near.width, 14);
  n.fillStyle = '#5c5e6a'; n.fillRect(0, SLAB - 14, L.near.width, 3);
  n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(0, SLAB, L.near.width, 4);
  for (let x = 0; x < L.near.width; x += 22) { n.fillStyle = 'rgba(0,0,0,0.12)'; n.fillRect(x, SLAB - 11, 2, 11); }
  for (let x = 30; x < L.near.width; x += 160) {
    concrete(n, x, SLAB, 26, 142 - SLAB, '#565a66', R);
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x + 22, SLAB, 4, 142 - SLAB);
    n.fillStyle = '#e8c020'; n.fillRect(x - 2, 118, 30, 4);                 // hazard band
    for (let k = 0; k < 30; k += 8) { n.fillStyle = '#1a1a1e'; n.fillRect(x - 2 + k, 118, 4, 4); }
    for (let k = 0; k < 5; k++) { n.fillStyle = '#7a7a86'; n.fillRect(x + 4 + (k % 2) * 14, SLAB + 12 + k * 16, 3, 3); }
  }
  // safety netting stretched between the columns, and the drop beyond it
  for (let x = 0; x < L.near.width; x += 160) {
    n.strokeStyle = 'rgba(210,150,60,0.30)'; n.lineWidth = 1;
    for (let k = -6; k < 170; k += 9) {
      n.beginPath(); n.moveTo(x + k, 56); n.lineTo(x + k + 46, 126); n.stroke();
      n.beginPath(); n.moveTo(x + k, 56); n.lineTo(x + k - 46, 126); n.stroke();
    }
    n.fillStyle = '#c87a20'; n.fillRect(x, 54, 160, 3);
  }
  // rebar mats, a pump hose and props standing on the deck
  let pi = 0;
  for (let x = 70; x < len - 320; x += 170) {
    const kind = pi % 3; pi++;
    if (kind === 0) { n.strokeStyle = '#6a5a4a'; n.lineWidth = 1.5;
      for (let k = 0; k < 8; k++) { n.beginPath(); n.moveTo(x + k * 9, 150); n.lineTo(x + k * 9 + 6, 178); n.stroke(); }
      for (let k = 0; k < 4; k++) { n.beginPath(); n.moveTo(x, 152 + k * 8); n.lineTo(x + 72, 156 + k * 8); n.stroke(); } }
    else if (kind === 1) { n.strokeStyle = '#3a4a5a'; n.lineWidth = 7;     // the concrete pump hose
      n.beginPath(); n.moveTo(x - 20, 142); n.quadraticCurveTo(x + 40, 170, x + 96, 150); n.stroke();
      n.strokeStyle = '#4e5e70'; n.lineWidth = 3; n.stroke();
      n.fillStyle = '#7a8090'; n.fillRect(x + 92, 144, 12, 12); }
    else { for (let k = 0; k < 4; k++) {                                   // acrow props
      n.fillStyle = '#c85a20'; n.fillRect(x + k * 18, SLAB + 4, 5, 138 - SLAB);
      n.fillStyle = '#e8842a'; n.fillRect(x + k * 18, SLAB + 4, 2, 138 - SLAB);
      n.fillStyle = '#2a2a32'; n.fillRect(x + k * 18 - 3, 138, 11, 4); } }
  }
  // the arena: a clear, swept bay at the end with the crane mast through it
  const a0 = len - 320;
  n.fillStyle = '#16141c'; n.fillRect(a0 + 140, SLAB, 10, 142 - SLAB);
  n.fillStyle = '#e8b020'; n.fillRect(a0 + 138, SLAB, 14, 142 - SLAB);
  for (let k = 0; k < 142 - SLAB; k += 14) { n.strokeStyle = '#8a6a14'; n.lineWidth = 1.5;
    n.beginPath(); n.moveTo(a0 + 138, SLAB + k); n.lineTo(a0 + 152, SLAB + k + 14); n.stroke();
    n.beginPath(); n.moveTo(a0 + 152, SLAB + k); n.lineTo(a0 + 138, SLAB + k + 14); n.stroke(); }
  // the floor slab: power-floated concrete, chalk lines, spatter
  n.fillStyle = '#54565f'; n.fillRect(0, 142, L.near.width, 98);
  for (let k = 0; k < L.near.width * 1.5; k++) { n.fillStyle = R() < 0.5 ? '#5d5f69' : '#4a4c55';
    n.fillRect(r(0, L.near.width), r(144, 240), 3, 1); }
  for (let x = 0; x < L.near.width; x += 90) { n.fillStyle = 'rgba(0,0,0,0.14)'; n.fillRect(x, 142, 2, 98); }
  for (let y = 162; y < 240; y += 26) { n.fillStyle = 'rgba(0,0,0,0.10)'; n.fillRect(0, y, L.near.width, 2); }
  for (let k = 0; k < L.near.width / 70; k++) { n.fillStyle = 'rgba(230,230,235,0.30)';
    n.fillRect(r(0, L.near.width), r(150, 234), 30 + R() * 50, 1); }
  n.fillStyle = '#3e4048'; n.fillRect(0, 142, L.near.width, 3);
  n.fillStyle = '#e8b020'; n.fillRect(0, 236, L.near.width, 4);
  L.wind = 1;
}

// ---- B2: THE STEEL FRAME --------------------------------------------------
// No slab yet. You fight along the beams themselves with open air between them.
function s3b_frame(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  duskSky(f, L, R, r);
  cityBelow(f, L, R, r, 158);
  for (let x = 0; x < L.far.width; x += 92) { const h = 24 + R() * 48;
    f.fillStyle = '#2a2048'; f.fillRect(x, 158 - h, 36, h); }
  // mid: the frame carrying on away from you, storey after storey
  for (let x = 0; x < L.mid.width; x += 116) {
    m.fillStyle = '#4a2e28'; m.fillRect(x, 20, 8, 130);
    for (let y = 30; y < 150; y += 34) {
      m.fillStyle = '#5a3830'; m.fillRect(x, y, 116, 6);
      m.strokeStyle = '#4a2e28'; m.lineWidth = 2;
      m.beginPath(); m.moveTo(x + 8, y + 6); m.lineTo(x + 108, y + 34); m.stroke();
    }
  }
  // near: the storey you are on. Columns, a top beam, and decking in patches.
  const TOP = 42;
  for (let x = 0; x < L.near.width; x += 150) {
    // the column, an H-section seen edge on
    n.fillStyle = '#7a3a26'; n.fillRect(x, TOP - 16, 22, 158 - TOP);
    n.fillStyle = '#a8542e'; n.fillRect(x + 3, TOP - 16, 6, 158 - TOP);
    n.fillStyle = 'rgba(0,0,0,0.38)'; n.fillRect(x + 16, TOP - 16, 6, 158 - TOP);
    n.fillStyle = '#c87a4a'; n.fillRect(x, TOP - 16, 22, 2);
    for (let k = 0; k < 150; k += 18) { n.fillStyle = '#d8946a'; n.fillRect(x + 4, TOP + k, 3, 3); n.fillRect(x + 12, TOP + 9 + k, 3, 3); }
    // the splice plate where two column lengths meet
    n.fillStyle = '#8a4530'; n.fillRect(x - 3, TOP + 46, 28, 16);
    for (let k = 0; k < 4; k++) { n.fillStyle = '#d8946a'; n.fillRect(x + 1 + (k % 2) * 18, TOP + 50 + Math.floor(k / 2) * 7, 3, 3); }
    // the beam running to the next column, with its knee brace
    n.fillStyle = '#7a3a26'; n.fillRect(x, TOP, 150, 11);
    n.fillStyle = '#b8603a'; n.fillRect(x, TOP, 150, 3);
    n.fillStyle = 'rgba(0,0,0,0.32)'; n.fillRect(x, TOP + 8, 150, 3);
    n.strokeStyle = '#7a3a26'; n.lineWidth = 6;
    n.beginPath(); n.moveTo(x + 22, TOP + 11); n.lineTo(x + 58, TOP + 38); n.stroke();
    n.beginPath(); n.moveTo(x + 128, TOP + 11); n.lineTo(x + 92, TOP + 38); n.stroke();
  }
  // metal decking laid in patches, with the gaps open to the drop
  let x2 = 0;
  while (x2 < L.near.width) {
    const w2 = 90 + R() * 130, gap = R() < 0.45;
    if (!gap) {
      n.fillStyle = '#4e5561'; n.fillRect(x2, 142, w2, 98);
      for (let k = 0; k < w2; k += 11) { n.fillStyle = '#5b636f'; n.fillRect(x2 + k, 142, 6, 98);
        n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x2 + k + 6, 142, 5, 98); }
      n.fillStyle = '#39414e'; n.fillRect(x2, 142, w2, 3);
      n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x2, 142, 3, 98);
      n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x2 + w2 - 3, 142, 3, 98);
      for (let k = 0; k < w2 / 18; k++) { n.fillStyle = 'rgba(200,120,60,0.16)'; n.fillRect(x2 + R() * w2, 146 + R() * 88, 8 + R() * 14, 5); }
    } else {
      // an open bay: you can see the floors below through it
      n.fillStyle = 'rgba(10,8,20,0.55)'; n.fillRect(x2, 142, w2, 98);
      for (let d = 0; d < 3; d++) {
        n.fillStyle = `rgba(90,60,50,${0.5 - d * 0.13})`;
        n.fillRect(x2 + 6 + d * 5, 160 + d * 26, w2 - 12 - d * 10, 5);
      }
      n.fillStyle = '#c87a20'; n.fillRect(x2, 142, w2, 3);                  // the edge you must not cross
      for (let k = 0; k < w2; k += 12) { n.fillStyle = '#1a1a1e'; n.fillRect(x2 + k, 142, 6, 3); }
      n.strokeStyle = 'rgba(210,150,60,0.45)'; n.lineWidth = 1;             // the tag line strung over it
      n.beginPath(); n.moveTo(x2, 150); n.quadraticCurveTo(x2 + w2 / 2, 162, x2 + w2, 150); n.stroke();
    }
    x2 += w2;
  }
  // a bundle of beams slung from above at the far end, over the arena
  const a0 = len - 300;
  n.fillStyle = '#2a2a32'; n.fillRect(a0 + 120, 0, 2, 44);
  n.fillStyle = '#e8b020'; n.fillRect(a0 + 110, 44, 22, 10);
  n.fillStyle = '#7a3a26';
  for (let k = 0; k < 4; k++) n.fillRect(a0 + 84, 54 + k * 7, 76, 6);
  n.fillStyle = '#b8603a'; for (let k = 0; k < 4; k++) n.fillRect(a0 + 84, 54 + k * 7, 76, 2);
  n.strokeStyle = '#4a4a52'; n.lineWidth = 2;
  n.beginPath(); n.moveTo(a0 + 116, 50); n.lineTo(a0 + 88, 56); n.moveTo(a0 + 126, 50); n.lineTo(a0 + 156, 56); n.stroke();
  L.wind = 1;
}

// ---- B3: THE CRANE DECK ---------------------------------------------------
// The fight is on the crane itself: slewing platform, the jib running off into
// the distance, counterweights and the operator's cab.
function s3b_crane(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  duskSky(f, L, R, r);
  cityBelow(f, L, R, r, 140);
  for (let x = 0; x < L.far.width; x += 64) { const h = 20 + R() * 40;
    f.fillStyle = '#241c40'; f.fillRect(x, 140 - h, 30, h); }
  // mid: the tower going down out of sight beneath you
  m.fillStyle = '#c87a14'; m.fillRect(L.mid.width * 0.5 - 30, 92, 60, 58);
  m.fillStyle = '#e09a2a'; m.fillRect(L.mid.width * 0.5 - 30, 92, 12, 58);
  m.strokeStyle = '#8a5a10'; m.lineWidth = 3;
  for (let k = 0; k < 58; k += 14) {
    m.beginPath(); m.moveTo(L.mid.width * 0.5 - 30, 92 + k); m.lineTo(L.mid.width * 0.5 + 30, 92 + k + 14); m.stroke();
    m.beginPath(); m.moveTo(L.mid.width * 0.5 + 30, 92 + k); m.lineTo(L.mid.width * 0.5 - 30, 92 + k + 14); m.stroke();
  }
  // near: the jib. The structure reads above, and the walkway itself fills the
  // whole walkable band (150..230) so you are standing ON it, not under it.
  const TOPC = 92, CHORD = 138, DECK = 150;
  n.fillStyle = '#c87a14'; n.fillRect(0, TOPC, L.near.width, 10);           // top chord
  n.fillStyle = '#e09a2a'; n.fillRect(0, TOPC, L.near.width, 3);
  n.strokeStyle = '#c87a14'; n.lineWidth = 5;                               // lattice web
  for (let x = 0; x < L.near.width; x += 46) {
    n.beginPath(); n.moveTo(x, TOPC + 10); n.lineTo(x + 23, CHORD); n.lineTo(x + 46, TOPC + 10); n.stroke();
    n.fillStyle = '#8a5a10'; n.fillRect(x + 21, TOPC + 10, 5, CHORD - TOPC - 10);
  }
  for (let x = 0; x < L.near.width; x += 23) { n.fillStyle = '#ffd06a'; n.fillRect(x, TOPC + 4, 3, 3); }
  n.fillStyle = '#c87a14'; n.fillRect(0, CHORD, L.near.width, 12);          // bottom chord
  n.fillStyle = '#e09a2a'; n.fillRect(0, CHORD, L.near.width, 3);
  n.fillStyle = '#8a5a10'; n.fillRect(0, CHORD + 12, L.near.width, 3);
  // the walking surface: open grating, seen from above, the drop showing through
  n.fillStyle = '#b8720f'; n.fillRect(0, DECK, L.near.width, 240 - DECK);
  for (let y = DECK; y < 240; y += 7) {
    n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(0, y, L.near.width, 2);
    n.fillStyle = 'rgba(255,214,106,0.10)'; n.fillRect(0, y + 2, L.near.width, 1);
  }
  for (let x = 0; x < L.near.width; x += 9) { n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x, DECK, 2, 240 - DECK); }
  for (let x = 0; x < L.near.width; x += 46) {                              // cross members under the grating
    n.fillStyle = '#8a5a10'; n.fillRect(x, DECK + 26, 46, 4);
    n.fillStyle = '#6a4408'; n.fillRect(x, DECK + 58, 46, 4);
  }
  for (let k = 0; k < L.near.width / 24; k++) { n.fillStyle = 'rgba(0,0,0,0.16)';   // wear and grease
    n.fillRect(r(0, L.near.width), r(DECK + 4, 236), 8 + R() * 16, 4); }
  n.fillStyle = '#ffd06a'; n.fillRect(0, DECK, L.near.width, 2);
  // the handrail along the near edge, drawn over the top of everything
  n.fillStyle = '#c8302a'; n.fillRect(0, 232, L.near.width, 3);
  n.fillStyle = '#e8e0d0'; n.fillRect(0, 236, L.near.width, 2);
  for (let x = 0; x < L.near.width; x += 54) { n.fillStyle = '#c87a14'; n.fillRect(x, 230, 4, 10); }
  // the hoist trolley and its block, riding the top chord
  for (let x = 140; x < L.near.width; x += 420) {
    n.fillStyle = '#2a2a32'; n.fillRect(x, TOPC - 12, 46, 14);
    n.fillStyle = '#3e3e48'; n.fillRect(x + 2, TOPC - 10, 42, 5);
    n.fillStyle = '#16141c'; n.fillRect(x + 8, TOPC - 16, 6, 5); n.fillRect(x + 32, TOPC - 16, 6, 5);
    n.fillStyle = '#4a4a52'; n.fillRect(x + 22, TOPC + 2, 2, 30);
    n.fillStyle = '#e8b020'; n.fillRect(x + 14, CHORD - 14, 18, 12);
    n.fillStyle = '#8a6a14'; n.fillRect(x + 14, CHORD - 14, 18, 3);
  }
  // the upper handrail you can see past, and the wind socks
  n.fillStyle = '#c8302a'; n.fillRect(0, TOPC - 26, L.near.width, 2);
  for (let x = 0; x < L.near.width; x += 60) { n.fillStyle = '#c87a14'; n.fillRect(x, TOPC - 26, 3, 26); }
  for (let x = 220; x < L.near.width; x += 560) {
    n.fillStyle = '#2a2a32'; n.fillRect(x, TOPC - 54, 2, 28);
    for (let k = 0; k < 4; k++) { n.fillStyle = (k % 2) ? '#e8642a' : '#e8e0d0';
      n.fillRect(x + 2 + k * 8, TOPC - 52 + k, 8, 11 - k); }
  }
  // the slewing platform at the end: cab, counterweights, the arena floor
  const a0 = len - 340, aw = L.near.width - a0;
  // the platform is solid plate rather than grating, so the arena reads clean
  n.fillStyle = '#c88a1a'; n.fillRect(a0, DECK, aw, 240 - DECK);
  for (let y = DECK + 10; y < 236; y += 20) { n.fillStyle = 'rgba(0,0,0,0.14)'; n.fillRect(a0, y, aw, 2); }
  for (let x = a0; x < L.near.width; x += 30) { n.fillStyle = 'rgba(0,0,0,0.12)'; n.fillRect(x, DECK, 2, 240 - DECK); }
  n.fillStyle = '#ffd06a'; n.fillRect(a0, DECK, aw, 3);
  n.fillStyle = '#16141c'; n.fillRect(a0 - 3, DECK, 5, 240 - DECK);
  n.fillStyle = '#c87a14'; n.fillRect(a0 + 40, 62, 70, CHORD - 62);          // the A-frame
  n.fillStyle = '#16141c'; n.fillRect(a0 + 44, 66, 62, CHORD - 70);
  n.strokeStyle = '#c87a14'; n.lineWidth = 6;
  n.beginPath(); n.moveTo(a0 + 46, CHORD); n.lineTo(a0 + 75, 40); n.lineTo(a0 + 104, CHORD); n.stroke();
  n.fillStyle = '#2a2a32'; n.fillRect(a0 + aw - 120, 88, 96, 50);           // counterweight slabs
  for (let k = 0; k < 4; k++) { n.fillStyle = k % 2 ? '#3a3a44' : '#33333c';
    n.fillRect(a0 + aw - 118 + k * 24, 90, 22, 46);
    n.fillStyle = 'rgba(255,255,255,0.08)'; n.fillRect(a0 + aw - 118 + k * 24, 90, 22, 2); }
  n.fillStyle = '#e8b020'; n.fillRect(a0 + aw - 122, 84, 100, 5);
  n.fillStyle = '#16141c'; n.fillRect(a0 + 126, 96, 46, 42);                // the cab
  n.fillStyle = '#d8d8e0'; n.fillRect(a0 + 128, 98, 42, 38);
  n.fillStyle = '#1e2a3a'; n.fillRect(a0 + 130, 100, 38, 24);
  n.fillStyle = 'rgba(180,220,255,0.35)'; n.fillRect(a0 + 132, 102, 14, 20);
  n.fillStyle = '#c8302a'; n.fillRect(a0 + 126, 92, 46, 4);
  L.wind = 1; L.vertigo = 1;
}

// ---- B4: THE CURTAIN WALL -------------------------------------------------
// The wildcard. The floor is being glazed: panels in, panels stacked, one bay
// still open to the sky, and the whole sunset doubled in the glass.
function s3b_glass(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  duskSky(f, L, R, r);
  cityBelow(f, L, R, r, 152);
  for (let x = 0; x < L.far.width; x += 84) { const h = 28 + R() * 54;
    f.fillStyle = '#2a2048'; f.fillRect(x, 152 - h, 38, h);
    for (let k = 0; k < 16; k++) if (R() < 0.3) { f.fillStyle = '#e8c060'; f.fillRect(x + 4 + R() * 30, 152 - h + 4 + R() * (h - 8), 3, 3); } }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  // near: the mullion grid, most bays glazed, some open, some with panels on a trolley
  const HEAD = 34, SILL = 142;
  n.fillStyle = '#39414e'; n.fillRect(0, HEAD - 10, L.near.width, 12);
  n.fillStyle = '#4e5a6a'; n.fillRect(0, HEAD - 10, L.near.width, 3);
  let x = 0, seq = 0;
  while (x < len - 320) {
    const bw = 76;
    const state = seq % 7 === 3 ? 'open' : (seq % 7 === 6 ? 'part' : 'glazed');
    if (state === 'glazed') {
      // the glass: the sky reflected, but shifted and cooler than the real one
      const g = n.createLinearGradient(0, HEAD, 0, SILL);
      g.addColorStop(0, '#2c2a58'); g.addColorStop(0.44, '#6a3a72'); g.addColorStop(0.78, '#c06a52'); g.addColorStop(1, '#e0a068');
      n.fillStyle = g; n.fillRect(x + 4, HEAD, bw - 8, SILL - HEAD);
      n.fillStyle = 'rgba(255,255,255,0.10)';                     // the sheen band
      n.beginPath(); n.moveTo(x + 4, SILL); n.lineTo(x + 30, HEAD); n.lineTo(x + 46, HEAD); n.lineTo(x + 20, SILL); n.fill();
      for (let k = 0; k < 16; k++) { n.fillStyle = 'rgba(242,208,112,0.45)';   // the city's lights, reflected
        n.fillRect(x + 8 + R() * (bw - 20), HEAD + 66 + R() * 42, 2, 2); }
      n.fillStyle = 'rgba(120,150,210,0.10)'; n.fillRect(x + 4, HEAD, bw - 8, SILL - HEAD);
      if (R() < 0.3) {                                            // a panel still carrying its protective film
        n.fillStyle = 'rgba(190,200,210,0.30)'; n.fillRect(x + 4, HEAD, bw - 8, SILL - HEAD);
        n.fillStyle = '#c8302a'; n.fillRect(x + 14, HEAD + 40, bw - 28, 8);
      }
    } else if (state === 'open') {
      n.fillStyle = 'rgba(0,0,0,0)'; n.clearRect(x + 4, HEAD, bw - 8, SILL - HEAD);
      n.fillStyle = '#c87a20'; n.fillRect(x + 4, SILL - 26, bw - 8, 4);       // the barrier across the hole
      n.fillRect(x + 4, SILL - 12, bw - 8, 4);
      for (let k = 0; k < bw - 8; k += 12) { n.fillStyle = '#1a1a1e'; n.fillRect(x + 4 + k, SILL - 26, 6, 4); n.fillRect(x + 4 + k, SILL - 12, 6, 4); }
      n.fillStyle = 'rgba(255,190,120,0.10)'; n.fillRect(x + 4, HEAD, bw - 8, SILL - HEAD - 26);
    } else {
      n.fillStyle = '#1c2029'; n.fillRect(x + 4, HEAD, bw - 8, SILL - HEAD);  // backing board, panel not yet on
      for (let k = 0; k < SILL - HEAD; k += 14) { n.fillStyle = '#262b36'; n.fillRect(x + 4, HEAD + k, bw - 8, 3); }
      n.fillStyle = '#39414e'; n.fillRect(x + 4, HEAD + 40, bw - 8, 5);
    }
    // the mullion itself, and the transom band across the middle
    n.fillStyle = '#39414e'; n.fillRect(x, HEAD - 4, 6, SILL - HEAD + 10);
    n.fillStyle = '#556172'; n.fillRect(x + 1, HEAD - 4, 2, SILL - HEAD + 10);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 4, HEAD - 4, 2, SILL - HEAD + 10);
    n.fillStyle = '#39414e'; n.fillRect(x, HEAD + 52, bw, 6);
    n.fillStyle = '#4e5a6a'; n.fillRect(x, HEAD + 52, bw, 2);
    x += bw; seq++;
  }
  // a stillage of glass waiting to go in, and a vacuum lifter
  for (let px_ = 120; px_ < len - 360; px_ += 380) {
    n.fillStyle = '#2a2e36'; n.fillRect(px_, 108, 90, 34);
    n.fillStyle = '#c8302a'; n.fillRect(px_, 104, 90, 5);
    for (let k = 0; k < 6; k++) { n.fillStyle = `rgba(150,190,200,${0.55 - k * 0.06})`;
      n.save(); n.translate(px_ + 10 + k * 5, 106); n.rotate(0.10); n.fillRect(0, -44, 4, 44); n.restore(); }
    n.fillStyle = '#39414e'; n.fillRect(px_ - 4, 140, 98, 4);
  }
  // the arena: the corner of the building, glazed on both faces
  const a0 = len - 320;
  n.fillStyle = '#39414e'; n.fillRect(a0, HEAD - 10, L.near.width - a0, 12);
  const g2 = n.createLinearGradient(0, HEAD, 0, SILL);
  g2.addColorStop(0, '#26244e'); g2.addColorStop(0.44, '#5e3468'); g2.addColorStop(0.8, '#b8604c'); g2.addColorStop(1, '#d89864');
  n.fillStyle = g2; n.fillRect(a0 + 6, HEAD, L.near.width - a0 - 6, SILL - HEAD);
  for (let k = 0; k < 90; k++) { n.fillStyle = 'rgba(242,208,112,0.40)';
    n.fillRect(a0 + 10 + R() * (L.near.width - a0 - 20), HEAD + 60 + R() * 48, 2, 2); }
  for (let mx = a0; mx < L.near.width; mx += 76) {
    n.fillStyle = '#39414e'; n.fillRect(mx, HEAD - 4, 6, SILL - HEAD + 10);
    n.fillStyle = '#556172'; n.fillRect(mx + 1, HEAD - 4, 2, SILL - HEAD + 10);
  }
  n.fillStyle = '#39414e'; n.fillRect(a0, HEAD + 52, L.near.width - a0, 6);
  n.fillStyle = 'rgba(255,255,255,0.09)';
  n.beginPath(); n.moveTo(a0 + 20, SILL); n.lineTo(a0 + 120, HEAD); n.lineTo(a0 + 160, HEAD); n.lineTo(a0 + 60, SILL); n.fill();
  // the floor: polished screed that picks the sunset up off the glass
  n.fillStyle = '#4a4c56'; n.fillRect(0, SILL, L.near.width, 98);
  for (let k = 0; k < L.near.width * 1.3; k++) { n.fillStyle = R() < 0.5 ? '#53555f' : '#41434c';
    n.fillRect(r(0, L.near.width), r(SILL + 2, 240), 3, 1); }
  for (let x2 = 0; x2 < L.near.width; x2 += 76) { n.fillStyle = 'rgba(0,0,0,0.13)'; n.fillRect(x2, SILL, 2, 98); }
  n.fillStyle = 'rgba(224,160,104,0.13)'; n.fillRect(0, SILL, L.near.width, 40);
  for (let x2 = 0; x2 < L.near.width; x2 += 76) { n.fillStyle = 'rgba(255,200,140,0.10)'; n.fillRect(x2 + 10, SILL, 54, 74); }
  n.fillStyle = '#343640'; n.fillRect(0, SILL, L.near.width, 3);
  n.fillStyle = '#e8b020'; n.fillRect(0, 236, L.near.width, 4);
}
