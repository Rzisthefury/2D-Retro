// ============================================================ the picker (stage 2)
const SECTIONS = [
  { id: 'A', stage: '3-A', now: 'GROUND LEVEL', len: 1500, options: [
    { k: 'A1', name: 'The Foundation', f: s3a_foundation,
      pitch: 'What you have now, built out: a live site at dusk with everything a site actually has standing about.',
      notes: ['Stacked cabins with a stair between them, a concrete pump with its boom folded, rebar cages, a skip of broken brick',
              'Tower cranes overhead on the mid layer - the beams hazard has somewhere to fall from',
              'Churned dirt with tyre ruts, standing water and floodlight masts; the shaft hazard is a real hole in the slab'] },
    { k: 'A2', name: 'The Demolition', f: s3a_demolition,
      pitch: 'Not going up - coming down. Half a building still standing with its rooms opened to the air.',
      notes: ['The cut face shows floors like a doll\'s house: wallpaper, a bath left hanging, rebar out of the slab edges',
              'Wrecking ball on a crawler crane, rubble chutes bolted down the facades, plastic sheeting over blown windows',
              'Brick dust in the air, spoil heaps and rubble underfoot instead of clean dirt'] },
    { k: 'A3', name: 'The Dry Dock', f: s3a_drydock,
      pitch: 'The yard is on the water. A hull in dock with gantries running the length of it.',
      notes: ['Plated hull with anti-fouling below the waterline, portholes, staging and ladders up the side',
              'Welding light flaring against the plate, gantry cranes overhead dropping hull sections',
              'Wet dock floor with keel blocks, mooring bollards and chain; the caisson gate closes the far end'] },
    { k: 'A4', name: 'The Batching Plant', f: s3a_plant,
      pitch: 'The wildcard. Silos, conveyors and aggregate heaps in an ochre dust haze.',
      notes: ['Three-silo bank with discharge hoppers overhead, a mixer house, aggregate bays with graded heaps',
              'A conveyor climbs across the entire mid layer; the hoppers are what drop on you',
              'Warm ochre palette, nothing like the rest of the game - and dumper trucks at the weighbridge for the finish'] },
  ] },
  { id: 'B', stage: '3-B', now: '30TH FLOOR', len: 1200, options: [
    { k: 'B1', name: 'The Open Floor', f: s3b_openfloor,
      pitch: 'A bare slab thirty storeys up, columns with no cladding, netting between them.',
      notes: ['Power-floated concrete with chalk lines, rebar mats, a pump hose and rows of acrow props',
              'Orange safety netting stretched between the columns with the drop behind it',
              'The crane mast passes straight through the floor at the arena end'] },
    { k: 'B2', name: 'The Steel Frame', f: s3b_frame,
      pitch: 'No slab yet. You fight along the beams with open air between them.',
      notes: ['H-columns with splice plates and bolt patterns, beams with knee braces, red oxide primer everywhere',
              'Metal decking in patches - the gaps are open, showing the floors below through them',
              'A bundle of beams hangs from the hook over the arena; the most vertiginous of the four'] },
    { k: 'B3', name: 'The Crane Deck', f: s3b_crane,
      pitch: 'The fight is on the crane itself - along the jib, out to the slewing platform.',
      notes: ['A lattice walkway between top chord and deck, hoist trolley riding overhead, wind socks',
              'Ends on the slewing platform: A-frame, operator\'s cab and a stack of counterweights',
              'The strongest silhouette in the game and the only one where the arena is a machine'] },
    { k: 'B4', name: 'The Curtain Wall', f: s3b_glass,
      pitch: 'The wildcard. The floor is being glazed, and the sunset is doubled in the glass.',
      notes: ['Mullion grid with most bays glazed, one bay open to the sky behind a barrier, one still on backing board',
              'Panels stacked on a stillage waiting to go in, some glass still carrying its protective film',
              'The polished screed picks the sunset up off the glass - much the prettiest option, and the least raw'] },
  ] },
];

const BUILT = new Map();
const ORDER = [];
function build(opt, len) {
  if (BUILT.has(opt.k)) { touch(opt.k); return BUILT.get(opt.k); }
  const R = mulberry(opt.k.charCodeAt(0) * 7919 + opt.k.charCodeAt(1) * 131 + len);
  const r = (a, b) => a + R() * (b - a);
  const L = {
    far: mkCanvas(Math.ceil(W + len * 0.25) + 20, H),
    mid: mkCanvas(Math.ceil(W + len * 0.55) + 20, H),
    near: mkCanvas(len + W, H),
  };
  opt.f(L, R, r, len);
  BUILT.set(opt.k, L); ORDER.push(opt.k);
  while (ORDER.length > 6) { const dead = ORDER.shift(); if (dead !== opt.k) BUILT.delete(dead); }
  return L;
}
function touch(k) { const i = ORDER.indexOf(k); if (i >= 0) { ORDER.splice(i, 1); ORDER.push(k); } }

// ---- live overlays -------------------------------------------------------
function drawTiles(g, t, cam) {
  const step = Math.floor(t / 20), tw2 = 30, th = 12;
  for (let row = 0; row < 8; row++) {
    const y = 150 + row * th, off = (row % 2) * (tw2 / 2);
    for (let col = -1; col < W / tw2 + 2; col++) {
      const wx = col * tw2 + off - (cam % tw2);
      const gx = Math.floor((col * tw2 + off + cam) / tw2);
      const on = (gx + row + step) % 3 === 0;
      const cols = ['#ff2a8a', '#2ad8ff', '#ffe02a', '#8a2aff', '#2aff8a', '#ff7a2a'];
      g.fillStyle = on ? cols[(gx * 7 + row * 3 + step) % 6] : '#1a1024';
      g.globalAlpha = on ? 0.34 : 0.9;
      g.fillRect(Math.round(wx) + 1, y + 1, tw2 - 2, th - 2);
    }
  }
  g.globalAlpha = 1;
}
function drawStrobe(g, t) {
  const beat = t % 42;
  if (beat < 3) { g.fillStyle = 'rgba(240,248,255,0.30)'; g.fillRect(0, 0, W, H); }
  else if (beat < 6) { g.fillStyle = 'rgba(240,248,255,0.12)'; g.fillRect(0, 0, W, H); }
  for (let k = 0; k < 4; k++) {
    const a = t * 0.02 + k * 1.6;
    const x = W / 2 + Math.sin(a) * (W / 2 + 40);
    g.fillStyle = k % 2 ? 'rgba(58,255,138,0.06)' : 'rgba(232,244,255,0.05)';
    g.beginPath(); g.moveTo(x, 46); g.lineTo(x - 40, 240); g.lineTo(x + 26, 240); g.lineTo(x + 8, 46); g.fill();
  }
}
function drawHaze(g, t, cam) {
  for (let i = 0; i < 7; i++) {
    const seed = i * 211;
    const x = ((seed * 37 + t * (0.25 + (i % 3) * 0.12)) % (W + 200)) - 100;
    const y = 120 + ((seed % 70));
    g.fillStyle = `rgba(200,210,235,${0.030 + (i % 3) * 0.012})`;
    g.beginPath(); g.ellipse(x, y + Math.sin(t / 60 + i) * 7, 60 + (i % 4) * 22, 16 + (i % 3) * 7, 0, 0, 7); g.fill();
  }
}
function drawCaustic(g, t, cam) {
  g.save(); g.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 16; i++) {
    const seed = i * 149;
    const x = ((seed * 23 - cam * 0.6) % (W + 80) + W + 80) % (W + 80) - 40;
    const y = 152 + (seed % 78);
    const w2 = 12 + Math.abs(Math.sin(t / 34 + i)) * 16;
    g.fillStyle = 'rgba(90,190,235,0.055)';
    g.beginPath(); g.ellipse(x, y, w2, 3 + Math.abs(Math.cos(t / 28 + i)) * 3, i * 0.4, 0, 7); g.fill();
  }
  g.restore();
}

function drawDust(g, t, cam) {
  for (let i = 0; i < 22; i++) {
    const seed = i * 167;
    const x = ((seed * 41 + t * (0.5 + (i % 4) * 0.28)) % (W + 160)) - 80;
    const y = 120 + ((seed % 110)) + Math.sin(t / 40 + i) * 5;
    g.fillStyle = `rgba(222,198,158,${0.05 + (i % 3) * 0.022})`;
    g.beginPath(); g.ellipse(x, y, 26 + (i % 5) * 16, 8 + (i % 3) * 5, 0, 0, 7); g.fill();
  }
  g.fillStyle = 'rgba(222,198,158,0.05)'; g.fillRect(0, 100, W, 140);
}
function drawWind(g, t, cam) {
  for (let i = 0; i < 14; i++) {
    const seed = i * 131;
    const x = ((seed * 53 + t * (2.4 + (i % 4))) % (W + 200)) - 100;
    const y = 46 + ((seed % 170));
    g.fillStyle = i % 3 ? 'rgba(255,255,255,0.10)' : 'rgba(255,220,190,0.13)';
    g.fillRect(x, y, 16 + (i % 5) * 9, 1);
  }
}
function drawVertigo(g, t, cam) {
  // a slow sway, as if the jib is moving under you
  g.fillStyle = 'rgba(255,190,140,0.04)';
  g.fillRect(0, 150 + Math.sin(t / 90) * 3, W, 90);
}

const VIEWS = [];
let playing = true, speed = 1, cam = 0, frames = 0, maxLen = 1500;
function makeView(card, opt, len) {
  const cv = card.querySelector('canvas');
  cv.width = W * PX; cv.height = H * PX;
  const g = cv.getContext('2d');
  g.imageSmoothingEnabled = false;
  const v = { cv, g, opt, len, live: false };
  VIEWS.push(v);
  const io = new IntersectionObserver(es => { es.forEach(e => { v.live = e.isIntersecting; }); }, { rootMargin: '200px' });
  io.observe(cv);
  return v;
}
function paint(v) {
  const { g, opt, len } = v;
  const L = build(opt, len);
  g.setTransform(PX, 0, 0, PX, 0, 0);
  const c = Math.min(cam, len - W);
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  g.drawImage(L.far, -Math.round(c * 0.25), 0, L.far.width, L.far.height);
  g.drawImage(L.mid, -Math.round(c * 0.55), 0, L.mid.width, L.mid.height);
  g.drawImage(L.near, -Math.round(c), 0, L.near.width, L.near.height);
  if (L.tiles) drawTiles(g, frames, c);
  if (L.caustic) drawCaustic(g, frames, c);
  if (L.dust) drawDust(g, frames, c);
  if (L.wind) drawWind(g, frames, c);
  if (L.vertigo) drawVertigo(g, frames, c);
  if (L.strobe) drawStrobe(g, frames);
  if (L.haze) drawHaze(g, frames, c);
  if (BAND.checked) {
    g.fillStyle = 'rgba(74,192,232,0.10)'; g.fillRect(0, 150, W, 80);
    g.fillStyle = 'rgba(74,192,232,0.5)'; g.fillRect(0, 150, W, 1); g.fillRect(0, 229, W, 1);
    ptext(g, 'WALKABLE BAND', 6, 152, 'rgba(180,230,255,0.75)');
  }
  ptext(g, opt.k, 5, 5, 'rgba(255,255,255,0.28)', 2);
}
function frame() {
  if (playing) { cam += 0.9 * speed; frames += speed; if (cam > maxLen - W) cam = 0; SCRUB.value = String(Math.round(cam)); }
  for (const v of VIEWS) if (v.live) paint(v);
  requestAnimationFrame(frame);
}
