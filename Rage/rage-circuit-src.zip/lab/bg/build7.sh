#!/bin/sh
# Assemble the stage 7 concept picker. Stage 7 uses none of the city toolkit,
# so only the core font/canvas helpers and the lab toolkit go in.
cd "$(dirname "$0")"
{ cat head3.html; cat body7.html; echo '<script>';
  cat 00_core.js 15_s7.js 16_s7a.js 17_s7b.js 18_s7c.js 97_viewer7.js 91_ui.js;
  echo '</script>'; } > picker7.html
# stage 7 gets its own pick key, so stage 6's choices do not show as pre-picked
sed -i "s/rc_bg_picks_v1/rc_bg_picks_s7/" picker7.html
wc -c picker7.html
