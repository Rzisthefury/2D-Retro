// ============================================================ city toolkit
// Reusable pieces so a block is assembled from genuinely different buildings
// rather than one template recoloured. Every helper takes a context and paints
// in logical units.

// ---- surfaces ------------------------------------------------------------
function brick(g, x, y, w, h, col, R, opts = {}) {
  g.fillStyle = col; g.fillRect(x, y, w, h);
  const ch = opts.course || 5, bw = opts.bw || 12;
  g.fillStyle = 'rgba(0,0,0,0.18)';
  for (let by = y + 2; by < y + h; by += ch) {
    g.fillRect(x, by, w, 1);
    for (let bx = x + ((Math.round((by - y) / ch)) % 2) * (bw / 2); bx < x + w; bx += bw) g.fillRect(bx, by, 1, ch);
  }
  // weathering: a few darker and lighter patches so no two walls read the same
  for (let k = 0; k < (opts.grime === false ? 0 : 14); k++) {
    g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,0.10)' : 'rgba(255,255,255,0.045)';
    g.fillRect(x + R() * w, y + R() * h, 6 + R() * 26, 3 + R() * 12);
  }
  g.fillStyle = 'rgba(0,0,0,0.32)'; g.fillRect(x + w - 3, y, 3, h);
}
function stucco(g, x, y, w, h, col, R) {
  g.fillStyle = col; g.fillRect(x, y, w, h);
  for (let k = 0; k < 40; k++) { g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,0.07)' : 'rgba(255,255,255,0.05)';
    g.fillRect(x + R() * w, y + R() * h, 2 + R() * 5, 1 + R() * 3); }
  // cracks
  g.strokeStyle = 'rgba(0,0,0,0.22)'; g.lineWidth = 1;
  for (let k = 0; k < 3; k++) { let cx = x + R() * w, cy = y + R() * h * 0.7;
    g.beginPath(); g.moveTo(cx, cy);
    for (let i = 0; i < 4; i++) { cx += (R() - 0.5) * 6; cy += 4 + R() * 6; g.lineTo(cx, cy); } g.stroke(); }
  g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x + w - 3, y, 3, h);
}
function concrete(g, x, y, w, h, col, R) {
  g.fillStyle = col; g.fillRect(x, y, w, h);
  // cast panels: each one shuttered slightly differently, with a visible seam
  const pw = 32 + R() * 10, ph = 24 + R() * 8;
  for (let py = y; py < y + h; py += ph) for (let pxx = x; pxx < x + w; pxx += pw) {
    g.fillStyle = R() < 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.06)';
    g.fillRect(pxx, py, pw - 1, ph - 1);
    g.fillStyle = 'rgba(0,0,0,0.26)'; g.fillRect(pxx, py, pw, 1.5); g.fillRect(pxx, py, 1.5, ph);
    g.fillStyle = 'rgba(255,255,255,0.05)'; g.fillRect(pxx + 1.5, py + 1.5, pw - 3, 1);
    for (let k = 0; k < 2; k++) { g.fillStyle = 'rgba(0,0,0,0.22)';                    // tie holes
      g.fillRect(pxx + 5 + k * (pw - 14), py + ph * 0.45, 2, 2); }
  }
  // rain staining running down from every seam, the thing that ages concrete
  for (let k = 0; k < w / 14; k++) {
    const sx = x + R() * w, sy = y + R() * h * 0.7;
    g.fillStyle = 'rgba(0,0,0,0.13)'; g.fillRect(sx, sy, 2 + R() * 3, 14 + R() * 34);
    g.fillStyle = 'rgba(0,0,0,0.07)'; g.fillRect(sx - 2, sy, 8, 8 + R() * 16);
  }
  for (let k = 0; k < 10; k++) { g.fillStyle = R() < 0.5 ? 'rgba(90,110,70,0.10)' : 'rgba(0,0,0,0.09)';
    g.fillRect(x + R() * w, y + R() * h, 5 + R() * 20, 3 + R() * 9); }
  // conduit and a junction box or two bolted across it
  if (R() < 0.7) { const cy2 = y + h * (0.2 + R() * 0.5);
    g.fillStyle = '#2f3540'; g.fillRect(x, cy2, w, 3);
    g.fillStyle = '#434b58'; g.fillRect(x, cy2, w, 1);
    for (let k = 0; k < w; k += 30) { g.fillStyle = '#242a33'; g.fillRect(x + k, cy2 - 1, 4, 5); }
    if (R() < 0.6) { const bx = x + R() * (w - 20);
      g.fillStyle = '#23282f'; g.fillRect(bx, cy2 - 7, 16, 14);
      g.fillStyle = '#3a4150'; g.fillRect(bx + 1, cy2 - 6, 14, 5); } }
  g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x + w - 3, y, 3, h);
}
// a painted-over advert still showing through - instant age and individuality
function ghostSign(g, x, y, w, h, word, R) {
  g.save(); g.globalAlpha = 0.16;
  g.fillStyle = '#e8e0d0'; g.fillRect(x, y, w, h);
  g.globalAlpha = 0.30;
  ptext(g, word, x + w / 2 - tw(word, 2) / 2, y + h / 2 - 7, '#f4ecd8', 2);
  g.restore();
}

// ---- windows -------------------------------------------------------------
// One window with a life of its own: lit or dark, blinds, curtains, an AC unit,
// a plant, sometimes somebody standing in it.
function windowUnit(g, x, y, w, h, R, opts = {}) {
  const lit = opts.lit === undefined ? R() < (opts.litRate || 0.38) : opts.lit;
  g.fillStyle = '#100c1a'; g.fillRect(x - 1, y - 1, w + 2, h + 2);
  const glow = opts.glow || (R() < 0.7 ? '#e8c060' : R() < 0.5 ? '#8ad0e8' : '#e8f0ff');
  g.fillStyle = lit ? glow : (opts.dark || '#241f38');
  g.fillRect(x, y, w, h);
  if (lit) {
    // the room behind: a back wall a shade darker, then furniture silhouettes
    g.fillStyle = 'rgba(0,0,0,0.18)'; g.fillRect(x, y + h * 0.55, w, h * 0.45);
    const roll = R();
    if (roll < 0.26) {                                   // somebody at the window
      const px_ = x + w * (0.3 + R() * 0.4), py = y + h;
      g.fillStyle = 'rgba(0,0,0,0.62)';
      g.fillRect(px_ - 2.5, py - h * 0.62, 5, h * 0.62);
      g.beginPath(); g.arc(px_, py - h * 0.66, 2.6, 0, 7); g.fill();
    } else if (roll < 0.42) {                            // a TV flickering
      g.fillStyle = 'rgba(160,220,255,0.55)'; g.fillRect(x + 1, y + h * 0.45, w - 2, h * 0.3);
    } else if (roll < 0.54) {                            // a plant on the sill
      g.fillStyle = '#2a6a3a'; g.fillRect(x + 1, y + h - 5, 4, 4);
      g.fillRect(x + 1.5, y + h - 8, 3, 3);
    }
  }
  if (R() < (opts.blindRate === undefined ? 0.3 : opts.blindRate)) {           // half-drawn blind
    const bh = h * (0.2 + R() * 0.45);
    g.fillStyle = 'rgba(20,16,28,0.78)'; g.fillRect(x, y, w, bh);
    for (let by = y + 1; by < y + bh; by += 2) { g.fillStyle = 'rgba(255,255,255,0.05)'; g.fillRect(x, by, w, 1); }
  }
  // frame
  g.fillStyle = '#120e1c';
  if (w >= 9) g.fillRect(x + w / 2 - 0.5, y, 1, h);
  g.fillRect(x, y + h * 0.42, w, 1);
  g.fillStyle = opts.sill || '#7a7080'; g.fillRect(x - 2, y + h, w + 4, 2);
  if (R() < (opts.acRate === undefined ? 0.12 : opts.acRate)) {                // window AC unit
    g.fillStyle = '#2a2a32'; g.fillRect(x + 1, y + h - 1, w - 2, 5);
    g.fillStyle = '#4a4a56'; g.fillRect(x + 2, y + h, w - 4, 2);
  }
}
function windowGrid(g, x, y, w, h, cols, rows, R, opts = {}) {
  const gapx = w / cols, gapy = h / rows;
  const ww = Math.max(6, gapx * (opts.fill || 0.58)), wh = Math.max(8, gapy * (opts.fillY || 0.62));
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++)
    windowUnit(g, x + c * gapx + (gapx - ww) / 2, y + r * gapy + (gapy - wh) / 2, ww, wh, R, opts);
}

// ---- architecture --------------------------------------------------------
function cornice(g, x, y, w, col, dep = 5) {
  g.fillStyle = col; g.fillRect(x - 3, y, w + 6, dep);
  g.fillStyle = 'rgba(255,255,255,0.14)'; g.fillRect(x - 3, y, w + 6, 1);
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x - 3, y + dep, w + 6, 2);
  for (let bx = x; bx < x + w; bx += 9) { g.fillStyle = 'rgba(0,0,0,0.22)'; g.fillRect(bx, y + 1, 2, dep - 2); }
}
function fireEscape(g, x, y, w, floors, R, col = '#16121c') {
  g.fillStyle = col;
  for (let f = 0; f < floors; f++) {
    const fy = y + f * 26;
    g.fillRect(x, fy, w, 2);                       // platform
    g.fillRect(x, fy - 9, 1, 9); g.fillRect(x + w - 1, fy - 9, 1, 9);
    for (let k = 0; k < w; k += 4) g.fillRect(x + k, fy - 9, 1, 9);
    g.fillRect(x, fy - 10, w, 1);
    // the ladder down to the next platform, offset so it zig-zags
    const lx = x + (f % 2 ? w - 12 : 3);
    g.fillRect(lx, fy + 2, 1, 24); g.fillRect(lx + 9, fy + 2, 1, 24);
    for (let k = 4; k < 24; k += 5) g.fillRect(lx, fy + 2 + k, 10, 1);
    if (R() < 0.35) {                              // clutter on the platform
      g.fillStyle = pick2(R, ['#8a3a4a', '#3a6a8a', '#7a6a3a']);
      g.fillRect(x + 4 + R() * (w - 14), fy - 7, 5, 6);
      g.fillStyle = col;
    }
    if (R() < 0.25) {                              // washing line
      g.strokeStyle = 'rgba(200,200,210,0.5)'; g.lineWidth = 1;
      g.beginPath(); g.moveTo(x + w, fy - 6); g.quadraticCurveTo(x + w + 16, fy - 1, x + w + 32, fy - 7); g.stroke();
      for (let k = 0; k < 3; k++) { g.fillStyle = pick2(R, ['#d8d0c0', '#8ab8d8', '#d88a9a', '#e8d070']);
        g.fillRect(x + w + 6 + k * 9, fy - 4 + k, 5, 7); }
      g.fillStyle = col;
    }
  }
}
function stoop(g, x, y, w, R, col = '#6a5a4a') {
  const steps = 5;
  for (let s = 0; s < steps; s++) {
    g.fillStyle = s % 2 ? col : '#7a6a58';
    g.fillRect(x + s, y - s * 3, w - s * 2, 3);
  }
  g.fillStyle = '#16121c';                         // railings
  g.fillRect(x, y - 16, 1.5, 17); g.fillRect(x + w - 1.5, y - 16, 1.5, 17);
  g.fillRect(x, y - 17, w, 1.5);
  for (let k = 3; k < w - 2; k += 4) g.fillRect(x + k, y - 16, 1, 16);
  if (R() < 0.4) { g.fillStyle = '#2a6a3a'; g.fillRect(x + w + 2, y - 6, 6, 6); g.fillRect(x + w + 3, y - 10, 4, 5); }
}
function doorway(g, x, y, w, h, R, opts = {}) {
  g.fillStyle = '#100c16'; g.fillRect(x - 2, y - 2, w + 4, h + 2);
  g.fillStyle = opts.col || pick2(R, ['#3a2418', '#2a3a3a', '#4a2030', '#1e2a44']);
  g.fillRect(x, y, w, h);
  g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(x, y, w, 1);
  if (opts.glass !== false && R() < 0.6) { g.fillStyle = 'rgba(200,230,255,0.16)'; g.fillRect(x + 2, y + 3, w - 4, h * 0.34); }
  g.fillStyle = '#f2c94c'; g.fillRect(x + w - 4, y + h * 0.55, 2, 2);   // handle
  if (opts.light !== false) {                                           // door lamp + its pool
    g.fillStyle = '#f2e8a0'; g.fillRect(x + w / 2 - 3, y - 7, 6, 3);
    g.fillStyle = 'rgba(242,232,160,0.10)';
    g.beginPath(); g.moveTo(x + w / 2 - 3, y - 4); g.lineTo(x - 10, y + h + 6);
    g.lineTo(x + w + 10, y + h + 6); g.lineTo(x + w / 2 + 3, y - 4); g.fill();
  }
}
function awning(g, x, y, w, R, cols) {
  const c = cols || [pick2(R, ['#b82a3a', '#2a7a5a', '#2a4a9a', '#c87a20', '#6a2a6a']), '#e8e0d0'];
  for (let k = 0; k < w; k += 8) { g.fillStyle = (k / 8) % 2 ? c[0] : c[1]; g.fillRect(x + k, y, 8, 10); }
  g.fillStyle = 'rgba(0,0,0,0.32)'; g.fillRect(x, y + 9, w, 2);
  // scalloped edge
  for (let k = 0; k < w; k += 8) { g.fillStyle = (k / 8) % 2 ? c[0] : c[1];
    g.beginPath(); g.arc(x + k + 4, y + 11, 4, 0, Math.PI); g.fill(); }
  g.fillStyle = '#3a3440'; g.fillRect(x, y - 1, w, 1);
}
function shopWindow(g, x, y, w, h, R, opts = {}) {
  g.fillStyle = '#16121c'; g.fillRect(x - 2, y - 2, w + 4, h + 4);
  const lit = opts.lit === undefined ? R() < 0.72 : opts.lit;
  g.fillStyle = lit ? (opts.inner || '#2a3a5a') : '#141020';
  g.fillRect(x, y, w, h);
  if (lit) {
    g.fillStyle = 'rgba(255,240,200,0.12)'; g.fillRect(x, y, w, h * 0.3);
    // goods on shelves
    for (let sy = y + h * 0.35; sy < y + h - 4; sy += 9) {
      g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x + 2, sy + 7, w - 4, 1);
      for (let sx = x + 3; sx < x + w - 4; sx += 5)
        if (R() < 0.75) { g.fillStyle = pick2(R, ['#c8503a', '#3a8a5a', '#d8b040', '#6a8ac8', '#c8c0a8']);
          g.fillRect(sx, sy + 2 + R() * 2, 3, 5); }
    }
  }
  // the glass itself
  g.fillStyle = 'rgba(180,220,255,0.15)'; g.fillRect(x + 2, y + 1, 5, h - 2);
  g.fillStyle = 'rgba(180,220,255,0.09)'; g.fillRect(x + 10, y + 1, 2, h - 2);
  g.fillStyle = '#4a4458'; g.fillRect(x + w / 2 - 0.5, y, 1, h);
}

// ---- street clutter ------------------------------------------------------
function trashBags(g, x, y, R, n = 3) {
  for (let k = 0; k < n; k++) {
    const bx = x + k * 7 + R() * 2, r = 4 + R() * 2;
    g.fillStyle = '#16141c'; g.beginPath(); g.ellipse(bx, y - r * 0.6, r, r * 0.85, 0, 0, 7); g.fill();
    g.fillStyle = R() < 0.5 ? '#2a2830' : '#1e2a24';
    g.beginPath(); g.ellipse(bx, y - r * 0.7, r - 1, r * 0.8, 0, 0, 7); g.fill();
    g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(bx - 2, y - r * 1.3, 3, 2);
  }
}
function newsBox(g, x, y, R, col) {
  const c = col || pick2(R, ['#c82a3a', '#2a6ac8', '#3a8a4a', '#d8a020']);
  g.fillStyle = '#120e16'; g.fillRect(x - 1, y - 21, 13, 21);
  g.fillStyle = c; g.fillRect(x, y - 20, 11, 18);
  g.fillStyle = 'rgba(0,0,0,0.45)'; g.fillRect(x + 1, y - 18, 9, 7);
  g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillRect(x + 2, y - 17, 7, 5);
  g.fillStyle = '#16141c'; g.fillRect(x + 2, y - 2, 2, 2); g.fillRect(x + 7, y - 2, 2, 2);
}
function hydrant(g, x, y) {
  g.fillStyle = '#120a14'; g.fillRect(x - 4, y - 14, 8, 14);
  g.fillStyle = '#c8283a'; g.fillRect(x - 3, y - 13, 6, 13);
  g.fillStyle = '#120a14'; g.fillRect(x - 6, y - 9, 12, 4);
  g.fillStyle = '#e84050'; g.fillRect(x - 5, y - 8, 10, 2);
  g.fillStyle = '#e84050'; g.fillRect(x - 2, y - 17, 4, 4);
  g.fillStyle = 'rgba(255,255,255,0.22)'; g.fillRect(x - 2, y - 12, 1, 11);
}
function streetLamp(g, x, y, R, h = 100, warm = '#f2e8a0') {
  g.fillStyle = '#16121c';
  g.fillRect(x, y - h, 4, h); g.fillRect(x - 3, y - 2, 10, 3);
  g.beginPath(); g.moveTo(x, y - h); g.quadraticCurveTo(x - 4, y - h - 8, x - 14, y - h - 6);
  g.lineWidth = 3; g.strokeStyle = '#16121c'; g.stroke();
  g.fillStyle = warm; g.fillRect(x - 17, y - h - 6, 8, 3);
  g.fillStyle = 'rgba(242,232,160,0.09)';
  g.beginPath(); g.moveTo(x - 17, y - h - 3); g.lineTo(x - 34, y + 2); g.lineTo(x + 8, y + 2); g.lineTo(x - 9, y - h - 3); g.fill();
  if (R() < 0.4) { g.fillStyle = '#c8302a'; g.fillRect(x + 4, y - h * 0.55, 10, 7);   // a flyer taped on
    ptext(g, '!', x + 8, y - h * 0.55 + 1, '#fff'); }
}
function busShelter(g, x, y, R) {
  g.fillStyle = '#16141c'; g.fillRect(x, y - 38, 54, 3);
  g.fillRect(x, y - 38, 2, 38); g.fillRect(x + 52, y - 38, 2, 38);
  g.fillStyle = 'rgba(170,210,255,0.14)'; g.fillRect(x + 2, y - 35, 50, 33);
  g.fillStyle = 'rgba(255,255,255,0.08)'; g.fillRect(x + 6, y - 34, 4, 31);
  // lit advert panel
  g.fillStyle = '#16141c'; g.fillRect(x + 36, y - 34, 17, 30);
  g.fillStyle = pick2(R, ['#e8b8c0', '#b8d8e8', '#e8d8a0']); g.fillRect(x + 37, y - 33, 15, 28);
  g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x + 39, y - 26, 11, 14);
  g.fillStyle = '#16141c'; g.fillRect(x + 4, y - 12, 28, 3);   // bench
  g.fillRect(x + 6, y - 9, 2, 9); g.fillRect(x + 28, y - 9, 2, 9);
}
function parkedCar(g, x, y, R, col) {
  const c = col || pick2(R, ['#7a2a30', '#2a4a6a', '#3a3a42', '#6a6a58', '#2a5a4a', '#8a7a30']);
  const O = '#120a14';
  g.fillStyle = O; g.fillRect(x - 30, y - 20, 60, 16);
  g.fillStyle = c; g.fillRect(x - 29, y - 19, 58, 14);
  g.fillStyle = O; g.fillRect(x - 17, y - 28, 32, 9);
  g.fillStyle = c; g.fillRect(x - 16, y - 27, 30, 8);
  g.fillStyle = '#1e2a3a'; g.fillRect(x - 14, y - 26, 12, 6); g.fillRect(x + 1, y - 26, 12, 6);
  g.fillStyle = 'rgba(255,255,255,0.14)'; g.fillRect(x - 29, y - 19, 58, 1);
  g.fillStyle = O; g.fillRect(x - 30, y - 8, 60, 3);
  for (const wx of [-19, 18]) { g.fillStyle = O; g.beginPath(); g.arc(x + wx, y - 4, 6, 0, 7); g.fill();
    g.fillStyle = '#4a4a52'; g.beginPath(); g.arc(x + wx, y - 4, 2.6, 0, 7); g.fill(); }
  g.fillStyle = '#e8e0b0'; g.fillRect(x - 31, y - 15, 3, 4);
  g.fillStyle = '#c83030'; g.fillRect(x + 28, y - 15, 3, 4);
}
function steamGrate(g, x, y, frames, R) {
  g.fillStyle = '#1a1820'; g.fillRect(x - 12, y - 2, 24, 5);
  for (let k = -11; k < 11; k += 3) { g.fillStyle = '#3a3844'; g.fillRect(x + k, y - 1, 2, 3); }
}
function trafficLight(g, x, y, R, phase = 0) {
  g.fillStyle = '#16141c';
  g.fillRect(x, y - 86, 4, 86); g.fillRect(x - 3, y - 2, 10, 3);
  g.fillRect(x + 2, y - 86, 34, 3);
  g.fillRect(x + 30, y - 86, 9, 24);
  const on = ['#e02a3a', '#e8c040', '#3ae05a'][phase % 3];
  for (let k = 0; k < 3; k++) { g.fillStyle = k === phase % 3 ? on : '#201c24';
    g.beginPath(); g.arc(x + 34.5, y - 80 + k * 7, 2.6, 0, 7); g.fill(); }
  g.fillStyle = 'rgba(224,42,58,0.10)';
  g.beginPath(); g.arc(x + 34.5, y - 80 + (phase % 3) * 7, 7, 0, 7); g.fill();
}
function crates(g, x, y, R, n = 3) {
  for (let k = 0; k < n; k++) {
    const w = 11 + R() * 5, h = 8 + R() * 4, cx = x + k * 12, cy = y - (k % 2) * h;
    g.fillStyle = '#16121c'; g.fillRect(cx - 1, cy - h - 1, w + 2, h + 2);
    g.fillStyle = pick2(R, ['#7a5a34', '#6a4a2a', '#8a6a40']); g.fillRect(cx, cy - h, w, h);
    g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(cx, cy - h * 0.55, w, 1.5);
    g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(cx, cy - h, w, 1);
  }
}
function dumpster(g, x, y, R) {
  g.fillStyle = '#120e14'; g.fillRect(x, y - 30, 52, 30);
  g.fillStyle = pick2(R, ['#2a5a3a', '#2a4a6a', '#6a3a2a']); g.fillRect(x + 1, y - 28, 50, 27);
  g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x + 1, y - 28, 50, 5);
  g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(x + 1, y - 28, 50, 1);
  g.fillStyle = '#e8e0d0'; g.fillRect(x + 20, y - 18, 12, 5);
  g.fillStyle = '#120e14'; g.beginPath(); g.arc(x + 8, y - 1, 3, 0, 7); g.arc(x + 44, y - 1, 3, 0, 7); g.fill();
  if (R() < 0.6) trashBags(g, x + 54, y, R, 2);
}
function pigeon(g, x, y, R, col = '#4a4a56') {
  g.fillStyle = col; g.beginPath(); g.ellipse(x, y - 2, 3, 2, 0, 0, 7); g.fill();
  g.beginPath(); g.arc(x + 2.4, y - 4, 1.4, 0, 7); g.fill();
  g.fillStyle = '#c8a040'; g.fillRect(x + 3.6, y - 4, 1.5, 1);
  g.fillStyle = 'rgba(255,255,255,0.22)'; g.fillRect(x - 1, y - 3, 2, 1);
}
function puddles(g, R, w, y0, y1, n = 10, col = 'rgba(120,140,200,0.25)') {
  for (let k = 0; k < n; k++) { g.fillStyle = col;
    g.beginPath(); g.ellipse(R() * w, y0 + R() * (y1 - y0), 10 + R() * 16, 2 + R() * 3, 0, 0, 7); g.fill(); }
}
function graffiti(g, x, y, R, w = 40) {
  g.strokeStyle = pick2(R, ['#e84a8a', '#4ae88a', '#e8e84a', '#8ab8ff', '#ff8a2a']);
  g.lineWidth = 2 + R() * 1.5;
  g.beginPath(); let gx = x, gy = y; g.moveTo(gx, gy);
  for (let k = 0; k < 7; k++) { gx += w / 7; g.lineTo(gx, gy + (R() - 0.5) * 14); }
  g.stroke();
}
