// ============================================================ the picker (stage 2)
const SECTIONS = [
  { id: 'A', stage: '6-A', now: 'THE FOUNDRY', len: 1560, options: [
    { k: 'A1', name: 'The Cast House', f: s6a_casthouse,
      pitch: 'What you have now, built out: the tapping floor of a blast furnace.',
      notes: ['A real tap hole with iron running out of it down a sand runner the whole length of the scene',
              'Ladle cars on rails behind the runner, gas offtakes and stoves in the mid layer',
              'Everything in orange, with the pouring bay as the arena'] },
    { k: 'A2', name: 'The Rolling Mill', f: s6a_mill,
      pitch: 'A red-hot slab running down a roller table through the stands.',
      notes: ['Roller table the full length with the slab glowing on it, lighting the underside of everything',
              'Mill stands straddling the table with work rolls, stand numbers and water sprays hissing onto the steel',
              'Scale flying off the slab; the coil box at the end is the arena'] },
    { k: 'A3', name: 'The Arc Furnace', f: s6a_arc,
      pitch: 'Blue-white arc light instead of orange. A charging crane, a scrap bucket, a fume hood.',
      notes: ['Three electrodes down through the furnace roof with the arc flaring between them',
              'The only cold-lit industrial option - it would make stage 6 read as three different places, not one',
              'Slag pot tapping on the near side, water-cooled panels behind'] },
    { k: 'A4', name: 'The Coke Ovens', f: s6a_coke,
      pitch: 'The wildcard. A battery of oven doors, a pusher machine, coal dust and quench steam.',
      notes: ['Door after door, each numbered, one in four leaking fire round the seal',
              'A pusher machine on rails halfway down, quench car at the end',
              'The dirtiest, most oppressive option - coal dust hangs in the air the whole way'] },
  ] },
  { id: 'B', stage: '6-B', now: 'ASSEMBLY LINE', len: 1320, options: [
    { k: 'B1', name: 'The Line', f: s6b_line,
      pitch: 'What you have now, built out: half-built units on a conveyor with arms working on them.',
      notes: ['The units on the belt are recognisably the robots you have been fighting, part-finished',
              'Ceiling arms reaching down at different angles, welding, with sparks coming off the work',
              'Andon lights, parts bins, and FINAL ASSEMBLY over the arena'] },
    { k: 'B2', name: 'The Body Shop', f: s6b_bodyshop,
      pitch: 'Shells hanging from an overhead monorail that passes right over the fight.',
      notes: ['The line runs above head height, so hulls swing past over your head the whole way',
              'Floor-standing welding robots either side throwing real arc light onto the scene',
              'Jigs on the floor to fight around; the busiest vertical composition of the four'] },
    { k: 'B3', name: 'The Packing Hall', f: s6b_packing,
      pitch: 'The finished product boxed. Palletisers, shrink-wrap, racking to the roof.',
      notes: ['Bright and orderly - light strips end to end, painted aisles, racking stacked four high behind',
              'Boxes coming down a conveyor into a palletiser, wrapped pallets stacked around the floor',
              'QC booths with pass lights at the end; by far the cleanest option'] },
    { k: 'B4', name: 'The Test Cells', f: s6b_cells,
      pitch: 'The wildcard. Armoured glass cells with finished units being run in.',
      notes: ['Every cell a different colour of light with a unit inside mid-test, one pane spidered with cracks',
              'Blast doors with hazard bands, beacons flashing over each one, an observation gantry overhead',
              'Ends at CELL 9 - DO NOT ENTER, lit red; the most ominous lead-in to a boss in the game'] },
  ] },
  { id: 'C', stage: '6-C', now: 'THE CRUCIBLE', len: 1180, options: [
    { k: 'C1', name: 'The Ladle Pit', f: s6c_ladlepit,
      pitch: 'A sunken pit in refractory brick with ladles pouring in from above.',
      notes: ['Firebrick walls on both sides, scorched black where the heat has licked up them',
              'Ladles tipping overhead with the stream falling past you into the pit',
              'Cooled splash frozen on the floor and fresh hot patches between it'] },
    { k: 'C2', name: 'The Torpedo Yard', f: s6c_torpedo,
      pitch: 'Giant cigar-shaped molten iron carriers on rails, glowing at the mouth.',
      notes: ['The cars are the set - 250 units long each, shaded as cylinders, charging mouths open and glowing',
              'Bogies, rails and ballast underfoot; the widest, lowest composition of the four',
              'Cooler overall than the other three, with the heat concentrated in points'] },
    { k: 'C3', name: 'The Quench Tank', f: s6c_quench,
      pitch: 'A steel tank of water with red-hot parts coming down into it. Steam everywhere.',
      notes: ['The only cold option: deep green-blue water with heat shimmering off the surface',
              'A crane lowers a glowing part into the tank overhead',
              'You fight on grated walkway round the tank, with a handrail along the front edge'] },
    { k: 'C4', name: 'The Slag Bank', f: s6c_slagbank,
      pitch: 'The wildcard. Outdoors, on a bank above a slag dump, under a sky lit orange by it.',
      notes: ['A pot tips a river of molten slag down the slope below you, lighting the whole scene',
              'The far slope is a glowing scar running the length of the mid layer',
              'The only outdoor option and the only one where Slag fights under open sky'] },
  ] },
];

const BUILT = new Map();
const ORDER = [];
function build(opt, len) {
  if (BUILT.has(opt.k)) { touch(opt.k); return BUILT.get(opt.k); }
  const R = mulberry(opt.k.charCodeAt(0) * 7919 + opt.k.charCodeAt(1) * 131 + len);
  const r = (a, b) => a + R() * (b - a);
  const L = {
    far: mkCanvas(Math.ceil(W + len * 0.25) + 20, H),
    mid: mkCanvas(Math.ceil(W + len * 0.55) + 20, H),
    near: mkCanvas(len + W, H),
  };
  opt.f(L, R, r, len);
  BUILT.set(opt.k, L); ORDER.push(opt.k);
  while (ORDER.length > 6) { const dead = ORDER.shift(); if (dead !== opt.k) BUILT.delete(dead); }
  return L;
}
function touch(k) { const i = ORDER.indexOf(k); if (i >= 0) { ORDER.splice(i, 1); ORDER.push(k); } }

// ---- live overlays -------------------------------------------------------
function drawTiles(g, t, cam) {
  const step = Math.floor(t / 20), tw2 = 30, th = 12;
  for (let row = 0; row < 8; row++) {
    const y = 150 + row * th, off = (row % 2) * (tw2 / 2);
    for (let col = -1; col < W / tw2 + 2; col++) {
      const wx = col * tw2 + off - (cam % tw2);
      const gx = Math.floor((col * tw2 + off + cam) / tw2);
      const on = (gx + row + step) % 3 === 0;
      const cols = ['#ff2a8a', '#2ad8ff', '#ffe02a', '#8a2aff', '#2aff8a', '#ff7a2a'];
      g.fillStyle = on ? cols[(gx * 7 + row * 3 + step) % 6] : '#1a1024';
      g.globalAlpha = on ? 0.34 : 0.9;
      g.fillRect(Math.round(wx) + 1, y + 1, tw2 - 2, th - 2);
    }
  }
  g.globalAlpha = 1;
}
function drawStrobe(g, t) {
  const beat = t % 42;
  if (beat < 3) { g.fillStyle = 'rgba(240,248,255,0.30)'; g.fillRect(0, 0, W, H); }
  else if (beat < 6) { g.fillStyle = 'rgba(240,248,255,0.12)'; g.fillRect(0, 0, W, H); }
  for (let k = 0; k < 4; k++) {
    const a = t * 0.02 + k * 1.6;
    const x = W / 2 + Math.sin(a) * (W / 2 + 40);
    g.fillStyle = k % 2 ? 'rgba(58,255,138,0.06)' : 'rgba(232,244,255,0.05)';
    g.beginPath(); g.moveTo(x, 46); g.lineTo(x - 40, 240); g.lineTo(x + 26, 240); g.lineTo(x + 8, 46); g.fill();
  }
}
function drawHaze(g, t, cam) {
  for (let i = 0; i < 7; i++) {
    const seed = i * 211;
    const x = ((seed * 37 + t * (0.25 + (i % 3) * 0.12)) % (W + 200)) - 100;
    const y = 120 + ((seed % 70));
    g.fillStyle = `rgba(200,210,235,${0.030 + (i % 3) * 0.012})`;
    g.beginPath(); g.ellipse(x, y + Math.sin(t / 60 + i) * 7, 60 + (i % 4) * 22, 16 + (i % 3) * 7, 0, 0, 7); g.fill();
  }
}
function drawCaustic(g, t, cam) {
  g.save(); g.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 16; i++) {
    const seed = i * 149;
    const x = ((seed * 23 - cam * 0.6) % (W + 80) + W + 80) % (W + 80) - 40;
    const y = 152 + (seed % 78);
    const w2 = 12 + Math.abs(Math.sin(t / 34 + i)) * 16;
    g.fillStyle = 'rgba(90,190,235,0.055)';
    g.beginPath(); g.ellipse(x, y, w2, 3 + Math.abs(Math.cos(t / 28 + i)) * 3, i * 0.4, 0, 7); g.fill();
  }
  g.restore();
}

function drawSpeedLines(g, sp, t) {
  for (let i = 0; i < 14; i++) {
    const seed = i * 97;
    const y = 152 + ((seed * 13) % 84);
    const x = W - (((t * (7 + (i % 4) * 3) * sp + seed * 31) % (W + 90)));
    g.fillStyle = i % 3 ? 'rgba(255,255,255,0.10)' : 'rgba(180,220,255,0.16)';
    g.fillRect(x, y, 22 + (i % 5) * 8, 1);
  }
  for (let i = 0; i < 6; i++) {
    const y = 120 + ((i * 53) % 26);
    const x = W - (((t * 16 * sp + i * 71) % (W + 140)));
    g.fillStyle = 'rgba(255,240,200,0.12)';
    g.fillRect(x, y, 50, 1);
  }
}
function drawHeat(g, t, cam) {
  // a slow orange breathing over the lower half, the way a hot shop pulses
  const k = 0.035 + Math.abs(Math.sin(t / 74)) * 0.030;
  g.fillStyle = `rgba(255,140,40,${k})`; g.fillRect(0, 140, W, 100);
}
function drawEmbers(g, t, cam) {
  for (let i = 0; i < 20; i++) {
    const seed = i * 137;
    const life = (t * 0.7 + seed) % 180;
    const x = ((seed * 29) % 1400) - (cam % 1400) + Math.sin(life / 18 + i) * 7;
    if (x < -20 || x > W + 20) continue;
    const a = Math.max(0, 0.75 * (1 - life / 180));
    g.fillStyle = `rgba(255,${Math.round(150 + (1 - life / 180) * 80)},60,${a})`;
    g.fillRect(x, 232 - life * 0.9, 2, 2);
  }
}
function drawArcFlicker(g, t) {
  if ((t % 11) < 2 || (t % 37) < 1) { g.fillStyle = 'rgba(200,232,255,0.10)'; g.fillRect(0, 0, W, 150); }
}
function drawCoalDust(g, t, cam) {
  for (let i = 0; i < 26; i++) {
    const seed = i * 173;
    const x = ((seed * 41 + t * (0.3 + (i % 4) * 0.2)) % (W + 160)) - 80;
    const y = 70 + ((seed % 150)) + Math.sin(t / 50 + i) * 6;
    g.fillStyle = `rgba(40,30,22,${0.05 + (i % 3) * 0.02})`;
    g.beginPath(); g.ellipse(x, y, 30 + (i % 5) * 18, 10 + (i % 3) * 6, 0, 0, 7); g.fill();
  }
  g.fillStyle = 'rgba(30,22,16,0.06)'; g.fillRect(0, 40, W, 200);
}
function drawBeacon(g, t, cam) {
  if ((t % 60) < 18) { g.fillStyle = 'rgba(232,40,58,0.055)'; g.fillRect(0, 0, W, 150); }
}
function drawSteamWall(g, t, cam) {
  for (let i = 0; i < 12; i++) {
    const seed = i * 211;
    const life = (t * 0.6 + seed) % 170;
    const x = ((seed * 37) % 1300) - (cam % 1300);
    if (x < -60 || x > W + 60) continue;
    const a = Math.max(0, 0.30 * (1 - life / 170));
    g.fillStyle = `rgba(226,232,240,${a})`;
    g.beginPath(); g.arc(x + Math.sin(life / 24) * 12, 150 - life * 0.62, 9 + life * 0.18, 0, 7); g.fill();
  }
}
function drawSpray(g, t, cam) {
  for (let i = 0; i < 26; i++) {
    const seed = i * 151;
    const life = (t * 1.5 + seed) % 120;
    const x = ((seed * 43 - cam * 0.4) % (W + 160) + W + 160) % (W + 160) - 80;
    const a = Math.max(0, 0.30 * (1 - life / 120));
    g.fillStyle = `rgba(235,245,255,${a})`;
    g.beginPath(); g.ellipse(x + life * 0.5, 126 - life * 0.30, 5 + life * 0.13, 3 + life * 0.07, 0, 0, 7); g.fill();
  }
  g.fillStyle = 'rgba(210,230,250,0.04)'; g.fillRect(0, 110, W, 130);
}
function drawTunnelHum(g, t, cam) {
  // the light ribbon pulsing very slightly, the way strip lighting does
  const k = 0.03 + Math.abs(Math.sin(t / 26)) * 0.022;
  g.fillStyle = `rgba(255,232,170,${k})`;
  g.fillRect(0, 44, W, 196);
}
function drawShedSteam(g, t, cam) {
  for (let i = 0; i < 8; i++) {
    const seed = i * 193;
    const life = (t * 0.42 + seed) % 200;
    const x = ((seed * 31) % 1600) - (cam % 1600);
    if (x < -50 || x > W + 50) continue;
    const a = Math.max(0, 0.22 * (1 - life / 200));
    g.fillStyle = `rgba(226,226,236,${a})`;
    g.beginPath(); g.arc(x + Math.sin(life / 26) * 10, 150 - life * 0.62, 7 + life * 0.13, 0, 7); g.fill();
  }
}
function drawDust(g, t, cam) {
  for (let i = 0; i < 22; i++) {
    const seed = i * 167;
    const x = ((seed * 41 + t * (0.5 + (i % 4) * 0.28)) % (W + 160)) - 80;
    const y = 120 + ((seed % 110)) + Math.sin(t / 40 + i) * 5;
    g.fillStyle = `rgba(222,198,158,${0.05 + (i % 3) * 0.022})`;
    g.beginPath(); g.ellipse(x, y, 26 + (i % 5) * 16, 8 + (i % 3) * 5, 0, 0, 7); g.fill();
  }
  g.fillStyle = 'rgba(222,198,158,0.05)'; g.fillRect(0, 100, W, 140);
}
function drawWind(g, t, cam) {
  for (let i = 0; i < 14; i++) {
    const seed = i * 131;
    const x = ((seed * 53 + t * (2.4 + (i % 4))) % (W + 200)) - 100;
    const y = 46 + ((seed % 170));
    g.fillStyle = i % 3 ? 'rgba(255,255,255,0.10)' : 'rgba(255,220,190,0.13)';
    g.fillRect(x, y, 16 + (i % 5) * 9, 1);
  }
}
function drawVertigo(g, t, cam) {
  // a slow sway, as if the jib is moving under you
  g.fillStyle = 'rgba(255,190,140,0.04)';
  g.fillRect(0, 150 + Math.sin(t / 90) * 3, W, 90);
}

const VIEWS = [];
let playing = true, speed = 1, cam = 0, frames = 0, maxLen = 1560;
function makeView(card, opt, len) {
  const cv = card.querySelector('canvas');
  cv.width = W * PX; cv.height = H * PX;
  const g = cv.getContext('2d');
  g.imageSmoothingEnabled = false;
  const v = { cv, g, opt, len, live: false };
  VIEWS.push(v);
  const io = new IntersectionObserver(es => { es.forEach(e => { v.live = e.isIntersecting; }); }, { rootMargin: '200px' });
  io.observe(cv);
  return v;
}
function paint(v) {
  const { g, opt, len } = v;
  const L = build(opt, len);
  g.setTransform(PX, 0, 0, PX, 0, 0);
  const c = Math.min(cam, len - W);
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  if (L.speed) {
    // vehicle scene: the world keeps rushing past even when you stand still,
    // exactly as the game does it - far and mid wrap, near rides with the camera
    const wrap = (v2, w2) => -(((v2 % w2) + w2) % w2);
    const ff = wrap(Math.round(c * 0.25) + Math.round(frames * L.speed * 1.4), L.far.width);
    const mm = wrap(Math.round(c * 0.55) + Math.round(frames * L.speed * 3.4), L.mid.width);
    g.drawImage(L.far, ff, 0, L.far.width, L.far.height);
    g.drawImage(L.far, ff + L.far.width, 0, L.far.width, L.far.height);
    g.drawImage(L.mid, mm, 0, L.mid.width, L.mid.height);
    g.drawImage(L.mid, mm + L.mid.width, 0, L.mid.width, L.mid.height);
  } else {
    g.drawImage(L.far, -Math.round(c * 0.25), 0, L.far.width, L.far.height);
    g.drawImage(L.mid, -Math.round(c * 0.55), 0, L.mid.width, L.mid.height);
  }
  g.drawImage(L.near, -Math.round(c), 0, L.near.width, L.near.height);
  if (L.tiles) drawTiles(g, frames, c);
  if (L.speed) drawSpeedLines(g, L.speed, frames);
  if (L.steamShed) drawShedSteam(g, frames, c);
  if (L.spray) drawSpray(g, frames, c);
  if (L.heat) drawHeat(g, frames, c);
  if (L.embers) drawEmbers(g, frames, c);
  if (L.arc) drawArcFlicker(g, frames);
  if (L.coalDust) drawCoalDust(g, frames, c);
  if (L.beacon) drawBeacon(g, frames, c);
  if (L.steamWall) drawSteamWall(g, frames, c);
  if (L.tunnelHum) drawTunnelHum(g, frames, c);
  if (L.caustic) drawCaustic(g, frames, c);
  if (L.dust) drawDust(g, frames, c);
  if (L.wind) drawWind(g, frames, c);
  if (L.vertigo) drawVertigo(g, frames, c);
  if (L.strobe) drawStrobe(g, frames);
  if (L.haze) drawHaze(g, frames, c);
  if (BAND.checked) {
    g.fillStyle = 'rgba(74,192,232,0.10)'; g.fillRect(0, 150, W, 80);
    g.fillStyle = 'rgba(74,192,232,0.5)'; g.fillRect(0, 150, W, 1); g.fillRect(0, 229, W, 1);
    ptext(g, 'WALKABLE BAND', 6, 152, 'rgba(180,230,255,0.75)');
  }
  ptext(g, opt.k, 5, 5, 'rgba(255,255,255,0.28)', 2);
}
function frame() {
  if (playing) { cam += 0.9 * speed; frames += speed; if (cam > maxLen - W) cam = 0; SCRUB.value = String(Math.round(cam)); }
  for (const v of VIEWS) if (v.live) paint(v);
  requestAnimationFrame(frame);
}
