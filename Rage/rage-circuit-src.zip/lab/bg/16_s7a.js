// ============================================================ 7-A options
// 1500 units long, two trailing-cable hazards. The longest scene in the stage,
// so all four need something that changes as you walk rather than one motif
// stamped down the length.

// ---- A1: THE CLEAN CORRIDOR ----------------------------------------------
// What is there now, built properly: a pharmaceutical-grade corridor. The
// brightest background in the game, straight after the foundry's orange.
function s7a_corridor(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  // far: the corridor carrying on, blown out and out of focus
  const sky = f.createLinearGradient(0, 34, 0, 150);
  sky.addColorStop(0, '#e6eef3'); sky.addColorStop(1, '#a8b8c2');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 128) {
    f.fillStyle = 'rgba(150,170,182,0.35)'; f.fillRect(x, 48, 40, 100);
    f.fillStyle = 'rgba(255,255,255,0.40)'; f.fillRect(x + 44, 40, 70, 8);
  }
  // mid: rooms on the far side of the glass, each a different colour of work
  const tints = ['#9fd8c0', '#a8c4de', '#cdd6a8', '#c6a8cc'];
  m.fillStyle = '#6d7e8a'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 176) {
    const t = tints[(x / 176 | 0) % 4];
    m.fillStyle = t; m.fillRect(x + 6, 40, 156, 108);
    m.fillStyle = 'rgba(255,255,255,0.50)'; m.fillRect(x + 14, 46, 140, 5);    // the room's own light strip
    m.fillStyle = 'rgba(0,0,0,0.26)';
    for (let k = 0; k < 4; k++) m.fillRect(x + 18 + k * 36, 96 + (k % 2) * 8, 26, 52);   // benches
    m.fillStyle = 'rgba(0,0,0,0.38)';
    for (let k = 0; k < 3; k++) m.fillRect(x + 26 + k * 46, 66 + (k % 2) * 7, 16, 26);   // gear on them
    m.fillStyle = 'rgba(255,255,255,0.22)'; m.fillRect(x + 6, 40, 156, 2);
    m.fillStyle = 'rgba(0,0,0,0.28)'; m.fillRect(x + 162, 40, 14, 108);        // the wall between rooms
  }
  // near: the near wall with glazed bays, the ceiling services, the floor
  ceilingSlab(n, L, 34, 15, '#c2ccd4', '#e2ebf0', '#93a0aa');
  ductRun(n, L, 49, 11, '#b3bec7', '#d8e2e9');
  lightStrip(n, L, 62, '#f4fcff', 'rgba(228,244,255,0.26)', 108);
  cableTray(n, L, R, 92, '#8e9ba6', true);
  const W2 = L.near.width;
  for (let x = 0; x < W2; x += 176) {                            // glazed bays through to the labs
    n.fillStyle = '#b4c0c9'; n.fillRect(x, 60, 176, 6);           // the transom over the glass
    n.fillStyle = '#dbe5ec'; n.fillRect(x, 60, 176, 2);
    n.fillStyle = '#aeb9c2'; n.fillRect(x + 8, 66, 152, 3);       // the glazing frame
    n.fillStyle = '#aeb9c2'; n.fillRect(x + 8, 66, 4, 62);
    n.fillStyle = '#aeb9c2'; n.fillRect(x + 156, 66, 4, 62);
    n.fillStyle = '#aeb9c2'; n.fillRect(x + 80, 66, 3, 62);       // the mullion
    n.fillStyle = 'rgba(255,255,255,0.09)';                        // one soft reflection, not a slab
    n.beginPath(); n.moveTo(x + 12, 128); n.lineTo(x + 56, 69); n.lineTo(x + 68, 69); n.lineTo(x + 24, 128); n.fill();
    n.fillStyle = 'rgba(255,255,255,0.20)'; n.fillRect(x + 12, 66, 144, 1);
    panelWall(n, x, 128, 176, 20, R, '#d4dee5', '#eef5fa', '#aab6c0', 46);   // the dado under the glass
    n.fillStyle = '#9aa6b0'; n.fillRect(x + 160, 56, 16, 92);      // the pier between bays
    n.fillStyle = '#c4ced6'; n.fillRect(x + 160, 56, 5, 92);
    ptext(n, ['STERILE', 'ZONE 2', 'NO ENTRY', 'WASH'][(x / 176 | 0) % 4], x + 16, 132, 'rgba(70,92,106,0.75)');
    n.fillStyle = '#e4ebf0'; n.fillRect(x + 128, 130, 12, 16);
    n.fillStyle = '#4ac0e8'; n.fillRect(x + 130, 132, 8, 5);
  }
  for (let x = 250, i = 0; x < W2 - 200; x += 430, i++) {         // pressure doors down the run
    n.fillStyle = '#c2ccd4'; n.fillRect(x - 18, 56, 100, 92);
    n.fillStyle = '#e2ebf0'; n.fillRect(x - 18, 56, 100, 3);
    bulkhead(n, x, 68, 64, 80, R, '#aeb9c2', '#dde6ec', i % 2 ? '#5ad06a' : '#e8283a', 'D' + (i + 1));
  }
  epoxyFloor(n, L, R, r, LAB_TOP, '#aebcc6', 'rgba(110,130,144,0.45)', '#e6eef3');
  for (let x = 30; x < W2; x += 108) floorGlow(n, L, x + 33, LAB_TOP, 80, 'rgba(226,244,255,0.10)');
  floorMark(n, 0, 196, W2, 34, 'rgba(90,208,106,0.35)');
  for (let x = 0; x < W2; x += 240) ptext(n, 'WALKWAY', x + 40, 202, 'rgba(90,208,106,0.30)');
  L.labHum = 1;
}

// ---- A2: THE SERVER SPINE -------------------------------------------------
// The lab's data floor. Cold-aisle blue, thousands of little lights, and the
// raised floor lifted open so the looms are the reason the cables bite.
function s7a_servers(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#070b12'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 26) {                     // racks receding into the dark
    f.fillStyle = '#0c1220'; f.fillRect(x, 40, 22, 108);
    for (let y = 46; y < 144; y += 9) {
      f.fillStyle = ((x + y) % 7) < 3 ? 'rgba(74,192,232,0.30)' : 'rgba(74,192,232,0.07)';
      f.fillRect(x + 3, y, 16, 2);
    }
  }
  m.fillStyle = '#0a1018'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 52) {                     // the far aisle, seen end-on
    m.fillStyle = '#111a26'; m.fillRect(x, 38, 44, 110);
    m.fillStyle = '#18242f'; m.fillRect(x, 38, 44, 3);
    for (let y = 44; y < 146; y += 8) {
      const on = ((x * 3 + y * 5) % 11) < 5;
      m.fillStyle = on ? 'rgba(90,208,106,0.40)' : 'rgba(120,150,180,0.10)';
      m.fillRect(x + 4, y, 36, 2);
    }
  }
  m.fillStyle = 'rgba(10,20,34,0.45)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  // near: the cold aisle you are actually standing in
  ceilingSlab(n, L, 34, 13, '#151c26', '#222c3a', '#0c1219');
  for (let x = 0; x < W2; x += 64) {                              // overhead busway and fibre baskets
    n.fillStyle = '#2a3442'; n.fillRect(x, 47, 58, 8);
    n.fillStyle = '#3c4a5c'; n.fillRect(x, 47, 58, 2);
    n.fillStyle = '#e8a030'; n.fillRect(x + 50, 49, 4, 4);
  }
  cableTray(n, L, R, 64, '#28313d', true);
  lightStrip(n, L, 80, '#bfe6ff', 'rgba(120,190,240,0.16)', 128, 0.7);
  for (let x = 0; x < W2; x += 118) {                             // the rack rows either side
    n.fillStyle = '#0d131b'; n.fillRect(x, 92, 110, 56);
    rack(n, x + 4, 94, 48, 54, R, '#161d27', '#4ac0e8');
    rack(n, x + 56, 94, 48, 54, R, '#161d27', '#5ad06a');
    n.fillStyle = 'rgba(74,192,232,0.10)'; n.fillRect(x - 4, 92, 118, 56);
    n.fillStyle = '#2a3442'; n.fillRect(x + 104, 88, 10, 60);
    ptext(n, 'R' + String((x / 118 | 0) + 10), x + 6, 86, 'rgba(150,190,220,0.55)');
  }
  for (let x = 320; x < W2 - 200; x += 560) {                     // a glass end-cap door on the aisle
    n.fillStyle = '#1b2430'; n.fillRect(x - 10, 60, 110, 88);
    viewPane(n, x, 64, 90, 84, 'rgba(70,130,180,0.20)', '#2e3a4a');
    n.save(); n.shadowColor = '#4ac0e8'; n.shadowBlur = 8; n.fillStyle = '#4ac0e8';
    n.fillRect(x + 42, 70, 6, 6); n.restore();
    ptext(n, 'HALL B', x + 30, 82, 'rgba(180,220,245,0.60)');
  }
  tileFloor(n, L, R, r, LAB_TOP, '#131a24', '#1d2733', '#182029', 32);
  for (let x = 160; x < W2; x += 380) {                           // a lifted floor panel, loom exposed
    n.fillStyle = '#04060a'; n.fillRect(x, LAB_TOP, 62, 22);      // a hole, so it reads as depth not height
    n.fillStyle = 'rgba(0,0,0,0.55)'; n.fillRect(x, LAB_TOP, 62, 5);
    for (let k = 0; k < 8; k++) {
      n.strokeStyle = ['rgba(120,58,58,0.85)', 'rgba(56,86,140,0.85)',
                       'rgba(140,124,64,0.85)', 'rgba(58,118,90,0.85)'][k % 4]; n.lineWidth = 2;
      n.beginPath(); n.moveTo(x + 3, LAB_TOP + 8 + k * 1.8);
      n.quadraticCurveTo(x + 31, LAB_TOP + 5 + k * 2.1, x + 59, LAB_TOP + 9 + k * 1.8); n.stroke();
    }
    n.fillStyle = '#1b232c'; n.fillRect(x + 60, LAB_TOP - 22, 4, 24);   // the panel stood on edge
    n.fillStyle = '#26323e'; n.fillRect(x + 60, LAB_TOP - 22, 4, 3);
  }
  for (let x = 40; x < W2; x += 118) floorGlow(n, L, x + 55, LAB_TOP, 96, 'rgba(74,192,232,0.07)');
  n.fillStyle = 'rgba(10,26,44,0.30)'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  L.labHum = 1; L.blink = 1;
}

// ---- A3: THE GROWTH GALLERY -----------------------------------------------
// A working wall of culture tanks with the feed plant serving them. Green,
// wet, and wrong - and it makes the Specimen Wing feel like the next step
// rather than a new idea.
function s7a_growth(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#05100c'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 34) {                     // rank after rank, far back
    const g = f.createLinearGradient(0, 44, 0, 146);
    g.addColorStop(0, 'rgba(70,200,150,0.30)'); g.addColorStop(1, 'rgba(10,50,40,0.30)');
    f.fillStyle = g; f.fillRect(x + 4, 44, 24, 102);
    f.fillStyle = 'rgba(0,0,0,0.45)'; f.fillRect(x + 12, 74, 8, 44);
  }
  m.fillStyle = '#081a16'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 96) {                     // the second row, bigger
    tank(m, x + 14, 52, 46, 84, R, 'rgba(26,132,102,0.85)', 'rgba(110,232,180,0.9)', { body: R() < 0.7 });
  }
  m.fillStyle = 'rgba(4,20,16,0.40)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  ceilingSlab(n, L, 34, 14, '#16231f', '#22332c', '#0a1512');
  for (let x = 0; x < W2; x += 96) {                              // feed lines dropping into each tank
    n.fillStyle = '#2b3a34'; n.fillRect(x + 30, 48, 6, 30);
    n.fillStyle = '#3d514a'; n.fillRect(x + 30, 48, 2, 30);
    n.fillStyle = '#1a2622'; n.fillRect(x + 20, 44, 28, 7);
  }
  ductRun(n, L, 50, 9, '#27352f', '#3b4d45');
  cableTray(n, L, R, 76, '#2b3a34', true);
  for (let x = 0; x < W2; x += 96) {                              // the working row you walk past
    const big = (x / 96 | 0) % 3 === 1;
    const wdt = big ? 62 : 48, tp = big ? 74 : 82;
    tank(n, x + 16, tp, wdt, 148 - tp, R, 'rgba(22,150,112,0.92)', 'rgba(130,248,196,0.95)',
      { body: (x / 96 | 0) % 4 !== 2, label: 'C-' + String(140 + (x / 96 | 0)) });
    n.fillStyle = '#1d2a25'; n.fillRect(x + 10, 140, wdt + 12, 8);      // the plinth, above the band
    n.fillStyle = '#2b3d36'; n.fillRect(x + 10, 140, wdt + 12, 2);
    if ((x / 96 | 0) % 4 === 2) {                                        // an emptied tank, hatch open
      n.fillStyle = 'rgba(10,20,18,0.75)'; n.fillRect(x + 16, tp, wdt, 148 - tp);
      n.strokeStyle = '#e8283a'; n.lineWidth = 2; n.strokeRect(x + 16, tp, wdt, 148 - tp);
      ptext(n, 'EMPTY', x + 20, tp + 30, 'rgba(232,40,58,0.70)');
    }
  }
  for (let x = 300; x < W2 - 200; x += 520) {                     // the control desk between banks
    n.fillStyle = '#16221e'; n.fillRect(x, 84, 120, 64);
    n.fillStyle = '#213028'; n.fillRect(x, 84, 120, 3);
    for (let k = 0; k < 4; k++) {
      n.fillStyle = '#0a1a14'; n.fillRect(x + 8 + k * 28, 92, 22, 18);
      n.fillStyle = 'rgba(110,232,180,0.55)'; n.fillRect(x + 10 + k * 28, 94, 18, 3);
      n.fillStyle = 'rgba(110,232,180,0.25)'; n.fillRect(x + 10 + k * 28, 100, 12, 2);
    }
    ptext(n, 'CULTURE CTRL', x + 10, 118, 'rgba(140,220,186,0.55)');
  }
  epoxyFloor(n, L, R, r, LAB_TOP, '#13201c', 'rgba(70,140,116,0.22)', '#25403a');
  for (let x = 20; x < W2; x += 96) floorGlow(n, L, x + 44, LAB_TOP, 74, 'rgba(90,224,168,0.09)');
  for (let k = 0; k < W2 * 0.06; k++) {                           // spillage, drying on the floor
    n.fillStyle = 'rgba(80,200,150,0.07)';
    n.beginPath(); n.ellipse(r(0, W2), r(LAB_TOP + 8, 232), 8 + R() * 22, 3 + R() * 4, 0, 0, 7); n.fill();
  }
  L.bubbles = 96; L.labHum = 1;
}

// ---- A4: THE SERVICE CRAWL ------------------------------------------------
// The wildcard: you never reach the clean side. This is the plant space behind
// it - conduit, ducting, drip trays, emergency lighting and nothing else.
function s7a_crawl(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#060809'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 60) {                     // structure glimpsed behind the plant
    f.fillStyle = '#0d1113'; f.fillRect(x, 34, 48, 114);
    f.fillStyle = '#131719'; f.fillRect(x, 34, 48, 3);
  }
  m.fillStyle = '#0a0d0f'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 44) {                     // a wall of pipework, all silhouette
    m.fillStyle = '#12171a'; m.fillRect(x, 40, 12, 108);
    m.fillStyle = '#171d21'; m.fillRect(x + 20, 34, 8, 114);
    m.fillStyle = '#0e1214'; m.fillRect(x + 32, 56, 10, 92);
  }
  for (let x = 0; x < L.mid.width; x += 150) {                    // the odd emergency lamp, amber
    m.save(); m.shadowColor = '#e8a030'; m.shadowBlur = 16;
    m.fillStyle = '#ffd08a'; m.fillRect(x + 16, 62, 9, 6); m.restore();
    const g = m.createRadialGradient(x + 20, 65, 2, x + 20, 65, 96);
    g.addColorStop(0, 'rgba(232,160,48,0.42)'); g.addColorStop(0.5, 'rgba(232,140,40,0.14)');
    g.addColorStop(1, 'rgba(232,160,48,0)');
    m.fillStyle = g; m.fillRect(x - 76, 0, 192, 148);
  }
  const W2 = L.near.width;
  ductRun(n, L, 34, 24, '#232a2e', '#39434a');                    // the big supply trunk, right overhead
  n.fillStyle = 'rgba(0,0,0,0.45)'; n.fillRect(0, 58, W2, 6);
  for (let x = 0; x < W2; x += 132) {                             // flexible take-offs into the rooms
    n.fillStyle = '#2b3338'; n.beginPath();
    n.moveTo(x + 20, 58); n.quadraticCurveTo(x + 46, 70, x + 40, 96); n.lineTo(x + 54, 96);
    n.quadraticCurveTo(x + 62, 66, x + 34, 58); n.fill();
    for (let k = 0; k < 6; k++) { n.fillStyle = 'rgba(255,255,255,0.06)'; n.fillRect(x + 24 + k * 3, 62 + k * 5, 18, 2); }
  }
  for (const py of [70, 86, 102]) {                               // insulated runs, one of them weeping
    n.fillStyle = py === 86 ? '#4a3c2c' : '#2e383e'; n.fillRect(0, py, W2, 10);
    n.fillStyle = py === 86 ? '#6a5740' : '#47545e'; n.fillRect(0, py, W2, 2);
    n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(0, py + 8, W2, 2);
    for (let x = 0; x < W2; x += 118) { n.fillStyle = '#1b2227'; n.fillRect(x, py - 2, 7, 14); }
  }
  for (let x = 0; x < W2; x += 74) {                              // risers, so it is not all horizontals
    const h = [116, 148, 128][(x / 74 | 0) % 3];
    n.fillStyle = '#1d252a'; n.fillRect(x + 52, 58, 9, h - 58);
    n.fillStyle = '#2b363d'; n.fillRect(x + 52, 58, 3, h - 58);
    for (let y = 62; y < h; y += 26) { n.fillStyle = '#131a1e'; n.fillRect(x + 50, y, 13, 4); }
  }
  for (let x = 170; x < W2; x += 430) {                           // a caged ladder, the only way out
    n.fillStyle = '#232c32'; n.fillRect(x, 58, 4, 90); n.fillRect(x + 22, 58, 4, 90);
    for (let y = 62; y < 146; y += 9) { n.fillStyle = '#39454e'; n.fillRect(x, y, 26, 3); }
    n.strokeStyle = '#2b363d'; n.lineWidth = 2;
    for (let y = 66; y < 146; y += 16) { n.beginPath(); n.arc(x + 13, y, 19, 3.6, 5.8); n.stroke(); }
  }
  cableTray(n, L, R, 112, '#1f262a', true);
  for (let x = 0; x < W2; x += 96) {                              // lagging, taped and patched
    n.fillStyle = 'rgba(200,190,160,0.10)'; n.fillRect(x + 30, 84, 34, 9);
    n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x + 30, 91, 34, 2);
  }
  panelWall(n, 0, 124, W2, 24, R, '#1a2024', '#252e33', '#101416', 38);
  for (let x = 200; x < W2 - 160; x += 470) {                     // the back of a clean room, lit from inside
    n.fillStyle = '#131a1e'; n.fillRect(x - 12, 104, 130, 44);
    viewPane(n, x, 110, 106, 38, 'rgba(180,220,235,0.16)', '#20282d');
    ptext(n, 'LAB ' + String(3 + (x / 470 | 0)), x + 8, 116, 'rgba(190,225,240,0.45)');
    floorGlow(n, L, x + 53, LAB_TOP, 110, 'rgba(180,220,245,0.07)');
  }
  for (let x = 60; x < W2; x += 240) {                            // drip trays hung under the runs
    n.fillStyle = '#2a2018'; n.fillRect(x, 106, 54, 5);
    n.fillStyle = '#3a2d20'; n.fillRect(x, 106, 54, 1);
  }
  // floor: galvanised grating, dark, with a wet sheen under the lamps
  n.fillStyle = '#1b2227'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  for (let y = LAB_TOP; y < 240; y += 5) { n.fillStyle = '#28323a'; n.fillRect(0, y, W2, 2); }
  for (let x = 0; x < W2; x += 7) { n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, LAB_TOP, 1, 240 - LAB_TOP); }
  for (let x = 0; x < W2; x += 128) { n.fillStyle = '#323e47'; n.fillRect(x, LAB_TOP, 4, 240 - LAB_TOP); }
  for (let k = 0; k < W2 * 0.05; k++) {
    n.fillStyle = 'rgba(160,190,210,0.05)';
    n.beginPath(); n.ellipse(r(0, W2), r(LAB_TOP + 10, 234), 12 + R() * 26, 4 + R() * 5, 0, 0, 7); n.fill();
  }
  for (let x = 0; x < W2; x += 150) floorGlow(n, L, x + 19, LAB_TOP, 96, 'rgba(232,160,48,0.20)');
  n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  L.emerg = 1; L.crawlDrip = 1;
}
