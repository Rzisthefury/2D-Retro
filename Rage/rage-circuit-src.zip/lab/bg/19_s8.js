// ============================================================ STAGE 8 shared
// Tower Top. Contract for every option in this file:
//   * nothing meaningful above y=34 - the HUD sits there
//   * the floor starts at y<=150 and NOTHING solid is painted in 150..230,
//     which is the band the fighters walk through
// Which leaves y 34..148 to carry the whole stage. Eighty floors up, so every
// interior wants the city visible in it somewhere, and every exterior wants
// the drop underneath it to read as a long way down.
// The Atrium carries a pit hazard, so all four A options need an honest hole
// in the floor at roughly mid-scene. The Helipad ends the game, so all four
// C options need an unmistakable arena at the far end for Dray to stand in.
const FLOOR8 = 148;                  // interior floors
const DECK8  = 146;                  // roof decks

// ---- sky and city --------------------------------------------------------
// The dusk the whole stage happens in. One gradient, reused so the three
// scenes read as one evening.
function duskSky(f, L, R, r, stops, starTop = 56) {
  const w = L.far.width;
  const g = f.createLinearGradient(0, 0, 0, 176);
  stops.forEach(([p, c]) => g.addColorStop(p, c));
  f.fillStyle = g; f.fillRect(0, 0, w, H);
  for (let i = 0; i < w * 0.05; i++) {
    const y = r(0, starTop);
    f.fillStyle = `rgba(255,255,255,${0.20 + (1 - y / starTop) * 0.45})`;
    f.fillRect(r(0, w), y, 1, 1);
  }
  for (let k = 0; k < w * 0.012; k++) {              // cloud banks catching the last light
    const y = r(30, 104), cw = r(60, 170);
    f.fillStyle = `rgba(255,205,180,${0.06 + R() * 0.10})`;
    f.beginPath(); f.ellipse(r(0, w), y, cw, 4 + R() * 5, 0, 0, 7); f.fill();
  }
}
// The city seen from eighty floors up: not buildings, a carpet of light with
// a few towers standing out of it. Anything below `top` is the drop.
function cityBelow(f, L, R, r, top, haze = 'rgba(120,90,150,0.30)') {
  const w = L.far.width;
  f.fillStyle = '#241a34'; f.fillRect(0, top, w, 240 - top);
  for (let d = 0; d < 3; d++) {                       // three receding bands of rooftops
    const base = top + 6 + d * 13, tone = ['#2e2242', '#281d3a', '#221833'][d];
    for (let x = -20; x < w; x += 9 + (d * 5)) {
      const bh = 5 + ((x * 7 + d * 31) % 17);
      f.fillStyle = tone; f.fillRect(x, base - bh, 8 + d * 4, 240);
    }
  }
  for (let k = 0; k < w * 0.9; k++) {                 // the lights themselves
    const y = r(top + 4, 238);
    const near = (y - top) / (238 - top);
    f.fillStyle = R() < 0.62 ? `rgba(242,208,112,${0.35 + near * 0.55})`
                             : `rgba(122,184,240,${0.30 + near * 0.5})`;
    f.fillRect(r(0, w), y, 1, 1);
  }
  for (let k = 0; k < w * 0.035; k++) {               // arterial roads, orange and continuous
    const y = r(top + 10, 236), lw = r(20, 70);
    f.fillStyle = 'rgba(248,170,80,0.22)'; f.fillRect(r(0, w), y, lw, 1);
  }
  const hz = f.createLinearGradient(0, top - 10, 0, top + 40);
  hz.addColorStop(0, haze); hz.addColorStop(1, 'rgba(0,0,0,0)');
  f.fillStyle = hz; f.fillRect(0, top - 10, w, 50);
}
// The same city, but seen through a window from inside: flatter, dimmer, and
// with the glass sitting in front of it.
function cityPlate(g, x, y, w, h, R, r, dark = '#0b0a18') {
  g.fillStyle = dark; g.fillRect(x, y, w, h);
  for (let bx = x; bx < x + w; bx += 11) {
    const bh = 8 + ((bx * 13) % 26);
    g.fillStyle = ((bx / 11) | 0) % 2 ? '#171426' : '#12101f';
    g.fillRect(bx, y + h - bh, 10, bh);
  }
  for (let k = 0; k < w * h * 0.010; k++) {
    g.fillStyle = R() < 0.6 ? 'rgba(226,190,96,0.75)' : 'rgba(112,168,232,0.70)';
    g.fillRect(r(x + 1, x + w - 1), r(y + h * 0.35, y + h - 1), 1, 1);
  }
  for (let k = 0; k < 3; k++) {                        // a beacon that is always on
    g.fillStyle = 'rgba(232,58,58,0.8)'; g.fillRect(r(x, x + w), r(y + 2, y + h * 0.4), 1, 2);
  }
}
// A curtain wall: mullions, transoms, and glass that reflects the room as much
// as it shows the outside. Pass a painter for what is behind it.
function curtainWall(n, L, x, w, y, h, R, r, opts = {}) {
  const bay = opts.bay || 64, frame = opts.frame || '#2a2740', hi = opts.hi || '#454065';
  const tran = opts.transom !== false;
  n.save(); n.beginPath(); n.rect(x, y, w, h); n.clip();
  for (let bx = x; bx < x + w; bx += bay) {
    const bw = Math.min(bay - 7, x + w - bx - 7);
    if (bw < 6) break;
    cityPlate(n, bx, y, bw, h, R, r, opts.dark);
    n.fillStyle = 'rgba(150,190,255,0.055)'; n.fillRect(bx, y, bw, h);
    n.fillStyle = 'rgba(190,220,255,0.07)';  // the raking reflection down the glass
    n.beginPath(); n.moveTo(bx, y + h); n.lineTo(bx + bw * 0.5, y);
    n.lineTo(bx + bw * 0.78, y); n.lineTo(bx + bw * 0.2, y + h); n.fill();
    n.fillStyle = frame; n.fillRect(bx + bw, y, 7, h);
    n.fillStyle = hi; n.fillRect(bx + bw, y, 2, h);
    if (tran) { n.fillStyle = frame; n.fillRect(bx, y + Math.round(h * 0.38), bw, 3); }
  }
  n.restore();
  n.fillStyle = frame; n.fillRect(x, y - 4, w, 5);
  n.fillStyle = hi; n.fillRect(x, y - 4, w, 2);
  n.fillStyle = frame; n.fillRect(x, y + h - 2, w, 5);
}
// ---- floors --------------------------------------------------------------
// Polished stone: big slabs, veining, and a reflection of whatever is lit above.
function stoneFloor(n, L, R, r, top, base, vein, sheen, slab = 62) {
  const w = L.near.width;
  const g = n.createLinearGradient(0, top, 0, 240);
  g.addColorStop(0, sheen); g.addColorStop(0.4, base); g.addColorStop(1, base);
  n.fillStyle = g; n.fillRect(0, top, w, 240 - top);
  for (let x = 0; x < w; x += slab) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x, top, 1, 240 - top); }
  for (let y = top + 20; y < 240; y += 28) { n.fillStyle = 'rgba(0,0,0,0.18)'; n.fillRect(0, y, w, 1); }
  for (let k = 0; k < w * 0.30; k++) {                  // veining
    const vx = r(0, w), vy = r(top + 2, 238);
    n.strokeStyle = vein; n.lineWidth = 1;
    n.beginPath(); n.moveTo(vx, vy);
    n.quadraticCurveTo(vx + r(-14, 14), vy + r(-5, 5), vx + r(-26, 26), vy + r(-8, 8)); n.stroke();
  }
  n.fillStyle = 'rgba(255,255,255,0.05)'; n.fillRect(0, top, w, 2);
}
// Deep contract carpet with a woven border down each side of the walking lane.
function carpetFloor(n, L, R, r, top, base, fleck, border) {
  const w = L.near.width;
  n.fillStyle = base; n.fillRect(0, top, w, 240 - top);
  for (let k = 0; k < w * 3; k++) {
    n.fillStyle = R() < 0.5 ? fleck : 'rgba(0,0,0,0.12)';
    n.fillRect(r(0, w), r(top, 240), 1, 1);
  }
  n.fillStyle = border; n.fillRect(0, top + 4, w, 3); n.fillRect(0, 232, w, 3);
  n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(0, top, w, 3);
  const g = n.createLinearGradient(0, top, 0, top + 26);
  g.addColorStop(0, 'rgba(0,0,0,0.30)'); g.addColorStop(1, 'rgba(0,0,0,0)');
  n.fillStyle = g; n.fillRect(0, top, w, 26);
}
// A roof deck of concrete pavers on pedestals, with the joints open.
function deckFloor(n, L, R, r, top, base, hi, seam, pitch = 40) {
  const w = L.near.width;
  n.fillStyle = base; n.fillRect(0, top, w, 240 - top);
  for (let y = top, row = 0; y < 240; y += pitch, row++) {
    for (let x = -((row % 2) * 12); x < w; x += pitch) {
      n.fillStyle = (row + Math.round(x / pitch)) % 3 ? base : hi;
      n.fillRect(x + 1, y + 1, pitch - 2, pitch - 2);
      n.fillStyle = seam; n.fillRect(x, y, 1, pitch); n.fillRect(x, y, pitch, 1);
    }
  }
  for (let k = 0; k < w * 0.8; k++) {
    n.fillStyle = R() < 0.5 ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.10)';
    n.fillRect(r(0, w), r(top, 240), 3 + R() * 9, 1);
  }
  n.fillStyle = hi; n.fillRect(0, top, w, 2);
}
// ---- interior furniture --------------------------------------------------
// Figured wood panelling with a rail and a plinth: the executive vocabulary.
function woodPanel(g, x, y, w, h, R, r, base = '#3a2618', hi = '#5c3d24', dk = '#241408', pitch = 52) {
  g.fillStyle = base; g.fillRect(x, y, w, h);
  for (let px = x; px < x + w; px += pitch) {
    const pw = Math.min(pitch - 4, x + w - px - 4);
    if (pw < 6) break;
    g.fillStyle = hi; g.fillRect(px + 2, y + 6, pw, h - 18);
    g.fillStyle = dk; g.fillRect(px + 2, y + 6, pw, 2); g.fillRect(px + 2, y + 6, 2, h - 18);
    for (let k = 0; k < pw * 0.5; k++) {                     // grain
      g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,0.13)' : 'rgba(255,200,140,0.07)';
      g.fillRect(px + 3 + R() * (pw - 4), y + 8 + R() * (h - 22), 1, 3 + R() * 7);
    }
    g.fillStyle = dk; g.fillRect(px, y, 3, h);
  }
  g.fillStyle = hi; g.fillRect(x, y, w, 3);                  // cornice
  g.fillStyle = '#7a5230'; g.fillRect(x, y + h - 12, w, 3);  // dado rail
  g.fillStyle = dk; g.fillRect(x, y + h - 6, w, 6);          // plinth
}
// A framed picture on a wall, lit from above by its own little lamp.
function artFrame(g, x, y, w, h, R, r, tone) {
  g.fillStyle = '#c8a24c'; g.fillRect(x - 3, y - 3, w + 6, h + 6);
  g.fillStyle = '#8a6a28'; g.fillRect(x - 3, y + h, w + 6, 3);
  g.fillStyle = tone; g.fillRect(x, y, w, h);
  for (let k = 0; k < w * h * 0.03; k++) {
    g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,0.30)' : 'rgba(255,230,190,0.18)';
    g.fillRect(r(x, x + w), r(y, y + h), 2 + R() * 4, 1 + R() * 3);
  }
  g.fillStyle = '#d8b25c'; g.fillRect(x + w / 2 - 7, y - 9, 14, 4);   // picture light
  const gl = g.createLinearGradient(0, y - 5, 0, y + h);
  gl.addColorStop(0, 'rgba(255,224,160,0.22)'); gl.addColorStop(1, 'rgba(255,224,160,0)');
  g.fillStyle = gl; g.fillRect(x - 4, y - 5, w + 8, h + 5);
}
// A bank of workstations seen side-on, with the monitors facing away.
function deskBank(g, x, y, w, R, r, glow = '#4ac0e8') {
  g.fillStyle = '#1e1c2c'; g.fillRect(x, y + 14, w, 4);              // the worktop
  g.fillStyle = '#2c2940'; g.fillRect(x, y + 14, w, 2);
  for (let k = x + 4; k < x + w - 8; k += 26) {
    g.fillStyle = '#16141f'; g.fillRect(k, y + 18, 3, 12);           // legs
    g.fillRect(k + 18, y + 18, 3, 12);
    g.fillStyle = '#111019'; g.fillRect(k + 2, y, 18, 14);           // monitor back
    g.fillStyle = '#23202f'; g.fillRect(k + 2, y, 18, 2);
    const on = ((k * 7) % 5) < 4;
    if (on) { g.fillStyle = glow; g.fillRect(k + 1, y + 2, 1, 10);   // light spilling round it
      g.fillStyle = 'rgba(74,192,232,0.13)'; g.fillRect(k - 5, y - 3, 30, 22); }
  }
}
// A glazed meeting pod standing on the floor plate, lit from inside.
function glassPod(g, x, y, w, h, R, r, tint = 'rgba(120,180,240,0.10)', frame = '#37334e') {
  g.fillStyle = 'rgba(10,10,20,0.55)'; g.fillRect(x, y, w, h);
  g.fillStyle = tint; g.fillRect(x, y, w, h);
  g.fillStyle = 'rgba(255,236,190,0.14)'; g.fillRect(x + 2, y + 4, w - 4, h - 10);
  g.fillStyle = '#2a2436'; g.fillRect(x + w * 0.2, y + h - 16, w * 0.6, 4);   // a table inside
  for (let k = 0; k < 4; k++) g.fillRect(x + w * 0.24 + k * w * 0.15, y + h - 12, 4, 8);
  g.fillStyle = frame; g.fillRect(x - 2, y - 3, w + 4, 4); g.fillRect(x - 2, y + h - 2, w + 4, 4);
  g.fillStyle = frame; g.fillRect(x - 2, y, 3, h); g.fillRect(x + w - 1, y, 3, h);
  g.fillStyle = 'rgba(255,255,255,0.09)';
  g.beginPath(); g.moveTo(x, y + h); g.lineTo(x + w * 0.42, y); g.lineTo(x + w * 0.6, y);
  g.lineTo(x + w * 0.16, y + h); g.fill();
}
// A planter with something growing out of it. Kept above the walkable band.
function planter(g, x, y, w, R, r, tall) {
  g.fillStyle = '#1c1a26'; g.fillRect(x, y, w, 12);
  g.fillStyle = '#2e2b3c'; g.fillRect(x, y, w, 3);
  g.fillStyle = '#0e1a10'; g.fillRect(x + 2, y + 3, w - 4, 4);
  const cx = x + w / 2, th = tall ? 58 : 30;
  g.fillStyle = '#2a2016'; g.fillRect(cx - 2, y - th, 4, th);
  for (let k = 0; k < (tall ? 40 : 20); k++) {
    const a = R() * 6.28, rr = R() * (tall ? 26 : 16);
    const lx = cx + Math.cos(a) * rr, ly = y - th - 4 + Math.sin(a) * (tall ? 16 : 10);
    g.fillStyle = R() < 0.4 ? '#2e5a34' : (R() < 0.6 ? '#3e7a44' : '#1e4226');
    g.fillRect(lx, ly, 4 + R() * 4, 3);
  }
}
// A handrail with balusters: an edge you can see over.
function railing(g, x, y, w, col = '#4a4660', hi = '#6a6688', pitch = 22) {
  g.fillStyle = col; g.fillRect(x, y, w, 3);
  g.fillStyle = hi; g.fillRect(x, y, w, 1);
  g.fillStyle = col; g.fillRect(x, y + 13, w, 2);
  for (let px = x; px < x + w; px += pitch) { g.fillStyle = col; g.fillRect(px, y, 2, 24); }
  g.fillStyle = 'rgba(160,200,255,0.06)'; g.fillRect(x, y + 3, w, 21);
}
// A void through the floor plate - the pit's alibi. Painted ABOVE the walkable
// band only: the edge nosing at `top`, then darkness that the pit prop sits in.
function floorVoid(n, x, top, w, R, r, deep = '#07060e') {
  n.fillStyle = deep; n.fillRect(x, top - 26, w, 26);
  for (let d = 0; d < 3; d++) {                             // floors below, receding
    n.fillStyle = `rgba(90,110,160,${0.08 - d * 0.02})`;
    n.fillRect(x + 4 + d * 3, top - 22 + d * 7, w - 8 - d * 6, 2);
  }
  for (let k = 0; k < w * 0.2; k++) {
    n.fillStyle = 'rgba(226,190,96,0.35)'; n.fillRect(r(x + 3, x + w - 3), r(top - 24, top - 3), 1, 1);
  }
  n.fillStyle = '#3a3552'; n.fillRect(x - 3, top - 4, w + 6, 4);      // the nosing
  n.fillStyle = '#585070'; n.fillRect(x - 3, top - 4, w + 6, 1);
  hazard8(n, x - 3, top - 10, w + 6, 6);
}
// Yellow-and-black banding (stage 8 keeps its own copy so the file stands alone).
function hazard8(g, x, y, w, h, a = '#e8c040', b = '#181410') {
  g.fillStyle = b; g.fillRect(x, y, w, h);
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
  g.strokeStyle = a; g.lineWidth = 4;
  for (let k = -h; k < w + h; k += 10) { g.beginPath(); g.moveTo(x + k, y + h); g.lineTo(x + k + h, y); g.stroke(); }
  g.restore();
}
// ---- roof furniture ------------------------------------------------------
// A lattice mast with its aircraft beacon.
function mast(g, x, top, bot, col = '#16121e', beacon = '#ff3a3a', wide = 10) {
  g.fillStyle = col; g.fillRect(x - 1, top, 3, bot - top); g.fillRect(x + wide - 1, top, 3, bot - top);
  for (let y = top + 6; y < bot; y += 13) {
    g.fillRect(x, y, wide, 2);
    g.strokeStyle = col; g.lineWidth = 1.5;
    g.beginPath(); g.moveTo(x, y + 13); g.lineTo(x + wide, y); g.stroke();
  }
  g.save(); g.shadowColor = beacon; g.shadowBlur = 8; g.fillStyle = beacon;
  g.fillRect(x + wide / 2 - 2, top - 5, 5, 5); g.restore();
}
// A rooftop plant box: chiller, cooling tower, riser cluster.
function plantBox(g, x, y, w, h, R, r, col = '#1e1c26', hi = '#33303e') {
  g.fillStyle = col; g.fillRect(x, y, w, h);
  g.fillStyle = hi; g.fillRect(x, y, w, 3);
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x + w - 4, y, 4, h);
  for (let k = x + 5; k < x + w - 8; k += 9) { g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(k, y + 6, 5, h - 12); }
  g.fillStyle = hi; g.fillRect(x - 3, y + h - 4, w + 6, 4);
  g.fillStyle = '#4a4858';                                   // a fan in the top
  g.beginPath(); g.arc(x + w * 0.5, y + h * 0.4, Math.min(w, h) * 0.22, 0, 7); g.fill();
  g.fillStyle = col; g.beginPath(); g.arc(x + w * 0.5, y + h * 0.4, Math.min(w, h) * 0.18, 0, 7); g.fill();
}
// The pad marking: a circle and an H, painted flat so nobody trips on it.
function padMark(n, cx, cy, rad, col = '#e8e8f0', lw = 5) {
  n.strokeStyle = col; n.lineWidth = lw;
  n.beginPath(); n.arc(cx, cy, rad, 0, 7); n.stroke();
  const bh = rad * 0.78, bw = rad * 0.40, t = lw + 3;
  n.fillStyle = col;
  n.fillRect(cx - bw - t / 2, cy - bh / 2, t, bh);
  n.fillRect(cx + bw - t / 2, cy - bh / 2, t, bh);
  n.fillRect(cx - bw, cy - t / 2, bw * 2, t);
}
// Perimeter lights along a roof edge, with their falloff.
function edgeLights(n, L, y, col = '#ffdc60', pitch = 70) {
  const w = L.near.width;
  for (let x = 20; x < w; x += pitch) {
    n.fillStyle = col; n.fillRect(x, y, 4, 3);
    const g = n.createRadialGradient(x + 2, y + 1, 0, x + 2, y + 1, 16);
    g.addColorStop(0, 'rgba(255,220,96,0.30)'); g.addColorStop(1, 'rgba(255,220,96,0)');
    n.fillStyle = g; n.fillRect(x - 14, y - 15, 32, 32);
  }
}

// ---- deck dressing -------------------------------------------------------
// Everything painted onto a roof deck: approach chevrons, a painted edge line,
// tie-down rings, a stencilled number. Paint only - nothing to trip over.
function deckMarks(n, L, R, r, top, hx, col = 'rgba(232,232,240,0.30)', warm = 'rgba(255,200,90,0.22)') {
  const w = L.near.width;
  n.fillStyle = col; n.fillRect(0, top + 8, w, 2);                 // the painted safety line
  n.fillStyle = 'rgba(232,160,48,0.22)'; n.fillRect(0, 232, w, 2);
  for (let x = 40; x < w; x += 132) {                              // tie-down rings sunk in the deck
    n.fillStyle = 'rgba(0,0,0,0.38)'; n.beginPath(); n.ellipse(x, 176 + ((x * 7) % 46), 6, 3, 0, 0, 7); n.fill();
    n.strokeStyle = 'rgba(190,190,205,0.35)'; n.lineWidth = 1.5;
    n.beginPath(); n.ellipse(x, 175 + ((x * 7) % 46), 5, 2.5, 0, 0, 7); n.stroke();
  }
  for (let k = 0; k < 5; k++) {                                    // approach chevrons walking to the pad
    const cx = hx - 300 + k * 46;
    n.strokeStyle = warm; n.lineWidth = 4;
    n.beginPath(); n.moveTo(cx, 196); n.lineTo(cx + 18, 208); n.lineTo(cx, 220); n.stroke();
  }
  for (let x = 90; x < w; x += 296) {                              // a keep-clear box with a number
    n.strokeStyle = 'rgba(232,232,240,0.16)'; n.lineWidth = 2;
    n.strokeRect(x, 188, 74, 38);
    ptext(n, String(80 + ((x / 296) | 0)), x + 6, 192, 'rgba(232,232,240,0.22)', 2);
  }
  for (let k = 0; k < w * 0.4; k++) {                              // weathering so it is not a flat field
    n.fillStyle = R() < 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.09)';
    n.fillRect(r(0, w), r(top + 4, 238), 8 + R() * 22, 1 + (R() < 0.3 ? 1 : 0));
  }
}
// The drop, seen over the parapet from the deck: a strip of city between the
// handrail and the upstand, so the height reads without leaving the roof.
function dropStrip(n, L, R, r, y, h, dim = 1) {
  const w = L.near.width;
  n.fillStyle = '#100c1c'; n.fillRect(0, y, w, h);
  for (let d = 0; d < 2; d++) {
    const base = y + 5 + d * 7;
    for (let x = -10; x < w; x += 8 + d * 4) {
      const bh = 3 + ((x * 11 + d * 17) % 9);
      n.fillStyle = d ? '#1a1428' : '#221a32'; n.fillRect(x, base - bh, 7 + d * 3, h);
    }
  }
  for (let k = 0; k < w * 0.7 * dim; k++) {
    n.fillStyle = R() < 0.6 ? `rgba(242,208,112,${0.30 + R() * 0.45})` : `rgba(122,184,240,${0.25 + R() * 0.4})`;
    n.fillRect(r(0, w), r(y + 2, y + h - 1), 1, 1);
  }
  for (let k = 0; k < w * 0.03; k++) {
    n.fillStyle = 'rgba(248,170,80,0.30)'; n.fillRect(r(0, w), r(y + 3, y + h - 2), 12 + R() * 34, 1);
  }
  const hz = n.createLinearGradient(0, y, 0, y + h);
  hz.addColorStop(0, 'rgba(90,70,130,0.35)'); hz.addColorStop(1, 'rgba(90,70,130,0.05)');
  n.fillStyle = hz; n.fillRect(0, y, w, h);
}
