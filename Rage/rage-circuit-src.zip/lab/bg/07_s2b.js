// ============================================================ STAGE 2-B options
// Four takes on the room the fight ends in. Interiors: no sky, no kerb - the
// walkable band 150..230 is the floor, and the light does the work.

// a crowd of silhouettes packed behind a rail, the thing that sells a club
function crowd(g, x0, x1, y, R, h = 26, col = 'rgba(0,0,0,0.62)') {
  for (let x = x0; x < x1; x += 5 + R() * 4) {
    const hh = h * (0.8 + R() * 0.4), bob = Math.sin(x * 0.7) * 2;
    g.fillStyle = col;
    g.fillRect(x, y - hh + bob, 5, hh);
    g.beginPath(); g.arc(x + 2.5, y - hh + bob - 2, 3, 0, 7); g.fill();
    if (R() < 0.3) { g.fillRect(x + 4, y - hh + bob - 8, 1.6, 9); }   // an arm up
  }
}
function trussRig(g, x0, x1, y, R, cols) {
  g.fillStyle = '#2a2a34'; g.fillRect(x0, y, x1 - x0, 4); g.fillRect(x0, y + 10, x1 - x0, 4);
  g.strokeStyle = '#3a3a46'; g.lineWidth = 2;
  for (let x = x0; x < x1; x += 16) { g.beginPath(); g.moveTo(x, y + 4); g.lineTo(x + 8, y + 10); g.lineTo(x + 16, y + 4); g.stroke(); }
  for (let x = x0 + 14; x < x1 - 10; x += 44) {
    g.fillStyle = '#16161e'; g.fillRect(x, y + 14, 11, 12);
    const c = cols[Math.floor(R() * cols.length)];
    g.save(); g.shadowColor = c; g.shadowBlur = 9; g.fillStyle = c; g.fillRect(x + 1, y + 25, 9, 4); g.restore();
  }
}

// ---- B1: THE MAIN ROOM ----------------------------------------------------
function s2b_mainroom(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0a0612'; f.fillRect(0, 0, L.far.width, H);
  for (let k = 0; k < 16; k++) {                       // beams hanging in the haze
    const x = r(0, L.far.width), c = pick2(R, ['rgba(255,42,138,0.11)', 'rgba(42,216,255,0.11)', 'rgba(255,224,42,0.08)']);
    f.fillStyle = c; f.beginPath(); f.moveTo(x, 0); f.lineTo(x - 44, 150); f.lineTo(x + 24, 150); f.lineTo(x + 7, 0); f.fill();
  }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  // mid: the balcony, packed, looking down on the floor
  m.fillStyle = '#100a1a'; m.fillRect(0, 46, L.mid.width, 58);
  crowd(m, 0, L.mid.width, 78, R, 22, 'rgba(0,0,0,0.55)');
  m.fillStyle = '#241634'; m.fillRect(0, 78, L.mid.width, 7);
  m.fillStyle = '#3a2450'; m.fillRect(0, 78, L.mid.width, 2);
  for (let x = 0; x < L.mid.width; x += 13) { m.fillStyle = '#1a1026'; m.fillRect(x, 85, 3, 19); }
  // near: back wall, speaker stacks, the bar, then the DJ booth
  n.fillStyle = '#160e22'; n.fillRect(0, 0, L.near.width, 150);
  n.fillStyle = '#1e1430'; for (let y = 0; y < 150; y += 10) n.fillRect(0, y, L.near.width, 1);
  for (let x = 0; x < L.near.width; x += 120) {
    const c = pick2(R, ['#ff2a8a', '#2ad8ff', '#ffe02a', '#8a2aff']);
    n.save(); n.shadowColor = c; n.shadowBlur = 8; n.fillStyle = c;
    n.fillRect(x + 12, 26, 76, 3); n.fillRect(x + 12, 26, 3, 42); n.fillRect(x + 24, 48, 64, 3);
    n.restore();
  }
  trussRig(n, 0, L.near.width, 4, R, ['#ff2a8a', '#2ad8ff', '#ffe02a', '#8a2aff', '#2aff8a']);
  for (let x = 70; x < len - 420; x += 260) {
    for (let k = 0; k < 4; k++) {
      n.fillStyle = '#0a0a0e'; n.fillRect(x, 72 + k * 21, 38, 20);
      n.fillStyle = '#26262e'; n.beginPath(); n.arc(x + 19, 82 + k * 21, 8, 0, 7); n.fill();
      n.fillStyle = '#0e0e12'; n.beginPath(); n.arc(x + 19, 82 + k * 21, 4, 0, 7); n.fill();
      n.fillStyle = 'rgba(255,255,255,0.06)'; n.fillRect(x, 72 + k * 21, 38, 1);
    }
  }
  const barX = 330;
  n.fillStyle = '#10080e'; n.fillRect(barX, 40, 190, 68);
  for (let k = 0; k < 30; k++) { n.fillStyle = pick2(R, ['#3a8a3a', '#8a3a2a', '#c8c060', '#6a8ab8', '#c86a3a']);
    n.fillRect(barX + 8 + (k % 10) * 18, 50 + Math.floor(k / 10) * 19, 6, 15); }
  n.fillStyle = 'rgba(180,240,255,0.12)'; n.fillRect(barX, 40, 190, 68);
  n.fillStyle = '#2a1a1a'; n.fillRect(barX - 6, 110, 202, 40);
  n.fillStyle = '#6a3a2a'; n.fillRect(barX - 6, 108, 202, 4);
  n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(barX - 6, 108, 202, 1);
  crowd(n, barX + 4, barX + 186, 128, R, 30);
  neonText(n, 'BAR', barX + 84, 30, '#ffe04a', 2);
  // the DJ booth, raised, lit from below
  const djX = len - 420;
  n.fillStyle = '#0a0610'; n.fillRect(djX, 54, 150, 96);
  n.fillStyle = '#2a1a3a'; n.fillRect(djX, 54, 150, 7);
  n.fillStyle = '#1a1a22'; n.beginPath(); n.arc(djX + 40, 76, 14, 0, 7); n.arc(djX + 110, 76, 14, 0, 7); n.fill();
  n.fillStyle = '#3a3a46'; n.beginPath(); n.arc(djX + 40, 76, 4, 0, 7); n.arc(djX + 110, 76, 4, 0, 7); n.fill();
  n.fillStyle = '#16161e'; n.fillRect(djX + 58, 68, 34, 18);
  for (let k = 0; k < 12; k++) { n.fillStyle = pick2(R, ['#2ad8ff', '#3ae0a0', '#f2c94c']); n.fillRect(djX + 61 + (k % 6) * 5, 71 + Math.floor(k / 6) * 6, 3, 4); }
  n.fillStyle = 'rgba(0,0,0,0.6)'; n.fillRect(djX + 66, 52, 16, 22);
  n.beginPath(); n.arc(djX + 74, 50, 7, 0, 7); n.fill();
  n.fillStyle = '#8a2aff'; n.fillRect(djX, 96, 150, 3);
  n.fillStyle = 'rgba(138,42,255,0.14)'; n.fillRect(djX - 10, 99, 170, 51);
  neonText(n, 'DJ', djX + 66, 106, '#2ad8ff');
  // the VIP stage at the very end, where the fight finishes
  const vx = len - 180;
  n.fillStyle = '#300814'; n.fillRect(vx, 0, L.near.width - vx, 150);
  for (let x = vx; x < L.near.width; x += 14) { n.fillStyle = (Math.round(x / 14) % 2) ? '#5a0c20' : '#420a18'; n.fillRect(x, 0, 14, 128); }
  n.fillStyle = '#e8c860'; n.fillRect(vx, 128, L.near.width - vx, 4);
  neonText(n, 'VIP LOUNGE', vx + 60, 20, '#ffe04a', 2);
  const bx = vx + 130;
  n.fillStyle = '#6a6a78'; n.fillRect(bx, 0, 1, 34);
  for (let yy = -11; yy <= 11; yy += 3) for (let xx = -11; xx <= 11; xx += 3)
    if (xx * xx + yy * yy <= 120) { n.fillStyle = pick2(R, ['#e8e8f0', '#9a9ab0', '#c8c8e0', '#ffffff']); n.fillRect(bx + xx, 46 + yy, 2, 2); }
  n.fillStyle = '#0c0814'; n.fillRect(0, 150, L.near.width, 90);
  L.tiles = 1; L.haze = 1;
}

// ---- B2: THE BASEMENT -----------------------------------------------------
// Raw concrete, a scaffold rig and a wall of speakers. Colder, harder, and lit
// by strobe rather than colour.
function s2b_basement(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#07080c'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 90) {           // the back of the room, lost in the dark
    m.fillStyle = '#0d0f14'; m.fillRect(x, 40, 84, 110);
    if (R() < 0.4) { m.fillStyle = '#161a22'; m.fillRect(x + 10, 60, 64, 50); }
  }
  crowd(m, 0, L.mid.width, 150, R, 34, 'rgba(0,0,0,0.75)');
  concrete(n, 0, 0, L.near.width, 150, '#2e3138', R);
  // structural columns and the scaffold rig bolted between them
  for (let x = 30; x < L.near.width; x += 210) {
    concrete(n, x, 0, 34, 150, '#353942', R);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 30, 0, 4, 150);
    graffiti(n, x + 2, 96 + R() * 30, R, 30);
  }
  for (let y = 12; y < 44; y += 20) {
    n.fillStyle = '#4a4e58'; n.fillRect(0, y, L.near.width, 4);
    for (let x = 0; x < L.near.width; x += 46) { n.fillStyle = '#5c616d'; n.fillRect(x, y - 1, 5, 6); }
  }
  for (let x = 0; x < L.near.width; x += 46) { n.fillStyle = '#4a4e58'; n.fillRect(x, 12, 4, 34); }
  for (let x = 20; x < L.near.width; x += 56) {
    n.fillStyle = '#16161c'; n.fillRect(x, 44, 12, 13);
    n.fillStyle = R() < 0.5 ? '#e8f4ff' : '#0f1014'; n.fillRect(x + 1, 55, 10, 4);
  }
  // the wall of speakers: the reason anybody came
  for (let x = 60; x < len - 360; x += 200) {
    for (let c = 0; c < 2; c++) for (let s = 0; s < 4; s++) {
      const sx = x + c * 46, sy = 64 + s * 21;
      n.fillStyle = '#0a0a0e'; n.fillRect(sx, sy, 44, 20);
      n.fillStyle = '#1a1a20'; n.fillRect(sx + 1, sy + 1, 42, 18);
      n.fillStyle = '#26262e'; n.beginPath(); n.arc(sx + 13, sy + 10, 7, 0, 7); n.arc(sx + 31, sy + 10, 7, 0, 7); n.fill();
      n.fillStyle = '#0e0e12'; n.beginPath(); n.arc(sx + 13, sy + 10, 3, 0, 7); n.arc(sx + 31, sy + 10, 3, 0, 7); n.fill();
    }
    n.fillStyle = '#3a3a46'; n.fillRect(x - 4, 148, 96, 4);
  }
  // chain-link penning off the far side, and a van somebody drove in
  for (let x = len - 700; x < len - 380; x += 6) {
    n.strokeStyle = 'rgba(150,160,180,0.30)'; n.lineWidth = 1;
    n.beginPath(); n.moveTo(x, 58); n.lineTo(x + 46, 150); n.stroke();
    n.beginPath(); n.moveTo(x, 58); n.lineTo(x - 46, 150); n.stroke();
  }
  const vanX = len - 620;
  n.fillStyle = '#11131a'; n.fillRect(vanX, 86, 128, 64);
  n.fillStyle = '#54606e'; n.fillRect(vanX + 2, 88, 124, 60);
  n.fillStyle = '#3e4854'; n.fillRect(vanX + 2, 88, 124, 5);
  n.fillStyle = '#1c2430'; n.fillRect(vanX + 86, 96, 36, 20);
  graffiti(n, vanX + 10, 122, R, 66);
  n.fillStyle = '#11131a'; n.beginPath(); n.arc(vanX + 28, 150, 9, 0, 7); n.arc(vanX + 104, 150, 9, 0, 7); n.fill();
  // the end of the room: the rig, a riser, and one red exit sign
  const r0 = len - 360;
  n.fillStyle = '#0c0e13'; n.fillRect(r0, 0, L.near.width - r0, 150);
  trussRig(n, r0 + 10, L.near.width - 10, 34, R, ['#e8f4ff', '#e8f4ff', '#3aff8a', '#ff2a4a']);
  n.fillStyle = '#1a1e26'; n.fillRect(r0 + 40, 104, L.near.width - r0 - 80, 46);
  n.fillStyle = '#252b36'; n.fillRect(r0 + 40, 104, L.near.width - r0 - 80, 4);
  for (let k = 0; k < 6; k++) { n.fillStyle = '#0a0a0e'; n.fillRect(r0 + 56 + k * 40, 66, 32, 36);
    n.fillStyle = '#26262e'; n.beginPath(); n.arc(r0 + 72 + k * 40, 84, 10, 0, 7); n.fill(); }
  n.fillStyle = '#2a0e12'; n.fillRect(L.near.width - 70, 40, 44, 18);
  n.save(); n.shadowColor = '#ff2a3a'; n.shadowBlur = 9; ptext(n, 'EXIT', L.near.width - 64, 45, '#ff4a56'); n.restore();
  // the floor: bare slab, taped lines, spilled everything
  n.fillStyle = '#23262c'; n.fillRect(0, 150, L.near.width, 90);
  for (let k = 0; k < L.near.width * 1.6; k++) { n.fillStyle = R() < 0.5 ? '#2a2e35' : '#1c1f25';
    n.fillRect(r(0, L.near.width), r(152, 240), 3, 1); }
  for (let x = 0; x < L.near.width; x += 74) { n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x, 150, 2, 90); }
  for (let k = 0; k < L.near.width / 90; k++) { n.fillStyle = 'rgba(0,0,0,0.28)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(160, 234), 12 + R() * 20, 4 + R() * 5, 0, 0, 7); n.fill(); }
  for (let k = 0; k < L.near.width / 16; k++) {
    n.fillStyle = pick2(R, ['rgba(190,200,210,0.35)', 'rgba(140,170,120,0.3)', 'rgba(200,150,90,0.3)']);
    n.save(); n.translate(r(0, L.near.width), r(156, 236)); n.rotate(R() * 3); n.fillRect(0, 0, 3 + R() * 5, 2); n.restore();
  }
  n.fillStyle = 'rgba(232,200,40,0.5)'; n.fillRect(0, 226, L.near.width, 3);
  L.strobe = 1; L.haze = 1;
}

// ---- B3: THE GAMING FLOOR -------------------------------------------------
// The club's respectable face one floor down: carpet, brass, green baize and a
// band on a stage. Warmer, slower, and the money is visible.
function s2b_casino(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#140a12'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 74) {
    m.fillStyle = '#1c1018'; m.fillRect(x, 30, 68, 120);
    m.fillStyle = '#2a1824'; m.fillRect(x + 6, 40, 56, 76);
    m.fillStyle = 'rgba(232,200,120,0.10)'; m.fillRect(x + 10, 44, 48, 68);
  }
  crowd(m, 0, L.mid.width, 150, R, 28, 'rgba(0,0,0,0.5)');
  // near: panelled walls, heavy drapes, chandeliers
  n.fillStyle = '#2a1620'; n.fillRect(0, 0, L.near.width, 150);
  for (let x = 0; x < L.near.width; x += 64) {
    n.fillStyle = '#331a26'; n.fillRect(x, 0, 58, 150);
    n.fillStyle = 'rgba(232,200,120,0.09)'; n.fillRect(x + 4, 20, 50, 96);
    n.fillStyle = '#5a3a24'; n.fillRect(x + 2, 18, 54, 3); n.fillRect(x + 2, 116, 54, 3);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 58, 0, 6, 150);
  }
  n.fillStyle = '#c8a040'; n.fillRect(0, 124, L.near.width, 4);
  n.fillStyle = '#8a6a28'; n.fillRect(0, 128, L.near.width, 2);
  for (let x = 40; x < L.near.width; x += 150) {        // drapes between the panels
    n.fillStyle = '#6a1424'; n.fillRect(x, 0, 42, 126);
    for (let k = 0; k < 42; k += 6) { n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(x + k, 0, 2, 126); }
    n.fillStyle = '#c8a040'; n.fillRect(x - 2, 0, 46, 5);
    n.fillStyle = '#8a1a2a'; n.fillRect(x, 120, 42, 6);
  }
  for (let x = 110; x < L.near.width; x += 220) {       // chandeliers
    n.fillStyle = '#c8a040'; n.fillRect(x, 0, 2, 16);
    n.fillStyle = '#e8c860'; n.beginPath(); n.arc(x + 1, 20, 9, 0, 7); n.fill();
    for (let k = 0; k < 9; k++) { const a = k * 0.7;
      n.fillStyle = '#fff0c0'; n.fillRect(x + 1 + Math.cos(a) * 13, 20 + Math.abs(Math.sin(a)) * 9, 2, 5); }
    n.fillStyle = 'rgba(255,230,160,0.11)'; n.beginPath(); n.arc(x + 1, 30, 40, 0, 7); n.fill();
  }
  // the tables: baize, rails, chips, a dealer behind each
  for (let x = 60; x < len - 380; x += 150) {
    const kind = Math.floor(R() * 2);
    n.fillStyle = '#3a2418'; n.fillRect(x, 108, 108, 34);
    n.fillStyle = '#1a5a34'; n.fillRect(x + 4, 111, 100, 26);
    n.fillStyle = '#227a44'; n.fillRect(x + 4, 111, 100, 3);
    n.fillStyle = '#5a3a20'; n.fillRect(x, 106, 108, 4);
    if (kind === 0) { n.fillStyle = '#16121c'; n.beginPath(); n.ellipse(x + 30, 124, 18, 9, 0, 0, 7); n.fill();
      n.fillStyle = '#c8a040'; n.beginPath(); n.ellipse(x + 30, 123, 17, 8, 0, 0, 7); n.fill();
      for (let k = 0; k < 12; k++) { const a = k * 0.52; n.fillStyle = (k % 2) ? '#c8202a' : '#16121c';
        n.fillRect(x + 30 + Math.cos(a) * 12, 123 + Math.sin(a) * 5.5, 3, 3); } }
    else { for (let k = 0; k < 7; k++) { n.fillStyle = '#e8e0d0';
      n.save(); n.translate(x + 14 + k * 12, 124); n.rotate(-0.2); n.fillRect(0, 0, 8, 11); n.restore(); } }
    for (let k = 0; k < 6; k++) { const cx3 = x + 12 + k * 16;
      n.fillStyle = pick2(R, ['#c8202a', '#2a5ac8', '#1a8a4a', '#e8e0d0']);
      for (let s = 0; s < 2 + Math.floor(R() * 3); s++) n.fillRect(cx3, 134 - s * 2, 7, 2); }
    crowd(n, x + 4, x + 104, 108, R, 26, 'rgba(0,0,0,0.55)');
  }
  // the stage at the end: a band in silhouette under a spot
  const s0 = len - 380;
  n.fillStyle = '#1e0e16'; n.fillRect(s0, 0, L.near.width - s0, 150);
  n.fillStyle = '#6a1424'; n.fillRect(s0, 0, L.near.width - s0, 40);
  for (let k = s0; k < L.near.width; k += 7) { n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(k, 0, 2, 40); }
  n.fillStyle = '#c8a040'; n.fillRect(s0, 38, L.near.width - s0, 4);
  neonText(n, 'THE VELVET ROOM', s0 + 40, 12, '#ffd86a', 2);
  n.fillStyle = '#2a1a1e'; n.fillRect(s0 + 20, 110, L.near.width - s0 - 40, 34);
  n.fillStyle = '#4a2a24'; n.fillRect(s0 + 20, 108, L.near.width - s0 - 40, 4);
  for (let k = 0; k < 4; k++) {
    const bx = s0 + 54 + k * 68;
    n.fillStyle = 'rgba(0,0,0,0.75)'; n.fillRect(bx, 74, 10, 36);
    n.beginPath(); n.arc(bx + 5, 70, 6, 0, 7); n.fill();
    if (k === 1) { n.fillRect(bx - 12, 86, 14, 5); n.fillRect(bx - 14, 78, 5, 12); }
    if (k === 2) { n.fillStyle = 'rgba(0,0,0,0.75)'; n.beginPath(); n.ellipse(bx + 16, 96, 11, 13, 0, 0, 7); n.fill(); }
  }
  for (let k = 0; k < 3; k++) { const lx = s0 + 60 + k * 90;
    n.fillStyle = 'rgba(255,230,170,0.10)';
    n.beginPath(); n.moveTo(lx, 44); n.lineTo(lx - 34, 150); n.lineTo(lx + 44, 150); n.lineTo(lx + 12, 44); n.fill(); }
  // the floor: patterned carpet, worn down the middle
  n.fillStyle = '#4a1420'; n.fillRect(0, 150, L.near.width, 90);
  for (let y = 152; y < 240; y += 14) for (let x = 0; x < L.near.width; x += 22) {
    n.fillStyle = (Math.round(y / 14) + Math.round(x / 22)) % 2 ? '#571a28' : '#43121e';
    n.fillRect(x, y, 21, 13);
    n.fillStyle = 'rgba(200,160,64,0.13)';
    n.beginPath(); n.arc(x + 11, y + 7, 4, 0, 7); n.fill();
  }
  n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(0, 178, L.near.width, 32);
  for (let k = 0; k < L.near.width * 0.7; k++) { n.fillStyle = 'rgba(0,0,0,0.10)'; n.fillRect(r(0, L.near.width), r(152, 238), 3, 2); }
  n.fillStyle = '#c8a040'; n.fillRect(0, 150, L.near.width, 3);
  L.haze = 1;
}

// ---- B4: THE TANK ROOM ----------------------------------------------------
// The wildcard: a designer club built around a wall of illuminated aquaria.
// Blue caustic light, a glass walkway, and nothing else in the game like it.
function s2b_tanks(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#04080e'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 56) {
    m.fillStyle = '#071018'; m.fillRect(x, 20, 50, 130);
    m.fillStyle = 'rgba(40,150,190,0.12)'; m.fillRect(x + 4, 26, 42, 118);
  }
  crowd(m, 0, L.mid.width, 150, R, 26, 'rgba(0,0,0,0.6)');
  // near: the tank wall. Every tank a different depth, weed and inhabitant.
  n.fillStyle = '#0a141c'; n.fillRect(0, 0, L.near.width, 150);
  let x = 0;
  while (x < len - 340) {
    const tw2 = 74 + R() * 40, top = 16 + R() * 12, bot = 128 - R() * 8;
    n.fillStyle = '#16232e'; n.fillRect(x, top - 4, tw2, bot - top + 8);
    const g2 = n.createLinearGradient(0, top, 0, bot);
    g2.addColorStop(0, '#2a8ab0'); g2.addColorStop(0.55, '#155a80'); g2.addColorStop(1, '#0a2e48');
    n.fillStyle = g2; n.fillRect(x + 3, top, tw2 - 6, bot - top);
    // shafts through the water
    for (let k = 0; k < 4; k++) { n.fillStyle = 'rgba(160,230,255,0.07)';
      const sx2 = x + 8 + R() * (tw2 - 20);
      n.beginPath(); n.moveTo(sx2, top); n.lineTo(sx2 - 8, bot); n.lineTo(sx2 + 6, bot); n.lineTo(sx2 + 8, top); n.fill(); }
    // weed, rock and whatever is living in there
    n.fillStyle = '#12463a';
    for (let k = 0; k < 9; k++) { const wx = x + 6 + R() * (tw2 - 12), wh = 16 + R() * 34;
      n.beginPath(); n.moveTo(wx, bot); n.quadraticCurveTo(wx + 6, bot - wh / 2, wx + 2, bot - wh);
      n.lineTo(wx + 5, bot - wh); n.quadraticCurveTo(wx + 10, bot - wh / 2, wx + 4, bot); n.fill(); }
    n.fillStyle = '#0d2636';
    n.beginPath(); n.ellipse(x + tw2 * 0.4, bot, 20, 8, 0, 0, 7); n.fill();
    n.beginPath(); n.ellipse(x + tw2 * 0.75, bot, 13, 6, 0, 0, 7); n.fill();
    const kind = Math.floor(R() * 3);
    if (kind === 0) for (let k = 0; k < 7; k++) {            // a shoal
      const fx = x + 10 + R() * (tw2 - 20), fy = top + 14 + R() * (bot - top - 28);
      n.fillStyle = pick2(R, ['#ffd86a', '#ff8a4a', '#e8f4ff']);
      n.beginPath(); n.ellipse(fx, fy, 4, 2.2, 0, 0, 7); n.fill();
      n.beginPath(); n.moveTo(fx - 4, fy); n.lineTo(fx - 8, fy - 2.5); n.lineTo(fx - 8, fy + 2.5); n.fill();
    } else if (kind === 1) for (let k = 0; k < 4; k++) {     // jellyfish
      const jx = x + 16 + k * (tw2 - 30) / 3, jy = top + 20 + R() * 40;
      n.save(); n.shadowColor = '#c8a0ff'; n.shadowBlur = 8;
      n.fillStyle = 'rgba(210,180,255,0.7)';
      n.beginPath(); n.arc(jx, jy, 6, Math.PI, 0); n.fill();
      n.restore();
      n.strokeStyle = 'rgba(210,180,255,0.45)'; n.lineWidth = 1;
      for (let t2 = 0; t2 < 4; t2++) { n.beginPath(); n.moveTo(jx - 4 + t2 * 2.6, jy);
        n.quadraticCurveTo(jx - 5 + t2 * 3, jy + 9, jx - 3 + t2 * 2.4, jy + 17); n.stroke(); }
    } else {                                                  // one big slow thing
      n.fillStyle = 'rgba(20,60,80,0.85)';
      n.beginPath(); n.ellipse(x + tw2 / 2, top + (bot - top) * 0.45, 24, 9, 0.12, 0, 7); n.fill();
      n.beginPath(); n.moveTo(x + tw2 / 2 - 24, top + (bot - top) * 0.45);
      n.lineTo(x + tw2 / 2 - 36, top + (bot - top) * 0.45 - 8);
      n.lineTo(x + tw2 / 2 - 34, top + (bot - top) * 0.45 + 8); n.fill();
      n.fillStyle = '#cfe8f4'; n.beginPath(); n.arc(x + tw2 / 2 + 16, top + (bot - top) * 0.43, 1.6, 0, 7); n.fill();
    }
    // the glass: highlight, bubbles and the steel frame
    n.fillStyle = 'rgba(200,245,255,0.14)'; n.fillRect(x + 6, top, 7, bot - top);
    n.fillStyle = 'rgba(200,245,255,0.08)'; n.fillRect(x + 17, top, 3, bot - top);
    for (let k = 0; k < 10; k++) { n.fillStyle = 'rgba(220,250,255,0.35)';
      n.beginPath(); n.arc(x + 10 + R() * (tw2 - 20), top + R() * (bot - top), 0.8 + R() * 1.2, 0, 7); n.fill(); }
    n.fillStyle = '#2b3f4e'; n.fillRect(x, top - 6, tw2, 7); n.fillRect(x, bot, tw2, 8);
    n.fillStyle = '#40596c'; n.fillRect(x, top - 6, tw2, 2); n.fillRect(x, bot, tw2, 2);
    n.fillStyle = '#16232e'; n.fillRect(x + tw2 - 4, top - 6, 5, bot - top + 14);
    x += tw2;
  }
  // the end: a curved glass tunnel with the fight inside it
  const t0 = len - 340, tw3 = L.near.width - t0;
  n.fillStyle = '#071119'; n.fillRect(t0, 0, tw3, 150);
  const g3 = n.createLinearGradient(0, 0, 0, 150);
  g3.addColorStop(0, '#1d6e92'); g3.addColorStop(0.6, '#0e3f5c'); g3.addColorStop(1, '#071f30');
  n.fillStyle = g3; n.fillRect(t0 + 6, 6, tw3 - 12, 138);
  for (let k = 0; k < 7; k++) { n.fillStyle = 'rgba(160,230,255,0.06)';
    const sx2 = t0 + 14 + k * (tw3 - 28) / 7;
    n.beginPath(); n.moveTo(sx2, 6); n.lineTo(sx2 - 14, 144); n.lineTo(sx2 + 4, 144); n.lineTo(sx2 + 10, 6); n.fill(); }
  for (let k = 0; k < 5; k++) {
    const jx = t0 + 40 + k * (tw3 - 80) / 4, jy = 30 + R() * 60;
    n.save(); n.shadowColor = '#c8a0ff'; n.shadowBlur = 10; n.fillStyle = 'rgba(215,190,255,0.75)';
    n.beginPath(); n.arc(jx, jy, 9, Math.PI, 0); n.fill(); n.restore();
    n.strokeStyle = 'rgba(215,190,255,0.4)'; n.lineWidth = 1;
    for (let t2 = 0; t2 < 5; t2++) { n.beginPath(); n.moveTo(jx - 6 + t2 * 3, jy);
      n.quadraticCurveTo(jx - 8 + t2 * 4, jy + 14, jx - 4 + t2 * 3, jy + 26); n.stroke(); }
  }
  for (let k = 0; k < 5; k++) {                          // the ribs of the tunnel
    const rx = t0 + k * tw3 / 4;
    n.fillStyle = '#2b3f4e'; n.fillRect(rx, 0, 8, 150);
    n.fillStyle = '#44607a'; n.fillRect(rx + 1, 0, 3, 150);
  }
  n.fillStyle = '#16232e'; n.fillRect(t0, 0, tw3, 8);
  neonText(n, 'THE DEEP END', t0 + tw3 / 2 - tw('THE DEEP END', 2) / 2, 152 - 150, '#8ef0ff', 2);
  // the floor: backlit glass panels over more water
  n.fillStyle = '#0a1a26'; n.fillRect(0, 150, L.near.width, 90);
  for (let y = 152; y < 240; y += 22) for (let x2 = 0; x2 < L.near.width; x2 += 34) {
    n.fillStyle = (Math.round(y / 22) + Math.round(x2 / 34)) % 2 ? '#10283a' : '#0c2030';
    n.fillRect(x2 + 1, y + 1, 32, 20);
    n.fillStyle = 'rgba(120,220,255,0.06)'; n.fillRect(x2 + 1, y + 1, 32, 3);
  }
  for (let k = 0; k < L.near.width / 20; k++) {            // caustics on the floor
    n.fillStyle = 'rgba(140,230,255,0.07)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(155, 236), 8 + R() * 14, 2 + R() * 4, R(), 0, 7); n.fill();
  }
  n.fillStyle = 'rgba(80,190,230,0.10)'; n.fillRect(0, 150, L.near.width, 90);
  n.fillStyle = '#2b3f4e'; n.fillRect(0, 150, L.near.width, 3);
  L.caustic = 1; L.haze = 1;
}
