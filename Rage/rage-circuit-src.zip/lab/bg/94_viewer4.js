// ============================================================ the picker (stage 2)
const SECTIONS = [
  { id: 'A', stage: '4-A', now: 'RAIL YARD', len: 1540, options: [
    { k: 'A1', name: 'The Yard', f: s4a_yard,
      pitch: 'What you have now, built out: a working yard full of mismatched rolling stock.',
      notes: ['Boxcars, tank wagons, loaded hoppers and tarped flats - four wagon types, none of them the same twice running',
              'Real point work between the roads: turnouts, point motors, lever targets and signal posts',
              'Sleeper stacks, oil drums, a spare bogie and rail off the track; the boss train waits at the far end'] },
    { k: 'A2', name: 'The Roundhouse', f: s4a_roundhouse,
      pitch: 'Inside the engine shed. Locomotives nose-in, smoke vents overhead, pits in the floor.',
      notes: ['Curved roof trusses with smoke vents open to the sky and lamps hanging on hooks over every road',
              'Smokebox doors, buffer beams and lamps facing you down the length of the shed',
              'Oily setts with inspection pits let into them, and the turntable as the arena'] },
    { k: 'A3', name: 'The Cutting', f: s4a_cutting,
      pitch: 'A deep cutting: retaining walls either side, a signal gantry across the top, a tunnel at the end.',
      notes: ['Brick retaining wall with buttress piers, drainage staining and buddleia growing out of the joints',
              'A lattice signal gantry spans the whole cutting with three signal heads on it',
              'The fight finishes in the tunnel mouth - a real arch with voussoirs round it'] },
    { k: 'A4', name: 'The Container Terminal', f: s4a_terminal,
      pitch: 'The wildcard. An intermodal yard: stacked boxes, a straddling gantry, painted lanes.',
      notes: ['Container blocks stacked one to three high in six liveries, with corner castings and box numbers',
              'A rail-mounted gantry straddles the entire scene with its spreader hanging off the trolley',
              'A reach stacker at the arena end; the most orderly and colourful background in the game'] },
  ] },
  { id: 'B', stage: '4-B', now: 'ON THE ROOF', len: 1240, options: [
    { k: 'B1', name: 'The Roof', f: s4b_roof,
      pitch: 'What you have now, built out: carriage roofs with a raised running board down the middle.',
      notes: ['Plates, seams and rivet rows, with vents, hatches and a lit skylight punched through them',
              'The running board is a distinct raised strip - the footing reads instead of being a flat slab',
              'Real gaps between carriages with the couplings and brake pipes visible, sleepers flashing below'] },
    { k: 'B2', name: 'The Flatbeds', f: s4b_flats,
      pitch: 'A string of flat wagons, each carrying something different. The footing changes every wagon.',
      notes: ['Timber bundles, steel coil in cradles, a tarped machine, and one empty with stanchions up',
              'Timber decking on a steel solebar with a hazard stripe along the edge',
              'You cross a real gap between every wagon'] },
    { k: 'B3', name: 'The Tanker Train', f: s4b_tankers,
      pitch: 'Curved tank tops with a walkway along the spine and handrails either side.',
      notes: ['The barrel is shaded as a cylinder, so the footing reads as round and narrow',
              'Domes, valve gear, hazard placards and end ladders between tanks',
              'Yellow handrails frame the fight - and they are exactly what you throw people over'] },
    { k: 'B4', name: 'The Bridge Run', f: s4b_bridge,
      pitch: 'The wildcard. The train is crossing a girder bridge and the steel whips past in front of you.',
      notes: ['Near truss verticals and diagonals pass in the foreground at high frequency - the most kinetic option by far',
              'The river is a long way down with the bridge lights reflected in it',
              'Runs 50% faster than the other three, and the arena is the middle of the span where the steel opens out'] },
  ] },
];

const BUILT = new Map();
const ORDER = [];
function build(opt, len) {
  if (BUILT.has(opt.k)) { touch(opt.k); return BUILT.get(opt.k); }
  const R = mulberry(opt.k.charCodeAt(0) * 7919 + opt.k.charCodeAt(1) * 131 + len);
  const r = (a, b) => a + R() * (b - a);
  const L = {
    far: mkCanvas(Math.ceil(W + len * 0.25) + 20, H),
    mid: mkCanvas(Math.ceil(W + len * 0.55) + 20, H),
    near: mkCanvas(len + W, H),
  };
  opt.f(L, R, r, len);
  BUILT.set(opt.k, L); ORDER.push(opt.k);
  while (ORDER.length > 6) { const dead = ORDER.shift(); if (dead !== opt.k) BUILT.delete(dead); }
  return L;
}
function touch(k) { const i = ORDER.indexOf(k); if (i >= 0) { ORDER.splice(i, 1); ORDER.push(k); } }

// ---- live overlays -------------------------------------------------------
function drawTiles(g, t, cam) {
  const step = Math.floor(t / 20), tw2 = 30, th = 12;
  for (let row = 0; row < 8; row++) {
    const y = 150 + row * th, off = (row % 2) * (tw2 / 2);
    for (let col = -1; col < W / tw2 + 2; col++) {
      const wx = col * tw2 + off - (cam % tw2);
      const gx = Math.floor((col * tw2 + off + cam) / tw2);
      const on = (gx + row + step) % 3 === 0;
      const cols = ['#ff2a8a', '#2ad8ff', '#ffe02a', '#8a2aff', '#2aff8a', '#ff7a2a'];
      g.fillStyle = on ? cols[(gx * 7 + row * 3 + step) % 6] : '#1a1024';
      g.globalAlpha = on ? 0.34 : 0.9;
      g.fillRect(Math.round(wx) + 1, y + 1, tw2 - 2, th - 2);
    }
  }
  g.globalAlpha = 1;
}
function drawStrobe(g, t) {
  const beat = t % 42;
  if (beat < 3) { g.fillStyle = 'rgba(240,248,255,0.30)'; g.fillRect(0, 0, W, H); }
  else if (beat < 6) { g.fillStyle = 'rgba(240,248,255,0.12)'; g.fillRect(0, 0, W, H); }
  for (let k = 0; k < 4; k++) {
    const a = t * 0.02 + k * 1.6;
    const x = W / 2 + Math.sin(a) * (W / 2 + 40);
    g.fillStyle = k % 2 ? 'rgba(58,255,138,0.06)' : 'rgba(232,244,255,0.05)';
    g.beginPath(); g.moveTo(x, 46); g.lineTo(x - 40, 240); g.lineTo(x + 26, 240); g.lineTo(x + 8, 46); g.fill();
  }
}
function drawHaze(g, t, cam) {
  for (let i = 0; i < 7; i++) {
    const seed = i * 211;
    const x = ((seed * 37 + t * (0.25 + (i % 3) * 0.12)) % (W + 200)) - 100;
    const y = 120 + ((seed % 70));
    g.fillStyle = `rgba(200,210,235,${0.030 + (i % 3) * 0.012})`;
    g.beginPath(); g.ellipse(x, y + Math.sin(t / 60 + i) * 7, 60 + (i % 4) * 22, 16 + (i % 3) * 7, 0, 0, 7); g.fill();
  }
}
function drawCaustic(g, t, cam) {
  g.save(); g.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 16; i++) {
    const seed = i * 149;
    const x = ((seed * 23 - cam * 0.6) % (W + 80) + W + 80) % (W + 80) - 40;
    const y = 152 + (seed % 78);
    const w2 = 12 + Math.abs(Math.sin(t / 34 + i)) * 16;
    g.fillStyle = 'rgba(90,190,235,0.055)';
    g.beginPath(); g.ellipse(x, y, w2, 3 + Math.abs(Math.cos(t / 28 + i)) * 3, i * 0.4, 0, 7); g.fill();
  }
  g.restore();
}

function drawSpeedLines(g, sp, t) {
  for (let i = 0; i < 14; i++) {
    const seed = i * 97;
    const y = 152 + ((seed * 13) % 84);
    const x = W - (((t * (7 + (i % 4) * 3) * sp + seed * 31) % (W + 90)));
    g.fillStyle = i % 3 ? 'rgba(255,255,255,0.10)' : 'rgba(180,220,255,0.16)';
    g.fillRect(x, y, 22 + (i % 5) * 8, 1);
  }
  for (let i = 0; i < 6; i++) {
    const y = 120 + ((i * 53) % 26);
    const x = W - (((t * 16 * sp + i * 71) % (W + 140)));
    g.fillStyle = 'rgba(255,240,200,0.12)';
    g.fillRect(x, y, 50, 1);
  }
}
function drawShedSteam(g, t, cam) {
  for (let i = 0; i < 8; i++) {
    const seed = i * 193;
    const life = (t * 0.42 + seed) % 200;
    const x = ((seed * 31) % 1600) - (cam % 1600);
    if (x < -50 || x > W + 50) continue;
    const a = Math.max(0, 0.22 * (1 - life / 200));
    g.fillStyle = `rgba(226,226,236,${a})`;
    g.beginPath(); g.arc(x + Math.sin(life / 26) * 10, 150 - life * 0.62, 7 + life * 0.13, 0, 7); g.fill();
  }
}
function drawDust(g, t, cam) {
  for (let i = 0; i < 22; i++) {
    const seed = i * 167;
    const x = ((seed * 41 + t * (0.5 + (i % 4) * 0.28)) % (W + 160)) - 80;
    const y = 120 + ((seed % 110)) + Math.sin(t / 40 + i) * 5;
    g.fillStyle = `rgba(222,198,158,${0.05 + (i % 3) * 0.022})`;
    g.beginPath(); g.ellipse(x, y, 26 + (i % 5) * 16, 8 + (i % 3) * 5, 0, 0, 7); g.fill();
  }
  g.fillStyle = 'rgba(222,198,158,0.05)'; g.fillRect(0, 100, W, 140);
}
function drawWind(g, t, cam) {
  for (let i = 0; i < 14; i++) {
    const seed = i * 131;
    const x = ((seed * 53 + t * (2.4 + (i % 4))) % (W + 200)) - 100;
    const y = 46 + ((seed % 170));
    g.fillStyle = i % 3 ? 'rgba(255,255,255,0.10)' : 'rgba(255,220,190,0.13)';
    g.fillRect(x, y, 16 + (i % 5) * 9, 1);
  }
}
function drawVertigo(g, t, cam) {
  // a slow sway, as if the jib is moving under you
  g.fillStyle = 'rgba(255,190,140,0.04)';
  g.fillRect(0, 150 + Math.sin(t / 90) * 3, W, 90);
}

const VIEWS = [];
let playing = true, speed = 1, cam = 0, frames = 0, maxLen = 1540;
function makeView(card, opt, len) {
  const cv = card.querySelector('canvas');
  cv.width = W * PX; cv.height = H * PX;
  const g = cv.getContext('2d');
  g.imageSmoothingEnabled = false;
  const v = { cv, g, opt, len, live: false };
  VIEWS.push(v);
  const io = new IntersectionObserver(es => { es.forEach(e => { v.live = e.isIntersecting; }); }, { rootMargin: '200px' });
  io.observe(cv);
  return v;
}
function paint(v) {
  const { g, opt, len } = v;
  const L = build(opt, len);
  g.setTransform(PX, 0, 0, PX, 0, 0);
  const c = Math.min(cam, len - W);
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  if (L.speed) {
    // vehicle scene: the world keeps rushing past even when you stand still,
    // exactly as the game does it - far and mid wrap, near rides with the camera
    const wrap = (v2, w2) => -(((v2 % w2) + w2) % w2);
    const ff = wrap(Math.round(c * 0.25) + Math.round(frames * L.speed * 1.4), L.far.width);
    const mm = wrap(Math.round(c * 0.55) + Math.round(frames * L.speed * 3.4), L.mid.width);
    g.drawImage(L.far, ff, 0, L.far.width, L.far.height);
    g.drawImage(L.far, ff + L.far.width, 0, L.far.width, L.far.height);
    g.drawImage(L.mid, mm, 0, L.mid.width, L.mid.height);
    g.drawImage(L.mid, mm + L.mid.width, 0, L.mid.width, L.mid.height);
  } else {
    g.drawImage(L.far, -Math.round(c * 0.25), 0, L.far.width, L.far.height);
    g.drawImage(L.mid, -Math.round(c * 0.55), 0, L.mid.width, L.mid.height);
  }
  g.drawImage(L.near, -Math.round(c), 0, L.near.width, L.near.height);
  if (L.tiles) drawTiles(g, frames, c);
  if (L.speed) drawSpeedLines(g, L.speed, frames);
  if (L.steamShed) drawShedSteam(g, frames, c);
  if (L.caustic) drawCaustic(g, frames, c);
  if (L.dust) drawDust(g, frames, c);
  if (L.wind) drawWind(g, frames, c);
  if (L.vertigo) drawVertigo(g, frames, c);
  if (L.strobe) drawStrobe(g, frames);
  if (L.haze) drawHaze(g, frames, c);
  if (BAND.checked) {
    g.fillStyle = 'rgba(74,192,232,0.10)'; g.fillRect(0, 150, W, 80);
    g.fillStyle = 'rgba(74,192,232,0.5)'; g.fillRect(0, 150, W, 1); g.fillRect(0, 229, W, 1);
    ptext(g, 'WALKABLE BAND', 6, 152, 'rgba(180,230,255,0.75)');
  }
  ptext(g, opt.k, 5, 5, 'rgba(255,255,255,0.28)', 2);
}
function frame() {
  if (playing) { cam += 0.9 * speed; frames += speed; if (cam > maxLen - W) cam = 0; SCRUB.value = String(Math.round(cam)); }
  for (const v of VIEWS) if (v.live) paint(v);
  requestAnimationFrame(frame);
}
