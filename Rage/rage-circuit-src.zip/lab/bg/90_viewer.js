// ============================================================ the picker
const SECTIONS = [
  { id: 'A', stage: '1-A', now: 'MAIN STREET', len: 1560, options: [
    { k: 'A1', name: 'Downtown Crossing', f: s1a_crossing,
      pitch: 'The same block you have now, rebuilt out of seven genuinely different buildings.',
      notes: ['Brownstone, bodega, dead theatre, tenement, car park, vacant lot, all-night diner - never two the same in a row',
              'The street changes shape as you walk it: a side-street crossing a third of the way in, scaffolding overhead, opening onto a junction for the boss',
              'Lit windows with people, TVs, plants; pigeons, parked cars, bus shelter, phone box, steam grates'] },
    { k: 'A2', name: 'Rain on 4th', f: s1a_rain,
      pitch: 'Same city, soaked. The road becomes a mirror and the neon bleeds down into it.',
      notes: ['Overcast - no stars, towers half dissolved in haze, cooler and greyer than the others',
              'Standing water everywhere holding coloured light; rain falls in three layers over the top',
              'Ends under a railway bridge with water sheeting off the edge'] },
    { k: 'A3', name: 'Under the Elevated', f: s1a_elevated,
      pitch: 'The street runs beneath an el line. Steel columns march past in front of you.',
      notes: ['Riveted columns and cross-bracing in the foreground give the scroll a hard rhythm no facade can',
              'A train crosses the deck above in the mid layer, throwing light down through the girders',
              'Sodium lamps bolted to every third column pool on the pavement; the boss fight is in the dark span at the end'] },
    { k: 'A4', name: 'Night Market', f: s1a_market,
      pitch: 'The wildcard. A packed market street under canopies and paper lanterns.',
      notes: ['Stalls between you and the shops: produce, hanging meat, fish on ice - each one different',
              'Strung lanterns and vertical neon signs stacked up the facades',
              'Hot red and gold palette, steam drifting through, the densest of the four'] },
  ] },
  { id: 'B', stage: '1-B', now: 'BACK ALLEY', len: 1320, options: [
    { k: 'B1', name: 'Service Alley', f: s1b_alley,
      pitch: 'What you have now, done properly: a brick canyon where every wall has had a different life.',
      notes: ['Walls alternate brick, render and concrete, each aged its own way, with painted-over ghost signs showing through',
              'Standpipes, soil stacks, barred windows, back doors - some lit and stepped, some boarded over',
              'Still finishes in the floodlit fenced lot, so nothing about the boss fight changes'] },
    { k: 'B2', name: 'Loading Docks', f: s1b_docks,
      pitch: 'Behind the shops. Roll-up doors at a dozen different heights, and a truck half backed in.',
      notes: ['Numbered bays, some shuttered in different colours, some open and glowing with pallets inside',
              'A box truck jutting out into the alley that you have to walk around',
              'Ends in a container yard under floodlight masts'] },
    { k: 'B3', name: 'The Subway Cut', f: s1b_subway,
      pitch: 'The alley drops underground. Tiled mezzanine, then the platform with a train waiting.',
      notes: ['Hard change of material halfway: brick and sky, then white tile and strip light',
              'Mosaic station panels, steel columns, benches, a busker case, a rat',
              'The boss fight happens alongside a standing train with people in the windows'] },
    { k: 'B4', name: 'The Rooftops', f: s1b_roofs,
      pitch: 'The wildcard. The alley goes up instead of along - tar roofs above the whole city.',
      notes: ['Roofs step up and down between blocks, with parapets you fight along',
              'Water towers, AC plant, pigeon coops, laundry lines, satellite dishes, lit stair bulkheads',
              'The full skyline sits behind you and the sky does the work the walls used to'] },
  ] },
];

// ---- build one option's layers (lazily, and evicted when we have too many)
const BUILT = new Map();
const ORDER = [];
function build(opt, len) {
  if (BUILT.has(opt.k)) { touch(opt.k); return BUILT.get(opt.k); }
  const R = mulberry(opt.k.charCodeAt(0) * 7919 + opt.k.charCodeAt(1) * 131 + len);
  const r = (a, b) => a + R() * (b - a);
  const L = {
    far: mkCanvas(Math.ceil(W + len * 0.25) + 20, H),
    mid: mkCanvas(Math.ceil(W + len * 0.55) + 20, H),
    near: mkCanvas(len + W, H),
  };
  opt.f(L, R, r, len);
  BUILT.set(opt.k, L); ORDER.push(opt.k);
  while (ORDER.length > 6) { const dead = ORDER.shift(); if (dead !== opt.k) BUILT.delete(dead); }
  return L;
}
function touch(k) { const i = ORDER.indexOf(k); if (i >= 0) { ORDER.splice(i, 1); ORDER.push(k); } }

// ---- the weather overlays, drawn live so they actually move
function drawRain(g, t, cam) {
  g.save();
  for (let layer = 0; layer < 3; layer++) {
    const n = [46, 34, 18][layer], sp = [13, 9, 5][layer], ln = [22, 15, 9][layer];
    g.strokeStyle = ['rgba(190,215,255,0.34)', 'rgba(190,215,255,0.22)', 'rgba(190,215,255,0.14)'][layer];
    g.lineWidth = layer === 0 ? 1.4 : 1;
    for (let i = 0; i < n; i++) {
      const seed = i * 137 + layer * 53;
      const x = ((seed * 31) % (W + 60)) - 30 - (cam * (0.3 + layer * 0.25)) % (W + 60) + (W + 60);
      const y = ((t * sp + seed * 17) % (H + 40)) - 20;
      g.beginPath(); g.moveTo(x % (W + 60) - 30, y); g.lineTo(x % (W + 60) - 33, y + ln); g.stroke();
    }
  }
  // splash-back on the road
  g.fillStyle = 'rgba(200,225,255,0.20)';
  for (let i = 0; i < 16; i++) {
    const seed = i * 211;
    if ((t + seed) % 34 > 5) continue;
    g.fillRect((seed * 13 + Math.floor(t / 34) * 71) % W, ROAD + 6 + (seed % 30), 3, 1);
  }
  g.fillStyle = 'rgba(120,150,200,0.06)'; g.fillRect(0, 0, W, H);
  g.restore();
}
function drawSteam(g, t, cam) {
  g.save();
  for (let i = 0; i < 9; i++) {
    const seed = i * 173;
    const life = (t * 0.55 + seed) % 150;
    const x = ((seed * 29) % 1400) - (cam % 1400);
    if (x < -40 || x > W + 40) continue;
    const a = Math.max(0, 0.22 * (1 - life / 150));
    g.fillStyle = `rgba(226,226,236,${a})`;
    g.beginPath(); g.arc(x + Math.sin(life / 22) * 9, 200 - life * 0.9, 6 + life * 0.14, 0, 7); g.fill();
    g.beginPath(); g.arc(x + 9 + Math.sin(life / 17) * 7, 208 - life * 0.75, 4 + life * 0.11, 0, 7); g.fill();
  }
  g.restore();
}

// ---- the running preview
const VIEWS = [];
let playing = true, speed = 1, cam = 0, frames = 0, maxLen = 1560;
function makeView(card, opt, len) {
  const cv = card.querySelector('canvas');
  cv.width = W * PX; cv.height = H * PX;
  const g = cv.getContext('2d');
  g.imageSmoothingEnabled = false;
  const v = { cv, g, opt, len, live: false, ready: false };
  VIEWS.push(v);
  const io = new IntersectionObserver(es => { es.forEach(e => { v.live = e.isIntersecting; }); }, { rootMargin: '200px' });
  io.observe(cv);
  return v;
}
function paint(v) {
  const { g, opt, len } = v;
  const L = build(opt, len);
  v.ready = true;
  g.setTransform(PX, 0, 0, PX, 0, 0);
  const c = Math.min(cam, len - W);
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  g.drawImage(L.far, -Math.round(c * 0.25), 0, L.far.width, L.far.height);
  g.drawImage(L.mid, -Math.round(c * 0.55), 0, L.mid.width, L.mid.height);
  g.drawImage(L.near, -Math.round(c), 0, L.near.width, L.near.height);
  if (L.rain) drawRain(g, frames, c);
  if (L.steam) drawSteam(g, frames, c);
  // the walkable band, so it is obvious where the fight actually happens
  if (BAND.checked) {
    g.fillStyle = 'rgba(74,192,232,0.10)'; g.fillRect(0, 150, W, 80);
    g.fillStyle = 'rgba(74,192,232,0.5)'; g.fillRect(0, 150, W, 1); g.fillRect(0, 229, W, 1);
    ptext(g, 'WALKABLE BAND', 6, 152, 'rgba(180,230,255,0.75)');
  }
  ptext(g, opt.k, 5, 5, 'rgba(255,255,255,0.28)', 2);
}
function frame() {
  if (playing) { cam += 0.9 * speed; frames += speed; if (cam > maxLen - W) cam = 0; SCRUB.value = String(Math.round(cam)); }
  for (const v of VIEWS) if (v.live) paint(v);
  requestAnimationFrame(frame);
}
