// ============================================================ building types
// Ground contract shared with the game's street: facades occupy y 0..142,
// sidewalk 140..196, curb at 196, road 201..240. The walkable band is 150..230,
// so nothing below y=150 may be solid-looking.
const GROUND = 142, WALK = 140, CURB = 196, ROAD = 201;

function bldgBrownstone(g, x, w, R) {
  const top = 12 + R() * 16;
  const wall = pick2(R, ['#6a3a2e', '#5a3228', '#73402f', '#4e3630']);
  brick(g, x, top, w, GROUND - top, wall, R, { course: 4, bw: 10 });
  cornice(g, x, top, w, '#7d4a38', 6);
  // tall sash windows in two storeys, stone lintels above each
  for (let row = 0; row < 2; row++) {
    const wy = top + 16 + row * 34;
    const n = Math.max(2, Math.floor(w / 26));
    for (let i = 0; i < n; i++) {
      const wx = x + 8 + i * ((w - 16) / n);
      g.fillStyle = '#8a6a58'; g.fillRect(wx - 3, wy - 4, 16, 3);
      windowUnit(g, wx, wy, 10, 20, R, { litRate: 0.45, sill: '#8a6a58' });
    }
  }
  // parlour floor: door up a stoop, garden level below it
  const dx = x + w * 0.58;
  g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(x, GROUND - 34, w, 34);
  doorway(g, dx, GROUND - 40, 15, 28, R, { col: '#3a2418' });
  stoop(g, dx - 4, GROUND, 23, R);
  g.fillStyle = '#16121c'; g.fillRect(x + 6, GROUND - 20, 14, 18);     // garden-level window
  g.fillStyle = R() < 0.5 ? '#e8c060' : '#241f38'; g.fillRect(x + 8, GROUND - 18, 10, 14);
  for (let k = 8; k < 19; k += 3) { g.fillStyle = '#16121c'; g.fillRect(x + k, GROUND - 19, 1, 16); }  // bars
  if (R() < 0.5) fireEscape(g, x + 4, top + 30, 18, 2, R);
}

function bldgBodega(g, x, w, R) {
  const top = 26 + R() * 14;
  stucco(g, x, top, w, GROUND - top, pick2(R, ['#8a6a3a', '#7a5a4a', '#6a6a52']), R);
  cornice(g, x, top, w, '#4a3a2a', 4);
  windowGrid(g, x + 6, top + 12, w - 12, 34, Math.max(2, Math.round(w / 30)), 1, R, { litRate: 0.5 });
  // shopfront: awning, window full of goods, door, crates and a cooler outside
  const sx = x + 4, sw = w - 8;
  g.fillStyle = '#16121c'; g.fillRect(sx, GROUND - 58, sw, 58);
  awning(g, sx, GROUND - 60, sw, R);
  shopWindow(g, sx + 4, GROUND - 42, sw * 0.56, 34, R, { inner: '#3a4a2a' });
  doorway(g, sx + sw * 0.68, GROUND - 42, 17, 40, R);
  const word = pick2(R, ['MARKET', 'GROCERY', 'DELI', 'BODEGA', 'FRUIT']);
  g.fillStyle = '#0c0a12'; g.fillRect(sx + 2, GROUND - 72, sw - 4, 11);
  neonText(g, word, sx + sw / 2 - tw(word) / 2, GROUND - 70, pick2(R, ['#ff4a8a', '#4ae8ff', '#e8ff4a', '#ff8a2a']));
  crates(g, x + w * 0.1, WALK + 44, R, 3);
  g.fillStyle = '#d8d0c8'; g.fillRect(x + w * 0.64, WALK + 30, 14, 16);   // ice cooler
  g.fillStyle = '#2a6ac8'; g.fillRect(x + w * 0.64, WALK + 30, 14, 5);
  ptext(g, 'ICE', x + w * 0.64 + 1, WALK + 36, '#e8f0ff');
}

function bldgTheatre(g, x, w, R) {
  const top = 8;
  g.fillStyle = '#3a2a3e'; g.fillRect(x, top, w, GROUND - top);
  for (let k = 0; k < 40; k++) { g.fillStyle = 'rgba(0,0,0,0.08)'; g.fillRect(x + R() * w, top + R() * (GROUND - top), 4 + R() * 16, 2 + R() * 7); }
  cornice(g, x, top, w, '#5a4460', 7);
  // arched upper windows, mostly dark - the place is half shut
  const n = Math.max(3, Math.round(w / 34));
  for (let i = 0; i < n; i++) {
    const wx = x + 10 + i * ((w - 20) / n), wy = top + 20;
    g.fillStyle = '#16121c'; g.beginPath(); g.moveTo(wx, wy + 26); g.lineTo(wx, wy + 8);
    g.arc(wx + 7, wy + 8, 7, Math.PI, 0); g.lineTo(wx + 14, wy + 26); g.fill();
    g.fillStyle = R() < 0.22 ? '#c8a050' : '#221c30';
    g.beginPath(); g.moveTo(wx + 2, wy + 24); g.lineTo(wx + 2, wy + 8);
    g.arc(wx + 7, wy + 8, 5, Math.PI, 0); g.lineTo(wx + 12, wy + 24); g.fill();
  }
  // vertical blade sign, half its bulbs dead
  const bx = x + w * 0.12;
  g.fillStyle = '#12101a'; g.fillRect(bx - 11, top + 2, 22, 78);
  const title = pick2(R, ['ORPHEUM', 'RIALTO', 'ROXY', 'PALACE']);
  neonCol(g, title.slice(0, 7), bx - 3, top + 8, '#ff3a6a', 1);
  for (let k = 0; k < 9; k++) {
    const on = R() < 0.62;
    g.fillStyle = on ? '#ffe08a' : '#2a2430';
    g.fillRect(bx - 10, top + 8 + k * 8, 2, 2); g.fillRect(bx + 8, top + 8 + k * 8, 2, 2);
  }
  // marquee over the pavement
  const mx = x + 6, mw = w - 12, my = GROUND - 56;
  g.fillStyle = '#16121c'; g.fillRect(mx, my, mw, 20);
  g.fillStyle = '#241c2e'; g.fillRect(mx + 2, my + 2, mw - 4, 16);
  for (let k = mx + 3; k < mx + mw - 3; k += 6) {
    g.fillStyle = R() < 0.7 ? '#ffe08a' : '#3a3040';
    g.fillRect(k, my - 2, 3, 3); g.fillRect(k, my + 19, 3, 3);
  }
  const line = pick2(R, ['CLOSED', 'ONE NIGHT', 'TONIGHT', 'SOLD OUT']);
  ptext(g, line, mx + mw / 2 - tw(line) / 2, my + 7, '#e8d8a0');
  // boarded doors and poster cases
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x, GROUND - 36, w, 36);
  for (let k = 0; k < 3; k++) {
    const dx = x + w * (0.3 + k * 0.17);
    g.fillStyle = '#2a1e24'; g.fillRect(dx, GROUND - 34, 14, 34);
    g.fillStyle = '#6a5a44';
    g.save(); g.translate(dx + 7, GROUND - 17); g.rotate(-0.22); g.fillRect(-10, -2, 20, 4); g.restore();
  }
  for (let k = 0; k < 2; k++) {
    const px_ = x + w * (0.06 + k * 0.78);
    g.fillStyle = '#16121c'; g.fillRect(px_, GROUND - 44, 16, 26);
    g.fillStyle = pick2(R, ['#8a2a3a', '#2a4a8a', '#6a2a6a']); g.fillRect(px_ + 1, GROUND - 43, 14, 24);
    g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(px_ + 3, GROUND - 38, 10, 12);
  }
}

function bldgTenement(g, x, w, R) {
  const top = 4 + R() * 10;
  const wall = pick2(R, ['#5a4a52', '#4a4458', '#63483e', '#41404f']);
  brick(g, x, top, w, GROUND - top, wall, R, { course: 5, bw: 11 });
  cornice(g, x, top, w, '#2e2836', 5);
  if (R() < 0.45) ghostSign(g, x + 6, top + 14, w - 12, 30, pick2(R, ['COAL', 'CIGARS', 'HOTEL', 'TONIC']), R);
  const cols = Math.max(3, Math.round(w / 22)), rows = 4;
  windowGrid(g, x + 4, top + 12, w - 8, GROUND - top - 50, cols, rows, R, { litRate: 0.42, acRate: 0.2, blindRate: 0.34 });
  // fire escapes are the signature - two zig-zag runs down the face
  fireEscape(g, x + w * 0.16, top + 30, 22, 3, R);
  if (w > 120) fireEscape(g, x + w * 0.62, top + 30, 22, 3, R);
  // street level: a shuttered shop and a stair down to a basement door
  g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x, GROUND - 38, w, 38);
  const sx = x + 8, sw = w * 0.42;
  g.fillStyle = '#2a2830'; g.fillRect(sx, GROUND - 34, sw, 34);
  for (let k = 0; k < sw; k += 4) { g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(sx + k, GROUND - 34, 2, 34); }
  graffiti(g, sx + 4, GROUND - 16, R, sw - 10);
  doorway(g, x + w * 0.62, GROUND - 34, 16, 34, R, { col: '#2a3a3a' });
}

function bldgGarage(g, x, w, R) {
  const top = 18;
  concrete(g, x, top, w, GROUND - top, '#4e4a54', R);
  // open parking decks - rows of dark slots with a car or two parked in them
  for (let row = 0; row < 3; row++) {
    const ry = top + 12 + row * 30;
    g.fillStyle = '#100e16'; g.fillRect(x + 4, ry, w - 8, 20);
    g.fillStyle = '#2a2833'; g.fillRect(x + 4, ry + 17, w - 8, 3);
    for (let k = 0; k < 3; k++) if (R() < 0.55) {
      const cx = x + 12 + k * ((w - 24) / 3);
      g.fillStyle = pick2(R, ['#5a2a30', '#2a3a5a', '#3a3a42']); g.fillRect(cx, ry + 9, 20, 7);
      g.fillStyle = 'rgba(0,0,0,0.5)'; g.fillRect(cx + 3, ry + 5, 13, 5);
    }
    g.fillStyle = '#6a6a78'; g.fillRect(x + 4, ry + 20, w - 8, 2);      // deck edge
    g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(x + 4, ry + 20, w - 8, 1);
    if (R() < 0.7) { g.fillStyle = '#d8f0ff'; g.fillRect(x + 10 + R() * (w - 30), ry + 1, 12, 2);
      g.fillStyle = 'rgba(200,240,255,0.10)'; g.fillRect(x + 6, ry + 3, w - 12, 12); }
  }
  // the mouth: a ramp, a striped barrier and a booth
  const mx = x + w * 0.24, mw = w * 0.5;
  g.fillStyle = '#0c0a12'; g.fillRect(mx, GROUND - 40, mw, 40);
  g.fillStyle = '#16141e'; g.fillRect(mx + 3, GROUND - 37, mw - 6, 37);
  g.fillStyle = 'rgba(255,220,120,0.10)'; g.fillRect(mx + 3, GROUND - 24, mw - 6, 24);
  for (let k = 0; k < mw; k += 12) { g.fillStyle = (k / 12) % 2 ? '#e8b020' : '#1a1a1e'; g.fillRect(mx + k, GROUND - 43, 12, 4); }
  g.fillStyle = '#2a2a34'; g.fillRect(mx - 14, GROUND - 26, 13, 26);    // booth
  g.fillStyle = '#e8d070'; g.fillRect(mx - 12, GROUND - 22, 9, 9);
  g.fillStyle = '#c8302a'; g.fillRect(mx + mw + 2, GROUND - 20, 3, 20); // barrier post
  for (let k = 0; k < 22; k += 6) { g.fillStyle = (k / 6) % 2 ? '#e8e8e8' : '#c8302a'; g.fillRect(mx + mw + 5, GROUND - 18 + 0, 6, 3); }
  const price = '$' + (2 + Math.floor(R() * 8)) + '.00';
  g.fillStyle = '#12101a'; g.fillRect(x + w * 0.05, GROUND - 60, 46, 16);
  ptext(g, 'PARK', x + w * 0.05 + 4, GROUND - 58, '#e8e8f0');
  ptext(g, price, x + w * 0.05 + 4, GROUND - 50, '#f2c94c');
}

function bldgVacantLot(g, x, w, R) {
  // sky and the backs of the buildings behind - a hole in the block
  g.fillStyle = 'rgba(0,0,0,0)'; g.clearRect(x, 0, w, GROUND - 46);
  g.fillStyle = '#1a1630';
  for (let bx = x; bx < x + w; bx += 22 + R() * 18) {
    const bh = 40 + R() * 50; g.fillRect(bx, GROUND - 46 - bh, 16 + R() * 20, bh + 46);
  }
  for (let k = 0; k < 40; k++) { g.fillStyle = R() < 0.6 ? '#d8b050' : '#6aa0e0'; g.fillRect(x + R() * w, GROUND - 90 + R() * 44, 1, 1); }
  // the party wall of the surviving neighbour, with the ghost of stairs on it
  g.fillStyle = '#3a2e34'; g.fillRect(x + w - 10, 20, 10, GROUND - 20);
  g.fillStyle = 'rgba(255,255,255,0.05)';
  for (let k = 0; k < 6; k++) g.fillRect(x + w - 9, 40 + k * 16, 8, 9);
  // plywood hoarding, fly-posted
  g.fillStyle = '#6a5a44'; g.fillRect(x, GROUND - 46, w, 46);
  for (let k = 0; k < w; k += 15) { g.fillStyle = 'rgba(0,0,0,0.20)'; g.fillRect(x + k, GROUND - 46, 1, 46); }
  for (let k = 0; k < 5; k++) {
    const px_ = x + 4 + R() * (w - 26);
    g.save(); g.translate(px_, GROUND - 40 + R() * 16); g.rotate((R() - 0.5) * 0.18);
    g.fillStyle = pick2(R, ['#c8303a', '#2a5ac8', '#e8c030', '#2a8a5a', '#e8e8e8']);
    g.fillRect(0, 0, 15, 20);
    g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(2, 3, 11, 8);
    g.restore();
  }
  graffiti(g, x + 8, GROUND - 14, R, w - 20);
  g.fillStyle = '#2a3a22';                               // weeds through the gap
  for (let k = 0; k < 14; k++) { const wx = x + R() * w; g.fillRect(wx, GROUND - 4, 1, -3 - R() * 5); }
}

function bldgDiner(g, x, w, R) {
  const top = 46 + R() * 10;
  // low chrome-and-glass box, warm inside, the brightest thing on the block
  g.fillStyle = '#2a2e38'; g.fillRect(x, top, w, GROUND - top);
  g.fillStyle = '#c8ccd8'; g.fillRect(x, top, w, 5);
  g.fillStyle = '#8a90a0'; g.fillRect(x, top + 5, w, 2);
  for (let k = 0; k < w; k += 10) { g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(x + k, top + 1, 4, 3); }
  const band = top + 10;
  g.fillStyle = '#a02a36'; g.fillRect(x, band, w, 12);
  const name = pick2(R, ['MERCY DINER', 'ALL NITE', 'THE ANCHOR', 'CORNER CAFE']);
  neonText(g, name, x + w / 2 - tw(name) / 2, band + 3, '#ffe8c0');
  // the glass front: booths, a counter, backlit and full of people-shapes
  const gy = band + 16, gh = GROUND - gy - 4;
  g.fillStyle = '#16141c'; g.fillRect(x + 3, gy, w - 6, gh);
  g.fillStyle = '#e8c878'; g.fillRect(x + 5, gy + 2, w - 10, gh - 4);
  g.fillStyle = 'rgba(0,0,0,0.20)'; g.fillRect(x + 5, gy + gh * 0.6, w - 10, gh * 0.4);
  for (let k = 0; k < Math.floor(w / 26); k++) {
    const bx = x + 10 + k * 26;
    g.fillStyle = '#8a3a3a'; g.fillRect(bx, gy + gh * 0.34, 7, gh * 0.5);      // booth back
    if (R() < 0.7) { g.fillStyle = 'rgba(0,0,0,0.55)';                          // a customer
      g.fillRect(bx + 9, gy + gh * 0.42, 5, gh * 0.4);
      g.beginPath(); g.arc(bx + 11.5, gy + gh * 0.40, 2.6, 0, 7); g.fill(); }
  }
  g.fillStyle = 'rgba(255,255,255,0.18)'; g.fillRect(x + 8, gy + 2, 5, gh - 4);
  for (let k = 0; k < w; k += 18) { g.fillStyle = '#4a4e5a'; g.fillRect(x + k, gy, 2, gh); }
  // a neon COFFEE cup on the roof and stools at the window
  const cx = x + w * 0.8;
  neonText(g, 'OPEN', x + 8, top - 10, '#4ae8ff');
  g.fillStyle = '#12101a'; g.fillRect(cx - 12, top - 26, 26, 22);
  neonText(g, 'EAT', cx - 8, top - 20, '#ffe04a');
}

const STREET_BUILDINGS = [
  { f: bldgBrownstone, w: [118, 160] }, { f: bldgBodega, w: [104, 140] },
  { f: bldgTheatre, w: [150, 200] },    { f: bldgTenement, w: [132, 186] },
  { f: bldgGarage, w: [126, 168] },     { f: bldgVacantLot, w: [86, 120] },
  { f: bldgDiner, w: [116, 150] },
];
// Walk a block choosing buildings without repeating the last two, so the
// street never reads as one template stamped over and over.
function blockRun(g, from, to, R, r, pool = STREET_BUILDINGS) {
  let x = from; const recent = [];
  while (x < to) {
    let pick, guard = 0;
    do { pick = Math.floor(R() * pool.length); } while (recent.includes(pick) && guard++ < 12);
    recent.push(pick); if (recent.length > 2) recent.shift();
    const b = pool[pick], w = Math.min(r(b.w[0], b.w[1]), to - x + 40);
    b.f(g, x, w, R);
    x += w;
  }
}
