// ============================================================ STAGE 7 shared
// The lab under the works. Contract for every option in this file:
//   * nothing meaningful above y=34 - the HUD sits there
//   * the floor starts at y<=150 and NOTHING solid is painted in 150..230,
//     which is the band the fighters walk through
// The Vault carries a falling hazard, so all three C options need honest
// structure overhead; A and B carry trailing-cable hazards, so a cable run
// that has been torn open belongs somewhere in each of those.
const LAB_TOP = 148;                 // where every lab floor begins

// ---- surfaces ------------------------------------------------------------
// A glossy epoxy floor: flat colour, a bay grid, and a sheen that catches
// whatever is glowing above it. The sheen is what sells "clean room".
function epoxyFloor(n, L, R, r, top, base, seam, sheen) {
  const w = L.near.width;
  const g = n.createLinearGradient(0, top, 0, 240);
  g.addColorStop(0, sheen); g.addColorStop(0.35, base); g.addColorStop(1, base);
  n.fillStyle = g; n.fillRect(0, top, w, 240 - top);
  for (let x = 0; x < w; x += 58) { n.fillStyle = seam; n.fillRect(x, top, 1, 240 - top); }
  for (let y = top + 18; y < 240; y += 26) { n.fillStyle = seam; n.fillRect(0, y, w, 1); }
  for (let k = 0; k < w * 0.5; k++) {                      // scuffs, so it is not a flat wash
    n.fillStyle = R() < 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.07)';
    n.fillRect(r(0, w), r(top + 3, 240), 5 + R() * 14, 1);
  }
}
// A raised access floor instead: square panels with lifting slots.
function tileFloor(n, L, R, r, top, base, hi, lo, pitch = 34) {
  const w = L.near.width;
  n.fillStyle = base; n.fillRect(0, top, w, 240 - top);
  for (let y = top, row = 0; y < 240; y += pitch, row++) {
    for (let x = -((row % 2) * pitch / 2); x < w; x += pitch) {
      n.fillStyle = (row + Math.round(x / pitch)) % 2 ? hi : lo;
      n.fillRect(x + 1, y + 1, pitch - 2, pitch - 2);
      n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x + pitch / 2 - 3, y + 3, 6, 1);
    }
  }
  n.fillStyle = 'rgba(0,0,0,0.18)'; n.fillRect(0, top, w, 2);
}
// A gasketed wall panel run - the modular sandwich panel every clean room is
// built out of. Vertical seams with a bright bead of sealant down each one.
function panelWall(g, x, y, w, h, R, col, hi, seam, pitch = 44) {
  g.fillStyle = col; g.fillRect(x, y, w, h);
  for (let px = x; px < x + w; px += pitch) {
    g.fillStyle = seam; g.fillRect(px, y, 2, h);
    g.fillStyle = hi; g.fillRect(px + 2, y, 1, h);
  }
  g.fillStyle = hi; g.fillRect(x, y, w, 2);                    // coving at the top
  g.fillStyle = 'rgba(0,0,0,0.22)'; g.fillRect(x, y + h - 4, w, 4);
  for (let k = 0; k < w * 0.06; k++) {                          // grime along the skirting
    g.fillStyle = 'rgba(0,0,0,0.10)'; g.fillRect(x + R() * w, y + h - 12 - R() * 10, 8 + R() * 16, 2);
  }
}
// Yellow-and-black hazard banding.
function hazardBand(g, x, y, w, h, a = '#e8c040', b = '#181410') {
  g.fillStyle = b; g.fillRect(x, y, w, h);
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
  g.strokeStyle = a; g.lineWidth = 4;
  for (let k = -h; k < w + h; k += 10) { g.beginPath(); g.moveTo(x + k, y + h); g.lineTo(x + k + h, y); g.stroke(); }
  g.restore();
}
// A ceiling light strip with a real housing, repeated down the run.
function lightStrip(n, L, y, col, glow, period = 96, lit = 1) {
  const w = L.near.width;
  for (let x = 20; x < w; x += period) {
    n.fillStyle = '#2a3038'; n.fillRect(x, y, 66, 7);
    n.fillStyle = '#3a4450'; n.fillRect(x, y, 66, 2);
    const on = ((x / period) | 0) % 9 !== 7;                    // one tube in nine is dead
    n.fillStyle = on ? col : '#2e3440'; n.fillRect(x + 3, y + 4, 60, 4);
    if (on) {
      n.save(); n.shadowColor = col; n.shadowBlur = 10; n.fillStyle = col;
      n.fillRect(x + 3, y + 5, 60, 2); n.restore();
      const gr = n.createLinearGradient(0, y + 8, 0, y + 8 + 48 * lit);
      gr.addColorStop(0, glow); gr.addColorStop(1, 'rgba(0,0,0,0)');
      n.fillStyle = gr; n.fillRect(x - 14, y + 8, 94, 48 * lit);
    }
  }
}
// A cable tray - the hazard's alibi. Every so often a span has been torn open
// and the looms hang out of it.
function cableTray(n, L, R, y, col = '#39414e', torn = true) {
  const w = L.near.width;
  n.fillStyle = col; n.fillRect(0, y, w, 6);
  n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(0, y, w, 1);
  n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(0, y + 5, w, 2);
  for (let x = 0; x < w; x += 24) { n.fillStyle = '#20252c'; n.fillRect(x, y - 3, 3, 4); }
  const cols = ['#b03a3a', '#3a6ab0', '#c8b040', '#3a9a6a', '#8a8a96'];
  for (let x = 0; x < w; x += 3) {                              // the loom sitting in the tray
    n.fillStyle = cols[(x / 3 | 0) % 5]; n.fillRect(x, y - 3 + ((x / 3 | 0) % 3), 3, 2);
  }
  if (!torn) return;
  for (let x = 120; x < w; x += 340) {                          // a burst span, cables swinging
    n.fillStyle = '#12161c'; n.fillRect(x - 6, y - 5, 44, 12);
    for (let k = 0; k < 5; k++) {
      const c = cols[k % 5], hx = x + 2 + k * 8, drop = 16 + (k % 3) * 11;
      n.strokeStyle = c; n.lineWidth = 2;
      n.beginPath(); n.moveTo(hx, y + 4);
      n.quadraticCurveTo(hx + 4, y + drop * 0.7, hx - 3 + k, y + drop); n.stroke();
      n.fillStyle = '#e8e0b0'; n.fillRect(hx - 4 + k, y + drop, 2, 2);
    }
    n.fillStyle = 'rgba(180,220,255,0.10)'; n.fillRect(x - 12, y, 60, 34);
  }
}
// A pressure door with interlock lights: the punctuation of a corridor.
function bulkhead(g, x, y, w, h, R, col, hi, lit = '#5ad06a', label = '') {
  g.fillStyle = '#12161c'; g.fillRect(x - 5, y - 4, w + 10, h + 4);
  g.fillStyle = col; g.fillRect(x, y, w, h);
  g.fillStyle = hi; g.fillRect(x, y, w, 3); g.fillRect(x, y, 3, h);
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x + w - 4, y, 4, h);
  g.fillStyle = '#12161c'; g.fillRect(x + w / 2 - 1, y, 2, h);  // the split
  g.strokeStyle = hi; g.lineWidth = 2;
  g.beginPath(); g.arc(x + w / 2, y + h * 0.42, Math.min(w, h) * 0.26, 0, 7); g.stroke();
  hazardBand(g, x, y + h - 9, w, 9);
  g.save(); g.shadowColor = lit; g.shadowBlur = 7;
  g.fillStyle = lit; g.fillRect(x + 6, y + 7, 5, 5); g.fillRect(x + w - 11, y + 7, 5, 5);
  g.restore();
  if (label) ptext(g, label, x + w / 2 - tw(label) / 2, y + 16, 'rgba(210,230,245,0.65)');
}
// A window into the next room, with whatever is behind it already drawn.
function viewPane(g, x, y, w, h, tint, frame = '#2a323c') {
  g.fillStyle = frame; g.fillRect(x - 3, y - 3, w + 6, h + 6);
  g.fillStyle = tint; g.fillRect(x, y, w, h);
  g.fillStyle = 'rgba(255,255,255,0.10)';
  g.beginPath(); g.moveTo(x, y + h); g.lineTo(x + w * 0.45, y); g.lineTo(x + w * 0.62, y); g.lineTo(x + w * 0.16, y + h); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.16)'; g.fillRect(x, y, w, 1);
}
// A tall tank of fluid with something suspended in it.
function tank(g, x, y, w, h, R, fluid, glow, opts = {}) {
  g.fillStyle = '#1a2028'; g.fillRect(x - 4, y - 6, w + 8, 8);       // top collar
  g.fillStyle = '#242c36'; g.fillRect(x - 5, y + h, w + 10, 10);     // base
  g.fillStyle = '#323c48'; g.fillRect(x - 5, y + h, w + 10, 2);
  const gr = g.createLinearGradient(x, y, x, y + h);
  gr.addColorStop(0, glow); gr.addColorStop(0.5, fluid); gr.addColorStop(1, '#0b1410');
  g.fillStyle = gr; g.fillRect(x, y, w, h);
  if (opts.body !== false) {                                          // the silhouette inside
    const cx = x + w / 2, cy = y + h * 0.5;
    g.fillStyle = 'rgba(8,16,14,0.62)';
    g.beginPath(); g.ellipse(cx, cy - h * 0.17, w * 0.17, h * 0.075, 0, 0, 7); g.fill();
    g.fillRect(cx - w * 0.17, cy - h * 0.10, w * 0.34, h * 0.26);
    g.beginPath(); g.moveTo(cx - w * 0.17, cy + h * 0.16); g.lineTo(cx - w * 0.09, cy + h * 0.34);
    g.lineTo(cx + w * 0.09, cy + h * 0.34); g.lineTo(cx + w * 0.17, cy + h * 0.16); g.fill();
    g.fillRect(cx - w * 0.30, cy - h * 0.07, w * 0.13, h * 0.24);
    g.fillRect(cx + w * 0.17, cy - h * 0.07, w * 0.13, h * 0.24);
  }
  for (let k = 0; k < h * 0.5; k++) {                                 // bubbles caught in the glass
    g.fillStyle = 'rgba(220,255,240,0.18)';
    g.fillRect(x + 2 + R() * (w - 4), y + 4 + R() * (h - 8), 1, 1 + (R() < 0.3 ? 1 : 0));
  }
  g.fillStyle = 'rgba(255,255,255,0.13)'; g.fillRect(x + 4, y + 4, 4, h - 10);   // glass highlight
  g.fillStyle = 'rgba(255,255,255,0.05)'; g.fillRect(x + w - 8, y + 6, 2, h - 14);
  g.strokeStyle = '#2e3a44'; g.lineWidth = 2;
  for (let k = 1; k < 4; k++) { g.beginPath(); g.moveTo(x - 4, y + h * k / 4); g.lineTo(x + w + 4, y + h * k / 4); g.stroke(); }
  g.save(); g.shadowColor = glow; g.shadowBlur = 14; g.fillStyle = glow;
  g.fillRect(x + 2, y + h - 6, w - 4, 3); g.restore();
  if (opts.label) ptext(g, opts.label, x + w / 2 - tw(opts.label) / 2, y + h + 2, 'rgba(200,230,215,0.55)');
}
// A rack of blinking gear. Deterministic LEDs so a still frame still reads.
function rack(g, x, y, w, h, R, col = '#1a1e26', led = '#5ad06a') {
  g.fillStyle = '#10141a'; g.fillRect(x - 2, y - 2, w + 4, h + 4);
  g.fillStyle = col; g.fillRect(x, y, w, h);
  for (let ry = y + 3; ry < y + h - 4; ry += 7) {
    g.fillStyle = 'rgba(255,255,255,0.05)'; g.fillRect(x + 2, ry, w - 4, 5);
    g.fillStyle = 'rgba(0,0,0,0.40)'; g.fillRect(x + 2, ry + 5, w - 4, 1);
    for (let k = 0; k < 4; k++) {
      const on = ((ry * 7 + k * 13 + Math.round(x)) % 5) < 3;
      g.fillStyle = on ? (k === 3 ? '#e8a030' : led) : 'rgba(255,255,255,0.08)';
      g.fillRect(x + 4 + k * 4, ry + 2, 2, 2);
    }
  }
  g.save(); g.shadowColor = led; g.shadowBlur = 9; g.fillStyle = led;
  g.fillRect(x + 3, y + 3, 2, 2); g.restore();
}
// Overhead structure: a coffered slab with services hung under it. Reads as
// weight above the fight without stealing contrast from the sprites.
function ceilingSlab(n, L, y, d, col, hi, shade) {
  const w = L.near.width;
  n.fillStyle = col; n.fillRect(0, y, w, d);
  n.fillStyle = hi; n.fillRect(0, y, w, 2);
  n.fillStyle = shade; n.fillRect(0, y + d - 3, w, 3);
  for (let x = 0; x < w; x += 72) { n.fillStyle = shade; n.fillRect(x, y, 5, d); }
  for (let x = 30; x < w; x += 72) { n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(x, y + 3, 28, d - 8); }
}
// Insulated duct running the length of a ceiling.
function ductRun(n, L, y, h, col, hi) {
  const w = L.near.width;
  n.fillStyle = col; n.fillRect(0, y, w, h);
  n.fillStyle = hi; n.fillRect(0, y, w, 2);
  n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(0, y + h - 3, w, 3);
  for (let x = 0; x < w; x += 56) {
    n.fillStyle = hi; n.fillRect(x, y - 2, 4, h + 4);
    n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x + 4, y, 2, h);
  }
}
// A soft pool of light thrown onto the floor by something above it.
function floorGlow(n, L, x, top, w, col) {
  const g = n.createLinearGradient(0, top, 0, 240);
  g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)');
  n.save(); n.globalCompositeOperation = 'lighter'; n.fillStyle = g;
  n.beginPath(); n.moveTo(x - w * 0.3, top); n.lineTo(x + w * 0.3, top);
  n.lineTo(x + w * 0.62, 240); n.lineTo(x - w * 0.62, 240); n.fill();
  n.restore();
}
// Stencilled floor marking - a walkway lane or a keep-clear box. Paint only,
// so it never reads as something you would trip over.
function floorMark(n, x, y, w, h, col, label) {
  n.strokeStyle = col; n.lineWidth = 2; n.strokeRect(x, y, w, h);
  if (label) ptext(n, label, x + 6, y + 5, col);
}
