// ============================================================ 8-C  THE HELIPAD
// The last scene in the game. Dray fights here and then something worse stands
// up in his suit, so all four options put an unmistakable arena at the far end
// with room around it, and the drop has to read as eighty floors.

// ---- C1  The Helipad ------------------------------------------------------
// The name done properly: dusk, the city a long way down, the aircraft sitting
// on the pad with its rotors still turning because he was about to leave.
function s8c_pad(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  duskSky(f, L, R, r, [[0, '#0a0828'], [0.42, '#5a2a68'], [0.76, '#e06a4a'], [1, '#ffc068']]);
  cityBelow(f, L, R, r, 150);
  // mid: neighbouring towers standing out of the haze, and the masts
  for (let x = 0; x < WM; x += 118) {
    const th = 46 + ((x * 19) % 58), tw2 = 26 + ((x * 7) % 16);
    m.fillStyle = 'rgba(22,16,34,0.92)'; m.fillRect(x, 150 - th, tw2, th + 20);
    m.fillStyle = 'rgba(34,24,50,0.9)'; m.fillRect(x, 150 - th, 5, th + 20);
    for (let k = 0; k < th * 1.6; k++) {
      m.fillStyle = R() < 0.6 ? 'rgba(242,208,112,0.75)' : 'rgba(122,184,240,0.68)';
      m.fillRect(x + 2 + R() * (tw2 - 3), 152 - th + R() * (th - 4), 1, 1);
    }
    for (let y = 154 - th; y < 150; y += 9) {                     // a lit floor band every so often
      if (((y * 7 + x) % 4)) continue;
      m.fillStyle = 'rgba(255,224,150,0.22)'; m.fillRect(x + 1, y, tw2 - 2, 2);
    }
    m.fillStyle = 'rgba(232,58,58,0.75)'; m.fillRect(x + tw2 / 2 - 1, 150 - th - 4, 2, 3);
  }
  for (let x = 40; x < WM; x += 300) mast(m, x, 44, 150, '#16121e');
  const LNear = { near: { width: W2 } };
  // near: the drop first, seen over the parapet, then the deck in front of it
  dropStrip(n, LNear, R, r, 112, 30, 1.8);
  deckFloor(n, LNear, R, r, DECK8, '#37344a', '#43405a', 'rgba(0,0,0,0.26)', 40);
  n.fillStyle = '#413d55'; n.fillRect(0, DECK8 - 10, W2, 10);     // the parapet along the back
  n.fillStyle = '#5b5674'; n.fillRect(0, DECK8 - 10, W2, 2);
  n.fillStyle = 'rgba(0,0,0,0.32)'; n.fillRect(0, DECK8 - 2, W2, 4);
  for (let x = 0; x < W2; x += 96) { n.fillStyle = '#4e4a66'; n.fillRect(x, DECK8 - 12, 12, 12); }
  for (let x = 60; x < W2 - 520; x += 250) {                      // plant standing on the deck
    plantBox(n, x, 96, 62, 44, R, r);
    plantBox(n, x + 74, 110, 34, 30, R, r, '#232029', '#3a3644');
    for (let k = 0; k < 3; k++) { n.fillStyle = '#2a2732'; n.fillRect(x + 118 + k * 10, 116 - k * 4, 6, 24 + k * 4); }
  }
  for (let x = 130; x < W2 - 460; x += 250) {                     // a stair head and a hose reel
    n.fillStyle = '#26232f'; n.fillRect(x, 106, 46, 34);
    n.fillStyle = '#343040'; n.fillRect(x, 106, 46, 3);
    n.fillStyle = '#12101a'; n.fillRect(x + 10, 114, 24, 26);
    n.fillStyle = '#5ad06a'; n.fillRect(x + 36, 112, 4, 4);
    n.fillStyle = '#8a2a2a'; n.beginPath(); n.arc(x + 58, 126, 9, 0, 7); n.fill();
    n.fillStyle = '#b03a3a'; n.beginPath(); n.arc(x + 58, 126, 6, 0, 7); n.fill();
  }
  railing(n, 0, 114, W2, '#3e3a52', '#5a5470', 34);               // the perimeter rail, seen edge-on
  edgeLights(n, LNear, DECK8 - 14, '#ffdc60', 70);
  // the pad itself, at the far end: circle, H, and the aircraft on it
  const hx = len - 300;
  n.fillStyle = '#2e2b3e'; n.beginPath(); n.arc(hx, 196, 96, 0, 7); n.fill();
  n.fillStyle = 'rgba(255,255,255,0.03)'; n.beginPath(); n.arc(hx, 196, 96, 0, 7); n.fill();
  padMark(n, hx, 196, 62, '#e8e8f0', 5);
  for (let k = 0; k < 16; k++) {                                   // pad perimeter lights
    const a = k / 16 * 6.283, lx = hx + Math.cos(a) * 92, ly = 196 + Math.sin(a) * 46;
    if (ly < DECK8) continue;
    n.fillStyle = '#4ac0e8'; n.fillRect(lx, ly, 3, 2);
  }
  deckMarks(n, LNear, R, r, DECK8, hx);
  ptext(n, 'DH-1', hx - 82, 152, 'rgba(232,232,240,0.45)', 2);
  chopper(n, hx - 10, 110, R);
  L.rotor = { x: hx - 10, y: 110 }; L.padGlow = true; L.beaconC1 = true;
  return L;
}
// The aircraft: side-on, skids down, rotors turning. Drawn above the walkable
// band so it never blocks a fighter - the tail boom is what reads at this size.
function chopper(n, cx, cy, R) {
  n.fillStyle = 'rgba(0,0,0,0.30)'; n.beginPath(); n.ellipse(cx, DECK8 + 4, 78, 7, 0, 0, 7); n.fill();
  n.fillStyle = '#1e2a34'; n.beginPath();                         // tail boom
  n.moveTo(cx + 14, cy - 2); n.lineTo(cx + 92, cy + 2); n.lineTo(cx + 92, cy + 9); n.lineTo(cx + 14, cy + 14); n.fill();
  n.fillStyle = '#2c3d4c'; n.fillRect(cx + 14, cy - 2, 78, 3);
  n.fillStyle = '#1a252e'; n.beginPath();                         // tail fin
  n.moveTo(cx + 84, cy + 4); n.lineTo(cx + 100, cy - 16); n.lineTo(cx + 106, cy - 14); n.lineTo(cx + 96, cy + 8); n.fill();
  n.strokeStyle = 'rgba(200,220,235,0.25)'; n.lineWidth = 2;      // tail rotor, blurred
  n.beginPath(); n.arc(cx + 100, cy - 6, 11, 0, 7); n.stroke();
  n.fillStyle = '#24323e'; n.beginPath();                         // cabin
  n.moveTo(cx - 40, cy + 2); n.quadraticCurveTo(cx - 44, cy + 22, cx - 20, cy + 26);
  n.lineTo(cx + 18, cy + 22); n.lineTo(cx + 20, cy - 4); n.quadraticCurveTo(cx - 6, cy - 12, cx - 40, cy + 2); n.fill();
  n.fillStyle = '#35495a'; n.beginPath();
  n.moveTo(cx - 40, cy + 2); n.quadraticCurveTo(cx - 6, cy - 12, cx + 20, cy - 4); n.lineTo(cx + 20, cy - 1);
  n.quadraticCurveTo(cx - 6, cy - 9, cx - 39, cy + 5); n.fill();
  n.fillStyle = 'rgba(150,200,240,0.55)'; n.beginPath();          // glazing
  n.moveTo(cx - 38, cy + 4); n.quadraticCurveTo(cx - 40, cy + 18, cx - 22, cy + 21);
  n.lineTo(cx - 4, cy + 18); n.lineTo(cx - 6, cy + 1); n.fill();
  n.fillStyle = 'rgba(210,235,255,0.30)'; n.beginPath();
  n.moveTo(cx - 36, cy + 5); n.lineTo(cx - 22, cy + 18); n.lineTo(cx - 14, cy + 17); n.lineTo(cx - 30, cy + 3); n.fill();
  n.fillStyle = '#8a1a2a'; n.fillRect(cx - 2, cy + 6, 18, 5);      // the house colours
  n.fillStyle = '#f2c94c'; n.fillRect(cx - 2, cy + 11, 18, 2);
  n.fillStyle = '#1a252e'; n.fillRect(cx - 34, cy + 28, 5, 14); n.fillRect(cx + 6, cy + 28, 5, 14);   // skids
  n.fillStyle = '#26333e'; n.fillRect(cx - 42, cy + 40, 62, 4);
  n.fillStyle = '#16202a'; n.fillRect(cx - 12, cy - 10, 8, 10);    // rotor head
  n.fillStyle = '#2c3d4c'; n.fillRect(cx - 14, cy - 12, 12, 4);
}

// ---- C2  The Spire --------------------------------------------------------
// Not a flat roof: the crown of the building. A structural spire overhead and
// the pad cantilevered off the side of it with nothing underneath.
function s8c_spire(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  duskSky(f, L, R, r, [[0, '#07061e'], [0.4, '#2e1a52'], [0.72, '#8a3a5c'], [1, '#e08a5a']]);
  cityBelow(f, L, R, r, 158, 'rgba(90,70,130,0.40)');
  for (let x = 0; x < WM; x += 190) {                              // only the tallest neighbours reach up here
    const th = 22 + ((x * 13) % 30);
    m.fillStyle = 'rgba(18,13,30,0.9)'; m.fillRect(x, 158 - th, 22, th + 30);
    m.fillStyle = 'rgba(232,58,58,0.7)'; m.fillRect(x + 10, 158 - th - 4, 2, 3);
  }
  const LNear = { near: { width: W2 } };
  // near: the spire structure, a diagrid that runs the whole scene overhead
  n.fillStyle = '#100d1a'; n.fillRect(0, 34, W2, 8);
  for (let x = -40; x < W2; x += 78) {                             // the diagrid itself
    const tall = ((x / 78) | 0) % 3 === 1;                         // every third bay runs deeper
    const bot = tall ? 134 : 112;
    n.strokeStyle = '#2a2438'; n.lineWidth = 5;
    n.beginPath(); n.moveTo(x, 34); n.lineTo(x + 78, bot); n.stroke();
    n.beginPath(); n.moveTo(x + 78, 34); n.lineTo(x, bot); n.stroke();
    n.strokeStyle = '#3e3652'; n.lineWidth = 2;
    n.beginPath(); n.moveTo(x, 34); n.lineTo(x + 78, bot); n.stroke();
    n.fillStyle = '#332c46'; n.beginPath();                        // the cast node where they cross
    n.arc(x + 39, (34 + bot) / 2, 7, 0, 7); n.fill();
    n.fillStyle = '#463d5e'; n.beginPath(); n.arc(x + 39, (34 + bot) / 2, 4, 0, 7); n.fill();
  }
  for (const y of [44, 92, 132]) { n.fillStyle = '#241e34'; n.fillRect(0, y, W2, 5); n.fillStyle = '#382f4c'; n.fillRect(0, y, W2, 2); }
  dropStrip(n, LNear, R, r, 108, 16, 0.6);
  for (let x = 30; x < W2; x += 156) {                             // the spire's own lighting
    n.fillStyle = '#4ac0e8'; n.fillRect(x, 58, 4, 4);
    const g = n.createRadialGradient(x + 2, 60, 0, x + 2, 60, 44);
    g.addColorStop(0, 'rgba(74,192,232,0.22)'); g.addColorStop(1, 'rgba(74,192,232,0)');
    n.fillStyle = g; n.fillRect(x - 42, 18, 88, 88);
  }
  // the deck is a steel grating platform slung inside the structure
  n.fillStyle = '#2a2438'; n.fillRect(0, DECK8 - 8, W2, 8);
  n.fillStyle = '#3e3652'; n.fillRect(0, DECK8 - 8, W2, 2);
  n.fillStyle = '#242032'; n.fillRect(0, DECK8, W2, 240 - DECK8);
  for (let x = 0; x < W2; x += 7) { n.fillStyle = 'rgba(0,0,0,0.42)'; n.fillRect(x, DECK8, 3, 240 - DECK8); }
  for (let y = DECK8 + 10; y < 240; y += 22) { n.fillStyle = 'rgba(255,255,255,0.05)'; n.fillRect(0, y, W2, 2); }
  for (let k = 0; k < W2 * 0.35; k++) {                            // the city glittering up through the grating
    n.fillStyle = R() < 0.6 ? 'rgba(242,208,112,0.16)' : 'rgba(122,184,240,0.14)';
    n.fillRect(r(0, W2), r(DECK8 + 2, 238), 1, 1);
  }
  for (let x = 0; x < W2; x += 62) {                               // the cantilever brackets under it
    n.fillStyle = '#1a1626'; n.beginPath();
    n.moveTo(x, DECK8); n.lineTo(x + 20, DECK8); n.lineTo(x, DECK8 + 20); n.fill();
  }
  deckMarks(n, LNear, R, r, DECK8, len - 290, 'rgba(160,220,255,0.24)', 'rgba(74,192,232,0.26)');
  railing(n, 0, 116, W2, '#453e5c', '#635a80', 30);
  for (let x = 44; x < W2 - 460; x += 210) {                       // riser clusters bolted to the frame
    for (let k = 0; k < 4; k++) { n.fillStyle = ['#2e2a3e', '#38334a', '#262232', '#332e44'][k]; n.fillRect(x + k * 9, 96, 7, 42); }
    n.fillStyle = '#4a4360'; n.fillRect(x - 2, 104, 40, 3); n.fillRect(x - 2, 126, 40, 3);
    hazard8(n, x - 2, 90, 40, 6);
  }
  // the pad: a cantilevered disc off the far end, hanging over nothing
  const hx = len - 290;
  n.fillStyle = '#0a0812'; n.fillRect(hx - 118, DECK8 - 2, 236, 96);      // the void under it
  for (let k = 0; k < 180; k++) { n.fillStyle = 'rgba(242,208,112,0.18)'; n.fillRect(r(hx - 112, hx + 112), r(DECK8 + 6, 236), 1, 1); }
  n.fillStyle = '#1e1a2c'; n.beginPath(); n.ellipse(hx, 196, 112, 52, 0, 0, 7); n.fill();
  n.fillStyle = '#332d46'; n.beginPath(); n.ellipse(hx, 192, 110, 50, 0, 0, 7); n.fill();
  n.fillStyle = '#403a56'; n.beginPath(); n.ellipse(hx, 190, 108, 48, 0, 0, 7); n.fill();
  for (let k = 0; k < 26; k++) {                                          // the deck plates radiating out
    const a = k / 26 * 6.283;
    n.strokeStyle = 'rgba(0,0,0,0.20)'; n.lineWidth = 1;
    n.beginPath(); n.moveTo(hx, 190); n.lineTo(hx + Math.cos(a) * 108, 190 + Math.sin(a) * 48); n.stroke();
  }
  padMark(n, hx, 190, 66, '#e8e8f0', 5);
  for (let k = 0; k < 18; k++) {
    const a = k / 18 * 6.283, lx = hx + Math.cos(a) * 104, ly = 190 + Math.sin(a) * 46;
    n.fillStyle = '#4ac0e8'; n.fillRect(lx, ly, 3, 2);
    const g = n.createRadialGradient(lx, ly, 0, lx, ly, 12);
    g.addColorStop(0, 'rgba(74,192,232,0.30)'); g.addColorStop(1, 'rgba(74,192,232,0)');
    n.fillStyle = g; n.fillRect(lx - 12, ly - 12, 24, 24);
  }
  mast(n, hx - 5, 34, 118, '#1a1626', '#ff3a3a', 12);
  L.spireBlink = true; L.padGlow = true;
  return L;
}

// ---- C3  The Storm --------------------------------------------------------
// The weather turned, which is the whole reason he is still on the roof: his
// aircraft cannot lift. Rain sideways, the city lost in cloud, lightning
// behind the mast.
function s8c_storm(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  const sky = f.createLinearGradient(0, 0, 0, 180);
  sky.addColorStop(0, '#090b18'); sky.addColorStop(0.45, '#16203a');
  sky.addColorStop(0.78, '#2a3350'); sky.addColorStop(1, '#3d4460');
  f.fillStyle = sky; f.fillRect(0, 0, W1, H);
  for (let k = 0; k < W1 * 0.06; k++) {                            // the cloud base, torn and moving
    const y = r(34, 130), cw = r(70, 220);
    f.fillStyle = `rgba(20,26,46,${0.25 + R() * 0.35})`;
    f.beginPath(); f.ellipse(r(0, W1), y, cw, 7 + R() * 12, 0, 0, 7); f.fill();
  }
  for (let k = 0; k < W1 * 0.02; k++) {
    f.fillStyle = `rgba(120,140,190,${0.05 + R() * 0.07})`;
    f.beginPath(); f.ellipse(r(0, W1), r(40, 120), r(50, 150), 5 + R() * 8, 0, 0, 7); f.fill();
  }
  // the city is only visible where it burns through the cloud
  f.fillStyle = '#121828'; f.fillRect(0, 152, W1, 88);
  for (let k = 0; k < W1 * 0.30; k++) {
    f.fillStyle = R() < 0.6 ? 'rgba(232,190,110,0.28)' : 'rgba(120,170,230,0.24)';
    f.fillRect(r(0, W1), r(156, 236), 1, 1);
  }
  f.fillStyle = 'rgba(40,52,84,0.55)'; f.fillRect(0, 148, W1, 92);
  for (let x = 0; x < WM; x += 220) {                              // neighbours as grey ghosts
    const th = 34 + ((x * 17) % 40);
    m.fillStyle = 'rgba(26,34,56,0.55)'; m.fillRect(x, 152 - th, 26, th + 30);
    m.fillStyle = 'rgba(232,58,58,0.45)'; m.fillRect(x + 12, 152 - th - 4, 2, 3);
  }
  const LNear = { near: { width: W2 } };
  deckFloor(n, LNear, R, r, DECK8, '#2b2f3e', '#343948', 'rgba(0,0,0,0.30)', 40);
  n.fillStyle = 'rgba(120,150,200,0.10)'; n.fillRect(0, DECK8, W2, 240 - DECK8);   // standing water
  for (let k = 0; k < W2 * 0.6; k++) {                             // puddles catching the sky
    n.fillStyle = 'rgba(150,180,230,0.09)';
    n.beginPath(); n.ellipse(r(0, W2), r(DECK8 + 6, 236), 9 + R() * 26, 3 + R() * 4, 0, 0, 7); n.fill();
  }
  n.fillStyle = '#3e4356'; n.fillRect(0, DECK8 - 6, W2, 6);
  n.fillStyle = '#525872'; n.fillRect(0, DECK8 - 6, W2, 2);
  for (let x = 40; x < W2 - 480; x += 236) {                       // plant, streaming wet
    plantBox(n, x, 100, 66, 46, R, r, '#1d2028', '#2e323e');
    n.fillStyle = 'rgba(160,190,240,0.13)'; n.fillRect(x, 100, 66, 3);
    for (let k = 0; k < 6; k++) { n.fillStyle = 'rgba(180,210,250,0.20)'; n.fillRect(x + 6 + k * 10, 146, 1, 4); }
    plantBox(n, x + 80, 116, 40, 30, R, r, '#1d2028', '#2e323e');
  }
  for (let x = 20; x < W2; x += 128) {                             // a windsock standing straight out
    if (((x / 128) | 0) % 4) continue;
    n.fillStyle = '#2c303c'; n.fillRect(x, 84, 3, 62);
    n.fillStyle = '#e8681a'; n.beginPath();
    n.moveTo(x + 3, 86); n.lineTo(x + 40, 92); n.lineTo(x + 40, 100); n.lineTo(x + 3, 100); n.fill();
    n.fillStyle = '#f2f2f2'; n.beginPath();
    n.moveTo(x + 22, 89); n.lineTo(x + 31, 90.5); n.lineTo(x + 31, 100); n.lineTo(x + 22, 100); n.fill();
  }
  deckMarks(n, LNear, R, r, DECK8, len - 300, 'rgba(200,220,250,0.22)', 'rgba(255,176,64,0.20)');
  railing(n, 0, 116, W2, '#3a3f52', '#565d76', 26);
  edgeLights(n, LNear, DECK8 - 9, '#ffb040', 64);
  // the pad, streaming, lights fighting through it
  const hx = len - 300;
  n.fillStyle = '#262a38'; n.beginPath(); n.arc(hx, 196, 98, 0, 7); n.fill();
  padMark(n, hx, 196, 62, 'rgba(226,232,244,0.75)', 5);
  n.fillStyle = 'rgba(140,175,225,0.10)'; n.beginPath(); n.arc(hx, 196, 98, 0, 7); n.fill();
  for (let k = 0; k < 16; k++) {
    const a = k / 16 * 6.283, lx = hx + Math.cos(a) * 94, ly = 196 + Math.sin(a) * 46;
    if (ly < DECK8) continue;
    n.fillStyle = '#ffb040'; n.fillRect(lx, ly, 3, 2);
    const g = n.createRadialGradient(lx, ly, 0, lx, ly, 22);
    g.addColorStop(0, 'rgba(255,176,64,0.24)'); g.addColorStop(1, 'rgba(255,176,64,0)');
    n.fillStyle = g; n.fillRect(lx - 22, ly - 22, 44, 44);
  }
  // his aircraft, tied down and going nowhere - the reason the fight happens
  n.fillStyle = 'rgba(0,0,0,0.26)'; n.beginPath(); n.ellipse(hx - 4, DECK8 + 6, 74, 7, 0, 0, 7); n.fill();
  chopper(n, hx - 14, 116, R);
  for (let k = 0; k < 3; k++) {                                     // the tie-down strops
    n.strokeStyle = 'rgba(232,160,48,0.75)'; n.lineWidth = 2;
    n.beginPath(); n.moveTo(hx - 50 + k * 44, 142); n.lineTo(hx - 74 + k * 56, DECK8 - 2); n.stroke();
  }
  mast(n, 120, 34, 146, '#1a1e2a', '#ff3a3a', 12);
  L.rain = true; L.lightning = true;
  return L;
}

// ---- C4  The Topping Out --------------------------------------------------
// The wildcard, and the one that closes the circle: the crown of the tower is
// still bare steel. This is the same building you first climbed on stage 3,
// twenty floors higher and still not finished.
function s8c_steel(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  duskSky(f, L, R, r, [[0, '#0b0a26'], [0.4, '#4a2860'], [0.74, '#d0603e'], [1, '#ffb052']]);
  cityBelow(f, L, R, r, 154);
  for (let x = 0; x < WM; x += 150) {                               // neighbours
    const th = 40 + ((x * 23) % 46);
    m.fillStyle = 'rgba(20,14,32,0.9)'; m.fillRect(x, 154 - th, 26, th + 30);
    for (let k = 0; k < th * 0.4; k++) { m.fillStyle = 'rgba(242,208,112,0.45)'; m.fillRect(x + 2 + R() * 22, 156 - th + R() * (th - 4), 1, 1); }
    m.fillStyle = 'rgba(232,58,58,0.7)'; m.fillRect(x + 12, 154 - th - 4, 2, 3);
  }
  const LNear = { near: { width: W2 } };
  // near: the frame. Columns, beams, and open sky between them.
  n.fillStyle = '#5a4a2e'; n.fillRect(0, 44, W2, 7);                // the top chord, above everything
  n.fillStyle = '#7a6538'; n.fillRect(0, 44, W2, 2);
  n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(0, 49, W2, 2);
  for (let x = 0; x < W2; x += 116) {                               // columns down to the deck
    n.fillStyle = '#4a3c24'; n.fillRect(x, 44, 13, DECK8 - 44);
    n.fillStyle = '#6b5730'; n.fillRect(x + 1, 44, 4, DECK8 - 44);
    n.fillStyle = 'rgba(0,0,0,0.38)'; n.fillRect(x + 9, 44, 4, DECK8 - 44);
    for (let y = 58; y < DECK8; y += 22) {                          // bolted splice plates
      n.fillStyle = '#3a2f1c'; n.fillRect(x - 3, y, 19, 7);
      for (let k = 0; k < 3; k++) { n.fillStyle = '#8a7340'; n.fillRect(x - 1 + k * 6, y + 2, 2, 2); }
    }
    n.strokeStyle = '#4a3c24'; n.lineWidth = 5;                     // cross bracing between them
    n.beginPath(); n.moveTo(x + 13, 62); n.lineTo(x + 116, 120); n.stroke();
    n.strokeStyle = '#61502c'; n.lineWidth = 2;
    n.beginPath(); n.moveTo(x + 13, 62); n.lineTo(x + 116, 120); n.stroke();
  }
  n.fillStyle = '#4a3c24'; n.fillRect(0, 96, W2, 6);                // an intermediate beam
  n.fillStyle = '#6b5730'; n.fillRect(0, 96, W2, 2);
  for (let x = 30; x < W2; x += 186) {                              // tarps lashed to the frame, snapping
    const flap = ((x * 7) % 11) - 5;
    n.fillStyle = 'rgba(126,134,150,0.60)'; n.beginPath();
    n.moveTo(x, 52); n.lineTo(x + 54, 56); n.lineTo(x + 48 + flap, 112); n.lineTo(x - 6, 104); n.fill();
    for (let k = 0; k < 5; k++) {                                   // folds, so it hangs instead of sitting flat
      const fx = x + 4 + k * 11;
      n.fillStyle = k % 2 ? 'rgba(176,184,198,0.30)' : 'rgba(84,90,104,0.34)';
      n.beginPath(); n.moveTo(fx, 53 + k); n.lineTo(fx + 7, 54 + k);
      n.lineTo(fx + 6 + flap * 0.4, 110 - k * 2); n.lineTo(fx - 1 + flap * 0.4, 108 - k * 2); n.fill();
    }
    n.fillStyle = 'rgba(214,220,232,0.26)'; n.beginPath();
    n.moveTo(x, 52); n.lineTo(x + 54, 56); n.lineTo(x + 52, 66); n.lineTo(x - 2, 62); n.fill();
    n.strokeStyle = 'rgba(232,160,48,0.55)'; n.lineWidth = 1.5;     // the rope holding it on
    n.beginPath(); n.moveTo(x - 6, 96); n.quadraticCurveTo(x + 24, 104, x + 50 + flap, 98); n.stroke();
    for (let k = 0; k < 3; k++) { n.fillStyle = '#e8a030'; n.fillRect(x + k * 24, 50, 4, 5); }
  }
  for (let x = 90; x < W2 - 460; x += 186) {                        // the materials still up here
    n.fillStyle = '#3a3024'; n.fillRect(x, 124, 54, 22);
    for (let k = 0; k < 4; k++) { n.fillStyle = k % 2 ? '#4e4030' : '#2e261c'; n.fillRect(x + 2, 126 + k * 5, 50, 4); }
    n.fillStyle = '#2a2c34'; n.beginPath(); n.arc(x + 74, 136, 11, 0, 7); n.fill();   // a cable drum
    n.fillStyle = '#3e424e'; n.beginPath(); n.arc(x + 74, 136, 8, 0, 7); n.fill();
    n.fillStyle = '#e8a030'; n.fillRect(x + 92, 128, 12, 18);                          // a cone
  }
  // string lighting slung along the frame - the only light up here
  for (let x = 0; x < W2; x += 116) {
    n.strokeStyle = '#2a2418'; n.lineWidth = 1;
    n.beginPath(); n.moveTo(x + 6, 54); n.quadraticCurveTo(x + 62, 74, x + 122, 54); n.stroke();
    for (let k = 1; k < 5; k++) {
      const lx = x + 6 + k * 23, ly = 54 + Math.sin(k / 5 * 3.14) * 19;
      n.fillStyle = '#ffd88a'; n.fillRect(lx, ly, 3, 3);
      const g = n.createRadialGradient(lx + 1, ly + 1, 0, lx + 1, ly + 1, 22);
      g.addColorStop(0, 'rgba(255,216,138,0.24)'); g.addColorStop(1, 'rgba(255,216,138,0)');
      n.fillStyle = g; n.fillRect(lx - 21, ly - 21, 44, 44);
    }
  }
  // the deck: metal decking laid over the beams, not finished
  n.fillStyle = '#3c3a44'; n.fillRect(0, DECK8 - 7, W2, 7);
  n.fillStyle = '#4e4b58'; n.fillRect(0, DECK8 - 7, W2, 2);
  n.fillStyle = '#33313c'; n.fillRect(0, DECK8, W2, 240 - DECK8);
  for (let x = 0; x < W2; x += 13) {                                // the profile of the decking
    n.fillStyle = '#3b3946'; n.fillRect(x, DECK8, 7, 240 - DECK8);
    n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x + 7, DECK8, 2, 240 - DECK8);
  }
  for (let k = 0; k < W2 * 0.5; k++) {
    n.fillStyle = R() < 0.5 ? 'rgba(196,120,50,0.12)' : 'rgba(0,0,0,0.12)';
    n.fillRect(r(0, W2), r(DECK8, 240), 5 + R() * 13, 1);
  }
  hazard8(n, 0, DECK8 - 12, W2, 5);
  deckMarks(n, LNear, R, r, DECK8, len - 290, 'rgba(240,226,190,0.22)', 'rgba(232,160,48,0.26)');
  // the crane, standing over the far end, with the pad decked out under it
  const hx = len - 290;
  n.fillStyle = '#0a0812'; n.fillRect(hx - 116, DECK8 - 2, 232, 96);
  for (let k = 0; k < 150; k++) { n.fillStyle = 'rgba(242,208,112,0.16)'; n.fillRect(r(hx - 110, hx + 110), r(DECK8 + 6, 236), 1, 1); }
  n.fillStyle = '#3e3b48'; n.beginPath(); n.ellipse(hx, 194, 110, 50, 0, 0, 7); n.fill();
  n.fillStyle = '#474351'; n.beginPath(); n.ellipse(hx, 192, 108, 48, 0, 0, 7); n.fill();
  for (let x = hx - 108; x < hx + 108; x += 13) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(x, 146, 3, 94); }
  padMark(n, hx, 192, 64, '#e8e8f0', 5);
  hazard8(n, hx - 112, 140, 224, 5);
  // the crane mast and jib, coming down through the whole frame
  n.fillStyle = '#8a6a1e'; n.fillRect(hx - 22, 34, 6, 112); n.fillRect(hx + 16, 34, 6, 112);
  for (let y = 40; y < 146; y += 16) {
    n.fillStyle = '#8a6a1e'; n.fillRect(hx - 22, y, 44, 3);
    n.strokeStyle = '#6e541a'; n.lineWidth = 2;
    n.beginPath(); n.moveTo(hx - 20, y + 16); n.lineTo(hx + 20, y); n.stroke();
  }
  n.fillStyle = '#e8a030'; n.fillRect(hx - 190, 56, 300, 5);        // the jib, right across the top
  for (let x = hx - 188; x < hx + 108; x += 22) {
    n.strokeStyle = '#c8861e'; n.lineWidth = 2;
    n.beginPath(); n.moveTo(x, 61); n.lineTo(x + 11, 48); n.lineTo(x + 22, 61); n.stroke();
  }
  n.fillStyle = '#c8861e'; n.fillRect(hx - 190, 44, 300, 3);
  n.strokeStyle = '#8a8a96'; n.lineWidth = 2;                       // the hook block, hanging
  n.beginPath(); n.moveTo(hx - 96, 61); n.lineTo(hx - 96, 118); n.stroke();
  n.fillStyle = '#4a4650'; n.fillRect(hx - 104, 118, 17, 15);
  n.fillStyle = '#5e5a68'; n.fillRect(hx - 104, 118, 17, 3);
  n.save(); n.shadowColor = '#ff3a3a'; n.shadowBlur = 8; n.fillStyle = '#ff3a3a';
  n.fillRect(hx - 4, 36, 5, 5); n.restore();
  L.craneSway = true; L.steelGlint = true;
  return L;
}
