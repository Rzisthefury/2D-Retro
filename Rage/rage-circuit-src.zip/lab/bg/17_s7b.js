// ============================================================ 7-B options
// 1280 units, a trailing cable and an open pit. Something has to justify a
// hole in the floor in all four.

// ---- B1: THE SPECIMEN WING ------------------------------------------------
// The name taken literally: a two-storey gallery of person-sized capsules,
// numbered, with a service catwalk over the top and one of them burst open.
function s7b_wing(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#04090f'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 40) {                     // the gallery running away from you
    const g = f.createLinearGradient(0, 40, 0, 148);
    g.addColorStop(0, 'rgba(60,170,200,0.26)'); g.addColorStop(1, 'rgba(8,40,54,0.30)');
    f.fillStyle = g; f.fillRect(x + 6, 40, 26, 108);
    f.fillStyle = 'rgba(0,0,0,0.50)'; f.fillRect(x + 14, 66, 10, 54);
  }
  f.fillStyle = 'rgba(4,12,20,0.45)'; f.fillRect(0, 0, L.far.width, H);
  // mid: the upper storey, its capsules seen over the catwalk handrail
  m.fillStyle = '#071219'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 60) {
    tank(m, x + 14, 38, 26, 44, R, 'rgba(24,110,140,0.90)', 'rgba(140,232,250,0.90)', { body: R() < 0.75 });
  }
  m.fillStyle = '#101b24'; m.fillRect(0, 86, L.mid.width, 9);     // the upper deck slab
  m.fillStyle = '#243746'; m.fillRect(0, 86, L.mid.width, 2);
  for (let x = 0; x < L.mid.width; x += 22) { m.fillStyle = '#18242e'; m.fillRect(x, 78, 2, 8); }
  m.fillStyle = '#1d2c38'; m.fillRect(0, 76, L.mid.width, 3);
  m.fillStyle = '#0b141c'; m.fillRect(0, 95, L.mid.width, 53);
  m.fillStyle = 'rgba(6,16,24,0.22)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  // near: the catwalk overhead, then the capsules you walk between
  ceilingSlab(n, L, 34, 12, '#101922', '#1c2936', '#080d13');
  for (let x = 0; x < W2; x += 30) { n.fillStyle = '#18242e'; n.fillRect(x, 46, 4, 12); }
  n.fillStyle = '#141f29'; n.fillRect(0, 54, W2, 8);              // the service catwalk
  n.fillStyle = '#2b3f52'; n.fillRect(0, 54, W2, 2);
  for (let x = 0; x < W2; x += 6) { n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x, 56, 2, 6); }
  n.fillStyle = 'rgba(0,0,0,0.38)'; n.fillRect(0, 62, W2, 3);
  cableTray(n, L, R, 66, '#22303d', true);
  for (let x = 0; x < W2; x += 112) {                             // the capsule bank
    const num = 200 + (x / 112 | 0) * 3;
    const broken = (x / 112 | 0) % 5 === 3;
    n.fillStyle = '#060d13'; n.fillRect(x, 70, 104, 78);          // the recess each one sits in
    n.fillStyle = '#152633'; n.fillRect(x + 2, 70, 100, 3);
    if (!broken) {                                                 // tall and narrow: a person fits in it
      tank(n, x + 20, 76, 30, 68, R, 'rgba(22,126,162,0.94)', 'rgba(152,242,255,0.98)',
        { body: (x / 112 | 0) % 4 !== 1, label: String(num) });
      tank(n, x + 58, 76, 30, 68, R, 'rgba(22,126,162,0.94)', 'rgba(152,242,255,0.98)',
        { body: (x / 112 | 0) % 4 !== 2, label: String(num + 1) });
      floorGlow(n, L, x + 51, LAB_TOP, 84, 'rgba(110,220,246,0.16)');
    } else {                                                       // one has gone: glass out, fluid down the wall
      tank(n, x + 20, 76, 30, 68, R, 'rgba(22,126,162,0.94)', 'rgba(152,242,255,0.98)',
        { body: false, label: String(num) });
      n.fillStyle = '#040a0f'; n.fillRect(x + 58, 76, 30, 68);
      n.fillStyle = '#1a2b36'; n.fillRect(x + 54, 70, 38, 7);
      n.strokeStyle = '#a8e4f4'; n.lineWidth = 2;
      for (let k = 0; k < 8; k++) {
        n.beginPath(); n.moveTo(x + 73, 106);
        n.lineTo(x + 73 + Math.cos(k * 0.79) * 20, 106 + Math.sin(k * 0.79) * 36); n.stroke();
      }
      n.fillStyle = 'rgba(152,242,255,0.20)'; n.fillRect(x + 60, 126, 26, 18);
      n.fillStyle = 'rgba(152,242,255,0.13)'; n.fillRect(x + 48, 143, 52, 5);
      ptext(n, String(num + 1), x + 62, 148, 'rgba(232,40,58,0.85)');
      floorGlow(n, L, x + 73, LAB_TOP, 70, 'rgba(110,220,246,0.10)');
    }
    n.fillStyle = '#16232e'; n.fillRect(x + 104, 66, 8, 82);      // the pier between recesses
    n.fillStyle = '#2b4054'; n.fillRect(x + 104, 66, 3, 82);
  }
  for (let x = 330; x < W2 - 200; x += 620) {                     // a records station between banks
    n.fillStyle = '#0e1922'; n.fillRect(x, 92, 106, 56);
    n.fillStyle = '#17262f'; n.fillRect(x, 96, 106, 3);
    for (let k = 0; k < 3; k++) {
      n.fillStyle = '#040c10'; n.fillRect(x + 8 + k * 34, 102, 26, 20);
      n.fillStyle = 'rgba(120,224,246,0.50)'; n.fillRect(x + 10 + k * 34, 104, 22, 2);
      n.fillStyle = 'rgba(120,224,246,0.22)'; n.fillRect(x + 10 + k * 34, 109, 14, 2);
    }
    ptext(n, 'SUBJECT LOG', x + 10, 130, 'rgba(150,215,235,0.55)');
  }
  epoxyFloor(n, L, R, r, LAB_TOP, '#0d1720', 'rgba(60,150,180,0.20)', '#1c333f');
  for (let k = 0; k < W2 * 0.05; k++) {
    n.fillStyle = 'rgba(110,220,246,0.06)';
    n.beginPath(); n.ellipse(r(0, W2), r(LAB_TOP + 8, 232), 10 + R() * 24, 3 + R() * 5, 0, 0, 7); n.fill();
  }
  L.bubbles = 112; L.labHum = 1;
}

// ---- B2: THE GENE DECK ----------------------------------------------------
// A working wet lab rather than a menagerie: benches, hoods, centrifuges and a
// wall of somebody's working. Bright, busy, and the least supernatural option.
function s7b_gene(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const g0 = f.createLinearGradient(0, 34, 0, 150);
  g0.addColorStop(0, '#d8e0e2'); g0.addColorStop(1, '#9aa8ac');
  f.fillStyle = g0; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 110) {
    f.fillStyle = 'rgba(140,158,162,0.40)'; f.fillRect(x, 60, 86, 88);
    f.fillStyle = 'rgba(255,255,255,0.35)'; f.fillRect(x, 54, 96, 6);
  }
  // mid: the far bench run, with the whiteboard wall above it
  m.fillStyle = '#c3cdd0'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 210) {
    m.fillStyle = '#eef3f4'; m.fillRect(x + 12, 46, 168, 54);     // whiteboards, covered in working
    m.fillStyle = '#d4dcde'; m.fillRect(x + 12, 46, 168, 3);
    for (let k = 0; k < 16; k++) {
      m.fillStyle = k % 4 === 0 ? 'rgba(200,60,60,0.45)' : 'rgba(40,60,80,0.40)';
      m.fillRect(x + 20 + (k % 4) * 40, 54 + Math.floor(k / 4) * 11, 10 + (k * 7) % 26, 2);
    }
    m.fillStyle = '#9fa9ac'; m.fillRect(x, 104, 200, 44);         // the bench carcass
    m.fillStyle = '#b6c0c3'; m.fillRect(x, 104, 200, 3);
    for (let k = 0; k < 5; k++) { m.fillStyle = '#7d878a'; m.fillRect(x + 14 + k * 38, 110, 22, 30); }
  }
  m.fillStyle = 'rgba(190,205,210,0.30)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  ceilingSlab(n, L, 34, 13, '#c6d0d2', '#e4ecee', '#97a2a6');
  lightStrip(n, L, 50, '#ffffff', 'rgba(240,248,250,0.26)', 100);
  ductRun(n, L, 66, 10, '#b1bcbf', '#d6dedf');
  cableTray(n, L, R, 82, '#8d989c', true);
  for (let x = 0; x < W2; x += 148) {                             // fume hoods, sashes at different heights
    const sash = 18 + ((x / 148 | 0) % 3) * 9;
    n.fillStyle = '#aab4b7'; n.fillRect(x, 92, 96, 56);
    n.fillStyle = '#c6d0d2'; n.fillRect(x, 92, 96, 3);
    n.fillStyle = '#1b2427'; n.fillRect(x + 6, 98, 84, 44);
    n.fillStyle = 'rgba(200,240,255,0.16)'; n.fillRect(x + 6, 98, 84, sash);
    n.fillStyle = '#8f9a9e'; n.fillRect(x + 6, 98 + sash, 84, 4);
    for (let k = 0; k < 4; k++) {                                  // glassware inside
      n.fillStyle = ['#7fd6c0', '#e8c96a', '#d8899a', '#8fb8e8'][k];
      n.fillRect(x + 16 + k * 18, 124 + (k % 2) * 4, 8, 14);
      n.fillStyle = 'rgba(255,255,255,0.25)'; n.fillRect(x + 16 + k * 18, 124 + (k % 2) * 4, 3, 14);
    }
    n.save(); n.shadowColor = '#5ad06a'; n.shadowBlur = 6; n.fillStyle = '#5ad06a';
    n.fillRect(x + 84, 95, 4, 4); n.restore();
    ptext(n, 'HOOD ' + String(1 + (x / 148 | 0)), x + 8, 88, 'rgba(60,82,92,0.70)');
  }
  for (let x = 74; x < W2; x += 148) {                            // instruments between the hoods
    n.fillStyle = '#9ba5a9'; n.fillRect(x + 28, 116, 44, 32);
    n.fillStyle = '#b8c2c5'; n.fillRect(x + 28, 116, 44, 3);
    n.fillStyle = '#26313a'; n.fillRect(x + 34, 122, 20, 14);
    n.fillStyle = 'rgba(90,208,106,0.55)'; n.fillRect(x + 36, 124, 16, 2);
    n.fillStyle = '#e8283a'; n.fillRect(x + 62, 122, 5, 5);
    for (let k = 0; k < 6; k++) {                                  // a rack of sample tubes
      n.fillStyle = '#d8e2e4'; n.fillRect(x + 32 + k * 6, 108, 4, 8);
      n.fillStyle = ['#c86a7a', '#e8c96a', '#7fd6c0'][k % 3]; n.fillRect(x + 32 + k * 6, 112, 4, 4);
    }
  }
  for (let x = 380; x < W2 - 200; x += 640) {                     // the autoclave, hazard-banded
    n.fillStyle = '#8e999d'; n.fillRect(x, 86, 76, 62);
    n.fillStyle = '#aab4b7'; n.fillRect(x, 86, 76, 3);
    n.fillStyle = '#20282c'; n.beginPath(); n.arc(x + 38, 116, 22, 0, 7); n.fill();
    n.strokeStyle = '#c6d0d2'; n.lineWidth = 3; n.beginPath(); n.arc(x + 38, 116, 22, 0, 7); n.stroke();
    hazardBand(n, x, 78, 76, 8);
    ptext(n, 'STERILISE', x + 12, 140, 'rgba(60,82,92,0.70)');
  }
  epoxyFloor(n, L, R, r, LAB_TOP, '#aab5b8', 'rgba(110,128,134,0.40)', '#dde5e7');
  for (let x = 30; x < W2; x += 100) floorGlow(n, L, x + 33, LAB_TOP, 80, 'rgba(250,255,255,0.09)');
  floorMark(n, 0, 200, W2, 30, 'rgba(232,201,76,0.30)');
  for (let x = 0; x < W2; x += 260) ptext(n, 'BIOHAZARD ZONE', x + 40, 206, 'rgba(232,201,76,0.28)');
  L.labHum = 1;
}

// ---- B3: THE COLD STORE ---------------------------------------------------
// Cryogenic storage. Frost on every surface, vapour rolling off the dewars and
// pooling at your feet, and a wall of numbered drawers that nobody has opened
// in years. The coldest-looking scene in the game.
function s7b_cold(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const g0 = f.createLinearGradient(0, 34, 0, 150);
  g0.addColorStop(0, '#16243a'); g0.addColorStop(1, '#2e4a66');
  f.fillStyle = g0; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 54) {                     // dewars in the far aisle
    f.fillStyle = '#1d3049'; f.fillRect(x + 8, 62, 34, 86);
    f.fillStyle = '#2b4462'; f.fillRect(x + 8, 62, 34, 4);
    f.fillStyle = 'rgba(200,232,255,0.16)'; f.fillRect(x + 12, 68, 8, 76);
  }
  f.fillStyle = 'rgba(180,215,245,0.10)'; f.fillRect(0, 34, L.far.width, 114);
  m.fillStyle = '#16263c'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 64) {                     // the drawer wall behind
    m.fillStyle = '#1e3350'; m.fillRect(x, 40, 58, 108);
    for (let y = 44; y < 146; y += 13) {
      m.fillStyle = '#25405f'; m.fillRect(x + 3, y, 52, 10);
      m.fillStyle = '#31527a'; m.fillRect(x + 3, y, 52, 2);
      m.fillStyle = 'rgba(200,232,255,0.30)'; m.fillRect(x + 24, y + 4, 12, 2);
    }
  }
  m.fillStyle = 'rgba(16,34,58,0.40)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  ceilingSlab(n, L, 34, 12, '#1a2c44', '#2a4364', '#101d2e');
  for (let x = 0; x < W2; x += 76) {                              // frosted chill lines and vapour headers
    n.fillStyle = '#24405e'; n.fillRect(x, 46, 64, 7);
    n.fillStyle = 'rgba(214,240,255,0.50)'; n.fillRect(x, 46, 64, 2);
    for (let k = 0; k < 7; k++) { n.fillStyle = 'rgba(214,240,255,0.35)'; n.fillRect(x + 4 + k * 9, 53, 3, 4); }
  }
  ductRun(n, L, 60, 10, '#223854', '#35567c');
  cableTray(n, L, R, 78, '#1d3149', true);
  for (let x = 0, bi = 0; x < W2; x += 128, bi++) {               // the storage banks you walk past
    const kind = bi % 3;
    if (kind === 2) {                                              // every third bay is something else
      n.fillStyle = '#10203a'; n.fillRect(x, 74, 118, 74);
      viewPane(n, x + 12, 80, 94, 54, 'rgba(160,210,245,0.14)', '#1d3556');
      n.fillStyle = 'rgba(214,240,255,0.22)'; n.fillRect(x + 12, 80, 94, 3);
      for (let k = 0; k < 9; k++) {                                // frost feathering across the glass
        n.fillStyle = 'rgba(226,246,255,0.14)';
        n.beginPath(); n.ellipse(x + 20 + (k * 23) % 86, 86 + (k * 17) % 44, 9 + (k % 3) * 5, 4, 0, 0, 7); n.fill();
      }
      n.fillStyle = '#152741'; n.fillRect(x, 134, 118, 14);
      hazardBand(n, x + 8, 136, 102, 8, '#8fd0f0', '#10202f');
      ptext(n, 'CHAMBER ' + String(2 + bi), x + 14, 70, 'rgba(190,225,255,0.60)');
      floorGlow(n, L, x + 59, LAB_TOP, 104, 'rgba(150,215,255,0.10)');
      continue;
    }
    const rows = kind === 0 ? 4 : 3, pitch = kind === 0 ? 13 : 17, top = kind === 0 ? 88 : 80;
    n.fillStyle = '#152741'; n.fillRect(x, top, 118, 148 - top);
    n.fillStyle = '#20395c'; n.fillRect(x, top, 118, 3);
    for (let row = 0; row < rows; row++) for (let col = 0; col < 3; col++) {
      const dx = x + 6 + col * 37, dy = top + 6 + row * pitch;
      n.fillStyle = '#1e3557'; n.fillRect(dx, dy, 33, pitch - 2);
      n.fillStyle = '#2c4d79'; n.fillRect(dx, dy, 33, 2);
      n.fillStyle = '#0d1828'; n.fillRect(dx + 12, dy + 4, 10, 3);
      n.fillStyle = 'rgba(214,240,255,0.45)'; n.fillRect(dx + 2, dy + pitch - 3, 29, 1);   // frost on the lip
    }
    if (bi % 4 === 1) {                                            // one drawer pulled out, empty
      n.fillStyle = '#060d16'; n.fillRect(x + 43, top + 32, 33, 11);
      n.fillStyle = '#2c4d79'; n.fillRect(x + 43, top + 43, 36, 4);
      n.fillStyle = 'rgba(214,240,255,0.25)'; n.fillRect(x + 43, top + 32, 33, 2);
    }
    ptext(n, 'CS-' + String(40 + bi), x + 6, top - 6, 'rgba(190,225,255,0.55)');
    n.fillStyle = '#1b3050'; n.fillRect(x + 118, top - 4, 10, 152 - top);
    n.fillStyle = '#2a4770'; n.fillRect(x + 118, top - 4, 3, 152 - top);
  }
  for (let x = 250; x < W2 - 180; x += 520) {                     // a standing dewar, breathing
    n.fillStyle = '#132540'; n.fillRect(x, 74, 52, 74);
    n.fillStyle = '#1f3a5e'; n.fillRect(x + 4, 74, 12, 74);
    n.fillStyle = '#2c4d79'; n.fillRect(x - 4, 70, 60, 8);
    n.fillStyle = 'rgba(214,240,255,0.55)'; n.fillRect(x - 4, 70, 60, 2);
    hazardBand(n, x, 138, 52, 8, '#8fd0f0', '#10202f');
    ptext(n, 'LN2', x + 16, 86, 'rgba(214,240,255,0.65)');
    floorGlow(n, L, x + 26, LAB_TOP, 86, 'rgba(150,215,255,0.10)');
  }
  epoxyFloor(n, L, R, r, LAB_TOP, '#142640', 'rgba(110,170,220,0.20)', '#27476c');
  for (let k = 0; k < W2 * 0.08; k++) {                           // frost creeping out from the walls
    n.fillStyle = 'rgba(214,240,255,0.06)';
    n.beginPath(); n.ellipse(r(0, W2), LAB_TOP + r(0, 26), 14 + R() * 30, 3 + R() * 5, 0, 0, 7); n.fill();
  }
  n.fillStyle = 'rgba(150,200,240,0.05)'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  L.cryo = 1; L.labHum = 1;
}

// ---- B4: THE WARD ---------------------------------------------------------
// The wildcard, and the one with no science-fiction in it at all: a hospital
// ward with the beds still made, the monitors still running, and nobody in
// any of them. One tube out of six has failed.
function s7b_ward(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const g0 = f.createLinearGradient(0, 34, 0, 150);
  g0.addColorStop(0, '#1e2a26'); g0.addColorStop(1, '#31403a');
  f.fillStyle = g0; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 96) {
    f.fillStyle = 'rgba(70,92,84,0.45)'; f.fillRect(x, 58, 76, 90);
    f.fillStyle = 'rgba(180,205,195,0.20)'; f.fillRect(x, 54, 84, 5);
  }
  // mid: the opposite side of the ward, curtains half drawn
  m.fillStyle = '#2c3a35'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 132) {
    m.fillStyle = '#39493f'; m.fillRect(x + 10, 46, 110, 102);
    for (let k = 0; k < 9; k++) { m.fillStyle = k % 2 ? '#425449' : '#3a4a41'; m.fillRect(x + 10 + k * 12, 46, 12, 102); }
    m.fillStyle = '#5b6f60'; m.fillRect(x + 6, 44, 118, 3);
    m.fillStyle = 'rgba(200,220,208,0.10)'; m.fillRect(x + 10, 46, 110, 30);
  }
  m.fillStyle = 'rgba(24,34,30,0.40)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  ceilingSlab(n, L, 34, 12, '#2b3831', '#3d4e44', '#1a231f');
  lightStrip(n, L, 48, '#d8e8d8', 'rgba(196,224,204,0.16)', 112, 0.8);
  for (let x = 0; x < W2; x += 132) {                             // curtain rails over each bay
    n.fillStyle = '#4b5d51'; n.fillRect(x, 60, 120, 3);
    for (let k = 0; k < 11; k++) { n.fillStyle = '#5f7466'; n.fillRect(x + 4 + k * 11, 58, 2, 4); }
  }
  cableTray(n, L, R, 70, '#30403a', true);
  for (let x = 0; x < W2; x += 132) {                             // the bays: bed, monitor, drip stand
    const bx = x + 14;
    n.fillStyle = '#354439'; n.fillRect(x, 78, 126, 70);          // the bay wall
    n.fillStyle = '#41523f'; n.fillRect(x, 78, 126, 2);
    n.fillStyle = '#26312b'; n.fillRect(x + 4, 92, 118, 4);       // the services rail
    n.fillStyle = '#1a2320'; n.fillRect(bx + 76, 82, 32, 26);     // the monitor, still running
    n.fillStyle = 'rgba(90,208,106,0.60)'; n.fillRect(bx + 79, 85, 26, 1);
    for (let k = 0; k < 13; k++) {                                 // a trace across it
      const yy = 96 + (k === 5 ? -7 : k === 6 ? 6 : 0);
      n.fillStyle = 'rgba(90,208,106,0.75)'; n.fillRect(bx + 79 + k * 2, yy, 2, 1);
    }
    ptext(n, 'B' + String(12 + (x / 132 | 0)), bx + 80, 100, 'rgba(150,200,160,0.45)');
    // the bed: frame and mattress, its top surface above the walkable band
    n.fillStyle = '#4c5d50'; n.fillRect(bx, 122, 66, 6);
    n.fillStyle = '#65786a'; n.fillRect(bx, 122, 66, 2);
    n.fillStyle = '#c8d4c4'; n.fillRect(bx + 2, 116, 62, 6);       // the made sheet
    n.fillStyle = '#e2eade'; n.fillRect(bx + 2, 116, 62, 2);
    n.fillStyle = '#aab8a6'; n.fillRect(bx + 4, 111, 20, 6);       // the pillow
    n.fillStyle = '#3e4d42'; n.fillRect(bx - 4, 106, 6, 22);       // head rail
    n.fillStyle = '#3e4d42'; n.fillRect(bx + 64, 110, 6, 18);      // foot rail
    n.fillStyle = '#3a4840'; n.fillRect(bx + 4, 128, 4, 18);        // legs, down to the floor line
    n.fillStyle = '#3a4840'; n.fillRect(bx + 56, 128, 4, 18);
    n.fillStyle = '#242e28'; n.beginPath(); n.arc(bx + 6, 146, 3, 0, 7); n.arc(bx + 58, 146, 3, 0, 7); n.fill();
    n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(bx, 146, 66, 2);
    n.strokeStyle = '#8a7a5c'; n.lineWidth = 2;                    // the restraints, left undone
    n.beginPath(); n.moveTo(bx + 6, 116); n.quadraticCurveTo(bx + 2, 126, bx + 8, 134); n.stroke();
    n.beginPath(); n.moveTo(bx + 56, 116); n.quadraticCurveTo(bx + 62, 126, bx + 54, 132); n.stroke();
    n.fillStyle = '#4c5d50'; n.fillRect(bx + 100, 104, 3, 44);     // the drip stand
    n.fillStyle = '#65786a'; n.fillRect(bx + 94, 102, 15, 3);
    n.fillStyle = 'rgba(220,235,225,0.55)'; n.fillRect(bx + 97, 106, 8, 12);
    n.fillStyle = '#243029'; n.fillRect(x + 126, 74, 6, 74);       // the divider between bays
  }
  for (let x = 420; x < W2 - 200; x += 700) {                     // a nurses' station, lights on
    n.fillStyle = '#2f3d35'; n.fillRect(x, 96, 118, 52);
    n.fillStyle = '#41523f'; n.fillRect(x, 96, 118, 3);
    n.fillStyle = '#5c6f5e'; n.fillRect(x - 4, 92, 126, 5);
    for (let k = 0; k < 3; k++) {
      n.fillStyle = '#131b17'; n.fillRect(x + 10 + k * 36, 102, 28, 20);
      n.fillStyle = 'rgba(120,200,160,0.45)'; n.fillRect(x + 12 + k * 36, 104, 24, 2);
      n.fillStyle = 'rgba(120,200,160,0.20)'; n.fillRect(x + 12 + k * 36, 108, 16, 2);
    }
    ptext(n, 'WARD 3 - STATION', x + 8, 130, 'rgba(160,200,172,0.50)');
  }
  epoxyFloor(n, L, R, r, LAB_TOP, '#2a3730', 'rgba(140,170,150,0.16)', '#465a4c');
  for (let x = 0; x < W2; x += 132) floorGlow(n, L, x + 60, LAB_TOP, 92, 'rgba(210,235,215,0.055)');
  for (let k = 0; k < W2 * 0.04; k++) {                           // paper, dropped and left
    n.fillStyle = 'rgba(226,234,222,0.30)';
    n.fillRect(r(0, W2), r(LAB_TOP + 14, 230), 5 + R() * 5, 3);
  }
  n.fillStyle = 'rgba(20,30,24,0.28)'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  L.flickerTube = 1;
}
