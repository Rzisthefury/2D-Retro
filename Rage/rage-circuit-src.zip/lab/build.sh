#!/bin/bash
cd /home/claude/rage
cat src/p0_head.html src/p0_shell.html \
    src/p1_core.js src/p2_audio.js src/p3_poses.js src/p3b_pix.js src/p3c_props.js \
    src/p4_data.js src/p5_fight.js src/p6_stage.js src/p7_game.js \
    lab/paint2.js src/p9_tail.html > lab/lab.html
