#!/bin/bash
cd "$(dirname "$0")"
JS="src/p1_core.js src/p2_audio.js src/p2b_band.js src/p3_poses.js src/p3b_pix.js src/p3c_props.js src/p4_data.js src/p5_fight.js src/p6_stage.js src/p6b_city.js src/p7_game.js"
cat src/p0_head.html src/p0_shell.html $JS src/p9_tail.html > dist/rage-circuit.html
cat src/p0_head_artifact.html src/p0_shell.html $JS src/p9_tail.html > dist/rage-circuit-artifact.html
wc -c dist/rage-circuit.html
