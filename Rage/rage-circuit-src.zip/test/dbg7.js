const { launch } = require('./harness');
(async () => {
  const t = await launch();
  await t.ev(() => {
    const r = window.__rc;
    r.SESSION.introSeen = true;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'anita', partner: true, partnerChar: 'cole', allyCmd: 0, stage: 8 });
    r.go('play');
    const G = r.G;
    r.loadScene(2, false); G.loadQ = [];
    const waves = G.scene.waves;
    G.camX = waves[waves.length - 1].at; G.waveIdx = waves.length - 1;
    r.setIntent(e => allyIntent(e));
    window.__log = [];
  });
  const o = await t.ev(() => {
    const r = window.__rc, G = r.G;
    let seen = null;
    for (let i = 0; i < 20000; i++) {
      if (G.player) G.player.hp = Math.max(G.player.hp, 60);
      r.tick();
      const b = G.bosses[0];
      if (b && b.hp <= 0 && !seen) {
        seen = { tick: i, state: b.state, killed: !!b.killed, hasDef: !!b.def, next: b.def && b.def.next, hp: b.hp };
      }
      if (seen && i > seen.tick + 6) break;
    }
    const b = G.bosses[0];
    return { seen, after: b && { state: b.state, killed: !!b.killed, remove: !!b.remove }, n: G.bosses.length, pending: G.pendingBoss };
  });
  console.log(JSON.stringify(o, null, 1));
  console.log(t.errors.slice(0, 4).join('\n') || 'no errors');
  await t.close();
})();
