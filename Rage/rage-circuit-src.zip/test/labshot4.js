const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
(async () => {
  const file = path.join(__dirname, '..', 'lab', 'lab.html');
  const server = http.createServer((q, r) => { r.writeHead(200, { 'Content-Type': 'text/html' }); r.end(fs.readFileSync(file)); });
  await new Promise(r => server.listen(0, r));
  const port = server.address().port;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 800 } });
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.goto(`http://localhost:${port}/`);
  await page.waitForTimeout(400);
  await page.evaluate(() => window.__rc.freeze(true));
  await page.evaluate(() => {
    const cv = document.getElementById('cv');
    cv.width = 1100; cv.height = 560; cv.style.width = '1100px'; cv.style.height = '560px';
    const c = cv.getContext('2d'); c.imageSmoothingEnabled = false;
    const L = window.__rc.LOOKS, D = window.__lab.drawFigureV;
    c.fillStyle = '#585866'; c.fillRect(0, 0, 1100, 560);
    text('THE HEAD BUG - HEADS WERE A FIXED 14 PX BITMAP, SO BIG CHARACTERS WORE A STREET PUNK HEAD', 16, 14, '#fff', 1, 0);
    const who = [[L.punkA, 'PUNK  1.0x'], [L.bruiserA, 'BRUISER  1.16x'], [L.tank, 'TANK  1.2x'], [L.brick, 'BIG BRICK  1.42x'], [L.slag, 'SLAG  1.44x']];
    text('BEFORE - every head the same size', 20, 46, '#c85a5a', 1, 0);
    text('AFTER - head scales with the character', 20, 306, '#5ad06a', 1, 0);
    who.forEach(([look, lab], i) => {
      const x = 130 + i * 205;
      c.fillStyle = 'rgba(0,0,0,0.2)'; c.fillRect(x - 96, 60, 192, 230);
      c.fillStyle = 'rgba(0,0,0,0.2)'; c.fillRect(x - 96, 320, 192, 230);
      D(x, 286, 1, 'idle', look, 'A', { scale: 1.75 });
      D(x, 546, 1, 'idle', look, 'S', { scale: 1.75 });
      text(lab, x, 296, '#f2c94c', 1, 1);
    });
  });
  await page.locator('#cv').screenshot({ path: 'shots/q3_head.png' });
  console.log(errs.slice(0, 4).join('\n') || 'no errors');
  await browser.close(); server.close();
})();
