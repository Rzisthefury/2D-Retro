// The Unit-9 capsule sits at x=700 in the birthing floor. This parks the camera
// on it to confirm the painted capsule and the breakable line up.
const { launch } = require('/home/claude/rage/test/harness');
(async () => {
  const t = await launch();
  await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: true, partnerChar: 'anita', stage: 7 });
    r.go('play');
    const G = r.G;
    for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
    r.loadScene(2, false);
    for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
    G.loadQ = []; G.banner = null; G.fade = 0; G.fadeDir = 0;
    // clear the waves so the camera is free to reach the capsule
    G.ents = G.ents.filter(e => e.team === 'hero');
    G.spawnQ = []; G.wave = null; G.waveIdx = 99; G.lockX = null;
    for (let i = 0; i < 1600 && G.camX < 700 - 213; i++) { G.player.x += 0.9; r.tick(); G.banner = null; }
    for (let i = 0; i < 40; i++) { r.tick(); G.banner = null; }
  });
  await t.ev(() => window.__rc.render());
  await t.page.locator('#cv').screenshot({ path: 'shots/s7_capsule.png' });
  const o = await t.ev(() => {
    const G = window.__rc.G;
    const caps = G.props.filter(p => p.objective === 'unit9').map(p => ({ x: p.x, y: p.y, kind: p.kind }));
    return { caps, cam: Math.round(G.camX), bg: G.scene.bg, name: G.scene.name };
  });
  console.log(JSON.stringify(o));
  console.log(t.errors.length ? 'PAGE ERRORS:\n' + t.errors.join('\n') : 'no errors');
  await t.close();
})();
