// Zoomed single-figure inspection sheet: raw sprite pixels, magnified.
const { launch } = require('./harness');
(async () => {
  const t = await launch();
  const set = (process.argv[2] || 'cole:idle').split(',');
  const name = process.argv[3] || 'zoomfig';
  const Z = Number(process.argv[4] || 2), YY = Number(process.argv[5] || 228);
  await t.ev(([set, Z, YY]) => {
    const c = window.__rc.ctx;
    c.setTransform(PX, 0, 0, PX, 0, 0);
    c.fillStyle = '#16141f'; c.fillRect(0, 0, 426, 240);
    c.imageSmoothingEnabled = false;
    const step = Math.floor(420 / set.length);
    set.forEach((spec, i) => {
      const [l, p] = spec.split(':');
      const look = window.__rc.LOOKS[l];
      const f = getFrame(look, p, null, null);
      const x = step / 2 + i * step, y = YY;
      c.drawImage(f.cv, 0, 0, f.w, f.h, x - f.ox * Z / PX, y - f.oy * Z / PX, f.w * Z / PX, f.h * Z / PX);
      text(l.toUpperCase(), x, 233, '#c8c4dc', 1, 1);
    });
  }, [set, Z, YY]);
  await t.grab(name);
  console.log(t.errors.slice(0, 3).join('\n') || 'ok');
  await t.close();
})();
