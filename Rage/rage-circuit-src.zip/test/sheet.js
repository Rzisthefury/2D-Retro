const { launch } = require('./harness');
const look = process.argv[2] || 'cole';
const scale = +(process.argv[3] || 1);
(async () => {
  const t = await launch();
  const r = await t.ev(([look, scale]) => {
    const x = window.__rc, c = x.ctx;
    c.fillStyle = '#4a4a5e'; c.fillRect(0, 0, 426, 240);
    const names = window.__sheetPoses || Object.keys(x.POSES);
    const t0 = performance.now();
    const cols = Math.floor(14 / scale);
    names.slice(0, cols * 3).forEach((n, i) => {
      const px = 22 * scale + (i % cols) * 30 * scale, py = 78 * scale + Math.floor(i / cols) * 78 * scale;
      drawFigure(px, py, 1, n, x.LOOKS[look], {});
    });
    return performance.now() - t0;
  }, [look, scale]);
  console.log('bake ms', Math.round(r));
  await t.page.locator('#cv').screenshot({ path: `shots/sheet_${look}.png` });
  await t.ev(() => {
    const x = window.__rc, c = x.ctx;
    c.fillStyle = '#4a4a5e'; c.fillRect(0, 0, 426, 240);
    const looks = ['cole','coleCPU','anita','anitaCPU','punkA','punkB','punkC','bladeA','bladeB','bruiserA','bruiserB','kickerA','kickerB','brick'];
    looks.forEach((l, i) => drawFigure(16 + i * 30, 112, 1, 'idle', x.LOOKS[l], {}));
    const looks2 = ['dummy','whipA','whipB','robot','ruby','onyx','rivet','vex'];
    looks2.forEach((l, i) => drawFigure(20 + i * 34, 232, 1, 'idle', x.LOOKS[l], {}));
    drawPortrait(300, 130, x.LOOKS.cole); drawPortrait(330, 130, x.LOOKS.anita); drawPortrait(360, 130, x.LOOKS.brick);
  });
  await t.page.locator('#cv').screenshot({ path: 'shots/sheet_looks.png' });
  console.log(t.errors.slice(0, 3).join('\n') || 'no errors');
  await t.close();
})();
