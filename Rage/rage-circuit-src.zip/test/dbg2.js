const { launch } = require('./harness');
(async () => {
  const t = await launch();
  const out = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 });
    r.go('play');
    r.setIntent(e => { const I = allyIntent(e); const live = r.G.ents.filter(f => f.team === 'foe' && !f.killed && !f.remove && !f.enter); if (!live.length && !I.atk) { I.mx = 1; I.my = 0; } e._I = I; return I; });
    const res = [];
    for (let k = 0; k < 1500; k++) { r.tick(); if (k % 100 === 0) res.push(JSON.stringify(r.G.player._I) + ' ' + r.G.ents.map(e => [e.kind, e.state, e.enter, Math.round(e.x), Math.round(e.y), e.inv, e.pose].join(',')).join(' | ')); }
    return res;
  });
  console.log(out.join('\n'));
  console.log(t.errors.join('\n') || 'no errors');
  await t.close();
})();
