const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
(async () => {
  const file = path.join(__dirname, '..', 'lab', 'lab.html');
  const server = http.createServer((q, r) => { r.writeHead(200, { 'Content-Type': 'text/html' }); r.end(fs.readFileSync(file)); });
  await new Promise(r => server.listen(0, r));
  const port = server.address().port;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1500, height: 1100 } });
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.goto(`http://localhost:${port}/`);
  await page.waitForTimeout(400);
  await page.evaluate(() => window.__rc.freeze(true));
  const shot = async (name, w, h, fn) => {
    await page.evaluate(([w, h]) => {
      const cv = document.getElementById('cv');
      cv.width = w; cv.height = h; cv.style.width = w + 'px'; cv.style.height = h + 'px';
      cv.getContext('2d').imageSmoothingEnabled = false;
    }, [w, h]);
    await page.evaluate(fn);
    await page.locator('#cv').screenshot({ path: `shots/${name}.png` });
  };

  // ---------- SHEET 1: the BODY question (same hand-pixeled head on all three)
  await shot('q1_body', 1200, 1020, () => {
    const c = window.__rc.ctx, L = window.__rc.LOOKS, D = window.__lab.drawFigureV;
    c.fillStyle = '#585866'; c.fillRect(0, 0, 1200, 1020);
    const cols = [['A', '1   WHAT YOU HAVE NOW'], ['S', '2   REBUILT'], ['T', '3   REBUILT, LONGER']];
    const rows = [[L.cole, 'idle', 'COLE'], [L.cole, 'straight', ''], [L.anita, 'aHighKick', 'ANITA'], [L.brick, 'heavyIdle', 'BIG BRICK']];
    cols.forEach(([st, lab], i) => {
      const x = 210 + i * 340;
      c.fillStyle = i === 0 ? 'rgba(90,20,30,0.30)' : 'rgba(0,0,0,0.22)';
      c.fillRect(x - 160, 10, 320, 1004);
      text(lab, x, 26, '#fff', 2, 1);
      rows.forEach(([look, pose], r) => {
        const y = 262 + r * 246;
        D(x, y, 1, pose, look, st, { scale: 2.5 });
      });
    });
    rows.forEach(([look, pose, name], r) => {
      if (name) text(name, 14, 262 + r * 246 - 210, '#f2c94c', 1, 0);
    });
  });

  console.log(errs.slice(0, 5).join('\n') || 'no errors');
  await browser.close(); server.close();
})();
