const { launch } = require('./harness');
let window_name = 'cast';
const SETS = [
  [[[['cole', 'idle'], ['anita', 'aIdle'], ['coleCPU', 'idle'], ['anitaCPU', 'aIdle'], ['vex', 'idle'], ['brick', 'heavyIdle'], ['rivet', 'heavyIdle']],
    [['punkA', 'idle'], ['punkB', 'idle'], ['punkC', 'idle'], ['bladeA', 'idle'], ['bladeB', 'idle'], ['kickerA', 'idle'], ['kickerB', 'idle']]], 'cast'],
  [[[['bruiserA', 'heavyIdle'], ['bruiserB', 'heavyIdle'], ['whipA', 'idle'], ['whipB', 'idle'], ['robot', 'idle'], ['ruby', 'tIdle'], ['onyx', 'tIdle']],
    [['cole', 'straight'], ['anita', 'aHighKick'], ['cole', 'roundhouse'], ['anita', 'aTornado1'], ['cole', 'haymaker'], ['brick', 'slamDown'], ['ruby', 'tSplit']]], 'cast2'],
];
const NAMES = { cole: 'COLE', anita: 'ANITA', coleCPU: 'CPU COLE', anitaCPU: 'CPU ANITA', vex: 'VEX', brick: 'BIG BRICK', rivet: 'RIVET',
  punkA: 'PUNK', punkB: 'PUNK', punkC: 'PUNK', bladeA: 'BLADE', bladeB: 'BLADE', kickerA: 'KICKER', kickerB: 'KICKER',
  bruiserA: 'BRUISER', bruiserB: 'BRUISER', whipA: 'WHIP', whipB: 'WHIP', robot: 'ROBOT', ruby: 'RUBY', onyx: 'ONYX' };
(async () => {
  const t = await launch();
  for (const [rows, name] of SETS) {
  window_name = name;
  await t.ev(([rows, names]) => { window.__rows = rows; window.__names = names; }, [rows, NAMES]);
  await t.ev(() => {
    const c = window.__rc.ctx;
    c.fillStyle = '#12101c'; c.fillRect(0, 0, 426, 240);
    const rows = window.__rows;
    const names = window.__names;
    rows.forEach((row, ri) => row.forEach(([l, p], i) => {
      const x = 34 + i * 56, y = 112 + ri * 116;
      drawFigure(x, y, 1, p, window.__rc.LOOKS[l], {});
      text(names[l] || l, x, y + 4, '#e8e8f0', 1, 1);
    }));
  });
  await t.page.locator('#cv').screenshot({ path: `shots/${window_name}.png` });
  }
  console.log(t.errors.slice(0, 3).join('\n') || 'ok');
  await t.close();
})();
