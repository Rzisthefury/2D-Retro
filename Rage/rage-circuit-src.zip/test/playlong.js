const { launch } = require('./harness');
const diff = +(process.argv[2] || 1), partner = process.argv[3] === 'ally';
const stage = +(process.argv[4] || 1), char = process.argv[5] || 'cole';
(async () => {
  const t = await launch();
  await t.ev(([diff, partner, stage, char]) => {
    const r = window.__rc;
    r.SESSION.introSeen = true;
    r.startRun({ mode: 'story', diff, classic: false, char, partner, partnerChar: char === 'cole' ? 'anita' : 'cole', allyCmd: 0, stage });
    r.go('play');
    r.setIntent(e => {
      const I = allyIntent(e);
      const G = r.G;
      const live = G.ents.filter(f => f.team === 'foe' && !f.killed && !f.remove && !f.enter);
      if (!live.length && !I.atk) { I.mx = 1; I.my = 0; }
      const bz = G.bosses.find(b => !b.killed && (b.state === 'dazed' || b.state === 'ttaunt') && Math.abs(b.x - e.x) < 50);
      if (bz) { I.mx = Math.sign(bz.x - e.x); I.my = Math.sign(bz.y - e.y); I.atk = false; }
      if (e.state === 'grab' && e.grab && e.grab.kind === 'boss') { I.atk = false; I.back = true; }
      return I;
    });
  }, [diff, partner, stage, char]);
  let log = [], last = '';
  for (let i = 0; i < 1100; i++) {
    const s = await t.ev(() => {
      const r = window.__rc; const G = r.G;
      for (let k = 0; k < 60; k++) {
        if (!r.G) break;
        if (r.G.player) r.G.player.hp = Math.max(r.G.player.hp, 60);
        r.tick();
        if (r.SCREEN !== 'play') break;
      }
      const g = r.G;
      if (!g) return { screen: r.SCREEN };
      return { screen: r.SCREEN, scene: g.sceneIdx, cam: Math.round(g.camX), wave: g.waveIdx, foes: g.ents.filter(e => e.team === 'foe').length,
        px: Math.round(g.player.x), pst: g.player.state, score: g.score, lives: g.lives, boss: g.bosses.length ? g.bosses.map(b => [b.name, b.state, b.hp]).flat() : null, t: g.stageFrames, q: g.spawnQ.length, exit: g.exitOpen };
    });
    const key = JSON.stringify([s.screen, s.scene, s.wave, s.boss && s.boss.filter((v, i) => i % 3 !== 2)]);
    if (key !== last) { log.push(JSON.stringify(s)); last = key; }
    if (i % 40 === 0) log.push('  ' + JSON.stringify(s));
    if (s.screen !== 'play') break;
    if (i === 60) await t.shot('pt_mid');
    if (i % 25 === 12) await t.shot(`pt_s${stage}_${i}`);
  }
  await t.shot('pt_end');
  console.log(log.join('\n'));
  const T = await t.ev(() => window.__rc.S.T && { bank: window.__rc.S.T.bank, grade: window.__rc.S.T.gr.g.g, xp: window.__rc.S.T.xp, earned: window.__rc.S.T.earned, frames: window.__rc.G.stageFrames, kos: window.__rc.G.kos });
  console.log('TALLY', JSON.stringify(T));
  console.log(t.errors.slice(0, 5).join('\n') || 'no errors');
  await t.close();
})();
