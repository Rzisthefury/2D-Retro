const { launch } = require('./harness');
(async () => {
  const t = await launch();
  const o = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 8 });
    r.go('play');
    const G = r.G;
    r.loadScene(2, false); G.loadQ = [];
    const waves = G.scene.waves;
    G.camX = waves[waves.length - 1].at; G.waveIdx = waves.length - 1;
    for (let i = 0; i < 40; i++) r.tick();
    const b = G.bosses[G.bosses.length - 1];
    const info = { name: b.name, hasDef: !!b.def, next: b.def && b.def.next, killed: b.killed, type: b.boss.type };
    // kill him the way the game does
    b.hp = 4;
    r.applyHit(G.player, b, { dmg: 40, type: 'K', kx: 3, kz: 3 });
    const seq = [];
    for (let i = 0; i < 300; i++) { r.tick(); seq.push(b.state); }
    return { info, states: [...new Set(seq)], pending: G.pendingBoss,
      bosses: G.bosses.map(x => [x.def.name, !!x.killed, !!x.remove, x.state]) };
  });
  console.log(JSON.stringify(o, null, 1));
  console.log(t.errors.slice(0, 4).join('\n') || 'no errors');
  await t.close();
})();
