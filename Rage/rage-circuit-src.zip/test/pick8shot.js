// Contact sheets for the stage 8 concept options: every option at three camera
// positions, with the HUD band and the walkable band drawn on so occlusion
// mistakes are impossible to miss.
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');

(async () => {
  const file = path.join(__dirname, '..', 'lab', 'bg', 'picker8.html');
  const server = http.createServer((q, r) => { r.writeHead(200, { 'Content-Type': 'text/html' }); r.end(fs.readFileSync(file)); });
  await new Promise(r => server.listen(0, r));
  const port = server.address().port;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1500, height: 900 } });
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.goto(`http://localhost:${port}/`);
  await page.waitForTimeout(900);

  for (const secId of ['A', 'B', 'C']) {
    await page.evaluate(id => {
      const sec = SECTIONS.find(s => s.id === id);
      const SHOTS = [40, 0.42, 0.82];             // start, middle, and the far end
      const cw = 426, ch = 240, pad = 10, lab = 22;
      const cv = document.createElement('canvas');
      cv.id = 'sheet';
      cv.width = (cw * 3 + pad * 4) * 2;
      cv.height = ((ch + lab) * 4 + pad) * 2;
      cv.style.width = (cw * 3 + pad * 4) + 'px';
      const g = cv.getContext('2d');
      g.setTransform(2, 0, 0, 2, 0, 0);
      g.imageSmoothingEnabled = false;
      g.fillStyle = '#0a0812'; g.fillRect(0, 0, cv.width, cv.height);
      sec.options.forEach((opt, oi) => {
        const L = build(opt, sec.len);
        const oy = pad + oi * (ch + lab);
        ptext(g, opt.k + '  ' + opt.name.toUpperCase(), pad, oy, '#f2c94c', 2);
        SHOTS.forEach((s, si) => {
          const c = s < 1 ? Math.round((sec.len - 426) * s) : s;
          const ox = pad + si * (cw + pad), oyy = oy + lab;
          g.save(); g.beginPath(); g.rect(ox, oyy, cw, ch); g.clip();
          g.translate(ox, oyy);
          g.fillStyle = '#000'; g.fillRect(0, 0, cw, ch);
          g.drawImage(L.far, -Math.round(c * 0.25), 0, L.far.width, L.far.height);
          g.drawImage(L.mid, -Math.round(c * 0.55), 0, L.mid.width, L.mid.height);
          g.drawImage(L.near, -Math.round(c), 0, L.near.width, L.near.height);
          s8Overlays(g, L, 300 + si * 37, c, sec.len);
          g.fillStyle = 'rgba(232,40,58,0.28)'; g.fillRect(0, 0, cw, 34);
          g.fillStyle = 'rgba(74,192,232,0.13)'; g.fillRect(0, 150, cw, 80);
          g.fillStyle = 'rgba(74,192,232,0.55)'; g.fillRect(0, 150, cw, 1); g.fillRect(0, 229, cw, 1);
          g.restore();
        });
      });
      document.body.prepend(cv);
    }, secId);
    await page.locator('#sheet').screenshot({ path: `shots/pick8_${secId}.png` });
    await page.evaluate(() => document.getElementById('sheet').remove());
  }
  console.log(errs.slice(0, 6).join('\n') || 'no errors');
  await browser.close(); server.close();
})();
