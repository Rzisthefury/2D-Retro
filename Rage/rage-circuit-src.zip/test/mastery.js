const { launch } = require('./harness');
const results = [];
function check(name, ok, info = '') { results.push([ok ? 'PASS' : 'FAIL', name, info]); }
(async () => {
  const t = await launch();

  // an arena with one fighter, one frozen foe and nothing else moving
  const arena = async (char, xp) => t.ev(([ch, x]) => {
    const r = window.__rc;
    r.SAVE().chars[ch].xp = x;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: ch, partner: false, stage: 1 });
    r.go('play');
    const G = r.G;
    G.loadQ = [];
    G.scene.waves = []; G.waveIdx = 99; G.wave = null; G.spawnQ = [];
    G.ents = G.ents.filter(e => e.team === 'hero');
    G.player.x = 140; G.player.y = 190; G.player.meter = 1;
    return r.masteryLevel(r.SAVE().chars[ch].xp);
  }, [char, xp]);

  const lvl6 = 9600;  // mastery 6
  const lvl4 = 3000;  // mastery 4

  // --- mastery 4: air throw
  for (const ch of ['cole', 'anita', 'tank', 'jett']) {
    const l = await arena(ch, lvl4);
    const o = await t.ev(() => {
      const r = window.__rc, G = r.G, p = G.player;
      const f = r.spawnEnemy('punk', p.x + 22, p.y, 1);
      f.enter = false; f.speed = 0; f.maxHp = f.hp = 600;
      // both of us off the ground
      p.state = 'jump'; p.st = 8; p.z = 40; p.vz = 0.2; p.face = 1;
      p.buf = { atk: 0, jump: 0, sp: 0 };
      f.state = 'fall'; f.z = 36; f.vz = 0.1;
      r.Input.keyEdges.add('KeyJ'); r.Input.keys.add('KeyJ');
      r.tick();
      r.Input.keys.delete('KeyJ');
      const grabbed = p.state === 'athrow';
      let states = new Set();
      for (let i = 0; i < 90; i++) { r.tick(); states.add(p.state); }
      return { grabbed, hp: f.hp, states: [...states] };
    });
    check(`${ch} mastery 4: air throw catches an airborne enemy and spikes him`, o.grabbed && o.hp < 600, JSON.stringify(o));
  }

  // not available below mastery 4
  await arena('cole', 0);
  let o = await t.ev(() => {
    const r = window.__rc, G = r.G, p = G.player;
    const f = r.spawnEnemy('punk', p.x + 22, p.y, 1);
    f.enter = false; f.speed = 0; f.maxHp = f.hp = 600;
    p.state = 'jump'; p.st = 8; p.z = 40; p.vz = 0.2; p.face = 1;
    p.buf = { atk: 0, jump: 0, sp: 0 };
    f.state = 'fall'; f.z = 36;
    r.Input.keyEdges.add('KeyJ'); r.Input.keys.add('KeyJ'); r.tick(); r.Input.keys.delete('KeyJ');
    return p.state;
  });
  check('air throw is locked until mastery 4', o === 'jump', o);

  // --- mastery 5: the air-down drop
  for (const [ch, mv] of [['cole', 'cElbow'], ['anita', 'aHeelDrop'], ['tank', 'kPress'], ['jett', 'jMeteor']]) {
    await arena(ch, lvl6);
    o = await t.ev(mv => {
      const r = window.__rc, G = r.G, p = G.player;
      const f = r.spawnEnemy('punk', p.x + 14, p.y, 1);
      f.enter = false; f.speed = 0; f.maxHp = f.hp = 600; f.state = 'ai'; f.ai.cool = 9999;
      p.state = 'jump'; p.st = 8; p.z = 60; p.vz = 0.2; p.face = 1;
      p.buf = { atk: 0, jump: 0, sp: 0 };
      // hold down + attack
      r.Input.keys.add('ArrowDown');
      r.Input.keyEdges.add('KeyJ'); r.Input.keys.add('KeyJ');
      r.tick();
      const chosen = p.airAtk;
      r.Input.keys.delete('KeyJ');
      let shock = false;
      for (let i = 0; i < 80; i++) { r.tick(); if (G.fx.some(x => x.k === 'shock')) shock = true; }
      r.Input.keys.delete('ArrowDown');
      return { chosen, want: mv, shock, hp: f.hp };
    }, mv);
    check(`${ch} mastery 5: air + down + attack is the drop, and it shakes the floor`, o.chosen === o.want && o.shock && o.hp < 600, JSON.stringify(o));
  }

  // --- mastery 6: the upgraded forward special
  for (const [ch, base, plus] of [['cole', 'specialF', 'specialFP'], ['anita', 'aspF', 'aspFP'], ['tank', 'kquake', 'kquakeP'], ['jett', 'jrush', 'jrushP']]) {
    await arena(ch, 4800);   // mastery 5, not yet 6
    const a = await t.ev(() => {
      const r = window.__rc, p = r.G.player;
      p.meter = 1; r.doSpecial(p, p.face);
      return p.mvName;
    });
    await arena(ch, lvl6);
    const b = await t.ev(() => {
      const r = window.__rc, p = r.G.player;
      p.meter = 1; r.doSpecial(p, p.face);
      return p.mvName;
    });
    check(`${ch} mastery 6 upgrades the forward special (${base} -> ${plus})`, a === base && b === plus, `${a} then ${b}`);
  }

  // the upgraded special really is stronger
  o = await t.ev(() => {
    const r = window.__rc;
    const sum = n => r.MOVES[n].hits.reduce((a, h) => a + h.dmg, 0);
    return { f: sum('specialF'), fp: sum('specialFP'), q: sum('kquake'), qp: sum('kquakeP') };
  });
  check('the upgraded specials hit harder than the originals', o.fp > o.f && o.qp > o.q, JSON.stringify(o));

  // move list shows them once earned
  o = await t.ev(() => {
    const r = window.__rc;
    const out = {};
    for (const id of ['cole', 'anita', 'tank', 'jett']) {
      const m = r.MASTERY_BY_CHAR[id];
      out[id] = [m[3].live, m[4].live, m[5].live, !m[6].live];
    }
    return out;
  });
  check('mastery 4, 5 and 6 are marked live for every fighter; 7+ still to come',
    Object.values(o).every(v => v.every(Boolean)), JSON.stringify(o));

  console.log(results.map(r => `${r[0]}  ${r[1]}  ${r[2]}`).join('\n'));
  const fail = results.filter(r => r[0] === 'FAIL').length;
  console.log(`\n${results.length - fail}/${results.length} passed`);
  console.log(t.errors.length ? t.errors.slice(0, 6).join('\n') : 'no errors');
  await t.close();
  process.exit(fail ? 1 : 0);
})();
