// Same cast and layout as the old build-4 sheet, for a true before/after.
const { launch } = require('./harness');
const ROWS = [
  [['cole','idle'],['anita','aIdle'],['coleCPU','idle'],['anitaCPU','aIdle'],['vex','aIdle'],['brick','heavyIdle'],['rivet','idle']],
  [['punkA','idle'],['punkB','idle'],['punkC','idle'],['bladeA','idle'],['bladeB','idle'],['kickerA','aIdle'],['kickerB','idle']],
];
const N = { cole:'COLE', anita:'ANITA', coleCPU:'CPU COLE', anitaCPU:'CPU ANITA', vex:'VEX', brick:'BIG BRICK', rivet:'RIVET',
  punkA:'PUNK', punkB:'PUNK', punkC:'PUNK', bladeA:'BLADE', bladeB:'BLADE', kickerA:'KICKER', kickerB:'KICKER' };
(async () => {
  const t = await launch();
  await t.ev(([rows, names]) => {
    const c = window.__rc.ctx;
    c.setTransform(PX, 0, 0, PX, 0, 0);
    c.fillStyle = '#16141f'; c.fillRect(0, 0, 426, 240);
    rows.forEach((row, ri) => row.forEach(([l, p], i) => {
      const x = 30 + i * 57, y = 105 + ri * 117;
      drawFigure(x, y, 1, p, window.__rc.LOOKS[l], { scale: 0.86 });
      text(names[l] || l, x, y + 4, '#c8c4dc', 1, 1);
    }));
  }, [ROWS, N]);
  await t.grab('castmatch');
  console.log(t.errors.slice(0, 3).join('\n') || 'ok');
  await t.close();
})();
