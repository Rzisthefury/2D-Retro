// Stamp head vs constructed head, magnified.
const { launch } = require('./harness');
const SET = (process.argv[2] || 'cole,anita,punkA,tank,jett,brick,vex,rivet').split(',');
(async () => {
  const t = await launch();
  await t.ev((set) => {
    const c = window.__rc.ctx;
    c.setTransform(PX, 0, 0, PX, 0, 0);
    c.fillStyle = '#16141f'; c.fillRect(0, 0, 426, 240);
    c.imageSmoothingEnabled = false;
    const step = Math.floor(420 / set.length);
    set.forEach((id, i) => {
      const look = window.__rc.LOOKS[id];
      const J = solvePose(POSES.idle, look);
      [0, 1].forEach(mode => {
        const H = Object.assign({}, J, { head: [0, 0], headA: 0 });
        const R = (J.hr || 7) * 2.6;
        const f = bakeGeneric(look, [-R, -R * 1.25, R, R * 1.1], gg => {
          if (mode) paintHead(gg, look, H);
          else paintStamp(gg, look, look.head, 0, 0, J.hs);
        });
        const Z = 3, x = step / 2 + i * step, y = 62 + mode * 112;
        c.drawImage(f.cv, 0, 0, f.w, f.h, x - f.ox * Z / PX, y - f.oy * Z / PX, f.w * Z / PX, f.h * Z / PX);
      });
      text(id.toUpperCase().slice(0, 7), step / 2 + i * step, 106, '#c8c4dc', 1, 1);
    });
    text('STAMP  (12x14, HAND PIXELED)', 6, 8, '#8a86a0', 1, 0);
    text('CONSTRUCTED  (SKULL + JAW + HAIR MASS)', 6, 118, '#8a86a0', 1, 0);
  }, SET);
  await t.grab('headcmp');
  console.log(t.errors.slice(0, 4).join('\n') || 'ok');
  await t.close();
})();
