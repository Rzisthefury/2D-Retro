// Regression tests for the two bugs Michael reported:
//  1. kickers timing jump kicks onto the hero's wake-up, an inescapable loop
//  2. an enemy hit mid-air stays frozen in the air forever
const { launch } = require('./harness');
const results = [];
function check(name, ok, info = '') { results.push([ok ? 'PASS' : 'FAIL', name, info]); }

(async () => {
  const t = await launch();
  await t.ev(() => {
    const r = window.__rc;
    // A clean stage-1 arena with no waves, so only the enemies we place exist.
    window.arena = (diff = 1) => {
      r.startRun({ mode: 'story', diff, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 });
      r.go('play');
      const G = r.G;
      G.loadQ = []; G.fade = 0; G.fadeDir = 0; G.banner = null;
      G.ents = G.ents.filter(e => e.team === 'hero');
      G.spawnQ = []; G.wave = null; G.waveIdx = 99; G.lockX = null;
      G.player.x = G.camX + 150; G.player.y = 190; G.player.state = 'stand'; G.player.z = 0;
      window.hold = {}; window.persist = {};
      r.setIntent(() => { const I = Object.assign({ mx: 0, my: 0 }, window.hold); window.hold = Object.assign({}, window.persist); return I; });
      return G;
    };
    window.run = n => { for (let i = 0; i < n; i++) r.tick(); };
  });

  let o;

  // ---- BUG 1: the jump-kick wake-up loop -------------------------------------
  // Two kickers on Mania, the worst case, left to work on a player who never
  // fights back. Before the fix the player never got a standing frame back.
  o = await t.ev(() => {
    const G = arena(3), r = __rc, p = G.player;
    p.hp = 99999; p.maxHp = 99999;                    // survive long enough to measure
    for (let i = 0; i < 2; i++) {
      const e = r.spawnEnemy('kicker', p.x + (i ? 90 : -90), p.y + (i ? 4 : -4), i ? -1 : 1);
      e.enter = false; e.hp = 99999; e.maxHp = 99999;
    }
    let downFrames = 0, standFrames = 0, longestPinned = 0, pinned = 0, knockdowns = 0, wasDown = false;
    let up = 0, minGap = 9999;                        // standing frames between knockdowns
    for (let i = 0; i < 1800; i++) {                  // 30 seconds
      r.tick();
      const down = ['fall', 'down', 'getup'].includes(p.state);
      if (down) {
        downFrames++; pinned++;
        if (!wasDown) { knockdowns++; if (knockdowns > 1) minGap = Math.min(minGap, up); up = 0; }
      } else { standFrames++; up++; longestPinned = Math.max(longestPinned, pinned); pinned = 0; }
      wasDown = down;
    }
    longestPinned = Math.max(longestPinned, pinned);
    return { downFrames, standFrames, longestPinned, knockdowns, minGap };
  });
  // A single knockdown can run long on its own: a hit landing on someone already
  // falling juggles them (up to the two-hit juggle cap), which restarts the arc
  // before the 42-frame down and 22-frame getup even begin. So the cap here is
  // generous - it is there to catch an unbounded pin, not to police one bad
  // knockdown. The property that actually proves the loop is dead is minGap.
  check('two Mania kickers cannot pin the player on the floor', o.longestPinned < 400, JSON.stringify(o));
  // The hard anti-loop property is the one above (never pinned for longer than a
  // single knockdown cycle). This is the softer companion: whatever the dice do,
  // there is always a real standing stretch between knockdowns. 30 frames is half
  // a second - impossible if a loop existed, where the gap collapses to nothing.
  check('every knockdown gives the player a real turn back', o.minGap >= 30, JSON.stringify(o));

  // A kicker must not launch a jump kick at a target who is already down.
  o = await t.ev(() => {
    const G = arena(3), r = __rc, p = G.player;
    const e = r.spawnEnemy('kicker', p.x + 90, p.y, -1);
    e.enter = false;
    p.state = 'down'; p.st = 0; p.hp = 99999;         // held on the floor the whole time
    let launched = 0;
    for (let i = 0; i < 400; i++) { p.state = 'down'; p.st = 0; e.ai.cool = 0; e.ai.tok = true; e.ai.tokT = 300; r.tick(); if (e.state === 'jkick') launched++; }
    return { launched };
  });
  check('no jump kick is launched at a downed player', o.launched === 0, JSON.stringify(o));

  // The wake guard itself: a second knockdown in quick succession is degraded.
  o = await t.ev(() => {
    const G = arena(1), r = __rc, p = G.player;
    p.hp = 99999; p.maxHp = 99999;
    const e = r.spawnEnemy('punk', p.x + 200, p.y, -1);
    e.enter = false;
    const K = { dmg: 5, type: 'K', kx: 3, kz: 3 };
    r.applyHit(e, p, K);                              // knocked down from standing: normal
    const first = p.state;
    while (p.state !== 'stand') r.tick();
    const guard = p.wakeGuard;
    r.applyHit(e, p, K);                              // straight away on the wake-up
    const second = p.state;
    return { first, second, guard };
  });
  check('a knockdown from standing still knocks down', o.first === 'fall', JSON.stringify(o));
  check('standing up arms the wake guard', o.guard > 0, JSON.stringify(o));
  check('the guard turns a wake-up knockdown into a stun, not a fall', o.second === 'hurt', JSON.stringify(o));

  // ...and it is not permanent immunity: it burns on use and re-arms only on a chain.
  o = await t.ev(() => {
    const G = arena(1), r = __rc, p = G.player;
    p.hp = 99999; p.maxHp = 99999;
    const e = r.spawnEnemy('punk', p.x + 200, p.y, -1);
    e.enter = false;
    const K = { dmg: 5, type: 'K', kx: 3, kz: 3 };
    r.applyHit(e, p, K);
    while (p.state !== 'stand') r.tick();
    r.applyHit(e, p, K);                              // degraded, burns the guard
    const afterBurn = p.wakeGuard;
    const hp0 = p.hp;
    r.applyHit(e, p, K);                              // guard is gone: knocks down again
    return { afterBurn, third: p.state, tookDamage: p.hp < hp0 };
  });
  check('the guard is spent when it is used, so it is not free immunity', o.afterBurn === 0 && o.third === 'fall', JSON.stringify(o));
  check('a guarded hit still costs health', o.tookDamage, JSON.stringify(o));

  // Once the guard window passes, knockdowns behave exactly as before.
  o = await t.ev(() => {
    const G = arena(1), r = __rc, p = G.player;
    p.hp = 99999; p.maxHp = 99999;
    const e = r.spawnEnemy('punk', p.x + 300, p.y, -1);
    e.enter = false;
    r.applyHit(e, p, { dmg: 5, type: 'K', kx: 3, kz: 3 });
    while (p.state !== 'stand') r.tick();
    for (let i = 0; i < 120; i++) r.tick();           // let the window lapse
    const guard = p.wakeGuard;
    r.applyHit(e, p, { dmg: 5, type: 'K', kx: 3, kz: 3 });
    return { guard, state: p.state };
  });
  check('after the window lapses a knockdown knocks down again', o.guard === 0 && o.state === 'fall', JSON.stringify(o));

  // ---- BUG 2: enemies stuck floating ----------------------------------------
  // The exact repro: hit a kicker mid jump-kick with a light, non-knockdown hit.
  o = await t.ev(() => {
    const G = arena(1), r = __rc, p = G.player;
    const e = r.spawnEnemy('kicker', p.x + 100, p.y, -1);
    e.enter = false;
    e.state = 'jkick'; e.st = 0; e.vz = 4.6; e.vx = -3.1; e.z = 0.1; e.hitIds = {};
    r.run ? 0 : 0;
    for (let i = 0; i < 14; i++) __rc.tick();          // let him get well off the ground
    const airborne = e.z;
    r.applyHit(p, e, { dmg: 3, type: 'L' });           // the light hit that used to freeze him
    const stateAfter = e.state;
    for (let i = 0; i < 240; i++) __rc.tick();
    return { airborne, stateAfter, z: e.z, state: e.state };
  });
  check('a kicker is genuinely airborne mid jump kick', o.airborne > 10, JSON.stringify(o));
  check('hitting an airborne enemy drops him instead of freezing him', o.stateAfter === 'fall', JSON.stringify(o));
  check('he ends up on the ground, not floating', o.z === 0, JSON.stringify(o));

  // The same for a medium hit, and for an enemy parked in the air by any means.
  o = await t.ev(() => {
    const G = arena(1), r = __rc, p = G.player;
    const e = r.spawnEnemy('punk', p.x + 100, p.y, -1);
    e.enter = false;
    e.state = 'ai'; e.z = 60; e.vz = 0;                // force the broken state directly
    for (let i = 0; i < 240; i++) __rc.tick();
    return { z: e.z, state: e.state };
  });
  check('safety net: an enemy left in the air in a walking state falls', o.z === 0, JSON.stringify(o));

  // No enemy anywhere should be airborne in a grounded state after a long brawl.
  o = await t.ev(() => {
    const G = arena(2), r = __rc, p = G.player;
    p.hp = 99999; p.maxHp = 99999;
    for (const type of ['kicker', 'kicker', 'punk', 'blade']) {
      const e = r.spawnEnemy(type, p.x + 80 + Math.random() * 60, p.y, -1);
      e.enter = false; e.hp = 99999; e.maxHp = 99999;
    }
    let floaters = 0;
    const ground = ['ai', 'move', 'hurt', 'land', 'pickup', 'stand'];
    for (let i = 0; i < 1500; i++) {
      window.hold = i % 7 === 0 ? { atk: true } : {};
      r.tick();
      for (const e of __rc.G.ents) if (e.team === 'foe' && e.z > 1 && ground.includes(e.state)) floaters++;
    }
    return { floaters };
  });
  check('a long brawl leaves nobody hovering', o.floaters === 0, JSON.stringify(o));

  const bad = results.filter(r => r[0] === 'FAIL');
  for (const [s, n, i] of results) console.log(s, ' ', n, ' ', i);
  console.log(`${results.length - bad.length}/${results.length} passed`);
  const errs = t.errors;
  console.log(errs.length ? 'PAGE ERRORS:\n' + errs.join('\n') : 'no errors');
  await t.close();
  process.exit(bad.length || errs.length ? 1 : 0);
})();
