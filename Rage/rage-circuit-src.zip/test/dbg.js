const { launch } = require('./harness');
(async () => {
  const t = await launch();
  const out = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 });
    r.go('play');
    const res = [];
    for (let k = 0; k < 600; k++) { r.tick(); if (k % 60 === 0) res.push(r.G.ents.map(e => [e.kind, e.state, e.enter, Math.round(e.x), Math.round(e.y), e.ai && e.ai.tok, e.ai && e.ai.cool, e.pose].join(',')).join(' | ')); }
    return res;
  });
  console.log(out.join('\n'));
  console.log(t.errors.join('\n') || 'no errors');
  await t.close();
})();
