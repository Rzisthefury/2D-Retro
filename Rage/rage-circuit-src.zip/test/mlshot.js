const { launch } = require('./harness');
(async () => {
  const t = await launch();
  for (const ch of ['tank', 'jett', 'cole']) {
    await t.ev(c => {
      const r = window.__rc;
      r.SAVE().chars[c].xp = 9600;
      r.SAVE().chars[c].moves = r.SHOP_MOVES[c].map(m => m.id);
      r.startRun({ mode: 'story', diff: 1, classic: false, char: c, partner: false, stage: 1 });
      r.G.loadQ = [];
      r.go('movelist', { back: 'pause' });
      r.tick();
    }, ch);
    await t.ev(() => window.__rc.render());
    await t.page.locator('#cv').screenshot({ path: `shots/ml_${ch}.png` });
  }
  console.log(t.errors.slice(0, 4).join('\n') || 'no errors');
  await t.close();
})();
