// The on-screen controls for playing on a phone.
//
// Worth its own suite because a touch bug is invisible everywhere else: every
// other test drives Input.keys directly, so the whole touch layer could be
// dead and 236 checks would still pass. These drive real pointer events at the
// real elements and then look at what the game did.
//
// The context is an iPhone-ish landscape viewport with a touchscreen, which is
// what makes the controls appear in the first place.
const { launch } = require('./harness');

(async () => {
  const t = await launch({ context: { viewport: { width: 844, height: 390 }, hasTouch: true, isMobile: true } });
  let pass = 0, fail = 0;
  const ok = (name, cond, info) => {
    if (cond) { pass++; console.log('PASS ', name, info === undefined ? '' : JSON.stringify(info)); }
    else { fail++; console.log('FAIL ', name, JSON.stringify(info)); }
  };

  // Dispatch real PointerEvents at the real handlers. Separate pointerIds are
  // what let a thumb on the stick and a thumb on a button coexist.
  await t.ev(() => {
    window.__t = {
      ev(sel, type, x, y, id) {
        const el = typeof sel === 'string' ? document.querySelector(sel) : sel;
        el.dispatchEvent(new PointerEvent(type, {
          pointerId: id, clientX: x, clientY: y, bubbles: true, cancelable: true, isPrimary: id === 1,
        }));
      },
      // where the stick zone's middle is, and the centre of a named button
      zoneMid() { const r = document.getElementById('tzone').getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height * 0.7 }; },
      btn(act) { return document.querySelector(`.tbtn[data-act="${act}"]`); },
      // start the stick at its zone middle, then push it by (dx, dy)
      stick(dx, dy) {
        const m = this.zoneMid();
        this.ev('#tzone', 'pointerdown', m.x, m.y, 7);
        this.ev('#tzone', 'pointermove', m.x + dx, m.y + dy, 7);
      },
      stickUp() { const m = this.zoneMid(); this.ev('#tzone', 'pointerup', m.x, m.y, 7); },
      hold(act, id) { const b = this.btn(act) || document.getElementById('tpause');
        const r = b.getBoundingClientRect();
        this.ev(b, 'pointerdown', r.left + r.width / 2, r.top + r.height / 2, id || 3); },
      lift(act, id) { const b = this.btn(act) || document.getElementById('tpause');
        const r = b.getBoundingClientRect();
        this.ev(b, 'pointerup', r.left + r.width / 2, r.top + r.height / 2, id || 3); },
    };
  });

  // ---- they show up, and they are out of the way -------------------------
  const vis = await t.ev(() => ({
    on: Touch.on, mode: Touch.mode,
    bodyClass: document.body.classList.contains('touch'),
    display: getComputedStyle(document.getElementById('tc')).display,
    hintHidden: getComputedStyle(document.getElementById('hint')).display === 'none',
  }));
  ok('the controls appear on a touch screen', vis.on && vis.bodyClass && vis.display !== 'none', vis);
  ok('they land in the side bars, not over the picture', vis.mode === 'bars', vis);
  ok('the keyboard hint line is hidden on a phone', vis.hintHidden, vis);

  // In bars mode nothing interactive may overlap the canvas. This is the whole
  // point of the layout Michael picked, and it is easy to break by nudging a
  // width, so it gets measured rather than eyeballed.
  const geom = await t.ev(() => {
    const c = document.getElementById('cv').getBoundingClientRect();
    const over = [];
    // #tring and #tzone are exempt: the ring only exists under your thumb while
    // you are touching, and the zone is an invisible capture region that reaches
    // a little over the picture on purpose, for thumb reach.
    for (const el of document.querySelectorAll('#tbtns .tbtn, #tpause')) {
      const r = el.getBoundingClientRect();
      const hit = r.right > c.left + 1 && r.left < c.right - 1 && r.bottom > c.top + 1 && r.top < c.bottom - 1;
      if (hit) over.push((el.dataset.act || el.id) + ' ' + JSON.stringify({ l: Math.round(r.left), r: Math.round(r.right) }));
    }
    return { canvas: { l: Math.round(c.left), r: Math.round(c.right) }, over };
  });
  ok('no button overlaps the canvas in bars mode', geom.over.length === 0, geom);

  // Reach: the buttons you press constantly have to be nearest the corner the
  // thumb rests in, and all of them have to be reachable at all. The first
  // version stacked them up the whole screen with attack at the very top.
  const reach = await t.ev(() => {
    const mid = a => { const r = document.querySelector(`.tbtn[data-act="${a}"]`).getBoundingClientRect();
      return { y: r.top + r.height / 2, top: r.top }; };
    return { atk: mid('attack'), jmp: mid('jump'), roll: mid('dodge'), bck: mid('back'),
             h: window.innerHeight,
             pause: document.getElementById('tpause').getBoundingClientRect(),
             atkBox: document.querySelector('.tbtn[data-act="attack"]').getBoundingClientRect() };
  });
  ok('attack sits nearest the thumb, back attack furthest',
    reach.atk.y > reach.jmp.y && reach.jmp.y > reach.bck.y, 
    { atk: Math.round(reach.atk.y), jmp: Math.round(reach.jmp.y), bck: Math.round(reach.bck.y) });
  ok('the roll is in the easy-reach half of the cluster',
    reach.roll.y > reach.bck.y, { roll: Math.round(reach.roll.y), bck: Math.round(reach.bck.y) });
  ok('every button is inside the screen',
    reach.bck.top >= 0 && reach.atk.y < reach.h, { bckTop: Math.round(reach.bck.top), h: reach.h });
  // the pause button used to land straight on top of attack
  const pb = reach.pause, ab = reach.atkBox;
  ok('the pause button does not sit on another button',
    !(pb.right > ab.left && pb.left < ab.right && pb.bottom > ab.top && pb.top < ab.bottom),
    { pause: { l: Math.round(pb.left), t: Math.round(pb.top) }, atk: { l: Math.round(ab.left), t: Math.round(ab.top) } });

  // ---- get into a fight --------------------------------------------------
  await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 });
    r.go('play');
    for (let i = 0; i < 6000 && r.G.loadQ.length; i++) r.tick();
  });
  const tick = n => t.ev(k => { for (let i = 0; i < k; i++) window.__rc.tick(); }, n);

  // ---- the stick moves you ----------------------------------------------
  const move = await t.ev(async () => {
    const G = window.__rc.G, p = G.player;
    const x0 = p.x;
    window.__t.stick(34, 0);                      // push right, inside the run threshold
    for (let i = 0; i < 12; i++) window.__rc.tick();
    const out = { heldRight: Input.held.right, moved: p.x - x0, state: p.state };
    window.__t.stickUp();
    for (let i = 0; i < 2; i++) window.__rc.tick();
    out.releasedHeld = Input.held.right;
    return out;
  });
  ok('pushing the stick right walks right', move.heldRight && move.moved > 0, move);
  ok('letting go stops you', move.releasedHeld === false, move);

  const diag = await t.ev(() => {
    window.__t.stick(-26, -26);
    window.__rc.tick();
    const out = { left: Input.held.left, up: Input.held.up };
    window.__t.stickUp(); window.__rc.tick();
    return out;
  });
  ok('a diagonal gives both directions', diag.left && diag.up, diag);

  // ---- push it to the edge and you run ----------------------------------
  // Michael asked to keep run on a double tap; double tapping a stick you are
  // already holding is awkward, so the edge runs too. Both routes end up in
  // Input.dbl, which is what the fight code reads.
  const run = await t.ev(() => {
    const p = window.__rc.G.player;
    p.state = 'stand'; p.st = 0;
    window.__t.stick(50, 0);                      // hard right, past TOUCH_RUN
    let sawRun = false, sawDbl = false;
    for (let i = 0; i < 10; i++) {
      window.__rc.tick();
      if (Input.dbl.right) sawDbl = true;
      if (p.state === 'run') sawRun = true;
    }
    window.__t.stickUp(); window.__rc.tick();
    return { sawRun, sawDbl, state: p.state };
  });
  ok('pushing the stick to the edge runs', run.sawRun && run.sawDbl, run);

  const noRun = await t.ev(() => {
    const p = window.__rc.G.player;
    p.state = 'stand'; p.st = 0;
    window.__t.stick(30, 0);                      // a gentle push must NOT run
    let sawRun = false;
    for (let i = 0; i < 10; i++) { window.__rc.tick(); if (p.state === 'run') sawRun = true; }
    window.__t.stickUp(); window.__rc.tick();
    return { sawRun };
  });
  ok('a gentle push walks rather than runs', noRun.sawRun === false, noRun);

  // ---- the buttons -------------------------------------------------------
  const atk = await t.ev(() => {
    const p = window.__rc.G.player;
    p.state = 'stand'; p.st = 0;
    window.__t.hold('attack');
    let sawAttack = false;
    for (let i = 0; i < 6; i++) { window.__rc.tick(); if (p.state === 'move') sawAttack = true; }
    window.__t.lift('attack');
    for (let i = 0; i < 2; i++) window.__rc.tick();
    return { sawAttack, held: Input.held.attack, state: p.state };
  });
  ok('the attack button throws a punch', atk.sawAttack, atk);

  // A tap that begins and ends inside one frame gap would be dropped entirely
  // without the latch, and it is exactly what a fast player does.
  const quick = await t.ev(() => {
    const p = window.__rc.G.player;
    p.state = 'stand'; p.st = 0;
    window.__t.hold('attack', 11);
    window.__t.lift('attack', 11);                // down and up with no tick between
    let sawAttack = false;
    for (let i = 0; i < 6; i++) { window.__rc.tick(); if (p.state === 'move') sawAttack = true; }
    return { sawAttack };
  });
  ok('a tap between two frames is not dropped', quick.sawAttack, quick);

  const jump = await t.ev(() => {
    const p = window.__rc.G.player;
    p.state = 'stand'; p.st = 0; p.z = 0;
    window.__t.hold('jump');
    let airborne = false;
    for (let i = 0; i < 12; i++) { window.__rc.tick(); if (p.z > 1) airborne = true; }
    window.__t.lift('jump');
    for (let i = 0; i < 20; i++) window.__rc.tick();
    return { airborne };
  });
  ok('the jump button gets you off the ground', jump.airborne, jump);

  // ---- the dodge button --------------------------------------------------
  // The roll only happens when the held direction matches the double tap, so
  // the button has to supply both. Centred stick means roll toward the camera.
  const roll = await t.ev(() => {
    const p = window.__rc.G.player;
    p.state = 'stand'; p.st = 0; p.z = 0;
    window.__t.hold('dodge');
    let sawRoll = false, dir = 0;
    for (let i = 0; i < 6; i++) { window.__rc.tick(); if (p.state === 'roll') { sawRoll = true; dir = p.rollDir; } }
    window.__t.lift('dodge');
    for (let i = 0; i < 20; i++) window.__rc.tick();
    return { sawRoll, dir };
  });
  ok('the dodge button rolls, toward the camera by default', roll.sawRoll && roll.dir === 1, roll);

  const rollUp = await t.ev(() => {
    const p = window.__rc.G.player;
    p.state = 'stand'; p.st = 0; p.z = 0;
    window.__t.stick(0, -40);                     // leaning away from the camera
    window.__rc.tick();
    window.__t.hold('dodge');
    let dir = 0;
    for (let i = 0; i < 6; i++) { window.__rc.tick(); if (p.state === 'roll') dir = p.rollDir; }
    window.__t.lift('dodge'); window.__t.stickUp();
    for (let i = 0; i < 20; i++) window.__rc.tick();
    return { dir };
  });
  ok('leaning the stick rolls that way instead', rollUp.dir === -1, rollUp);

  // ---- two thumbs at once ------------------------------------------------
  const both = await t.ev(() => {
    const G = window.__rc.G, p = G.player;
    p.state = 'stand'; p.st = 0;
    const x0 = p.x;
    window.__t.stick(34, 0);
    window.__t.hold('attack', 21);
    let sawAttack = false;
    for (let i = 0; i < 8; i++) { window.__rc.tick(); if (p.state === 'move') sawAttack = true; }
    const out = { moved: p.x - x0, sawAttack, bothHeld: Input.held.right && Input.held.attack };
    window.__t.lift('attack', 21); window.__t.stickUp();
    for (let i = 0; i < 2; i++) window.__rc.tick();
    return out;
  });
  ok('stick and a button work at the same time', both.bothHeld && both.sawAttack, both);

  // ---- pause, and menus ---------------------------------------------------
  const pause = await t.ev(() => {
    window.__t.hold('start');
    for (let i = 0; i < 3; i++) window.__rc.tick();
    window.__t.lift('start');
    for (let i = 0; i < 2; i++) window.__rc.tick();
    return { screen: window.__rc.SCREEN };
  });
  ok('the pause button pauses', pause.screen === 'pause', pause);

  // The existing menus read confirm/cancel, so attack and special have to feed
  // those or the game is unplayable on a phone past the title screen.
  const menu = await t.ev(() => {
    const before = window.__rc.S.cur;
    window.__t.stick(0, 40);                       // down
    for (let i = 0; i < 4; i++) window.__rc.tick();
    const moved = window.__rc.S.cur !== before;
    window.__t.stickUp(); window.__rc.tick();
    window.__t.hold('special');                    // cancel gets you out
    for (let i = 0; i < 3; i++) window.__rc.tick();
    window.__t.lift('special');
    for (let i = 0; i < 2; i++) window.__rc.tick();
    return { moved, screen: window.__rc.SCREEN };
  });
  ok('the stick moves a menu cursor', menu.moved, menu);
  ok('special cancels out of a menu', menu.screen === 'play', menu);

  // ---- the option turns them off -----------------------------------------
  const off = await t.ev(() => {
    const S = window.__rc.SAVE();
    S.options.touch = 'off'; Touch.apply();
    const hidden = getComputedStyle(document.getElementById('tc')).display === 'none';
    window.__t.stick(50, 0);
    window.__rc.tick();
    const dead = !Input.held.right;
    window.__t.stickUp();
    S.options.touch = 'auto'; Touch.apply(); window.__rc.tick();
    return { hidden, dead, backOn: Touch.on };
  });
  ok('turning touch controls off hides them', off.hidden, off);
  ok('and stops them feeding input', off.dead, off);
  ok('and auto brings them back', off.backOn, off);

  console.log(`${pass}/${pass + fail} passed`);
  console.log(t.errors.length ? 'PAGE ERRORS:\n' + t.errors.join('\n') : 'no errors');
  await t.close();
  process.exit(fail ? 1 : 0);
})();
