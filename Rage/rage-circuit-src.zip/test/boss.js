const { launch } = require('./harness');
const results = [];
function check(name, ok, info = '') { results.push([ok ? 'PASS' : 'FAIL', name, info]); }
(async () => {
  const t = await launch();
  await t.ev(() => {
    const r = window.__rc;
    window.bossArena = (diff = 1, skipIntro = true) => {
      r.startRun({ mode: 'story', diff, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 });
      r.go('play');
      r.loadScene(1, false);
      const G = r.G;
      G.loadQ = [];
      G.fade = 0; G.fadeDir = 0; G.banner = null;
      G.ents = G.ents.filter(e => e.team === 'hero');
      G.waveIdx = 3; G.camX = 894;
      G.player.x = 894 + 150; G.player.y = 190; G.player.state = 'stand'; G.player.z = 0;
      window.hold = {}; window.persist = {};
      r.setIntent(() => { const I = Object.assign({ mx: 0, my: 0 }, window.hold); window.hold = Object.assign({}, window.persist); return I; });
      for (let i = 0; i < 3; i++) r.tick();
      const b = G.boss;
      if (skipIntro) { b.state = 'bidle'; b.st = 0; b.x = G.camX + 300; b.boss.cool = 9999; G.banner = null; }
      window.boss = b;
      return b;
    };
    window.run = n => { for (let i = 0; i < n; i++) r.tick(); };
  });
  let o;
  o = await t.ev(() => { const b = bossArena(1, false); const G = __rc.G; let hits = 0; for (let i = 0; i < 150; i++) { if (canBeHit(b)) hits++; __rc.tick(); } return { hits, banner: G.banner && G.banner.s, st: b.state }; });
  check('boss intro: no damage window, name banner shown', o.hits === 0 && o.banner === 'BIG BRICK HARLAN', JSON.stringify(o));
  // charge: tell then wall daze
  o = await t.ev(() => { const b = bossArena(1); const G = __rc.G; G.player.x = G.camX + 60; G.player.y = 200; b.x = G.camX + 330; b.y = 170; b.state = 'bchargeTell'; b.st = 0; const seq = []; let tell = 0; for (let i = 0; i < 160; i++) { __rc.tick(); if (b.state === 'bchargeTell') tell++; if (seq[seq.length - 1] !== b.state) seq.push(b.state); } return { seq, tell, dy: Math.abs(b.y - G.player.y), dmg: G.dmgTaken, pst: G.player.state }; });
  check('charge has a 48-frame tell on Medium and re-aims its lane', o.tell >= 47 && o.seq[1] === 'bcharge', JSON.stringify(o));
  check('charge into the wall leaves him dazed', o.seq.includes('dazed'), o.seq.join('>'));
  check('charge hits the player in its lane', o.dmg === 16, JSON.stringify(o));
  // slam
  o = await t.ev(() => { const b = bossArena(1); const G = __rc.G; G.player.x = b.x - 40; G.player.y = b.y; b.face = -1; b.state = 'bslamTell'; b.st = 0; run(60); const grounded = G.dmgTaken; bossArena(1); const G2 = __rc.G; G2.player.x = window.boss.x - 40; G2.player.y = window.boss.y; window.boss.face = -1; window.boss.state = 'bslamTell'; window.boss.st = 0; run(33); window.hold = { jump: true }; run(30); return { grounded, jumped: G2.dmgTaken }; });
  check('slam knocks down grounded players (16 dmg)', o.grounded === 16, JSON.stringify(o));
  check('jumping over the slam avoids it', o.jumped === 0, JSON.stringify(o));
  // daze -> grab -> screen throw
  o = await t.ev(() => { const b = bossArena(1); const G = __rc.G, p = G.player; b.state = 'dazed'; b.st = 0; b.dazeLeft = 150; b.x = p.x + 44; b.y = p.y; window.persist = { mx: 1 }; run(20); window.persist = {}; const g = p.state; const hp0 = b.hp; window.hold = { back: true }; run(1); const states = []; for (let i = 0; i < 160; i++) { __rc.tick(); if (states[states.length - 1] !== b.state) states.push(b.state); } return { g, dmg: hp0 - b.hp, max: b.maxHp, states }; });
  check('dazed boss can be grabbed', o.g === 'grab', JSON.stringify(o));
  check('screen-throwing the boss deals 16% + 10', o.dmg === Math.round(10 + o.max * 0.16), JSON.stringify(o));
  check('boss drops back in from the top', o.states.join('>').includes('screen>fall>down'), o.states.join('>'));
  o = await t.ev(() => { const b = bossArena(1); const G = __rc.G, p = G.player; b.x = p.x + 44; b.y = p.y; window.persist = { mx: 1 }; run(30); window.persist = {}; return p.state; });
  check('non-dazed boss cannot be grabbed', o !== 'grab', o);
  // stagger into daze
  o = await t.ev(() => { const b = bossArena(1); const G = __rc.G, p = G.player; b.boss.cool = 9999; let st = []; for (let i = 0; i < 20; i++) { applyHit(p, b, { dmg: 5, type: 'H' }); b.hitstop = 0; if (!st.includes(b.state)) st.push(b.state); } return st; });
  check('sustained damage staggers him into a daze', o.includes('dazed'), o.join());
  // pole phase
  o = await t.ev(() => { const b = bossArena(1); const G = __rc.G; b.hp = Math.floor(b.maxHp * 0.5); b.boss.cool = 0; const st = []; for (let i = 0; i < 90; i++) { __rc.tick(); if (st[st.length - 1] !== b.state) st.push(b.state); } const w = b.weapon && b.weapon.kind; b.state = 'bidle'; applyHit(G.player, b, { dmg: 12, type: 'K', kx: 2, kz: 3 }); const items = G.items.map(i => i.kind); return { st, w, after: b.weapon, items }; });
  check('at 50% HP he roars and rips out a lamppost', o.st[0] === 'broar' && o.w === 'pole', JSON.stringify(o));
  check('knocking him down drops the pole as a pipe', !o.after && o.items.includes('pipe'), JSON.stringify(o));
  o = await t.ev(() => { const b = bossArena(2); b.hp = Math.floor(b.maxHp * 0.58); b.boss.cool = 0; run(3); return b.state; });
  check('hard: pole phase starts at 60%', o === 'broar', o);
  o = await t.ev(() => { const b = bossArena(3); const G = __rc.G; b.hp = Math.floor(b.maxHp * 0.58); b.boss.cool = 0; run(80); const punks = G.ents.filter(e => e.type === 'punk').length; b.state = 'bslamTell'; b.st = 0; run(40); return { punks, waves: G.projs.filter(p => p.kind === 'wave').length }; });
  check('mania: 2 punks join, slam sends 2 shockwaves', o.punks === 2 && o.waves === 2, JSON.stringify(o));
  // grab + pile driver
  o = await t.ev(() => { const b = bossArena(1); const G = __rc.G, p = G.player; b.x = p.x + 30; b.face = -1; startMove(b, 'eReach'); run(20); const held = p.state; run(60); return { held, dmg: G.dmgTaken }; });
  check('boss reach grabs and pile-drives (22)', o.held === 'held' && o.dmg === 22, JSON.stringify(o));
  // telegraph rule: log every damage the boss deals and the states before it
  o = await t.ev(() => {
    const bad = []; let hits = 0;
    for (let trial = 0; trial < 6; trial++) {
      const b = bossArena(trial % 4); const G = __rc.G, p = G.player; b.boss.cool = 20;
      const hist = [];
      let lastD = 0;
      for (let i = 0; i < 1800; i++) {
        p.hp = p.maxHp;
        if (p.state === 'dead') break;
        __rc.tick();
        hist.push(b.state + ':' + (b.mvName || '') + ':' + b.mf);
        if (G.dmgTaken > lastD) {
          lastD = G.dmgTaken; hits++;
          const recent = hist.slice(-80);
          const told = recent.some(h => /bchargeTell|bslamTell|broar/.test(h)) || recent.some(h => /^move:(bPunch|bHook|bPole|eReach):(9|1[0-9]|2[0-9])$/.test(h)) || recent.some(h => h.startsWith('gslam'));
          if (!told) bad.push(recent.slice(-6).join(' '));
        }
      }
    }
    return { hits, bad: bad.slice(0, 5) };
  });
  check('every boss hit is preceded by a tell', o.hits > 5 && o.bad.length === 0, JSON.stringify(o));
  // defeat -> tally -> save
  o = await t.ev(() => {
    __rc.eraseSave();
    const b = bossArena(1); const G = __rc.G;
    b.hp = 1; applyHit(G.player, b, { dmg: 5, type: 'K', kx: 2, kz: 3 });
    for (let i = 0; i < 600 && __rc.SCREEN === 'play'; i++) __rc.tick();
    const T = __rc.S.T;
    const s = JSON.parse(localStorage.getItem('ragecircuit_save_v1'));
    return { scr: __rc.SCREEN, bank: T && T.bank, sbank: s.bank, reached: s.reached, grade: s.grades['u_1_1'], xp: s.chars.cole.xp, clears: s.stats.clears };
  });
  check('killing the boss clears the stage into the tally', o.scr === 'tally', JSON.stringify(o));
  check('tally banks points and autosaves (bank, reached, grade, xp)', o.bank > 0 && o.sbank === o.bank && o.reached === 2 && !!o.grade && o.xp > 0 && o.clears === 1, JSON.stringify(o));
  o = await t.ev(() => {
    __rc.eraseSave();
    const b = bossArena(1); const G = __rc.G; __rc.CHEAT.onehit = 1; __rc.tick();
    b.hp = 1; applyHit(G.player, b, { dmg: 5, type: 'K', kx: 2, kz: 3 });
    for (let i = 0; i < 600 && __rc.SCREEN === 'play'; i++) __rc.tick();
    __rc.CHEAT.onehit = 0;
    const s = JSON.parse(localStorage.getItem('ragecircuit_save_v1'));
    return { scr: __rc.SCREEN, bank: s.bank, reached: s.reached };
  });
  check('a cheated clear saves and banks nothing', o.scr === 'tally' && o.bank === 0 && o.reached === 1, JSON.stringify(o));
  // grade math
  o = await t.ev(() => { bossArena(1); const G = __rc.G; G.dmgTaken = 0; G.livesLost = 0; G.bestCombo = 25; G.stageFrames = 60 * 60 * 3; const a = __rc.computeGrade().g.g; G.continued = true; const b = __rc.computeGrade().g.g; G.continued = false; G.dmgTaken = 400; G.livesLost = 3; G.bestCombo = 3; G.stageFrames = 60 * 60 * 9; const c = __rc.computeGrade().g.g; return [a, b, c]; });
  check('grades: flawless fast = S, continued caps at C, sloppy = D', o.join() === 'S,C,D', o.join());
  await t.ev(() => { const b = bossArena(1); const G = __rc.G; b.x = G.player.x + 120; b.y = G.player.y - 10; b.state = 'bchargeTell'; b.st = 20; __rc.tick(); });
  await t.shot('boss_charge');
  await t.ev(() => { const b = bossArena(1); const G = __rc.G; b.x = G.player.x + 50; b.state = 'bslamTell'; b.st = 10; __rc.tick(); });
  await t.shot('boss_slam');
  await t.ev(() => { const b = bossArena(1); const G = __rc.G; b.state = 'dazed'; b.st = 30; b.dazeLeft = 99; b.weapon = null; b.x = G.player.x + 60; for (let i = 0; i < 30; i++) __rc.tick(); });
  await t.shot('boss_dazed');
  await t.ev(() => { const b = bossArena(1); const G = __rc.G; b.state = 'dazed'; b.dazeLeft = 150; b.x = G.player.x + 44; b.y = G.player.y; window.persist = { mx: 1 }; run(20); window.persist = {}; window.hold = { back: true }; run(1); run(30); });
  await t.shot('boss_screen');
  await t.ev(() => { const b = bossArena(1); const G = __rc.G; b.weapon = { kind: 'pole', dur: 999 }; b.x = G.player.x + 70; startMove(b, 'bPole'); for (let i = 0; i < 27; i++) __rc.tick(); });
  await t.shot('boss_pole');
  console.log(results.map(r => r.join('  ')).join('\n'));
  console.log(results.filter(r => r[0] === 'PASS').length + '/' + results.length + ' passed');
  console.log(t.errors.slice(0, 5).join('\n') || 'no errors');
  await t.close();
})();
