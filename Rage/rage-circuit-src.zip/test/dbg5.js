const { launch } = require('./harness');
(async () => {
  const t = await launch();
  let o = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 7 });
    r.go('play');
    const G = r.G;
    r.loadScene(2, false); G.loadQ = [];
    const cap = G.props.find(p => p.kind === 'capsule');
    const p = G.player;
    p.x = cap.x - 18; p.y = cap.y; p.face = 1;
    r.startMove(p, 'jab1');
    const log = [];
    for (let k = 0; k < 12; k++) { r.tick(); log.push([p.state, p.mf, Math.round(p.x), Math.round(p.y), cap.broken]); }
    return { cap: { x: cap.x, y: cap.y, broken: cap.broken }, p: { x: p.x, y: p.y, st: p.state }, log, screen: r.SCREEN, fade: G.fade, props: G.props.length };
  });
  console.log('CAPSULE', JSON.stringify(o));
  o = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 8 });
    r.go('play');
    const G = r.G; G.loadQ = [];
    G.scene.waves = []; G.waveIdx = 99; G.wave = null; G.spawnQ = [];
    G.ents = G.ents.filter(e => e.team === 'hero');
    const b = r.spawnBoss(G.camX + 300, 190, 'dray');
    G.loadQ = [];
    for (let i = 0; i < 200; i++) r.tick();
    b.hp = 1;
    r.applyHit(G.player, b, { dmg: 99, type: 'K' });
    const seq = [];
    for (let i = 0; i < 220; i++) { r.tick(); seq.push(b.state); }
    return { defNext: b.def.next, states: [...new Set(seq)], bosses: G.bosses.map(x => [x.def.name, x.killed, x.remove, x.state]) };
  });
  console.log('DRAY', JSON.stringify(o));
  console.log(t.errors.slice(0, 4).join('\n') || 'no errors');
  await t.close();
})();
