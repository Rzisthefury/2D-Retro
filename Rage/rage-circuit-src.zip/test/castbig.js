// Large side-by-side cast sheet for judging the rebuilt anatomy.
const { launch } = require('./harness');
const ROWS = [
  [['cole','idle'],['anita','aIdle'],['tank','kIdle'],['jett','jIdle'],['vex','aIdle'],['unit9','idle']],
  [['punkA','idle'],['punkB','walk2'],['bladeA','idle'],['kickerA','aIdle'],['bruiserA','heavyIdle'],['brick','heavyIdle']],
  [['suitA','idle'],['guardA','idle'],['bikerA','idle'],['robot','idle'],['gauge','heavyIdle'],['dray','idle']],
];
const N = { cole:'COLE', anita:'ANITA', tank:'TANK', jett:'JETT', vex:'VEX', unit9:'UNIT-9',
  punkA:'PUNK', punkB:'PUNK', bladeA:'BLADE', kickerA:'KICKER', bruiserA:'BRUISER', brick:'BRICK',
  suitA:'SUIT', guardA:'GUARD', bikerA:'BIKER', robot:'ROBOT', gauge:'GAUGE', dray:'DRAY' };
(async () => {
  const t = await launch();
  const name = process.argv[2] || 'castbig';
  await t.ev(([rows, names]) => {
    const c = window.__rc.ctx;
    c.setTransform(PX, 0, 0, PX, 0, 0);
    c.fillStyle = '#16141f'; c.fillRect(0, 0, 426, 240);
    rows.forEach((row, ri) => row.forEach(([l, p], i) => {
      const x = 36 + i * 70, y = 76 + ri * 80;
      drawFigure(x, y, 1, p, window.__rc.LOOKS[l], { scale: 0.72 });
      text(names[l] || l, x, y + 3, '#c8c4dc', 1, 1);
    }));
  }, [ROWS, N]);
  await t.grab(name);
  console.log(t.errors.slice(0, 3).join('\n') || 'ok');
  await t.close();
})();
