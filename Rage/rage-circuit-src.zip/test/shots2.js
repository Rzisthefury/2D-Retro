const { launch } = require('./harness');
(async () => {
  const t = await launch();
  const setup = () => t.ev(() => { const r = window.__rc; for (let i = 0; i < 900 && r.G && r.G.loadQ && r.G.loadQ.length; i++) r.tick(); });
  await t.ticks(20); await t.shot('b2_title_boot');
  await t.ev(() => { window.__rc.go('title', { menu: true }); }); await t.ticks(4); await t.shot('b2_title');
  await t.ev(() => { window.__rc.SAVE().bank = 900000; window.__rc.go('shop', { tab: 1, fid: 'anita' }); }); await t.ticks(4); await t.shot('b2_shop_moves');
  await t.ev(() => { window.__rc.go('setup', {}); }); await t.ticks(4);
  await t.ev(() => { window.__rc.S.fighter = 1; }); await t.ticks(4); await t.shot('b2_setup_anita');
  // stage 2 boss
  await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'anita', partner: true, partnerChar: 'cole', allyCmd: 0, stage: 2 });
    r.go('play'); r.loadScene(1, false); const G = r.G; G.fade = 0; G.fadeDir = 0;
    G.camX = 774; G.waveIdx = 2; G.player.x = 850; G.player.y = 190; if (G.ally) { G.ally.x = 830; G.ally.y = 205; }
  });
  await setup();
  await t.ev(() => { for (let i = 0; i < 260; i++) window.__rc.tick(); });
  await t.shot('b2_twins');
  await t.ev(() => { const r = window.__rc; for (let i = 0; i < 400; i++) { r.G.player.hp = r.G.player.maxHp; r.tick(); } });
  await t.shot('b2_twins2');
  // stage 3 mech
  await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 2, classic: false, char: 'cole', partner: true, partnerChar: 'anita', allyCmd: 0, stage: 3 });
    r.go('play'); r.loadScene(1, false); const G = r.G; G.fade = 0; G.fadeDir = 0;
    G.camX = 774; G.waveIdx = 2; G.player.x = 830; G.player.y = 196;
  });
  await setup();
  await t.ev(() => { const r = window.__rc; for (let i = 0; i < 300; i++) { r.G.player.hp = r.G.player.maxHp; r.tick(); } });
  await t.shot('b2_mech');
  await t.ev(() => { const r = window.__rc; const m = r.G.bosses[0]; m.state = 'mflame'; m.st = 1; m.mpose = 'flame'; for (let i = 0; i < 30; i++) { r.G.player.hp = 100; r.tick(); } });
  await t.shot('b2_mech_flame');
  // stage 3 scene 1 with beams + robot
  await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 2, classic: false, char: 'anita', partner: false, allyCmd: 0, stage: 3 });
    r.go('play'); const G = r.G; G.camX = 300; G.player.x = 400;
  });
  await setup();
  await t.ev(() => { const r = window.__rc; const G = r.G; G.hazards.push({ kind: 'beams', every: 200, cd: 2 }); for (let i = 0; i < 260; i++) r.tick(); });
  await t.shot('b2_site');
  // corner breakout
  await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 });
    r.go('play'); const G = r.G; G.loadQ = []; G.waveIdx = 99; G.lockX = 0; G.camX = 0;
    G.ents = G.ents.filter(e => e.team === 'hero');
    const b = r.spawnBoss(380, 190, 'brick'); b.state = 'dazed'; b.dazeLeft = 9999; b.boss.cornerT = 115;
    G.player.x = 330;
    for (let i = 0; i < 12; i++) { applyHit(G.player, b, { dmg: 1, type: 'L' }); b.hitstop = 0; r.tick(); }
  });
  await t.shot('b2_burst');
  console.log(t.errors.slice(0, 3).join('\n') || 'ok');
  await t.close();
})();
