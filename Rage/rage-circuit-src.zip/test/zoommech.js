const { launch } = require('./harness');
(async () => {
  const t = await launch();
  await t.ev(() => {
    const c = window.__rc.ctx;
    c.fillStyle = '#4a4a5e'; c.fillRect(0, 0, 426, 240);
    ['idle', 'clawUp', 'clawDown', 'flame', 'stompUp', 'break'].forEach((p, i) => blitFrame(getMechFrame(p), 36 + i * 72, 230, 1, { scale: 1 }));
    drawFigure(30, 110, 1, 'tIdle', LOOKS.ruby, { scale: 1.4 });
    drawFigure(80, 110, 1, 'tCrouch', LOOKS.onyx, { scale: 1.4 });
    drawFigure(140, 110, 1, 'tSplit', LOOKS.ruby, { scale: 1.4 });
    drawFigure(210, 110, 1, 'wCrack', LOOKS.whipA, { scale: 1.4 });
    drawFigure(260, 110, 1, 'idle', LOOKS.robot, { scale: 1.4 });
    drawFigure(320, 110, 1, 'heavyIdle', LOOKS.rivet, { scale: 1.4 });
    drawFigure(380, 110, 1, 'aFlyKick', LOOKS.anita, { scale: 1.4 });
  });
  await t.page.locator('#cv').screenshot({ path: 'shots/zoom_mech.png' });
  console.log(t.errors.slice(0, 3).join('\n') || 'ok');
  await t.close();
})();
