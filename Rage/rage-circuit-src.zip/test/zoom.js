const { launch } = require('./harness');
const items = JSON.parse(process.argv[2] || '[["cole","idle"],["anita","idle"],["brick","heavyIdle"]]');
const name = process.argv[3] || 'zoom';
(async () => {
  const t = await launch();
  await t.ev((items) => {
    const x = window.__rc, c = x.ctx;
    c.fillStyle = '#4a4a5e'; c.fillRect(0, 0, 426, 240);
    const sc = items.length > 3 ? 2 : 2.6;
    items.forEach(([l, p, w], i) => drawFigure(50 + i * (426 / items.length), 232, 1, p, x.LOOKS[l], { scale: sc, weapon: w }));
  }, items);
  await t.page.locator('#cv').screenshot({ path: `shots/${name}.png` });
  console.log(t.errors.slice(0, 3).join('\n') || 'ok');
  await t.close();
})();
