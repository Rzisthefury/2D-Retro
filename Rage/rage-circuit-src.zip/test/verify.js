const { launch } = require('./harness');
const results = [];
function check(name, ok, info = '') { results.push([ok ? 'PASS' : 'FAIL', name, info]); }
(async () => {
  const t = await launch();
  // helper in page: fresh arena with one enemy next to the player
  await t.ev(() => {
    const r = window.__rc;
    window.arena = (type = 'punk', dx = 26, opts = {}) => {
      r.startRun(Object.assign({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 }, opts));
      r.go('play');
      const G = r.G;
      G.loadQ = [];
      G.scene.waves = G.scene.waves; G.waveIdx = 99; G.wave = null; G.spawnQ = []; G.banner = null;
      G.ents = G.ents.filter(e => e.team === 'hero');
      G.player.x = 150; G.player.y = 190; G.player.face = 1;
      let e = null;
      if (type) { e = r.spawnEnemy(type, 150 + dx, 190, 1); e.enter = false; e.face = -1; e.ai.cool = 9999; e.ai.t = 9999; }
      window.foe = e;
      window.hold = {};
      r.setIntent(p => { const I = Object.assign({ mx: 0, my: 0, atk: false, atkHeld: false, atkRel: false, jump: false, sp: false, back: false, pick: false, dblX: 0, dblY: 0, mash: false }, window.hold); window.hold = Object.assign({}, window.persist || {}); return I; });
      window.persist = {};
      return e;
    };
    window.run = (n, freezeFoe = true) => { for (let i = 0; i < n; i++) { if (freezeFoe && window.foe && window.foe.ai) { window.foe.ai.cool = 9999; window.foe.ai.tok = false; } r.tick(); } };
    window.press = (k, extra = {}) => { window.hold = Object.assign({ [k]: true }, extra); window.run(1); };
  });
  // 1. combo chain -> knockdown
  let o = await t.ev(() => { arena('punk', 24); const seen = []; for (let i = 0; i < 70; i++) { if (i % 5 === 0) window.hold = { atk: true }; run(1); const p = __rc.G.player; if (p.mvName && !seen.includes(p.mvName)) seen.push(p.mvName); } return { seen, st: foe.state, hp: foe.hp }; });
  check('5-hit combo chains jab1>jab2>straight>hook>roundhouse', o.seen.join() === 'jab1,jab2,straight,hook,roundhouse', o.seen.join());
  check('combo finisher knocks down', ['fall', 'down', 'getup'].includes(o.st), o.st + ' hp' + o.hp);
  // 1b. whiff does not chain
  o = await t.ev(() => { arena(null); const seen = []; for (let i = 0; i < 60; i++) { if (i % 5 === 0) window.hold = { atk: true }; run(1); const p = __rc.G.player; if (p.state === 'move' && !seen.includes(p.mvName)) seen.push(p.mvName); } return seen; });
  check('missed jab does not chain', o.join() === 'jab1', o.join());
  // 2. grab + knees
  o = await t.ev(() => { arena('punk', 30); for (let i = 0; i < 20; i++) { window.hold = { mx: 1 }; run(1); } const g = __rc.G.player.state; const hp0 = foe.hp; const st = []; for (let k = 0; k < 3; k++) { press('atk'); run(20); st.push(foe.state); } return { g, st, hp0, hp: foe.hp }; });
  check('walking into enemy grabs', o.g === 'grab', o.g);
  check('knee, knee, third knee knocks down', o.st[0] === 'grabbed' && o.st[1] === 'grabbed' && ['fall', 'down'].includes(o.st[2]), o.st.join() + ' dmg ' + (o.hp0 - o.hp));
  // 3. throw backwards hits a second enemy
  o = await t.ev(() => { arena('punk', 30); const e2 = __rc.spawnEnemy('punk', 110, 190, -1); e2.enter = false; e2.speed = 0; e2.ai.cool = 9999; e2.ai.t = 9999; for (let i = 0; i < 20; i++) { window.hold = { mx: 1 }; run(1); } press('atk', { mx: -1 }); const hp2 = e2.hp; for (let i = 0; i < 60; i++) { e2.ai.cool = 9999; run(1); } return { fst: foe.state, fx: foe.x, px: __rc.G.player.x, e2: e2.state, d2: hp2 - e2.hp, face: __rc.G.player.face }; });
  check('back throw sends enemy behind', o.fx < o.px && o.face === -1, JSON.stringify(o));
  check('thrown body knocks down the enemy behind', o.d2 > 0 && ['fall', 'down', 'getup'].includes(o.e2), JSON.stringify(o));
  // 4. screen throw
  o = await t.ev(() => { arena('punk', 30); for (let i = 0; i < 20; i++) { window.hold = { mx: 1 }; run(1); } const hp0 = foe.hp; press('back'); const states = []; for (let i = 0; i < 50; i++) { run(1); if (!states.includes(foe.state)) states.push(foe.state); } return { states, dmg: hp0 - foe.hp, cracks: __rc.G.cracks.length, max: foe.maxHp }; });
  check('screen throw flies at the camera and cracks the glass', o.states.includes('screen') && o.cracks > 0, o.states.join());
  check('screen throw deals 30% max HP + 10', o.dmg === Math.round(10 + o.max * 0.3), 'dmg ' + o.dmg);
  // 5. vault then suplex
  o = await t.ev(() => { arena('bruiser', 34); for (let i = 0; i < 20; i++) { window.hold = { mx: 1 }; run(1); } const p = __rc.G.player; const g0 = p.state; press('jump'); run(20); const back = p.grabBack, side = Math.sign(p.x - foe.x); const hp0 = foe.hp; press('atk'); run(40); return { g0, back, side, face: p.face, dmg: hp0 - foe.hp, st: foe.state }; });
  check('vault lands behind in a back grab', o.g0 === 'grab' && o.back && o.side === 1 && o.face === -1, JSON.stringify(o));
  check('suplex from back grab: 18 dmg knockdown', o.dmg === 18 && ['down', 'fall', 'getup'].includes(o.st), JSON.stringify(o));
  // 6. specials: free when full, costs HP when empty
  o = await t.ev(() => { arena('punk', 20); const p = __rc.G.player; p.meter = 1; const h0 = p.hp; press('sp'); const a = { hp: p.hp, m: p.meter, mv: p.mvName }; run(90); p.meter = 0; const h1 = p.hp; press('sp'); const b = { hp: p.hp, mv: p.mvName }; run(40); return { a, h0, b, h1, foe: foe.state }; });
  check('special with full meter is free', o.a.hp === o.h0 && o.a.m === 0 && o.a.mv === 'specialN', JSON.stringify(o.a));
  check('special with empty meter costs 7% HP', o.h1 - o.b.hp === 7, `${o.h1} -> ${o.b.hp}`);
  o = await t.ev(() => { arena('punk', 50); const p = __rc.G.player; p.meter = 1; const x0 = p.x; press('sp', { mx: 1 }); const mv = p.mvName; run(60); return { mv, dx: p.x - x0, foe: foe.state }; });
  check('forward special dashes and hits', o.mv === 'specialF' && o.dx > 50 && ['fall', 'down', 'hurt', 'getup'].includes(o.foe), JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 20); const p = __rc.G.player; for (let i = 0; i < 16; i++) { __rc.G.frames++; } const r = []; const f0 = foe.hp; p.meter = 1; press('sp'); for (let i = 0; i < 25; i++) { run(1); r.push(p.inv > 0 ? 1 : 0); } return { inv: r.slice(0, 20).every(v => v), dmg: f0 - foe.hp }; });
  check('defensive special is invincible during the spin', o.inv, JSON.stringify(o));
  // 7. charge punch
  o = await t.ev(() => { arena('punk', 28); const p = __rc.G.player; window.persist = { atkHeld: true }; press('atk', { atkHeld: true }); run(60); const charging = p.charging, ct = p.chargeT; window.persist = {}; run(2); return { charging, ct, mv: p.mvName, st: p.state }; });
  check('hold attack charges, release throws haymaker', o.charging && o.mv === 'haymaker', JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 28); const p = __rc.G.player; window.persist = { atkHeld: true }; press('atk', { atkHeld: true }); run(120); window.persist = {}; run(2); return p.mvName; });
  check('meteor haymaker locked at mastery 1', o === 'haymaker', o);
  o = await t.ev(() => { __rc.SAVE().chars.cole.xp = 2000; arena('punk', 28); const p = __rc.G.player; window.persist = { atkHeld: true }; press('atk', { atkHeld: true }); run(120); window.persist = {}; run(2); const r = p.mvName; __rc.SAVE().chars.cole.xp = 0; return r; });
  check('meteor haymaker at mastery 3', o === 'meteor', o);
  o = await t.ev(() => { __rc.SAVE().chars.cole.xp = 700; arena('punk', 24); const p = __rc.G.player; window.persist = { mx: 1 }; const seen = []; for (let i = 0; i < 60; i++) { if (i % 5 === 0) window.hold = { atk: true, mx: 1 }; run(1); if (p.mvName && !seen.includes(p.mvName)) seen.push(p.mvName); } window.persist = {}; __rc.SAVE().chars.cole.xp = 0; return seen.join(); });
  check('crash shoulder replaces 5th hit at mastery 2 (forward held)', o.includes('crash') && !o.includes('roundhouse'), o);
  o = await t.ev(() => { __rc.SAVE().chars.cole.xp = 700; arena('punk', 24, { classic: true }); const p = __rc.G.player; const seen = []; for (let i = 0; i < 60; i++) { if (i % 5 === 0) window.hold = { atk: true, mx: 1 }; run(1); if (p.mvName && !seen.includes(p.mvName)) seen.push(p.mvName); } __rc.SAVE().chars.cole.xp = 0; return seen.join(); });
  check('classic rules disable mastery moves', !o.includes('crash'), o);
  // 8. run + blitz
  o = await t.ev(() => { arena('punk', 90); const p = __rc.G.player; window.persist = { mx: 1 }; press('mx', { mx: 1, dblX: 1 }); run(10); const st = p.state; window.persist = {}; press('atk', { mx: 1 }); const mv = p.mvName; run(40); return { st, mv, foe: foe.state }; });
  check('double-tap runs, attack blitzes', o.st === 'run' && o.mv === 'blitz', JSON.stringify(o));
  // 9. roll
  o = await t.ev(() => { arena(null); const p = __rc.G.player; const y0 = p.y; press('my', { my: 1, dblY: 1 }); const st = p.state; const inv = []; for (let i = 0; i < 24; i++) { run(1); inv.push(p.inv > 0 ? 1 : 0); } return { st, dy: p.y - y0, inv: inv.reduce((a, b) => a + b) }; });
  check('double-tap down dodge-rolls with i-frames', o.st === 'roll' && o.dy > 30 && o.inv >= 12, JSON.stringify(o));
  // 10. jump kick
  o = await t.ev(() => { arena('punk', 60); const p = __rc.G.player; press('jump', { mx: 1 }); run(6); press('atk'); const a = p.airAtk; run(40); return { a, foe: foe.state }; });
  check('moving jump attack is a flying kick that knocks down', o.a === 'jkick' && ['fall', 'down', 'getup'].includes(o.foe), JSON.stringify(o));
  // 11. weapons
  o = await t.ev(() => { arena('punk', 40); const G = __rc.G, p = G.player; G.items.push({ x: 152, y: 190, z: 0, vz: 0, vx: 0, kind: 'pipe', t: 0, dur: 14 }); press('pick'); run(12); const w = p.weapon && p.weapon.kind; p.x = 150; foe.x = 180; const hp0 = foe.hp; press('atk'); run(20); const d = hp0 - foe.hp; const dur = p.weapon && p.weapon.dur; run(30); press('back'); run(8); const pr = G.projs.length; run(40); return { w, d, dur, pr, hasW: !!p.weapon }; });
  check('pick up pipe with LB', o.w === 'pipe', JSON.stringify(o));
  check('pipe hit does 8 and wears durability', o.d === 8 && o.dur === 13, JSON.stringify(o));
  check('Y throws the weapon', o.pr === 1 && !o.hasW, JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 40); const G = __rc.G, p = G.player; p.weapon = { kind: 'pipe', dur: 1 }; p.x = 150; foe.x = 185; press('atk'); run(20); return !!p.weapon; });
  check('weapon breaks at 0 durability', o === false);
  o = await t.ev(() => { arena('blade', 30); const G = __rc.G, p = G.player; const had = foe.weapon && foe.weapon.kind; for (let i = 0; i < 70; i++) { if (i % 5 === 0) window.hold = { atk: true }; run(1); } return { had, now: foe.weapon, items: G.items.map(i => i.kind) }; });
  check('knocking down a blade drops the knife', o.had === 'knife' && !o.now && o.items.includes('knife'), JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 120); const G = __rc.G; foe.ai.cool = -1; G.items.push({ x: 250, y: 190, z: 0, vz: 0, vx: 0, kind: 'pipe', t: 0, dur: 10 }); for (let i = 0; i < 200; i++) { foe.ai.tok = false; foe.ai.cool = -1; __rc.tick(); } return foe.weapon && foe.weapon.kind; });
  check('enemies pick up weapons off the floor', o === 'pipe', String(o));
  // 12. items + 1UP + stars
  o = await t.ev(() => { arena(null); const G = __rc.G, p = G.player; p.hp = 50; G.items.push({ x: 150, y: 190, z: 0, vz: 0, vx: 0, kind: 'apple', t: 0 }); press('atk'); run(12); const a = p.hp; G.items.push({ x: 150, y: 190, z: 0, vz: 0, vx: 0, kind: 'roast', t: 0 }); press('pick'); run(12); const b = p.hp; const l0 = G.lives; addScore(50000); const l1 = G.lives; addScore(30000); return { a, b, l0, l1, stars: G.stars }; });
  check('apple heals 30%, roast heals to full', o.a === 80 && o.b === 100, JSON.stringify(o));
  check('1UP at 50,000 points', o.l1 === o.l0 + 1, JSON.stringify(o));
  check('star rank rises with score', o.stars === 3, JSON.stringify(o));
  o = await t.ev(() => { arena(null); const G = __rc.G, p = G.player; p.meter = 0; for (const k of ['rage', 'iron', 'overdrive', 'refill', 'starup']) { G.items.push({ x: 150, y: 190, z: 0, vz: 0, vx: 0, kind: 'power', power: k, t: 0 }); press('pick'); run(12); } return { pw: p.pw, m: p.meter, s: G.stars }; });
  check('power-ups apply (rage/iron/overdrive/refill/star)', o.pw.rage > 0 && o.pw.iron > 0 && o.pw.overdrive > 0 && o.m >= 0.9 && o.s === 2, JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 24); const p = __rc.G.player; p.pw.rage = 600; const h0 = foe.hp; press('atk'); run(10); return h0 - foe.hp; });
  check('rage doubles damage', o === 8, String(o));
  // 13. enemy AI hurts an idle player; token limit
  o = await t.ev(() => { arena(null); const G = __rc.G; for (let i = 0; i < 5; i++) { const e = __rc.spawnEnemy('punk', 250 + i * 15, 170 + i * 10, 1); e.enter = false; } let maxTok = 0; for (let i = 0; i < 900; i++) { __rc.tick(); maxTok = Math.max(maxTok, G.ents.filter(f => f.kind === 'enemy' && f.ai.tok).length); } return { hp: G.player.hp, maxTok, dmg: G.dmgTaken }; });
  check('enemies attack an idle player', o.dmg > 0, JSON.stringify(o));
  check('medium allows at most 2 attackers at once', o.maxTok <= 2, JSON.stringify(o));
  // 14. bruiser grab + mash escape
  o = await t.ev(() => { arena('bruiser', 30); const G = __rc.G, p = G.player; foe.face = -1; __rc.startMoveX = null; startMove(foe, 'eReach'); for (let i = 0; i < 20; i++) run(1); const held = p.state; for (let i = 0; i < 30; i++) { window.hold = { mash: true }; run(1); } return { held, after: p.state, dmg: G.dmgTaken }; });
  check('bruiser grab holds the player', o.held === 'held', JSON.stringify(o));
  check('mashing escapes before the slam', o.after !== 'held' && o.dmg === 0, JSON.stringify(o));
  // 15. hazards
  o = await t.ev(() => { arena('punk', 30); const G = __rc.G; G.hazards = [{ kind: 'manhole', x: 260, y: 190, cool: 0, spray: 0 }]; foe.x = 250; foe.ai.cool = 9999; knock(foe, 3, 2); for (let i = 0; i < 60; i++) run(1); return { st: foe.state, rem: foe.remove, killed: foe.killed }; });
  check('enemy knocked into an open manhole is KO\'d', o.killed, JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 60); const G = __rc.G; G.hazards = [{ kind: 'hydrant', x: 175, y: 190, cool: 0, spray: 0, dir: 1 }]; foe.x = 215; const h0 = foe.hp; press('atk'); run(30); return { spray: G.hazards[0].spray > 0, st: foe.state, d: h0 - foe.hp }; });
  check('punching a hydrant sprays water that knocks enemies down', o.spray && o.d > 0, JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 60); const G = __rc.G; foe.y = 218; foe.x = 300; foe.speed = 0; G.car = { x: G.camX + 470, y: 218, t: 0 }; for (let i = 0; i < 150; i++) run(1); return { d: foe.maxHp - foe.hp, st: foe.state }; });
  check('traffic hits enemies in its lane', o.d >= 18, JSON.stringify(o));
  // 16. breakables drop items
  o = await t.ev(() => { arena(null); const G = __rc.G; G.props = [{ x: 175, y: 190, kind: 'can', item: 'p:starup', broken: false, flash: 0 }]; press('atk'); run(30); return { broken: G.props[0].broken, items: G.items.map(i => i.kind + (i.power || '')) }; });
  check('breakable drops its item', o.broken && o.items.length === 1, JSON.stringify(o));
  // 17. death, lives, stars lost, continue
  o = await t.ev(() => { arena(null); const G = __rc.G, p = G.player; G.stars = 3; p.hp = 1; applyHit({ team: 'foe', x: 100, face: 1, dmgMult: 1, look: {}, pw: {}, kind: 'enemy' }, p, { dmg: 10, type: 'K', kx: 2, kz: 3 }); for (let i = 0; i < 250; i++) run(1); return { lives: G.lives, stars: G.stars, st: p.state, hp: p.hp }; });
  check('death costs a life and a star, then respawns', o.lives === 4 && o.stars === 2 && o.hp === 100, JSON.stringify(o));
  o = await t.ev(() => { arena(null); const G = __rc.G, p = G.player; G.lives = 1; G.score = 12345; p.hp = 1; applyHit({ team: 'foe', x: 100, face: 1, dmgMult: 1, look: {}, pw: {}, kind: 'enemy' }, p, { dmg: 10, type: 'K', kx: 2, kz: 3 }); for (let i = 0; i < 250; i++) { __rc.tick(); if (__rc.SCREEN !== 'play') break; } const scr = __rc.SCREEN; for (let i = 0; i < 40; i++) __rc.tick(); window.hold = {}; __rc.Input.keyEdges.add('Enter'); __rc.tick(); return { scr, after: __rc.SCREEN, score: __rc.G.score, lives: __rc.G.lives, cont: __rc.G.continued }; });
  check('last life -> continue screen', o.scr === 'continue', JSON.stringify(o));
  check('continue: score 0, 5 lives, flagged', o.after === 'play' && o.score === 0 && o.lives === 5 && o.cont, JSON.stringify(o));
  // 18. ally
  o = await t.ev(() => { arena(null, 0, { partner: true }); const G = __rc.G; for (let i = 0; i < 3; i++) { const e = __rc.spawnEnemy('punk', 280 + i * 20, 180 + i * 12, 1); e.enter = false; } let dealt = 0; const hp0 = G.ents.filter(e => e.team === 'foe').reduce((a, e) => a + e.hp, 0); for (let i = 0; i < 900; i++) __rc.tick(); const hp1 = G.ents.filter(e => e.team === 'foe').reduce((a, e) => a + Math.max(0, e.hp), 0); return { hasAlly: !!G.ally, dealt: hp0 - hp1, kos: G.kos, allyHp: G.ally && G.ally.maxHp }; });
  check('CPU partner fights on its own', o.hasAlly && (o.dealt > 30 || o.kos > 0), JSON.stringify(o));
  check('CPU partner uses base stats', o.allyHp === 100, JSON.stringify(o));
  o = await t.ev(() => { arena(null, 0, { partner: true }); const G = __rc.G; __rc.Input.keyEdges.add('KeyO'); __rc.tick(); return G.allyCmd; });
  check('RB cycles ally command', o === 1, String(o));
  o = await t.ev(() => { __rc.SAVE().options.friendly = false; arena(null, 0, { partner: true }); const G = __rc.G, p = G.player, a = G.ally; a.x = p.x + 24; a.y = p.y; a.aiT = 1; const h0 = a.hp; press('atk'); run(8); const off = h0 - a.hp; __rc.SAVE().options.friendly = true; arena(null, 0, { partner: true }); const p2 = __rc.G.player, a2 = __rc.G.ally; a2.x = p2.x + 24; a2.y = p2.y; const h1 = a2.hp; press('atk'); run(8); __rc.SAVE().options.friendly = false; return { off, on: h1 - a2.hp }; });
  check('friendly fire off by default, half damage when on', o.off === 0 && o.on === 2, JSON.stringify(o));
  // 19. upgrades
  o = await t.ev(() => { const cs = __rc.SAVE().chars.cole; cs.atk = 5; cs.hp = 5; cs.def = 5; arena('punk', 24); const p = __rc.G.player; const h0 = foe.hp; press('atk'); run(10); const d = h0 - foe.hp; const mh = p.maxHp; const def = p.defMul; arena('punk', 24, { classic: true }); const mh2 = __rc.G.player.maxHp; cs.atk = 0; cs.hp = 0; cs.def = 0; return { d, mh, def, mh2 }; });
  check('attack tier 5 = +50%, health tier 5 = 150 HP, defense -30%', o.d === 6 && o.mh === 150 && Math.abs(o.def - 0.7) < 1e-9, JSON.stringify(o));
  check('classic ignores upgrades', o.mh2 === 100, JSON.stringify(o));
  o = await t.ev(() => { const cs = __rc.SAVE().chars.cole; cs.starlock = true; arena(null); const G = __rc.G; const s0 = G.stars; const p = G.player; p.hp = 1; applyHit({ team: 'foe', x: 100, face: 1, dmgMult: 1, look: {}, pw: {}, kind: 'enemy' }, p, { dmg: 10, type: 'K', kx: 2, kz: 3 }); for (let i = 0; i < 250; i++) run(1); cs.starlock = false; return { s0, s1: G.stars }; });
  check('star lock: start at 3 stars and keep them on death', o.s0 === 3 && o.s1 === 3, JSON.stringify(o));
  o = await t.ev(() => { const cs = __rc.SAVE().chars.cole; cs.freesp = true; arena(null); const p = __rc.G.player; p.meter = 0; const h = p.hp; press('sp'); cs.freesp = false; return h - p.hp; });
  check('free specials capstone', o === 0, String(o));
  // 20. mania HP
  o = await t.ev(() => { arena('punk', 30, { diff: 3 }); const a = foe.maxHp; arena('punk', 30, { diff: 1 }); return [a, foe.maxHp]; });
  check('mania enemies have +25% on top of the hard-tier HP', o[0] === Math.round(30 * 1.75) && o[1] === 30, JSON.stringify(o));
  // 21. cheats flag
  o = await t.ev(() => { arena(null); __rc.CHEAT.invincible = 1; __rc.tick(); const f = __rc.G.cheated; __rc.CHEAT.invincible = 0; return f; });
  check('turning on a cheat flags the run', o === true);
  console.log(results.map(r => r.join('  ')).join('\n'));
  console.log(results.filter(r => r[0] === 'PASS').length + '/' + results.length + ' passed');
  console.log(t.errors.slice(0, 5).join('\n') || 'no errors');
  await t.close();
})();
