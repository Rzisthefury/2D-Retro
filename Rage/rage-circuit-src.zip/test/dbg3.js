const { launch } = require('./harness');
(async () => {
  const t = await launch();
  const out = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 });
    r.go('play');
    r.setIntent(e => { const I = allyIntent(e); const live = r.G.ents.filter(f => f.team === 'foe' && !f.killed && !f.remove && !f.enter); if (!live.length && !I.atk) { I.mx = 1; I.my = 0; } e._I = I; return I; });
    const res = [];
    for (let k = 0; k < 4000; k++) { r.G.player.hp = 100; r.tick(); if (k > 1500 && k % 25 === 0) { const p = r.G.player; res.push(`${k} P ${p.state} ${p.mvName} ${Math.round(p.x)},${Math.round(p.y)} f${p.face} I:${p._I.mx},${p._I.my},${p._I.atk ? 'A' : ''}  ` + r.G.ents.filter(e => e.team === 'foe').map(e => [e.type, e.state, e.mvName, Math.round(e.x), Math.round(e.y), e.hp, e.ai.tok, Math.round(e.ai.cool), e.inv, e.face].join(',')).join(' | ')); } }
    return res.slice(0, 50);
  });
  console.log(out.join('\n'));
  await t.close();
})();
