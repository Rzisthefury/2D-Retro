const { launch } = require('./harness');
(async () => {
  const t = await launch();
  const r = await t.ev(() => {
    const x = window.__rc; x.startRun({ mode: 'story', diff: 3, classic: false, char: 'cole', partner: true, allyCmd: 0, stage: 1 }); x.go('play');
    // Drain the sprite prewarm queue FIRST. updatePlay spends ~14ms a tick
    // baking sprites while G.loadQ has anything in it, so a window that starts
    // before it empties measures the bake, not the game. This was written down
    // after build 5 and never actually applied to this script, which is why it
    // has been reporting ~44/s ever since.
    for (let i = 0; i < 20000 && x.G.loadQ.length; i++) x.tick();
    for (let i = 0; i < 6; i++) { const e = x.spawnEnemy(['punk','blade','bruiser','kicker'][i%4], 200 + i*30, 160 + i*10, 1); e.enter = false; }
    const t0 = performance.now(); let n = 0;
    while (performance.now() - t0 < 3000) { x.G.player.hp = 100; x.tick(); x.render(); n++; }
    return n / 3;
  });
  console.log('tick+render per second:', Math.round(r));
  await t.ticks(1); await t.shot('perf_crowd');
  await t.close();
})();
