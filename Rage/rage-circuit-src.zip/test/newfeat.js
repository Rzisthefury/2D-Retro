// Tests for build 2: Anita, move upgrades, corner breakout, names, whip/robot, twins, mech, stage flow, pixel sprites
const { launch } = require('./harness');
const results = [];
function check(name, ok, info = '') { results.push([ok ? 'PASS' : 'FAIL', name, info]); }
(async () => {
  const t = await launch();
  await t.ev(() => {
    const r = window.__rc;
    window.arena = (type = 'punk', dx = 26, opts = {}) => {
      r.startRun(Object.assign({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 }, opts));
      r.go('play');
      const G = r.G;
      G.loadQ = [];
      G.waveIdx = 99; G.wave = null; G.spawnQ = []; G.banner = null; G.hazards = [];
      G.ents = G.ents.filter(e => e.team === 'hero');
      G.player.x = 150; G.player.y = 190; G.player.face = 1;
      let e = null;
      if (type) { e = r.spawnEnemy(type, 150 + dx, 190, 1); e.enter = false; e.face = -1; e.ai.cool = 9999; e.ai.t = 9999; }
      window.foe = e;
      window.hold = {}; window.persist = {};
      r.setIntent(() => { const I = Object.assign({ mx: 0, my: 0 }, window.hold); window.hold = Object.assign({}, window.persist); return I; });
      return e;
    };
    window.run = (n) => { for (let i = 0; i < n; i++) { if (window.foe && window.foe.ai) { window.foe.ai.cool = 9999; window.foe.ai.tok = false; } r.tick(); } };
    window.press = (k, extra = {}) => { window.hold = Object.assign({ [k]: true }, extra); window.run(1); };
    window.bossArena = (stage, keys, diff = 1) => {
      r.startRun({ mode: 'story', diff, classic: false, char: 'cole', partner: false, allyCmd: 0, stage });
      r.go('play');
      const G = r.G;
      G.loadQ = []; G.banner = null; G.hazards = []; G.beams = [];
      G.ents = G.ents.filter(e => e.team === 'hero');
      G.waveIdx = 99; G.camX = 0;
      G.player.x = 150; G.player.y = 190;
      window.hold = {}; window.persist = {};
      r.setIntent(() => { const I = Object.assign({ mx: 0, my: 0 }, window.hold); window.hold = Object.assign({}, window.persist); return I; });
      G.lockX = 0;
      const bs = keys.map((k, i) => { const b = r.spawnBoss(300 + i * 30, 180 + i * 16, k); b.state = b.idleState; b.st = 0; b.boss.cool = 9999; return b; });
      return bs;
    };
  });
  // ---------- Anita
  let o = await t.ev(() => { arena('punk', 30, { char: 'anita' }); const p = __rc.G.player; const seen = []; for (let i = 0; i < 70; i++) { if (i % 5 === 0) window.hold = { atk: true }; run(1); if (p.mvName && !seen.includes(p.mvName)) seen.push(p.mvName); } return { seen, look: p.look.name, st: foe.state }; });
  check('Anita plays with her own look and kick combo', o.look === 'anita' && o.seen.join() === 'ak1,ak2,ak3,ak4,ak5', JSON.stringify(o));
  check('Anita combo ends in a knockdown', ['fall', 'down', 'getup'].includes(o.st), o.st);
  o = await t.ev(() => { arena(null, 0, { char: 'anita' }); const p = __rc.G.player; press('jump'); run(10); const z1 = p.z; press('jump'); run(2); const vz = p.vz; const left = p.jumpsLeft; press('jump'); run(2); return { z1, vz, left, vz2: p.vz }; });
  check('Anita double jump: second jump fires, third does not', o.vz > 3 && o.left === 0 && o.vz2 < o.vz, JSON.stringify(o));
  o = await t.ev(() => { arena(null, 0, { char: 'cole' }); const p = __rc.G.player; press('jump'); run(10); const vz0 = p.vz; press('jump'); run(1); return { before: vz0, after: p.vz }; });
  check('Cole has no double jump', o.after < o.before, JSON.stringify(o));
  o = await t.ev(() => { __rc.SAVE().chars.anita.moves = ['triple']; arena(null, 0, { char: 'anita' }); const p = __rc.G.player; press('jump'); run(8); press('jump'); run(8); const l1 = p.jumpsLeft; press('jump'); run(2); const vz = p.vz; __rc.SAVE().chars.anita.moves = []; return { l1, vz, left: p.jumpsLeft }; });
  check('Triple jump upgrade gives a third jump', o.l1 === 1 && o.vz > 3 && o.left === 0, JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 50, { char: 'anita' }); const p = __rc.G.player; p.meter = 1; press('sp', { mx: 1 }); const mv = p.mvName; run(50); return { mv, foe: foe.state }; });
  check('Anita forward special = drive knee', o.mv === 'aspF' && ['fall', 'down', 'hurt', 'getup'].includes(o.foe), JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 30, { char: 'anita' }); const p = __rc.G.player; window.persist = { atkHeld: true }; press('atk', { atkHeld: true }); run(60); const c = p.charging; window.persist = {}; run(2); return { c, mv: p.mvName }; });
  check('Anita has no charge punch at mastery 1', !o.c && o.mv !== 'axe', JSON.stringify(o));
  o = await t.ev(() => { __rc.SAVE().chars.anita.xp = 2000; arena('punk', 30, { char: 'anita' }); const p = __rc.G.player; window.persist = { atkHeld: true }; press('atk', { atkHeld: true }); run(70); window.persist = {}; run(2); __rc.SAVE().chars.anita.xp = 0; return p.mvName; });
  check('Axe kick at Anita mastery 3', o === 'axe', o);
  o = await t.ev(() => { arena('punk', 90, { char: 'anita' }); const p = __rc.G.player; window.persist = { mx: 1 }; press('mx', { mx: 1, dblX: 1 }); run(8); window.persist = {}; press('atk', { mx: 1 }); const mv = p.mvName; run(40); return { mv, foe: foe.state }; });
  check('Anita dash kick (no upgrade)', o.mv === 'adash', JSON.stringify(o));
  o = await t.ev(() => { __rc.SAVE().chars.anita.moves = ['spindash']; arena('punk', 90, { char: 'anita' }); const p = __rc.G.player; window.persist = { mx: 1 }; press('mx', { mx: 1, dblX: 1 }); run(8); window.persist = {}; const h0 = foe.hp; press('atk', { mx: 1 }); const mv = p.mvName; run(40); __rc.SAVE().chars.anita.moves = []; return { mv, dmg: h0 - foe.hp }; });
  check('Spinning dash kick upgrade hits twice (7 + 9)', o.mv === 'adashSpin' && o.dmg === 16, JSON.stringify(o));
  o = await t.ev(() => { __rc.SAVE().chars.anita.moves = ['aircombo']; arena('punk', 40, { char: 'anita' }); const p = __rc.G.player; press('jump', { mx: 1 }); run(4); press('atk'); run(10); const hit = p.airHit; press('atk'); run(3); const a2 = p.airAtk; run(30); __rc.SAVE().chars.anita.moves = []; return { hit, a2 }; });
  check('Air combo upgrade chains a second air kick', o.hit && o.a2 === 'ajkick2', JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 40, { char: 'anita' }); const p = __rc.G.player; press('jump', { mx: 1 }); run(4); press('atk'); run(10); press('atk'); run(3); return p.airAtk; });
  check('No air combo without the upgrade', o !== 'ajkick2', o);
  o = await t.ev(() => { __rc.SAVE().chars.anita.moves = ['stiletto']; arena('punk', 110, { char: 'anita' }); const p = __rc.G.player; p.meter = 1; foe.speed = 0; press('jump'); run(10); press('sp'); const pr = __rc.G.projs.length; const m = p.meter; const h0 = foe.hp; run(40); __rc.SAVE().chars.anita.moves = []; return { pr, m, dmg: h0 - foe.hp, items: __rc.G.items.length }; });
  check('Stiletto throw: uses meter, hits, leaves no pickup', o.pr === 1 && o.m === 0 && o.dmg === 12 && o.items === 0, JSON.stringify(o));
  // ---------- Cole upgrades
  o = await t.ev(() => { arena('punk', 90); const p = __rc.G.player; window.persist = { mx: 1 }; press('mx', { mx: 1, dblX: 1 }); run(8); window.persist = {}; press('atk', { mx: 1 }); for (let i = 0; i < 30; i++) { window.hold = { atk: true }; run(1); } return p.mvName; });
  check('No blitz follow-up without the upgrade', o !== 'blitz2', o);
  o = await t.ev(() => { __rc.SAVE().chars.cole.moves = ['blitz2']; arena('punk', 90); const p = __rc.G.player; window.persist = { mx: 1 }; press('mx', { mx: 1, dblX: 1 }); run(8); window.persist = {}; const h0 = foe.hp; press('atk', { mx: 1 }); const seen = []; for (let i = 0; i < 40; i++) { if (i % 3 === 0) window.hold = { atk: true }; run(1); if (!seen.includes(p.mvName)) seen.push(p.mvName); } run(40); __rc.SAVE().chars.cole.moves = []; return { seen, dmg: h0 - foe.hp }; });
  check('Blitz follow-up upgrade: blitz then launcher (12 + 10)', o.seen.includes('blitz') && o.seen.includes('blitz2') && o.dmg === 22, JSON.stringify(o));
  o = await t.ev(() => { __rc.SAVE().chars.cole.moves = ['dkick']; arena('punk', 60); const p = __rc.G.player; foe.hp = 999; const h0 = foe.hp; press('jump', { mx: 1 }); run(4); press('atk'); const a = p.airAtk; run(40); __rc.SAVE().chars.cole.moves = []; return { a, dmg: h0 - foe.hp }; });
  check('Double flying kick upgrade hits twice (6 + 7)', o.a === 'jkick2' && o.dmg === 13, JSON.stringify(o));
  o = await t.ev(() => { __rc.SAVE().chars.cole.moves = ['dkick']; arena('punk', 60, { classic: true }); const p = __rc.G.player; press('jump', { mx: 1 }); run(4); press('atk'); const a = p.airAtk; __rc.SAVE().chars.cole.moves = []; return a; });
  check('Classic rules turn move upgrades off', o === 'jkick', o);
  // ---------- names
  o = await t.ev(() => { arena(null); const names = {}; for (let i = 0; i < 600; i++) { const e = __rc.spawnEnemy('punk', 200, 190, 1); names[e.name] = (names[e.name] || 0) + 1; e.remove = true; } __rc.G.ents = __rc.G.ents.filter(e => !e.remove); return names; });
  const special = ['DONOVAN', 'Y SIGNAL', 'SQUIDWARD', 'DOOSH', 'SERGE'];
  const sc = special.reduce((a, n) => a + (o[n] || 0), 0);
  check('All five special names appear, about 1 in 6', special.every(n => o[n] > 0) && sc > 60 && sc < 150, `${sc}/600 ` + JSON.stringify(o));
  // ---------- corner breakout
  o = await t.ev(() => {
    const [b] = bossArena(1, ['brick']); const G = __rc.G, p = G.player;
    b.x = G.camX + 400; b.y = 190; b.state = 'dazed'; b.dazeLeft = 9999; p.x = b.x - 40;
    const states = [];
    for (let i = 0; i < 260; i++) { if (i % 10 === 0 && canBeHit(b)) { applyHit(p, b, { dmg: 2, type: 'L' }); b.hitstop = 0; } __rc.tick(); if (states[states.length - 1] !== b.state) states.push(b.state); }
    return { states, x: Math.round(b.x), pst: p.state, hp: p.hp };
  });
  check('Brick pinned in a corner breaks out after ~2 s', o.states.includes('bburst'), o.states.join('>'));
  check('Breakout shoves the player and moves him to centre', o.x > 180 && o.x < 250 && o.hp < 100, JSON.stringify(o));
  o = await t.ev(() => {
    const [b] = bossArena(1, ['brick']); const G = __rc.G, p = G.player;
    b.x = G.camX + 400; b.state = 'dazed'; b.dazeLeft = 9999; p.x = b.x - 40;
    let first = -1;
    for (let i = 0; i < 260; i++) { if (i % 10 === 0 && canBeHit(b)) { applyHit(p, b, { dmg: 2, type: 'L' }); b.hitstop = 0; } __rc.tick(); if (b.state === 'bburst' && first < 0) first = i; }
    return first;
  });
  check('Corner breakout triggers at 1.5 seconds (85-95 frames)', o >= 85 && o <= 95, String(o));
  o = await t.ev(() => {
    const [b] = bossArena(1, ['brick']); const G = __rc.G, p = G.player;
    b.x = G.camX + 213; b.state = 'dazed'; b.dazeLeft = 9999; p.x = b.x - 40;
    let burst = -1, hits = 0;
    for (let i = 0; i < 400; i++) { if (i % 16 === 0 && canBeHit(b)) { applyHit(p, b, { dmg: 2, type: 'L' }); b.hitstop = 0; hits++; } __rc.tick(); if (b.state === 'bburst' && burst < 0) burst = hits; }
    return { burst, x: Math.round(b.x) };
  });
  check('Mid-screen: 10 hits while he cannot act also triggers a breakout', o.burst >= 9 && o.burst <= 12, JSON.stringify(o));
  o = await t.ev(() => {
    const [b] = bossArena(1, ['brick']); const G = __rc.G, p = G.player;
    b.x = G.camX + 213; p.x = 60;
    let burst = false;
    for (let i = 0; i < 600; i++) { if (i % 120 === 0 && canBeHit(b)) { applyHit(p, b, { dmg: 2, type: 'L' }); b.hitstop = 0; } __rc.tick(); if (b.state === 'bburst') burst = true; }
    return burst;
  });
  check('Occasional hits do not trigger a breakout (pressure decays)', o === false);
  o = await t.ev(() => {
    const [b] = bossArena(1, ['brick']); const G = __rc.G, p = G.player;
    b.x = G.camX + 400; b.state = 'dazed'; b.dazeLeft = 9999; p.x = b.x - 40;
    let burst = false;
    for (let i = 0; i < 300; i++) { __rc.tick(); if (b.state === 'bburst') burst = true; }
    return burst;
  });
  check('No breakout if nobody is hitting him', o === false);
  o = await t.ev(() => {
    const out = {};
    for (const [st, k] of [[2, 'ruby'], [3, 'mech']]) {
      const [b] = bossArena(st, [k]); const G = __rc.G, p = G.player;
      b.x = G.camX + 30 + b.w; if (k === 'ruby') { b.state = 'dazed'; b.dazeLeft = 9999; } p.x = b.x + 40;
      let burst = false, far = b.x;
      for (let i = 0; i < 300; i++) { p.hp = p.maxHp; if (i % 10 === 0 && canBeHit(b)) { applyHit(p, b, { dmg: 1, type: 'L' }); b.hitstop = 0; } __rc.tick(); if (b.state === 'bburst') burst = true; far = Math.max(far, b.x); }
      out[k] = { burst, x: Math.round(far) };
    }
    return out;
  });
  check('Twins and mech also break out of a corner (they reach the middle)', o.ruby.burst && o.mech.burst && o.ruby.x > 150 && o.mech.x > 150, JSON.stringify(o));
  // ---------- new enemies
  o = await t.ev(() => { arena(null); const G = __rc.G; const e = __rc.spawnEnemy('whip', 150 + 70, 190, 1); e.enter = false; e.face = -1; startMove(e, 'eWhip'); let max = 0; for (let i = 0; i < 40; i++) { __rc.tick(); max = Math.max(max, e.whipT || 0); } return { dmg: G.dmgTaken, max }; });
  check('Whip hits from ~70 px away and draws the whip', o.dmg > 0 && o.max > 0, JSON.stringify(o));
  o = await t.ev(() => { arena('robot', 30); const p = __rc.G.player; const h0 = foe.hp; press('atk'); run(10); const st1 = foe.state; for (let i = 0; i < 20; i++) { window.hold = { mx: 1 }; run(1); } return { st1, dmg: h0 - foe.hp, grab: p.state }; });
  check('Robot ignores light hitstun and cannot be grabbed', o.st1 !== 'hurt' && o.dmg > 0 && o.grab !== 'grab', JSON.stringify(o));
  o = await t.ev(() => { arena('robot', 30); const G = __rc.G, p = G.player; const e2 = __rc.spawnEnemy('punk', 170, 192, 1); e2.enter = false; e2.speed = 0; e2.ai.cool = 9999; foe.speed = 0; foe.hp = 1; applyHit(p, foe, { dmg: 5, type: 'K', kx: 1, kz: 2 }); const hp0 = p.hp; for (let i = 0; i < 160; i++) { e2.ai.cool = 9999; __rc.tick(); } return { gone: !G.ents.includes(foe), php: hp0 - p.hp, e2: e2.maxHp - e2.hp, boom: true }; });
  check('Robot explodes on death, hurting heroes and enemies nearby', o.gone && o.php > 0 && o.e2 > 0, JSON.stringify(o));
  // ---------- twins
  o = await t.ev(() => {
    const bs = bossArena(2, ['ruby', 'onyx']); const G = __rc.G, p = G.player;
    const [a, b] = bs; a.boss.cool = 0; b.boss.cool = 0;
    a.x = 300; b.x = 330; p.x = 150;
    const seen = new Set();
    let hits = 0, bad = 0; const hist = []; let lastD = 0;
    for (let i = 0; i < 2400; i++) {
      p.hp = p.maxHp; if (p.state === 'dead') break;
      __rc.tick();
      for (const x of bs) seen.add(x.state);
      hist.push(bs.map(x => x.state + ':' + (x.mvName || '') + ':' + x.mf).join('|'));
      if (G.dmgTaken > lastD) { lastD = G.dmgTaken; hits++; const rec = hist.slice(-60).join(' '); if (!/tcartTell|tflipTell|move:tKick:1[0-9]|move:tBack|bburst/.test(rec)) bad++; }
    }
    return { seen: [...seen], hits, bad, sides: Math.sign(a.x - p.x) !== Math.sign(b.x - p.x) };
  });
  check('Twins use cartwheel, flip and kick', ['tcartTell', 'tcart', 'tflipTell', 'tflip', 'move'].every(s => o.seen.includes(s)), o.seen.join());
  check('Every twin hit is telegraphed', o.hits > 3 && o.bad === 0, JSON.stringify(o));
  o = await t.ev(() => { const [a] = bossArena(2, ['ruby']); const p = __rc.G.player; a.x = 180; a.y = 190; for (let i = 0; i < 30; i++) { window.hold = { mx: 1 }; __rc.tick(); } const g1 = p.state; a.state = 'ttaunt'; a.st = 0; a.x = 180; a.y = 190; p.state = 'stand'; p.x = 150; p.y = 190; p.face = 1; for (let i = 0; i < 20; i++) { window.hold = { mx: 1 }; __rc.tick(); } return { g1, g2: p.state }; });
  check('Twins can only be grabbed while taunting or dazed', o.g1 !== 'grab' && o.g2 === 'grab', JSON.stringify(o));
  o = await t.ev(() => { const [a, b] = bossArena(2, ['ruby', 'onyx']); const G = __rc.G; a.hp = 1; applyHit(G.player, a, { dmg: 5, type: 'K', kx: 2, kz: 3 }); __rc.tick(); return { enraged: b.enraged, dead: G.bossDead }; });
  check('Killing one twin enrages the other; stage not clear yet', o.enraged && !o.dead, JSON.stringify(o));
  // ---------- mech
  o = await t.ev(() => {
    // The mech picks its move by RANGE: claw and stomp when close, flame in the
    // mid band. Parking the player at one distance therefore only ever exercises
    // one branch, and whether the other shows up is down to the dice - which is
    // what made this check flaky. Drive the distance instead, so every branch is
    // actually visited.
    const [m] = bossArena(3, ['mech']); const G = __rc.G, p = G.player;
    m.boss.cool = 0; m.x = 260; p.x = 180;
    const seen = new Set(); let hits = 0, bad = 0; const hist = []; let lastD = 0;
    for (let i = 0; i < 3600; i++) {
      p.hp = p.maxHp; if (p.state === 'dead') break;
      // Alternate between close range and the flamethrower's band, but only
      // reposition while the mech is idle - shoving the player mid-attack would
      // cancel the knockback and stop hits registering the way they do in play.
      if (m.state === 'midle') {
        p.x = (i % 600) < 300 ? m.x - 66 * m.face : m.x - 130 * m.face;
        p.y = m.y;
      }
      __rc.tick(); seen.add(m.state);
      hist.push(m.state);
      if (G.dmgTaken > lastD) { lastD = G.dmgTaken; hits++; const rec = hist.slice(-80).join(' '); if (!/mclawTell|mflameTell|mstompTell|bburst/.test(rec)) bad++; }
    }
    return { seen: [...seen], hits, bad };
  });
  check('Mech uses claw, flamethrower and stomp', ['mclaw', 'mflame', 'mstomp'].every(s => o.seen.includes(s)), o.seen.join());
  check('Every mech hit is telegraphed', o.hits > 3 && o.bad === 0, JSON.stringify(o));
  o = await t.ev(() => { const [m] = bossArena(3, ['mech']); const G = __rc.G, p = G.player; m.x = 200; p.x = 160; const h0 = m.hp; for (let i = 0; i < 20; i++) { window.hold = { mx: 1 }; __rc.tick(); } const g = p.state; applyHit(p, m, { dmg: 12, type: 'K', kx: 3, kz: 3 }); return { g, st: m.state, dmg: h0 - m.hp }; });
  check('Mech cannot be grabbed or knocked down', o.g !== 'grab' && o.st !== 'fall' && o.dmg === 12, JSON.stringify(o));
  o = await t.ev(() => { const [m] = bossArena(3, ['mech']); const p = __rc.G.player; for (let i = 0; i < 12; i++) { applyHit(p, m, { dmg: 8, type: 'H' }); m.hitstop = 0; } const st = m.state; const h0 = m.hp; applyHit(p, m, { dmg: 10, type: 'H' }); return { st, bonus: h0 - m.hp }; });
  check('Steady damage overheats the mech; it takes 1.5x while stalled', o.st === 'mstall' && o.bonus === 15, JSON.stringify(o));
  o = await t.ev(() => {
    const [m] = bossArena(3, ['mech']); const G = __rc.G, p = G.player;
    m.hp = 1; applyHit(p, m, { dmg: 5, type: 'H' });
    __rc.tick();
    const s1 = m.state; let rivet = null; let clearWhileMech = false;
    for (let i = 0; i < 120; i++) { p.hp = p.maxHp; __rc.tick(); if (G.bossDead) clearWhileMech = true; rivet = G.bosses.find(b => b.boss.key === 'rivet'); if (rivet) break; }
    const st = rivet && rivet.state;
    if (rivet) { rivet.hp = 1; rivet.state = 'bidle'; applyHit(p, rivet, { dmg: 5, type: 'K', kx: 2, kz: 3 }); }
    for (let i = 0; i < 20; i++) __rc.tick();
    return { s1, rivet: !!rivet, st, clearWhileMech, dead: G.bossDead, pole: rivet && rivet.boss.poleDone };
  });
  check('Destroyed mech explodes and Rivet jumps out', o.s1 === 'mbreak' && o.rivet && !o.clearWhileMech, JSON.stringify(o));
  check('Beating Rivet clears the boss fight', o.dead === true, JSON.stringify(o));
  // ---------- hazards
  o = await t.ev(() => { arena('punk', 0); const G = __rc.G; G.hazards = [{ kind: 'wire', x: 150, y: 190, t: 0 }]; foe.speed = 0; foe.x = 150; foe.y = 190; G.player.x = 60; const f0 = foe.hp; const st = []; for (let i = 0; i < 140; i++) { foe.ai.cool = 9999; foe.x = 150; foe.y = 190; __rc.tick(); if (i === 95) st.push(foe.hp); } return { before: f0, at99: st[0], after: foe.hp }; });
  check('Live wire only zaps after its 40-frame warning', o.at99 === o.before && o.after < o.before, JSON.stringify(o));
  o = await t.ev(() => { arena(null); const G = __rc.G; G.hazards = [{ kind: 'beams', every: 330, cd: 1 }]; const p = G.player; let shadowT = -1, hitT = -1; for (let i = 0; i < 200; i++) { const x0 = p.x, y0 = p.y; __rc.tick(); p.x = x0; p.y = y0; if (G.beams.length && shadowT < 0) shadowT = i; if (G.dmgTaken > 0 && hitT < 0) hitT = i; } return { shadowT, hitT }; });
  check('Falling beam: shadow first, impact 60+ frames later', o.shadowT >= 0 && o.hitT - o.shadowT >= 55, JSON.stringify(o));
  o = await t.ev(() => { arena('punk', 0); const G = __rc.G; G.hazards = [{ kind: 'pit', x: 250, y: 190 }]; foe.x = 240; knock(foe, 3, 2); for (let i = 0; i < 60; i++) { foe.ai.cool = 9999; __rc.tick(); } return foe.killed; });
  check('Enemies knocked into the elevator shaft are KO\'d', o === true);
  // ---------- stage flow
  o = await t.ev(() => {
    __rc.eraseSave();
    __rc.startRun({ mode: 'story', diff: 1, classic: false, char: 'anita', partner: false, allyCmd: 0, stage: 1 });
    __rc.go('play');
    const G = __rc.G; G.loadQ = [];
    G.score = 30000; G.lives = 3;
    __rc.finishStage();
    for (let i = 0; i < 40; i++) __rc.tick();
    __rc.Input.keyEdges.add('Enter'); __rc.tick(); __rc.tick();
    __rc.Input.keyEdges.add('Enter'); __rc.tick(); __rc.tick();
    const s1 = __rc.SCREEN;
    for (let i = 0; i < 40; i++) __rc.tick();
    __rc.Input.keyEdges.add('Enter'); __rc.tick();
    const s2 = __rc.SCREEN;
    return { s1, s2, stage: __rc.G.stage, lives: __rc.G.lives, bg: __rc.G.scene.bg,
      want: __rc.STAGE_DATA[2].scenes[0].bg,
      xp: __rc.SAVE().chars.anita.xp, reached: __rc.SAVE().reached };
  });
  // the background is read from the stage table rather than hardcoded, so
  // redressing a scene does not break the flow check
  check('Stage 1 clear leads to the Stage 2 intro, then Stage 2', o.s1 === 'stageintro' && o.s2 === 'play' && o.stage === 2 && o.bg === o.want, JSON.stringify(o));
  check('Lives carry over; Anita earns her own mastery', o.lives >= 3 && o.xp > 0 && o.reached === 2, JSON.stringify(o));
  // ---------- shop per fighter
  o = await t.ev(() => {
    const r = __rc; r.SAVE().bank = 500000; r.go('shop', { tab: 1, fid: 'anita' }); r.tick();
    r.Input.keyEdges.add('Enter'); r.tick(); r.tick();
    const a = r.SAVE().chars.anita.moves.slice();
    r.Input.keyEdges.add('KeyU'); r.tick(); r.tick();
    const fid = r.S.fid;
    r.Input.keyEdges.add('Enter'); r.tick();
    return { a, fid, c: r.SAVE().chars.tank.moves.slice(), bank: r.SAVE().bank };
  });
  check('Shop MOVES tab buys per fighter; Y switches fighter', o.a.includes('triple') && o.fid === 'tank' && o.c.includes('clutchx') && o.bank === 500000 - 70000 - 70000, JSON.stringify(o));
  // ---------- sprite bake
  o = await t.ev(() => { const f = getFrame(LOOKS.cole, 'idle', null, null); const d = f.cv.getContext('2d').getImageData(0, 0, f.w, f.h).data; const cols = new Set(); let semi = 0; for (let i = 0; i < d.length; i += 4) { if (d[i + 3] && d[i + 3] < 255) semi++; if (d[i + 3]) cols.add((d[i] << 16) | (d[i + 1] << 8) | d[i + 2]); } return { h: f.h / PX, cols: cols.size, semi }; });
  check('Sprites are hard-edged pixel art with a limited palette', o.semi === 0 && o.cols < 48, JSON.stringify(o));
  check('Fighters are SoR3-sized (~85 px tall)', o.h >= 80 && o.h <= 110, JSON.stringify(o));
  console.log(results.map(r => r.join('  ')).join('\n'));
  console.log(results.filter(r => r[0] === 'PASS').length + '/' + results.length + ' passed');
  console.log(t.errors.slice(0, 5).join('\n') || 'no errors');
  await t.close();
})();
