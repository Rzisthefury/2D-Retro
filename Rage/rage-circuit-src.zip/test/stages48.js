const { launch } = require('./harness');
const results = [];
function check(name, ok, info = '') { results.push([ok ? 'PASS' : 'FAIL', name, info]); }
(async () => {
  const t = await launch();

  // every stage and every scene loads, prewarms, and runs
  for (let st = 1; st <= 8; st++) {
    const o = await t.ev(st => {
      const r = window.__rc;
      r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: true, partnerChar: 'anita', stage: st });
      r.go('play');
      const G = r.G, out = [];
      const nsc = r.STAGE_DATA[st].scenes.length;
      for (let i = 0; i < nsc; i++) {
        if (i) { r.loadScene(i, false); }
        for (let k = 0; k < 6000 && G.loadQ.length; k++) r.tick();
        for (let k = 0; k < 90; k++) r.tick();
        out.push({ name: G.scene.name, bg: G.scene.bg, ents: G.ents.length, q: G.loadQ.length });
      }
      return { nsc, out };
    }, st);
    const okAll = o.out.every(x => x.q === 0 && x.ents > 0);
    check(`stage ${st}: all ${o.nsc} scenes load and populate`, okAll, JSON.stringify(o.out.map(x => x.name)));
  }

  // scene counts match what we promised
  let o = await t.ev(() => {
    const out = {};
    for (let st = 1; st <= 8; st++) out[st] = window.__rc.STAGE_DATA[st].scenes.length;
    return out;
  });
  check('stages 6, 7 and 8 are three scenes long', o[6] === 3 && o[7] === 3 && o[8] === 3, JSON.stringify(o));
  check('stages 1-5 stay two scenes long', [1, 2, 3, 4, 5].every(k => o[k] === 2), JSON.stringify(o));

  // a wave placed past the camera's last reachable position soft-locks the run forever
  o = await t.ev(() => {
    const r = window.__rc, bad = [];
    const scenes = [];
    for (let st = 1; st <= 8; st++) r.STAGE_DATA[st].scenes.forEach((sc, i) => scenes.push([st, i, sc]));
    scenes.push(['rush', 0, r.BOSS_RUSH_STAGE.scenes[0]]);
    for (const [st, i, sc] of scenes) {
      const max = Math.max(0, sc.len - 426);
      for (const w of sc.waves) if (w.at > max) bad.push(`stage ${st} scene ${i} "${sc.name}": wave at ${w.at} > reachable ${max}`);
      const last = sc.waves[sc.waves.length - 1];
      if (last && last.boss && last.at > max) bad.push(`stage ${st} scene ${i}: boss wave unreachable`);
    }
    return bad;
  });
  check('no wave is placed past where the camera can reach (would soft-lock)', o.length === 0, o.join(' | '));

  // and every scene's props and hazards sit inside the scene
  o = await t.ev(() => {
    const r = window.__rc, bad = [];
    for (let st = 1; st <= 8; st++) r.STAGE_DATA[st].scenes.forEach((sc, i) => {
      for (const b of sc.breakables) if (b.x < 20 || b.x > sc.len + 380) bad.push(`stage ${st}.${i} prop at ${b.x}`);
      for (const h of sc.hazards) if (h.x !== undefined && (h.x < 20 || h.x > sc.len + 380)) bad.push(`stage ${st}.${i} hazard at ${h.x}`);
      for (const b of sc.breakables) if (b.y < 150 || b.y > 230) bad.push(`stage ${st}.${i} prop off the walkable band at y ${b.y}`);
    });
    return bad;
  });
  check('every prop and hazard sits inside its scene and on the walkable floor', o.length === 0, o.join(' | '));

  // every boss named in a stage exists and spawns
  o = await t.ev(() => {
    const r = window.__rc, keys = new Set();
    for (let st = 1; st <= 8; st++) for (const sc of r.STAGE_DATA[st].scenes) for (const w of sc.waves) if (w.boss) w.boss.forEach(k => keys.add(k));
    const missing = [...keys].filter(k => !r.BOSS_DEFS[k]);
    return { keys: [...keys], missing };
  });
  check('every boss a stage asks for is defined', o.missing.length === 0, JSON.stringify(o.missing));

  for (const key of ['gauge', 'vexb', 'slag', 'warden', 'dray', 'brick2', 'ruby2', 'rivet2']) {
    const b = await t.ev(k => {
      const r = window.__rc, G = r.G;
      r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 4 });
      r.go('play'); r.G.loadQ = [];
      r.G.scene.waves = []; r.G.waveIdx = 99; r.G.wave = null; r.G.spawnQ = [];
      r.G.ents = r.G.ents.filter(e => e.team === 'hero');
      const boss = r.spawnBoss(r.G.camX + 300, 190, k);
      r.G.loadQ = [];
      const states = new Set();
      for (let i = 0; i < 900; i++) { r.G.player.hp = r.G.player.maxHp; r.tick(); states.add(boss.state); }
      return { hp: boss.hp, max: boss.maxHp, states: [...states], dead: !!boss.killed, name: boss.name };
    }, key);
    check(`boss ${key} spawns, introduces itself and attacks`, b.states.length >= 3 && !b.dead, JSON.stringify(b.states));
  }

  // Dray's second phase
  o = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 8 });
    r.go('play');
    const G = r.G;
    G.loadQ = [];
    G.scene.waves = []; G.waveIdx = 99; G.wave = null; G.spawnQ = [];
    G.ents = G.ents.filter(e => e.team === 'hero');
    const b = r.spawnBoss(G.camX + 300, 190, 'dray');
    G.loadQ = [];
    for (let i = 0; i < 200; i++) r.tick();
    b.hp = 1;
    r.applyHit(G.player, b, { dmg: 99, type: 'K' });
    let mid = '';
    for (let i = 0; i < 220; i++) { r.tick(); if (b.state === 'bphase') mid = 'bphase'; }
    const now = G.bosses.filter(x => !x.remove && !x.killed);
    return { mid, next: now.map(x => x.def.name), done: G.done };
  });
  check('Dray collapses into a second phase instead of dying', o.mid === 'bphase' && o.next.some(n => n.indexOf('WARLORD') >= 0), JSON.stringify(o));

  // the vault capsule frees Unit-9
  o = await t.ev(() => {
    const r = window.__rc;
    r.SAVE().unlocks.unit9 = false;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 7 });
    r.go('play');
    const G = r.G;
    r.loadScene(2, false);
    G.loadQ = [];
    G.scene.waves = []; G.waveIdx = 99; G.wave = null; G.spawnQ = [];
    G.ents = G.ents.filter(e => e.team === 'hero');
    const cap = G.props.find(p => p.kind === 'capsule');
    if (!cap) return { found: false };
    const p = G.player;
    G.camX = cap.x - 200;                      // walk the camera up to it
    p.x = cap.x - 18; p.y = cap.y; p.face = 1;
    for (let i = 0; i < 200 && !cap.broken; i++) { p.x = cap.x - 18; r.startMove(p, 'jab1'); for (let k = 0; k < 10; k++) r.tick(); }
    return { found: true, broken: cap.broken, freed: G.freedUnit, saved: r.SAVE().unlocks.unit9 };
  });
  check('the Vault capsule can be broken and frees Unit-9', o.found && o.broken && o.freed && o.saved, JSON.stringify(o));

  // stage 5 scene 2 is a board run and the camera pulls you along
  o = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 5 });
    r.go('play');
    const G = r.G;
    r.loadScene(1, false); G.loadQ = [];
    G.scene.waves = []; G.waveIdx = 99; G.wave = null; G.spawnQ = [];
    G.ents = G.ents.filter(e => e.team === 'hero');
    const x0 = G.camX;
    const px0 = G.player.x;
    for (let i = 0; i < 120; i++) r.tick();   // no input at all
    return { ride: !!G.scene.ride, cam: Math.round(G.camX - x0), moved: Math.round(G.player.x - px0), name: G.scene.name };
  });
  check('the board run scrolls you forward with no input', o.ride && o.cam > 50 && o.moved > 30, JSON.stringify(o));

  // mid-stage boss waves hand back to the stage instead of ending it
  o = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 8 });
    r.go('play');
    const G = r.G;
    r.loadScene(1, false); G.loadQ = [];
    const bossWaves = G.scene.waves.filter(w => w.boss).length;
    G.camX = G.scene.waves[1].at; G.waveIdx = 1;
    for (let i = 0; i < 20; i++) r.tick();
    const spawned = G.bosses.length;
    for (const b of G.bosses) { b.hp = 0; b.killed = true; b.remove = true; }
    G.bosses = [];
    for (let i = 0; i < 10; i++) r.tick();
    return { bossWaves, spawned, done: G.done, clearT: G.clearT, idx: G.waveIdx };
  });
  check('the Executive Floor has two rematch fights and does not end on the first', o.bossWaves === 2 && o.spawned === 1 && !o.done && o.clearT === 0, JSON.stringify(o));

  // a boss that ends a middle scene must open the exit, not end the stage
  o = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 8 });
    r.go('play');
    const G = r.G;
    r.loadScene(1, false); G.loadQ = [];            // Executive Floor: middle scene, ends on a boss
    const waves = G.scene.waves;
    G.camX = waves[waves.length - 1].at; G.waveIdx = waves.length - 1;
    for (let i = 0; i < 30; i++) r.tick();
    const spawned = G.bosses.length;
    for (const b of G.bosses) { b.hp = 0; b.killed = true; b.remove = true; }   // dead, but still on the roster
    G.ents = G.ents.filter(e => e.team === 'hero');
    for (let i = 0; i < 20; i++) r.tick();
    return { spawned, done: G.done, clearT: G.clearT, exit: G.exitOpen, scene: G.sceneIdx };
  });
  check('beating the Executive Floor boss opens the way on instead of ending the stage',
    o.spawned === 2 && !o.done && o.clearT === 0 && o.exit, JSON.stringify(o));

  // ...while the final scene's boss does end it
  o = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 8 });
    r.go('play');
    const G = r.G;
    r.loadScene(2, false); G.loadQ = [];
    const waves = G.scene.waves;
    G.camX = waves[waves.length - 1].at; G.waveIdx = waves.length - 1;
    for (let i = 0; i < 30; i++) r.tick();
    for (const b of G.bosses) { b.hp = 0; b.killed = true; b.remove = true; }
    G.pendingBoss = false;
    G.ents = G.ents.filter(e => e.team === 'hero');
    for (let i = 0; i < 20; i++) r.tick();
    return { clearT: G.clearT > 0, scene: G.sceneIdx };
  });
  check('beating the Helipad boss does end the stage', o.clearT && o.scene === 2, JSON.stringify(o));

  console.log(results.map(r => `${r[0]}  ${r[1]}  ${r[2]}`).join('\n'));
  const fail = results.filter(r => r[0] === 'FAIL').length;
  console.log(`\n${results.length - fail}/${results.length} passed`);
  console.log(t.errors.length ? t.errors.slice(0, 6).join('\n') : 'no errors');
  await t.close();
  process.exit(fail ? 1 : 0);
})();
