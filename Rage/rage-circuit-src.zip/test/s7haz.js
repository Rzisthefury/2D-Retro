// The cold store carries a trailing cable and an open well. Park the camera on
// each so the reskinned hazard is checked against the background it sits in.
const { launch } = require('/home/claude/rage/test/harness');
(async () => {
  const t = await launch();
  for (const [scene, target, tag] of [[1, 700, 'wire'], [1, 1020, 'pit']]) {
    await t.ev(([scene, target]) => {
      const r = window.__rc;
      r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: true, partnerChar: 'anita', stage: 7 });
      r.go('play');
      const G = r.G;
      for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
      r.loadScene(scene, false);
      for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
      G.loadQ = []; G.banner = null; G.fade = 0; G.fadeDir = 0;
      G.ents = G.ents.filter(e => e.team === 'hero');
      G.spawnQ = []; G.wave = null; G.waveIdx = 99; G.lockX = null;
      for (let i = 0; i < 2200 && G.camX < target - 213; i++) { G.player.x += 0.9; r.tick(); G.banner = null; }
      for (const h of G.hazards) h.t = 110;                  // catch them mid-event
      for (let i = 0; i < 6; i++) { r.tick(); G.banner = null; }
    }, [scene, target]);
    await t.ev(() => window.__rc.render());
    await t.page.locator('#cv').screenshot({ path: `shots/s7_${tag}.png` });
  }
  console.log(t.errors.length ? 'PAGE ERRORS:\n' + t.errors.join('\n') : 'no errors');
  await t.close();
})();
