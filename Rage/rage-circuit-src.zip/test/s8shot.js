// In-game shots of the three new stage 8 scenes, with fighters on screen so
// the sprite-vs-background contrast is judged the way it will actually look.
const { launch } = require('/home/claude/rage/test/harness');
(async () => {
  const t = await launch();
  for (const sc of [0, 1, 2]) {
    await t.ev(s => {
      const r = window.__rc;
      r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: true, partnerChar: 'anita', allyCmd: 0, stage: 8 });
      r.go('play');
      const G = r.G;
      for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
      if (s) { r.loadScene(s, false); for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick(); }
      G.loadQ = []; G.banner = null; G.fade = 0; G.fadeDir = 0;
      for (let i = 0; i < 240; i++) { r.tick(); G.banner = null; }
    }, sc);
    await t.ev(() => window.__rc.render());
    await t.page.locator('#cv').screenshot({ path: `shots/s8_${sc}.png` });
    // and again further into the scene, so a long run is not judged on its head
    await t.ev(() => { const r = window.__rc, G = r.G;
      for (let i = 0; i < 900; i++) { G.player.x += 0.9; r.tick(); G.banner = null; } });
    await t.ev(() => window.__rc.render());
    await t.page.locator('#cv').screenshot({ path: `shots/s8_${sc}b.png` });
  }
  console.log(t.errors.length ? 'PAGE ERRORS:\n' + t.errors.join('\n') : 'no errors');
  await t.close();
})();
