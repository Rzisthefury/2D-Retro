const { launch } = require('./harness');
const results = [];
function check(name, ok, info = '') { results.push([ok ? 'PASS' : 'FAIL', name, info]); }
(async () => {
  const t = await launch();
  const scr = () => t.ev(() => window.__rc.SCREEN);
  await t.ev(() => window.__rc.eraseSave());
  await t.ticks(5);
  await t.press('Enter'); await t.ticks(3);
  check('title: press start opens the menu', await t.ev(() => window.__rc.S.menu === true));
  await t.shot('f_title_menu');
  // setup
  await t.press('Enter'); await t.ticks(3);
  check('START GAME opens setup', (await scr()) === 'setup');
  await t.press('ArrowDown'); await t.press('ArrowDown'); await t.press('ArrowRight');
  await t.press('ArrowDown'); await t.press('ArrowRight');
  await t.press('ArrowDown'); await t.press('ArrowRight');
  let o = await t.ev(() => ({ p: window.__rc.S.partner, c: window.__rc.S.cmd, d: window.__rc.S.diff }));
  check('setup toggles partner, command, difficulty', o.p === 1 && o.c === 1 && o.d === 2, JSON.stringify(o));
  await t.shot('f_setup');
  await t.press('ArrowUp'); await t.press('ArrowUp'); await t.press('ArrowUp'); await t.press('ArrowRight');
  o = await t.ev(() => ({ f: window.__rc.S.fighter }));
  await t.shot('f_setup_locked');
  await t.press('ArrowLeft');
  // code entry: hold LB(I)+RB(O) then ← ← → → Y X
  await t.ev(() => { const I = window.__rc.Input; I.keys.add('KeyI'); I.keys.add('KeyO'); });
  for (const k of ['ArrowLeft', 'ArrowLeft', 'ArrowRight', 'ArrowRight', 'KeyU', 'KeyJ']) { await t.ev(k => { const I = window.__rc.Input; I.keys.add(k); I.keyEdges.add(k); window.__rc.tick(); I.keys.delete(k); window.__rc.tick(); }, k); }
  await t.shot('f_code');
  await t.ev(() => { const I = window.__rc.Input; I.keys.delete('KeyI'); I.keys.delete('KeyO'); });
  o = await t.ev(() => ({ s: window.__rc.SESSION.unlocked.vex, saved: window.__rc.SAVE().unlocks.vex }));
  check('secret code unlocks Vex for this session only', o.s === true && !o.saved, JSON.stringify(o));
  // start: goes to intro then play
  for (let i = 0; i < 6; i++) await t.press('ArrowDown');
  await t.press('Enter'); await t.ticks(3);
  check('first start shows the story intro', (await scr()) === 'intro');
  await t.ticks(20); await t.shot('f_intro');
  await t.ev(() => { const I = window.__rc.Input; I.keyEdges.add('Enter'); });
  await t.ticks(2);
  await t.ev(() => { window.__rc.Input.pressed.start = true; });
  // skip with start (Enter maps to start)
  for (let i = 0; i < 6; i++) { await t.press('Enter'); await t.ticks(2); if ((await scr()) === 'play') break; }
  check('intro skips into the stage', (await scr()) === 'play', await scr());
  o = await t.ev(() => ({ partner: !!window.__rc.G.ally, cmd: window.__rc.G.allyCmd, diff: window.__rc.G.diff }));
  check('run uses the setup choices', o.partner && o.cmd === 1 && o.diff === 2, JSON.stringify(o));
  await t.ev(() => { for (let i = 0; i < 900 && window.__rc.G.loadQ && window.__rc.G.loadQ.length; i++) window.__rc.tick(); });
  await t.ticks(90); await t.shot('f_play_ally');
  // pause
  await t.press('Enter'); await t.ticks(2);
  check('start pauses', (await scr()) === 'pause');
  await t.shot('f_pause');
  await t.press('ArrowDown'); await t.press('Enter'); await t.ticks(2);
  check('pause -> move list', (await scr()) === 'movelist');
  await t.shot('f_movelist');
  await t.press('Escape'); await t.ticks(2);
  // cheats from pause
  await t.ev(() => window.__rc.go('cheats', { from: 'pause' })); await t.ticks(2);
  await t.shot('f_cheats');
  await t.press('Enter'); await t.ticks(2);
  o = await t.ev(() => ({ inv: window.__rc.CHEAT.invincible, flag: window.__rc.G.cheated }));
  check('cheat toggles and flags the run', o.inv === 1 && o.flag === true, JSON.stringify(o));
  await t.press('Enter'); await t.ticks(1);
  await t.press('Escape'); await t.ticks(2);
  check('cheats back to pause', (await scr()) === 'pause');
  // options from pause
  await t.ev(() => window.__rc.go('options', { from: 'pause' })); await t.ticks(2);
  await t.press('ArrowLeft'); await t.ticks(1);
  o = await t.ev(() => [window.__rc.SAVE().options.music, JSON.parse(localStorage.getItem('ragecircuit_save_v1')).options.music]);
  check('options change music volume and save', o[0] === 6 && o[1] === 6, String(o));
  await t.press('ArrowDown'); await t.press('ArrowDown'); await t.press('ArrowDown'); await t.press('Enter');
  o = await t.ev(() => window.__rc.SAVE().options.friendly);
  check('friendly fire toggles on', o === true);
  await t.press('Enter'); await t.ticks(1);
  await t.shot('f_options');
  // controls remap
  await t.ev(() => window.__rc.go('controls', { from: 'title' })); await t.ticks(2);
  await t.press('Enter'); await t.ticks(6);
  await t.page.keyboard.down('p'); await t.ticks(1); await t.page.keyboard.up('p'); await t.ticks(6);
  o = await t.ev(() => window.__rc.Input.keyMap().attack);
  check('remap attack key', o === 'KeyP', o);
  await t.shot('f_controls');
  await t.ev(() => { window.__rc.S.cur = 6; }); await t.press('Enter'); await t.ticks(2);
  o = await t.ev(() => window.__rc.Input.keyMap().attack);
  check('reset controls to defaults', o === 'KeyJ', o);
  // training
  await t.ev(() => { window.__rc.startRun({ mode: 'training' }); window.__rc.go('play'); });
  await t.ticks(30);
  o = await t.ev(() => { const G = window.__rc.G; const p = G.player; p.x = 230; p.y = 175; p.face = 1; const d = G.ents.find(e => e.type === 'dummy'); d.x = 256; d.y = 175; window.__rc.setIntent(() => ({ mx: 0, my: 0, atk: G.frames % 6 === 0 })); let nums = 0; for (let i = 0; i < 120; i++) { window.__rc.tick(); nums = Math.max(nums, G.fx.filter(f => f.k === 'num').length); } return { nums, dummies: G.ents.filter(e => e.type === 'dummy').length, hp: d.hp, score: G.score }; });
  check('training: dummies take hits, show damage numbers, never die', o.nums > 0 && o.dummies === 1 && o.hp === 9999 && o.score === 0, JSON.stringify(o));
  await t.shot('f_training');
  await t.ev(() => window.__rc.go('pause', { cur: 0 })); await t.ticks(1);
  await t.press('ArrowDown'); await t.press('ArrowRight'); await t.press('ArrowDown'); await t.press('ArrowRight'); await t.ticks(2);
  o = await t.ev(() => ({ m: window.__rc.G.trainDummy, c: window.__rc.G.trainCount, n: window.__rc.G.ents.filter(e => e.type === 'dummy').length }));
  check('training pause sets dummy behaviour and count', o.m === 1 && o.c === 2 && o.n === 2, JSON.stringify(o));
  await t.shot('f_training_pause');
  // shop
  await t.ev(() => { const r = window.__rc; r.SAVE().bank = 500000; r.go('shop', { tab: 0 }); }); await t.ticks(2);
  await t.press('Enter'); await t.press('Enter'); await t.ticks(1);
  o = await t.ev(() => ({ atk: window.__rc.SAVE().chars.cole.atk, bank: window.__rc.SAVE().bank }));
  check('buy attack tiers 1 and 2 (30k + 60k)', o.atk === 2 && o.bank === 410000, JSON.stringify(o));
  await t.shot('f_shop_up');
  await t.ev(() => { window.__rc.S.cur = 4; }); await t.press('Enter');
  o = await t.ev(() => ({ owned: window.__rc.SAVE().chars.cole.starlock, bank: window.__rc.SAVE().bank }));
  check('capstone locked until all stats are maxed', !o.owned && o.bank === 410000, JSON.stringify(o));
  await t.ev(() => { window.__rc.S.cur = 6; }); await t.press('Enter'); await t.press('Enter');
  o = await t.ev(() => ({ atk: window.__rc.SAVE().chars.cole.atk, bank: window.__rc.SAVE().bank }));
  check('respec refunds everything', o.atk === 0 && o.bank === 500000, JSON.stringify(o));
  await t.press('ArrowRight'); await t.press('ArrowRight'); await t.ticks(1);
  await t.press('Enter'); await t.press('ArrowDown'); await t.press('Enter'); await t.press('ArrowDown'); await t.press('Enter');
  o = await t.ev(() => ({ owned: window.__rc.SAVE().perksOwned, eq: window.__rc.SAVE().chars.cole.perks, bank: window.__rc.SAVE().bank }));
  check('perks: buy three, only two slots equip', o.owned.length === 3 && o.eq.length === 2, JSON.stringify(o));
  await t.ev(() => { window.__rc.S.cur = 6; }); await t.press('Enter');
  o = await t.ev(() => ({ slots: window.__rc.SAVE().slots }));
  check('buy a third perk slot', o.slots === 3, JSON.stringify(o));
  await t.ev(() => { window.__rc.S.cur = 2; }); await t.press('Enter');
  o = await t.ev(() => window.__rc.SAVE().chars.cole.perks.length);
  check('equip into the new slot', o === 3, String(o));
  await t.shot('f_shop_perks');
  await t.press('ArrowRight'); await t.press('Enter'); await t.press('Enter');
  o = await t.ev(() => window.__rc.SAVE().consumables.life);
  check('buy consumables', o === 2, String(o));
  await t.shot('f_shop_items');
  await t.press('ArrowRight'); await t.press('Enter');
  o = await t.ev(() => window.__rc.SAVE().cheatsOwned);
  check('buy a bonus cheat', o.includes('bigheads'), JSON.stringify(o));
  await t.shot('f_shop_extras');
  await t.press('ArrowRight'); await t.ticks(1); await t.shot('f_shop_mastery');
  // consumable used at stage start
  o = await t.ev(() => { const r = window.__rc; r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 }); r.go('play'); return { lives: r.G.lives, left: r.SAVE().consumables.life, perks: r.G.loadout }; });
  check('extra-life consumable applies once at stage start', o.lives === 6 && o.left === 1, JSON.stringify(o));
  o = await t.ev(() => { const r = window.__rc; r.startRun({ mode: 'story', diff: 1, classic: true, char: 'cole', partner: false, allyCmd: 0, stage: 1 }); return { lives: r.G.lives, left: r.SAVE().consumables.life, perks: r.G.loadout }; });
  check('classic run ignores perks and consumables', o.lives === 5 && o.left === 1 && o.perks.length === 0, JSON.stringify(o));
  // bigheads cheat appears
  await t.ev(() => window.__rc.go('cheats', { from: 'title' })); await t.ticks(1);
  o = await t.ev(() => cheatRows().some(r => r.c && r.c.id === 'bigheads'));
  check('bought cheat shows in the cheat menu', o);
  // persistence across reload
  await t.ev(() => window.__rc.writeSave());
  await t.page.reload(); await t.page.waitForTimeout(300); await t.ev(() => window.__rc.freeze(true));
  o = await t.ev(() => ({ bank: window.__rc.SAVE().bank, slots: window.__rc.SAVE().slots, perks: window.__rc.SAVE().chars.cole.perks.length, cheat: window.__rc.CHEAT.invincible, vex: window.__rc.SESSION.unlocked.vex }));
  check('save survives a reload; cheats and session codes do not', o.slots === 3 && o.perks === 3 && o.bank > 0 && o.cheat === 0 && !o.vex, JSON.stringify(o));
  // erase
  await t.ev(() => window.__rc.go('erase', { from: 'title', cur: 1 })); await t.ticks(1);
  await t.shot('f_erase');
  await t.press('ArrowLeft'); await t.press('Enter');
  o = await t.ev(() => ({ bank: window.__rc.SAVE().bank, slots: window.__rc.SAVE().slots, music: window.__rc.SAVE().options.music }));
  check('erase save wipes progress, keeps options', o.bank === 0 && o.slots === 2 && o.music === 6, JSON.stringify(o));
  // boss rush locked
  await t.ev(() => window.__rc.go('title', { menu: true, cur: 3 })); await t.ticks(1); await t.press('Enter');
  check('boss rush locked before a full clear', (await scr()) === 'title');
  // tally -> next stage / to be continued
  await t.ev(() => { const r = window.__rc; r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 }); r.G.loadQ = []; r.G.kos = 20; r.G.bestCombo = 14; r.G.score = 60000; r.G.stageFrames = 9000; r.finishStage(); });
  await t.ticks(200); await t.shot('f_tally');
  await t.press('Enter'); await t.ticks(3); check('stage 1 tally -> stage 2 intro', (await scr()) === 'stageintro', await scr());
  await t.shot('f_stageintro');
  await t.ticks(40); await t.press('Enter'); await t.ticks(4);
  o = await t.ev(() => ({ scr: window.__rc.SCREEN, stage: window.__rc.G.stage }));
  check('stage intro -> stage 2 plays', o.scr === 'play' && o.stage === 2, JSON.stringify(o));
  await t.ev(() => { const r = window.__rc; r.G.stage = 3; r.G.loadQ = []; r.G.score = 80000; r.finishStage(); });
  await t.ticks(220); await t.press('Enter'); await t.ticks(3); check('stage 3 tally -> stage 4 intro', (await scr()) === 'stageintro', await scr());
  // stage 5 clear recruits Vex
  await t.ev(() => { const r = window.__rc; r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 5 }); r.G.loadQ = []; r.G.score = 90000; r.finishStage(); });
  await t.ticks(200);
  check('clearing stage 5 unlocks Vex as a fighter', await t.ev(() => window.__rc.SAVE().unlocks.vex));
  // stage 8 clear: ending screen, boss rush unlocked
  await t.ev(() => { const r = window.__rc; r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 8 }); r.G.loadQ = []; r.G.score = 120000; r.finishStage(); });
  await t.ticks(220); await t.press('Enter'); await t.ticks(3);
  check('stage 8 tally -> ending', (await scr()) === 'ending', await scr());
  o = await t.ev(() => ({ cleared: window.__rc.SAVE().cleared, rush: window.__rc.SAVE().unlocks.bossrush, e: window.__rc.S.e.id }));
  check('a Medium clear without the capsule gives the GOOD ending and unlocks boss rush', o.cleared && o.rush && o.e === 'good', JSON.stringify(o));
  await t.ticks(200); await t.shot('f_ending');
  await t.press('Enter'); await t.ticks(4); await t.ticks(120); await t.shot('f_credits');
  // easy + capsule paths
  o = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 0, classic: false, char: 'cole', partner: false, stage: 8 });
    const a = r.endingFor().id;
    r.G.diff = 2; r.G.freedUnit = true;
    const b = r.endingFor().id;
    return { a, b };
  });
  check('Easy gives the plain ending; Medium+ with the capsule gives the best one', o.a === 'ok' && o.b === 'best', JSON.stringify(o));
  // boss rush now runs every boss back to back
  o = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, stage: 8, rush: true });
    r.go('play'); r.G.loadQ = [];
    return { waves: r.G.scene.waves.length, name: r.G.scene.name, rush: r.G.rush };
  });
  check('boss rush loads a scene of nothing but bosses', o.rush && o.name === 'BOSS RUSH' && o.waves === 8, JSON.stringify(o));
  await t.ev(() => { window.__rc.G = null; window.__rc.go('title', { menu: true }); });
  await t.ticks(3); check('back to title', (await scr()) === 'title', await scr());
  // continue screen render
  await t.ev(() => { const r = window.__rc; r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 }); r.go('continue', { n: 7 }); });
  await t.ticks(2); await t.shot('f_continue');
  // gallery / sound test
  await t.ev(() => { window.__rc.go('gallery', { page: 4 }); }); await t.ticks(2); await t.shot('f_gallery');
  await t.ev(() => { window.__rc.go('soundtest', {}); }); await t.ticks(2); await t.shot('f_soundtest');
  // big heads in play
  await t.ev(() => { const r = window.__rc; r.CHEAT.bigheads = 1; r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: true, allyCmd: 0, stage: 1 }); r.go('play'); });
  await t.ticks(160); await t.shot('f_bigheads');
  await t.ev(() => { window.__rc.CHEAT.bigheads = 0; });
  console.log(results.map(r => r.join('  ')).join('\n'));
  console.log(results.filter(r => r[0] === 'PASS').length + '/' + results.length + ' passed');
  console.log(t.errors.slice(0, 5).join('\n') || 'no errors');
  await t.close();
})();
