const { launch } = require('./harness');
(async () => {
  const t = await launch();
  const out = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 1 });
    r.go('play');
    const G = r.G; G.waveIdx = 99; G.ents = G.ents.filter(e => e.team === 'hero');
    const p = G.player; p.x = 150; p.y = 190;
    const f = r.spawnEnemy('punk', 180, 190, 1); f.enter = false;
    const e2 = r.spawnEnemy('punk', 110, 190, -1); e2.enter = false; e2.speed = 0;
    let hold = {};
    r.setIntent(() => { const I = Object.assign({ mx: 0, my: 0 }, hold); hold = {}; return I; });
    for (let i = 0; i < 20; i++) { hold = { mx: 1 }; f.ai.cool = 999; e2.ai.cool = 999; r.tick(); }
    const res = [p.state];
    hold = { atk: true, mx: -1 }; r.tick();
    for (let i = 0; i < 50; i++) { f.ai.cool = 999; e2.ai.cool = 999; r.tick(); res.push([i, f.state, Math.round(f.x), Math.round(f.y), Math.round(f.z), f.projBody, Math.round(e2.x), Math.round(e2.y), e2.state, e2.hp].join(',')); }
    return res;
  });
  console.log(out.join('\n'));
  await t.close();
})();
