const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
(async () => {
  const file = path.join(__dirname, '..', 'lab', 'lab.html');
  const server = http.createServer((q, r) => { r.writeHead(200, { 'Content-Type': 'text/html' }); r.end(fs.readFileSync(file)); });
  await new Promise(r => server.listen(0, r));
  const port = server.address().port;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1500, height: 1100 } });
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.goto(`http://localhost:${port}/`);
  await page.waitForTimeout(400);
  await page.evaluate(() => window.__rc.freeze(true));
  const shot = async (name, w, h, fn) => {
    await page.evaluate(([w, h]) => {
      const cv = document.getElementById('cv');
      cv.width = w; cv.height = h; cv.style.width = w + 'px'; cv.style.height = h + 'px';
      cv.getContext('2d').imageSmoothingEnabled = false;
    }, [w, h]);
    await page.evaluate(fn);
    await page.locator('#cv').screenshot({ path: `shots/${name}.png` });
  };

  await shot('q2_size', 1280, 760, () => {
    const c = window.__rc.ctx, L = window.__rc.LOOKS, D = window.__lab.drawFigureV, GF = window.__lab.getFrameV;
    c.fillStyle = '#585866'; c.fillRect(0, 0, 1280, 760);
    text('THE SAME FIGHTER, REDRAWN AT FOUR DETAIL LEVELS. HEADS BLOWN UP TO THE SAME SIZE SO YOU CAN COMPARE.', 16, 12, '#fff', 1, 0);
    const opts = [
      [1.00, '1   NOW', '426 x 240', 'HEAD IS 13 PX', 'same crowd', '#c85a5a'],
      [1.35, '2   BIGGER FIGHTERS', '426 x 240', 'HEAD IS 18 PX', 'FEWER FIT ON SCREEN', '#e8a020'],
      [1.50, '3   SHARPER GAME', '640 x 360', 'HEAD IS 20 PX', 'same crowd, same feel', '#5ad06a'],
      [2.00, '4   MAXIMUM', '854 x 480', 'HEAD IS 27 PX', 'same crowd, heavier', '#4ac0e8'],
    ];
    opts.forEach(([sc, lab, res, note, crowd, col2], i) => {
      const x = 165 + i * 310;
      c.fillStyle = 'rgba(0,0,0,0.24)'; c.fillRect(x - 150, 30, 300, 710);
      text(lab, x, 44, '#fff', 2, 1);
      text(res, x, 68, col2, 1, 1);
      // a look baked at this detail level
      const big = window.__rc.LOOKS['__s' + i] || (window.__rc.LOOKS['__s' + i] = recolor(L.cole, { scale: sc }));
      // head blown up so every option shows at the same on-sheet size
      // blit the head region of the baked frame straight out, scaled to a fixed cell
      const f = GF(big, 'idle', 'S', null);
      const sh = Math.round(20 * sc + 9), sw = Math.round(32 * sc + 10);
      const sx = Math.max(0, Math.round(f.ox - sw / 2)), sy = 0;
      const k = 176 / sh;
      c.imageSmoothingEnabled = false;
      c.drawImage(f.cv, sx, sy, sw, sh, Math.round(x - sw * k / 2), 88, Math.round(sw * k), Math.round(sh * k));
      c.strokeStyle = '#2a2a34'; c.lineWidth = 2; c.strokeRect(x - 90, 86, 180, 190);
      text(note, x, 286, col2, 1, 1);
      // true size figure
      D(x, 470, 1, 'straight', big, 'S', { scale: 1 });
      text('TRUE SIZE', x, 486, '#a8a8c8', 1, 1);
      text(crowd.toUpperCase(), x, 506, col2, 1, 1);
      // crowd at true size
      const per = 54 * sc;
      const n = Math.min(5, Math.floor(280 / per));
      for (let k = 0; k < n; k++) {
        const lk = window.__rc.LOOKS['__c' + i + k] || (window.__rc.LOOKS['__c' + i + k] = recolor(k % 2 ? L.punkA : L.bruiserA, { scale: sc }));
        D(x - 130 + 20 + k * per, 712, k % 2 ? -1 : 1, 'idle', lk, 'S', { scale: 1 });
      }
      text('A CROWD, TRUE SIZE', x, 728, '#a8a8c8', 1, 1);
    });
  });

  console.log(errs.slice(0, 5).join('\n') || 'no errors');
  await browser.close(); server.close();
})();
