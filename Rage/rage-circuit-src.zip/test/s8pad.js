// Park the camera on the helipad so the finale arena and the tied-down
// aircraft are judged the way the player meets them, and catch the atrium pit.
const { launch } = require('/home/claude/rage/test/harness');
(async () => {
  const t = await launch();
  const shot = async (scene, x, name) => {
    await t.ev(([sc, px]) => {
      const r = window.__rc;
      r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: true, partnerChar: 'anita', allyCmd: 0, stage: 8 });
      r.go('play');
      const G = r.G;
      for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
      if (sc) { r.loadScene(sc, false); for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick(); }
      G.loadQ = []; G.banner = null; G.fade = 0; G.fadeDir = 0;
      // clear the waves so the camera lock lets go, then walk to the spot
      G.ents = []; G.spawnQ = []; G.wave = null; G.lockX = null;
      for (let i = 0; i < 40; i++) { r.tick(); G.banner = null; }
      G.player.x = px; if (G.ally) G.ally.x = px - 40;
      for (const h of (G.hazards || [])) h.t = 110;
      for (let i = 0; i < 90; i++) { r.tick(); G.banner = null; G.ents = []; }
      // the camera lerps, so put it exactly where the shot wants it and settle
      G.camX = Math.max(0, Math.min(G.scene.len - 426, px - 213));
      for (let i = 0; i < 4; i++) { r.tick(); G.banner = null; G.ents = []; G.camX = Math.max(0, Math.min(G.scene.len - 426, px - 213)); }
    }, [scene, x]);
    await t.ev(() => window.__rc.render());
    await t.page.locator('#cv').screenshot({ path: `shots/${name}.png` });
  };
  await shot(0, 975, 's8_pit');     // the lift shaft the pit hazard stands in
  await shot(1, 1075, 's8_tower');  // the PHASE TWO model at mid-room
  await shot(2, 1000, 's8_pad');    // the pad, the aircraft, the tie-downs
  console.log(t.errors.length ? 'PAGE ERRORS:\n' + t.errors.join('\n') : 'no errors');
  await t.close();
})();
