const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
async function launch() {
  const file = path.join(__dirname, '..', 'dist', 'rage-circuit.html');
  const server = http.createServer((req, res) => { res.writeHead(200, { 'Content-Type': 'text/html' }); res.end(fs.readFileSync(file)); });
  await new Promise(r => server.listen(0, r));
  const port = server.address().port;
  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const page = await browser.newPage({ viewport: { width: 852, height: 520 } });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message + '\n' + e.stack));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE ' + m.text()); });
  await page.goto(`http://localhost:${port}/`);
  await page.waitForTimeout(300);
  await page.evaluate(() => window.__rc.freeze(true));
  const api = {
    page, errors,
    async close() { await browser.close(); server.close(); },
    // run n ticks with a key state
    async ticks(n, keys = []) {
      await page.evaluate(([n, keys]) => {
        const I = window.__rc.Input;
        for (const k of keys) { I.keys.add(k); I.keyEdges.add(k); }
        for (let i = 0; i < n; i++) window.__rc.tick();
        for (const k of keys) I.keys.delete(k);
        window.__rc.render();
      }, [n, keys]);
    },
    async press(code, hold = 1) { await api.ticks(hold, [code]); await api.ticks(1); },
    async shot(name) { await page.evaluate(() => window.__rc.render()); await api.grab(name); },
    // full backbuffer, not the CSS-scaled element
    async grab(name, dir) {
      const d = await page.evaluate(() => document.getElementById('cv').toDataURL('image/png'));
      fs.writeFileSync(path.join(dir || path.join(__dirname, '..', 'shots'), name + '.png'), Buffer.from(d.split(',')[1], 'base64'));
    },
    async ev(fn, arg) { return page.evaluate(fn, arg); },
  };
  return api;
}
module.exports = { launch };
