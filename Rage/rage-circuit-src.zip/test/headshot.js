const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
(async () => {
  const file = path.join(__dirname, '..', 'lab', 'lab.html');
  const server = http.createServer((q, r) => { r.writeHead(200, { 'Content-Type': 'text/html' }); r.end(fs.readFileSync(file)); });
  await new Promise(r => server.listen(0, r));
  const port = server.address().port;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 800 } });
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.goto(`http://localhost:${port}/`);
  await page.waitForTimeout(400);
  await page.evaluate(() => window.__rc.freeze(true));
  await page.evaluate(() => {
    const cv = document.getElementById('cv');
    cv.width = 1300; cv.height = 620; cv.style.width = '1300px'; cv.style.height = '620px';
    const c = cv.getContext('2d'); c.imageSmoothingEnabled = false;
    const L = window.__rc.LOOKS, D = window.__lab.drawFigureV;
    c.fillStyle = '#5a5a68'; c.fillRect(0, 0, 1300, 620);
    const who = [[L.cole, 'COLE'], [L.anita, 'ANITA'], [L.tank, 'TANK'], [L.brick, 'BRICK'], [L.vex, 'VEX']];
    text('B  HAND-PIXELED STAMP - what the game uses now', 16, 16, '#fff', 2, 0);
    text('C  CONSTRUCTED SKULL + JAW + HAIR MASS', 16, 316, '#fff', 2, 0);
    // clip each cell to just the head
    who.forEach(([look, lab], i) => {
      const x = 130 + i * 250;
      [['B', 60], ['C', 360]].forEach(([st, top]) => {
        const SC = 9;
        const f = window.__lab.getFrameV(look, 'idle', st, null);
        // frame top (crown) sits just inside the cell
        const feetY = top + 8 + f.oy * SC;
        c.save(); c.beginPath(); c.rect(x - 110, top, 220, 230); c.clip();
        D(x, feetY, 1, 'idle', look, st, { scale: SC });
        c.restore();
        c.strokeStyle = '#2a2a34'; c.lineWidth = 2; c.strokeRect(x - 110, top, 220, 230);
      });
      text(lab, x, 296, '#f2c94c', 2, 1);
    });
  });
  await page.locator('#cv').screenshot({ path: 'shots/lab_head.png' });
  console.log(errs.slice(0, 4).join('\n') || 'no errors');
  await browser.close(); server.close();
})();
