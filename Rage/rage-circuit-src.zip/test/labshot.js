const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
(async () => {
  const file = path.join(__dirname, '..', 'lab', 'lab.html');
  const server = http.createServer((q, r) => { r.writeHead(200, { 'Content-Type': 'text/html' }); r.end(fs.readFileSync(file)); });
  await new Promise(r => server.listen(0, r));
  const port = server.address().port;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
  const errs = [];
  page.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await page.goto(`http://localhost:${port}/`);
  await page.waitForTimeout(400);
  await page.evaluate(() => window.__rc.freeze(true));

  // big offscreen canvas so we can draw a poster-sized comparison sheet
  const shot = async (name, fn, w, h) => {
    await page.evaluate(([w, h]) => {
      const cv = document.getElementById('cv');
      cv.width = w; cv.height = h;
      cv.style.width = w + 'px'; cv.style.height = h + 'px';
      const c = cv.getContext('2d'); c.imageSmoothingEnabled = false;
    }, [w, h]);
    await page.evaluate(fn);
    await page.locator('#cv').screenshot({ path: `shots/${name}.png` });
  };

  // ---------- SHEET 1: body construction, same pose, 5 builds
  await shot('lab_build', () => {
    const c = window.__rc.ctx, L = window.__rc.LOOKS, D = window.__lab.drawFigureV;
    c.fillStyle = '#5a5a68'; c.fillRect(0, 0, 1320, 520);
    const styles = [['A', 'A  CURRENT'], ['B', 'B  TAPERED'], ['C', 'C  CONSTRUCTED'], ['D', 'D  REALISTIC'], ['E', 'E  RENDERED']];
    styles.forEach(([st, lab], i) => {
      const x = 140 + i * 258;
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(x - 118, 16, 236, 470);
      D(x, 430, 1, 'idle', L.cole, st, { scale: 3.4 });
      text(lab, x, 40, '#fff', 2, 1);
    });
  }, 1320, 520);

  // ---------- SHEET 2: same five, in a fighting pose + a female build
  await shot('lab_pose', () => {
    const c = window.__rc.ctx, L = window.__rc.LOOKS, D = window.__lab.drawFigureV;
    c.fillStyle = '#5a5a68'; c.fillRect(0, 0, 1320, 900);
    const styles = ['A', 'B', 'C', 'D', 'E'];
    const rows = [['straight', L.cole, 'COLE - PUNCH'], ['aHighKick', L.anita, 'ANITA - KICK'], ['heavyIdle', L.brick, 'BIG BRICK']];
    rows.forEach(([pose, look, lab], r) => {
      const y = 280 + r * 292;
      text(lab, 12, y - 250, '#fff', 2, 0);
      styles.forEach((st, i) => {
        const x = 150 + i * 252;
        c.fillStyle = 'rgba(0,0,0,0.22)'; c.fillRect(x - 118, y - 262, 236, 282);
        D(x, y, 1, pose, look, st, { scale: 2.5 });
        text(st, x - 108, y - 254, '#f2c94c', 2, 0);
      });
    });
  }, 1320, 900);

  // ---------- SHEET 3: heads — stamp vs constructed
  await shot('lab_head', () => {
    const c = window.__rc.ctx, L = window.__rc.LOOKS, D = window.__lab.drawFigureV;
    c.fillStyle = '#5a5a68'; c.fillRect(0, 0, 1320, 560);
    const who = [[L.cole, 'COLE'], [L.anita, 'ANITA'], [L.tank, 'TANK'], [L.brick, 'BRICK'], [L.warden, 'WARDEN']];
    text('B   HAND-PIXELED STAMP  (what the game uses now)', 20, 24, '#fff', 2, 0);
    text('C   CONSTRUCTED SKULL + JAW + HAIR MASS', 20, 300, '#fff', 2, 0);
    who.forEach(([look, lab], i) => {
      const x = 150 + i * 250;
      D(x, 250, 1, 'idle', look, 'B', { scale: 6 });
      D(x, 530, 1, 'idle', look, 'C', { scale: 6 });
      text(lab, x, 62, '#f2c94c', 1, 1);
    });
  }, 1320, 560);

  console.log(errs.slice(0, 6).join('\n') || 'no errors');
  await browser.close(); server.close();
})();
