// Checks the music wiring end to end: that every id the game can ask for
// resolves to a real track, that the new engine owns the ones it should, that
// the cues are one-shots that hand back, and that no room is silent.
//
// The point of this suite is that a music bug is invisible in every other
// test - the game plays fine with no sound at all - so nothing else in the
// repo would catch a track id that stopped resolving.
const { launch } = require('./harness');

(async () => {
  const t = await launch();
  let pass = 0, fail = 0;
  const ok = (name, cond, info) => {
    if (cond) { pass++; console.log('PASS ', name, info === undefined ? '' : JSON.stringify(info)); }
    else { fail++; console.log('FAIL ', name, JSON.stringify(info)); }
  };

  // ---- every id the game can ask for resolves somewhere -------------------
  const res = await t.ev(() => {
    const r = window.__rc;
    const out = { rooms: [], bosses: [], front: [], missing: [], band: [], old: [] };
    const STAGES = r.STAGE_DATA || {};
    for (const n in STAGES) {
      for (const sc of STAGES[n].scenes) out.rooms.push([STAGES[n].scenes.indexOf(sc), n, sc.name, sc.music]);
    }
    for (let i = 1; i <= 8; i++) out.bosses.push(i === 1 ? 'boss' : 'boss' + i);
    out.bosses.push('boss8x');
    out.front = ['title', 'menu', 'shop', 'training', 'ending'];
    const all = out.rooms.map(x => x[3]).concat(out.bosses, out.front, ['cue_unit9', 'cue_roof']);
    for (const id of all) {
      const inBand = RCBand.has(id), inOld = !!TRACKS[id];
      if (!inBand && !inOld) out.missing.push(id);
      else if (inBand) out.band.push(id); else out.old.push(id);
    }
    return out;
  });
  ok('every track id the game can ask for resolves', res.missing.length === 0, { missing: res.missing });
  ok('no room is left without music', res.rooms.every(r => r[3]), res.rooms.filter(r => !r[3]));

  // every room has its OWN track now - no two share one
  const ids = res.rooms.map(r => r[3]);
  const dupes = ids.filter((x, i) => ids.indexOf(x) !== i);
  ok('every room has a track of its own', dupes.length === 0, { shared: dupes });

  ok('the band owns everything except the leftovers', res.old.length === 0, { stillOnOldEngine: res.old });

  // ---- the band's own list is complete and prepped ------------------------
  const band = await t.ev(() => {
    const names = RCBand.names();
    const bad = names.filter(n => !(RCBand.seconds(n) > 0));
    return { count: names.length, bad, names };
  });
  ok('every band track has a real length', band.bad.length === 0, { zeroLength: band.bad });
  ok('band carries all 35 tracks', band.count === 35, { count: band.count });

  // ---- the songs themselves are structurally sound ------------------------
  // Two faults in a song are completely silent at runtime: a form section that
  // names a drum or bass pattern the song does not define (that lane simply
  // plays nothing), and a loopFrom that leaves nothing to loop over. The first
  // one is how stage 1's boss lost its entire kit while the dropout was being
  // fixed, so it is worth a check of its own.
  const audit = await t.ev(() => RCBand.audit());
  ok('no song names a pattern it does not define', audit.length === 0, { problems: audit });

  // ---- an intro plays once, not every time round the loop -----------------
  // This was the bug Michael reported as the music "crashing out" at the stage
  // 1 boss: the form looped back to its sparse two-bar intro every 41 seconds,
  // so what was written as an intro kept coming back as a hole in the fight.
  const loops = await t.ev(() => {
    const out = {};
    for (const n of RCBand.names()) out[n] = RCBand.loopInfo(n);
    return out;
  });
  const combat = Object.keys(loops).filter(n => /^(stage|boss)/.test(n));
  // Note the condition is on introish, NOT on introBars: introBars is derived
  // from loopFrom, so asserting on it would be a check that can only ever pass.
  ok('every combat track whose first section has no tune loops past it',
    combat.every(n => !loops[n].introish || loops[n].loopFrom > 0),
    combat.filter(n => loops[n].introish && loops[n].loopFrom === 0));
  ok('every track still has a body to loop over',
    Object.keys(loops).every(n => loops[n].loopBars >= 2),
    Object.keys(loops).filter(n => loops[n].loopBars < 2));

  // ---- routing: Music.play sends to the right engine ----------------------
  const route = await t.ev(() => {
    window.__rc.initAudio();
    const out = { haveAC: !!(typeof AC !== 'undefined' && AC) };
    Music.play('stage1a'); out.newIsBand = Music.band === true; out.newName = Music.name;
    Music.stop(); out.stopped = Music.name === null && Music.band === false;
    return out;
  });
  ok('a band track routes to the band', route.newIsBand && route.newName === 'stage1a', route);
  ok('stop clears both engines', route.stopped, route);

  // ---- the cues are one-shots that hand back ------------------------------
  const cue = await t.ev(() => {
    window.__rc.initAudio();
    Music.play('stage7c');
    const before = Music.name;
    Music.cue('cue_unit9');
    const during = { name: Music.name, back: Music.cueBack, timer: !!Music.cueT };
    Music.stop();
    return { before, during };
  });
  ok('the capsule cue plays and remembers what to return to',
    cue.during.name === 'cue_unit9' && cue.during.back === 'stage7c' && cue.during.timer, cue);

  // ---- the Birthing Floor capsule actually fires it -----------------------
  const cap = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 7 });
    r.go('play');
    const G = r.G;
    for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
    r.loadScene(2, false);
    for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
    window.__rc.initAudio();
    const cap = (G.props || []).find(p => p.objective === 'unit9');
    if (!cap) return { found: false };
    const was = Music.name;
    G.camX = Math.max(0, cap.x - 213);
    window.__rc.breakProp(cap, { kind: 'player' });
    const now = { name: Music.name, freed: !!G.freedUnit, back: Music.cueBack };
    Music.stop();
    return { found: true, was, now };
  });
  ok('breaking the capsule frees Unit-9', cap.found && cap.now.freed, cap);
  ok('breaking the capsule fires its cue', cap.found && cap.now.name === 'cue_unit9', cap);

  // ---- Dray's second form gets its own theme ------------------------------
  const phase = await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0, stage: 8 });
    r.go('play');
    const G = r.G;
    for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
    r.loadScene(2, false);
    for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
    window.__rc.initAudio();
    const b = r.spawnBoss(200, 190, 'dray');
    G.boss = b;
    Music.play('boss8');
    const before = Music.name;
    window.__rc.phaseInto(b);
    const after = Music.name;
    const nextIsFrame = !!(G.boss && G.boss.def && G.boss.def.final);
    Music.stop();
    return { before, after, nextIsFrame };
  });
  ok('Dray phases into the Warlord Frame', phase.nextIsFrame, phase);
  ok('the phase change switches the music', phase.before === 'boss8' && phase.after === 'boss8x', phase);

  // ---- the sound test lists everything ------------------------------------
  const st = await t.ev(() => {
    const names = window.__rc.musicList();
    return { count: names.length, hasCue: names.indexOf('cue_roof') >= 0, hasX: names.indexOf('boss8x') >= 0 };
  });
  ok('the sound test lists every track', st.count >= 35 && st.hasCue && st.hasX, st);

  // ---- the band goes through the game's music bus -------------------------
  // The lab engine connects its master straight to AC.destination. If that
  // survived the port, every new track would ignore the music volume option
  // and play at full blast - which no other test would ever notice.
  const bus = await t.ev(() => {
    window.__rc.initAudio();
    const S = window.__rc.SAVE();
    const before = S.options.music;
    S.options.music = 10; applyVolumes();
    const loud = masterMusic.gain.value;
    S.options.music = 2; applyVolumes();
    const quiet = masterMusic.gain.value;
    S.options.music = 0; applyVolumes();
    const off = masterMusic.gain.value;
    S.options.music = before; applyVolumes();
    // and the band is wired to that bus rather than straight to the speakers
    Music.play('stage1a');
    const onBand = Music.band === true && RCBand.playing() === 'stage1a';
    Music.stop();
    return { loud, quiet, off, onBand };
  });
  ok('the music volume option still moves the bus', bus.loud > bus.quiet && bus.quiet > bus.off && bus.off === 0, bus);
  ok('the band plays through that bus, not past it', bus.onBand, bus);

  console.log(`${pass}/${pass + fail} passed`);
  console.log(t.errors.length ? 'PAGE ERRORS:\n' + t.errors.join('\n') : 'no errors');
  await t.close();
  process.exit(fail ? 1 : 0);
})();
