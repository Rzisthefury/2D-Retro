const { launch } = require('./harness');
(async () => {
  const t = await launch();
  let pass = 0, fail = 0;
  const ok = (c, m) => { if (c) { pass++; } else { fail++; console.log('FAIL: ' + m); } };
  const arena = async (char, stage = 1) => {
    await t.ev(([ch, st]) => {
      const r = window.__rc;
      r.startRun({ mode: 'story', diff: 1, classic: false, char: ch, partner: false, stage: st });
      r.go('play');
      const G = r.G; G.loadQ = [];
      G.scene.waves = []; G.waveIdx = 99; G.wave = null; G.spawnQ = [];
      G.ents = G.ents.filter(e => e.team === 'hero');
      G.player.x = 120; G.player.y = 190;
    }, [char, stage]);
    await t.ticks(4);
  };
  const foe = async (x = 170) => t.ev(xx => {
    const r = window.__rc, G = r.G;
    const e = r.spawnEnemy('punk', xx, 190, 1);
    e.enter = false; e.speed = 0; e.state = 'ai'; e.maxHp = e.hp = 900;
    e.ai.mode = 'hold'; e.ai.cool = 9999;
    return e.id;
  }, x);
  const get = async id => t.ev(i => {
    const e = window.__rc.G.ents.find(q => q.id === i);
    return e ? { hp: e.hp, state: e.state, x: e.x, held: !!e.heldBy } : null;
  }, id);

  for (const ch of ['cole', 'anita', 'tank', 'jett']) {
    await arena(ch);
    const look = await t.ev(() => window.__rc.G.player.look.name);
    ok(look === ch, ch + ' uses its own look, got ' + look);
    const id = await foe();
    // basic combo chain
    for (let i = 0; i < 6; i++) { await t.press('KeyJ'); await t.ticks(6); }
    const f = await get(id);
    ok(f && f.hp < 900, ch + ' combo damages an enemy (hp ' + (f && f.hp) + ')');
    const err = await t.ev(() => window.__rc.G.player.state);
    ok(typeof err === 'string', ch + ' player still alive');
  }

  // --- Tank: running clutch grabs
  await arena('tank');
  const tid = await foe(210);
  await t.ev(() => { const G = window.__rc.G; G.player.state = 'run'; G.player.st = 10; G.player.face = 1; });
  await t.press('KeyU');            // back button = Y
  await t.ticks(16);
  const tg = await t.ev(() => { const p = window.__rc.G.player; return { state: p.state, grab: !!p.grab }; });
  ok(tg.grab && tg.state === 'grab', 'Tank running clutch pulls an enemy into a grab, got ' + JSON.stringify(tg));

  // --- Tank: iron hide armour
  await arena('tank');
  await t.ev(() => {
    const r = window.__rc, G = r.G;
    G.player.kit = 'tank';
    window.__rc.SAVE().chars.tank.moves = ['ironhide'];
    r.startMove(G.player, 'kbull');
  });
  await t.ticks(3);
  const armored = await t.ev(() => {
    const r = window.__rc, G = r.G, p = G.player;
    const f = r.spawnEnemy('punk', p.x + 20, p.y, 1);
    r.applyHit(f, p, { dmg: 6, type: 'L' });
    return { state: p.state, armorUsed: !!p.armorUsed };
  });
  ok(armored.state === 'move' && armored.armorUsed, 'Iron Hide eats the first hit of a charge, got ' + JSON.stringify(armored));

  // --- Jett: air dash
  await arena('jett');
  await t.press('KeyK');   // jump
  await t.ticks(8);
  const before = await t.ev(() => ({ x: window.__rc.G.player.x, left: window.__rc.G.player.dashLeft }));
  await t.press('KeyU');
  await t.ticks(10);
  const after = await t.ev(() => ({ x: window.__rc.G.player.x, left: window.__rc.G.player.dashLeft, st: window.__rc.G.player.state }));
  ok(before.left === 1, 'Jett starts a jump with one air dash, got ' + before.left);
  ok(after.x - before.x > 40, 'Jett air dash covers ground (' + Math.round(after.x - before.x) + 'px)');
  ok(after.left === 0, 'Jett air dash is spent after use');

  // --- Jett: double air dash upgrade
  await arena('jett');
  await t.ev(() => { window.__rc.SAVE().chars.jett.moves = ['airdash2']; });
  await t.press('KeyK');
  await t.ticks(6);
  const dd = await t.ev(() => window.__rc.G.player.dashLeft);
  ok(dd === 2, 'DOUBLE AIR DASH gives two dashes, got ' + dd);

  // --- specials for the new fighters
  for (const ch of ['tank', 'jett']) {
    await arena(ch);
    const id = await foe(150);
    await t.ev(() => { window.__rc.G.player.meter = 1; });
    await t.press('KeyL');
    await t.ticks(30);
    const f = await get(id);
    ok(f && f.hp < 900, ch + ' neutral special connects (hp ' + (f && f.hp) + ')');
  }

  // --- mastery + shop tables exist for everyone
  const tables = await t.ev(() => {
    const out = {};
    for (const id of ['cole', 'anita', 'tank', 'jett', 'vex', 'unit9']) {
      out[id] = {
        kit: !!window.__rc.KITS[id], mastery: !!window.__rc.MASTERY_BY_CHAR[id],
        shop: !!window.__rc.SHOP_MOVES[id], save: !!window.__rc.SAVE().chars[id],
        movelist: !!window.__rc.MOVE_LISTS[id],
      };
    }
    return out;
  });
  for (const id in tables) {
    const v = tables[id];
    ok(v.kit && v.mastery && v.shop && v.save && v.movelist, id + ' has kit/mastery/shop/save/movelist: ' + JSON.stringify(v));
  }

  console.log(`\nchars.js: ${pass} passed, ${fail} failed`);
  console.log(t.errors.length ? t.errors.slice(0, 6).join('\n') : 'no page errors');
  await t.close();
  process.exit(fail ? 1 : 0);
})();
