const { launch } = require('./harness');
const SETS = [
  [[[['tank', 'kIdle'], ['jett', 'jIdle'], ['tankCPU', 'kIdle'], ['jettCPU', 'jIdle'], ['vex', 'aIdle'], ['unit9', 'kIdle'], ['unit9CPU', 'kIdle']],
    [['tank', 'kHook'], ['tank', 'kSlam'], ['tank', 'kLariat1'], ['jett', 'jSpin'], ['jett', 'jDash'], ['jett', 'jUpper'], ['vex', 'vexLunge']]], 'cast-new1'],
  [[[['gauge', 'heavyIdle'], ['slag', 'heavyIdle'], ['warden', 'heavyIdle'], ['dray', 'idle'], ['drayx', 'heavyIdle'], ['suitA', 'idle'], ['suitB', 'idle']],
    [['guardA', 'idle'], ['guardB', 'idle'], ['bikerA', 'idle'], ['bikerB', 'idle'], ['robotB', 'idle'], ['gauge', 'slamDown'], ['drayx', 'roar']]], 'cast-new2'],
];
const NAMES = { tank: 'TANK', jett: 'JETT', tankCPU: 'CPU TANK', jettCPU: 'CPU JETT', vex: 'VEX', unit9: 'UNIT-9', unit9CPU: 'CPU UNIT-9',
  gauge: 'GAUGE', slag: 'SLAG', warden: 'WARDEN', dray: 'DRAY', drayx: 'DRAY-X', suitA: 'SUIT', suitB: 'SUIT',
  guardA: 'GUARD', guardB: 'GUARD', bikerA: 'BIKER', bikerB: 'BIKER', robotB: 'ROBOT-B' };
(async () => {
  const t = await launch();
  for (const [rows, name] of SETS) {
    await t.ev(([rows, names]) => { window.__rows = rows; window.__names = names; }, [rows, NAMES]);
    await t.ev(() => {
      const c = window.__rc.ctx;
      c.fillStyle = '#12101c'; c.fillRect(0, 0, 426, 240);
      window.__rows.forEach((row, ri) => row.forEach(([l, p], i) => {
        const x = 34 + i * 56, y = 112 + ri * 116;
        drawFigure(x, y, 1, p, window.__rc.LOOKS[l], {});
        text(window.__names[l] || l, x, y + 4, '#e8e8f0', 1, 1);
      }));
    });
    await t.grab(name);
  }
  console.log(t.errors.slice(0, 3).join('\n') || 'ok');
  await t.close();
})();
