const { launch } = require('./harness');
(async () => {
  const t = await launch();
  await t.ticks(30); await t.shot('01_title');
  await t.press('Enter'); await t.ticks(10); await t.shot('02_menu');
  await t.press('Enter'); await t.ticks(10); await t.shot('03_setup');
  // start game
  await t.ev(() => { const r = window.__rc; r.go('setup'); });
  await t.ticks(2);
  for (let i = 0; i < 6; i++) await t.press('ArrowDown');
  await t.press('Enter'); await t.ticks(5); await t.shot('04_intro');
  await t.press('Enter', 1); // skip via start key (Enter maps to both)
  await t.ticks(40);
  console.log('screen', await t.ev(() => window.__rc.SCREEN));
  await t.shot('05_play');
  await t.ticks(200, ['ArrowRight']);
  await t.shot('06_walk');
  for (let i = 0; i < 20; i++) { await t.press('KeyJ'); await t.ticks(3); }
  await t.shot('07_fight');
  const st = await t.ev(() => { const G = window.__rc.G; return { ents: G.ents.map(e => [e.kind, e.type, e.state, Math.round(e.x), Math.round(e.y), e.hp]), cam: G.camX, score: G.score }; });
  console.log(JSON.stringify(st));
  console.log(t.errors.join('\n') || 'no errors');
  await t.close();
})();
