const { launch } = require('./harness');
const SHOTS = [[4,0],[4,1],[5,0],[5,1],[6,0],[6,1],[6,2],[7,0],[7,1],[7,2],[8,0],[8,1],[8,2]];
(async () => {
  const t = await launch();
  for (const [st, sc] of SHOTS) {
    await t.ev(([st, sc]) => {
      const r = window.__rc;
      r.startRun({ mode: 'story', diff: 1, classic: false, char: 'cole', partner: true, partnerChar: 'anita', allyCmd: 0, stage: st });
      r.go('play');
      const G = r.G;
      for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
      if (sc) { r.loadScene(sc, false); for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick(); }
      G.loadQ = [];
      G.banner = null; G.fade = 0; G.fadeDir = 0;
      for (let i = 0; i < 150; i++) { r.tick(); G.banner = null; }
    }, [st, sc]);
    await t.ev(() => window.__rc.render());
    await t.page.locator('#cv').screenshot({ path: `shots/s${st}_${sc}.png` });
  }
  // board run, mid-ride
  await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 1, classic: false, char: 'jett', partner: true, partnerChar: 'tank', stage: 5 });
    r.go('play');
    const G = r.G;
    for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
    r.loadScene(1, false);
    for (let i = 0; i < 6000 && G.loadQ.length; i++) r.tick();
    G.loadQ = []; G.fade = 0; G.fadeDir = 0;
    for (let i = 0; i < 260; i++) { r.tick(); G.banner = null; }
  });
  await t.ev(() => window.__rc.render());
  await t.page.locator('#cv').screenshot({ path: 'shots/board.png' });
  // move list for each new fighter
  for (const ch of ['tank', 'jett']) {
    await t.ev(c => {
      const r = window.__rc;
      r.SAVE().chars[c].xp = 9600;
      r.SAVE().chars[c].moves = r.SHOP_MOVES[c].map(m => m.id);
      r.startRun({ mode: 'story', diff: 1, classic: false, char: c, partner: false, stage: 1 });
      r.G.loadQ = [];
      r.go('movelist', { back: 'pause' });
      r.tick();
    }, ch);
    await t.ev(() => window.__rc.render());
    await t.page.locator('#cv').screenshot({ path: `shots/ml_${ch}.png` });
  }
  // ending + credits
  await t.ev(() => {
    const r = window.__rc;
    r.startRun({ mode: 'story', diff: 2, classic: false, char: 'cole', partner: false, stage: 8 });
    r.G.freedUnit = true; r.G.loadQ = [];
    r.go('ending', { e: r.endingFor(), line: 9, t2: 0 });
    for (let i = 0; i < 60; i++) r.tick();
  });
  await t.ev(() => window.__rc.render());
  await t.page.locator('#cv').screenshot({ path: 'shots/ending.png' });
  console.log(t.errors.slice(0, 6).join('\n') || 'no errors');
  await t.close();
})();
