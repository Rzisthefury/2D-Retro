// ============================================================ FIGHT
let G = null;           // live run state
let ENT_ID = 0;
function newRunState(o) {
  return Object.assign({
    mode: 'story', diff: 1, classic: false, char: 'cole', partner: false, allyCmd: 0,
    stage: 1, sceneIdx: 0, scene: null, camX: 0, lockX: null, waveIdx: 0, wave: null, spawnQ: [],
    ents: [], items: [], props: [], projs: [], fx: [], hazards: [], car: null,
    player: null, ally: null, boss: null,
    score: 0, nextOneUp: TUNING.oneUpEvery, lives: 5, stars: 1, allyLives: 5,
    cheated: false, frames: 0, stageFrames: 0, stageScore0: 0, dmgTaken: 0, livesLost: 0,
    bestCombo: 0, combo: 0, comboT: 0, comboShow: 0, breaks: 0, breakTotal: 0, kos: 0,
    continued: false, goT: 0, shake: 0, flashT: 0, banner: null, fade: 0, fadeDir: 0, fadeCb: null,
    slowmo: 0, bossDead: false, clearT: 0, trainDummy: 0, trainCount: 1, trainRespawn: 0,
    tokens: 0, time: 0, xpGain: 0, loadout: [], bosses: [], beams: [], pendingBoss: false, partnerChar: null,
    rush: false, freedUnit: false, rideSpeed: 2.4,
  }, o);
}
const diffOf = () => DIFFS[G.diff];
const upgradesOn = () => !G.classic && G.mode === 'story';
function charSave(id) { return SAVE.chars[id || G.char] || SAVE.chars.cole; }
function kitOf(e) { return KITS[e.kit] || KITS.cole; }
function hasMove(e, id) { return e.kind === 'player' && upgradesOn() && (charSave(e.kit).moves || []).includes(id); }
function hasPerk(id) { return upgradesOn() && G.loadout.includes(id); }

// ------------------------------------------------------------ entity
function makeFighter(kind, o) {
  const e = Object.assign({
    id: ++ENT_ID, kind, x: 0, y: 190, z: 0, vx: 0, vy: 0, vz: 0, face: 1,
    hp: 100, maxHp: 100, state: 'stand', st: 0, mv: null, mvName: '', mf: 0, hitMask: 0,
    look: LOOKS.cole, name: '', team: kind === 'player' || kind === 'ally' ? 'hero' : 'foe',
    hitstop: 0, inv: 0, flash: 0, weapon: null, chain: null, chainT: 0, chainHit: false,
    grab: null, grabT: 0, grabCount: 0, grabBack: false, heldBy: null, contactT: 0,
    airAtk: null, airAtkF: 0, chargeT: 0, charging: false, meter: 1, dead: false, remove: false,
    juggle: 0, bounce: 0, projBody: 0, pendingDmg: 0, lastHitBy: null, pose: 'idle', dp: null,
    pw: { rage: 0, iron: 0, overdrive: 0 }, walkT: 0, ai: { t: 0, mode: 'approach', tok: false, cool: 0, side: 1, oy: 0 },
    w: 11, h: 60, type: null, pts: 0, stagger: 0, mash: 0, fallDmgTo: null, screen: null, dmgMult: 1,
    wakeArmor: 0, wakeGuard: 0, enter: false, sink: 0, poseLock: 0,
  }, o);
  e.dp = POSES.idle.slice();
  return e;
}
function spawnHero(kind, x, y, kit) {
  kit = kit || G.char;
  const K = KITS[kit] || KITS.cole;
  const cs = charSave(kit);
  const up = upgradesOn() && kind === 'player';
  const hpMul = up ? 1 + 0.1 * cs.hp : 1;
  const alt = kind === 'ally' && kit === G.char;
  const e = makeFighter(kind, {
    x, y, look: LOOKS[alt ? K.cpuLook : K.look], kit,
    name: (kind === 'ally' ? 'CPU ' : '') + K.name,
    w: Math.round(11 * GS), h: Math.round(60 * GS),
    maxHp: Math.round(100 * hpMul), atkMul: up ? 1 + 0.1 * cs.atk : 1,
    meterMul: up ? 1 + 0.1 * cs.meter : 1, defMul: up ? 1 - 0.06 * cs.def : 1,
  });
  e.hp = e.maxHp;
  return e;
}
function spawnEnemy(type, x, y, fromSide) {
  const T = ENEMY_TYPES[type];
  const lookKey = pick(T.looks);
  const hp = Math.round(T.hp * (type === 'dummy' ? 1 : diffOf().hp));
  const nm = type !== 'dummy' && chance(1 / 6) ? pick(SPECIAL_NAMES) : pick(T.names);
  const e = makeFighter('enemy', {
    type, x, y, look: LOOKS[lookKey], name: nm, maxHp: hp, hp, w: T.w * GS, pts: T.pts,
    speed: T.speed * (G.diff >= 3 ? 1.12 : 1), heavy: !!T.heavy, face: fromSide > 0 ? -1 : 1,
    weapon: T.weapon ? { kind: T.weapon, dur: 99 } : null, enter: true, h: (T.heavy ? 70 : 60) * GS,
    robot: !!T.robot,
  });
  e.ai.side = fromSide;
  e.ai.oy = rand(-14, 14);
  e.ai.t = irand(10, 40);
  G.ents.push(e);
  return e;
}
function spawnBoss(x, y, key = 'brick') {
  const D = BOSS_DEFS[key];
  const hp = Math.round(D.hp * diffOf().hp);
  const intro = D.type === 'twin' ? 'tintro' : D.type === 'mech' ? 'mintro' : D.type === 'vex' ? 'vintro' : 'bintro';
  const b = makeFighter('boss', {
    x, y, look: LOOKS[D.look] || LOOKS.rivet, name: D.name, maxHp: hp, hp, w: D.w * GS, h: D.h * GS, pts: D.pts,
    face: -1, state: intro, st: 0, speed: D.speed, heavy: D.type !== 'twin', def: D, noFemMap: D.type === 'twin',
  });
  b.boss = { type: D.type, key, mini: !!D.mini, phase: 1, pole: false, poleDone: !!D.mini, cool: 60, lane: 0, chargeDir: -1, cornerT: 0, pressure: 0 };
  b.idleState = D.type === 'twin' ? 'tidle' : D.type === 'mech' ? 'midle' : D.type === 'vex' ? 'vidle' : 'bidle';
  if (D.noPole) b.boss.poleDone = true;
  if (D.dmgMult) b.dmgMult = D.dmgMult;
  if (D.robot) b.robot = true;
  if (D.fire) b.fireBoss = true;
  if (D.beam) b.beamBoss = true;
  G.ents.push(b);
  G.bosses.push(b);
  if (!G.boss || G.boss.killed) G.boss = b;
  return b;
}
function liveBosses() { return G.bosses.filter(b => !b.killed && !b.remove); }
const heroes = () => G.ents.filter(e => e.team === 'hero' && !e.remove);
const foes = () => G.ents.filter(e => e.team === 'foe' && !e.remove);
const aliveHeroes = () => heroes().filter(e => !e.dead && e.state !== 'gone');
function isDownish(e) { return ['fall', 'down', 'getup', 'dead', 'screen', 'thrown', 'gone', 'manhole', 'respawn'].includes(e.state); }
function canBeHit(e) {
  if (e.remove || e.dead || e.inv > 0) return false;
  if (['down', 'dead', 'screen', 'gone', 'manhole', 'respawn', 'bintro', 'tintro', 'mintro', 'vintro', 'mbreak', 'bburst'].includes(e.state)) return false;
  if (e.state === 'getup' && e.st < 14) return false;
  if (e.state === 'fall' && e.juggle >= 2) return false;
  return true;
}

// ------------------------------------------------------------ moves
function startMove(e, name, st = 'move') {
  const mv = MOVES[name];
  e.mv = mv; e.mvName = name; e.mf = 0; e.hitMask = 0; e.state = st; e.st = 0;
  e.chainHit = false; e.hitIds = {}; e.armorUsed = false;
  if (mv.snd === 'clank' || name.startsWith('kn')) sfx('whiff');
  else if (mv.hits && mv.hits.length) sfx('whiff');
}
function moveStep(e) {
  const mv = e.mv;
  if (mv.step) for (const [a, b, v] of mv.step) if (e.mf >= a && e.mf < b) e.x += v * e.face * (e.pw.overdrive > 0 ? 1.3 : 1);
  if (mv.inv && e.mf >= mv.inv[0] && e.mf <= mv.inv[1]) e.inv = Math.max(e.inv, 1);
  e.pose = poseAt(mv, e.mf);
  checkMoveHits(e, mv.hits, e.mf);
  e.mf++;
}
function checkMoveHits(e, hits, f) {
  hits.forEach((h, i) => {
    if (f < h.f[0] || f > h.f[1]) return;
    const bit = 1 << i;
    const hitNow = [];
    const targets = e.team === 'hero'
      ? G.ents.filter(t => t.team === 'foe' || (SAVE.options.friendly && t.team === 'hero' && t !== e && G.mode === 'story'))
      : G.ents.filter(t => t.team === 'hero');
    for (const t of targets) {
      if (t === e || !canBeHit(t)) continue;
      if (e.hitIds && e.hitIds[i] && e.hitIds[i].has(t.id)) continue;
      if (boxHit(e, h, t)) hitNow.push(t);
    }
    // hydrants
    if (e.team === 'hero' || e.team === 'foe') for (const hz of G.hazards) if (hz.kind === 'hydrant') hydrantCheck(e, h, hz);
    // breakables
    if (e.team === 'hero') for (const p of G.props) if (!p.broken && propHit(e, h, p)) breakProp(p, e);
    if (!e.hitIds) e.hitIds = {};
    if (!e.hitIds[i]) e.hitIds[i] = new Set();
    for (const t of hitNow) {
      e.hitIds[i].add(t.id);
      if (h.grabs && canClutch(e, t)) { clutchGrab(e, t); return; }
      applyHit(e, t, h);
    }
    if (hitNow.length) e.hitMask |= bit;
  });
}
function hitRange(e, h) {
  const reach = (e.kind === 'boss' && e.boss && e.boss.type === 'brick' ? (e.look.scale || 1) : (e.look.scale || 1)) * GS;
  const a = e.x + e.face * h.x[0] * reach, b = e.x + e.face * h.x[1] * reach;
  return [Math.min(a, b), Math.max(a, b)];
}
function boxHit(e, h, t) {
  const [x0, x1] = hitRange(e, h);
  const tw = t.w;
  if (x1 < t.x - tw || x0 > t.x + tw) return false;
  const tol = (e.kind === 'boss' || t.kind === 'boss' ? 17 : TUNING.depthTol) + (h.dy || 0);
  if (Math.abs(e.y - t.y) > tol) return false;
  const reach = (e.look.scale || 1) * GS;
  const z0 = e.z + h.z[0] * reach, z1 = e.z + h.z[1] * reach;
  const tz0 = t.z, tz1 = t.z + (t.state === 'fall' ? 30 * GS : t.h);
  return !(z1 < tz0 || z0 > tz1);
}
function propHit(e, h, p) {
  const [x0, x1] = hitRange(e, h);
  return !(x1 < p.x - 10 || x0 > p.x + 10) && Math.abs(e.y - p.y) <= 12 && e.z < 30;
}
function heroPower(e) {
  let m = e.atkMul || 1;
  if (e.pw.rage > 0) m *= 2;
  return m;
}
function applyHit(att, t, h, opt = {}) {
  let dmg = h.dmg;
  if (att.team === 'hero') {
    dmg *= heroPower(att);
    if (att.kind === 'player' && G.mode === 'story' && CHEAT.onehit && t.team === 'foe') dmg = 9999;
    if (h.starBonus) dmg += h.starBonus;
  } else {
    dmg *= diffOf().dmg * (att.dmgMult || 1);
  }
  if (t.team === 'hero') {
    if (att.team === 'hero') dmg *= 0.5;
    dmg *= t.defMul || 1;
    if (t.kind === 'player' && CHEAT.invincible) dmg = 0;
    if (G.mode === 'training') dmg = 0;
  }
  if (t.state === 'mstall') dmg *= 1.5;
  dmg = Math.max(dmg > 0 ? 1 : 0, Math.round(dmg));
  if (t.kind === 'boss') { t.lastHurtF = G.frames; bossPressure(t); }
  if (t.type === 'dummy') { G.fx.push({ k: 'num', x: t.x, y: t.y - t.h - 6, v: dmg, t: 50 }); }
  else t.hp -= dmg;
  if (t.team === 'hero' && dmg > 0) { G.dmgTaken += t.kind === 'player' ? dmg : 0; }
  t.lastHitBy = att;
  t.flash = 4;
  const heavy = h.type !== 'L';
  const stop = h.type === 'K' ? TUNING.hitstopK : h.type === 'H' ? TUNING.hitstopH : TUNING.hitstopL;
  att.hitstop = Math.max(att.hitstop, stop);
  t.hitstop = Math.max(t.hitstop, stop);
  sfx(h.type === 'K' ? (h.dmg >= 12 ? 'hitX' : 'hitH') : heavy ? 'hitH' : 'hitL');
  const hx = (att.x + t.x) / 2 + t.face * 0, hz = t.z + t.h * 0.6;
  G.fx.push({ k: 'spark', x: t.x - sign(t.x - att.x) * 6, y: t.y, z: hz, t: 8, big: heavy, fire: h.fire });
  if (h.type === 'K' || h.dmg >= 10) G.shake = Math.max(G.shake, h.type === 'K' ? 5 : 3);
  if (att.kind === 'player' || t.kind === 'player') rumble(heavy ? 0.7 : 0.35, heavy ? 0.5 : 0.25, heavy ? 140 : 70);
  if (att.team === 'hero' && t.team === 'foe') { G.lastFoe = t; G.lastFoeT = 200; }
  if (att.kind === 'player' && t.team === 'foe') {
    addScore(dmg * 10);
    bumpCombo();
    att.chainHit = true;
  }
  if (t.team === 'hero' && t.kind === 'player') resetCombo(true);
  // reaction
  if (t.grab) releaseGrab(t);
  if (t.heldBy) { t.heldBy = null; }
  const dir = sign(t.x - att.x) || att.face;
  const killed = t.hp <= 0;
  if (t.kind === 'boss') {
    if (t.boss.type === 'mech') return mechHitReact(att, t, h, dmg, dir, killed);
    if (t.boss.type === 'twin') { if (twinHitReact(att, t, h, dmg, dir, killed)) return; }
    else return bossHitReact(att, t, h, dmg, dir, killed);
  }
  const iron = t.team === 'hero' && t.pw.iron > 0 && !killed;
  if (iron) return;
  // Wake guard: a hero who just stood up from a chained knockdown cannot be put
  // straight back down. The hit still hurts, it just does not restart the loop.
  let hType = h.type;
  if (t.team === 'hero' && t.wakeGuard > 0 && hType === 'K' && !killed && t.state !== 'fall' && t.z <= 1) {
    hType = 'H';
    t.wakeGuard = 0;
    G.fx.push({ k: 'ring', x: t.x, y: t.y, z: 40, t: 12, col: 'rgba(242,201,76,0.8)' });
  }
  // TANK: IRON HIDE shrugs off the first hit of any charge attack
  if (!killed && t.kind === 'player' && hasMove(t, 'ironhide') && !t.armorUsed && h.type !== 'K' &&
      ((t.state === 'move' && t.mv && ['kbull', 'kbull3', 'kgut', 'kquake', 'kquake2'].includes(t.mvName)) || t.charging)) {
    t.armorUsed = true; t.flash = 6;
    G.fx.push({ k: 'ring', x: t.x, y: t.y, z: 44, t: 12, col: '#c8d8f0' });
    return;
  }
  if (t.robot && !killed && h.type === 'L' && t.state !== 'fall') return;
  if (t.state === 'fall') {
    t.juggle++;
    knock(t, dir * Math.max(1.5, (h.kx || 2) * 0.7), Math.max(2.4, (h.kz || 2.5) * 0.8));
  // Anyone caught off the ground comes down. Checking `z` rather than the state
  // name covers every airborne state - 'jump', the kicker's 'jkick', air moves -
  // instead of only the one. A non-knockdown hit used to put an airborne enemy
  // into 'hurt' with its height frozen, and nothing after that applies gravity,
  // so it walked around at head height for the rest of the fight.
  } else if (killed || hType === 'K' || (t.kind !== 'boss' && (t.state === 'jump' || t.z > 1))) {
    knock(t, dir * (h.kx || 2.4), h.kz || 3);
    if (h.proj) t.projBody = 40;
  } else {
    t.state = 'hurt'; t.st = 0; t.mv = null;
    t.hurtT = hType === 'H' ? TUNING.hurtH : TUNING.hurtL;
    t.pose = hType === 'H' ? 'hurt2' : 'hurt1';
    t.x += dir * (hType === 'H' ? 3 : 1.5);
    t.face = -dir;
    if (t.type === 'dummy' && G.trainDummy === 2) { t.state = 'stand'; t.pose = 'idle'; }
  }
  if (t.weapon && (hType === 'K' || killed)) dropWeapon(t);
}
function knock(t, vx, vz) {
  if (t.grab) releaseGrab(t);
  t.state = 'fall'; t.st = 0; t.mv = null;
  t.vx = vx; t.vz = vz; t.z = Math.max(t.z, 1);
  t.face = -sign(vx) || t.face;
  t.bounce = 0;
  t.pose = 'fall';
  t.poseLock = 0;
  if (t.weapon) { if (t.kind === 'boss' && t.weapon.kind === 'pole') dropBossPole(t); else dropWeapon(t); }
}
function dropWeapon(t) {
  const w = t.weapon; t.weapon = null;
  if (!w || w.kind === 'whip' || w.kind === 'pole') return;
  const it = spawnItem(t.x, t.y, w.kind, null, 2.5);
  it.dur = w.dur; it.vx = rand(-1, 1);
}

// ------------------------------------------------------------ scoring / combo
function addScore(n) {
  if (G.mode !== 'story') return;
  G.score += Math.round(n);
  while (G.score >= G.nextOneUp) {
    G.nextOneUp += TUNING.oneUpEvery;
    G.lives++; sfx('oneup');
    popText('1UP!', G.player ? G.player.x : G.camX + 200, G.player ? G.player.y - 80 : 120, '#3ac84a');
  }
  const ss = TUNING.starScores;
  let lvl = 1; for (let i = 0; i < ss.length; i++) if (G.score >= ss[i]) lvl = i + 1;
  if (lvl > G.starsFromScore) {
    G.starsFromScore = lvl;
    if (G.stars < lvl) { G.stars = lvl; sfx('power'); popText('STAR UP!', G.player.x, G.player.y - 80, '#f2c94c'); }
  }
}
function bumpCombo() { G.combo++; G.comboT = TUNING.comboTimeout; G.comboShow = 90; if (G.combo > G.bestCombo) G.bestCombo = G.combo; }
function resetCombo(hurt) {
  if (G.combo >= 5) {
    const bonus = Math.min(20000, G.combo * G.combo * 10);
    addScore(bonus);
    if (G.player) popText('COMBO +' + fmt(bonus), G.player.x, G.player.y - 90, '#f2c94c');
  }
  G.combo = 0; G.comboT = 0;
}
function popText(s, x, y, col) { G.fx.push({ k: 'txt', s, x, y, col, t: 70 }); }

// ------------------------------------------------------------ items
function spawnItem(x, y, kind, power, hop = 2) {
  const it = { x, y, z: 4, vz: hop, vx: 0, kind, power, t: 0, dur: kind === 'pipe' ? 14 : kind === 'knife' ? 12 : 0 };
  G.items.push(it);
  return it;
}
function itemFromCode(code, x, y) {
  let kind = code, power = null;
  if (code.startsWith('p:')) { kind = 'power'; power = code.slice(2); }
  const d = diffOf();
  if (d.drop < 1 && Math.random() > d.drop) {
    if (kind === 'roast') kind = 'apple';
    else if (kind === 'power' && power !== 'oneup') { kind = 'cash'; power = null; }
  }
  if (CHEAT.wrain && chance(0.5)) { kind = chance(0.5) ? 'pipe' : 'knife'; power = null; }
  return spawnItem(x, y, kind, power, 2.6);
}
function updateItems() {
  for (const it of G.items) {
    it.t++;
    if (it.z > 0 || it.vz > 0) { it.z += it.vz; it.vz -= 0.3; it.x += it.vx; if (it.z <= 0) { it.z = 0; it.vz = 0; it.vx = 0; } }
    if (it.falling) { if (it.z <= 0) it.falling = false; }
    // points vanish after a while; others stay
    if ((it.kind === 'cash' || it.kind === 'gold') && it.t > 60 * 20) it.gone = true;
  }
  G.items = G.items.filter(i => !i.gone);
}
function itemNear(e) {
  let best = null, bd = 1e9;
  for (const it of G.items) {
    if (it.z > 2) continue;
    const dx = Math.abs(it.x - e.x), dy = Math.abs(it.y - e.y);
    if (dx < 15 && dy < 9 && dx + dy < bd) { best = it; bd = dx + dy; }
  }
  return best;
}
function takeItem(e, it) {
  it.gone = true;
  const k = it.kind;
  if (k === 'apple' || k === 'roast') {
    let amt = e.maxHp * (k === 'apple' ? 0.3 : 1);
    if (e.kind === 'player' && hasPerk('hearty')) amt *= 1.5;
    e.hp = Math.min(e.maxHp, e.hp + Math.round(amt));
    sfx('food'); popText(k === 'apple' ? '+HP' : 'FULL HP', e.x, e.y - 70, '#5ad06a');
  } else if (k === 'cash' || k === 'gold') {
    const v = k === 'cash' ? 1000 : 5000;
    if (e.kind === 'player') { addScore(v); popText('+' + fmt(v), e.x, e.y - 70, '#f2c94c'); }
    sfx('cash');
  } else if (k === 'pipe' || k === 'knife') {
    if (e.weapon) dropWeapon(e);
    let dur = it.dur || 12;
    if (e.kind === 'player' && hasPerk('tough') && !it.toughApplied) dur *= 2;
    e.weapon = { kind: k, dur };
    sfx('pickup');
  } else if (k === 'power') {
    applyPower(e, it.power);
  }
}
function applyPower(e, p) {
  const lf = e.kind === 'player' && hasPerk('longpow') ? 1.5 : 1;
  sfx(p === 'oneup' ? 'oneup' : 'power');
  const lab = { rage: 'RAGE!', iron: 'IRON BODY!', overdrive: 'OVERDRIVE!', refill: 'METER FULL!', starup: 'STAR UP!', oneup: '1UP!' }[p];
  popText(lab, e.x, e.y - 76, '#fff');
  if (p === 'rage' || p === 'iron' || p === 'overdrive') e.pw[p] = Math.round(TUNING.powerTime[p] * lf);
  else if (p === 'refill') e.meter = 1;
  else if (p === 'starup') { if (e.kind === 'player') G.stars = Math.min(3, G.stars + 1); }
  else if (p === 'oneup') { if (e.kind === 'player') G.lives++; else G.allyLives++; }
}

// ------------------------------------------------------------ props & hazards
function breakProp(p, by) {
  p.broken = true; p.flash = 4;
  G.breaks++;
  sfx('brk');
  for (let i = 0; i < 7; i++) G.fx.push({ k: 'debris', x: p.x, y: p.y, z: 12, vx: rand(-2.5, 2.5), vz: rand(1.5, 4), t: 40, col: p.kind === 'crate' ? '#a8743a' : p.kind === 'barrel' ? '#b8402a' : '#7a8490' });
  if (p.item) itemFromCode(p.item, p.x, p.y + 1);
  if (by && by.kind === 'player') addScore(200);
  if (p.objective === 'unit9' && !G.freedUnit) {
    G.freedUnit = true;
    addScore(15000);
    popText('UNIT-9 IS FREE!', p.x, p.y - 80, '#3ae0c0');
    G.banner = { s: 'UNIT-9 FREED', t: 170, col: '#3ae0c0', sub: 'IT WALKS OUT ON ITS OWN' };
    G.flashT = 5; sfx('levelup');
    for (let i = 0; i < 18; i++) G.fx.push({ k: 'debris', x: p.x, y: p.y, z: 30, vx: rand(-3, 3), vz: rand(2, 5), t: 45, col: pick(['#3ae0c0', '#8ef0e0', '#3a4a58']) });
    // Eight seconds that play once, then the floor's music comes back. The
    // capsule is not a wave, so this is the only place it can be fired from.
    Music.cue('cue_unit9');
    if (!G.cheated) { SAVE.unlocks.unit9 = true; writeSave(); }
  }
}
function hydrantCheck(e, h, hz) {
  if (hz.cool > 0) return;
  const [x0, x1] = hitRange(e, h);
  if (x1 < hz.x - 7 || x0 > hz.x + 7 || Math.abs(e.y - hz.y) > 12) return;
  hz.cool = 420; hz.spray = 180; hz.dir = sign(hz.x - e.x) || 1;
  sfx('water'); sfx('clank');
  if (e.kind === 'player') addScore(100);
}
function updateHazards() {
  for (const hz of G.hazards) {
    if (hz.kind === 'hydrant') {
      if (hz.cool > 0) hz.cool--;
      if (hz.spray > 0) {
        hz.spray--;
        if (hz.spray % 20 === 0 && hz.spray > 20) sfx('water');
        const x0 = hz.dir > 0 ? hz.x + 4 : hz.x - 84, x1 = hz.dir > 0 ? hz.x + 84 : hz.x - 4;
        for (const e of G.ents) {
          if (!canBeHit(e) || e.kind === 'boss' || e.state === 'fall' || e.z > 20) continue;
          if (e.x > x0 && e.x < x1 && Math.abs(e.y - hz.y) < 12) {
            if (e.hydroT && G.frames - e.hydroT < 50) continue;
            e.hydroT = G.frames;
            const fake = { x: hz.x, face: hz.dir, team: 'hazard', kind: 'hazard', look: {}, pw: {}, hitstop: 0 };
            applyHazardHit(e, 6, hz.dir * 3.2, 3.2);
          }
        }
        for (let i = 0; i < 2; i++) G.fx.push({ k: 'drop', x: hz.x + hz.dir * 4, y: hz.y, z: 16, vx: hz.dir * rand(2, 4.5), vz: rand(0.5, 2.2), t: 30 });
      }
    } else if (hz.kind === 'wire') {
      hz.t = ((hz.t || 0) + 1) % 200;
      if (hz.t === 60) sfx('warn');
      if (hz.t === 100) { sfx('zap'); G.shake = Math.max(G.shake, 2); }
      if (hz.t >= 100 && hz.t < 130) {
        for (const e of G.ents) {
          if (!canBeHit(e) || e.kind === 'boss' || e.z > 4) continue;
          const dx = (e.x - hz.x) / 30, dy = (e.y - hz.y) / 9;
          const cyc = hz.cycle || 0;
          if (dx * dx + dy * dy < 1 && e.zapCycle !== cyc) {
            e.zapCycle = cyc;
            applyHazardHit(e, 10, sign(e.x - hz.x) * 2 || 2, 3.4);
            e.shockT = 30;
            if (e.team === 'foe' && G.player) addScore(300);
          }
        }
      }
      if (hz.t === 0) hz.cycle = (hz.cycle || 0) + 1;
      if (hz.cycle === undefined) hz.cycle = 0;
    } else if (hz.kind === 'beams') {
      hz.cd = (hz.cd === undefined ? 180 : hz.cd) - 1;
      if (hz.cd <= 0 && !G.clearT && G.mode === 'story') {
        hz.cd = Math.round(hz.every * (1.3 - G.diff * 0.12)) + irand(0, 60);
        const hs = aliveHeroes();
        const tgt = hs.length ? pick(hs) : null;
        const x = clamp((tgt ? tgt.x : G.camX + W / 2) + rand(-24, 24), G.camX + 30, G.camX + W - 30);
        const y = clamp((tgt ? tgt.y : 190) + rand(-6, 6), TUNING.bandTop + 6, TUNING.bandBot - 6);
        G.beams.push({ x, y, t: 0, z: 220 });
        sfx('warn');
      }
    } else if (hz.kind === 'manhole' || hz.kind === 'pit') {
      const rx = hz.kind === 'pit' ? 30 : 16, ry = hz.kind === 'pit' ? 7 : 6;
      for (const e of G.ents) {
        if (e.kind === 'boss' || e.remove || e.state === 'manhole' || e.state === 'gone' || e.state === 'respawn' || e.state === 'screen') continue;
        if (e.z > 3 || e.state === 'grabbed' || e.state === 'held') continue;
        const dx = (e.x - hz.x) / rx, dy = (e.y - hz.y) / ry;
        if (dx * dx + dy * dy < 1) {
          e.state = 'manhole'; e.st = 0; e.mv = null; e.x = hz.x; e.y = hz.y; e.vx = e.vz = 0;
          if (e.grab) releaseGrab(e);
          sfx('ko');
          if (e.team === 'foe') { e.hp = 0; if (G.player) addScore(e.pts + 300); popText(hz.kind === 'pit' ? 'SHAFTED!' : 'MANHOLE!', hz.x, hz.y - 40, '#4ac0e8'); }
        }
      }
    }
  }
  // falling beams
  for (const bm of G.beams) {
    bm.t++;
    const fallAt = 70 - G.diff * 6;
    if (bm.t > fallAt && bm.z > 0) {
      bm.z = Math.max(0, bm.z - 24);
      if (bm.z === 0) {
        sfx('slam'); G.shake = Math.max(G.shake, 8); rumble(0.6, 0.6, 200);
        for (let i = 0; i < 6; i++) G.fx.push({ k: 'debris', x: bm.x + rand(-26, 26), y: bm.y, z: 6, vx: rand(-2, 2), vz: rand(1, 3), t: 30, col: '#a86a3a' });
        for (const e of G.ents) {
          if (!canBeHit(e) || e.z > 20 || (e.kind === 'boss' && e.boss.type === 'mech')) continue;
          if (Math.abs(e.x - bm.x) < 30 && Math.abs(e.y - bm.y) < 9) {
            applyHazardHit(e, 16, sign(e.x - bm.x) * 2 || 2, 3.6);
            if (e.team === 'foe' && G.player) addScore(400);
          }
        }
      }
    }
  }
  G.beams = G.beams.filter(b => b.t < 70 + 150);
  // traffic
  const c = G.car;
  if (c) {
    c.t++;
    if (c.t === 1) sfx('horn');
    if (c.t === 50) sfx('horn');
    if (c.t > 80) {
      if (c.t === 81) sfx('engine');
      c.x -= 9;
      for (const e of G.ents) {
        if (!canBeHit(e) || e.kind === 'boss' || e.z > 30) continue;
        if (Math.abs(e.y - c.y) < 13 && Math.abs(e.x - c.x) < 34 && !(e.carHit === c)) {
          e.carHit = c;
          applyHazardHit(e, 18, -5, 4.5);
          if (e.team === 'foe' && G.player) addScore(300);
        }
      }
      if (c.x < G.camX - 140) G.car = null;
    }
  }
}
function applyHazardHit(e, dmg, vx, vz) {
  if (e.kind === 'boss') {
    e.hp -= dmg; e.flash = 4; e.lastHurtF = G.frames;
    if (e.boss.type === 'mech') return;
    if (e.hp <= 0 || e.boss.type === 'twin') knock(e, vx, vz);
    return;
  }
  if (e.team === 'hero') {
    dmg = Math.round(dmg * diffOf().dmg * (e.defMul || 1));
    if ((e.kind === 'player' && CHEAT.invincible) || G.mode === 'training') dmg = 0;
    if (e.kind === 'player') { G.dmgTaken += dmg; resetCombo(true); }
    if (e.pw.iron > 0) { e.hp -= dmg; e.flash = 4; return; }
  }
  e.hp -= dmg; e.flash = 4; e.hitstop = 4;
  sfx('hitH'); G.shake = Math.max(G.shake, 4);
  if (e.kind === 'player') rumble(0.8, 0.6, 180);
  knock(e, vx, vz);
}

// ------------------------------------------------------------ grabs
function startGrab(e, t, back) {
  e.grab = t; e.grabT = 0; e.grabCount = 0; e.grabBack = back;
  e.state = 'grab'; e.st = 0; e.mv = null;
  t.heldBy = e; t.state = 'grabbed'; t.st = 0; t.mv = null; t.vx = t.vz = 0; t.z = 0;
  if (t.weapon && t.team === 'foe') { /* keep */ }
  t.face = back ? e.face : -e.face;
  sfx('grab');
  if (e.kind === 'player') rumble(0.2, 0.2, 60);
}
// Tank's running clutch: a striking move that turns into a grab on contact
function canClutch(e, t) {
  if (t.team === e.team || t.remove || t.heldBy || t.z > 6) return false;
  if (t.robot || (t.boss && t.boss.type === 'mech')) return false;
  if (t.kind === 'boss' && !['dazed', 'ttaunt', 'hurt'].includes(t.state)) return false;
  return ['stand', 'hurt', 'ai', 'dazed', 'ttaunt', 'move', 'run', 'jump'].includes(t.state);
}
function clutchGrab(e, t) {
  t.z = 0; t.vz = 0; t.vx = 0;
  t.x = e.x + e.face * (e.w + t.w + 2);
  t.y = e.y;
  startGrab(e, t, t.face === e.face);
  e.mv = null; e.mvName = '';
  G.fx.push({ k: 'ring', x: t.x, y: t.y, z: 40, t: 12, col: '#f2c94c' });
  sfx('hitH');
}
function releaseGrab(e) {
  const t = e.grab;
  e.grab = null;
  if (t && t.heldBy === e) {
    t.heldBy = null;
    if (t.state === 'grabbed') {
      t.state = t.kind === 'boss' ? 'dazed' : t.kind === 'enemy' ? 'ai' : 'stand';
      t.st = 0; t.pose = 'idle'; t.inv = 6;
    }
  }
  if (e.state === 'grab' || e.state === 'gmove') { e.state = 'stand'; e.mv = null; }
}
function grabPos(e) {
  const t = e.grab; if (!t) return;
  const gd = (e.w + t.w) * 0.85 + 2;
  t.x = e.x + e.face * gd; t.y = e.y + 0.5; t.z = 0;
}
function tryGrabContact(e, mx) {
  if (!mx || sign(mx) !== e.face) { e.contactT = 0; return false; }
  const reach = TUNING.grabReach + (e.kind === 'player' && hasPerk('reach') ? 10 : 0);
  let tgt = null;
  for (const t of G.ents) {
    if (t.team === e.team || t.remove) continue;
    if (!['stand', 'hurt', 'ai', 'dazed', 'ttaunt'].includes(t.state)) continue;
    if (t.kind === 'boss' && !['dazed', 'ttaunt'].includes(t.state)) continue;
    if (t.robot || (t.boss && t.boss.type === 'mech')) continue;
    if (t.z > 2 || t.heldBy) continue;
    const dx = (t.x - e.x) * e.face;
    if (dx > 0 && dx < e.w + t.w + reach - 10 && Math.abs(t.y - e.y) < 7) { tgt = t; break; }
  }
  if (!tgt) { e.contactT = 0; return false; }
  e.contactT++;
  if (e.contactT >= TUNING.grabContact) {
    e.contactT = 0;
    const back = tgt.face === e.face;
    startGrab(e, tgt, back);
    return true;
  }
  return false;
}

// ------------------------------------------------------------ hero control
function playerIntent() {
  const I = Input;
  return {
    mx: (I.held.right ? 1 : 0) - (I.held.left ? 1 : 0),
    my: (I.held.down ? 1 : 0) - (I.held.up ? 1 : 0),
    atk: I.pressed.attack, atkHeld: I.held.attack, atkRel: I.released.attack,
    jump: I.pressed.jump, sp: I.pressed.special, back: I.pressed.back, pick: I.pressed.pick,
    dblX: I.dbl.left ? -1 : I.dbl.right ? 1 : 0, dblY: I.dbl.up ? -1 : I.dbl.down ? 1 : 0,
    mash: I.anyEdge,
  };
}
function commonTimers(e) {
  if (e.inv > 0) e.inv--;
  if (e.flash > 0) e.flash--;
  if (e.wakeArmor > 0) e.wakeArmor--;
  if (e.wakeGuard > 0) e.wakeGuard--;
  for (const k in e.pw) if (e.pw[k] > 0) e.pw[k]--;
  e.st++;
}
function heroStars(e) { return e.kind === 'player' ? G.stars : 1; }
function heroMastery(e) {
  if (e.kind !== 'player' || !upgradesOn()) return 1;
  return masteryLevel(charSave(e.kit).xp);
}
function heroUpdate(e, I) {
  if (!e.buf) e.buf = { atk: 0, jump: 0, sp: 0 };
  if (I.atk) e.buf.atk = TUNING.bufferFrames;
  if (I.jump) e.buf.jump = TUNING.bufferFrames;
  if (I.sp) e.buf.sp = TUNING.bufferFrames;
  if (I.atk) e.holdChain = true;
  if (!I.atkHeld) e.holdChain = false;
  if (e.hitstop > 0) { e.hitstop--; return; }
  commonTimers(e);
  const mr = TUNING.meterRefill * (e.meterMul || 1);
  if (e.meter < 1) e.meter = Math.min(1, e.meter + mr);
  if (e.kind === 'player' && CHEAT.infspecial) e.meter = 1;
  const b = e.buf;
  const K = kitOf(e);
  const spd = (e.pw.overdrive > 0 ? 1.35 : 1) * (e.kind === 'player' && CHEAT.turbo ? 1.4 : 1) * (K.speed || 1);
  if (e.flipT > 0) e.flipT--;
  if (e.state !== 'jump' && e.state !== 'roll' && e.state !== 'held') e.rotOver = null;
  switch (e.state) {
    case 'stand': heroStand(e, I, b, spd); break;
    case 'run': {
      e.x += TUNING.runX * e.face * spd; e.y += I.my * TUNING.runY;
      e.pose = e.look.fem ? (Math.floor(e.st / 6) % 2 ? 'aRun1' : 'aRun2') : 'run' + (1 + (Math.floor(e.st / 5) % 4));
      if (e.st % 10 === 0) G.fx.push({ k: 'dust', x: e.x - e.face * 6, y: e.y, t: 14 });
      if (b.atk) { b.atk = 0; startMove(e, K.blitzAlt && hasMove(e, K.blitzAltId || 'spindash') ? K.blitzAlt : K.blitz); break; }
      if (I.back && K.grabMove) { startMove(e, K.grabMoveAlt && hasMove(e, K.grabMoveAltId) ? K.grabMoveAlt : K.grabMove); break; }
      if (b.jump) { b.jump = 0; heroJump(e, TUNING.runJumpX * e.face); break; }
      if (I.sp) { doSpecial(e, e.face); break; }
      if (I.mx !== e.face) { e.state = 'stand'; e.st = 0; }
      break;
    }
    case 'jump': heroAir(e, I, b); break;
    case 'athrow': heroAirThrow(e); break;
    case 'land':
      e.pose = 'land';
      if (e.st >= 5) { e.state = 'stand'; e.st = 0; }
      break;
    case 'move': heroMove(e, I, b); break;
    case 'roll':
      e.y += e.rollDir * 2.5;
      e.x += e.face * 0.4;
      e.pose = 'roll';
      e.rotOver = e.st * 17;
      if (e.st >= 2 && e.st <= 17) e.inv = Math.max(e.inv, 1);
      if (e.st >= 22) { e.state = 'stand'; e.st = 0; e.rotOver = null; }
      break;
    case 'grab': heroGrab(e, I, b); break;
    case 'gmove': heroGrapple(e, I); break;
    case 'vault': {
      const t = e.grab;
      if (!t || t.heldBy !== e) { e.state = 'stand'; e.z = 0; break; }
      const k = e.st / 16;
      e.x = lerp(e.vault0, e.vault1, k);
      e.z = Math.sin(k * Math.PI) * 34;
      e.pose = k < 0.5 ? 'jumpUp' : 'jumpFall';
      t.st = 0;
      if (e.st >= 16) {
        e.z = 0; e.face = -e.face; e.grabBack = true; e.state = 'grab'; e.grabT = Math.max(0, e.grabT - 30);
        sfx('land');
      }
      break;
    }
    case 'held': heroHeld(e, I); break;
    default: commonState(e);
  }
  if (b.atk > 0) b.atk--;
  if (b.jump > 0) b.jump--;
  if (b.sp > 0) b.sp--;
}
function heroStand(e, I, b, spd) {
  const K = kitOf(e);
  const canHold2 = K.hold2 && heroMastery(e) >= 3;
  if (e.charging && !I.atkHeld) {
    const ct = e.chargeT; e.charging = false; e.chargeT = 0;
    if (canHold2 && ct >= K.hold2T) { startMove(e, K.hold2); sfx('special'); return; }
    if (K.hold1 && ct >= 40) { startMove(e, K.hold1); return; }
  }
  if (I.sp || b.sp) { b.sp = 0; doSpecial(e, I.mx); return; }
  if (I.back) {
    if (e.weapon) { startGrappleToss(e); return; }
    startMove(e, K.back); return;
  }
  if (b.jump) { b.jump = 0; heroJump(e, I.mx * TUNING.jumpX * spd); return; }
  if (b.atk) {
    b.atk = 0;
    const it = itemNear(e);
    if (it && !foeClose(e, 34)) { startMove(e, 'pickup'); e.pickTarget = it; return; }
    if (e.weapon) { startMove(e, e.weapon.kind === 'pipe' ? 'wpn1' : 'kn1'); return; }
    startMove(e, K.combo); e.fromStand = true; return;
  }
  if (I.pick) {
    const it = itemNear(e);
    if (it) { startMove(e, 'pickup'); e.pickTarget = it; return; }
    if (e.weapon) { dropWeapon(e); sfx('clank'); return; }
  }
  if (I.dblX && I.dblX === I.mx) { e.face = I.dblX; e.state = 'run'; e.st = 0; return; }
  if (I.dblY && I.dblY === I.my) { e.state = 'roll'; e.st = 0; e.rollDir = I.dblY; sfx('whiff'); return; }
  // charging
  if (I.atkHeld && e.holdChain && !e.weapon && (K.hold1 || canHold2)) {
    e.chargeT++;
    if (e.chargeT > 12) {
      e.charging = true;
      e.pose = K.hold1 ? (e.st % 6 < 3 ? 'charge1' : 'charge2') : (e.st % 6 < 3 ? 'aChamber' : 'aIdle');
      if (K.hold1 && e.chargeT === 40) { sfx('charge'); G.fx.push({ k: 'ring', x: e.x, y: e.y, z: 44, t: 14, col: '#f2c94c' }); }
      if (canHold2 && e.chargeT === K.hold2T) { sfx('charge'); G.fx.push({ k: 'ring', x: e.x, y: e.y, z: 44, t: 18, col: '#ff5a2a' }); }
      return;
    }
  } else if (!I.atkHeld) { e.chargeT = 0; e.charging = false; }
  // walk
  const vx = I.mx * TUNING.walkX * spd, vy = I.my * TUNING.walkY * spd;
  e.x += vx; e.y += vy;
  if (I.mx) e.face = I.mx;
  if (I.mx || I.my) {
    e.walkT++;
    e.pose = 'walk' + (1 + (Math.floor(e.walkT / 7) % 4));
    if (tryGrabContact(e, I.mx)) return;
  } else {
    e.walkT = 0; e.contactT = 0;
    e.pose = Math.floor(e.st / 32) % 2 ? 'idle2' : 'idle';
  }
}
function foeClose(e, d) {
  return G.ents.some(t => t.team !== e.team && !t.remove && !isDownish(t) && Math.abs(t.x - e.x) < d && Math.abs(t.y - e.y) < 12);
}
function heroJump(e, vx) {
  const K = kitOf(e);
  e.state = 'jump'; e.st = 0; e.vz = TUNING.jumpV * (K.jump || 1); e.vx = vx; e.z = 0.1; e.airAtk = null; e.hitIds = {};
  e.jumpsLeft = (K.jumps || 1) - 1 + (hasMove(e, 'triple') ? 1 : 0);
  e.air2Used = false; e.airHit = false; e.stilettoUsed = false; e.rotOver = null;
  e.dashLeft = K.airDash ? (K.airDashes || 1) + (hasMove(e, 'airdash2') ? 1 : 0) : 0;
  e.dashT = 0; e.dashHit = new Set();
  sfx('jump');
}
function heroAir(e, I, b) {
  const K = kitOf(e);
  e.z += e.vz; e.vz -= TUNING.gravity; e.x += e.vx;
  // extra jumps
  if (b.jump && e.jumpsLeft > 0 && !e.airAtk && e.st > 4) {
    b.jump = 0; e.jumpsLeft--;
    e.vz = TUNING.jumpV * 0.92; e.flipT = 18;
    if (I.mx) { e.vx = I.mx * TUNING.jumpX * (K.speed || 1); e.face = I.mx; }
    sfx('jump'); G.fx.push({ k: 'ring', x: e.x, y: e.y, z: e.z, t: 10, col: '#e8e8f0' });
  }
  // air dash
  if (I.back && K.airDash && e.dashLeft > 0 && e.dashT <= 0) {
    e.dashLeft--; e.dashT = 13; e.airAtk = null; e.airAtkF = 0;
    e.vz = 0; e.vx = e.face * 7.4; e.hitIds = {}; e.dashHit = new Set();
    sfx('whiff');
    G.fx.push({ k: 'ring', x: e.x, y: e.y, z: e.z + 30, t: 10, col: '#2ad0f0' });
  }
  if (e.dashT > 0) {
    e.dashT--;
    e.inv = Math.max(e.inv, 1);
    e.vz = 0; e.z = Math.max(e.z, 8);
    e.pose = K.airDash ? MOVES[K.airDash].pose : 'jumpFall';
    if (e.dashT % 2 === 0) G.fx.push({ k: 'ring', x: e.x - e.face * 8, y: e.y, z: e.z + 26, t: 7, col: 'rgba(60,200,255,0.8)' });
    if (hasMove(e, 'afterburn')) {
      for (const t of G.ents) {
        if (t.team === e.team || !canBeHit(t) || e.dashHit.has(t.id)) continue;
        if (Math.abs(t.x - e.x) < 22 && Math.abs(t.y - e.y) < 13 && t.z < e.z + 40 && t.z + t.h > e.z) {
          e.dashHit.add(t.id);
          applyHit(e, t, { dmg: 8, type: 'H', fire: true });
        }
      }
    }
    if (e.dashT === 0) e.vx *= 0.3;
  }
  // stiletto
  if (I.sp && hasMove(e, 'stiletto') && !e.stilettoUsed && !e.airAtk) {
    e.stilettoUsed = true;
    payForSpecial(e);
    e.airAtk = 'athrow'; e.airAtkF = 0;
    G.projs.push({ x: e.x + e.face * 12, y: e.y, z: e.z + 44, vx: e.face * 5.5, vz: -2.4, kind: 'knife', team: e.team, owner: e,
      dmg: 12, type: 'K', life: 90, dur: 0, hit: new Set(), vanish: true });
    sfx('knife');
  }
  if (b.atk && !e.airAtk) {
    b.atk = 0;
    // MASTERY 4: catch anyone else who is off the ground and spike them
    const at = K.airThrow && heroMastery(e) >= 4 ? airThrowTarget(e) : null;
    if (at) { startAirThrow(e, at); return; }
    // MASTERY 5: the air-down drop
    if (K.airDown && heroMastery(e) >= 5 && I.my > 0) {
      e.airAtk = K.airDown; e.airAtkF = 0; e.hitIds = {}; e.airHit = false;
      e.vx *= 0.3; e.vz = -MOVES[K.airDown].drop;
      sfx('whiff');
    } else {
      const moving = Math.abs(e.vx) > 0.5;
      e.airAtk = moving ? (K.jFUp && hasMove(e, 'dkick') ? K.jFUp : K.jF) : K.jN;
      e.airAtkF = 0; e.hitIds = {}; e.airHit = false;
      sfx('whiff');
    }
  } else if (b.atk && e.airAtk && K.air2 && hasMove(e, 'aircombo') && e.airHit && !e.air2Used && e.airAtkF >= 6) {
    b.atk = 0;
    e.air2Used = true; e.airAtk = K.air2; e.airAtkF = 0; e.hitIds = {}; e.airHit = false;
    e.vz = Math.max(e.vz, 1.6);
    sfx('whiff');
  }
  if (e.airAtk) {
    const m = MOVES[e.airAtk];
    e.airAtkF++;
    e.pose = m.seq ? airSeqPose(m, e.airAtkF) : m.pose;
    e.hitMask = 0;
    checkMoveHits(e, m.hits, e.airAtkF);
    if (e.hitMask) e.airHit = true;
    e.rotOver = null;
  } else if (e.flipT > 0) {
    e.pose = 'aTuck'; e.rotOver = (18 - e.flipT) * 40;
  } else { e.pose = e.vz > 0 ? 'jumpUp' : 'jumpFall'; e.rotOver = null; }
  if (e.z <= 0 && e.vz < 0) {
    const drop = e.airAtk && MOVES[e.airAtk] && MOVES[e.airAtk].shock;
    e.z = 0; e.vz = 0; e.vx = 0; e.airAtk = null; e.rotOver = null; e.flipT = 0; e.dashT = 0;
    e.state = 'land'; e.st = 0; sfx('land');
    G.fx.push({ k: 'dust', x: e.x, y: e.y, t: 12 });
    if (drop) {
      sfx('slam'); G.shake = Math.max(G.shake, 8);
      if (e.kind === 'player') rumble(0.8, 0.6, 220);
      G.fx.push({ k: 'shock', x: e.x, y: e.y, t: 20, r: drop });
      for (const t of G.ents) {
        if (t.team === e.team || !canBeHit(t) || t.z > 8) continue;
        const dx = t.x - e.x, dy = (t.y - e.y) * 2.2;
        if (dx * dx + dy * dy < drop * drop) applyHit(e, t, { dmg: Math.round(drop / 6), type: 'K', kx: 2.6 * (sign(dx) || 1), kz: 3.2 });
      }
    }
  }
}
// MASTERY 4: air throw
function airThrowTarget(e) {
  for (const t of G.ents) {
    if (t.team === e.team || t.remove || t.heldBy || !canBeHit(t)) continue;
    if (t.kind === 'boss' || t.robot || t.heavy) continue;
    if (t.z < 10) continue;
    if (Math.abs(t.y - e.y) > 15) continue;
    if ((t.x - e.x) * e.face < -8 || Math.abs(t.x - e.x) > 36) continue;
    if (Math.abs(t.z - e.z) > 44) continue;
    return t;
  }
  return null;
}
function startAirThrow(e, t) {
  e.grab = t; e.grabT = 0; e.state = 'athrow'; e.st = 0; e.airAtk = null; e.mv = null;
  t.heldBy = e; t.state = 'grabbed'; t.st = 0; t.mv = null; t.vx = t.vz = 0;
  t.face = -e.face;
  e.vz = Math.min(e.vz, 0.4); e.vx = 0;
  sfx('grab');
  if (e.kind === 'player') rumble(0.3, 0.3, 80);
}
function heroAirThrow(e) {
  const K = kitOf(e), t = e.grab;
  if (!t || t.heldBy !== e) { e.grab = null; e.state = e.z > 1 ? 'jump' : 'land'; e.st = 0; return; }
  e.pose = K.airThrow || 'aAirThrow';
  t.pose = 'held'; t.st = 0;
  e.vz -= 0.62;
  e.z = Math.max(0, e.z + e.vz);
  e.x += e.face * 1.2;
  t.x = e.x + e.face * 13 * GS; t.y = e.y; t.z = Math.max(0, e.z - 8);
  if (e.st % 3 === 0) G.fx.push({ k: 'dust', x: t.x, y: t.y, t: 8 });
  if (e.z <= 0) {
    e.z = 0; e.vz = 0;
    t.heldBy = null; e.grab = null;
    t.z = 5;
    applyHit(e, t, { dmg: 20, type: 'K', kx: 2.4 * e.face, kz: 3.6, proj: true });
    sfx('slam'); G.shake = Math.max(G.shake, 9);
    if (e.kind === 'player') rumble(0.9, 0.7, 240);
    G.fx.push({ k: 'shock', x: t.x, y: t.y, t: 18, r: 46 });
    e.state = 'land'; e.st = 0;
  }
}
function airSeqPose(m, f) {
  let t = 0;
  for (const [p, n] of m.seq) { t += n; if (f < t) return p; }
  return m.seq[m.seq.length - 1][0];
}
function heroMove(e, I, b) {
  const mv = e.mv;
  const K = kitOf(e);
  if (e.mvName === 'pickup' && e.mf === 6 && e.pickTarget && !e.pickTarget.gone) { takeItem(e, e.pickTarget); e.pickTarget = null; }
  if (e.mvName === 'toss' && e.mf === 6) releaseToss(e);
  moveStep(e);
  if (e.mvName === 'wpnSpecial' || e.mvName === 'wpn1' || e.mvName === 'wpn2' || e.mvName === 'wpn3' || e.mvName.startsWith('kn')) {
    if (e.hitMask && !e.wpnWorn) { e.wpnWorn = true; wearWeapon(e, e.mvName === 'wpnSpecial' ? 2 : 1); }
  }
  if (mv.special && G.stars >= 3 && e.kind === 'player' && (e.mvName === 'specialF' || e.mvName === 'aspF') && e.mf > 6 && e.mf < 24) e.x += e.face * 1.2;
  if (mv.special && e.mf % 3 === 0 && heroStars(e) >= 2) G.fx.push({ k: 'flame', x: e.x + rand(-10, 10), y: e.y, z: rand(10, 50), t: 16 });
  // chain
  if (b.atk && K.blitzFollow && e.mvName === K.blitz && e.chainHit && e.mf >= 10 && hasMove(e, 'blitz2')) {
    b.atk = 0; startMove(e, K.blitzFollow); return;
  }
  if (b.atk && e.mf >= mv.cancel && mv.next && e.chainHit) {
    b.atk = 0;
    let nx = mv.next;
    if (mv.alt && heroMastery(e) >= 2 && I.mx === e.face) nx = mv.alt;
    if (e.weapon === null && (nx.startsWith('wpn') || nx.startsWith('kn'))) nx = K.combo;
    startMove(e, nx); e.wpnWorn = false;
    return;
  }
  if ((I.sp || b.sp) && e.chainHit && !mv.special && e.mf >= 2 && !e.mvName.startsWith('eX')) { b.sp = 0; doSpecial(e, I.mx); return; }
  if (e.mf >= mv.total) {
    e.state = 'stand'; e.st = 0; e.mv = null; e.wpnWorn = false; e.chargeT = 0;
  }
}
function wearWeapon(e, n) {
  if (!e.weapon) return;
  e.weapon.dur -= n;
  if (e.weapon.dur <= 0) {
    const k = e.weapon.kind;
    e.weapon = null; sfx('brk');
    for (let i = 0; i < 4; i++) G.fx.push({ k: 'debris', x: e.x + e.face * 20, y: e.y, z: 40, vx: rand(-2, 2), vz: rand(1, 3), t: 30, col: k === 'pipe' ? '#9aa3ad' : '#e6eef5' });
  }
}
function payForSpecial(e) {
  const free = e.kind === 'player' && ((upgradesOn() && charSave(e.kit).freesp) || CHEAT.infspecial);
  if (e.meter >= 1) e.meter = 0;
  else if (!free) {
    const cost = Math.round(e.maxHp * TUNING.specialHpCost / 100);
    if (G.mode === 'story') e.hp = Math.max(1, e.hp - cost);
  }
}
function doSpecial(e, mx) {
  const K = kitOf(e);
  payForSpecial(e);
  const spN = K.spNAlt && hasMove(e, K.spNAltId) ? K.spNAlt : K.spN;
  const spF = K.spFPlus && heroMastery(e) >= 6 ? K.spFPlus : K.spF;
  let name = mx && mx === e.face ? spF : mx && mx === -e.face ? spF : spN;
  if (e.weapon && e.weapon.kind === 'pipe') name = 'wpnSpecial';
  e.face = mx || e.face;
  startMove(e, name);
  e.wpnWorn = false; e.hitIds = {};
  sfx('special');
  G.flashT = 4;
  if (e.kind === 'player') rumble(0.5, 0.8, 200);
}
function startGrappleToss(e) { startMove(e, 'toss'); }
function releaseToss(e) {
  const w = e.weapon; if (!w) return;
  e.weapon = null;
  G.projs.push({ x: e.x + e.face * 14, y: e.y, z: 40, vx: e.face * 6.5, vz: 0, kind: w.kind, team: e.team, owner: e,
    dmg: w.kind === 'pipe' ? 14 : 12, type: w.kind === 'pipe' ? 'K' : 'H', life: 70, dur: w.dur, hit: new Set() });
  sfx('whiff');
}
function heroGrab(e, I, b) {
  const t = e.grab;
  if (!t || t.heldBy !== e || t.state !== 'grabbed') { e.grab = null; e.state = 'stand'; return; }
  e.grabT++;
  grabPos(e);
  e.pose = 'grab';
  t.pose = t.kind === 'boss' ? 'dizzy' : 'held';
  if (e.grabT > TUNING.grabHold) {
    releaseGrab(e);
    t.x += t.face * -4; e.x -= e.face * 6;
    return;
  }
  if (b.atk) {
    b.atk = 0;
    if (e.grabBack) { startMove(e, 'suplex', 'gmove'); return; }
    if (I.mx && I.mx === -e.face) { startMove(e, 'throwMv', 'gmove'); return; }
    e.grabCount++;
    startMove(e, 'knee', 'gmove'); return;
  }
  if (I.back && !e.grabBack) { startMove(e, 'screenThrow', 'gmove'); return; }
  if (b.jump && !e.grabBack) {
    b.jump = 0;
    e.state = 'vault'; e.st = 0; e.vault0 = e.x;
    const gd = (e.w + t.w) * 0.85 + 2;
    e.vault1 = t.x + e.face * gd;
    sfx('jump');
    return;
  }
  if (I.sp) { releaseGrab(e); doSpecial(e, 0); }
}
function grappleDmg(e, t, dmg, type, kx, kz) {
  applyHit(e, t, { dmg, type, kx, kz });
}
function heroGrapple(e, I) {
  const t = e.grab, n = e.mvName, f = e.mf;
  if (!t || t.heldBy !== e) { e.grab = null; if (n !== 'suplex' && n !== 'throwMv' && n !== 'screenThrow') { e.state = 'stand'; return; } }
  e.pose = poseAt(e.mv, f);
  if (n === 'knee') {
    if (t) grabPos(e);
    if (f === 5 && t) {
      if (e.grabCount >= 3) {
        const g = e.grab; e.grab = null; g.heldBy = null;
        if (g.kind === 'boss') { g.state = 'dazed'; g.dazeLeft = 0; } else g.state = 'stand';
        grappleDmg(e, g, 9, 'K', 3, 3.2);
      } else {
        grappleDmg(e, t, 6, 'L');
        if (t.state !== 'fall') { t.state = 'grabbed'; t.heldBy = e; e.grab = t; t.pose = 'hurt2'; }
        else { e.grab = null; }
      }
    }
  } else if (n === 'throwMv' && t) {
    const k = Math.min(1, f / 12);
    t.x = e.x + e.face * lerp(16, -4, k); t.z = lerp(0, 34, k); t.pose = 'fall'; t.y = e.y + 0.5;
    if (f === 12) { e.face = -e.face; }
    if (f === 14) {
      e.grab = null; t.heldBy = null;
      t.x = e.x + e.face * 12;
      knock(t, e.face * 4.8, 2.6);
      t.z = 34; t.projBody = 50; t.pendingDmg = 12; t.thrower = e;
      t.juggle = 2;
      sfx('whiff'); if (e.kind === 'player') addScore(300);
    }
  } else if (n === 'suplex' && t) {
    if (f < 8) { grabPos(e); t.pose = 'held'; }
    else if (f < 18) { const k = (f - 8) / 10; t.x = e.x + e.face * lerp(18, 0, k); t.z = lerp(0, 40, k); t.pose = 'fall'; }
    else if (f < 26) { const k = (f - 18) / 8; t.x = e.x - e.face * lerp(0, 22, k); t.z = lerp(40, 0, k); t.pose = 'down'; }
    if (f === 26) {
      e.grab = null; t.heldBy = null; t.z = 0;
      if (t.kind === 'boss') { t.state = 'dazed'; t.dazeLeft = 0; } else t.state = 'stand';
      grappleDmg(e, t, 18, 'K', 1, 1.4);
      t.juggle = 2;
      G.shake = 8; sfx('slam');
      G.fx.push({ k: 'dust', x: t.x, y: t.y, t: 18 }); G.fx.push({ k: 'dust', x: t.x - 8, y: t.y, t: 18 });
      if (e.kind === 'player') addScore(500);
    }
  } else if (n === 'screenThrow' && t) {
    const k = Math.min(1, f / 16);
    t.x = e.x + e.face * lerp(16, 0, k); t.z = lerp(0, 44, k); t.pose = 'fall';
    if (f === 16) {
      e.grab = null; t.heldBy = null;
      startScreenThrow(t, e);
    }
  }
  moveStepNoHit(e);
  if (e.mf >= e.mv.total) {
    if (e.grab && e.grab.heldBy === e && e.grab.state === 'grabbed') { e.state = 'grab'; e.mv = null; }
    else { e.state = 'stand'; e.mv = null; e.grab = null; }
    e.st = 0;
  }
}
function moveStepNoHit(e) { e.mf++; }
function heroHeld(e, I) {
  e.pose = 'held';
  if (I.mash) e.mash++;
  const holder = e.heldBy;
  if (!holder || holder.remove || holder.grab !== e || isDownish(holder) || holder.state === 'hurt') {
    e.heldBy = null; e.state = 'stand'; e.z = 0; e.st = 0; return;
  }
  if (e.mash >= 12 + G.diff * 3 && !holder.dropping) {
    holder.grab = null; e.heldBy = null; e.state = 'stand'; e.z = 0; e.inv = 30; e.mash = 0;
    e.x -= holder.face * -8;
    if (holder.kind === 'boss') { holder.state = 'bidle'; holder.st = 0; holder.boss.cool = 40; }
    else { holder.state = 'hurt'; holder.hurtT = 16; holder.st = 0; holder.pose = 'hurt1'; }
    sfx('whiff'); popText('ESCAPED!', e.x, e.y - 70, '#fff');
  }
}

// ------------------------------------------------------------ shared reaction states
function commonState(e) {
  switch (e.state) {
    case 'hurt':
      if (e.st >= (e.hurtT || 14)) { e.state = e.team === 'foe' && e.kind === 'enemy' ? 'ai' : e.kind === 'boss' ? (e.dazeLeft > 0 ? 'dazed' : e.idleState) : 'stand'; e.st = 0; }
      break;
    case 'fall':
      e.z += e.vz; e.vz -= TUNING.gravity * 0.95; e.x += e.vx;
      e.pose = 'fall';
      if (e.projBody > 0) { e.projBody--; bodyHits(e); }
      if (e.z <= 0 && e.vz < 0) {
        e.z = 0;
        if (e.pendingDmg) {
          e.hp -= e.pendingDmg; e.pendingDmg = 0; e.flash = 4; sfx('hitH');
          if (e.kind === 'player') G.dmgTaken += 0;
        }
        if (e.bounce === 0) {
          e.bounce = 1; e.vz = 1.9; e.vx *= 0.45; sfx('fall');
          G.fx.push({ k: 'dust', x: e.x, y: e.y, t: 16 });
          G.shake = Math.max(G.shake, e.kind === 'boss' ? 7 : 3);
          if (e.kind === 'player') rumble(0.5, 0.3, 120);
        } else {
          e.state = 'down'; e.st = 0; e.vx = 0; e.vz = 0; e.projBody = 0; e.juggle = 0;
        }
      }
      break;
    case 'down':
      e.pose = 'down';
      if (e.st >= (e.kind === 'boss' ? 50 : TUNING.downTime)) {
        if (e.hp <= 0) { e.state = 'dead'; e.st = 0; e.dead = true; }
        else { e.state = 'getup'; e.st = 0; }
      }
      break;
    case 'getup':
      e.pose = e.st < 12 ? 'getup' : 'land';
      if (e.st >= TUNING.getupTime) {
        e.inv = Math.max(e.inv, e.team === 'hero' ? TUNING.getupInv : 8);
        e.state = e.kind === 'enemy' ? 'ai' : e.kind === 'boss' ? e.idleState : 'stand';
        if (e.kind === 'boss') { e.wakeArmor = 50; e.boss.cool = 10; if (e.boss.type === 'brick' && G.diff >= 2 && chance(0.5)) { e.state = 'bslamTell'; } }
        if (e.kind === 'enemy') { e.ai.cool = 20; e.ai.t = 20; }
        // Standing up arms the wake guard. For the short window after the
        // getup invincibility runs out, a knockdown hit lands as damage and a
        // stun instead of putting you straight back on the floor, so nothing
        // can hold you in a knockdown loop. It burns the moment it is used.
        if (e.team === 'hero') e.wakeGuard = TUNING.wakeGuard;
        e.st = 0;
      }
      break;
    case 'grabbed':
      if (!e.heldBy || e.heldBy.grab !== e) { e.heldBy = null; e.state = e.kind === 'enemy' ? 'ai' : e.kind === 'boss' ? 'dazed' : 'stand'; e.st = 0; e.z = 0; if (e.kind === 'boss') e.dazeLeft = Math.max(e.dazeLeft || 0, 20); }
      break;
    case 'manhole':
      e.sink = Math.min(1, e.st / 18);
      e.pose = 'jumpUp';
      if (e.st >= 20 && e.team === 'foe') { e.state = 'gone'; e.remove = true; e.dead = true; }
      if (e.st >= 70 && e.team === 'hero') {
        let d = Math.round(e.maxHp * 0.2 * diffOf().dmg);
        if ((e.kind === 'player' && CHEAT.invincible) || G.mode === 'training') d = 0;
        e.hp -= d; if (e.kind === 'player') G.dmgTaken += d;
        e.sink = 0; e.state = 'fall'; e.z = 1; e.vz = 6; e.vx = 2.2; e.bounce = 0; e.inv = 40;
        e.y = Math.max(TUNING.bandTop, e.y - 12);
        sfx('jump');
      }
      break;
    case 'screen': updateScreenThrow(e); break;
    case 'dead':
      e.pose = 'down';
      if (e.robot) {
        if (e.st === 1) sfx('warn');
        if (e.st === 46) robotExplode(e);
        if (e.st >= 48) e.remove = true;
        break;
      }
      if (e.team === 'foe') { if (e.st >= 40) e.remove = true; }
      else heroDead(e);
      break;
    case 'respawn':
      e.z = Math.max(0, e.z - 5); e.pose = 'jumpFall';
      if (e.z <= 0) { e.state = 'land'; e.st = 0; sfx('land'); }
      break;
    case 'gone': break;
  }
}
function robotExplode(e) {
  sfx('slam'); sfx('brk'); G.shake = Math.max(G.shake, 10); G.flashT = 3; rumble(0.8, 0.8, 300);
  G.fx.push({ k: 'boom', x: e.x, y: e.y, t: 26, r: 76 });
  for (let i = 0; i < 10; i++) G.fx.push({ k: 'debris', x: e.x, y: e.y, z: 30, vx: rand(-4, 4), vz: rand(2, 5), t: 40, col: pick(['#8a94a4', '#5a6474', '#e8a020']) });
  for (const t of G.ents) {
    if (t === e || !canBeHit(t) || t.z > 40) continue;
    const dx = (t.x - e.x) / 76, dy = (t.y - e.y) / 22;
    if (dx * dx + dy * dy < 1) applyHazardHit(t, 14, sign(t.x - e.x) * 3.5 || 3.5, 3.8);
  }
}
function bodyHits(body) {
  if (!body.bodyHit) body.bodyHit = new Set();
  const thrower = body.thrower || body.lastHitBy;
  if (!thrower) return;
  for (const o of G.ents) {
    if (o === body || o.team !== body.team || !canBeHit(o) || body.bodyHit.has(o.id)) continue;
    if (Math.abs(o.x - body.x) < o.w + 12 && Math.abs(o.y - body.y) < 13 && body.z < 44) {
      body.bodyHit.add(o.id);
      applyHit(thrower, o, { dmg: 9, type: 'K', kx: 2.6, kz: 3 });
    }
  }
}
function heroDead(e) {
  if (e.st === 1) sfx('ko');
  if (e.st < 70) return;
  if (e.kind === 'player') {
    G.livesLost++;
    if (!CHEAT.inflives && G.mode === 'story') G.lives--;
    if (!(upgradesOn() && charSave().starlock) && !CHEAT.maxstars) G.stars = Math.max(1, G.stars - 1);
    if (G.lives <= 0) { e.state = 'gone'; G.gameOver = true; return; }
  } else {
    G.allyLives--;
    if (G.allyLives <= 0) { e.state = 'gone'; e.remove = true; G.ally = null; popText('CPU PARTNER OUT', G.camX + W / 2, 120, '#e8283a'); return; }
  }
  respawnHero(e);
}
function respawnHero(e) {
  e.dead = false; e.killed = false; e.hp = e.maxHp; e.state = 'respawn'; e.st = 0;
  e.x = G.camX + (e.kind === 'player' ? 90 : 60); e.y = clamp(e.y, TUNING.bandTop + 10, TUNING.bandBot - 10); e.z = 170;
  e.inv = TUNING.respawnInv; e.meter = 1; e.weapon = null; e.face = 1; e.grab = null; e.heldBy = null;
  if (e.kind === 'player' && CHEAT.weapon) e.weapon = { kind: CHEAT.weapon === 1 ? 'pipe' : 'knife', dur: 99 };
}

// ------------------------------------------------------------ screen throw
function startScreenThrow(t, by) {
  t.state = 'screen'; t.st = 0; t.mv = null;
  t.screen = { x0: t.x - G.camX, y0: t.y - t.z - 30, by };
  sfx('whiff');
  if (t.weapon) dropWeapon(t);
}
function updateScreenThrow(t) {
  const s = t.screen, f = t.st;
  if (f === 22) {
    const dmg = Math.round(10 + t.maxHp * (t.kind === 'boss' ? 0.16 : 0.3));
    if (t.type !== 'dummy') t.hp -= dmg * ((s.by && s.by.pw && s.by.pw.rage > 0) ? 2 : 1);
    else G.fx.push({ k: 'num', x: t.x, y: 80, v: dmg, t: 50 });
    t.lastHitBy = s.by;
    G.cracks.push({ x: 213 + rand(-40, 40), y: 100 + rand(-15, 15), t: 110, seed: Math.random() });
    sfx('glass'); sfx('hitX');
    G.shake = 10; G.flashT = 3;
    rumble(1, 1, 300);
    if (s.by && s.by.kind === 'player') { addScore(1000); bumpCombo(); popText('SMASH!', s.by.x, s.by.y - 90, '#4ac0e8'); }
  }
  if (f >= 80) {
    t.screen = null;
    if (t.hp <= 0) { t.state = 'dead'; t.st = 20; t.dead = true; t.remove = true; }
    else {
      t.state = 'fall'; t.z = 150; t.vz = -1; t.vx = 0; t.bounce = 0;
      t.x = clamp(t.x, G.camX + 40, G.camX + W - 40);
    }
  }
}

// ------------------------------------------------------------ ally AI
const ALLY_CMDS = ['AGGRESSIVE', 'GUARD', 'FOLLOW'];
function allyIntent(e) {
  const I = { mx: 0, my: 0, atk: false, atkHeld: false, jump: false, sp: false, back: false, pick: false, dblX: 0, dblY: 0, mash: false };
  const p = G.player;
  if (!e.aiT) e.aiT = 0;
  e.aiT++;
  if (e.state === 'held') { I.mash = e.aiT % 4 === 0; return I; }
  const cmd = G.allyCmd;
  const anchor = p && !p.dead && p.state !== 'gone' ? p : e;
  let tgt = null, bd = 1e9;
  for (const f of G.ents) {
    if (f.team !== 'foe' || !canBeHit(f) || f.enter || f.state === 'grabbed') continue;
    if (f.x < G.camX + 4 || f.x > G.camX + W - 4) continue;
    const dA = Math.abs(f.x - e.x) + Math.abs(f.y - e.y) * 1.5;
    const dP = Math.abs(f.x - anchor.x) + Math.abs(f.y - anchor.y);
    if (cmd === 1 && dP > 100) continue;
    if (cmd === 2 && dA > 42) continue;
    if (dA < bd) { bd = dA; tgt = f; }
  }
  // dodge a boss charge lane
  for (const b of G.bosses) {
    if (['bchargeTell', 'bcharge', 'tcartTell', 'tcart', 'mflameTell', 'mflame'].includes(b.state) && Math.abs(b.y - e.y) < 22) {
      I.my = e.y > (TUNING.bandTop + TUNING.bandBot) / 2 ? -1 : 1;
      return I;
    }
  }
  if (e.state === 'grab') {
    if (e.aiT % 12 === 0) {
      I.atk = true;
      if (e.grabCount >= 2) I.mx = -e.face;
    }
    return I;
  }
  if (!tgt) {
    const gx = anchor.x - anchor.face * 34, gy = clamp(anchor.y + 14, TUNING.bandTop, TUNING.bandBot);
    if (anchor !== e) {
      if (Math.abs(gx - e.x) > 14) I.mx = sign(gx - e.x);
      if (Math.abs(gy - e.y) > 6) I.my = sign(gy - e.y);
      if (!I.mx && !I.my && e.state === 'stand') e.face = anchor.face;
    }
    return I;
  }
  const side = sign(e.x - tgt.x) || -1;
  const gx = tgt.x + side * (tgt.w + 16), gy = tgt.y;
  const dx = gx - e.x, dy = gy - e.y;
  if (Math.abs(dx) > 5) I.mx = sign(dx);
  if (Math.abs(dy) > 3) I.my = sign(dy);
  const inRange = Math.abs(tgt.x - e.x) < tgt.w + 26 && Math.abs(dy) < 7;
  if (inRange) {
    I.mx = 0;
    if (e.state === 'stand') e.face = sign(tgt.x - e.x) || e.face;
    if (e.aiT % 7 === 0) I.atk = true;
    const crowd = G.ents.filter(f => f.team === 'foe' && canBeHit(f) && Math.abs(f.x - e.x) < 44 && Math.abs(f.y - e.y) < 14).length;
    if (crowd >= 3 && e.meter >= 1 && e.state === 'stand') I.sp = true;
    // walk into them sometimes to grab
    if (e.aiT % 90 < 20 && tgt.kind === 'enemy' && tgt.state === 'ai') I.mx = sign(tgt.x - e.x);
  } else if (Math.abs(tgt.x - e.x) > 50 && Math.abs(tgt.x - e.x) < 80 && Math.abs(dy) < 5 && e.aiT % 60 === 0 && chance(0.4)) {
    I.jump = true; I.mx = sign(tgt.x - e.x);
    e.face = I.mx;
  } else if (e.state === 'jump' && Math.abs(tgt.x - e.x) < 44) {
    I.atk = true;
  }
  return I;
}

// ------------------------------------------------------------ enemy AI
function nearestHero(e) {
  let best = null, bd = 1e9;
  for (const h of G.ents) {
    if (h.team !== 'hero' || h.dead || ['gone', 'respawn', 'manhole'].includes(h.state)) continue;
    const d = Math.abs(h.x - e.x) + Math.abs(h.y - e.y) * 2;
    if (d < bd) { bd = d; best = h; }
  }
  return best;
}
function tokenCount() { return G.ents.filter(f => f.kind === 'enemy' && f.ai.tok && !isDownish(f)).length; }
function enemyRange(e) {
  if (e.weapon && e.weapon.kind === 'pipe') return 44 * GS;
  if (e.type === 'whip') return 64 * GS;
  return ({ punk: 27, blade: 31, bruiser: 36, kicker: 37, dummy: 26, robot: 34 }[e.type] || 28) * GS;
}
// States in which an enemy is genuinely meant to be off the ground and is
// running its own vertical motion. Anything else with height left over is a bug.
const GROUNDED_STATES = ['ai', 'move', 'hurt', 'land', 'pickup', 'stand'];
function enemyUpdate(e) {
  if (e.hitstop > 0) { e.hitstop--; return; }
  commonTimers(e);
  if (e.state === 'stand') e.state = 'ai';
  // Safety net for the float bug: whatever route left this enemy hanging in the
  // air in a walking state, gravity finishes the job rather than freezing it there.
  if (e.z > 0 && GROUNDED_STATES.includes(e.state)) {
    e.vz = (e.vz || 0) - TUNING.gravity;
    e.z += e.vz;
    if (e.z <= 0) { e.z = 0; e.vz = 0; }
  }
  switch (e.state) {
    case 'ai': enemyThink(e); break;
    case 'move': enemyMove(e); break;
    case 'gslam': enemySlam(e); break;
    case 'jkick': {
      e.z += e.vz; e.vz -= TUNING.gravity; e.x += e.vx;
      e.pose = e.st < 8 ? 'jumpUp' : 'jumpKick';
      if (e.st >= 8) checkMoveHits(e, [Object.assign({}, MOVES.jkick.hits[0], { dmg: 8 })], e.st);
      if (e.z <= 0 && e.vz < 0) { e.z = 0; e.state = 'land'; e.st = 0; e.vx = 0; sfx('land'); }
      break;
    }
    case 'land': e.pose = 'land'; if (e.st > 14) { e.state = 'ai'; e.st = 0; e.ai.cool = 40; } break;
    case 'pickup':
      e.pose = 'pickup';
      if (e.st === 8 && e.pickTarget && !e.pickTarget.gone && Math.abs(e.pickTarget.x - e.x) < 18) {
        const it = e.pickTarget; it.gone = true;
        if (it.kind === 'pipe' || it.kind === 'knife') { e.weapon = { kind: it.kind, dur: it.dur || 10 }; sfx('pickup'); }
      }
      if (e.st > 16) { e.state = 'ai'; e.st = 0; }
      break;
    default: commonState(e);
  }
}
function enemyThink(e) {
  const d = diffOf();
  const tgt = nearestHero(e);
  e.ai.t--; e.ai.cool--;
  if (e.ai.tok) { e.ai.tokT = (e.ai.tokT || 0) - 1; if (e.ai.tokT <= 0) e.ai.tok = false; }
  if (e.type === 'dummy') return dummyThink(e, tgt);
  if (e.enter) {
    const dir = e.x < G.camX + W / 2 ? 1 : -1;
    e.x += dir * e.speed * 1.2; e.face = dir;
    e.walkT++; e.pose = 'walk' + (1 + (Math.floor(e.walkT / 8) % 4));
    if (e.x > G.camX + 18 && e.x < G.camX + W - 18) e.enter = false;
    return;
  }
  if (!tgt) { e.pose = 'idle'; return; }
  const dx = tgt.x - e.x, dy = tgt.y - e.y, adx = Math.abs(dx);
  const range = enemyRange(e);
  // weapon pickup
  if (!e.ai.tok && !e.weapon && (e.type === 'punk' || e.type === 'blade') && e.ai.cool < 0) {
    for (const it of G.items) {
      const want = it.kind === 'pipe' || it.kind === 'knife';
      if (!want || it.z > 2) continue;
      if (Math.abs(it.x - e.x) < 90 && Math.abs(it.y - e.y) < 30 && it.x > G.camX + 10 && it.x < G.camX + W - 10) {
        if (Math.abs(it.x - e.x) < 8 && Math.abs(it.y - e.y) < 5) {
          e.state = 'pickup'; e.st = 0; e.pickTarget = it; return;
        }
        walkTo(e, it.x, it.y, e.speed);
        return;
      }
    }
  }
  if (!e.ai.tok && e.ai.cool <= 0 && tokenCount() < d.tokens && chance(0.05 + G.diff * 0.02)) { e.ai.tok = true; e.ai.tokT = 300; }
  const tok = e.ai.tok;
  // ranged options
  // A jump kick is committed frames before it lands, so launching at a target who
  // is already on the floor is what produces a wake-up loop: the kick arrives
  // exactly as the getup invincibility runs out. Only jump at someone standing.
  const jumpable = tgt && !isDownish(tgt) && tgt.inv <= 0 && tgt.state !== 'held';
  if (e.type === 'kicker' && jumpable && e.ai.cool <= 0 && adx > 64 && adx < 120 && Math.abs(dy) < 8 && (tok || chance(0.01))) {
    e.face = sign(dx); e.state = 'jkick'; e.st = 0; e.vz = 4.6; e.vx = e.face * 3.1; e.z = 0.1; e.hitIds = {};
    e.ai.tok = false; e.ai.cool = d.react * 3; sfx('jump'); return;
  }
  if (e.type === 'blade' && e.weapon && e.weapon.kind === 'knife' && e.ai.cool <= 0 && adx > 80 && adx < 180 && Math.abs(dy) < 6 && chance(0.02 + G.diff * 0.01)) {
    e.face = sign(dx); startMove(e, 'eToss'); e.ai.cool = d.react * 4; return;
  }
  if (e.type === 'bruiser' && G.diff >= 2 && e.ai.cool <= 0 && adx > 110 && adx < 200 && Math.abs(dy) < 8 && chance(0.02)) {
    e.face = sign(dx); startMove(e, 'eRush'); e.ai.cool = d.react * 5; return;
  }
  let gx, gy;
  if (tok) { gx = tgt.x - sign(dx || 1) * (range - 6); gy = tgt.y; }
  else {
    const hold = e.type === 'kicker' ? 96 : 62 + (e.id % 3) * 20;
    gx = tgt.x - sign(dx || e.ai.side) * hold; gy = clamp(tgt.y + e.ai.oy * 2.2, TUNING.bandTop, TUNING.bandBot);
    if (e.st % 200 === 0) e.ai.oy = rand(-14, 14);
  }
  // never loiter off-screen: take the other side of the target instead
  const L = G.camX + 16, Rr = G.camX + W - 16;
  if (gx < L || gx > Rr) gx = clamp(tgt.x + (tgt.x - gx), L, Rr);
  const moving = walkTo(e, gx, gy, e.speed * (tok ? 1 : 0.7));
  e.face = sign(dx) || e.face;
  if (tok && adx < range + 3 && Math.abs(dy) < 7 && e.ai.cool <= 0 && tgt.z < 20 && canBeHit(tgt)) {
    if (e.ai.t > 0) { if (!moving) e.pose = 'idle'; return; }
    let mvn = 'ePunch';
    if (e.weapon && e.weapon.kind === 'pipe') mvn = 'eSwing';
    else if (e.type === 'blade' && e.weapon) mvn = 'eSlash';
    else if (e.type === 'bruiser') mvn = chance(0.4) && tgt.state !== 'held' ? 'eReach' : 'eHay';
    else if (e.type === 'robot') mvn = chance(0.5) ? 'eHay' : 'ePunch2';
    else if (e.type === 'whip') mvn = 'eWhip';
    else if (e.type === 'kicker') mvn = chance(0.6) ? 'eKick' : 'ePunch';
    startMove(e, mvn);
    e.ai.tok = false; e.ai.cool = d.react * 2 + irand(0, 30); e.ai.t = d.react;
    return;
  }
  if (e.ai.t <= 0) e.ai.t = d.react;
}
function walkTo(e, gx, gy, spd) {
  let mv = false;
  if (Math.abs(gx - e.x) > 3) { e.x += sign(gx - e.x) * Math.min(spd, Math.abs(gx - e.x)); mv = true; }
  if (Math.abs(gy - e.y) > 2) { e.y += sign(gy - e.y) * Math.min(spd * 0.7, Math.abs(gy - e.y)); mv = true; }
  if (mv) { e.walkT++; e.pose = 'walk' + (1 + (Math.floor(e.walkT / 8) % 4)); }
  else e.pose = Math.floor(e.st / 30) % 2 ? 'idle2' : 'idle';
  return mv;
}
function dummyThink(e, tgt) {
  const mode = G.trainDummy; // 0 stand 1 walk 2 guard 3 attack
  e.pose = 'idle';
  if (!tgt) return;
  e.face = sign(tgt.x - e.x) || e.face;
  if (mode === 1) { e.x += Math.sin(e.st / 40) * 0.8; e.walkT++; e.pose = 'walk' + (1 + (Math.floor(e.walkT / 8) % 4)); }
  if (mode === 3 && e.ai.cool <= 0 && Math.abs(tgt.x - e.x) < 32 && Math.abs(tgt.y - e.y) < 8) { startMove(e, 'ePunch'); e.ai.cool = 70; }
  if (mode === 3 && Math.abs(tgt.x - e.x) > 30) walkTo(e, tgt.x - sign(tgt.x - e.x) * 26, tgt.y, 0.8);
}
function enemyMove(e) {
  const n = e.mvName;
  if (n === 'eToss' && e.mf === 18 && e.weapon) {
    G.projs.push({ x: e.x + e.face * 14, y: e.y, z: 42, vx: e.face * 5.2, vz: 0, kind: 'knife', team: 'foe', owner: e,
      dmg: 9, type: 'H', life: 80, dur: 10, hit: new Set() });
    e.weapon = null; sfx('knife');
  }
  if (n === 'eReach' && e.mf >= 10 && e.mf <= 18) {
    for (const h of G.ents) {
      if (h.team !== 'hero' || !canBeHit(h) || h.z > 3 || h.heldBy || h.state === 'held' || h.state === 'grab') continue;
      const ddx = (h.x - e.x) * e.face;
      if (ddx > 0 && ddx < 34 && Math.abs(h.y - e.y) < 8) {
        if (h.kind === 'player' && CHEAT.invincible) continue;
        if (G.mode === 'training') continue;
        e.grab = h; h.heldBy = e; h.state = 'held'; h.st = 0; h.mash = 0; h.mv = null;
        if (h.grab) releaseGrab(h);
        startMove(e, 'eSlam', 'gslam'); sfx('grab');
        return;
      }
    }
  }
  if (n === 'eWhip') e.whipT = e.mf >= 16 && e.mf <= 26 ? e.mf - 15 : 0;
  if (n === 'eRush' && e.mf >= 16 && e.mf % 6 === 0) G.fx.push({ k: 'dust', x: e.x - e.face * 8, y: e.y, t: 12 });
  moveStep(e);
  if (e.mf >= e.mv.total) {
    e.whipT = 0;
    const follow = n === 'ePunch' && e.hitMask && e.type !== 'dummy' && chance(0.45 + G.diff * 0.1);
    if (follow) { startMove(e, 'ePunch2'); return; }
    e.state = 'ai'; e.st = 0; e.mv = null;
  }
}
function enemySlam(e) {
  const h = e.grab, f = e.mf;
  e.pose = poseAt(e.mv, f);
  if (!h || h.heldBy !== e) { e.grab = null; e.state = e.kind === 'boss' ? e.idleState : 'ai'; e.st = 0; e.dropping = false; return; }
  const lift = e.kind === 'boss' ? 56 : 40;
  if (f < 40) { h.x = e.x + e.face * 4; h.z = Math.min(lift, f * 2); h.y = e.y + 0.5; h.pose = 'held'; h.rotOver = 180; }
  else { e.dropping = true; h.z = Math.max(0, lift - (f - 40) * 8); h.rotOver = 180; }
  if (f === 46) {
    e.grab = null; h.heldBy = null; h.rotOver = null; e.dropping = false;
    h.state = 'stand';
    applyHit(e, h, { dmg: e.kind === 'boss' ? 22 : 14, type: 'K', kx: 1.5, kz: 2.4 });
    G.shake = 9; sfx('slam');
    G.fx.push({ k: 'dust', x: h.x, y: h.y, t: 18 });
  }
  e.mf++;
  if (e.mf >= e.mv.total) { e.state = e.kind === 'boss' ? e.idleState : 'ai'; e.st = 0; e.mv = null; }
}

// ------------------------------------------------------------ boss AI (Big Brick Harlan)
const BOSS_MOVES = {
  bPunch: M([['idle', 10], ['jab1', 7], ['idle', 14]], { f: [10, 13], x: [4, 34], z: [30, 60], dmg: 8, type: 'H' }, { cancel: 99 }),
  bHook: M([['hookA', 12], ['hook', 8], ['idle', 16]], { f: [12, 15], x: [2, 34], z: [30, 60], dmg: 10, type: 'K', kx: 3.5, kz: 3 }, { cancel: 99 }),
  bPole: M([['poleWind', 26], ['poleSwing', 10], ['idle', 20]], { f: [26, 30], x: [-6, 58], z: [0, 60], dmg: 14, type: 'K', kx: 4, kz: 3.4, dy: 6 }, { cancel: 99 }),
};
Object.assign(MOVES, BOSS_MOVES);
function bossTarget(b) { return nearestHero(b); }
function bossUpdate(b) {
  if (b.hitstop > 0) { b.hitstop--; return; }
  commonTimers(b);
  const B = b.boss, d = diffOf();
  b.stagger = Math.max(0, b.stagger - 0.12);
  const tgt = bossTarget(b);
  switch (b.state) {
    case 'bintro': {
      const f = b.st;
      if (f < 70) { b.x -= 1.1; b.walkT++; b.pose = 'walk' + (1 + (Math.floor(b.walkT / 10) % 4)); }
      else if (f < 150) { b.pose = 'roar'; if (f === 72) { sfx('roar'); G.shake = 12; rumble(0.8, 0.4, 500); G.banner = { s: b.def.name, t: 150, col: '#e8283a', sub: b.def.sub }; } }
      else { b.state = 'bidle'; b.st = 0; B.cool = 30; }
      b.inv = 2;
      break;
    }
    case 'bidle': case 'bwalk': {
      B.cool--;
      if (!tgt) { b.pose = 'idle'; break; }
      const dx = tgt.x - b.x, dy = tgt.y - b.y, adx = Math.abs(dx), ady = Math.abs(dy);
      b.face = sign(dx) || b.face;
      if (!B.poleDone && b.hp <= b.maxHp * (G.diff >= 2 ? 0.6 : 0.5)) { b.state = 'broar'; b.st = 0; break; }
      if (B.cool > 0 || tgt.state === 'held' || tgt.state === 'respawn') {
        const want = adx > 70 ? tgt.x - sign(dx) * 50 : b.x;
        walkTo(b, want, tgt.y, b.speed * 0.8);
        break;
      }
      const r = Math.random();
      if (adx < 50 && ady < 12) {
        if (b.weapon && r < 0.55) startMove(b, 'bPole');
        else if (r < 0.4) startMove(b, 'bPunch');
        else if (r < 0.62) startMove(b, 'bHook');
        else if (r < 0.85 && canBeHit(tgt) && tgt.z < 3) startMove(b, 'eReach');
        else { b.state = 'bslamTell'; b.st = 0; }
        B.cool = 34 - G.diff * 6 + irand(0, 20);
      } else if (b.beamBoss && adx > 80 && r < 0.42) {
        b.state = 'bbeamTell'; b.st = 0; B.cool = 52;
      } else if (adx > 120 && ady < 60 && r < 0.5) {
        b.state = 'bchargeTell'; b.st = 0; B.cool = 40;
      } else if (adx < 95 && ady < 36 && r < 0.3) {
        b.state = 'bslamTell'; b.st = 0; B.cool = 40;
      } else {
        walkTo(b, tgt.x - sign(dx) * 38, tgt.y, b.speed);
        if (b.weapon && adx < 64 && ady < 10 && r < 0.3) { startMove(b, 'bPole'); B.cool = 40; }
      }
      break;
    }
    case 'move': {
      if (b.mvName === 'eReach') enemyMove(b);
      else {
        moveStep(b);
        if (b.mf >= b.mv.total) { b.state = 'bidle'; b.st = 0; b.mv = null; }
      }
      if (b.state === 'ai') b.state = 'bidle';
      break;
    }
    case 'gslam': enemySlam(b); break;
    case 'bchargeTell': {
      const tell = [60, 48, 40, 32][G.diff];
      if (b.st === 1) { sfx('warn'); B.chargeDir = tgt ? (sign(tgt.x - b.x) || -1) : -1; }
      if (tgt && b.st < tell - 12) b.y = approach(b.y, tgt.y, 1.3);
      b.face = B.chargeDir;
      b.pose = Math.floor(b.st / 8) % 2 ? 'paw1' : 'paw2';
      if (b.st % 16 === 0) G.fx.push({ k: 'dust', x: b.x - b.face * 10, y: b.y, t: 14 });
      if (b.st >= tell) { b.state = 'bcharge'; b.st = 0; B.hitSet = new Set(); B.cx0 = b.x; sfx('roar'); }
      break;
    }
    case 'bcharge': {
      const spd = [4.4, 5.2, 5.8, 6.4][G.diff];
      b.x += b.face * spd;
      b.pose = Math.floor(b.st / 5) % 2 ? 'charge' : 'charge2';
      if (b.st % 4 === 0) G.fx.push({ k: 'dust', x: b.x - b.face * 18, y: b.y, t: 14 });
      if (b.fireBoss && b.st % 22 === 10) firePool(b, b.x - b.face * 20, b.y);
      for (const h of G.ents) {
        if (h.team !== 'hero' || !canBeHit(h) || B.hitSet.has(h.id) || h.z > 30) continue;
        if (Math.abs(h.y - b.y) < 15 && Math.abs(h.x - (b.x + b.face * 14)) < 22) {
          B.hitSet.add(h.id);
          applyHit(b, h, { dmg: 16, type: 'K', kx: 5, kz: 3.6 });
        }
      }
      const wall = b.face > 0 ? b.x > G.camX + W - 26 : b.x < G.camX + 26;
      if (wall) {
        b.x = clamp(b.x, G.camX + 26, G.camX + W - 26);
        sfx('slam'); G.shake = 12; rumble(0.9, 0.9, 400);
        G.fx.push({ k: 'ring', x: b.x + b.face * 16, y: b.y, z: 40, t: 16, col: '#fff' });
        b.state = 'dazed'; b.st = 0; b.dazeLeft = [150, 110, 80, 60][G.diff]; sfx('dizzy');
      } else if (Math.abs(b.x - B.cx0) > 420) { b.state = 'bidle'; b.st = 0; }
      break;
    }
    case 'bslamTell': {
      const tell = [50, 40, 34, 28][G.diff];
      b.pose = 'slamUp';
      if (b.st === 1) sfx('warn');
      if (b.st % 10 === 0) G.shake = Math.max(G.shake, 2);
      if (b.st >= tell) { b.state = 'bslam'; b.st = 0; }
      break;
    }
    case 'bslam': {
      b.pose = 'slamDown';
      if (b.st === 1) {
        sfx('slam'); G.shake = 12; rumble(1, 0.7, 350);
        G.fx.push({ k: 'shock', x: b.x + b.face * 20, y: b.y, t: 22, r: 80 });
        for (const h of G.ents) {
          if (h.team !== 'hero' || !canBeHit(h) || h.z > 6) continue;
          const ddx = h.x - (b.x + b.face * 20), ddy = (h.y - b.y) * 2.2;
          if (ddx * ddx + ddy * ddy < 80 * 80) applyHit(b, h, { dmg: 16, type: 'K', kx: 3 * sign(ddx || 1), kz: 3.6 });
        }
        if (G.diff >= 2 || b.fireBoss) {
          const dirs = (G.diff >= 3 || b.fireBoss) ? [-1, 1] : [tgt ? sign(tgt.x - b.x) || 1 : 1];
          for (const dd of dirs) G.projs.push({ x: b.x + dd * 40, y: b.y, z: 0, vx: dd * 4.2, vz: 0, kind: 'wave', team: 'foe', owner: b, dmg: 10, type: 'K', life: 90, hit: new Set() });
        }
        if (b.fireBoss) for (const dd of [-1, 1]) firePool(b, b.x + dd * 54, b.y);
      }
      if (b.st >= 34) { b.state = 'bidle'; b.st = 0; }
      break;
    }
    case 'bbeamTell': {
      const tell = [56, 46, 38, 30][G.diff];
      b.pose = b.st % 12 < 6 ? 'wardenAim' : 'wardenBeam';
      if (b.st === 1) { sfx('warn'); B.beamY = tgt ? tgt.y : b.y; B.beamDir = tgt ? (sign(tgt.x - b.x) || -1) : -1; }
      b.face = B.beamDir;
      if (b.st % 6 === 0) G.fx.push({ k: 'ring', x: b.x + b.face * 16, y: B.beamY, z: 46, t: 10, col: '#2ad0f0' });
      if (b.st >= tell) { b.state = 'bbeam'; b.st = 0; }
      break;
    }
    case 'bbeam': {
      b.pose = 'wardenBeam';
      if (b.st === 1) {
        sfx('zap'); G.flashT = 3; G.shake = 6; rumble(0.7, 0.5, 260);
        const n = 1 + (G.diff >= 2 ? 1 : 0);
        for (let i = 0; i < n; i++) {
          G.projs.push({ x: b.x + b.face * 18, y: B.beamY + (i - (n - 1) / 2) * 15, z: 44, vx: b.face * 6.2, vz: 0,
            kind: 'bolt', team: 'foe', owner: b, dmg: 12, type: 'H', life: 120, hit: new Set(), vanish: true });
        }
      }
      if (b.st >= 26) { b.state = 'bidle'; b.st = 0; }
      break;
    }
    case 'bphase': {
      b.inv = 999;
      b.pose = b.st < 40 ? 'hurt2' : 'roar';
      if (b.st === 2) { sfx('dizzy'); popText('NOT LIKE THIS.', b.x, b.y - 100, '#f2c94c'); }
      if (b.st % 7 === 0) { G.fx.push({ k: 'spark', x: b.x + rand(-16, 16), y: b.y, z: rand(20, 70), t: 10, big: true }); G.shake = Math.max(G.shake, 3); }
      if (b.st === 70) phaseInto(b);
      break;
    }
    case 'broar': {
      b.pose = b.st < 40 ? 'roar' : 'reach';
      b.inv = 2;
      if (b.st === 2) { sfx('roar'); G.shake = 14; rumble(0.9, 0.5, 600); popText('HE\'S MAD!', b.x, b.y - 110, '#e8283a'); }
      if (b.st === 44) {
        B.poleDone = true; b.weapon = { kind: 'pole', dur: 999 }; sfx('brk');
        for (let i = 0; i < 8; i++) G.fx.push({ k: 'debris', x: b.x, y: b.y - 2, z: 40, vx: rand(-3, 3), vz: rand(1, 4), t: 40, col: '#5a6a5a' });
        if (G.diff >= 2) for (let i = 0; i < G.diff - 1; i++) {
          const s = i % 2 ? -1 : 1;
          spawnEnemy('punk', s > 0 ? G.camX + W + 30 : G.camX - 30, rand(TUNING.bandTop + 10, TUNING.bandBot - 10), s);
        }
      }
      if (b.st >= 70) { b.state = 'bidle'; b.st = 0; B.cool = 20; b.speed = 1.1; }
      break;
    }
    case 'dazed': {
      b.pose = Math.floor(b.st / 14) % 2 ? 'dizzy' : 'dizzy2';
      b.dazeLeft--;
      if (b.st % 12 === 0) G.fx.push({ k: 'star', x: b.x, y: b.y, z: 98, t: 24, a: b.st / 6 });
      if (b.dazeLeft <= 0) { b.state = 'bidle'; b.st = 0; B.cool = 10; b.stagger = 0; }
      break;
    }
    default: commonState(b);
  }
}
// every hit on a boss that cannot act right now adds pressure
function bossPressure(t) {
  if (!t.boss) return;
  const helpless = ['hurt', 'dazed', 'down', 'fall', 'getup', 'grabbed', 'mstall', 'ttaunt'].includes(t.state);
  if (helpless) t.boss.pressure = (t.boss.pressure || 0) + 1;
}
function bossHitReact(att, t, h, dmg, dir, killed) {
  const B = t.boss;
  t.stagger += dmg;
  if (killed) {
    knock(t, dir * 3, 4.2);
    G.slowmo = 70;
    if (t.weapon) dropBossPole(t);
    return;
  }
  const armored = ['bchargeTell', 'bcharge', 'bslamTell', 'bslam', 'broar', 'gslam', 'bburst',
    'vdashTell', 'vdash', 'vblink', 'venrage', 'bbeamTell', 'bbeam'].includes(t.state) || t.wakeArmor > 0 ||
    (t.state === 'move' && t.mf > 4);
  const bigHit = h.type === 'K' && (h.dmg >= 9 || (att.mv && att.mv.special) || h.proj);
  if (t.state === 'dazed') {
    if (bigHit) { t.dazeLeft = 0; knock(t, dir * 2.4, 3.2); if (t.weapon) dropBossPole(t); }
    return;
  }
  if (t.state === 'grabbed') return;
  if (armored) return;
  if (bigHit && t.state !== 'fall') { knock(t, dir * 2.2, 3); if (t.weapon) dropBossPole(t); return; }
  const thr = 46 * (1 + 0.15 * G.diff);
  if (t.stagger >= thr && !isDownish(t)) {
    t.stagger = 0; t.state = 'dazed'; t.st = 0; t.dazeLeft = [150, 120, 95, 75][G.diff]; sfx('dizzy');
    return;
  }
  if ([t.idleState, 'bidle', 'bwalk'].includes(t.state)) { t.state = 'hurt'; t.st = 0; t.hurtT = 9; t.pose = 'hurt1'; }
}
function firePool(owner, x, y) {
  G.projs.push({ x: clamp(x, G.camX + 14, G.camX + W - 14), y, z: 0, vx: 0, vz: 0, kind: 'fire', team: 'foe', owner,
    dmg: 5, type: 'H', life: 260, hit: new Set(), vanish: true });
  sfx('zap');
}
// a boss whose def names a `next` collapses and gets back up as something worse
function phaseInto(b) {
  const key = b.def && b.def.next;
  b.remove = true;
  G.pendingBoss = false;
  if (!key) return;
  // Something worse stands up in the suit, and it gets its own theme. Without
  // this the boss track just carries on and the second form is musically the
  // same fight as the first.
  const nextMus = BOSS_PHASE_MUSIC[key];
  if (nextMus && RCBand.has(nextMus)) Music.play(nextMus);
  const n = spawnBoss(b.x, b.y, key);
  n.state = n.boss.type === 'vex' ? 'vintro' : 'bintro';
  n.st = 60; n.z = 0; n.face = -1; n.inv = 60;
  G.boss = n;
  G.shake = 16; G.flashT = 6; sfx('roar'); rumble(1, 1, 600);
  for (let i = 0; i < 14; i++) G.fx.push({ k: 'debris', x: n.x, y: n.y, z: 50, vx: rand(-4, 4), vz: rand(2, 5), t: 44, col: pick(['#f2c94c', '#c82a4a', '#1a1626']) });
}
function dropBossPole(b) {
  b.weapon = null;
  const it = spawnItem(b.x, b.y + 2, 'pipe', null, 3);
  it.dur = 16; it.vx = rand(-1.5, 1.5);
  popText('POLE DROPPED!', b.x, b.y - 110, '#e8e2a0');
}



// ------------------------------------------------------------ boss: the blade fighters (Vex, Dray)
Object.assign(MOVES, {
  vSlash: M([['vexReady', 10], ['vexLunge', 8], ['vexSpinA', 6], ['vexReady', 12]],
    [{ f: [10, 14], x: [4, 40], z: [20, 62], dmg: 9, type: 'H' }, { f: [18, 22], x: [4, 42], z: [16, 64], dmg: 10, type: 'K', kx: 3.2, kz: 2.8 }],
    { cancel: 99, step: [[10, 18, 3.2]], snd: 'knife' }),
  vSpin: M([['vexSpinA', 5], ['vexSpinB', 5], ['vexSpinA', 5], ['vexSpinB', 5], ['vexReady', 12]],
    [{ f: [2, 4], x: [-34, 34], z: [16, 66], dmg: 6, type: 'H' }, { f: [8, 10], x: [-34, 34], z: [16, 66], dmg: 6, type: 'H' },
     { f: [14, 19], x: [-38, 38], z: [12, 70], dmg: 9, type: 'K', kx: 3.6, kz: 3.8 }],
    { cancel: 99, step: [[0, 20, 2.4]], snd: 'knife' }),
  vThrow: M([['vexReady', 12], ['vexThrow', 10], ['vexReady', 14]], [], { cancel: 99 }),
  vCane: M([['drayCane', 12], ['drayPoint', 8], ['drayCane', 14]], { f: [12, 16], x: [4, 46], z: [22, 60], dmg: 10, type: 'H' }, { cancel: 99, snd: 'clank' }),
});
const VEX_TELE = { pose: 'vexBlink' };
function vexUpdate(b) {
  if (b.hitstop > 0) { b.hitstop--; return; }
  commonTimers(b);
  const B = b.boss, d = diffOf();
  b.stagger = Math.max(0, b.stagger - 0.14);
  const tgt = bossTarget(b);
  switch (b.state) {
    case 'vintro': {
      const f = b.st;
      if (f < 50) { b.x -= 1.6; b.walkT++; b.pose = 'walk' + (1 + (Math.floor(b.walkT / 7) % 4)); }
      else if (f < 130) {
        b.pose = f % 20 < 10 ? 'vexReady' : 'vexSpinA';
        if (f === 52) { sfx('knife'); G.banner = { s: b.def.name, t: 150, col: '#e8283a', sub: b.def.sub }; rumble(0.5, 0.5, 300); }
      } else { b.state = 'vidle'; b.st = 0; B.cool = 24; }
      b.inv = 2;
      break;
    }
    case 'vidle': {
      B.cool--;
      if (!tgt) { b.pose = 'idle'; break; }
      const dx = tgt.x - b.x, dy = tgt.y - b.y, adx = Math.abs(dx), ady = Math.abs(dy);
      b.face = sign(dx) || b.face;
      if (!B.poleDone && b.hp <= b.maxHp * 0.5) { b.state = 'venrage'; b.st = 0; break; }
      if (B.cool > 0 || tgt.state === 'respawn') {
        // circle the target instead of standing still
        const want = b.x + (adx < 60 ? -sign(dx) * 2.2 : sign(dx) * 1.4);
        walkTo(b, want, tgt.y + (B.lane || 0), b.speed * 0.9);
        b.pose = 'walk' + (1 + (Math.floor(b.walkT++ / 6) % 4));
        if (b.st % 40 === 0) B.lane = rand(-16, 16);
        break;
      }
      const r = Math.random();
      if (adx < 52 && ady < 13) {
        if (r < 0.5) startMove(b, 'vSlash');
        else if (r < 0.8) startMove(b, 'vSpin');
        else { b.state = 'vblink'; b.st = 0; }
        B.cool = 30 - G.diff * 5 + irand(0, 16);
      } else if (adx > 110 && r < 0.55) {
        if (r < 0.3 && G.diff >= 1) startMove(b, 'vThrow');
        else { b.state = 'vblink'; b.st = 0; }
        B.cool = 38 - G.diff * 5;
      } else if (r < 0.35) {
        b.state = 'vdashTell'; b.st = 0; B.cool = 36;
      } else {
        walkTo(b, tgt.x - sign(dx) * 34, tgt.y, b.speed);
        b.pose = 'walk' + (1 + (Math.floor(b.walkT++ / 5) % 4));
      }
      break;
    }
    case 'move': {
      moveStep(b);
      if (b.mvName === 'vThrow' && b.mf === 14) {
        const n = 1 + Math.min(2, G.diff);
        for (let i = 0; i < n; i++) {
          G.projs.push({ x: b.x + b.face * 12, y: b.y + (i - (n - 1) / 2) * 13, z: 42, vx: b.face * 5.6, vz: 0,
            kind: 'knife', team: 'foe', owner: b, dmg: 8, type: 'H', life: 110, hit: new Set(), vanish: true });
        }
        sfx('knife');
      }
      if (b.mf >= b.mv.total) { b.state = b.idleState; b.st = 0; b.mv = null; }
      break;
    }
    case 'vblink': {
      b.inv = 2;
      b.pose = 'vexBlink';
      if (b.st === 1) { sfx('zap'); G.fx.push({ k: 'ring', x: b.x, y: b.y, z: 40, t: 12, col: '#ff2a4a' }); }
      if (b.st === 10 && tgt) {
        const side = tgt.x > G.camX + W / 2 ? -1 : 1;
        b.x = clamp(tgt.x + side * 40, G.camX + 24, G.camX + W - 24);
        b.y = tgt.y; b.face = -side;
        G.fx.push({ k: 'ring', x: b.x, y: b.y, z: 40, t: 12, col: '#ff2a4a' });
      }
      if (b.st >= 18) { b.state = b.idleState; b.st = 0; B.cool = 10; }
      break;
    }
    case 'vdashTell': {
      const tell = [46, 38, 30, 22][G.diff];
      if (b.st === 1) { sfx('warn'); B.chargeDir = tgt ? (sign(tgt.x - b.x) || -1) : -1; }
      if (tgt && b.st < tell - 8) b.y = approach(b.y, tgt.y, 1.6);
      b.face = B.chargeDir;
      b.pose = b.st % 10 < 5 ? 'vexReady' : 'vexSpinA';
      if (b.st >= tell) { b.state = 'vdash'; b.st = 0; B.hitSet = new Set(); B.cx0 = b.x; sfx('whiff'); }
      break;
    }
    case 'vdash': {
      const spd = [5.2, 6, 6.8, 7.4][G.diff];
      b.x += b.face * spd;
      b.pose = b.st % 6 < 3 ? 'vexSpinA' : 'vexSpinB';
      if (b.st % 3 === 0) G.fx.push({ k: 'ring', x: b.x - b.face * 10, y: b.y, z: 34, t: 8, col: 'rgba(255,60,90,0.7)' });
      for (const h of G.ents) {
        if (h.team !== 'hero' || !canBeHit(h) || B.hitSet.has(h.id) || h.z > 34) continue;
        if (Math.abs(h.y - b.y) < 15 && Math.abs(h.x - (b.x + b.face * 12)) < 20) {
          B.hitSet.add(h.id);
          applyHit(b, h, { dmg: 13, type: 'K', kx: 4.4, kz: 3.4 });
        }
      }
      const wall = b.face > 0 ? b.x > G.camX + W - 24 : b.x < G.camX + 24;
      if (wall) {
        b.x = clamp(b.x, G.camX + 24, G.camX + W - 24);
        sfx('slam'); G.shake = 8;
        b.state = 'dazed'; b.st = 0; b.dazeLeft = [120, 92, 70, 52][G.diff]; sfx('dizzy');
      } else if (Math.abs(b.x - B.cx0) > 380) { b.state = b.idleState; b.st = 0; }
      break;
    }
    case 'venrage': {
      b.pose = b.st % 16 < 8 ? 'vexReady' : 'vexSpinA';
      b.inv = 2;
      if (b.st === 2) { sfx('roar'); G.shake = 10; popText('NO MORE PLAYING!', b.x, b.y - 100, '#e8283a'); }
      if (b.st === 40) {
        B.poleDone = true; b.enraged = true; b.speed *= 1.25; b.dmgMult = 1.2;
        if (G.diff >= 2) for (let i = 0; i < G.diff - 1; i++) {
          const s = i % 2 ? -1 : 1;
          spawnEnemy('blade', s > 0 ? G.camX + W + 30 : G.camX - 30, rand(TUNING.bandTop + 10, TUNING.bandBot - 10), s);
        }
      }
      if (b.st >= 60) { b.state = b.idleState; b.st = 0; B.cool = 16; }
      break;
    }
    case 'bphase': {
      b.inv = 999;
      b.pose = b.st < 40 ? 'hurt2' : 'drayCape';
      if (b.st === 2) { sfx('dizzy'); popText('ENOUGH. NO MORE GAMES.', b.x, b.y - 100, '#f2c94c'); }
      if (b.st % 7 === 0) { G.fx.push({ k: 'spark', x: b.x + rand(-16, 16), y: b.y, z: rand(20, 70), t: 10, big: true }); G.shake = Math.max(G.shake, 3); }
      if (b.st === 70) phaseInto(b);
      break;
    }
    case 'dazed': {
      b.pose = Math.floor(b.st / 14) % 2 ? 'dizzy' : 'dizzy2';
      b.dazeLeft--;
      if (b.st % 12 === 0) G.fx.push({ k: 'star', x: b.x, y: b.y, z: 82, t: 24, a: b.st / 6 });
      if (b.dazeLeft <= 0) { b.state = b.idleState; b.st = 0; B.cool = 10; b.stagger = 0; }
      break;
    }
    default: commonState(b);
  }
}

// ------------------------------------------------------------ boss: cornered breakout (all bosses)
const CORNER_FRAMES = 90;      // 1.5 s pinned in a corner
const PRESSURE_HITS = 10;      // ...or this many hits while he can't act, anywhere on screen
function bossCorner(b) {
  const B = b.boss;
  if (b.killed || b.remove || b.state === 'mbreak') return false;
  if (b.state === 'bburst') { bossBurst(b); return true; }
  if (b.hitstop > 0) return false;
  const margin = 64 + b.w;
  const cornered = b.x < G.camX + margin || b.x > G.camX + W - margin;
  const pinned = G.frames - (b.lastHurtF === undefined ? -999 : b.lastHurtF) < 45;
  if (cornered && pinned) B.cornerT++;
  else B.cornerT = Math.max(0, B.cornerT - 3);
  // pressure: hits taken while stunned, dazed, down or otherwise unable to answer
  B.pressure = Math.max(0, (B.pressure || 0) - 1 / 300);
  const pressured = B.pressure >= PRESSURE_HITS;
  if (B.cornerT >= CORNER_FRAMES || pressured) {
    if (pressured) B.cornerT = CORNER_FRAMES;
  }
  if (B.cornerT >= CORNER_FRAMES && !['screen', 'fall', 'bintro', 'tintro', 'mintro', 'vintro', 'gslam'].includes(b.state) && b.z <= 0) {
    if (b.heldBy) { const h = b.heldBy; h.grab = null; if (h.state === 'grab' || h.state === 'gmove' || h.state === 'vault') { h.state = 'stand'; h.mv = null; h.z = 0; } b.heldBy = null; }
    b.state = 'bburst'; b.st = 0; b.mv = null; b.dazeLeft = 0; b.burstT = 1; b.z = 0; b.rotOver = null;
    sfx('warn');
    popText('BREAKING OUT!', b.x, b.y - 30, '#ffd040');
    return true;
  }
  return false;
}
function bossBurst(b) {
  commonTimers(b);
  b.inv = 2; b.burstT = b.st + 1;
  const tell = 24, type = b.boss.type;
  if (b.st < tell) {
    b.pose = type === 'twin' ? 'tCrouch' : type === 'vex' ? 'vexReady' : 'roar';
    b.mpose = 'stall';
    if (b.st % 4 === 0) G.shake = Math.max(G.shake, 2);
    return;
  }
  if (b.st === tell) {
    sfx('slam'); sfx('roar'); G.shake = 10; rumble(0.8, 0.6, 300);
    G.fx.push({ k: 'shock', x: b.x, y: b.y, t: 22, r: 110 });
    for (const h of G.ents) {
      if (h.team !== 'hero' || !canBeHit(h) || h.z > 40) continue;
      const dx = h.x - b.x, dy = (h.y - b.y) * 2;
      if (dx * dx + dy * dy < 110 * 110) applyHit(b, h, { dmg: 6, type: 'K', kx: 4.5, kz: 3.2 });
    }
    b.burstFrom = b.x;
    return;
  }
  const cx = G.camX + W / 2;
  const dur = 30;
  const k = Math.min(1, (b.st - tell) / dur);
  b.x = lerp(b.burstFrom, cx, k);
  b.face = sign(cx - b.burstFrom) || b.face;
  if (type === 'twin' || type === 'vex') { b.pose = 'aTuck'; b.rotOver = (b.st * 30) % 360; b.z = Math.sin(k * Math.PI) * 44; }
  else { b.walkT++; b.pose = 'walk' + (1 + (Math.floor(b.walkT / 6) % 4)); b.mpose = b.walkT % 16 < 8 ? 'walk1' : 'walk2'; }
  if (k >= 1) {
    b.state = b.idleState; b.st = 0; b.burstT = 0; b.rotOver = null; b.z = 0;
    b.boss.cornerT = 0; b.boss.pressure = 0; b.boss.cool = 25; b.wakeArmor = 45; b.stagger = 0;
  }
}

// ------------------------------------------------------------ boss: Ruby & Onyx
Object.assign(MOVES, {
  tKick: M([['tIdle', 4], ['tCrouch', 10], ['tSplit', 8], ['tIdle', 12]], { f: [14, 18], x: [4, 44], z: [20, 70], dmg: 9, type: 'K', kx: 3, kz: 3 }, { cancel: 99 }),
  tBack: M([['tCrouch', 12], ['tKickHigh', 8], ['tIdle', 10]], { f: [12, 16], x: [4, 46], z: [20, 80], dmg: 10, type: 'K', kx: 3.4, kz: 3.4 }, { cancel: 99 }),
});
function twinPose(b) {
  const p = b.pose;
  if (p && p.startsWith('walk')) b.pose = 'aWalk' + p.slice(4);
  else if (p === 'idle' || p === 'idle2') b.pose = p === 'idle' ? 'tIdle' : 'tIdle2';
}
function twinUpdate(b) {
  if (b.hitstop > 0) { b.hitstop--; return; }
  commonTimers(b);
  const B = b.boss;
  b.stagger = Math.max(0, b.stagger - 0.15);
  const tgt = nearestHero(b);
  const rage = b.enraged ? 0.75 : 1;
  const twins = G.bosses.filter(o => o.boss.type === 'twin');
  const other = twins.find(o => o !== b && !o.killed);
  const first = twins[0] === b;
  switch (b.state) {
    case 'tintro': {
      const f = b.st;
      b.inv = 2; b.face = -1;
      if (f < 60) { b.x -= 1.6; b.walkT++; b.pose = 'aWalk' + (1 + (Math.floor(b.walkT / 7) % 4)); }
      else if (f < 130) {
        b.pose = (f + (first ? 0 : 15)) % 30 < 15 ? 'tTaunt' : 'tIdle';
        if (f === 62 && first) { sfx('roar'); G.shake = 6; G.banner = { s: 'RUBY & ONYX', t: 150, col: '#e8283a', sub: 'THE VOSS TWINS' }; }
      } else { b.state = 'tidle'; b.st = 0; B.cool = first ? 30 : 80; }
      break;
    }
    case 'tidle': {
      B.cool--;
      if (!tgt) { b.pose = 'tIdle'; break; }
      const dx = tgt.x - b.x, dy = tgt.y - b.y, adx = Math.abs(dx), ady = Math.abs(dy);
      b.face = sign(dx) || b.face;
      let side = sign(b.x - tgt.x) || 1;
      if (other && sign(other.x - tgt.x) === side && Math.abs(other.x - tgt.x) < Math.abs(b.x - tgt.x)) side = -side;
      const busy = other && ['tcartTell', 'tcart', 'tflipTell', 'tflip', 'move'].includes(other.state);
      if (B.cool > 0 || tgt.state === 'held' || tgt.state === 'respawn' || (busy && B.cool > -40)) {
        walkTo(b, clamp(tgt.x + side * 74, G.camX + 34, G.camX + W - 34), clamp(tgt.y + (first ? -8 : 8), TUNING.bandTop, TUNING.bandBot), b.speed * 0.75);
        b.face = sign(dx) || b.face;
        twinPose(b);
        break;
      }
      const r = Math.random();
      if (adx < 50 * GS && ady < 10) { startMove(b, 'tKick'); B.cool = Math.round((44 - G.diff * 6) * rage) + irand(0, 20); }
      else if (ady < 40 && r < 0.5) { b.state = 'tcartTell'; b.st = 0; B.cartDir = sign(dx) || 1; B.cool = 60; }
      else if (adx < 170 && r < 0.9) { b.state = 'tflipTell'; b.st = 0; B.cool = 60; }
      else { walkTo(b, tgt.x - sign(dx) * 40, tgt.y, b.speed); twinPose(b); }
      break;
    }
    case 'move':
      moveStep(b);
      if (b.mf >= b.mv.total) { b.state = 'tidle'; b.st = 0; b.mv = null; }
      break;
    case 'tcartTell': {
      const tell = Math.round([40, 32, 26, 20][G.diff] * rage);
      if (b.st === 1) sfx('warn');
      if (tgt && b.st < tell - 8) b.y = approach(b.y, tgt.y, 1.4);
      b.face = B.cartDir; b.pose = 'tCrouch';
      if (b.st >= tell) { b.state = 'tcart'; b.st = 0; B.hitSet = new Set(); sfx('whiff'); }
      break;
    }
    case 'tcart': {
      b.x += b.face * [4.2, 4.8, 5.4, 6][G.diff] * (b.enraged ? 1.15 : 1);
      b.pose = 'tCartA'; b.rotOver = (b.st * 30) % 360;
      if (b.st % 6 === 0) sfx('whiff');
      for (const h of G.ents) {
        if (h.team !== 'hero' || !canBeHit(h) || B.hitSet.has(h.id) || h.z > 30) continue;
        if (Math.abs(h.y - b.y) < 14 && Math.abs(h.x - b.x) < 22) { B.hitSet.add(h.id); applyHit(b, h, { dmg: 10, type: 'K', kx: 3.5, kz: 3.6 }); }
      }
      if (b.x < G.camX + 34 || b.x > G.camX + W - 34) {
        b.x = clamp(b.x, G.camX + 34, G.camX + W - 34);
        b.state = 'ttaunt'; b.st = 0; b.rotOver = null; b.face = -b.face;
      }
      break;
    }
    case 'ttaunt':
      b.pose = b.st % 20 < 10 ? 'tTaunt' : 'tIdle';
      if (b.st >= Math.round([70, 55, 45, 36][G.diff])) { b.state = 'tidle'; b.st = 0; }
      break;
    case 'tflipTell': {
      const tell = Math.round([34, 28, 22, 18][G.diff] * rage);
      b.pose = 'tCrouch';
      if (tgt) b.face = sign(tgt.x - b.x) || b.face;
      if (b.st === 1) sfx('warn');
      if (b.st >= tell) {
        b.state = 'tflip'; b.st = 0; B.fx0 = b.x; B.fy0 = b.y;
        const tx = tgt ? tgt.x + sign(tgt.x - b.x) * 36 : b.x;
        B.fx1 = clamp(tx, G.camX + 30, G.camX + W - 30); B.fy1 = tgt ? tgt.y : b.y;
        sfx('jump');
      }
      break;
    }
    case 'tflip': {
      const k = Math.min(1, b.st / 24);
      b.x = lerp(B.fx0, B.fx1, k); b.y = lerp(B.fy0, B.fy1, k);
      b.z = Math.sin(k * Math.PI) * 64;
      b.pose = 'aTuck'; b.rotOver = (b.st * 30) % 360;
      if (k >= 1) {
        b.z = 0; b.rotOver = null;
        if (tgt) b.face = sign(tgt.x - b.x) || -b.face;
        startMove(b, 'tBack');
      }
      break;
    }
    case 'dazed':
      b.pose = Math.floor(b.st / 14) % 2 ? 'dizzy' : 'dizzy2';
      b.dazeLeft--;
      if (b.st % 12 === 0) G.fx.push({ k: 'star', x: b.x, y: b.y, z: 90, t: 24, a: b.st / 6 });
      if (b.dazeLeft <= 0) { b.state = 'tidle'; b.st = 0; B.cool = 10; b.stagger = 0; }
      break;
    default: commonState(b);
  }
}
function twinHitReact(att, t, h, dmg, dir, killed) {
  t.stagger += dmg;
  if (killed) {
    if (t.state === 'tflip' || t.state === 'tcart') { t.rotOver = null; }
    knock(t, dir * 3, 4);
    if (!liveBosses().some(o => o !== t)) G.slowmo = 60;
    return true;
  }
  if (['tcartTell', 'tcart', 'tflipTell', 'tflip', 'tintro', 'bburst'].includes(t.state) || t.wakeArmor > 0 || (t.state === 'move' && t.mf > 8)) return true;
  if (t.state === 'dazed') { if (h.type === 'K') { t.dazeLeft = 0; knock(t, dir * 2.6, 3.2); } return true; }
  if (t.state === 'grabbed') return true;
  if (t.stagger >= 36 * (1 + 0.15 * G.diff) && !isDownish(t)) {
    t.stagger = 0; t.state = 'dazed'; t.st = 0; t.dazeLeft = [140, 110, 85, 65][G.diff]; sfx('dizzy');
    return true;
  }
  return false;
}

// ------------------------------------------------------------ boss: Wrecker mech + Rivet
function mechUpdate(b) {
  if (b.hitstop > 0) { b.hitstop--; return; }
  commonTimers(b);
  const B = b.boss;
  b.stagger = Math.max(0, b.stagger - 0.1);
  const tgt = nearestHero(b);
  const T = (arr) => arr[G.diff];
  switch (b.state) {
    case 'mintro': {
      b.inv = 2; b.face = -1;
      if (b.st < 90) { b.x -= 0.9; b.walkT++; b.mpose = b.walkT % 20 < 10 ? 'walk1' : 'walk2'; if (b.walkT % 20 === 0) { sfx('thud'); G.shake = Math.max(G.shake, 3); } }
      else b.mpose = b.st % 24 < 12 ? 'clawUp' : 'idle';
      if (b.st === 10) sfx('engine');
      if (b.st === 92) { sfx('roar'); G.shake = 12; G.banner = { s: b.def.name, t: 150, col: '#e8b020', sub: b.def.sub }; }
      if (b.st >= 160) { b.state = 'midle'; b.st = 0; B.cool = 40; }
      break;
    }
    case 'midle': {
      B.cool--;
      if (!tgt) { b.mpose = 'idle'; break; }
      const dx = tgt.x - b.x, dy = tgt.y - b.y, adx = Math.abs(dx), ady = Math.abs(dy);
      b.face = sign(dx) || b.face;
      let moving = false;
      const want = tgt.x - sign(dx) * 66;
      if (Math.abs(want - b.x) > 6) { b.x += sign(want - b.x) * b.speed; moving = true; }
      if (ady > 4) { b.y += sign(dy) * b.speed * 0.6; moving = true; }
      if (moving) { b.walkT++; b.mpose = b.walkT % 24 < 12 ? 'walk1' : 'walk2'; if (b.walkT % 24 === 0) { sfx('thud'); G.shake = Math.max(G.shake, 2); } }
      else b.mpose = 'idle';
      if (B.cool > 0 || tgt.state === 'respawn') break;
      const r = Math.random();
      if (adx < 96 && ady < 20) { b.state = r < 0.6 ? 'mclawTell' : 'mstompTell'; }
      else if (ady < 26 && adx < 170) b.state = r < 0.7 ? 'mflameTell' : 'mstompTell';
      else if (adx < 120) b.state = 'mstompTell';
      else break;
      b.st = 0; B.cool = 56 - G.diff * 8 + irand(0, 24); B.hitSet = new Set();
      break;
    }
    case 'mclawTell':
      b.mpose = 'clawUp';
      if (b.st === 1) sfx('warn');
      if (b.st >= T([44, 36, 30, 24])) { b.state = 'mclaw'; b.st = 0; sfx('whiff'); }
      break;
    case 'mclaw':
      b.mpose = 'clawDown';
      if (b.st <= 6) for (const h of G.ents) {
        if (h.team !== 'hero' || !canBeHit(h) || B.hitSet.has(h.id) || h.z > 40) continue;
        const d = (h.x - b.x) * b.face;
        if (d > 0 && d < 96 && Math.abs(h.y - b.y) < 20) { B.hitSet.add(h.id); applyHit(b, h, { dmg: 14, type: 'K', kx: 4, kz: 3.4 }); }
      }
      if (b.st === 2) { sfx('clank'); G.shake = Math.max(G.shake, 5); }
      if (b.st >= 26) { b.state = 'midle'; b.st = 0; }
      break;
    case 'mflameTell':
      b.mpose = 'flameAim';
      if (b.st === 1) sfx('warn');
      if (tgt && b.st < 20) b.y = approach(b.y, tgt.y, 0.8);
      if (b.st >= T([50, 42, 34, 28])) { b.state = 'mflame'; b.st = 0; }
      break;
    case 'mflame': {
      b.mpose = 'flame';
      if (b.st % 8 === 0) noise(0.3, 0.35, 'lowpass', 1200, 500);
      for (let i = 0; i < 3; i++) {
        const dd = rand(24, 140);
        G.fx.push({ k: 'fire', x: b.x + b.face * dd, y: b.y + rand(-1, 1) * (6 + dd * 0.06), z: 36 + rand(-6, 6), t: irand(8, 14) });
      }
      for (const h of G.ents) {
        if (h.team !== 'hero' || !canBeHit(h) || h.z > 50) continue;
        const d = (h.x - b.x) * b.face;
        if (d > 20 && d < 140 && Math.abs(h.y - b.y) < 8 + d * 0.06 && G.frames - (h.flameT || -99) > 26) {
          h.flameT = G.frames;
          applyHit(b, h, { dmg: 7, type: 'K', kx: 2.6, kz: 3, fire: true });
        }
      }
      if (b.st >= 70) { b.state = 'midle'; b.st = 0; }
      break;
    }
    case 'mstompTell':
      b.mpose = 'stompUp';
      if (b.st === 1) sfx('warn');
      if (b.st >= T([40, 34, 28, 22])) { b.state = 'mstomp'; b.st = 0; }
      break;
    case 'mstomp':
      b.mpose = 'stompDown';
      if (b.st === 1) {
        sfx('slam'); G.shake = 12; rumble(1, 0.7, 350);
        G.fx.push({ k: 'shock', x: b.x + b.face * 14, y: b.y, t: 22, r: 100 });
        for (const h of G.ents) {
          if (h.team !== 'hero' || !canBeHit(h) || h.z > 6) continue;
          const ddx = h.x - (b.x + b.face * 14), ddy = (h.y - b.y) * 2.2;
          if (ddx * ddx + ddy * ddy < 100 * 100) applyHit(b, h, { dmg: 14, type: 'K', kx: 3, kz: 3.6 });
        }
        if (G.diff >= 2) for (const dd of [-1, 1]) G.projs.push({ x: b.x + dd * 44, y: b.y, z: 0, vx: dd * 4.2, vz: 0, kind: 'wave', team: 'foe', owner: b, dmg: 10, type: 'K', life: 90, hit: new Set() });
      }
      if (b.st >= 32) { b.state = 'midle'; b.st = 0; }
      break;
    case 'mstall':
      b.mpose = 'stall';
      if (b.st % 6 === 0) G.fx.push({ k: 'steam', x: b.x + rand(-20, 20), y: b.y, z: 110 + rand(0, 10), t: 30 });
      if (b.st >= 150 - G.diff * 20) { b.state = 'midle'; b.st = 0; B.cool = 20; }
      break;
    case 'mbreak': {
      b.mpose = 'break'; b.inv = 2;
      if (b.st % 8 === 0) { sfx('hitX'); G.fx.push({ k: 'boom', x: b.x + rand(-30, 30), y: b.y, zOff: rand(30, 100), t: 18, r: 22 }); G.shake = Math.max(G.shake, 5); }
      if (b.st === 90) {
        sfx('slam'); sfx('brk'); G.shake = 14; G.flashT = 4; rumble(1, 1, 500);
        G.fx.push({ k: 'boom', x: b.x, y: b.y, t: 30, r: 90 });
        for (let i = 0; i < 16; i++) G.fx.push({ k: 'debris', x: b.x, y: b.y, z: 60, vx: rand(-5, 5), vz: rand(2, 6), t: 50, col: pick(['#e8b020', '#4a4e58', '#c8302a']) });
        for (const h of G.ents) {
          if (h.team !== 'hero' || !canBeHit(h)) continue;
          if (Math.abs(h.x - b.x) < 80 && Math.abs(h.y - b.y) < 24) applyHazardHit(h, 12, sign(h.x - b.x) * 4 || 4, 4);
        }
        const r = spawnBoss(b.x, b.y, 'rivet');
        r.state = 'bintro'; r.st = 70; r.z = 0; r.face = -1; r.inv = 60;
        G.boss = r; G.pendingBoss = false;
        b.remove = true;
      }
      break;
    }
    default: b.mpose = 'idle'; b.state = 'midle';
  }
}
function mechHitReact(att, t, h, dmg, dir, killed) {
  if (killed || t.state === 'mstall' || t.state === 'mbreak') return;
  t.stagger += dmg;
  if (t.stagger >= 70 * (1 + 0.15 * G.diff) && t.state === 'midle') {
    t.state = 'mstall'; t.st = 0; t.stagger = 0; sfx('dizzy');
    popText('OVERHEATED!', t.x, t.y - 20, '#ffd040');
  }
}

// ------------------------------------------------------------ projectiles
function updateProjs() {
  for (const p of G.projs) {
    p.life--;
    p.x += p.vx;
    if (p.vz) { p.z += p.vz; if (p.z <= 0) { p.z = 0; p.life = 0; G.fx.push({ k: 'spark', x: p.x, y: p.y, z: 2, t: 6 }); } }
    if (p.kind === 'wave') {
      if (p.life % 3 === 0) G.fx.push({ k: 'dust', x: p.x, y: p.y, t: 10 });
    }
    if (p.kind === 'fire') {
      if (p.life % 34 === 0) p.hit.clear();
      if (p.life % 6 === 0) G.fx.push({ k: 'flame', x: p.x + rand(-10, 10), y: p.y, z: rand(0, 10), t: 14 });
    }
    for (const t of G.ents) {
      if (p.hit.has(t.id) || !canBeHit(t)) continue;
      if (t.team === p.team && !(SAVE.options.friendly && p.team === 'hero' && t.team === 'hero' && t !== p.owner)) continue;
      if (t === p.owner) continue;
      if (Math.abs(t.x - p.x) < t.w + 5 && Math.abs(t.y - p.y) < 9 && p.z >= t.z - 4 && p.z <= t.z + t.h) {
        p.hit.add(t.id);
        applyHit(p.owner, t, { dmg: p.dmg, type: p.type, kx: 3 * sign(p.vx), kz: 2.8 });
        if (p.kind !== 'wave' && p.kind !== 'fire') { p.life = 0; p.bounced = true; }
      }
    }
    if (p.kind !== 'fire' && (p.x < G.camX - 60 || p.x > G.camX + W + 60)) p.life = 0;
    if (p.life <= 0 && p.kind !== 'wave' && p.kind !== 'fire' && p.kind !== 'bolt' && !p.vanish && p.x > G.camX && p.x < G.camX + W) {
      const it = spawnItem(p.x, p.y, p.kind, null, p.bounced ? 3 : 1.5);
      it.dur = Math.max(2, (p.dur || 8) - 2); it.z = Math.max(2, p.z * 0.5); it.vx = -sign(p.vx) * (p.bounced ? 1.5 : 0.5);
      if (p.bounced) sfx('clank');
    }
  }
  G.projs = G.projs.filter(p => p.life > 0);
}

// ------------------------------------------------------------ per-frame world update
function checkDeath(e) {
  if (e.hp > 0 || e.killed) return;
  e.killed = true;
  if (e.team === 'foe') {
    G.kos++;
    if (e.kind === 'boss') {
      addScore(e.pts); popText('+' + fmt(e.pts), e.x, e.y - 110, '#f2c94c');
      if (e.boss.type === 'mech') { e.state = 'mbreak'; e.st = 0; G.pendingBoss = true; return; }
      if (e.def && e.def.next) { e.state = 'bphase'; e.st = 0; e.mv = null; e.hp = 0; G.pendingBoss = true; return; }
      if (e.boss.type === 'twin') for (const o of liveBosses()) if (o.boss.type === 'twin') { o.enraged = true; o.speed *= 1.3; popText('YOU\'LL PAY FOR THAT!', o.x, o.y - 100, '#e8283a'); }
    }
    else {
      addScore(e.pts);
      if (e.type !== 'dummy' && chance(0.07 * diffOf().drop)) spawnItem(e.x, e.y, pick(['apple', 'cash', 'cash']), null, 3);
    }
    if (e.state !== 'fall' && e.state !== 'manhole' && e.state !== 'screen' && e.state !== 'dead') knock(e, e.face * -2.5, 3);
  }
}
function updateFighters() {
  const p = G.player, a = G.ally;
  for (const e of G.ents) {
    if (e.remove) continue;
    if (e === p) heroUpdate(e, G.demoIntent ? G.demoIntent(e) : playerIntent());
    else if (e === a) heroUpdate(e, allyIntent(e));
    else if (e.kind === 'boss') {
      if (!bossCorner(e)) {
        if (e.boss.type === 'twin') twinUpdate(e);
        else if (e.boss.type === 'mech') mechUpdate(e);
        else if (e.boss.type === 'vex') vexUpdate(e);
        else bossUpdate(e);
      }
    }
    else enemyUpdate(e);
    checkDeath(e);
    // bounds
    if (e.state !== 'manhole' && e.state !== 'screen') e.y = clamp(e.y, TUNING.bandTop, TUNING.bandBot);
    if (e.team === 'hero' && !['gone', 'screen'].includes(e.state)) {
      const right = G.exitOpen ? G.scene.len + 40 : G.camX + W - 12;
      e.x = clamp(e.x, G.camX + 12, right);
    } else if (e.team === 'foe' && !e.enter && e.state !== 'screen') {
      const tight = e.state === 'ai' || e.state === 'move' || e.state === 'bidle' || e.state === 'tidle' || e.state === 'midle';
      e.x = tight ? clamp(e.x, G.camX + 10, G.camX + W - 10) : clamp(e.x, G.camX - 30, G.camX + W + 30);
      if (e.kind === 'boss') { const m = e.boss.type === 'mech' ? 50 : 20; e.x = clamp(e.x, G.camX + m, G.camX + W - m); }
    }
    if (G.mode === 'training') e.x = clamp(e.x, 12, W - 12);
  }
  // dead enemies removed
  G.ents = G.ents.filter(e => !e.remove || e === G.player);
  if (G.ally && G.ally.remove) G.ally = null;
}

// ------------------------------------------------------------ fx
function updateFx() {
  for (const f of G.fx) {
    f.t--;
    if (f.k === 'debris' || f.k === 'drop') { f.x += f.vx; f.z += f.vz; f.vz -= 0.3; if (f.z < 0) { f.z = 0; f.vx *= 0.6; f.vz = -f.vz * 0.3; } }
    if (f.k === 'txt') f.y -= 0.5;
    if (f.k === 'num') f.y -= 0.6;
    if (f.k === 'flame') f.z += 0.8;
  }
  G.fx = G.fx.filter(f => f.t > 0);
  for (const c of G.cracks) c.t--;
  G.cracks = G.cracks.filter(c => c.t > 0);
}
