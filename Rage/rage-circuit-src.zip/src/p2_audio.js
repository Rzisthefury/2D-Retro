// ============================================================ AUDIO
let AC = null, masterMusic = null, masterSfx = null, noiseBuf = null;
function initAudio() {
  if (AC) return;
  try {
    AC = new (window.AudioContext || window.webkitAudioContext)();
    masterMusic = AC.createGain(); masterMusic.connect(AC.destination);
    masterSfx = AC.createGain(); masterSfx.connect(AC.destination);
    const comp = AC.createDynamicsCompressor();
    masterSfx.disconnect(); masterSfx.connect(comp); comp.connect(AC.destination);
    noiseBuf = AC.createBuffer(1, AC.sampleRate * 1, AC.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    applyVolumes();
  } catch (e) { AC = null; }
}
function applyVolumes() {
  if (!AC) return;
  masterMusic.gain.value = (SAVE.options.music / 10) * 0.32;
  masterSfx.gain.value = (SAVE.options.sfx / 10) * 0.55;
}
function tryResumeAudio() {
  initAudio();
  if (AC && AC.state === 'suspended') AC.resume().then(() => Music.ensure()).catch(() => {});
  else Music.ensure();
}
function audioBlocked() { return !AC || AC.state !== 'running'; }

function envGain(dest, t, vol, att, dec) {
  const g = AC.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(vol, 0.0002), t + att);
  g.gain.exponentialRampToValueAtTime(0.0001, t + att + dec);
  g.connect(dest);
  return g;
}
function tone(type, f0, f1, dur, vol, delay = 0, dest = null, filt = 0) {
  if (!AC) return;
  const t = AC.currentTime + delay;
  const o = AC.createOscillator();
  o.type = type;
  o.frequency.setValueAtTime(f0, t);
  if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(f1, 1), t + dur);
  const g = envGain(dest || masterSfx, t, vol, 0.004, dur);
  if (filt) {
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = filt;
    o.connect(f); f.connect(g);
  } else o.connect(g);
  o.start(t); o.stop(t + dur + 0.05);
}
function noise(dur, vol, ftype, f0, f1, delay = 0, dest = null, q = 1) {
  if (!AC) return;
  const t = AC.currentTime + delay;
  const s = AC.createBufferSource(); s.buffer = noiseBuf;
  const f = AC.createBiquadFilter(); f.type = ftype; f.Q.value = q;
  f.frequency.setValueAtTime(f0, t);
  if (f1 !== f0) f.frequency.exponentialRampToValueAtTime(Math.max(f1, 20), t + dur);
  const g = envGain(dest || masterSfx, t, vol, 0.002, dur);
  s.connect(f); f.connect(g);
  s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05);
}
const SFX = {
  hitL() { noise(0.08, 0.7, 'lowpass', 2400, 600); tone('square', 180, 70, 0.07, 0.35); },
  hitH() { noise(0.16, 0.9, 'lowpass', 1800, 200); tone('square', 120, 40, 0.14, 0.5); tone('sine', 90, 35, 0.2, 0.6); },
  hitX() { noise(0.25, 1, 'lowpass', 3000, 150); tone('sawtooth', 160, 30, 0.25, 0.5); tone('sine', 70, 25, 0.3, 0.8); },
  whiff() { noise(0.07, 0.25, 'bandpass', 900, 2600, 0, null, 2); },
  jump() { tone('square', 220, 440, 0.07, 0.12); },
  land() { tone('sine', 110, 50, 0.06, 0.3); },
  fall() { noise(0.2, 0.7, 'lowpass', 500, 80); tone('sine', 80, 30, 0.25, 0.8); },
  brk() { noise(0.25, 0.8, 'highpass', 800, 3000); tone('square', 900, 300, 0.12, 0.15); tone('square', 1400, 700, 0.1, 0.1, 0.05); },
  pickup() { tone('square', 660, 660, 0.05, 0.18); tone('square', 990, 990, 0.08, 0.18, 0.05); },
  cash() { tone('square', 1320, 1320, 0.05, 0.15); tone('square', 1760, 1760, 0.18, 0.15, 0.05); },
  food() { tone('sine', 400, 150, 0.1, 0.4); tone('sine', 300, 600, 0.12, 0.35, 0.1); },
  oneup() { [523, 659, 784, 1047, 1319].forEach((f, i) => tone('square', f, f, 0.08, 0.16, i * 0.07)); },
  power() { [392, 523, 659, 784].forEach((f, i) => tone('sawtooth', f, f * 1.01, 0.09, 0.14, i * 0.05, null, 3000)); },
  special() { tone('sawtooth', 200, 900, 0.3, 0.3, 0, null, 2500); noise(0.35, 0.5, 'bandpass', 500, 3000, 0, null, 1.5); },
  charge() { tone('triangle', 200, 800, 0.35, 0.18); },
  glass() { noise(0.4, 0.8, 'highpass', 3000, 6000); [2400, 3100, 2800].forEach((f, i) => tone('sine', f, f * 0.98, 0.25, 0.12, i * 0.04)); },
  horn() { tone('square', 330, 330, 0.25, 0.22, 0, null, 1500); tone('square', 415, 415, 0.25, 0.18, 0, null, 1500); tone('square', 330, 330, 0.4, 0.22, 0.3, null, 1500); },
  engine() { tone('sawtooth', 80, 160, 0.6, 0.35, 0, null, 600); noise(0.6, 0.4, 'lowpass', 400, 1200); },
  water() { noise(0.9, 0.5, 'lowpass', 1500, 600); },
  move() { tone('square', 880, 880, 0.03, 0.1); },
  ok() { tone('square', 660, 660, 0.04, 0.14); tone('square', 1320, 1320, 0.06, 0.14, 0.04); },
  back() { tone('square', 500, 300, 0.07, 0.12); },
  buy() { [784, 988, 1175, 1568].forEach((f, i) => tone('square', f, f, 0.06, 0.14, i * 0.05)); },
  err() { tone('sawtooth', 120, 100, 0.18, 0.2); },
  knife() { tone('triangle', 2400, 1800, 0.12, 0.15); noise(0.05, 0.3, 'highpass', 5000, 5000); },
  clank() { tone('square', 700, 500, 0.12, 0.2); tone('square', 1100, 900, 0.1, 0.12); },
  roar() { tone('sawtooth', 110, 70, 0.8, 0.4, 0, null, 900); noise(0.8, 0.4, 'bandpass', 400, 200, 0, null, 2); },
  slam() { tone('sine', 60, 25, 0.5, 1); noise(0.45, 0.9, 'lowpass', 600, 60); },
  grab() { tone('sine', 150, 90, 0.06, 0.4); },
  dizzy() { for (let i = 0; i < 4; i++) tone('sine', 900 - i * 80, 1100 - i * 80, 0.08, 0.08, i * 0.08); },
  thud() { tone('sine', 140, 60, 0.1, 0.5); },
  ko() { tone('square', 300, 60, 0.4, 0.2); },
  warn() { tone('square', 1000, 1000, 0.06, 0.15); tone('square', 1000, 1000, 0.06, 0.15, 0.12); },
  levelup() { [523, 784, 1047, 784, 1047, 1568].forEach((f, i) => tone('square', f, f, 0.07, 0.14, i * 0.06)); },
  zap() { noise(0.35, 0.8, 'highpass', 2000, 5000); tone('sawtooth', 90, 60, 0.3, 0.3); tone('square', 1400, 300, 0.2, 0.12); },
  go() { tone('square', 988, 988, 0.08, 0.15); tone('square', 988, 988, 0.08, 0.15, 0.12); },
};
function sfx(name) { if (AC && SFX[name]) try { SFX[name](); } catch (e) {} }

// ------------------------------------------------------------ music
function pat(str) { return str.trim().split(/\s+/).map(t => t === '.' ? null : +t); }
const TRACKS = {
  title: {
    bpm: 128, root: 38, lroot: 62,
    prog: [0, 0, -2, 3],
    kick: 'x...x...x...x...', snare: '....x.......x...', hat: '..x...x...x...xo',
    bass: pat('0 . 12 . 0 . 12 0 . 0 12 . 0 . 10 12'),
    arp: [0, 7, 12, 15, 12, 7, 3, 7],
    leads: {
      A: [pat('12 . . . 10 . 12 . 15 . . . 14 . 12 .'), pat('10 . . . . . 7 . 10 . 12 . . . . .'),
          pat('8 . . . 10 . 12 . 13 . . . 12 . 10 .'), pat('15 . . . 14 . . . 12 . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 0 }],
  },
  stage1a: {
    bpm: 136, root: 40, lroot: 64,
    prog: [0, 0, -4, -2],
    kick: 'x...x...x...x..x', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.xo',
    bass: pat('0 . 0 12 . 0 10 . 0 . 0 12 . 7 10 12'),
    arp: [0, 3, 7, 10, 12, 10, 7, 3],
    leads: {
      A: [pat('12 . . 10 . 12 . 15 . . 12 . 10 . 7 .'), pat('10 . . 7 . 10 . 12 . . . . . . . .'),
          pat('8 . . 7 . 8 . 12 . . 15 . . 12 . .'), pat('14 . . 12 . 10 . 14 . . . . 15 . 14 .')],
      B: [pat('19 . 17 . 15 . 17 . 19 . . . 22 . . .'), pat('19 . 17 . 15 . 14 . 12 . . . . . . .'),
          pat('15 . 17 . 19 . 20 . 19 . 17 . 15 . 12 .'), pat('14 . . . . . 15 . . . 17 . 19 . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 0 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 1 },
               { bars: 4, lead: 'B', arp: 1 }, { bars: 4, lead: null, arp: 1, half: 1 }, { bars: 4, lead: 'B', arp: 1 }],
  },
  stage1b: {
    bpm: 140, root: 45, lroot: 69,
    prog: [0, 0, 1, -2],
    kick: 'x..x..x.x..x..x.', snare: '....x.......x..x', hat: '.xx.xx.x.xx.xx.x',
    bass: pat('0 0 . 0 12 . 0 . 0 0 . 13 12 . 10 .'),
    arp: [0, 3, 7, 3, 12, 7, 3, 7],
    leads: {
      A: [pat('12 . . . 13 . . . 15 . 13 . 12 . . .'), pat('10 . . . 12 . . . 8 . . . 7 . . .'),
          pat('12 . . . 13 . . . 17 . 15 . 13 . . .'), pat('15 . 13 . 12 . 10 . 12 . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 0 },
               { bars: 4, lead: null, arp: 1, half: 1 }],
  },
  boss: {
    bpm: 152, root: 38, lroot: 62,
    prog: [0, 1, 0, -1],
    kick: 'x.x.x.x.x.x.x.x.', snare: '....x.......x.xx', hat: 'xxxxxxxxxxxxxxxx',
    bass: pat('0 0 12 0 0 12 0 1 0 0 12 0 13 12 1 0'),
    arp: [0, 1, 7, 12, 13, 12, 7, 1],
    leads: {
      A: [pat('12 . 13 . 12 . 15 . 13 . 12 . 10 . 12 .'), pat('13 . . . 12 . . . 8 . 7 . 8 . 10 .'),
          pat('12 . 13 . 12 . 17 . 15 . 13 . 12 . 13 .'), pat('18 . . . 17 . . . 13 . . . 12 . . .')],
    },
    sections: [{ bars: 2, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  stage2a: {
    bpm: 124, root: 43, lroot: 67,
    prog: [0, 0, 3, 5],
    kick: 'x...x...x...x...', snare: '....x.......x...', hat: '..o...o...o...o.',
    bass: pat('0 . 12 0 . 12 0 . 0 . 12 0 . 10 12 .'),
    arp: [0, 3, 7, 12, 15, 12, 7, 3],
    leads: {
      A: [pat('15 . . 14 . 12 . . 10 . 12 . . . . .'), pat('15 . . 14 . 12 . . 17 . . . 15 . . .'),
          pat('12 . . . 10 . . . 12 . 14 . 15 . . .'), pat('17 . 15 . 14 . 12 . 10 . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: null, arp: 0, half: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  stage2b: {
    bpm: 128, root: 41, lroot: 65,
    prog: [0, -2, -4, -2],
    kick: 'x...x...x...x...', snare: '....x.......x...', hat: 'x.o.x.o.x.o.x.oo',
    bass: pat('0 0 12 . 0 0 12 . 0 0 12 . 10 . 12 .'),
    arp: [0, 7, 10, 12, 10, 7, 3, 7],
    leads: {
      A: [pat('12 . 15 . 17 . 15 . 12 . . . 10 . . .'), pat('12 . 15 . 17 . 19 . 17 . . . . . . .'),
          pat('19 . 17 . 15 . 17 . 19 . 22 . 19 . . .'), pat('17 . . . 15 . . . 12 . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 0 }],
  },
  stage3a: {
    bpm: 132, root: 38, lroot: 62,
    prog: [0, 0, 1, 0],
    kick: 'x..x..x.x.x..x..', snare: '....x.......x...', hat: 'xxx.xxx.xxx.xxx.',
    bass: pat('0 0 0 . 0 0 1 . 0 0 0 . 3 . 1 .'),
    arp: [0, 1, 5, 7, 12, 7, 5, 1],
    leads: {
      A: [pat('12 . . . 13 . 12 . 10 . . . 8 . . .'), pat('7 . . . 8 . 10 . 12 . . . . . . .'),
          pat('12 . . . 13 . 15 . 17 . 15 . 13 . . .'), pat('12 . . . . . . . 13 . . . 12 . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 0 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: null, arp: 1, half: 1 }],
  },
  stage3b: {
    bpm: 140, root: 40, lroot: 64,
    prog: [0, 1, 3, 1],
    kick: 'x.x.x.x.x.x.x.x.', snare: '....x.......x..x', hat: '.x.x.x.x.x.x.x.x',
    bass: pat('0 12 0 12 0 12 0 12 1 13 1 13 0 12 0 12'),
    arp: [0, 3, 7, 12],
    leads: {
      A: [pat('12 . 13 . 15 . 13 . 12 . . . 8 . 7 .'), pat('8 . . . 7 . . . 5 . . . 7 . . .'),
          pat('12 . 13 . 15 . 17 . 18 . 17 . 15 . 13 .'), pat('12 . . . . . . . . . . . . . . .')],
    },
    sections: [{ bars: 2, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 0 }],
  },
  boss2: {
    bpm: 148, root: 43, lroot: 67,
    prog: [0, 3, 0, -2],
    kick: 'x...x...x...x.x.', snare: '....x.......x...', hat: 'xoxoxoxoxoxoxoxo',
    bass: pat('0 . 0 12 0 . 0 12 0 . 0 12 10 . 12 .'),
    arp: [0, 3, 7, 10, 15, 10, 7, 3],
    leads: {
      A: [pat('15 . 14 . 15 . 17 . 15 . 14 . 12 . 10 .'), pat('12 . . . 14 . . . 15 . . . . . . .'),
          pat('15 . 14 . 15 . 19 . 17 . 15 . 14 . 12 .'), pat('10 . . . 12 . . . 14 . . . 15 . . .')],
    },
    sections: [{ bars: 2, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  boss3: {
    bpm: 156, root: 36, lroot: 60,
    prog: [0, 0, 1, -1],
    kick: 'xxx.x.x.xxx.x.x.', snare: '....x.......x.xx', hat: 'xxxxxxxxxxxxxxxx',
    bass: pat('0 0 0 12 0 0 1 13 0 0 0 12 11 . 12 .'),
    arp: [0, 1, 6, 12, 13, 12, 6, 1],
    leads: {
      A: [pat('12 . 13 . 12 . 18 . 17 . 13 . 12 . 13 .'), pat('18 . . . 17 . . . 13 . . . 12 . . .'),
          pat('12 . 13 . 15 . 18 . 19 . 18 . 15 . 13 .'), pat('24 . . . 23 . . . 19 . . . 18 . . .')],
    },
    sections: [{ bars: 2, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  // ---- stage 4: LAST TRAIN
  stage4a: {
    bpm: 146, root: 40, lroot: 64,
    prog: [0, 0, -3, -5],
    kick: 'x..x..x.x..x..x.', snare: '....x.......x...', hat: 'x.xxx.x.x.xxx.xo',
    bass: pat('0 . 0 . 12 . 0 . 0 . 0 12 . 10 . 7'),
    arp: [0, 3, 7, 12, 15, 12, 7, 3],
    leads: {
      A: [pat('12 . 15 . . . 14 . 12 . . . 10 . . .'), pat('10 . 12 . . . 10 . 7 . . . . . . .'),
          pat('15 . . . 17 . . . 15 . 14 . 12 . . .'), pat('12 . 10 . 7 . . . . . . . . . . .')],
      B: [pat('19 . . 19 . 17 . 15 . . 17 . 19 . . .'), pat('22 . . . 20 . 19 . 17 . . . . . . .'),
          pat('19 . 17 . 15 . 14 . 15 . 17 . 19 . . .'), pat('24 . . . 22 . 19 . 15 . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 0 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 1 },
               { bars: 4, lead: 'B', arp: 1 }, { bars: 4, lead: null, arp: 1, half: 1 }],
  },
  stage4b: {
    bpm: 154, root: 43, lroot: 67,
    prog: [0, 0, 2, -2],
    kick: 'x.x.x.x.x.x.x.x.', snare: '....x..x....x..x', hat: '.x.x.x.x.x.x.xxo',
    bass: pat('0 0 . 12 0 . 0 12 0 0 . 14 12 . 10 .'),
    arp: [0, 5, 7, 12, 14, 12, 7, 5],
    leads: {
      A: [pat('12 . 12 . 14 . 15 . 17 . . . 15 . 14 .'), pat('12 . . . 10 . . . 7 . . . . . . .'),
          pat('14 . 14 . 15 . 17 . 19 . . . 17 . 15 .'), pat('12 . 10 . 12 . . . . . . . . . . .')],
      B: [pat('24 . 22 . 19 . 17 . 19 . . . 22 . . .'), pat('24 . . . 22 . . . 19 . 17 . . . . .'),
          pat('19 . 22 . 24 . 26 . 24 . 22 . 19 . . .'), pat('17 . . . 19 . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'B', arp: 1 },
               { bars: 4, lead: null, arp: 1, half: 1 }],
  },
  boss4: {
    bpm: 150, root: 38, lroot: 62,
    prog: [0, 0, 1, 0],
    kick: 'x.xxx.x.x.xxx.x.', snare: '....x.......x.xx', hat: 'xxxxxxxxxxxxxxxo',
    bass: pat('0 0 1 0 . 0 1 0 0 0 1 0 12 . 10 .'),
    arp: [0, 1, 7, 8, 12, 8, 7, 1],
    leads: {
      A: [pat('12 . 13 . 12 . . . 8 . . . 7 . . .'), pat('12 . 13 . 15 . . . 13 . 12 . . . . .'),
          pat('19 . . . 18 . . . 17 . . . 13 . 12 .'), pat('12 . . . 8 . 7 . 6 . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 0 }],
  },
  // ---- stage 5: HIGHWAY HEAT
  stage5a: {
    bpm: 164, root: 41, lroot: 65,
    prog: [0, 3, 5, 3],
    kick: 'x...x...x...x.x.', snare: '....x.......x...', hat: 'xxxxxxxxxxxxxxxo',
    bass: pat('0 . 12 . 0 . 12 . 0 . 12 . 15 . 12 .'),
    arp: [0, 4, 7, 12, 16, 12, 7, 4],
    leads: {
      A: [pat('16 . . 14 . 12 . . 14 . . . 12 . . .'), pat('12 . . 14 . 16 . . 19 . . . . . . .'),
          pat('17 . . 16 . 14 . . 16 . . . 14 . . .'), pat('19 . 17 . 16 . 14 . 12 . . . . . . .')],
      B: [pat('24 . . . 21 . . . 19 . 21 . 24 . . .'), pat('26 . . . 24 . 21 . 19 . . . . . . .'),
          pat('21 . 24 . 26 . 28 . 26 . 24 . 21 . . .'), pat('19 . . . 21 . . . 24 . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'B', arp: 1 },
               { bars: 4, lead: 'A', arp: 1 }],
  },
  stage5b: {
    bpm: 168, root: 45, lroot: 69,
    prog: [0, -2, -4, -5],
    kick: 'x..x.x..x..x.x.x', snare: '....x..x....x..x', hat: '.x.x.x.x.x.x.x.o',
    bass: pat('0 . 0 12 . 0 10 . 0 . 0 12 . 8 7 .'),
    arp: [0, 3, 7, 10, 15, 10, 7, 3],
    leads: {
      A: [pat('15 . . . 14 . 12 . 10 . . . 12 . . .'), pat('15 . 17 . 19 . . . 17 . . . . . . .'),
          pat('12 . . . 10 . 8 . 7 . . . 10 . . .'), pat('12 . 15 . 17 . . . . . . . . . . .')],
      B: [pat('27 . . . 24 . 22 . 19 . . . 22 . . .'), pat('24 . . . 22 . . . 19 . 17 . . . . .'),
          pat('22 . 19 . 17 . 15 . 17 . 19 . 22 . . .'), pat('19 . . . . . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'B', arp: 1 }, { bars: 4, lead: null, arp: 1, half: 1 },
               { bars: 4, lead: 'A', arp: 1 }],
  },
  boss5: {
    bpm: 156, root: 42, lroot: 66,
    prog: [0, 0, -1, -3],
    kick: 'x..x..x..x..x.x.', snare: '....x.......x...', hat: 'x.xxx.xxx.xxx.xo',
    bass: pat('0 . 0 . 11 . 0 . 0 . 0 11 . 9 . 7'),
    arp: [0, 3, 6, 9, 12, 9, 6, 3],
    leads: {
      A: [pat('12 . . 15 . 18 . . 15 . . . 12 . . .'), pat('11 . . 14 . 17 . . 14 . . . . . . .'),
          pat('18 . 17 . 15 . 14 . 12 . . . 11 . . .'), pat('9 . . . 12 . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  // ---- stage 6: SYNDICATE WORKS
  stage6a: {
    bpm: 138, root: 36, lroot: 60,
    prog: [0, 0, 0, -2],
    kick: 'x...x..xx...x..x', snare: '....x.......x...', hat: 'x..x..x.x..x..xo',
    bass: pat('0 . . 0 . 0 . 12 0 . . 0 . 10 . 0'),
    arp: [0, 7, 12, 7, 15, 12, 7, 3],
    leads: {
      A: [pat('12 . . . . . 15 . . . 12 . . . 10 .'), pat('7 . . . . . 10 . . . 12 . . . . .'),
          pat('15 . . . 17 . . . 15 . . . 12 . . .'), pat('10 . . . 7 . . . . . . . . . . .')],
      B: [pat('24 . . . 22 . . . 19 . . . 15 . . .'), pat('22 . . . 19 . . . 17 . . . . . . .'),
          pat('19 . . 22 . . 24 . . . 22 . 19 . . .'), pat('15 . . . . . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 0 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'B', arp: 1 },
               { bars: 4, lead: 'A', arp: 1 }],
  },
  stage6b: {
    bpm: 146, root: 39, lroot: 63,
    prog: [0, 0, 4, 2],
    kick: 'x.x.x..xx.x.x..x', snare: '....x..x....x..x', hat: 'xxxxxxxxxxxxxxxo',
    bass: pat('0 0 . 12 . 0 . 0 0 0 . 14 . 12 . 10'),
    arp: [0, 4, 7, 11, 14, 11, 7, 4],
    leads: {
      A: [pat('14 . 12 . 11 . 12 . 14 . . . 16 . . .'), pat('11 . . . 9 . . . 7 . . . . . . .'),
          pat('16 . 14 . 12 . 14 . 16 . . . 19 . . .'), pat('14 . 12 . 11 . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: null, arp: 1, half: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  boss6: {
    bpm: 144, root: 35, lroot: 59,
    prog: [0, 0, 1, 1],
    kick: 'xx..xx..xx..xx.x', snare: '....x.......x.xx', hat: 'x.x.x.x.x.x.x.xo',
    bass: pat('0 0 . 0 1 . 0 . 0 0 . 1 . 0 . 12'),
    arp: [0, 1, 5, 8, 12, 8, 5, 1],
    leads: {
      A: [pat('12 . 13 . 12 . 8 . 5 . . . 1 . . .'), pat('12 . 13 . 17 . . . 13 . . . . . . .'),
          pat('20 . . . 19 . . . 17 . 13 . 12 . . .'), pat('8 . . . 5 . . . 1 . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 0 }],
  },
  // ---- stage 7: THE LAB
  stage7a: {
    bpm: 134, root: 44, lroot: 68,
    prog: [0, -3, -5, -7],
    kick: 'x.......x...x...', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.',
    bass: pat('0 . . 12 . . 0 . 0 . . 12 . . 10 .'),
    arp: [0, 3, 7, 10, 14, 10, 7, 3],
    leads: {
      A: [pat('14 . . . . . 12 . . . 10 . . . . .'), pat('12 . . . . . 10 . . . 7 . . . . .'),
          pat('17 . . . 15 . . . 14 . . . 12 . . .'), pat('10 . . . . . . . . . . . . . . .')],
      B: [pat('26 . . . 24 . . . 22 . . . 19 . . .'), pat('24 . . . 22 . . . 17 . . . . . . .'),
          pat('22 . . 24 . . 26 . . . 24 . 22 . . .'), pat('19 . . . 17 . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'B', arp: 1 }],
  },
  stage7b: {
    bpm: 142, root: 41, lroot: 65,
    prog: [0, 0, -1, -4],
    kick: 'x..x.x..x..x.x..', snare: '....x.......x..x', hat: '.xx.xx.x.xx.xx.o',
    bass: pat('0 . 0 11 . 0 . 8 0 . 0 11 . 8 . 7'),
    arp: [0, 3, 8, 11, 15, 11, 8, 3],
    leads: {
      A: [pat('15 . . 14 . 15 . 18 . . 15 . 14 . . .'), pat('11 . . . 8 . . . 7 . . . . . . .'),
          pat('18 . . 17 . 15 . 14 . . 15 . 18 . . .'), pat('20 . 18 . 15 . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: null, arp: 1, half: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  boss7: {
    bpm: 152, root: 40, lroot: 64,
    prog: [0, 0, -2, -2],
    kick: 'x.x.x.x.x.x.x.xx', snare: '....x..x....x..x', hat: 'xxxxxxxxxxxxxxxo',
    bass: pat('0 0 . 0 12 . 0 . 0 0 . 10 . 12 . 0'),
    arp: [0, 3, 7, 12, 15, 12, 7, 3],
    leads: {
      A: [pat('19 . . . 15 . . . 12 . 15 . 19 . . .'), pat('22 . 19 . 15 . . . 12 . . . . . . .'),
          pat('17 . . . 14 . . . 10 . 14 . 17 . . .'), pat('12 . . . 10 . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  // ---- stage 8: TOWER TOP
  stage8a: {
    bpm: 142, root: 43, lroot: 67,
    prog: [0, -4, -5, -7],
    kick: 'x...x...x...x..x', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.xo',
    bass: pat('0 . . 0 12 . 0 . 0 . . 0 . 8 . 7'),
    arp: [0, 4, 7, 12, 16, 12, 7, 4],
    leads: {
      A: [pat('16 . . . 14 . 12 . 16 . . . 19 . . .'), pat('12 . . . 11 . . . 7 . . . . . . .'),
          pat('19 . . . 17 . 16 . 14 . . . 12 . . .'), pat('11 . . . 12 . . . . . . . . . . .')],
      B: [pat('28 . . . 24 . . . 21 . 24 . 28 . . .'), pat('26 . . . 24 . 21 . 19 . . . . . . .'),
          pat('24 . . 21 . . 19 . . . 21 . 24 . . .'), pat('19 . . . . . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'B', arp: 1 },
               { bars: 4, lead: 'A', arp: 1 }],
  },
  stage8b: {
    bpm: 150, root: 38, lroot: 62,
    prog: [0, 0, 3, 5],
    kick: 'x..xx..xx..xx..x', snare: '....x.......x...', hat: '.x.x.x.x.x.x.x.o',
    bass: pat('0 . 0 12 . 0 . 12 0 . 0 15 . 12 . 10'),
    arp: [0, 3, 7, 12, 19, 12, 7, 3],
    leads: {
      A: [pat('19 . . 17 . 15 . . 17 . . . 19 . 22 .'), pat('15 . . 12 . 10 . . 12 . . . . . . .'),
          pat('22 . . . 24 . . . 22 . 19 . 15 . . .'), pat('12 . 15 . 19 . . . . . . . . . . .')],
      B: [pat('31 . . . 27 . . . 24 . 27 . 31 . . .'), pat('29 . . . 27 . 24 . 22 . . . . . . .'),
          pat('27 . 24 . 22 . 19 . 22 . 24 . 27 . . .'), pat('24 . . . . . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'B', arp: 1 }, { bars: 4, lead: null, arp: 1, half: 1 },
               { bars: 4, lead: 'A', arp: 1 }],
  },
  boss8: {
    bpm: 158, root: 37, lroot: 61,
    prog: [0, 0, 1, -2],
    kick: 'xx.xx.x.xx.xx.xx', snare: '....x.xx....x.xx', hat: 'xxxxxxxxxxxxxxxo',
    bass: pat('0 0 1 0 12 . 0 1 0 0 1 0 . 10 . 12'),
    arp: [0, 1, 6, 8, 12, 8, 6, 1],
    leads: {
      A: [pat('12 . 13 . 12 . 18 . 17 . . . 13 . 12 .'), pat('12 . 13 . 17 . 18 . 20 . . . . . . .'),
          pat('24 . . . 23 . . . 20 . 18 . 17 . 13 .'), pat('12 . . . 8 . 6 . 1 . . . . . . .')],
      B: [pat('29 . . . 25 . . . 24 . 25 . 29 . . .'), pat('30 . . . 29 . 25 . 24 . . . . . . .'),
          pat('25 . 24 . 20 . 18 . 20 . 24 . 25 . . .'), pat('24 . . . . . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }, { bars: 4, lead: 'B', arp: 1 },
               { bars: 4, lead: 'A', arp: 0 }],
  },
  ending: {
    bpm: 104, root: 45, lroot: 69,
    prog: [0, 5, -3, -5],
    kick: 'x.......x.......', snare: '............x...', hat: '..x...x...x...x.',
    bass: pat('0 . . . 7 . . . 12 . . . 7 . . .'),
    arp: [0, 4, 7, 12, 16, 12, 7, 4],
    leads: {
      A: [pat('16 . . . . . 19 . . . 16 . . . 14 .'), pat('12 . . . . . 14 . . . 16 . . . . .'),
          pat('19 . . . 21 . . . 19 . . . 16 . . .'), pat('14 . . . 12 . . . . . . . . . . .')],
    },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  menu: {
    bpm: 112, root: 41, lroot: 65,
    prog: [0, -4, -2, -5],
    kick: 'x.......x.......', snare: '....x.......x...', hat: '..x...x...x...x.',
    bass: pat('0 . . 0 . . 7 . 0 . . 0 . 10 . 12'),
    arp: [0, 7, 12, 16, 19, 16, 12, 7],
    leads: { A: [pat('12 . . . . . 16 . . . 14 . . . . .'), pat('12 . . . . . . . 11 . . . . . . .'),
                 pat('9 . . . . . 12 . . . 11 . . . . .'), pat('7 . . . . . . . . . . . . . . .')] },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  shop: {
    bpm: 100, root: 43, lroot: 67,
    prog: [0, 5, -3, 2],
    kick: 'x.....x...x.....', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.',
    bass: pat('0 . . 7 . . 12 . 0 . 10 . 7 . 5 .'),
    arp: [0, 4, 7, 11, 14, 11, 7, 4],
    leads: { A: [pat('16 . 14 . 12 . . . 11 . 12 . . . . .'), pat('17 . 16 . 14 . . . 12 . . . . . . .'),
                 pat('12 . 14 . 16 . . . 19 . 17 . 16 . . .'), pat('14 . . . . . . . . . . . . . . .')] },
    sections: [{ bars: 4, lead: null, arp: 1 }, { bars: 4, lead: 'A', arp: 1 }],
  },
  training: {
    bpm: 120, root: 45, lroot: 69,
    prog: [0, 0, 3, 5],
    kick: 'x...x...x...x...', snare: '........x.......', hat: '..x...x...x...x.',
    bass: pat('0 . . 0 . . 0 . 0 . . 0 . . 3 .'),
    arp: [0, 7, 12, 7], leads: {},
    sections: [{ bars: 4, lead: null, arp: 1 }],
  },
};
const Music = {
  cur: null, name: null, timer: null, next: 0, step: 0, bar: 0, sec: 0, secBar: 0,
  // band: the track is playing on the new engine rather than the old one.
  // cueBack: what to return to when a one-shot cue finishes.
  band: false, cueT: null, cueBack: null,
  play(name) {
    if (this.name === name) return;
    this.stop();
    this.name = name;
    if (!AC) return;
    // Anything the band knows goes to the band; anything it does not falls
    // back to the original engine, so a track id that was never rewritten
    // still plays rather than going silent.
    if (RCBand.has(name)) {
      RCBand.init(AC, masterMusic);
      RCBand.play(name);
      this.band = true; this.cur = null;
      return;
    }
    this.band = false;
    this.cur = TRACKS[name];
    if (!this.cur) return;
    this.next = AC.currentTime + 0.08; this.step = 0; this.bar = 0; this.sec = 0; this.secBar = 0;
    this.timer = setInterval(() => this.tick(), 25);
  },
  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null; this.name = null; this.cur = null;
    if (this.cueT) { clearTimeout(this.cueT); this.cueT = null; }
    this.cueBack = null;
    if (this.band) { RCBand.stop(); this.band = false; }
  },
  // A one-shot: play `name` once, then go back to `back` (or to whatever was
  // playing). Used for Unit-9's capsule and Dray going off the roof - moments
  // that want a statement rather than a loop.
  cue(name, back) {
    if (!AC || !RCBand.has(name)) return;
    const ret = back === undefined ? this.name : back;
    this.stop();
    this.name = name;
    RCBand.init(AC, masterMusic);
    RCBand.play(name);
    this.band = true;
    this.cueBack = ret;
    const secs = RCBand.seconds(name);
    this.cueT = setTimeout(() => {
      this.cueT = null;
      const b = this.cueBack;
      this.stop();
      if (b) this.play(b);
    }, Math.max(500, secs * 1000));
  },
  ensure() {
    if (this.name && AC && !this.timer && !this.band) { const n = this.name; this.name = null; this.play(n); }
    else if (this.name && AC && this.band && !RCBand.playing()) { const n = this.name; this.name = null; this.play(n); }
  },
  tick() {
    if (!AC || !this.cur || AC.state !== 'running') return;
    const T = this.cur, spb = 60 / T.bpm / 4;
    if (this.next < AC.currentTime - 0.25) this.next = AC.currentTime + 0.05;
    while (this.next < AC.currentTime + 0.12) {
      this.playStep(T, this.next, spb);
      this.next += spb;
      this.step++;
      if (this.step >= 16) {
        this.step = 0; this.bar++; this.secBar++;
        const s = T.sections[this.sec];
        if (this.secBar >= s.bars) { this.secBar = 0; this.sec = (this.sec + 1) % T.sections.length; }
      }
    }
  },
  playStep(T, t, spb) {
    const st = this.step, s = T.sections[this.sec];
    const root = T.root + T.prog[this.bar % T.prog.length];
    const d = masterMusic;
    const half = s.half;
    if (T.kick[st] === 'x' && !(half && st % 8)) this.kick(t, d);
    if (T.snare[st] === 'x' && !half) this.snare(t, d);
    if (T.hat[st] !== '.') this.hat(t, d, T.hat[st] === 'o');
    const b = T.bass[st];
    if (b !== null) this.bass(t, d, root + b, spb * 1.6);
    if (s.arp && st % 2 === 0) {
      const a = T.arp[(st / 2) % T.arp.length];
      this.pluck(t, d, root + 24 + a, spb * 1.5);
    }
    if (s.lead && T.leads[s.lead]) {
      const barPat = T.leads[s.lead][this.secBar % T.leads[s.lead].length];
      const n = barPat[st];
      if (n !== null) {
        let len = 1; while (st + len < 16 && barPat[st + len] === null && len < 6) len++;
        this.lead(t, d, T.lroot + n + (T.prog[this.bar % T.prog.length] === 0 ? 0 : 0), spb * len * 0.95);
      }
    }
  },
  f(m) { return 440 * Math.pow(2, (m - 69) / 12); },
  kick(t, d) {
    const o = AC.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(160, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.12);
    const g = AC.createGain(); g.gain.setValueAtTime(1.0, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.26);
    o.connect(g); g.connect(d); o.start(t); o.stop(t + 0.3);
  },
  snare(t, d) {
    const s = AC.createBufferSource(); s.buffer = noiseBuf;
    const f = AC.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1900; f.Q.value = 0.7;
    const g = AC.createGain(); g.gain.setValueAtTime(0.55, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
    s.connect(f); f.connect(g); g.connect(d); s.start(t, Math.random() * 0.5); s.stop(t + 0.2);
    const o = AC.createOscillator(); o.type = 'triangle'; o.frequency.setValueAtTime(200, t); o.frequency.exponentialRampToValueAtTime(120, t + 0.08);
    const g2 = AC.createGain(); g2.gain.setValueAtTime(0.35, t); g2.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    o.connect(g2); g2.connect(d); o.start(t); o.stop(t + 0.12);
  },
  hat(t, d, open) {
    const s = AC.createBufferSource(); s.buffer = noiseBuf;
    const f = AC.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 7000;
    const g = AC.createGain(); const dur = open ? 0.18 : 0.04;
    g.gain.setValueAtTime(open ? 0.18 : 0.14, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f); f.connect(g); g.connect(d); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.02);
  },
  bass(t, d, m, dur) {
    const o = AC.createOscillator(); o.type = 'sawtooth'; o.frequency.value = this.f(m);
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.Q.value = 6;
    f.frequency.setValueAtTime(1400, t); f.frequency.exponentialRampToValueAtTime(220, t + dur);
    const g = AC.createGain(); g.gain.setValueAtTime(0.42, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(f); f.connect(g); g.connect(d); o.start(t); o.stop(t + dur + 0.02);
  },
  pluck(t, d, m, dur) {
    const o = AC.createOscillator(); o.type = 'square'; o.frequency.value = this.f(m);
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 2200;
    const g = AC.createGain(); g.gain.setValueAtTime(0.07, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(f); f.connect(g); g.connect(d); o.start(t); o.stop(t + dur + 0.02);
  },
  lead(t, d, m, dur) {
    const g = AC.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.16, t + 0.01);
    g.gain.setValueAtTime(0.16, t + dur * 0.6); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 3200;
    f.connect(g); g.connect(d);
    for (const [type, det] of [['square', 0], ['sawtooth', 7]]) {
      const o = AC.createOscillator(); o.type = type; o.frequency.value = this.f(m); o.detune.value = det;
      const lfo = AC.createOscillator(); lfo.frequency.value = 5.5;
      const lg = AC.createGain(); lg.gain.value = 6; lfo.connect(lg); lg.connect(o.detune);
      o.connect(f); o.start(t); o.stop(t + dur + 0.02); lfo.start(t); lfo.stop(t + dur + 0.02);
    }
  },
};
function jingle(kind) {
  if (!AC) return;
  const seqs = {
    clear: [[523, 0.1], [659, 0.1], [784, 0.1], [1047, 0.3], [0, 0.08], [988, 0.12], [1047, 0.5]],
    over: [[392, 0.3], [370, 0.3], [349, 0.3], [330, 0.9]],
    start: [[330, 0.08], [440, 0.08], [554, 0.08], [659, 0.3]],
  }[kind];
  let t = 0;
  for (const [f, d] of seqs) { if (f) { tone('square', f, f, d, 0.16, t); tone('sawtooth', f / 2, f / 2, d, 0.1, t, null, 1200); } t += d; }
}
