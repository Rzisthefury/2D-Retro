// ============================================================ STAGE / BACKGROUNDS / HUD
function mulberry(a) { return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
// Background layers are authored in logical units but backed by a PX-times larger
// bitmap, so every path, gradient and arc in the painters below gains real detail
// for free. `width`/`height` are shadowed to report the logical size the painters
// expect; bgDraw() supplies the logical destination size when blitting.
function mkCanvas(w, h) {
  const c = document.createElement('canvas');
  c.width = Math.ceil(w * PX); c.height = Math.ceil(h * PX);
  const g = c.getContext('2d');
  g.setTransform(PX, 0, 0, PX, 0, 0);
  g.imageSmoothingEnabled = false;
  g.lineCap = 'round'; g.lineJoin = 'round';
  Object.defineProperty(c, 'width', { value: w, configurable: true });
  Object.defineProperty(c, 'height', { value: h, configurable: true });
  return c;
}
function bgDraw(c, x, y) { ctx.drawImage(c, x, y, c.width, c.height); }
const BG_CACHE = {};
const NEON = ['PAWN', 'DINER', 'BAR', 'HOTEL', 'ARCADE', '24H', 'LIQUOR', 'PIZZA', 'GYM', 'CLUB'];

function buildBackground(kind, len) {
  const key = kind + len;
  if (BG_CACHE[key]) return BG_CACHE[key];
  const R = mulberry(kind.length * 7919 + len);
  const r = (a, b) => a + R() * (b - a);
  const L = { far: mkCanvas(Math.ceil(W + len * 0.25) + 20, H), mid: mkCanvas(Math.ceil(W + len * 0.55) + 20, H), near: mkCanvas(len + W, H) };
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  if (kind === 'gym') {
    const g = n;
    g.fillStyle = '#23202e'; g.fillRect(0, 0, L.near.width, H);
    for (let x = 0; x < L.near.width; x += 32) { g.fillStyle = x % 64 ? '#28243a' : '#2c2842'; g.fillRect(x, 0, 32, 140); }
    g.fillStyle = '#3a3450'; g.fillRect(0, 128, L.near.width, 12);
    g.fillStyle = '#6a4a2a'; g.fillRect(0, 140, L.near.width, 100);
    for (let y = 140; y < 240; y += 10) { g.fillStyle = '#5a3e22'; g.fillRect(0, y, L.near.width, 1); }
    for (let x = 0; x < L.near.width; x += 48) { g.fillStyle = '#5a3e22'; g.fillRect(x + (x / 48 % 2) * 24, 140, 1, 100); }
    g.fillStyle = '#8a8aa8'; g.fillRect(40, 30, 120, 70); g.fillStyle = '#b8c0d8'; g.fillRect(44, 34, 112, 62);
    g.fillStyle = 'rgba(255,255,255,0.25)'; g.fillRect(60, 34, 12, 62); g.fillRect(80, 34, 5, 62);
    g.fillStyle = '#8a1a2a'; g.fillRect(250, 26, 130, 26);
    L.label = 'TRAINING';
    f.fillStyle = '#000'; f.fillRect(0, 0, 1, 1);
    BG_CACHE[key] = L; return L;
  }
  if (kind === 'elevated') { elevatedBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'canyon') { canyonBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'found') { foundationBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'shed') { roundhouseBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'roadtun') { tunnelBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'cast') { castHouseBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'line') { assemblyLineBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'torpedo') { torpedoBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'corridor') { corridorBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'coldstore') { coldStoreBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'birth') { birthingBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'blackout') { blackoutBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'modelroom') { modelRoomBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'stormpad') { stormPadBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'dawnroad') { dawnRoadBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'bridge') { bridgeBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'glass') { glassBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'basement') { basementBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'roofs') { roofsBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'dance') { danceBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'site' || kind === 'deck') { siteBg(L, R, r, len, kind); BG_CACHE[key] = L; return L; }
  if (kind === 'yard') { yardBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'train') { trainBg(L, R, r, len); BG_CACHE[key] = L; return L; }
  if (kind === 'road' || kind === 'road2') { roadBg(L, R, r, len, kind); BG_CACHE[key] = L; return L; }
  if (kind === 'works' || kind === 'assembly' || kind === 'crucible') { worksBg(L, R, r, len, kind); BG_CACHE[key] = L; return L; }
  if (kind === 'lab' || kind === 'vault') { labBg(L, R, r, len, kind); BG_CACHE[key] = L; return L; }
  if (kind === 'atrium' || kind === 'roof') { towerBg(L, R, r, len, kind); BG_CACHE[key] = L; return L; }
  // ---- sky (far canvas)
  const sky = f.createLinearGradient(0, 0, 0, 140);
  if (kind === 'street' || kind === 'club') { sky.addColorStop(0, '#07051a'); sky.addColorStop(0.6, '#2a1242'); sky.addColorStop(1, '#6a2a52'); }
  else { sky.addColorStop(0, '#04040c'); sky.addColorStop(0.7, '#141432'); sky.addColorStop(1, '#2a2040'); }
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  for (let i = 0; i < 90; i++) { f.fillStyle = R() < 0.3 ? '#fff' : '#8a88b0'; f.fillRect(r(0, L.far.width), r(0, 70), 1, 1); }
  f.fillStyle = '#e8e2c8'; f.beginPath(); f.arc(300, 30, 12, 0, 7); f.fill();
  f.fillStyle = kind === 'street' || kind === 'club' ? '#2a1242' : '#141432'; f.beginPath(); f.arc(305, 27, 11, 0, 7); f.fill();
  for (let x = 0; x < L.far.width;) {
    const bw = r(18, 44), bh = r(40, 105);
    f.fillStyle = '#140f2a'; f.fillRect(x, 130 - bh, bw, bh + 20);
    for (let wy = 130 - bh + 4; wy < 128; wy += 6) for (let wx = x + 3; wx < x + bw - 3; wx += 5)
      if (R() < 0.22) { f.fillStyle = R() < 0.7 ? '#e8c860' : '#80c0e8'; f.fillRect(wx, wy, 2, 2); }
    if (R() < 0.2) { f.fillStyle = '#e8283a'; f.fillRect(x + bw / 2, 130 - bh - 6, 1, 6); f.fillRect(x + bw / 2 - 1, 130 - bh - 7, 3, 2); }
    x += bw + r(0, 6);
  }
  // ---- mid
  for (let x = 0; x < L.mid.width;) {
    const bw = r(40, 80), bh = r(60, 120);
    const col = kind === 'street' || kind === 'club' ? '#241c40' : '#1c1a2c';
    m.fillStyle = col; m.fillRect(x, 136 - bh, bw, bh + 10);
    m.fillStyle = '#2e2650'; m.fillRect(x, 136 - bh, bw, 3);
    for (let wy = 136 - bh + 8; wy < 128; wy += 11) for (let wx = x + 5; wx < x + bw - 6; wx += 10) {
      m.fillStyle = R() < 0.3 ? '#d8b050' : '#141028'; m.fillRect(wx, wy, 5, 6);
    }
    if (R() < 0.35) {
      m.fillStyle = '#3a2a20'; m.fillRect(x + bw * 0.3, 136 - bh - 16, 16, 12);
      m.fillRect(x + bw * 0.3 + 2, 136 - bh - 4, 2, 4); m.fillRect(x + bw * 0.3 + 12, 136 - bh - 4, 2, 4);
    }
    x += bw + r(4, 20);
  }
  // ---- near
  if (kind === 'street' || kind === 'club') {
    streetNear(n, R, r, L, len);
    if (kind === 'club') clubNear(n, R, r, L, len);
  } else if (kind === 'alley') {
    const lotStart = len - 520;
    for (let x = 0; x < lotStart;) {
      const bw = r(110, 170);
      n.fillStyle = pick2(R, ['#3e1c20', '#321c24', '#2c2430']); n.fillRect(x, 0, bw, 150);
      n.fillStyle = 'rgba(0,0,0,0.22)';
      for (let by = 2; by < 148; by += 5) { n.fillRect(x, by, bw, 1); for (let bx = x + ((by / 5) % 2) * 6; bx < x + bw; bx += 12) n.fillRect(bx, by, 1, 5); }
      n.fillStyle = 'rgba(0,0,0,0.45)'; n.fillRect(x + bw - 4, 0, 4, 150);
      // pipes
      n.fillStyle = '#4a4e58'; n.fillRect(x + r(10, bw - 20), 0, 4, 150);
      n.fillStyle = '#5a6068'; n.fillRect(x, 60 + r(0, 20), bw, 3);
      // back door + light
      if (R() < 0.6) {
        const dx = x + r(20, bw - 40);
        n.fillStyle = '#16121c'; n.fillRect(dx - 2, 94, 26, 56);
        n.fillStyle = '#2a3a3a'; n.fillRect(dx, 96, 22, 54);
        n.fillStyle = '#f2e8a0'; n.fillRect(dx + 6, 84, 10, 4);
        n.fillStyle = 'rgba(242,232,160,0.10)'; n.beginPath(); n.moveTo(dx + 6, 88); n.lineTo(dx - 14, 150); n.lineTo(dx + 36, 150); n.lineTo(dx + 16, 88); n.fill();
      }
      // dumpster
      if (R() < 0.5) {
        const dx = x + r(10, bw - 60);
        n.fillStyle = '#120e14'; n.fillRect(dx, 120, 50, 30);
        n.fillStyle = '#2a5a3a'; n.fillRect(dx + 1, 122, 48, 27);
        n.fillStyle = '#1e4a2e'; n.fillRect(dx + 1, 122, 48, 4);
        n.fillStyle = '#e8e0d0'; n.fillRect(dx + 20, 132, 10, 4);
      }
      // ladder
      if (R() < 0.4) { const lx = x + r(10, bw - 20); n.fillStyle = '#16121c'; n.fillRect(lx, 10, 2, 100); n.fillRect(lx + 10, 10, 2, 100); for (let k = 12; k < 110; k += 8) n.fillRect(lx, k, 12, 1); }
      // tag
      n.strokeStyle = pick2(R, ['#e84a8a', '#4ae88a', '#e8e84a', '#8ab8ff', '#ff8a2a']); n.lineWidth = 3;
      n.beginPath(); let gx = x + r(10, bw - 50), gy = r(100, 130); n.moveTo(gx, gy);
      for (let k = 0; k < 7; k++) { gx += r(3, 8); n.lineTo(gx, gy + r(-8, 8)); } n.stroke();
      x += bw;
    }
    // parking lot (boss arena): fence and far city behind
    n.fillStyle = '#0c0a18'; n.fillRect(lotStart, 0, L.near.width - lotStart, 150);
    n.fillStyle = '#1a1630';
    for (let xx = lotStart; xx < L.near.width; xx += r(20, 40)) { const bh = r(30, 80); n.fillRect(xx, 110 - bh, r(16, 36), bh + 40); }
    for (let k = 0; k < 60; k++) { n.fillStyle = '#d8b050'; n.fillRect(r(lotStart, L.near.width), r(40, 110), 1, 1); }
    // flood lights
    for (let xx = lotStart + 60; xx < L.near.width; xx += 200) {
      n.fillStyle = '#16121c'; n.fillRect(xx, 20, 3, 130); n.fillRect(xx - 8, 18, 19, 5);
      n.fillStyle = '#fff8d0'; n.fillRect(xx - 7, 22, 17, 2);
      n.fillStyle = 'rgba(255,248,208,0.07)'; n.beginPath(); n.moveTo(xx - 7, 24); n.lineTo(xx - 60, 240); n.lineTo(xx + 64, 240); n.lineTo(xx + 10, 24); n.fill();
    }
    // chain-link fence
    n.strokeStyle = 'rgba(160,160,180,0.45)'; n.lineWidth = 1;
    for (let xx = lotStart; xx < L.near.width + 100; xx += 6) { n.beginPath(); n.moveTo(xx, 90); n.lineTo(xx + 50, 150); n.stroke(); n.beginPath(); n.moveTo(xx, 90); n.lineTo(xx - 50, 150); n.stroke(); }
    n.fillStyle = '#6a6a78'; n.fillRect(lotStart, 88, L.near.width - lotStart, 3);
    for (let xx = lotStart; xx < L.near.width; xx += 60) n.fillRect(xx, 88, 3, 62);
    // ground
    n.fillStyle = '#2e2a30'; n.fillRect(0, 148, lotStart, 92);
    for (let k = 0; k < 500; k++) { n.fillStyle = R() < 0.5 ? '#36323a' : '#26222a'; n.fillRect(r(0, lotStart), r(150, 240), 2, 1); }
    n.fillStyle = '#1e1a22'; n.fillRect(0, 148, lotStart, 3);
    n.fillStyle = '#34343c'; n.fillRect(lotStart, 148, L.near.width - lotStart, 92);
    n.fillStyle = '#e8e8e0'; for (let xx = lotStart + 30; xx < L.near.width; xx += 70) n.fillRect(xx, 160, 2, 70);
    // puddles
    for (let k = 0; k < 10; k++) { n.fillStyle = 'rgba(120,140,200,0.25)'; n.beginPath(); n.ellipse(r(0, L.near.width), r(170, 235), r(10, 22), r(2, 4), 0, 0, 7); n.fill(); }
  }
  BG_CACHE[key] = L;
  return L;
}
function streetNear(n, R, r, L, len) {
    for (let x = 0; x < L.near.width;) {
      const bw = r(90, 150);
      const wall = pick2(R, ['#5a2a2e', '#3a3448', '#4a3a2e', '#2e3a44', '#503040']);
      n.fillStyle = wall; n.fillRect(x, 10, bw, 132);
      // bricks
      n.fillStyle = 'rgba(0,0,0,0.18)';
      for (let by = 12; by < 140; by += 5) { n.fillRect(x, by, bw, 1); for (let bx = x + ((by / 5) % 2) * 6; bx < x + bw; bx += 12) n.fillRect(bx, by, 1, 5); }
      n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + bw - 3, 10, 3, 132);
      // upper windows
      for (let wx = x + 12; wx < x + bw - 20; wx += 30) {
        n.fillStyle = '#120e1c'; n.fillRect(wx, 22, 18, 26);
        n.fillStyle = R() < 0.4 ? '#e8c060' : '#262040'; n.fillRect(wx + 2, 24, 14, 22);
        n.fillStyle = '#120e1c'; n.fillRect(wx + 8, 24, 2, 22); n.fillRect(wx + 2, 34, 14, 1);
        n.fillStyle = '#7a7080'; n.fillRect(wx - 2, 48, 22, 2);
      }
      // fire escape
      if (R() < 0.45) {
        const fx = x + r(10, bw - 50);
        n.fillStyle = '#16121c';
        n.fillRect(fx, 52, 44, 2); n.fillRect(fx, 44, 1, 8); n.fillRect(fx + 43, 44, 1, 8);
        for (let k = 0; k < 44; k += 4) n.fillRect(fx + k, 44, 1, 8);
        n.fillRect(fx, 44, 44, 1);
      }
      // storefront
      const sx = x + 8, sw = bw - 16;
      n.fillStyle = '#16121c'; n.fillRect(sx, 70, sw, 72);
      n.fillStyle = '#2a3a5a'; n.fillRect(sx + 3, 84, sw * 0.55, 46);
      n.fillStyle = 'rgba(160,200,255,0.18)'; n.fillRect(sx + 5, 86, 6, 42); n.fillRect(sx + 14, 86, 3, 42);
      n.fillStyle = '#e8b860'; for (let k = 0; k < 3; k++) n.fillRect(sx + 20 + k * 12, 110 + k % 2 * 4, 6, 20 - k % 2 * 4);
      const dx = sx + sw * 0.62;
      n.fillStyle = '#3a2418'; n.fillRect(dx, 90, 22, 52); n.fillStyle = '#f2c94c'; n.fillRect(dx + 17, 116, 2, 2);
      // awning
      const aw = pick2(R, ['#b82a3a', '#2a7a5a', '#2a4a9a', '#c87a20']);
      for (let k = 0; k < sw; k += 8) { n.fillStyle = (k / 8) % 2 ? aw : '#e8e0d0'; n.fillRect(sx + k, 72, 8, 10); }
      n.fillStyle = 'rgba(0,0,0,0.3)'; n.fillRect(sx, 81, sw, 2);
      // neon sign
      const word = pick2(R, NEON), nc = pick2(R, ['#ff4a8a', '#4ae8ff', '#e8ff4a', '#ff8a2a', '#8a6aff']);
      const tw = word.length * 6 + 6;
      const nx = x + bw / 2 - tw / 2;
      n.fillStyle = '#0c0a12'; n.fillRect(nx, 56, tw, 12);
      n.save(); n.shadowColor = nc; n.shadowBlur = 6;
      const a = fontAtlas(nc);
      for (let i = 0; i < word.length; i++) n.drawImage(a, a.idx[word[i]] * 6, 0, 5, 7, nx + 3 + i * 6, 58, 5, 7);
      n.restore();
      // graffiti
      if (R() < 0.5) {
        n.strokeStyle = pick2(R, ['#e84a8a', '#4ae88a', '#e8e84a', '#8ab8ff']); n.lineWidth = 2;
        n.beginPath(); let gx = x + r(10, bw - 40), gy = 136;
        n.moveTo(gx, gy); for (let k = 0; k < 6; k++) { gx += r(3, 7); n.lineTo(gx, gy - r(0, 10)); }
        n.stroke();
      }
      x += bw;
    }
    // sidewalk
    n.fillStyle = '#5a5468'; n.fillRect(0, 140, L.near.width, 56);
    n.fillStyle = '#6a6478'; for (let y = 142; y < 194; y += 13) n.fillRect(0, y, L.near.width, 11);
    n.fillStyle = '#4a4458'; for (let xx = 0; xx < L.near.width; xx += 26) n.fillRect(xx + ((xx / 26) % 2) * 6, 140, 1, 56);
    n.fillStyle = '#3a3448'; n.fillRect(0, 140, L.near.width, 2);
    // lamp posts & hydrants belong to the near layer only as decoration
    for (let xx = 120; xx < L.near.width; xx += 260) {
      n.fillStyle = '#16121c'; n.fillRect(xx, 44, 4, 100); n.fillRect(xx - 2, 142, 8, 3);
      n.fillRect(xx - 12, 44, 16, 3); n.fillStyle = '#f2e8a0'; n.fillRect(xx - 12, 47, 8, 3);
      n.fillStyle = 'rgba(242,232,160,0.08)';
      n.beginPath(); n.moveTo(xx - 12, 50); n.lineTo(xx - 30, 145); n.lineTo(xx + 10, 145); n.lineTo(xx - 4, 50); n.fill();
    }
    // curb + road
    n.fillStyle = '#b8b0c0'; n.fillRect(0, 196, L.near.width, 3);
    n.fillStyle = '#8a8298'; n.fillRect(0, 199, L.near.width, 2);
    n.fillStyle = '#2a2834'; n.fillRect(0, 201, L.near.width, 39);
    for (let k = 0; k < 400; k++) { n.fillStyle = R() < 0.5 ? '#32303e' : '#24222e'; n.fillRect(r(0, L.near.width), r(202, 240), 2, 1); }
    n.fillStyle = '#e8c040'; for (let xx = 0; xx < L.near.width; xx += 40) n.fillRect(xx, 226, 22, 2);
}

function neonText(g, word, x, y, c, s = 1) {
  const a = fontAtlas(c);
  g.save(); g.shadowColor = c; g.shadowBlur = 8;
  for (let i = 0; i < word.length; i++) { const k = a.idx[word[i]]; if (k !== undefined) g.drawImage(a, k * 6, 0, 5, 7, x + i * 6 * s, y, 5 * s, 7 * s); }
  g.restore();
}
function clubNear(n, R, r, L, len) {
  // the club facade takes over a long stretch of the street
  const x0 = 520, w = 520;
  n.fillStyle = '#140c1c'; n.fillRect(x0, 0, w, 142);
  n.fillStyle = '#1e1228'; for (let y = 4; y < 140; y += 8) n.fillRect(x0, y, w, 1);
  // marquee
  n.fillStyle = '#0a0610'; n.fillRect(x0 + 60, 20, w - 120, 40);
  n.strokeStyle = '#ff2a8a'; n.lineWidth = 2; n.strokeRect(x0 + 62, 22, w - 124, 36);
  for (let k = x0 + 64; k < x0 + w - 64; k += 8) { n.fillStyle = (k / 8) % 2 ? '#ffe08a' : '#ff8ac8'; n.fillRect(k, 18, 3, 3); n.fillRect(k, 59, 3, 3); }
  neonText(n, 'CLUB VELVET', x0 + w / 2 - 99, 28, '#ff4ab0', 3);
  // doors + rope line
  n.fillStyle = '#2a0a1a'; n.fillRect(x0 + w / 2 - 30, 80, 60, 62);
  n.fillStyle = '#e8c860'; n.fillRect(x0 + w / 2 - 1, 104, 2, 12);
  n.fillStyle = '#6a1030'; n.fillRect(x0 + w / 2 - 34, 76, 68, 4);
  for (const px_ of [x0 + 150, x0 + 190, x0 + w - 190, x0 + w - 150]) { n.fillStyle = '#c8a040'; n.fillRect(px_, 120, 3, 22); n.fillRect(px_ - 2, 118, 7, 3); }
  n.strokeStyle = '#a01838'; n.lineWidth = 2;
  n.beginPath(); n.moveTo(x0 + 152, 124); n.quadraticCurveTo(x0 + 172, 134, x0 + 192, 124); n.stroke();
  n.beginPath(); n.moveTo(x0 + w - 188, 124); n.quadraticCurveTo(x0 + w - 168, 134, x0 + w - 148, 124); n.stroke();
  // neon tubes and posters
  for (let k = 0; k < 4; k++) {
    const px_ = x0 + 40 + k * 130;
    n.fillStyle = '#1a0e24'; n.fillRect(px_, 70, 34, 46);
    n.fillStyle = pick2(R, ['#ff4ab0', '#4ae8ff', '#e8ff4a', '#8a6aff']); n.fillRect(px_ + 3, 73, 28, 3); n.fillRect(px_ + 14, 80, 6, 30);
  }
  neonText(n, 'LIVE DJ', x0 + 30, 126, '#4ae8ff', 1);
  neonText(n, 'VIP', x0 + w - 60, 126, '#ffe04a', 1);
}
function danceBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0a0612'; f.fillRect(0, 0, L.far.width, H);
  // light beams in the haze
  for (let k = 0; k < 14; k++) {
    const x = r(0, L.far.width), c = pick2(R, ['rgba(255,42,138,0.10)', 'rgba(42,216,255,0.10)', 'rgba(255,224,42,0.08)']);
    f.fillStyle = c; f.beginPath(); f.moveTo(x, 0); f.lineTo(x - 40, 150); f.lineTo(x + 20, 150); f.lineTo(x + 6, 0); f.fill();
  }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 60) { m.fillStyle = '#140c20'; m.fillRect(x, 0, 6, 150); }
  // near: back wall
  n.fillStyle = '#160e22'; n.fillRect(0, 0, L.near.width, 150);
  n.fillStyle = '#1e1430'; for (let y = 0; y < 150; y += 10) n.fillRect(0, y, L.near.width, 1);
  for (let x = 0; x < L.near.width; x += 110) {
    const c = pick2(R, ['#ff2a8a', '#2ad8ff', '#ffe02a', '#8a2aff']);
    n.save(); n.shadowColor = c; n.shadowBlur = 8; n.fillStyle = c;
    n.fillRect(x + 10, 30, 70, 2); n.fillRect(x + 10, 30, 2, 40); n.fillRect(x + 20, 50, 60, 2);
    n.restore();
  }
  // speaker stacks, bar, DJ booth
  for (let x = 90; x < len - 400; x += 300) {
    for (let k = 0; k < 3; k++) {
      n.fillStyle = '#0a0a0e'; n.fillRect(x, 80 + k * 23, 34, 22);
      n.fillStyle = '#26262e'; n.beginPath(); n.arc(x + 17, 91 + k * 23, 8, 0, 7); n.fill();
      n.fillStyle = '#0e0e12'; n.beginPath(); n.arc(x + 17, 91 + k * 23, 4, 0, 7); n.fill();
    }
  }
  const barX = 360;
  n.fillStyle = '#2a1a1a'; n.fillRect(barX, 110, 160, 40);
  n.fillStyle = '#6a3a2a'; n.fillRect(barX, 108, 160, 4);
  n.fillStyle = '#10080e'; n.fillRect(barX, 50, 160, 50);
  for (let k = 0; k < 16; k++) { n.fillStyle = pick2(R, ['#3a8a3a', '#8a3a2a', '#c8c060', '#6a8ab8']); n.fillRect(barX + 6 + k * 9, 62 + (k % 2) * 16, 4, 12); }
  neonText(n, 'BAR', barX + 70, 40, '#ffe04a', 1);
  // DJ booth
  const djX = len - 700;
  n.fillStyle = '#0a0610'; n.fillRect(djX, 70, 120, 80);
  n.fillStyle = '#2a1a3a'; n.fillRect(djX, 70, 120, 6);
  n.fillStyle = '#1a1a22'; n.beginPath(); n.arc(djX + 30, 86, 12, 0, 7); n.arc(djX + 90, 86, 12, 0, 7); n.fill();
  neonText(n, 'DJ', djX + 54, 110, '#2ad8ff', 1);
  // VIP stage (boss arena)
  const vx = len - 420;
  n.fillStyle = '#300814'; n.fillRect(vx, 0, L.near.width - vx, 150);
  for (let x = vx; x < L.near.width; x += 14) { n.fillStyle = (x / 14) % 2 ? '#5a0c20' : '#420a18'; n.fillRect(x, 0, 14, 130); }
  n.fillStyle = '#e8c860'; n.fillRect(vx, 128, L.near.width - vx, 4);
  neonText(n, 'VIP LOUNGE', vx + 150, 20, '#ffe04a', 2);
  // disco ball
  const bx = vx + 210;
  n.fillStyle = '#6a6a78'; n.fillRect(bx, 0, 1, 34);
  for (let yy = -10; yy <= 10; yy += 3) for (let xx = -10; xx <= 10; xx += 3)
    if (xx * xx + yy * yy <= 110) { n.fillStyle = pick2(R, ['#e8e8f0', '#9a9ab0', '#c8c8e0', '#ffffff']); n.fillRect(bx + xx, 44 + yy, 2, 2); }
  // floor base (tiles are drawn live)
  n.fillStyle = '#0c0814'; n.fillRect(0, 150, L.near.width, 90);
}
function siteBg(L, R, r, len, kind) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const deck = kind === 'deck';
  const sky = f.createLinearGradient(0, 0, 0, 160);
  if (deck) { sky.addColorStop(0, '#1a1440'); sky.addColorStop(0.5, '#6a3a6a'); sky.addColorStop(1, '#e88a5a'); }
  else { sky.addColorStop(0, '#2a1a3a'); sky.addColorStop(0.6, '#a8506a'); sky.addColorStop(1, '#f0a060'); }
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  f.fillStyle = '#ffe0a0'; f.beginPath(); f.arc(330, deck ? 118 : 96, 16, 0, 7); f.fill();
  for (let k = 0; k < 8; k++) { f.fillStyle = 'rgba(255,220,200,0.18)'; f.fillRect(r(0, L.far.width), r(20, 90), r(40, 90), 3); }
  if (deck) {
    // the city far below
    f.fillStyle = '#2a1a3a'; f.fillRect(0, 150, L.far.width, 90);
    for (let k = 0; k < 400; k++) { f.fillStyle = pick2(R, ['#ffe08a', '#ff8a5a', '#8ad8ff']); f.fillRect(r(0, L.far.width), r(152, 240), 1, 1); }
    for (let x = 0; x < L.far.width; x += r(30, 70)) { f.fillStyle = '#3a2a4a'; const h = r(10, 40); f.fillRect(x, 150 - h, r(12, 24), h); }
  } else {
    for (let x = 0; x < L.far.width;) { const bw = r(20, 50), bh = r(30, 90); f.fillStyle = '#4a2a4a'; f.fillRect(x, 140 - bh, bw, bh + 10); x += bw + r(0, 8); }
    // cranes
    for (let x = 60; x < L.far.width; x += 260) {
      f.fillStyle = '#3a1a2a'; f.fillRect(x, 20, 4, 120); f.fillRect(x - 40, 20, 120, 3);
      f.fillRect(x + 70, 23, 1, 30); f.fillRect(x - 36, 23, 10, 8);
    }
  }
  // mid: steel skeletons
  for (let x = 0; x < L.mid.width; x += deck ? 180 : 140) {
    const h = deck ? r(30, 60) : r(60, 110);
    m.strokeStyle = deck ? '#4a2a3a' : '#5a2a2a'; m.lineWidth = 2;
    for (let yy = 150; yy > 150 - h; yy -= 16) { m.beginPath(); m.moveTo(x, yy); m.lineTo(x + 60, yy); m.stroke(); }
    m.beginPath(); m.moveTo(x, 150); m.lineTo(x, 150 - h); m.moveTo(x + 60, 150); m.lineTo(x + 60, 150 - h); m.stroke();
    for (let yy = 150; yy > 166 - h; yy -= 16) { m.beginPath(); m.moveTo(x, yy); m.lineTo(x + 60, yy - 16); m.stroke(); }
  }
  // near
  const girder = (x0, y0, x1, y1, w) => {
    n.strokeStyle = '#6a2a1a'; n.lineWidth = w + 2; n.beginPath(); n.moveTo(x0, y0); n.lineTo(x1, y1); n.stroke();
    n.strokeStyle = '#b8582a'; n.lineWidth = w; n.stroke();
    n.strokeStyle = '#d8804a'; n.lineWidth = 1; n.beginPath(); n.moveTo(x0, y0 - w / 2 + 1); n.lineTo(x1, y1 - w / 2 + 1); n.stroke();
  };
  if (deck) {
    for (let x = 60; x < L.near.width; x += 170) {
      girder(x, 0, x, 150, 10);
      for (let yy = 10; yy < 150; yy += 30) { n.fillStyle = '#e8a070'; n.fillRect(x - 2, yy, 4, 2); }
    }
    girder(0, 8, L.near.width, 8, 10);
    // railing
    n.fillStyle = '#e8b020'; n.fillRect(0, 128, L.near.width, 3); n.fillRect(0, 140, L.near.width, 2);
    for (let x = 0; x < L.near.width; x += 24) n.fillRect(x, 128, 2, 14);
    // crane hook
    for (let x = 400; x < L.near.width; x += 500) {
      n.fillStyle = '#2a2a30'; n.fillRect(x, 0, 2, 70);
      n.fillStyle = '#e8b020'; n.fillRect(x - 8, 70, 18, 10);
      n.strokeStyle = '#8a8a90'; n.lineWidth = 3; n.beginPath(); n.arc(x + 1, 88, 6, -0.5, Math.PI + 0.3); n.stroke();
    }
    n.fillStyle = '#4c4e58'; n.fillRect(0, 142, L.near.width, 98);
    n.fillStyle = '#5a5c68'; for (let y = 146; y < 240; y += 16) n.fillRect(0, y, L.near.width, 1);
    for (let x = 0; x < L.near.width; x += 32) { n.fillStyle = '#3a3c46'; n.fillRect(x, 142, 1, 98); }
    for (let k = 0; k < 300; k++) { n.fillStyle = '#6a6c78'; n.fillRect(r(0, L.near.width), r(144, 240), 1, 1); }
    n.fillStyle = '#e8b020'; n.fillRect(0, 142, L.near.width, 2);
  } else {
    // fence with tarp
    n.fillStyle = '#2a2430'; n.fillRect(0, 60, L.near.width, 82);
    n.strokeStyle = 'rgba(180,180,190,0.35)'; n.lineWidth = 1;
    for (let x = 0; x < L.near.width + 80; x += 7) { n.beginPath(); n.moveTo(x, 60); n.lineTo(x + 70, 140); n.stroke(); n.beginPath(); n.moveTo(x, 60); n.lineTo(x - 70, 140); n.stroke(); }
    for (let x = 0; x < L.near.width; x += 120) { n.fillStyle = '#7a7a86'; n.fillRect(x, 56, 3, 86); }
    for (let x = 30; x < L.near.width; x += 360) {
      n.fillStyle = '#2a5a3a'; n.fillRect(x, 70, 140, 50);
      neonText(n, 'SYNDICATE', x + 16, 80, '#e8e8e0', 1);
      neonText(n, 'DEVELOPMENTS', x + 16, 92, '#e8b020', 1);
    }
    // girder stacks, containers, mixer, signs
    for (let x = 200; x < L.near.width; x += 290) {
      const kind2 = Math.floor(R() * 3);
      if (kind2 === 0) { for (let k = 0; k < 4; k++) girder(x, 138 - k * 7, x + 90, 138 - k * 7, 5); }
      else if (kind2 === 1) {
        n.fillStyle = pick2(R, ['#2a6a8a', '#8a3a2a', '#3a7a3a']); n.fillRect(x, 86, 120, 56);
        for (let k = x + 4; k < x + 120; k += 8) { n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(k, 88, 2, 52); }
      } else {
        n.fillStyle = '#d8d0c0'; n.beginPath(); n.ellipse(x + 40, 108, 30, 20, -0.3, 0, 7); n.fill();
        n.fillStyle = '#e87a20'; n.fillRect(x + 10, 120, 70, 20);
        n.fillStyle = '#1a1a1e'; n.beginPath(); n.arc(x + 20, 140, 6, 0, 7); n.arc(x + 70, 140, 6, 0, 7); n.fill();
      }
      n.fillStyle = '#e8d020'; n.beginPath(); n.moveTo(x + 150, 100); n.lineTo(x + 162, 120); n.lineTo(x + 138, 120); n.fill();
      n.fillStyle = '#1a1a1a'; n.fillRect(x + 149, 106, 2, 8); n.fillRect(x + 149, 116, 2, 2);
    }
    // dirt ground
    n.fillStyle = '#6a4a34'; n.fillRect(0, 142, L.near.width, 98);
    for (let k = 0; k < 700; k++) { n.fillStyle = pick2(R, ['#7a5a40', '#5a3e2a', '#8a6a4a']); n.fillRect(r(0, L.near.width), r(144, 240), 2, 1); }
    n.fillStyle = 'rgba(40,24,16,0.35)'; for (let x = 0; x < L.near.width; x += 12) { n.fillRect(x, 200, 8, 3); n.fillRect(x + 4, 222, 8, 3); }
    n.fillStyle = '#4a3424'; n.fillRect(0, 142, L.near.width, 3);
    for (let x = 80; x < L.near.width; x += 230) { n.fillStyle = '#e87a20'; n.beginPath(); n.moveTo(x, 160); n.lineTo(x + 5, 146); n.lineTo(x + 10, 160); n.fill(); n.fillStyle = '#fff'; n.fillRect(x + 3, 152, 4, 2); }
  }
}
// ------------------------------------------------------------ stage 4-8 backgrounds
function nightSky(f, L, R, r, a, b, c) {
  const sky = f.createLinearGradient(0, 0, 0, 150);
  sky.addColorStop(0, a); sky.addColorStop(0.7, b); sky.addColorStop(1, c);
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  for (let i = 0; i < 80; i++) { f.fillStyle = R() < 0.3 ? '#fff' : '#8a88b0'; f.fillRect(r(0, L.far.width), r(0, 80), 1, 1); }
}
function farSkyline(f, L, R, r, base, col, lit) {
  for (let x = 0; x < L.far.width;) {
    const bw = r(20, 52), bh = r(28, 84);
    f.fillStyle = col; f.fillRect(x, base - bh, bw, bh + 24);
    for (let wy = base - bh + 4; wy < base - 2; wy += 7) for (let wx = x + 3; wx < x + bw - 3; wx += 6)
      if (R() < 0.18) { f.fillStyle = lit; f.fillRect(wx, wy, 2, 2); }
    x += bw + r(2, 10);
  }
}
function gravelFloor(n, L, R, r, top, a, b, c) {
  n.fillStyle = a; n.fillRect(0, top, L.near.width, 240 - top);
  for (let k = 0; k < L.near.width * 0.9; k++) { n.fillStyle = R() < 0.5 ? b : c; n.fillRect(r(0, L.near.width), r(top + 2, 238), 2, 1); }
  n.fillStyle = c; n.fillRect(0, top, L.near.width, 2);
}
// ---- STAGE 4a: rail yard
function yardBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  nightSky(f, L, R, r, '#05040f', '#141030', '#3a2048');
  farSkyline(f, L, R, r, 132, '#100c22', '#d8b050');
  // mid: flood gantries
  for (let x = 0; x < L.mid.width; x += 160) {
    m.fillStyle = '#181428'; m.fillRect(x + 20, 54, 4, 96); m.fillRect(x + 84, 54, 4, 96); m.fillRect(x + 20, 52, 68, 5);
    m.fillStyle = '#fff8d0'; m.fillRect(x + 30, 58, 7, 3); m.fillRect(x + 70, 58, 7, 3);
    m.fillStyle = 'rgba(255,248,208,0.07)';
    m.beginPath(); m.moveTo(x + 30, 61); m.lineTo(x - 14, 150); m.lineTo(x + 84, 150); m.lineTo(x + 77, 61); m.fill();
  }
  // near: parked freight cars along the back
  for (let x = -40; x < L.near.width; x += r(150, 230)) {
    const cw = r(110, 170), ch = 62, top = 148 - ch;
    const body = pick2(R, ['#5a2a24', '#2a4a34', '#3a3a52', '#5a4a24']);
    n.fillStyle = '#0c0a12'; n.fillRect(x - 2, top - 2, cw + 4, ch + 8);
    n.fillStyle = body; n.fillRect(x, top, cw, ch);
    n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(x, top, cw, 4);
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, top + ch - 8, cw, 8);
    for (let k = x + 6; k < x + cw - 4; k += 11) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(k, top + 4, 1, ch - 12); }
    n.fillStyle = '#e8e0c8'; n.fillRect(x + cw * 0.3, top + 20, 30, 10);
    n.fillStyle = body; n.fillRect(x + cw * 0.3 + 2, top + 22, 26, 6);
    // trucks
    n.fillStyle = '#16141a'; n.fillRect(x + 10, 148, cw - 20, 8);
    for (const wx of [x + 22, x + cw - 30]) { n.fillStyle = '#26242c'; n.beginPath(); n.arc(wx, 153, 5, 0, 7); n.fill(); }
    // graffiti
    n.strokeStyle = pick2(R, ['#e84a8a', '#4ae88a', '#e8e84a', '#8ab8ff']); n.lineWidth = 3;
    n.beginPath(); let gx = x + r(14, cw - 60), gy = top + r(28, 48); n.moveTo(gx, gy);
    for (let k = 0; k < 6; k++) { gx += r(4, 9); n.lineTo(gx, gy + r(-7, 7)); } n.stroke();
  }
  gravelFloor(n, L, R, r, 148, '#2c2a30', '#3a3840', '#201e26');
  // rails running the length
  for (const ry of [170, 206]) {
    n.fillStyle = '#3a3028';
    for (let x = 0; x < L.near.width; x += 22) n.fillRect(x, ry - 3, 16, 7);
    n.fillStyle = '#8a8a96'; n.fillRect(0, ry - 4, L.near.width, 2); n.fillRect(0, ry + 4, L.near.width, 2);
    n.fillStyle = '#c8c8d4'; n.fillRect(0, ry - 4, L.near.width, 1);
  }
  // signal posts
  for (let x = 220; x < L.near.width - 200; x += 420) {
    n.fillStyle = '#16141c'; n.fillRect(x, 70, 4, 100); n.fillRect(x - 5, 64, 14, 22);
    const on = R() < 0.5;
    n.fillStyle = on ? '#3ae05a' : '#e02a3a'; n.beginPath(); n.arc(x + 2, 72, 3.4, 0, 7); n.fill();
  }
  // the waiting train at the far end (boss arena lead-in)
  const tx = len - 300;
  n.fillStyle = '#0e0c14'; n.fillRect(tx, 40, L.near.width - tx, 108);
  n.fillStyle = '#3a3a4a'; n.fillRect(tx + 10, 52, L.near.width - tx, 96);
  n.fillStyle = '#f2c020'; n.fillRect(tx + 10, 52, L.near.width - tx, 4);
  for (let k = tx + 24; k < L.near.width; k += 40) { n.fillStyle = '#1a2a3a'; n.fillRect(k, 70, 26, 22); n.fillStyle = '#6a9ac8'; n.fillRect(k + 2, 72, 22, 18); }
}
// ---- STAGE 4b: on the train roof (scrolling)
function trainBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  nightSky(f, L, R, r, '#04030c', '#100c28', '#2e1a40');
  farSkyline(f, L, R, r, 150, '#0c0a1c', '#c8a048');
  L.speed = 1;
  // mid: poles and wires whipping past
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 74) {
    m.fillStyle = '#100e1a'; m.fillRect(x, 20, 5, 130);
    m.fillRect(x - 10, 24, 25, 3);
    m.strokeStyle = 'rgba(20,18,30,0.9)'; m.lineWidth = 1;
    m.beginPath(); m.moveTo(x, 28); m.quadraticCurveTo(x + 37, 44, x + 74, 28); m.stroke();
    m.beginPath(); m.moveTo(x, 34); m.quadraticCurveTo(x + 37, 52, x + 74, 34); m.stroke();
  }
  // near: only the embankment rushing past, so the sky and skyline stay visible
  n.fillStyle = '#0a0818'; n.fillRect(0, 112, L.near.width, 38);
  for (let k = 0; k < 600; k++) { n.fillStyle = R() < 0.5 ? '#1c1a30' : '#12101f'; n.fillRect(r(0, L.near.width), r(114, 148), r(14, 44), 2); }
  for (let x = 0; x < L.near.width; x += 130) { n.fillStyle = '#241f38'; n.fillRect(x, 104, 44, 46); n.fillStyle = '#2e2846'; n.fillRect(x, 104, 44, 2); }
  n.fillStyle = '#1a2030'; n.fillRect(0, 144, L.near.width, 8);
  // roof plates
  n.fillStyle = '#39414e'; n.fillRect(0, 150, L.near.width, 90);
  n.fillStyle = '#2b323d'; n.fillRect(0, 150, L.near.width, 4);
  n.fillStyle = '#48525f'; n.fillRect(0, 232, L.near.width, 8);
  for (let x = 0; x < L.near.width; x += 64) {
    n.fillStyle = '#242a34'; n.fillRect(x, 150, 2, 90);
    n.fillStyle = '#525d6c'; n.fillRect(x + 2, 150, 1, 90);
  }
  for (let y = 162; y < 232; y += 18) { n.fillStyle = 'rgba(0,0,0,0.14)'; n.fillRect(0, y, L.near.width, 2); }
  // rivets, vents, hatches
  for (let x = 16; x < L.near.width; x += 32) for (let y = 156; y < 236; y += 24) { n.fillStyle = '#6a7484'; n.fillRect(x, y, 2, 2); n.fillStyle = '#20262e'; n.fillRect(x, y + 2, 2, 1); }
  for (let x = 120; x < L.near.width; x += 260) {
    n.fillStyle = '#1c222a'; n.fillRect(x, 186, 30, 18);
    n.fillStyle = '#39414e'; n.fillRect(x + 2, 188, 26, 14);
    n.fillStyle = '#5a6472'; for (let k = 0; k < 4; k++) n.fillRect(x + 4, 190 + k * 3, 22, 1);
  }
  for (let x = 240; x < L.near.width; x += 340) {
    n.fillStyle = '#242c36'; n.beginPath(); n.ellipse(x, 214, 16, 6, 0, 0, 7); n.fill();
    n.fillStyle = '#4a5462'; n.beginPath(); n.ellipse(x, 212, 15, 5, 0, 0, 7); n.fill();
    n.fillStyle = '#20262e'; n.fillRect(x - 2, 206, 4, 4);
  }
}
// ---- STAGE 5: the highway (scrolling)
function roadBg(L, R, r, len, kind) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const dawn = kind === 'road2';
  if (dawn) { const sky = f.createLinearGradient(0, 0, 0, 150); sky.addColorStop(0, '#1a1440'); sky.addColorStop(0.55, '#8a3a6a'); sky.addColorStop(1, '#f0a050'); f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H); }
  else nightSky(f, L, R, r, '#06040e', '#181038', '#4a2050');
  farSkyline(f, L, R, r, 128, dawn ? '#3a2044' : '#0e0a20', dawn ? '#ffd890' : '#d8b050');
  L.speed = 1.6;
  // mid: sound walls and lamp posts
  for (let x = 0; x < L.mid.width; x += 46) {
    m.fillStyle = x % 92 ? '#221c34' : '#1c1730'; m.fillRect(x, 96, 46, 54);
    m.fillStyle = 'rgba(255,255,255,0.05)'; m.fillRect(x, 96, 46, 2);
  }
  for (let x = 0; x < L.mid.width; x += 184) {
    m.fillStyle = '#14101e'; m.fillRect(x, 26, 4, 74); m.fillRect(x, 26, 22, 4);
    m.fillStyle = '#ffe8a0'; m.fillRect(x + 16, 30, 8, 3);
    m.fillStyle = 'rgba(255,232,160,0.09)'; m.beginPath(); m.moveTo(x + 16, 33); m.lineTo(x - 20, 150); m.lineTo(x + 60, 150); m.lineTo(x + 24, 33); m.fill();
  }
  // near: guardrail then asphalt (the wall behind it stays visible)
  n.fillStyle = dawn ? '#2e2036' : '#0e0c18'; n.fillRect(0, 130, L.near.width, 18);
  n.fillStyle = '#8a8e9a'; n.fillRect(0, 128, L.near.width, 6);
  n.fillStyle = '#c8ccd8'; n.fillRect(0, 128, L.near.width, 2);
  n.fillStyle = '#3a3e48'; n.fillRect(0, 134, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 34) { n.fillStyle = '#4a4e5a'; n.fillRect(x, 134, 4, 14); }
  n.fillStyle = '#26262c'; n.fillRect(0, 146, L.near.width, 94);
  for (let k = 0; k < L.near.width * 1.2; k++) { n.fillStyle = R() < 0.5 ? '#2c2c34' : '#202026'; n.fillRect(r(0, L.near.width), r(148, 238), 3, 1); }
  n.fillStyle = '#3a3a44'; n.fillRect(0, 146, L.near.width, 2);
  // lane markings
  for (const ly of [176, 212]) for (let x = 0; x < L.near.width; x += 54) { n.fillStyle = '#e8e4c8'; n.fillRect(x, ly, 28, 3); }
  n.fillStyle = '#e8c020'; n.fillRect(0, 236, L.near.width, 3);
  // overpasses
  for (let x = 400; x < L.near.width - 300; x += 900) {
    n.fillStyle = '#0a0812'; n.fillRect(x, 0, 90, 92);
    n.fillStyle = '#2e2a3a'; n.fillRect(x - 10, 62, 110, 22);
    n.fillStyle = '#403a4e'; n.fillRect(x - 10, 62, 110, 4);
    n.fillStyle = '#1a1624'; n.fillRect(x + 10, 84, 16, 44); n.fillRect(x + 62, 84, 16, 44);
  }
}
// ---- STAGE 6: the foundry
function worksBg(L, R, r, len, kind) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const asm = kind === 'assembly';
  f.fillStyle = asm ? '#0c0e16' : '#1a0c0a'; f.fillRect(0, 0, L.far.width, H);
  // far: furnace glow / cold hall
  for (let x = 0; x < L.far.width; x += 120) {
    const g = f.createLinearGradient(0, 0, 0, 150);
    if (asm) { g.addColorStop(0, '#12161f'); g.addColorStop(1, '#1c2430'); }
    else { g.addColorStop(0, '#2a1008'); g.addColorStop(0.7, '#6a2008'); g.addColorStop(1, '#e06a10'); }
    f.fillStyle = g; f.fillRect(x, 40, 100, 110);
    f.fillStyle = asm ? '#080a10' : '#140804'; f.fillRect(x + 100, 0, 20, 150);
  }
  // mid: gantry crane and pipes
  for (let x = 0; x < L.mid.width; x += 210) {
    m.fillStyle = '#1e1a22'; m.fillRect(x, 30, 8, 120); m.fillRect(x + 150, 30, 8, 120);
    m.fillStyle = '#2e2832'; m.fillRect(x - 10, 24, 180, 10);
    m.fillStyle = '#4a4250'; m.fillRect(x - 10, 24, 180, 2);
    m.fillStyle = '#1e1a22'; m.fillRect(x + 66, 34, 26, 20);
    m.fillStyle = '#c8a020'; m.fillRect(x + 70, 38, 18, 4);
    m.fillStyle = '#3a3440'; m.fillRect(x + 78, 54, 2, 40);
    m.fillStyle = '#5a5060'; m.fillRect(x + 68, 94, 22, 12);
  }
  for (let y = 0; y < 60; y += 18) { m.fillStyle = '#2a242e'; m.fillRect(0, y, L.mid.width, 6); m.fillStyle = '#3e3644'; m.fillRect(0, y, L.mid.width, 1); }
  // near: pillars and a low wall, with the furnace hall open between them
  n.fillStyle = asm ? '#161a24' : '#2a1812'; n.fillRect(0, 108, L.near.width, 42);
  n.fillStyle = asm ? '#222a38' : '#3a2018'; n.fillRect(0, 108, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 170) {
    n.fillStyle = asm ? '#1c2230' : '#2e1c14'; n.fillRect(x, 0, 40, 150);
    n.fillStyle = asm ? '#2a3546' : '#40261c'; n.fillRect(x + 3, 0, 10, 150);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 36, 0, 5, 150);
    n.fillStyle = asm ? '#3a4658' : '#5a3424'; n.fillRect(x - 4, 60, 48, 5);
    n.fillStyle = asm ? '#2ad0f0' : '#ff8a10'; n.fillRect(x + 12, 26, 16, 4);
    n.fillStyle = asm ? 'rgba(42,208,240,0.10)' : 'rgba(255,138,16,0.12)';
    n.beginPath(); n.moveTo(x + 12, 30); n.lineTo(x - 18, 150); n.lineTo(x + 58, 150); n.lineTo(x + 28, 30); n.fill();
  }
  if (asm) {
    // conveyor and robot arms along the back
    for (let x = 0; x < L.near.width; x += 150) {
      n.fillStyle = '#2e3a4a'; n.fillRect(x, 96, 140, 12);
      n.fillStyle = '#48586c'; n.fillRect(x, 96, 140, 2);
      for (let k = 0; k < 14; k++) { n.fillStyle = '#1a222c'; n.fillRect(x + k * 10, 98, 4, 8); }
      // ceiling-mounted arm
      n.fillStyle = '#2a3442'; n.fillRect(x + 48, 30, 10, 30);
      n.fillStyle = '#3e4c5e'; n.fillRect(x + 44, 56, 18, 10);
      n.save(); n.translate(x + 53, 64); n.rotate(0.6 + (x % 3) * 0.3);
      n.fillStyle = '#4a5a6e'; n.fillRect(-3, 0, 6, 30);
      n.fillStyle = '#2ad0f0'; n.fillRect(-2, 26, 4, 5);
      n.restore();
      n.fillStyle = '#6a7a8e'; n.fillRect(x + 20, 88, 24, 10);
      n.fillStyle = '#2a3442'; n.fillRect(x + 20, 88, 24, 2);
    }
  } else {
    // molten channel + ladles
    for (let x = 50; x < L.near.width; x += 170) {
      n.fillStyle = '#1a0e0a'; n.fillRect(x, 96, 110, 16);
      const g2 = n.createLinearGradient(0, 96, 0, 112);
      g2.addColorStop(0, '#ffe070'); g2.addColorStop(0.5, '#ff8a10'); g2.addColorStop(1, '#c02a08');
      n.fillStyle = g2; n.fillRect(x + 3, 99, 104, 10);
      n.fillStyle = 'rgba(255,170,40,0.14)'; n.fillRect(x - 10, 60, 130, 40);
    }
    for (let x = 120; x < L.near.width; x += 340) {
      n.fillStyle = '#2e2028'; n.fillRect(x, 40, 44, 40);
      n.fillStyle = '#4a3a3a'; n.fillRect(x, 40, 44, 4);
      n.fillStyle = '#ffb020'; n.fillRect(x + 6, 76, 32, 4);
      n.fillStyle = '#16121a'; n.fillRect(x + 20, 0, 4, 40);
    }
  }
  // pipes overhead
  for (const py of [22, 40]) {
    n.fillStyle = asm ? '#39414e' : '#4a3028'; n.fillRect(0, py, L.near.width, 9);
    n.fillStyle = asm ? '#4e5a6a' : '#5e3c30'; n.fillRect(0, py, L.near.width, 2);
    for (let x = 0; x < L.near.width; x += 130) { n.fillStyle = '#20242c'; n.fillRect(x, py - 2, 8, 13); }
  }
  // floor
  const base = asm ? '#2a3140' : '#3a2a22';
  n.fillStyle = base; n.fillRect(0, 148, L.near.width, 92);
  for (let x = 0; x < L.near.width; x += 44) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x, 148, 2, 92); }
  for (let y = 158; y < 240; y += 22) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(0, y, L.near.width, 2); }
  for (let k = 0; k < 300; k++) { n.fillStyle = R() < 0.5 ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.12)'; n.fillRect(r(0, L.near.width), r(150, 238), 3, 1); }
  n.fillStyle = asm ? '#1c222c' : '#241810'; n.fillRect(0, 148, L.near.width, 3);
  if (!asm) for (let k = 0; k < 24; k++) { n.fillStyle = 'rgba(255,140,30,0.16)'; n.beginPath(); n.ellipse(r(0, L.near.width), r(160, 230), r(8, 20), r(2, 4), 0, 0, 7); n.fill(); }
}
// ---- STAGE 7: the lab
function labBg(L, R, r, len, kind) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const vault = kind === 'vault';
  f.fillStyle = vault ? '#060c12' : '#0a1018'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 80) { f.fillStyle = '#0e1620'; f.fillRect(x, 20, 70, 130); f.fillStyle = '#16202c'; f.fillRect(x, 20, 70, 2); }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 120) {
    m.fillStyle = '#121c26'; m.fillRect(x, 10, 100, 140);
    m.fillStyle = '#1c2a38'; m.fillRect(x + 6, 16, 88, 6);
    m.fillStyle = '#2ad0f0'; m.fillRect(x + 8, 18, 40, 2);
  }
  // near: panelled wall
  n.fillStyle = vault ? '#1a2630' : '#20303c'; n.fillRect(0, 0, L.near.width, 150);
  for (let x = 0; x < L.near.width; x += 60) {
    n.fillStyle = vault ? '#223440' : '#2a3e4c'; n.fillRect(x, 0, 56, 148);
    n.fillStyle = 'rgba(255,255,255,0.07)'; n.fillRect(x, 0, 56, 2);
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x + 56, 0, 4, 148);
  }
  // ceiling light strip
  n.fillStyle = '#0e1820'; n.fillRect(0, 0, L.near.width, 16);
  for (let x = 20; x < L.near.width; x += 90) { n.fillStyle = '#d8f8ff'; n.fillRect(x, 4, 46, 5); n.fillStyle = 'rgba(180,240,255,0.10)'; n.fillRect(x - 10, 9, 66, 40); }
  // specimen tanks
  for (let x = 70; x < L.near.width - 80; x += 190) {
    n.fillStyle = '#101c24'; n.fillRect(x, 48, 42, 100);
    n.fillStyle = vault ? 'rgba(255,60,90,0.32)' : 'rgba(60,224,192,0.30)'; n.fillRect(x + 3, 52, 36, 92);
    n.fillStyle = 'rgba(255,255,255,0.16)'; n.fillRect(x + 7, 52, 5, 92);
    n.fillStyle = '#3a4a58'; n.fillRect(x - 3, 44, 48, 6); n.fillRect(x - 3, 142, 48, 8);
    n.fillStyle = '#6a7a88'; n.fillRect(x - 3, 44, 48, 2);
    // the shape inside
    n.fillStyle = 'rgba(10,20,28,0.65)'; n.beginPath(); n.ellipse(x + 21, 96, 9, 26, 0, 0, 7); n.fill();
    n.fillStyle = vault ? '#ff5a70' : '#8ef0e0'; n.fillRect(x + 17, 76, 3, 3); n.fillRect(x + 23, 76, 3, 3);
  }
  // consoles
  for (let x = 160; x < L.near.width - 60; x += 190) {
    n.fillStyle = '#16222c'; n.fillRect(x, 96, 58, 52);
    n.fillStyle = '#24384a'; n.fillRect(x + 3, 100, 52, 30);
    for (let k = 0; k < 9; k++) { n.fillStyle = pick2(R, ['#2ad0f0', '#3ae0a0', '#f2c94c', '#16222c']); n.fillRect(x + 6 + (k % 5) * 10, 104 + Math.floor(k / 5) * 9, 7, 5); }
    n.fillStyle = '#0e1820'; n.fillRect(x, 130, 58, 4);
  }
  // floor
  n.fillStyle = vault ? '#2c3a46' : '#33434f'; n.fillRect(0, 148, L.near.width, 92);
  for (let x = 0; x < L.near.width; x += 40) { n.fillStyle = 'rgba(255,255,255,0.05)'; n.fillRect(x, 148, 1, 92); }
  for (let y = 160; y < 240; y += 20) { n.fillStyle = 'rgba(255,255,255,0.04)'; n.fillRect(0, y, L.near.width, 1); }
  n.fillStyle = vault ? '#1c2832' : '#22303a'; n.fillRect(0, 148, L.near.width, 3);
  n.fillStyle = vault ? 'rgba(255,60,90,0.10)' : 'rgba(60,224,192,0.08)';
  for (let x = 0; x < L.near.width; x += 120) n.fillRect(x, 152, 60, 84);
  // hazard stripe at the very front
  for (let x = 0; x < L.near.width; x += 16) { n.fillStyle = (x / 16) % 2 ? '#e8b020' : '#1a1a1e'; n.fillRect(x, 234, 16, 6); }
}
// ---- STAGE 8: tower atrium and roof
// Dead since build 13 - stage 8's three scenes are blackoutBg, modelRoomBg and
// stormPadBg in p6b_city.js now. Kept because nothing costs anything to keep.
function towerBg(L, R, r, len, kind) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const roof = kind === 'roof';
  if (roof) {
    const sky = f.createLinearGradient(0, 0, 0, 170);
    sky.addColorStop(0, '#0a0828'); sky.addColorStop(0.45, '#5a2a68'); sky.addColorStop(0.8, '#e06a4a'); sky.addColorStop(1, '#ffc068');
    f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
    for (let i = 0; i < 50; i++) { f.fillStyle = 'rgba(255,255,255,0.5)'; f.fillRect(r(0, L.far.width), r(0, 50), 1, 1); }
    for (let k = 0; k < 10; k++) { f.fillStyle = 'rgba(255,200,180,0.18)'; f.fillRect(r(0, L.far.width), r(30, 96), r(50, 110), 4); }
    // the city, far below
    f.fillStyle = '#2a1c3c'; f.fillRect(0, 146, L.far.width, 94);
    for (let x = 0; x < L.far.width; x += 7) { f.fillStyle = R() < 0.4 ? '#3a2a4e' : '#241a34'; f.fillRect(x, 146 + r(0, 10), 6, 94); }
    for (let k = 0; k < 700; k++) { f.fillStyle = R() < 0.6 ? '#f2d070' : '#7ab8f0'; f.fillRect(r(0, L.far.width), r(150, 236), 1, 1); }
    // antenna masts in the mid
    for (let x = 0; x < L.mid.width; x += 260) {
      m.fillStyle = '#16121e'; m.fillRect(x, 10, 4, 140);
      for (let y = 20; y < 140; y += 16) { m.fillRect(x - 8, y, 20, 2); }
      m.fillStyle = '#ff3a3a'; m.fillRect(x - 1, 8, 6, 4);
    }
    // near: helipad roof
    n.fillStyle = 'rgba(0,0,0,0)'; n.fillRect(0, 0, 1, 1);
    n.fillStyle = '#3e3a4a'; n.fillRect(0, 140, L.near.width, 100);
    n.fillStyle = '#54506a'; n.fillRect(0, 140, L.near.width, 5);
    for (let x = 0; x < L.near.width; x += 52) { n.fillStyle = 'rgba(0,0,0,0.18)'; n.fillRect(x, 145, 2, 95); }
    for (let y = 158; y < 240; y += 26) { n.fillStyle = 'rgba(0,0,0,0.14)'; n.fillRect(0, y, L.near.width, 2); }
    // the big H
    const hx = len - 360;
    n.strokeStyle = '#e8e8f0'; n.lineWidth = 5;
    n.beginPath(); n.arc(hx, 192, 62, 0, 7); n.stroke();
    n.fillStyle = '#e8e8f0'; n.fillRect(hx - 24, 168, 8, 48); n.fillRect(hx + 16, 168, 8, 48); n.fillRect(hx - 24, 188, 48, 8);
    // edge lights
    for (let x = 20; x < L.near.width; x += 70) { n.fillStyle = '#ffdc60'; n.fillRect(x, 142, 4, 3); n.fillStyle = 'rgba(255,220,96,0.14)'; n.fillRect(x - 6, 134, 16, 10); }
    // AC units and vents along the back
    for (let x = 60; x < len - 500; x += 240) {
      n.fillStyle = '#1e1c26'; n.fillRect(x, 104, 54, 38);
      n.fillStyle = '#2e2c3a'; n.fillRect(x + 2, 106, 50, 34);
      n.fillStyle = '#16141c'; n.beginPath(); n.arc(x + 27, 122, 12, 0, 7); n.fill();
      n.fillStyle = '#4a4858'; for (let k = 0; k < 4; k++) { n.save(); n.translate(x + 27, 122); n.rotate(k * 0.78); n.fillRect(-1.5, -11, 3, 22); n.restore(); }
    }
  } else {
    // atrium interior
    f.fillStyle = '#0b0a16'; f.fillRect(0, 0, L.far.width, H);
    for (let x = 0; x < L.far.width; x += 40) { f.fillStyle = x % 80 ? '#141222' : '#100e1c'; f.fillRect(x, 0, 40, 150); }
    // night city through the glass
    for (let x = 0; x < L.mid.width; x += 64) {
      m.fillStyle = '#0a0818'; m.fillRect(x, 16, 58, 120);
      for (let k = 0; k < 26; k++) { m.fillStyle = R() < 0.6 ? '#d8b050' : '#6aa0e0'; m.fillRect(x + r(2, 54), 16 + r(2, 116), 1, 1); }
      m.fillStyle = '#2e2a44'; m.fillRect(x + 58, 0, 6, 150);
      m.fillStyle = 'rgba(160,200,255,0.06)'; m.fillRect(x, 16, 26, 120);
    }
    n.fillStyle = '#241f3c'; n.fillRect(0, 128, L.near.width, 22);
    n.fillStyle = '#322a52'; n.fillRect(0, 128, L.near.width, 3);
    // marble columns, uplit
    for (let x = 0; x < L.near.width; x += 170) {
      n.fillStyle = '#342e52'; n.fillRect(x, 0, 32, 150);
      n.fillStyle = '#4a4270'; n.fillRect(x + 3, 0, 11, 150);
      n.fillStyle = '#605888'; n.fillRect(x + 5, 0, 4, 150);
      n.fillStyle = '#1a1628'; n.fillRect(x - 6, 0, 44, 11); n.fillRect(x - 6, 134, 44, 16);
      n.fillStyle = '#f2c94c'; n.fillRect(x - 6, 134, 44, 2);
      n.fillStyle = 'rgba(242,201,76,0.16)';
      n.beginPath(); n.moveTo(x + 4, 132); n.lineTo(x - 4, 40); n.lineTo(x + 34, 40); n.lineTo(x + 28, 132); n.fill();
      n.fillStyle = 'rgba(160,200,255,0.06)'; n.fillRect(x + 44, 22, 108, 100);
      n.fillStyle = '#463c6a'; n.fillRect(x + 44, 20, 108, 3); n.fillRect(x + 44, 122, 108, 3);
    }
    // company crest behind the boss arena
    const cx0 = len - 320;
    n.fillStyle = '#0e0c18'; n.fillRect(cx0 - 90, 20, 180, 118);
    n.fillStyle = '#8a1a2a'; n.beginPath(); n.moveTo(cx0, 34); n.lineTo(cx0 + 52, 66); n.lineTo(cx0 + 32, 126); n.lineTo(cx0 - 32, 126); n.lineTo(cx0 - 52, 66); n.fill();
    n.fillStyle = '#f2c94c'; n.beginPath(); n.moveTo(cx0, 46); n.lineTo(cx0 + 40, 70); n.lineTo(cx0 + 24, 116); n.lineTo(cx0 - 24, 116); n.lineTo(cx0 - 40, 70); n.fill();
    n.fillStyle = '#8a1a2a'; n.fillRect(cx0 - 6, 62, 12, 44); n.fillRect(cx0 - 20, 74, 40, 10);
    // floor: polished stone
    n.fillStyle = '#231e38'; n.fillRect(0, 148, L.near.width, 92);
    for (let x = 0; x < L.near.width; x += 46) { n.fillStyle = 'rgba(255,255,255,0.05)'; n.fillRect(x, 148, 2, 92); }
    for (let y = 162; y < 240; y += 24) { n.fillStyle = 'rgba(255,255,255,0.04)'; n.fillRect(0, y, L.near.width, 2); }
    for (let x = 0; x < L.near.width; x += 170) { n.fillStyle = 'rgba(242,201,76,0.10)'; n.fillRect(x + 8, 152, 18, 86); }
    n.fillStyle = '#f2c94c'; n.fillRect(0, 148, L.near.width, 2);
  }
}
function pick2(R, arr) { return arr[Math.floor(R() * arr.length)]; }

// ------------------------------------------------------------ stage flow
function stageDef() { return G.rush ? BOSS_RUSH_STAGE : (STAGE_DATA[G.stage] || STAGE1); }
function startRun(opts) {
  G = newRunState(opts);
  G.cracks = [];
  G.starsFromScore = 1;
  const cs = charSave();
  G.loadout = upgradesOn() ? cs.perks.slice(0, SAVE.slots) : [];
  G.lives = 5;
  if (opts.mode === 'training') return startTraining();
  startStage();
}
function baseStars() {
  if (CHEAT.maxstars) return 3;
  if (upgradesOn() && charSave().starlock) return 3;
  return hasPerk('starter') ? 2 : 1;
}
function startStage() {
  G.stageScore0 = G.score;
  G.stageFrames = 0; G.dmgTaken = 0; G.livesLost = 0; G.bestCombo = 0; G.breaks = 0; G.kos = 0;
  G.stars = Math.max(G.stars, baseStars());
  G.consumed = [];
  if (upgradesOn()) {
    for (const c of CONSUMABLES) if (SAVE.consumables[c.id] > 0) { SAVE.consumables[c.id]--; G.consumed.push(c.id); }
    if (G.consumed.length) writeSave();
    if (G.consumed.includes('life')) G.lives++;
  }
  loadScene(0, true);
  G.banner = G.rush ? { s: 'BOSS RUSH', t: 170, col: '#e8283a', sub: 'EVERY BOSS. ONE LIFE BAR AT A TIME.' }
    : { s: 'STAGE ' + G.stage, t: 170, col: '#fff', sub: (STAGES[G.stage - 1] || { name: '' }).name };
  jingle('start');
}
function loadScene(i, first) {
  const def = stageDef().scenes[i];
  G.sceneIdx = i; G.scene = def;
  G.camX = 0; G.lockX = null; G.waveIdx = 0; G.wave = null; G.spawnQ = [];
  G.exitOpen = false; G.goT = 0; G.car = null; G.carAt = null;
  G.items = []; G.projs = []; G.fx = []; G.cracks = [];
  G.bg = buildBackground(def.bg, def.len);
  G.props = def.breakables.map(b => Object.assign({ broken: false, flash: 0 }, b));
  G.breakTotal += G.props.length;
  G.hazards = def.hazards.map(h => Object.assign({ cool: 0, spray: 0, dir: 1 }, h));
  const keep = [];
  if (first) {
    G.ents = [];
    G.player = spawnHero('player', 70, 186);
    G.ents.push(G.player);
    if (G.partner) { G.ally = spawnHero('ally', 44, 208, G.partnerChar || G.char); G.ents.push(G.ally); if (!G.allyLives || G.allyLives <= 0) G.allyLives = 5; }
    applyStageStart(G.player);
  } else {
    G.ents = G.ents.filter(e => e.team === 'hero' && !e.remove);
    for (const h of G.ents) { h.x = h === G.player ? 70 : 44; h.y = h === G.player ? 186 : 208; h.state = h.dead ? h.state : 'stand'; h.z = 0; h.grab = null; h.heldBy = null; }
    G.fade = 1; G.fadeDir = -1;
  }
  G.boss = null; G.bosses = []; G.beams = []; G.pendingBoss = false; G.clearT = 0; G.done = false;
  G.rideSpeed = 2.4;
  G.loadQ = buildPrewarm();
  Music.play(def.music);
  if (def.ride) G.banner = { s: 'BOARD RUN', t: 200, col: '#2ad0f0', sub: 'HOLD -> TO PUSH, <- TO HANG BACK' };
}
// ------------------------------------------------------------ sprite prewarm
const GENERIC_POSES = ['idle', 'idle2', 'walk1', 'walk2', 'walk3', 'walk4', 'hurt1', 'hurt2', 'fall', 'down', 'getup', 'land', 'held',
  'jumpUp', 'jumpFall', 'dizzy', 'dizzy2', 'grab', 'pickup'];
const HERO_POSES = ['run1', 'run2', 'run3', 'run4', 'aRun1', 'aRun2', 'roll', 'victory', 'kneePrep', 'knee', 'liftA', 'liftB', 'sup1', 'sup2', 'sup3',
  'tossA', 'tossB', 'jumpKnee', 'aTuck', 'splat', 'aAirThrow', 'kLift', 'elbowDrop'];
function movePoses(set, names) {
  const seen = new Set();
  const walk = n => {
    if (!n || seen.has(n)) return; seen.add(n);
    const m = MOVES[n]; if (!m) return;
    if (m.seq) m.seq.forEach(([p]) => set.add(p));
    if (m.pose) set.add(m.pose);
    walk(m.next); walk(m.alt);
  };
  names.forEach(walk);
}
function posesForHero(kit) {
  const K = KITS[kit], set = new Set(GENERIC_POSES.concat(HERO_POSES));
  movePoses(set, [K.combo, K.back, K.blitz, K.blitzFollow, K.blitzAlt, K.spN, K.spNAlt, K.spF, K.jN, K.jF, K.jFUp, K.air2, K.hold1, K.hold2,
    K.grabMove, K.grabMoveAlt, K.airDash, K.airDown, K.spFPlus, 'athrow',
    'knee', 'throwMv', 'suplex', 'screenThrow', 'wpn1', 'wpn2', 'wpn3', 'kn1', 'kn2', 'kn3', 'wpnSpecial', 'toss', 'pickup']);
  return set;
}
const ENEMY_MOVES = { punk: ['ePunch', 'ePunch2', 'eSwing', 'eSlash'], blade: ['ePunch', 'ePunch2', 'eSlash', 'eToss'], bruiser: ['ePunch', 'ePunch2', 'eHay', 'eReach', 'eSlam', 'eRush'],
  kicker: ['ePunch', 'ePunch2', 'eKick'], whip: ['ePunch', 'eWhip'], robot: ['eHay', 'ePunch2'], dummy: ['ePunch'],
  suit: ['ePunch', 'ePunch2', 'eKick', 'eSlash'], guard: ['ePunch', 'eSwing', 'eKick'], biker: ['ePunch2', 'eSlash', 'eToss', 'eKick'],
  hvbot: ['eHay', 'ePunch2', 'eReach'] };
function buildPrewarm() {
  const q = [];
  const push = (look, set, weapon) => { for (const p of set) q.push([look, mapPose(look, p), weapon || null]); };
  for (const h of G.ents) if (h.team === 'hero') push(h.look, posesForHero(h.kit));
  const types = new Set();
  for (const w of G.scene.waves) for (const g of w.groups) g.t.forEach(t => types.add(t));
  if (G.mode === 'training') types.add('dummy');
  for (const t of types) {
    const set = new Set(GENERIC_POSES.concat(['jumpKick']));
    movePoses(set, ENEMY_MOVES[t] || []);
    for (const lk of ENEMY_TYPES[t].looks) push(LOOKS[lk], set, ENEMY_TYPES[t].weapon);
  }
  for (const w of G.scene.waves) if (w.boss) for (const k of w.boss) {
    const D = BOSS_DEFS[k];
    if (D.type === 'mech') { for (const m of MECH_POSES) q.push([LOOKS.mech, 'mech:' + m, null]); continue; }
    const set = new Set(GENERIC_POSES);
    if (D.type === 'twin') ['tIdle', 'tIdle2', 'tCrouch', 'tCartA', 'tSplit', 'tKickHigh', 'tTaunt', 'aWalk1', 'aWalk2', 'aWalk3', 'aWalk4', 'aTuck'].forEach(p => set.add(p));
    else if (D.type === 'vex') {
      ['vexReady', 'vexLunge', 'vexSpinA', 'vexSpinB', 'vexThrow', 'vexBlink', 'drayCane', 'drayPoint', 'drayCape', 'aTuck'].forEach(p => set.add(p));
      movePoses(set, ['vSlash', 'vSpin', 'vThrow']);
    } else {
      ['heavyIdle', 'heavyIdle2', 'roar', 'slamUp', 'slamDown', 'paw1', 'paw2', 'charge', 'charge2', 'reach', 'pileLift', 'pileDrop'].forEach(p => set.add(p));
      if (D.beam) ['wardenAim', 'wardenBeam'].forEach(p => set.add(p));
      movePoses(set, ['bPunch', 'bHook', 'bPole']);
    }
    push(LOOKS[D.look], set);
    if (k === 'mech') push(LOOKS.rivet, set);
    if (D.next) {
      const N = BOSS_DEFS[D.next], s2 = new Set(GENERIC_POSES);
      ['heavyIdle', 'heavyIdle2', 'roar', 'slamUp', 'slamDown', 'paw1', 'paw2', 'charge', 'charge2', 'reach'].forEach(p => s2.add(p));
      movePoses(s2, ['bPunch', 'bHook']);
      push(LOOKS[N.look], s2);
    }
  }
  if (stageDef().scenes.some(sc => sc.waves.some(w => w.boss && w.boss.includes('mech')))) {
    const set = new Set(GENERIC_POSES.concat(['heavyIdle', 'heavyIdle2', 'roar', 'slamUp', 'slamDown', 'paw1', 'paw2', 'charge', 'charge2', 'reach', 'pileLift', 'pileDrop']));
    movePoses(set, ['bPunch', 'bHook']);
    if (G.sceneIdx === stageDef().scenes.length - 1) push(LOOKS.rivet, set);
  }
  q.reverse();
  q.total = q.length;
  return q;
}
function applyStageStart(p) {
  if (hasPerk('armed') || (G.consumed && G.consumed.includes('weapon'))) p.weapon = { kind: 'pipe', dur: hasPerk('tough') ? 28 : 14 };
  if (CHEAT.weapon) p.weapon = { kind: CHEAT.weapon === 1 ? 'pipe' : 'knife', dur: 99 };
  if (G.consumed && G.consumed.includes('rage')) p.pw.rage = 1200;
}
function startTraining() {
  G.mode = 'training';
  G.scene = TRAINING_SCENE; G.sceneIdx = 0;
  G.bg = buildBackground('gym', W);
  G.props = []; G.hazards = []; G.items = []; G.projs = []; G.fx = []; G.cracks = [];
  G.ents = [];
  G.player = spawnHero('player', 120, 190);
  G.ents.push(G.player);
  G.camX = 0; G.lockX = 0; G.trainDummy = 0; G.trainCount = 1;
  for (let i = 0; i < 3; i++) G.items.push({ x: 60 + i * 20, y: 225, z: 0, vz: 0, vx: 0, kind: i === 2 ? 'knife' : 'pipe', t: 0, dur: 999, train: true });
  trainingSpawn();
  Music.play('training');
}
function trainingSpawn() {
  const alive = G.ents.filter(e => e.type === 'dummy' && !e.remove && !e.dead).length;
  for (let i = alive; i < G.trainCount; i++) {
    const e = spawnEnemy('dummy', 260 + i * 40, 175 + i * 18, 1);
    e.enter = false; e.face = -1;
  }
}
function waveCount() { return G.wave ? G.wave : null; }
function livingFoes() { return G.ents.filter(e => e.team === 'foe' && !e.remove && !e.killed); }
function updateStage() {
  if (G.mode === 'training') {
    G.player.meter = 1;
    G.player.hp = G.player.maxHp;
    const alive = G.ents.filter(e => e.type === 'dummy' && !e.remove && !e.killed);
    for (const d of alive) d.hp = d.maxHp;
    if (alive.length < G.trainCount) { G.trainRespawn++; if (G.trainRespawn > 40) { G.trainRespawn = 0; trainingSpawn(); } }
    for (const it of G.items) if (it.train) it.dur = 999;
    if (G.items.filter(i => i.train).length < 3 && G.frames % 120 === 0) {
      const kinds = ['pipe', 'pipe', 'knife'];
      const have = G.items.filter(i => i.train).map(i => i.kind);
      for (const k of kinds) { const ix = have.indexOf(k); if (ix >= 0) have.splice(ix, 1); else { G.items.push({ x: 60 + G.items.length * 20, y: 225, z: 20, vz: 0, vx: 0, kind: k, t: 0, dur: 999, train: true }); break; } }
    }
    return;
  }
  const S = G.scene, waves = S.waves;
  const p = G.player;
  // wave trigger
  const next = waves[G.waveIdx];
  if (!G.wave && next && G.camX >= next.at - 0.5) {
    G.wave = next; G.lockX = next.at; G.goT = 0;
    let n = 0;
    next.groups.forEach((g, gi) => {
      let list = g.t.slice();
      const ex = diffOf().extra;
      if (gi === 0) {
        if (ex > 0) for (let k = 0; k < ex; k++) list.push(k % 2 ? 'blade' : 'punk');
        if (ex < 0 && list.length >= 2) list.pop();
      }
      list.forEach((t, k) => {
        const side = g.side === 'B' ? (k % 2 ? -1 : 1) : g.side === 'L' ? -1 : 1;
        G.spawnQ.push({ t, side, at: G.stageFrames + (g.delay || 0) + k * 22 + 10 });
        n++;
      });
    });
    if (next.boss) {
      next.boss.forEach((k, i) => {
        const b = spawnBoss(G.camX + W + 40 + i * 44, next.boss.length > 1 ? 172 + i * 34 : 190, k);
        if (i > 0) b.st = -20;
      });
      Music.play(next.music || (G.stage === 1 ? 'boss' : 'boss' + G.stage));
    }
    if (next.car) G.carAt = G.stageFrames + next.car;
  }
  // spawns
  if (G.spawnQ.length) {
    const alive = livingFoes().length;
    const q = G.spawnQ[0];
    if (G.stageFrames >= q.at && alive < TUNING.maxOnScreen) {
      G.spawnQ.shift();
      const x = q.side > 0 ? G.camX + W + 24 : G.camX - 24;
      spawnEnemy(q.t, x, rand(TUNING.bandTop + 6, TUNING.bandBot - 6), q.side);
    }
  }
  if (G.carAt && G.stageFrames >= G.carAt) { G.carAt = null; G.car = { x: G.camX + W + 70, y: 218, t: 0 }; }
  // wave clear
  G.bossDead = G.bosses.length > 0 && liveBosses().length === 0 && !G.pendingBoss;
  if (G.wave && !G.spawnQ.length && !livingFoes().length && !(G.wave.boss && !G.bossDead)) {
    const wasBoss = G.wave.boss;
    G.wave = null; G.lockX = null; G.waveIdx++;
    G.bosses = []; G.boss = null;
    const lastWave = G.waveIdx >= waves.length;
    const lastScene = G.sceneIdx >= stageDef().scenes.length - 1;
    // only the last boss of the last scene ends the stage
    if (wasBoss && lastWave && lastScene) { G.clearT = 1; }
    else {
      if (wasBoss) {
        // a mid-stage boss: breathe, take the food, then carry on
        const p2 = G.player;
        spawnItem(clamp((p2 ? p2.x : G.camX + W / 2) + 40, G.camX + 30, G.camX + W - 30), 214, 'roast', null, 3);
        if (G.rush) G.banner = { s: 'NEXT', t: 90, col: '#f2c94c', sub: G.waveIdx + ' / ' + waves.length + ' DOWN' };
        else Music.play(S.music);
      }
      if (!lastWave) { G.goT = 150; sfx('go'); }
      else { G.exitOpen = true; G.goT = 9999; sfx('go'); }
    }
  }
  // camera
  const nx = waves[G.waveIdx];
  let camMax = S.len - W;
  if (G.lockX !== null) camMax = Math.min(camMax, G.lockX);
  else if (nx) camMax = Math.min(camMax, nx.at);
  if (S.ride) {
    // the board carries you forward on its own; lean forward or back to trim the speed
    const live = p && !p.dead && p.state !== 'gone';
    const boost = live ? (Input.held.right ? 1.7 : 0) - (Input.held.left ? 1.1 : 0) : 0;
    G.rideSpeed = approach(G.rideSpeed === undefined ? 2.4 : G.rideSpeed, 2.4 + boost, 0.12);
    if (G.camX < camMax) G.camX = Math.min(camMax, G.camX + Math.max(0.5, G.rideSpeed));
    if (p) p.x = Math.max(p.x, G.camX + 16);
  } else if (p && !p.dead && p.state !== 'gone') {
    const want = clamp(p.x - 160, 0, camMax);
    if (want > G.camX) G.camX = Math.min(want, G.camX + 4);
  }
  if (G.goT > 0 && G.goT < 9999) G.goT--;
  // scene exit
  if (G.exitOpen && p && p.x > S.len + 6 && !G.fadeDir) {
    G.fadeDir = 1; G.fade = 0;
    G.fadeCb = () => { loadScene(G.sceneIdx + 1, false); };
  }
  // stage clear
  if (G.clearT > 0) {
    G.clearT++;
    // The end of the game gets its own moment. The Warlord Frame comes apart
    // in the harmony - fifths sliding down a semitone at a time - the kit
    // drops out, and the last bar is one held guitar note over nothing. It
    // runs about six seconds, so the usual Music.stop() at frame 30 has to
    // stand aside and let it finish; the clear jingle is on the sfx bus and
    // plays over the top of it regardless.
    const lastFight = G.stage === 8 && !G.rush;
    if (G.clearT === 1 && lastFight && RCBand.has('cue_roof')) Music.cue('cue_roof', null);
    if (G.clearT === 30) {
      if (!lastFight) Music.stop();
      jingle('clear'); G.banner = { s: 'STAGE CLEAR', t: 200, col: '#f2c94c' };
    }
    for (const h of heroes()) if (h.state === 'stand') h.pose = 'victory';
    if (G.clearT === 200) { G.done = true; }
  }
}

// ------------------------------------------------------------ world render
function renderWorld() {
  const sh = G.shake > 0 ? Math.round(rand(-G.shake, G.shake) * 0.6) : 0;
  const shy = G.shake > 0 ? Math.round(rand(-G.shake, G.shake) * 0.4) : 0;
  const cx = Math.round(G.camX) - sh;
  const L = G.bg;
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
  ctx.save(); ctx.translate(0, shy);
  if (G.mode !== 'training') {
    if (L.speed) {
      // vehicle stage: the world keeps rushing past even when you stand still
      const wrap = (v, w) => -(((v % w) + w) % w);
      const ff = wrap(Math.round(cx * 0.25) + Math.round(G.frames * L.speed * 1.4), L.far.width);
      const mm = wrap(Math.round(cx * 0.55) + Math.round(G.frames * L.speed * 3.4), L.mid.width);
      bgDraw(L.far, ff, 0); bgDraw(L.far, ff + L.far.width, 0);
      bgDraw(L.mid, mm, 0); bgDraw(L.mid, mm + L.mid.width, 0);
    } else {
      bgDraw(L.far, -Math.round(cx * 0.25), 0);
      bgDraw(L.mid, -Math.round(cx * 0.55), 0);
    }
  }
  bgDraw(L.near, -cx, 0);
  if (L.speed) drawSpeedLines(L.speed);
  if (G.mode === 'training') text('TRAINING ROOM', 315, 36, '#f2c94c', 1, 1);
  if (G.scene.bg === 'dance') drawDanceFloor(cx);
  if (G.scene.bg === 'elevated') drawElTrain(cx);
  if (G.scene.bg === 'basement') drawClubStrobe();
  if (G.scene.bg === 'shed') drawShedSteam(cx);
  if (G.scene.bg === 'corridor' || G.scene.bg === 'coldstore' || G.scene.bg === 'birth') drawLabHum();
  if (G.scene.bg === 'coldstore') drawCryoFog(cx);
  if (G.scene.bg === 'birth') drawCapsuleBubbles(cx);
  if (G.scene.bg === 'blackout') { drawEmergPulse(); drawTorchBeams(cx); }
  if (G.scene.bg === 'modelroom') drawCaseGlint(cx);
  if (G.scene.bg === 'stormpad') { drawRain(); drawLightning(); }
  // floor-level hazards
  for (const hz of G.hazards) {
    const x = hz.x - cx;
    if (hz.kind === 'wire') drawWire(hz, x);
    if (hz.kind === 'pit') {
      ctx.fillStyle = '#e8b020'; ctx.fillRect(x - 34, hz.y - 9, 68, 18);
      for (let k = -34; k < 34; k += 8) { ctx.fillStyle = '#1a1a1e'; ctx.beginPath(); ctx.moveTo(x + k, hz.y - 9); ctx.lineTo(x + k + 4, hz.y - 9); ctx.lineTo(x + k + 8, hz.y + 9); ctx.lineTo(x + k + 4, hz.y + 9); ctx.fill(); }
      ctx.fillStyle = '#050407'; ctx.fillRect(x - 30, hz.y - 7, 60, 14);
      ctx.fillStyle = '#16141c'; ctx.fillRect(x - 30, hz.y - 7, 60, 3);
      text(hz.label || 'SHAFT', x, hz.y - 19, '#e8b020', 1, 1);
    }
    if (hz.kind === 'manhole' && hz.skin === 'pit') {
      // an engine pit: same mechanic, but a rectangular hole between the rails
      px(x - 30, hz.y - 9, 60, 18, '#0a090d');
      px(x - 27, hz.y - 7, 54, 14, '#16141a');
      px(x - 30, hz.y - 11, 60, 3, '#4a4450');
      px(x - 30, hz.y + 7, 60, 3, '#4a4450');
      px(x - 24, hz.y - 4, 48, 8, 'rgba(232,208,112,0.10)');
      for (let k = -24; k < 24; k += 12) px(x + k, hz.y - 7, 2, 14, 'rgba(90,84,100,0.5)');
      if (Math.floor(G.frames / 30) % 2) px(x - 10, hz.y - 20, 20, 12, 'rgba(226,226,236,0.10)');
    } else if (hz.kind === 'manhole') {
      ctx.fillStyle = '#0a080c'; ctx.beginPath(); ctx.ellipse(x, hz.y, 14, 5, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#5a5664'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(x, hz.y, 15, 5.6, 0, 0, 7); ctx.stroke();
      px(x + 14, hz.y - 1, 12, 3, '#46424e'); px(x + 15, hz.y - 1, 10, 1, '#6a6674');
      if (Math.floor(G.frames / 30) % 2) { ctx.fillStyle = 'rgba(80,200,120,0.12)'; ctx.fillRect(x - 10, hz.y - 16, 20, 12); }
    }
  }
  for (const b of G.bosses) drawBossTells(b, cx);
  for (const bm of G.beams) drawBeamShadow(bm, cx);
  if (G.car && G.car.t < 80 && Math.floor(G.car.t / 6) % 2 === 0) {
    ctx.fillStyle = 'rgba(255,200,40,0.2)'; ctx.fillRect(0, G.car.y - 13, W, 26);
    text('! CAR !', W - 8, G.car.y - 4, '#ffd040', 1, 2);
  }
  // shadows
  for (const e of G.ents) if (!e.remove && e.state !== 'screen' && e.state !== 'manhole' && e.state !== 'gone') drawShadow(e.x - cx, e.y, e.w * (e.kind === 'boss' ? 1.3 : 1.1) * Math.max(0.5, 1 - e.z / 120));
  for (const it of G.items) drawShadow(it.x - cx, it.y, 7);
  // depth sort
  const list = [];
  for (const p of G.props) if (!p.broken || p.flash > 0) list.push({ y: p.y, f: () => drawBreakable(p, p.x - cx, p.y) });
  for (const hz of G.hazards) if (hz.kind === 'hydrant') list.push({ y: hz.y, f: () => drawHydrant(hz, hz.x - cx, hz.y) });
  for (const it of G.items) list.push({ y: it.y - 0.5, f: () => drawItem(it, it.x - cx, it.y - it.z) });
  for (const e of G.ents) if (!e.remove && e.state !== 'screen' && e.state !== 'gone') list.push({ y: e.y + (e.state === 'grabbed' ? 0.3 : 0), f: () => renderEnt(e, cx) });
  for (const p of G.projs) list.push({ y: p.y, f: () => drawProj(p, p.x - cx, p.y - p.z) });
  if (G.car) list.push({ y: G.car.y + 6, f: () => drawCar(G.car, G.car.x - cx, G.car.y) });
  for (const bm of G.beams) list.push({ y: bm.y + 2, f: () => drawBeam(bm, cx) });
  for (const f of G.fx) if (f.k !== 'txt' && f.k !== 'num') list.push({ y: f.y + 1, f: () => drawFx(f, cx) });
  list.sort((a, b) => a.y - b.y);
  for (const o of list) o.f();
  for (const p of G.props) if (p.flash > 0) p.flash--;
  for (const f of G.fx) if (f.k === 'txt' || f.k === 'num') drawFx(f, cx);
  // GO arrow
  if (G.goT > 0 && Math.floor(G.frames / 20) % 2 === 0 && !G.clearT) {
    text('GO', W - 34, 90, '#f2c94c', 2, 1);
    text('→', W - 34, 110, '#f2c94c', 2, 1);
  }
  ctx.restore();
  // screen throws
  for (const e of G.ents) if (e.state === 'screen' && e.screen) renderScreenThrow(e);
  for (const c of G.cracks) drawCrack(c);
}
function drawSpeedLines(sp) {
  const n = 14;
  for (let i = 0; i < n; i++) {
    const seed = i * 97;
    const y = 152 + ((seed * 13) % 84);
    const x = W - (((G.frames * (7 + (i % 4) * 3) * sp + seed * 31) % (W + 90)));
    ctx.fillStyle = i % 3 ? 'rgba(255,255,255,0.10)' : 'rgba(180,220,255,0.16)';
    ctx.fillRect(x, y, 22 + (i % 5) * 8, 1);
  }
  for (let i = 0; i < 6; i++) {
    const y = 120 + ((i * 53) % 26);
    const x = W - (((G.frames * 16 * sp + i * 71) % (W + 140)));
    ctx.fillStyle = 'rgba(255,240,200,0.12)';
    ctx.fillRect(x, y, 50, 1);
  }
}
const OFF_BOARD = ['fall', 'down', 'getup', 'dead', 'screen', 'gone', 'manhole', 'respawn', 'bintro', 'vintro'];
function drawBoard(e, cx) {
  if (OFF_BOARD.includes(e.state)) return;
  const x = Math.round(e.x - cx), y = Math.round(e.y - e.z);
  const w = Math.max(9, Math.round(13 * (e.look.scale || 1) * GS));
  const hero = e.team === 'hero';
  ctx.fillStyle = hero ? 'rgba(60,200,255,0.22)' : 'rgba(255,90,40,0.20)';
  ctx.beginPath(); ctx.ellipse(x, y + 6, w + 2, 4, 0, 0, 7); ctx.fill();
  px(x - w, y - 2, w * 2, 5, '#120a14');
  px(x - w + 1, y - 1, w * 2 - 2, 3, hero ? '#1f7f9a' : '#8a2a1a');
  px(x - w + 1, y - 2, w * 2 - 2, 1, hero ? '#8ef0ff' : '#ffb07a');
  const k = Math.floor(G.frames / 4) % 2;
  px(x - w + 2 + k * 2, y + 3, 3, 1, hero ? '#8ef0ff' : '#ffc060');
  px(x + w - 6 - k * 2, y + 3, 3, 1, hero ? '#8ef0ff' : '#ffc060');
}
function renderEnt(e, cx) {
  if (e.kind === 'boss' && e.boss && e.boss.type === 'mech') return drawMech(e, cx);
  if (G.scene.ride && !e.look.heavy) drawBoard(e, cx);
  let pn = e.pose;
  if (e.noFemMap) { if (e.look.heavy && (pn === 'idle' || pn === 'idle2')) pn = pn === 'idle' ? 'heavyIdle' : 'heavyIdle2'; }
  else pn = mapPose(e.look, pn);
  let rot = null;
  if (e.rotOver !== null && e.rotOver !== undefined) rot = e.rotOver;
  if (e.state === 'fall' && e.projBody > 0) rot = -60 - (e.st * 14) % 360;
  let alpha = 1;
  if ((e.state === 'dead' && e.team === 'foe') && Math.floor(e.st / 3) % 2) alpha = 0;
  if (e.team === 'hero' && e.inv > 30 && Math.floor(e.inv / 3) % 2) alpha = 0.35;
  if (e.state === 'dead' && e.team === 'hero' && e.st > 30 && Math.floor(e.st / 3) % 2) alpha = 0;
  if (alpha === 0) return;
  let tint = null;
  if (e.pw.rage > 0) tint = Math.floor(G.frames / 6) % 2 ? 'rgba(255,40,40,0.35)' : 'rgba(255,90,40,0.2)';
  else if (e.pw.iron > 0) tint = 'rgba(190,200,220,0.4)';
  else if (e.pw.overdrive > 0 && Math.floor(G.frames / 5) % 2) tint = 'rgba(40,200,255,0.3)';
  if (e.charging && e.chargeT >= 40) tint = Math.floor(G.frames / 4) % 2 ? (e.chargeT >= 90 ? 'rgba(255,90,20,0.55)' : 'rgba(255,230,80,0.45)') : null;
  if (e.mv && e.mv.special && heroStars(e) >= 2 && e.team === 'hero') tint = 'rgba(255,120,30,0.35)';
  if (e.kind === 'boss' && (e.state === 'broar' || e.enraged)) tint = Math.floor(G.frames / 6) % 2 ? 'rgba(255,30,30,0.3)' : null;
  if (e.burstT > 0) tint = Math.floor(G.frames / 3) % 2 ? 'rgba(255,255,255,0.6)' : 'rgba(255,200,60,0.4)';
  if (e.type === 'robot' && e.state === 'dead' && e.st < 45) tint = Math.floor(e.st / 4) % 2 ? 'rgba(255,40,40,0.6)' : null;
  let look = e.look;
  if (CHEAT.bigheads) look = bigHead(look);
  const y = e.y - e.z;
  let sy = y;
  if (e.state === 'manhole') {
    ctx.save(); ctx.beginPath(); ctx.rect(e.x - cx - 50, 0, 100, e.y); ctx.clip();
    sy = e.y + e.sink * 90;
  }
  drawFigure(e.x - cx, sy, e.face, pn, look, { flash: e.flash > 0 && e.flash % 2 === 0, weapon: e.weapon && WEAPON_GEO[e.weapon.kind] ? e.weapon.kind : null, tint, alpha, rot });
  if (e.state === 'manhole') ctx.restore();
  if (e.weapon && e.weapon.kind === 'whip' && e.whipT > 0) drawWhip(e, cx);
  const tagY = y - 100 * (e.look.scale || 1);
  if (e.kind === 'player' && G.partner && e.state !== 'dead') text('1P', e.x - cx, tagY, '#4ac0e8', 1, 1);
  if (e.kind === 'ally' && e.state !== 'dead') text('CPU', e.x - cx, tagY, '#5ad06a', 1, 1);
}
const bigCache = new Map();
function bigHead(look) {
  let b = bigCache.get(look);
  if (!b) { b = recolor(look, { headScale: 2 }); bigCache.set(look, b); }
  return b;
}
function drawItem(it, x, y) {
  if (it.kind === 'power') ITEM_DRAW.power(x, y, it);
  else if (ITEM_DRAW[it.kind]) {
    if ((it.kind === 'cash' || it.kind === 'gold') && it.t > 60 * 17 && Math.floor(it.t / 4) % 2) return;
    ITEM_DRAW[it.kind](x, y);
  }
  if (it.train) text('∞', x, y + 2, '#fff', 1, 1);
}
function drawHydrant(hz, x, y) {
  if (hz.skin === 'vent') return drawVent(hz, x, y);
  const O = '#120a14';
  px(x - 6, y - 18, 12, 18, O); px(x - 5, y - 17, 10, 17, '#c8283a');
  px(x - 8, y - 12, 16, 5, O); px(x - 7, y - 11, 14, 3, '#e84050');
  px(x - 4, y - 21, 8, 4, O); px(x - 3, y - 20, 6, 3, '#e84050');
  px(x - 3, y - 16, 2, 14, 'rgba(255,255,255,0.25)');
  if (hz.spray > 0) {
    ctx.fillStyle = 'rgba(140,200,255,0.55)';
    const len = 84 * Math.min(1, (180 - hz.spray) / 10 + 0.2);
    const x0 = hz.dir > 0 ? x + 6 : x - 6 - len;
    ctx.fillRect(x0, y - 16 + Math.sin(G.frames / 3), len, 5);
    ctx.fillStyle = 'rgba(220,240,255,0.7)'; ctx.fillRect(x0, y - 15 + Math.sin(G.frames / 3), len, 2);
  }
}
function drawProj(p, x, y) {
  if (p.kind === 'fire') {
    const k = Math.floor(G.frames / 4) % 3;
    ctx.fillStyle = 'rgba(255,120,20,0.30)';
    ctx.beginPath(); ctx.ellipse(x, p.y, 20, 7, 0, 0, 7); ctx.fill();
    for (let i = 0; i < 5; i++) {
      const fx2 = x - 14 + i * 7 + ((i + k) % 2) * 2;
      const h = 10 + ((i * 7 + G.frames) % 11);
      ctx.fillStyle = i % 2 ? '#ff8a10' : '#ffd040';
      ctx.fillRect(fx2, p.y - h, 3, h);
      ctx.fillStyle = '#ffe8a0'; ctx.fillRect(fx2, p.y - h, 3, 3);
    }
    return;
  }
  if (p.kind === 'bolt') {
    ctx.fillStyle = Math.floor(G.frames / 3) % 2 ? '#8ef0ff' : '#2ad0f0';
    ctx.fillRect(x - 12, y - 2, 24, 4);
    ctx.fillStyle = '#fff'; ctx.fillRect(x - 6, y - 1, 12, 2);
    return;
  }
  if (p.kind === 'wave') {
    const k = Math.floor(G.frames / 3) % 2;
    ctx.fillStyle = k ? '#ffd040' : '#ff8030';
    ctx.beginPath(); ctx.moveTo(x - 8, p.y); ctx.lineTo(x, p.y - 16); ctx.lineTo(x + 8, p.y); ctx.fill();
    return;
  }
  ctx.save(); ctx.translate(Math.round(x), Math.round(y));
  if (p.kind === 'pipe') ctx.rotate(G.frames * 0.5);
  if (p.vx < 0) ctx.scale(-1, 1);
  if (p.kind === 'knife') { px(-6, -2, 13, 3, '#120a14'); px(-5, -1, 4, 1, '#4a2d1a'); px(-1, -1, 7, 1, '#e6eef5'); }
  else { px(-11, -2, 23, 4, '#120a14'); px(-10, -1, 21, 2, '#9aa3ad'); }
  ctx.restore();
}
function drawCar(c, x, y) {
  if (c.t < 80) return;
  const O = '#120a14';
  // In the shed what comes through is a shunting locomotive, not a taxi.
  if (G.scene.bg === 'shed') {
    px(x - 46, y - 34, 92, 30, O); px(x - 45, y - 33, 90, 28, '#2a4030');
    px(x - 45, y - 33, 90, 3, '#3a5440');
    px(x - 45, y - 12, 90, 8, '#1e2e22');
    px(x - 20, y - 50, 40, 17, O); px(x - 19, y - 49, 38, 15, '#2a4030');
    px(x - 15, y - 46, 12, 9, '#7a9ab8'); px(x + 2, y - 46, 12, 9, '#7a9ab8');
    px(x + 24, y - 44, 14, 11, O); px(x + 25, y - 43, 12, 9, '#1e2e22');   // the exhaust stack
    px(x - 48, y - 26, 4, 10, '#c8302a');
    px(x - 52, y - 24, 5, 6, '#fff8b0');
    ctx.fillStyle = 'rgba(255,248,176,0.22)';
    ctx.beginPath(); ctx.moveTo(x - 52, y - 24); ctx.lineTo(x - 116, y - 38); ctx.lineTo(x - 116, y + 2); ctx.lineTo(x - 52, y - 14); ctx.fill();
    px(x - 46, y - 8, 92, 6, O);
    for (const wx of [-32, -12, 10, 30]) {
      ctx.fillStyle = O; ctx.beginPath(); ctx.arc(x + wx, y - 2, 7, 0, 7); ctx.fill();
      ctx.fillStyle = '#4a4a52'; ctx.beginPath(); ctx.arc(x + wx, y - 2, 3, 0, 7); ctx.fill();
    }
    px(x - 44, y - 6, 88, 3, '#1a1a1e');
    text('SHUNT', x - 15, y - 26, '#c8c8a0', 1, 0, null);
    return;
  }
  px(x - 34, y - 26, 68, 22, O); px(x - 33, y - 25, 66, 20, '#d8a020');
  px(x - 20, y - 36, 36, 12, O); px(x - 19, y - 35, 34, 11, '#d8a020');
  px(x - 17, y - 33, 13, 8, '#2a3a5a'); px(x - 1, y - 33, 14, 8, '#2a3a5a');
  px(x - 34, y - 14, 68, 3, '#1a1a1a'); text('TAXI', x - 11, y - 22, '#1a1a1a', 1, 0, null);
  px(x - 36, y - 20, 4, 5, '#fff8b0');
  ctx.fillStyle = 'rgba(255,248,176,0.25)'; ctx.beginPath(); ctx.moveTo(x - 36, y - 20); ctx.lineTo(x - 90, y - 30); ctx.lineTo(x - 90, y); ctx.lineTo(x - 36, y - 15); ctx.fill();
  for (const wx of [-22, 20]) { ctx.fillStyle = O; ctx.beginPath(); ctx.arc(x + wx, y - 4, 7, 0, 7); ctx.fill(); ctx.fillStyle = '#5a5a60'; ctx.beginPath(); ctx.arc(x + wx, y - 4, 3, 0, 7); ctx.fill(); }
  for (let k = 0; k < 3; k++) px(x + 40 + k * 10 + rand(0, 4), y - 20 + k * 5, 8, 1, 'rgba(255,255,255,0.5)');
}
function drawFx(f, cx) {
  const x = f.x - cx;
  switch (f.k) {
    case 'spark': {
      const r = (f.big ? 13 : 9) * (1 - f.t / 10 + 0.4);
      const y = f.y - f.z;
      ctx.strokeStyle = f.fire ? '#ff7a2a' : f.t % 2 ? '#fff' : '#ffe080';
      ctx.lineWidth = f.big ? 2 : 1;
      for (let i = 0; i < 8; i++) {
        const a = i * Math.PI / 4 + f.t * 0.2, rr = i % 2 ? r * 0.55 : r;
        ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * 3, y + Math.sin(a) * 3); ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); ctx.stroke();
      }
      if (f.t > 5) { ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, f.big ? 4 : 2.5, 0, 7); ctx.fill(); }
      break;
    }
    case 'dust': {
      const k = 1 - f.t / 18;
      ctx.fillStyle = `rgba(200,190,210,${0.5 * (f.t / 18)})`;
      ctx.beginPath(); ctx.arc(x - k * 10, f.y - 3 - k * 4, 3 + k * 5, 0, 7); ctx.arc(x + k * 10, f.y - 3 - k * 4, 3 + k * 5, 0, 7); ctx.fill();
      break;
    }
    case 'debris': px(x - 1, f.y - f.z - 1, 3, 3, f.col); break;
    case 'drop': px(x, f.y - f.z, 2, 2, 'rgba(180,220,255,0.9)'); break;
    case 'ring': {
      const k = 1 - f.t / 18;
      ctx.strokeStyle = f.col; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(x, f.y - f.z, 8 + k * 26, 8 + k * 26, 0, 0, 7); ctx.stroke();
      break;
    }
    case 'shock': {
      const k = 1 - f.t / 22;
      ctx.strokeStyle = `rgba(255,220,120,${f.t / 22})`; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.ellipse(x, f.y, f.r * k, f.r * k / 2.2, 0, 0, 7); ctx.stroke();
      break;
    }
    case 'flame': {
      const c = f.t > 10 ? '#ffe060' : f.t > 5 ? '#ff8030' : '#c02a20';
      px(x - 2, f.y - f.z - 2, 4, 4, c);
      break;
    }
    case 'star': {
      const a = f.a + (24 - f.t) * 0.25;
      text('★', x + Math.cos(a) * 14 - 3, f.y - f.z + Math.sin(a) * 4, '#f2c94c', 1, 0, null);
      break;
    }
    case 'fire': {
      const c = f.t > 10 ? '#fff4a0' : f.t > 6 ? '#ffa030' : '#c83020';
      const r = 2 + (14 - f.t) * 0.35;
      ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, f.y - f.z, r, 0, 7); ctx.fill();
      break;
    }
    case 'steam': {
      ctx.fillStyle = `rgba(220,220,230,${f.t / 40})`;
      ctx.beginPath(); ctx.arc(x + (30 - f.t) * 0.3, f.y - f.z - (30 - f.t), 3 + (30 - f.t) * 0.2, 0, 7); ctx.fill();
      break;
    }
    case 'boom': {
      const k = 1 - f.t / 30;
      const y = f.y - (f.zOff || 20);
      ctx.fillStyle = f.t % 4 < 2 ? '#fff4a0' : '#ff8a2a';
      ctx.beginPath(); ctx.arc(x, y, f.r * (0.3 + k * 0.7), 0, 7); ctx.fill();
      ctx.fillStyle = '#c83020'; ctx.beginPath(); ctx.arc(x, y, f.r * (0.15 + k * 0.5), 0, 7); ctx.fill();
      break;
    }
    case 'txt': text(f.s, x, f.y - 40 + f.t * 0, f.col, 1, 1); break;
    case 'num': text(String(f.v), x, f.y, '#ffe080', 1, 1); break;
  }
}
function renderScreenThrow(e) {
  const s = e.screen, f = e.st;
  let sx, sy, sc, alpha = 1;
  const big = e.kind === 'boss';
  const maxS = big ? 1.8 : 2.6, half = big ? 46 : 32;
  const endY = 118 + half * maxS;
  if (f < 22) {
    const k = f / 22;
    sc = lerp(1, maxS, k * k);
    sx = lerp(s.x0, 213, k); sy = lerp(s.y0 + 30, endY, k) - Math.sin(k * Math.PI) * 30;
  } else {
    sx = 213; sc = maxS;
    sy = endY + Math.max(0, f - 40) * 2.2;
    alpha = f > 60 ? Math.max(0, 1 - (f - 60) / 20) : 1;
  }
  let look = e.look; if (CHEAT.bigheads) look = bigHead(look);
  if (e.kind === 'boss' && e.boss && e.boss.type === 'mech') return;
  drawFigure(sx, sy, 1, 'splat', look, { scale: sc, alpha, flash: f >= 22 && f < 26 });
}
function drawCrack(c) {
  const a = Math.min(1, c.t / 30);
  ctx.strokeStyle = `rgba(230,240,255,${0.85 * a})`; ctx.lineWidth = 1;
  const R = mulberry(Math.floor(c.seed * 1e6));
  for (let i = 0; i < 11; i++) {
    let x = c.x, y = c.y, ang = (i / 11) * Math.PI * 2 + R() * 0.4;
    ctx.beginPath(); ctx.moveTo(x, y);
    for (let k = 0; k < 5; k++) { const l = 8 + R() * 16; ang += (R() - 0.5) * 0.7; x += Math.cos(ang) * l; y += Math.sin(ang) * l; ctx.lineTo(x, y); }
    ctx.stroke();
  }
  ctx.beginPath(); ctx.arc(c.x, c.y, 10, 0, 7); ctx.stroke();
  ctx.beginPath(); ctx.arc(c.x, c.y, 22, 0.3, 2.4); ctx.stroke();
}

// ------------------------------------------------------------ HUD
function bar(x, y, w, h, v, col, back = '#3a1a1a', trail = null) {
  px(x - 1, y - 1, w + 2, h + 2, '#120a14');
  px(x, y, w, h, back);
  if (trail !== null) px(x, y, Math.round(w * clamp(trail, 0, 1)), h, '#e8e8f0');
  px(x, y, Math.round(w * clamp(v, 0, 1)), h, col);
  px(x, y, Math.round(w * clamp(v, 0, 1)), 1, 'rgba(255,255,255,0.35)');
}
function drawHUD() {
  const p = G.player;
  px(0, 0, W, 34, 'rgba(8,6,14,0.78)');
  px(0, 34, W, 1, '#2a2440');
  if (!p) return;
  drawPortrait(4, 4, p.look);
  text(p.name, 32, 3, '#fff');
  const st = G.stars;
  for (let i = 0; i < 3; i++) text('★', 64 + i * 7, 3, i < st ? '#f2c94c' : '#3a3450', 1, 0, null);
  if (!p.trailHp) p.trailHp = p.hp;
  p.trailHp = p.trailHp > p.hp ? p.trailHp - 0.6 : p.hp;
  const hpc = p.hp / p.maxHp > 0.3 ? '#f2c94c' : (Math.floor(G.frames / 8) % 2 ? '#e8283a' : '#f2c94c');
  bar(32, 13, 104, 6, p.hp / p.maxHp, hpc, '#3a1a1a', p.trailHp / p.maxHp);
  const full = p.meter >= 1;
  bar(32, 23, 104, 3, p.meter, full ? (Math.floor(G.frames / 10) % 2 ? '#8a6aff' : '#c8a8ff') : '#4a3a9a', '#1a1430');
  if (full) text('SP', 139, 21, '#c8a8ff', 1, 0, null);
  text('×' + (CHEAT.inflives && G.mode === 'story' ? '∞' : Math.max(0, G.lives)), 5, 27 - 1, '#fff');
  if (G.mode === 'story') {
    text('SCORE', 154, 3, '#8a88a8');
    text(fmt(G.score), 154, 12, '#fff');
  } else text('TRAINING', 154, 3, '#f2c94c');
  // weapon + powerups
  let ix = 154;
  if (p.weapon) {
    text(p.weapon.kind === 'pipe' ? 'PIPE' : 'KNIFE', ix, 23, '#c8c8d8', 1, 0, null);
    const d = p.weapon.dur >= 99 ? 1 : p.weapon.dur / (p.weapon.kind === 'pipe' ? 14 : 12);
    bar(ix + 32, 25, 16, 2, d, '#c8c8d8', '#2a2a3a');
    ix += 54;
  }
  for (const [k, c, l] of [['rage', '#e8283a', 'R'], ['iron', '#9aa8b8', 'I'], ['overdrive', '#30c0e0', 'O']]) {
    if (p.pw[k] > 0) {
      px(ix, 21, 9, 9, c); text(l, ix + 2, 22, '#fff', 1, 0, null);
      bar(ix + 11, 25, 14, 2, p.pw[k] / (TUNING.powerTime[k] * 1.5), c, '#2a2a3a');
      ix += 30;
    }
  }
  // enemy info
  const shownBosses = G.bosses.filter(o => !o.remove && !(['bintro', 'tintro', 'mintro'].includes(o.state) && o.st < 60));
  if (G.lastFoeT > 0) G.lastFoeT--;
  if (shownBosses.length >= 2) {
    shownBosses.slice(0, 2).forEach((o, i) => {
      const x = 236 + i * 92;
      text(o.name, x, 3, o.killed ? '#6a5a60' : '#ff6a7a');
      if (!o.trailHp) o.trailHp = o.hp;
      o.trailHp = o.trailHp > o.hp ? o.trailHp - 1.2 : o.hp;
      bar(x, 13, 84, 6, Math.max(0, o.hp) / o.maxHp, '#e8283a', '#2a1414', Math.max(0, o.trailHp) / o.maxHp);
      if (o.state === 'dazed' || o.state === 'ttaunt') text('GRAB HER!', x, 23, Math.floor(G.frames / 8) % 2 ? '#f2c94c' : '#fff', 1, 0, null);
    });
  } else {
    let foe = null;
    if (shownBosses.length) foe = shownBosses[0];
    else if (G.lastFoe && G.lastFoeT > 0 && !G.lastFoe.remove) foe = G.lastFoe;
    if (foe) {
      const bw = foe.kind === 'boss' ? 180 : 110;
      text(foe.name, 236, 3, foe.kind === 'boss' ? '#ff6a7a' : '#e8e8f0');
      if (!foe.trailHp) foe.trailHp = foe.hp;
      foe.trailHp = foe.trailHp > foe.hp ? foe.trailHp - (foe.kind === 'boss' ? 1.2 : 0.5) : foe.hp;
      bar(236, 13, bw, 6, Math.max(0, foe.hp) / foe.maxHp, foe.kind === 'boss' ? '#e8283a' : '#e87a30', '#2a1414', Math.max(0, foe.trailHp) / foe.maxHp);
      if (foe.kind === 'boss' && foe.state === 'dazed') text('DAZED! GRAB HIM', 236, 23, Math.floor(G.frames / 8) % 2 ? '#f2c94c' : '#fff', 1, 0, null);
      if (foe.kind === 'boss' && foe.state === 'mstall') text('OVERHEATED! HIT IT!', 236, 23, Math.floor(G.frames / 8) % 2 ? '#f2c94c' : '#fff', 1, 0, null);
      if (foe.robot) text('ARMORED - CAN\'T GRAB', 236, 23, '#8a94a4', 1, 0, null);
    }
  }
  const a = G.ally;
  if (a && G.partner) {
    const lab = 'CPU ' + ALLY_CMDS[G.allyCmd];
    const ax = W - 6 - textWidth(lab) - 60, ay = H - 11;
    px(ax - 3, ay - 3, W - ax, 13, 'rgba(8,6,14,0.7)');
    text(lab, ax, ay, '#5ad06a', 1, 0, null);
    bar(ax + textWidth(lab) + 6, ay + 2, 30, 3, Math.max(0, a.hp) / a.maxHp, '#5ad06a', '#1a2a1a');
    text('×' + G.allyLives, W - 6, ay, '#fff', 1, 2, null);
  }
  if (G.cheated && Math.floor(G.frames / 20) % 2) text('*', 142, 3, '#c86aff');
  if (G.classic && G.mode === 'story') text('CLASSIC', 4, 37, '#c8c8d8');
  // combo
  if (G.combo >= 2 && G.comboShow > 0) {
    const s = G.combo >= 10 ? 2 : 2;
    text(G.combo + '', W - 8, 44, G.combo >= 10 ? '#f2c94c' : '#fff', s, 2);
    text('HITS', W - 8, 60, '#e8e8f0', 1, 2);
  }
  if (audioBlocked() && Math.floor(G.frames / 40) % 2 === 0) text('CLICK OR PRESS A KEY FOR SOUND', W / 2, 38, '#8a88a8', 1, 1);
}
function drawBanner() {
  const bn = G.banner; if (!bn) return;
  if (bn.t <= 0) { G.banner = null; return; }
  const k = Math.min(1, (bn.t) / 20, (200 - bn.t) / 12);
  const y = 96;
  px(0, y - 6, W, bn.sub ? 34 : 24, `rgba(0,0,0,${0.6 * Math.max(0, k)})`);
  const off = Math.round((1 - Math.max(0, Math.min(1, k))) * 60);
  text(bn.s, W / 2 + off, y, bn.col, 2, 1);
  if (bn.sub) text(bn.sub, W / 2 - off, y + 18, '#e8e8f0', 1, 1);
}

function drawBossTells(b, cx) {
  const blink = Math.floor(b.st / 4) % 2 === 0;
  if (b.state === 'bchargeTell' && blink) {
    ctx.fillStyle = 'rgba(232,40,58,0.28)';
    const x0 = b.boss.chargeDir > 0 ? b.x - cx : 0, x1 = b.boss.chargeDir > 0 ? W : b.x - cx;
    ctx.fillRect(x0, b.y - 12, x1 - x0, 24);
    for (let k = 0; k < 5; k++) {
      const ax = b.x - cx + b.boss.chargeDir * (40 + k * 60 + (b.st % 20) * 2);
      text(b.boss.chargeDir > 0 ? '>' : '<', ax, b.y - 4, '#ff5a6a', 1, 1, null);
    }
  }
  if (b.state === 'tcartTell' && blink) {
    ctx.fillStyle = 'rgba(232,40,140,0.25)';
    const d = b.boss.cartDir;
    const x0 = d > 0 ? b.x - cx : 0, x1 = d > 0 ? W : b.x - cx;
    ctx.fillRect(x0, b.y - 11, x1 - x0, 22);
    text(d > 0 ? '>>' : '<<', b.x - cx + d * 40, b.y - 4, '#ff6ab8', 1, 1, null);
  }
  if (b.state === 'tflipTell') {
    ctx.strokeStyle = blink ? 'rgba(255,106,184,0.9)' : 'rgba(255,255,255,0.6)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(b.x - cx, b.y - 60, 6 + b.st * 0.3, 0, 7); ctx.stroke();
    text('!', b.x - cx, b.y - 100, '#ff6ab8', 2, 1);
  }
  if (b.state === 'bslamTell') {
    ctx.strokeStyle = blink ? 'rgba(255,90,40,0.8)' : 'rgba(255,220,80,0.6)';
    ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(b.x + b.face * 20 - cx, b.y, 80, 80 / 2.2, 0, 0, 7); ctx.stroke();
  }
  if (b.state === 'mstompTell') {
    ctx.strokeStyle = blink ? 'rgba(255,90,40,0.8)' : 'rgba(255,220,80,0.6)';
    ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(b.x + b.face * 14 - cx, b.y, 100, 100 / 2.2, 0, 0, 7); ctx.stroke();
  }
  if (b.state === 'mclawTell' && blink) {
    ctx.fillStyle = 'rgba(232,40,58,0.3)';
    const x0 = b.face > 0 ? b.x - cx : b.x - cx - 96;
    ctx.fillRect(x0, b.y - 20, 96, 40);
    text('!', b.x - cx + b.face * 60, b.y - 60, '#ff5a6a', 2, 1);
  }
  if (b.state === 'mflameTell') {
    ctx.fillStyle = blink ? 'rgba(255,140,40,0.32)' : 'rgba(255,220,80,0.18)';
    const x0 = b.x - cx + b.face * 20, x1 = b.x - cx + b.face * 140;
    ctx.beginPath(); ctx.moveTo(x0, b.y - 9); ctx.lineTo(x1, b.y - 17); ctx.lineTo(x1, b.y + 17); ctx.lineTo(x0, b.y + 9); ctx.fill();
  }
  if (b.state === 'vdashTell' && blink) {
    ctx.fillStyle = 'rgba(255,42,74,0.26)';
    const d = b.boss.chargeDir;
    const x0 = d > 0 ? b.x - cx : 0, x1 = d > 0 ? W : b.x - cx;
    ctx.fillRect(x0, b.y - 11, x1 - x0, 22);
    for (let k = 0; k < 4; k++) text(d > 0 ? '>' : '<', b.x - cx + d * (46 + k * 64 + (b.st % 16) * 2), b.y - 4, '#ff6a80', 1, 1, null);
  }
  if (b.state === 'bbeamTell') {
    const y = b.boss.beamY === undefined ? b.y : b.boss.beamY;
    ctx.fillStyle = blink ? 'rgba(42,208,240,0.26)' : 'rgba(180,240,255,0.12)';
    const d = b.boss.beamDir || b.face;
    const x0 = d > 0 ? b.x - cx : 0, x1 = d > 0 ? W : b.x - cx;
    ctx.fillRect(x0, y - 7, x1 - x0, 14);
    ctx.fillStyle = '#8ef0ff'; ctx.fillRect(x0, y - 8, x1 - x0, 1); ctx.fillRect(x0, y + 7, x1 - x0, 1);
    text('!', b.x - cx + d * 40, y - 24, '#2ad0f0', 2, 1);
  }
  if (b.state === 'bphase') {
    ctx.strokeStyle = blink ? 'rgba(242,201,76,0.85)' : 'rgba(255,255,255,0.5)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(b.x - cx, b.y - 40, 8 + b.st * 0.5, 0, 7); ctx.stroke();
  }
  if (b.state === 'bburst') {
    ctx.strokeStyle = blink ? 'rgba(255,255,255,0.8)' : 'rgba(255,208,64,0.7)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(b.x - cx, b.y, 110 * Math.min(1, b.st / 24), 50 * Math.min(1, b.st / 24), 0, 0, 7); ctx.stroke();
  }
}
function drawMech(e, cx) {
  const f = getMechFrame(e.mpose || 'idle');
  let tint = null;
  if (e.state === 'mstall') tint = Math.floor(G.frames / 5) % 2 ? 'rgba(255,120,40,0.3)' : null;
  if (e.state === 'mbreak') tint = Math.floor(G.frames / 3) % 2 ? 'rgba(255,60,40,0.5)' : null;
  if (e.burstT > 0) tint = Math.floor(G.frames / 3) % 2 ? 'rgba(255,255,255,0.6)' : null;
  const shakeX = e.state === 'mbreak' ? rand(-2, 2) : 0;
  if (!tint && e.flash > 0 && e.flash % 2 === 0) tint = 'rgba(255,255,255,0.45)';
  blitFrame(f, e.x - cx + shakeX, e.y - e.z, e.face, { tint });
}
function drawWhip(e, cx) {
  const J = getFrame(e.look, e.pose, null, null).J;
  if (!J) return;
  const hx = e.x - cx + J.a2.hd[0] * e.face, hy = e.y - e.z + J.a2.hd[1] + J.snap;
  const k = e.whipT / 10;
  const len = 74 * GS * Math.min(1, k * 1.6);
  ctx.strokeStyle = '#1a1018'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(hx, hy);
  const ex = hx + e.face * len, ey = hy + 10 - Math.sin(k * Math.PI) * 14;
  ctx.quadraticCurveTo(hx + e.face * len * 0.5, hy - 18 * (1 - k), ex, ey);
  ctx.stroke();
  ctx.strokeStyle = '#8a1a4a'; ctx.lineWidth = 1; ctx.stroke();
  if (e.whipT >= 2 && e.whipT <= 5) { ctx.fillStyle = '#fff'; ctx.fillRect(ex - 1, ey - 1, 3, 3); }
}
function drawWire(hz, x) {
  const t = hz.t || 0;
  ctx.fillStyle = 'rgba(80,140,220,0.35)'; ctx.beginPath(); ctx.ellipse(x, hz.y, 30, 9, 0, 0, 7); ctx.fill();
  ctx.fillStyle = 'rgba(160,210,255,0.25)'; ctx.beginPath(); ctx.ellipse(x - 6, hz.y - 2, 12, 3, 0, 0, 7); ctx.fill();
  // the cable
  ctx.strokeStyle = '#141018'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(x - 60, hz.y - 30); ctx.quadraticCurveTo(x - 40, hz.y + 2, x - 8, hz.y); ctx.stroke();
  px(x - 10, hz.y - 2, 4, 3, '#c8a040');
  const warn = t >= 60 && t < 100, zap = t >= 100 && t < 130;
  if (warn || (t % 30 < 3)) for (let i = 0; i < (warn ? 3 : 1); i++) px(x - 8 + rand(-4, 4), hz.y - 3 + rand(-4, 2), 2, 2, '#fff8a0');
  if (warn && Math.floor(t / 5) % 2) text('!', x, hz.y - 22, '#fff04a', 2, 1);
  if (zap) {
    ctx.strokeStyle = t % 4 < 2 ? '#ffffff' : '#8ad8ff'; ctx.lineWidth = 1.5;
    for (let k = 0; k < 4; k++) {
      ctx.beginPath(); let lx = x - 28, ly = hz.y + rand(-6, 6); ctx.moveTo(lx, ly);
      while (lx < x + 28) { lx += rand(4, 9); ly = hz.y + rand(-8, 8) - rand(0, 30) * (k === 0 ? 1 : 0); ctx.lineTo(lx, ly); }
      ctx.stroke();
    }
    ctx.fillStyle = 'rgba(200,230,255,0.25)'; ctx.beginPath(); ctx.ellipse(x, hz.y, 32, 10, 0, 0, 7); ctx.fill();
  }
}
function drawBeamShadow(bm, cx) {
  if (bm.z <= 0) return;
  const k = Math.min(1, bm.t / (70 - G.diff * 6));
  ctx.fillStyle = `rgba(0,0,0,${0.2 + 0.35 * k})`;
  ctx.fillRect(bm.x - cx - 30 * k, bm.y - 4 * k, 60 * k, 8 * k);
  if (Math.floor(bm.t / 5) % 2) text('!', bm.x - cx, bm.y - 26, '#ff5a3a', 2, 1);
}
function drawBeam(bm, cx) {
  const x = bm.x - cx, y = bm.y - bm.z;
  if (bm.z > 200) return;
  const fade = bm.t > 70 + 110 ? Math.max(0, 1 - (bm.t - 180) / 40) : 1;
  ctx.globalAlpha = fade;
  // On the glazed floor what comes down is a curtain-wall panel, not a girder.
  if (G.scene.bg === 'glass') {
    px(x - 26, y - 46, 52, 48, '#39414e');
    const g = ctx.createLinearGradient(0, y - 44, 0, y - 2);
    g.addColorStop(0, '#2c2a58'); g.addColorStop(0.5, '#6a3a72'); g.addColorStop(1, '#d89864');
    ctx.fillStyle = g; ctx.fillRect(x - 23, y - 43, 46, 42);
    ctx.fillStyle = 'rgba(255,255,255,0.18)';
    ctx.beginPath(); ctx.moveTo(x - 23, y - 1); ctx.lineTo(x - 2, y - 43); ctx.lineTo(x + 8, y - 43); ctx.lineTo(x - 13, y - 1); ctx.fill();
    px(x - 26, y - 46, 52, 3, '#5c6a7c');
    px(x - 26, y - 4, 52, 3, '#2b3340');
    px(x - 3, y - 58, 6, 13, '#4a4a52');
    ctx.globalAlpha = 1;
    return;
  }
  // On the birthing floor it is a length of the feed header that comes down,
  // umbilicals still hanging off it - a girder would belong to another building.
  if (G.scene.bg === 'birth') {
    px(x - 30, y - 12, 60, 12, '#100c1c');
    px(x - 29, y - 11, 58, 10, '#2d2350');
    px(x - 29, y - 11, 58, 3, '#463a72');
    px(x - 29, y - 3, 58, 2, 'rgba(0,0,0,0.40)');
    for (let k = -22; k <= 22; k += 11) px(x + k, y - 9, 3, 6, '#1b1430');
    ctx.strokeStyle = '#6a4aa8'; ctx.lineWidth = 2;
    for (let k = -18; k <= 18; k += 12) {
      ctx.beginPath(); ctx.moveTo(x + k, y);
      ctx.quadraticCurveTo(x + k + 4, y + 8, x + k - 2, y + 15); ctx.stroke();
    }
    ctx.save(); ctx.shadowColor = '#b894ff'; ctx.shadowBlur = 7;
    px(x + 20, y - 8, 4, 4, '#b894ff'); ctx.restore();
    ctx.globalAlpha = 1;
    return;
  }
  px(x - 31, y - 9, 62, 9, '#120a14');
  px(x - 30, y - 8, 60, 7, '#b0582a');
  px(x - 30, y - 8, 60, 2, '#d8804a');
  px(x - 30, y - 3, 60, 2, '#7a3a1a');
  for (let k = -24; k <= 24; k += 12) px(x + k, y - 6, 2, 2, '#e8a070');
  ctx.globalAlpha = 1;
}
function drawDanceFloor(cx) {
  const t = Math.floor(G.frames / 20);
  const tw = 30, th = 12;
  for (let row = 0; row < 8; row++) {
    const y = 150 + row * th;
    const off = (row % 2) * (tw / 2);
    for (let col = -1; col < W / tw + 2; col++) {
      const wx = col * tw + off - (cx % tw);
      const gx = Math.floor((col * tw + off + cx) / tw);
      const hue = (gx * 7 + row * 3 + t) % 6;
      const on = (gx + row + t) % 3 === 0;
      const cols = ['#ff2a8a', '#2ad8ff', '#ffe02a', '#8a2aff', '#2aff8a', '#ff7a2a'];
      ctx.fillStyle = on ? cols[hue] : '#1a1024';
      ctx.globalAlpha = on ? 0.32 : 0.9;
      ctx.fillRect(Math.round(wx) + 1, y + 1, tw - 2, th - 2);
    }
  }
  ctx.globalAlpha = 1;
}
