// ============================================================ CITY TOOLKIT
// Assembled pieces for street and rooftop backgrounds. A block is built out of
// genuinely different buildings rather than one template recoloured, which is
// what stops a long scene reading as the same shopfront stamped over and over.
// Ground contract shared with every street scene: facades occupy y 0..142,
// pavement 140..196, kerb at 196, carriageway 201..240. The walkable band is
// 150..230, so nothing below y=150 may look solid.
const GROUND = 142, WALK = 140, CURB = 196, ROAD = 201;

// plain pixel text into any context (the game's own 5x7 atlas)
function ptext(g, str, x, y, col, s = 1) {
  str = String(str).toUpperCase();
  const a = fontAtlas(col);
  for (let i = 0; i < str.length; i++) { const k = a.idx[str[i]];
    if (k !== undefined) g.drawImage(a, k * 6, 0, 5, 7, x + i * 6 * s, y, 5 * s, 7 * s); }
}
// vertical neon, one glyph per row (blade signs down a facade)
function neonCol(g, word, x, y, c, s = 1) {
  g.save(); g.shadowColor = c; g.shadowBlur = 7 * s;
  for (let i = 0; i < word.length; i++) ptext(g, word[i], x, y + i * 9 * s, c, s);
  g.restore();
}
const tw = (str, s = 1) => str.length * 6 * s - s;

// ---- surfaces ------------------------------------------------------------
function brick(g, x, y, w, h, col, R, opts = {}) {
  g.fillStyle = col; g.fillRect(x, y, w, h);
  const ch = opts.course || 5, bw = opts.bw || 12;
  g.fillStyle = 'rgba(0,0,0,0.18)';
  for (let by = y + 2; by < y + h; by += ch) {
    g.fillRect(x, by, w, 1);
    for (let bx = x + ((Math.round((by - y) / ch)) % 2) * (bw / 2); bx < x + w; bx += bw) g.fillRect(bx, by, 1, ch);
  }
  // weathering: a few darker and lighter patches so no two walls read the same
  for (let k = 0; k < (opts.grime === false ? 0 : 14); k++) {
    g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,0.10)' : 'rgba(255,255,255,0.045)';
    g.fillRect(x + R() * w, y + R() * h, 6 + R() * 26, 3 + R() * 12);
  }
  g.fillStyle = 'rgba(0,0,0,0.32)'; g.fillRect(x + w - 3, y, 3, h);
}
function stucco(g, x, y, w, h, col, R) {
  g.fillStyle = col; g.fillRect(x, y, w, h);
  for (let k = 0; k < 40; k++) { g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,0.07)' : 'rgba(255,255,255,0.05)';
    g.fillRect(x + R() * w, y + R() * h, 2 + R() * 5, 1 + R() * 3); }
  // cracks
  g.strokeStyle = 'rgba(0,0,0,0.22)'; g.lineWidth = 1;
  for (let k = 0; k < 3; k++) { let cx = x + R() * w, cy = y + R() * h * 0.7;
    g.beginPath(); g.moveTo(cx, cy);
    for (let i = 0; i < 4; i++) { cx += (R() - 0.5) * 6; cy += 4 + R() * 6; g.lineTo(cx, cy); } g.stroke(); }
  g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x + w - 3, y, 3, h);
}
function concrete(g, x, y, w, h, col, R) {
  g.fillStyle = col; g.fillRect(x, y, w, h);
  // cast panels: each one shuttered slightly differently, with a visible seam
  const pw = 32 + R() * 10, ph = 24 + R() * 8;
  for (let py = y; py < y + h; py += ph) for (let pxx = x; pxx < x + w; pxx += pw) {
    g.fillStyle = R() < 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.06)';
    g.fillRect(pxx, py, pw - 1, ph - 1);
    g.fillStyle = 'rgba(0,0,0,0.26)'; g.fillRect(pxx, py, pw, 1.5); g.fillRect(pxx, py, 1.5, ph);
    g.fillStyle = 'rgba(255,255,255,0.05)'; g.fillRect(pxx + 1.5, py + 1.5, pw - 3, 1);
    for (let k = 0; k < 2; k++) { g.fillStyle = 'rgba(0,0,0,0.22)';                    // tie holes
      g.fillRect(pxx + 5 + k * (pw - 14), py + ph * 0.45, 2, 2); }
  }
  // rain staining running down from every seam, the thing that ages concrete
  for (let k = 0; k < w / 14; k++) {
    const sx = x + R() * w, sy = y + R() * h * 0.7;
    g.fillStyle = 'rgba(0,0,0,0.13)'; g.fillRect(sx, sy, 2 + R() * 3, 14 + R() * 34);
    g.fillStyle = 'rgba(0,0,0,0.07)'; g.fillRect(sx - 2, sy, 8, 8 + R() * 16);
  }
  for (let k = 0; k < 10; k++) { g.fillStyle = R() < 0.5 ? 'rgba(90,110,70,0.10)' : 'rgba(0,0,0,0.09)';
    g.fillRect(x + R() * w, y + R() * h, 5 + R() * 20, 3 + R() * 9); }
  // conduit and a junction box or two bolted across it
  if (R() < 0.7) { const cy2 = y + h * (0.2 + R() * 0.5);
    g.fillStyle = '#2f3540'; g.fillRect(x, cy2, w, 3);
    g.fillStyle = '#434b58'; g.fillRect(x, cy2, w, 1);
    for (let k = 0; k < w; k += 30) { g.fillStyle = '#242a33'; g.fillRect(x + k, cy2 - 1, 4, 5); }
    if (R() < 0.6) { const bx = x + R() * (w - 20);
      g.fillStyle = '#23282f'; g.fillRect(bx, cy2 - 7, 16, 14);
      g.fillStyle = '#3a4150'; g.fillRect(bx + 1, cy2 - 6, 14, 5); } }
  g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x + w - 3, y, 3, h);
}
// a painted-over advert still showing through - instant age and individuality
function ghostSign(g, x, y, w, h, word, R) {
  g.save(); g.globalAlpha = 0.16;
  g.fillStyle = '#e8e0d0'; g.fillRect(x, y, w, h);
  g.globalAlpha = 0.30;
  ptext(g, word, x + w / 2 - tw(word, 2) / 2, y + h / 2 - 7, '#f4ecd8', 2);
  g.restore();
}

// ---- windows -------------------------------------------------------------
// One window with a life of its own: lit or dark, blinds, curtains, an AC unit,
// a plant, sometimes somebody standing in it.
function windowUnit(g, x, y, w, h, R, opts = {}) {
  const lit = opts.lit === undefined ? R() < (opts.litRate || 0.38) : opts.lit;
  g.fillStyle = '#100c1a'; g.fillRect(x - 1, y - 1, w + 2, h + 2);
  const glow = opts.glow || (R() < 0.7 ? '#e8c060' : R() < 0.5 ? '#8ad0e8' : '#e8f0ff');
  g.fillStyle = lit ? glow : (opts.dark || '#241f38');
  g.fillRect(x, y, w, h);
  if (lit) {
    // the room behind: a back wall a shade darker, then furniture silhouettes
    g.fillStyle = 'rgba(0,0,0,0.18)'; g.fillRect(x, y + h * 0.55, w, h * 0.45);
    const roll = R();
    if (roll < 0.26) {                                   // somebody at the window
      const px_ = x + w * (0.3 + R() * 0.4), py = y + h;
      g.fillStyle = 'rgba(0,0,0,0.62)';
      g.fillRect(px_ - 2.5, py - h * 0.62, 5, h * 0.62);
      g.beginPath(); g.arc(px_, py - h * 0.66, 2.6, 0, 7); g.fill();
    } else if (roll < 0.42) {                            // a TV flickering
      g.fillStyle = 'rgba(160,220,255,0.55)'; g.fillRect(x + 1, y + h * 0.45, w - 2, h * 0.3);
    } else if (roll < 0.54) {                            // a plant on the sill
      g.fillStyle = '#2a6a3a'; g.fillRect(x + 1, y + h - 5, 4, 4);
      g.fillRect(x + 1.5, y + h - 8, 3, 3);
    }
  }
  if (R() < (opts.blindRate === undefined ? 0.3 : opts.blindRate)) {           // half-drawn blind
    const bh = h * (0.2 + R() * 0.45);
    g.fillStyle = 'rgba(20,16,28,0.78)'; g.fillRect(x, y, w, bh);
    for (let by = y + 1; by < y + bh; by += 2) { g.fillStyle = 'rgba(255,255,255,0.05)'; g.fillRect(x, by, w, 1); }
  }
  // frame
  g.fillStyle = '#120e1c';
  if (w >= 9) g.fillRect(x + w / 2 - 0.5, y, 1, h);
  g.fillRect(x, y + h * 0.42, w, 1);
  g.fillStyle = opts.sill || '#7a7080'; g.fillRect(x - 2, y + h, w + 4, 2);
  if (R() < (opts.acRate === undefined ? 0.12 : opts.acRate)) {                // window AC unit
    g.fillStyle = '#2a2a32'; g.fillRect(x + 1, y + h - 1, w - 2, 5);
    g.fillStyle = '#4a4a56'; g.fillRect(x + 2, y + h, w - 4, 2);
  }
}
function windowGrid(g, x, y, w, h, cols, rows, R, opts = {}) {
  const gapx = w / cols, gapy = h / rows;
  const ww = Math.max(6, gapx * (opts.fill || 0.58)), wh = Math.max(8, gapy * (opts.fillY || 0.62));
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++)
    windowUnit(g, x + c * gapx + (gapx - ww) / 2, y + r * gapy + (gapy - wh) / 2, ww, wh, R, opts);
}

// ---- architecture --------------------------------------------------------
function cornice(g, x, y, w, col, dep = 5) {
  g.fillStyle = col; g.fillRect(x - 3, y, w + 6, dep);
  g.fillStyle = 'rgba(255,255,255,0.14)'; g.fillRect(x - 3, y, w + 6, 1);
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x - 3, y + dep, w + 6, 2);
  for (let bx = x; bx < x + w; bx += 9) { g.fillStyle = 'rgba(0,0,0,0.22)'; g.fillRect(bx, y + 1, 2, dep - 2); }
}
function fireEscape(g, x, y, w, floors, R, col = '#16121c') {
  g.fillStyle = col;
  for (let f = 0; f < floors; f++) {
    const fy = y + f * 26;
    g.fillRect(x, fy, w, 2);                       // platform
    g.fillRect(x, fy - 9, 1, 9); g.fillRect(x + w - 1, fy - 9, 1, 9);
    for (let k = 0; k < w; k += 4) g.fillRect(x + k, fy - 9, 1, 9);
    g.fillRect(x, fy - 10, w, 1);
    // the ladder down to the next platform, offset so it zig-zags
    const lx = x + (f % 2 ? w - 12 : 3);
    g.fillRect(lx, fy + 2, 1, 24); g.fillRect(lx + 9, fy + 2, 1, 24);
    for (let k = 4; k < 24; k += 5) g.fillRect(lx, fy + 2 + k, 10, 1);
    if (R() < 0.35) {                              // clutter on the platform
      g.fillStyle = pick2(R, ['#8a3a4a', '#3a6a8a', '#7a6a3a']);
      g.fillRect(x + 4 + R() * (w - 14), fy - 7, 5, 6);
      g.fillStyle = col;
    }
    if (R() < 0.25) {                              // washing line
      g.strokeStyle = 'rgba(200,200,210,0.5)'; g.lineWidth = 1;
      g.beginPath(); g.moveTo(x + w, fy - 6); g.quadraticCurveTo(x + w + 16, fy - 1, x + w + 32, fy - 7); g.stroke();
      for (let k = 0; k < 3; k++) { g.fillStyle = pick2(R, ['#d8d0c0', '#8ab8d8', '#d88a9a', '#e8d070']);
        g.fillRect(x + w + 6 + k * 9, fy - 4 + k, 5, 7); }
      g.fillStyle = col;
    }
  }
}
function stoop(g, x, y, w, R, col = '#6a5a4a') {
  const steps = 5;
  for (let s = 0; s < steps; s++) {
    g.fillStyle = s % 2 ? col : '#7a6a58';
    g.fillRect(x + s, y - s * 3, w - s * 2, 3);
  }
  g.fillStyle = '#16121c';                         // railings
  g.fillRect(x, y - 16, 1.5, 17); g.fillRect(x + w - 1.5, y - 16, 1.5, 17);
  g.fillRect(x, y - 17, w, 1.5);
  for (let k = 3; k < w - 2; k += 4) g.fillRect(x + k, y - 16, 1, 16);
  if (R() < 0.4) { g.fillStyle = '#2a6a3a'; g.fillRect(x + w + 2, y - 6, 6, 6); g.fillRect(x + w + 3, y - 10, 4, 5); }
}
function doorway(g, x, y, w, h, R, opts = {}) {
  g.fillStyle = '#100c16'; g.fillRect(x - 2, y - 2, w + 4, h + 2);
  g.fillStyle = opts.col || pick2(R, ['#3a2418', '#2a3a3a', '#4a2030', '#1e2a44']);
  g.fillRect(x, y, w, h);
  g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(x, y, w, 1);
  if (opts.glass !== false && R() < 0.6) { g.fillStyle = 'rgba(200,230,255,0.16)'; g.fillRect(x + 2, y + 3, w - 4, h * 0.34); }
  g.fillStyle = '#f2c94c'; g.fillRect(x + w - 4, y + h * 0.55, 2, 2);   // handle
  if (opts.light !== false) {                                           // door lamp + its pool
    g.fillStyle = '#f2e8a0'; g.fillRect(x + w / 2 - 3, y - 7, 6, 3);
    g.fillStyle = 'rgba(242,232,160,0.10)';
    g.beginPath(); g.moveTo(x + w / 2 - 3, y - 4); g.lineTo(x - 10, y + h + 6);
    g.lineTo(x + w + 10, y + h + 6); g.lineTo(x + w / 2 + 3, y - 4); g.fill();
  }
}
function awning(g, x, y, w, R, cols) {
  const c = cols || [pick2(R, ['#b82a3a', '#2a7a5a', '#2a4a9a', '#c87a20', '#6a2a6a']), '#e8e0d0'];
  for (let k = 0; k < w; k += 8) { g.fillStyle = (k / 8) % 2 ? c[0] : c[1]; g.fillRect(x + k, y, 8, 10); }
  g.fillStyle = 'rgba(0,0,0,0.32)'; g.fillRect(x, y + 9, w, 2);
  // scalloped edge
  for (let k = 0; k < w; k += 8) { g.fillStyle = (k / 8) % 2 ? c[0] : c[1];
    g.beginPath(); g.arc(x + k + 4, y + 11, 4, 0, Math.PI); g.fill(); }
  g.fillStyle = '#3a3440'; g.fillRect(x, y - 1, w, 1);
}
function shopWindow(g, x, y, w, h, R, opts = {}) {
  g.fillStyle = '#16121c'; g.fillRect(x - 2, y - 2, w + 4, h + 4);
  const lit = opts.lit === undefined ? R() < 0.72 : opts.lit;
  g.fillStyle = lit ? (opts.inner || '#2a3a5a') : '#141020';
  g.fillRect(x, y, w, h);
  if (lit) {
    g.fillStyle = 'rgba(255,240,200,0.12)'; g.fillRect(x, y, w, h * 0.3);
    // goods on shelves
    for (let sy = y + h * 0.35; sy < y + h - 4; sy += 9) {
      g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x + 2, sy + 7, w - 4, 1);
      for (let sx = x + 3; sx < x + w - 4; sx += 5)
        if (R() < 0.75) { g.fillStyle = pick2(R, ['#c8503a', '#3a8a5a', '#d8b040', '#6a8ac8', '#c8c0a8']);
          g.fillRect(sx, sy + 2 + R() * 2, 3, 5); }
    }
  }
  // the glass itself
  g.fillStyle = 'rgba(180,220,255,0.15)'; g.fillRect(x + 2, y + 1, 5, h - 2);
  g.fillStyle = 'rgba(180,220,255,0.09)'; g.fillRect(x + 10, y + 1, 2, h - 2);
  g.fillStyle = '#4a4458'; g.fillRect(x + w / 2 - 0.5, y, 1, h);
}

// ---- street clutter ------------------------------------------------------
function trashBags(g, x, y, R, n = 3) {
  for (let k = 0; k < n; k++) {
    const bx = x + k * 7 + R() * 2, r = 4 + R() * 2;
    g.fillStyle = '#16141c'; g.beginPath(); g.ellipse(bx, y - r * 0.6, r, r * 0.85, 0, 0, 7); g.fill();
    g.fillStyle = R() < 0.5 ? '#2a2830' : '#1e2a24';
    g.beginPath(); g.ellipse(bx, y - r * 0.7, r - 1, r * 0.8, 0, 0, 7); g.fill();
    g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(bx - 2, y - r * 1.3, 3, 2);
  }
}
function newsBox(g, x, y, R, col) {
  const c = col || pick2(R, ['#c82a3a', '#2a6ac8', '#3a8a4a', '#d8a020']);
  g.fillStyle = '#120e16'; g.fillRect(x - 1, y - 21, 13, 21);
  g.fillStyle = c; g.fillRect(x, y - 20, 11, 18);
  g.fillStyle = 'rgba(0,0,0,0.45)'; g.fillRect(x + 1, y - 18, 9, 7);
  g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillRect(x + 2, y - 17, 7, 5);
  g.fillStyle = '#16141c'; g.fillRect(x + 2, y - 2, 2, 2); g.fillRect(x + 7, y - 2, 2, 2);
}
function hydrant(g, x, y) {
  g.fillStyle = '#120a14'; g.fillRect(x - 4, y - 14, 8, 14);
  g.fillStyle = '#c8283a'; g.fillRect(x - 3, y - 13, 6, 13);
  g.fillStyle = '#120a14'; g.fillRect(x - 6, y - 9, 12, 4);
  g.fillStyle = '#e84050'; g.fillRect(x - 5, y - 8, 10, 2);
  g.fillStyle = '#e84050'; g.fillRect(x - 2, y - 17, 4, 4);
  g.fillStyle = 'rgba(255,255,255,0.22)'; g.fillRect(x - 2, y - 12, 1, 11);
}
function streetLamp(g, x, y, R, h = 100, warm = '#f2e8a0') {
  g.fillStyle = '#16121c';
  g.fillRect(x, y - h, 4, h); g.fillRect(x - 3, y - 2, 10, 3);
  g.beginPath(); g.moveTo(x, y - h); g.quadraticCurveTo(x - 4, y - h - 8, x - 14, y - h - 6);
  g.lineWidth = 3; g.strokeStyle = '#16121c'; g.stroke();
  g.fillStyle = warm; g.fillRect(x - 17, y - h - 6, 8, 3);
  g.fillStyle = 'rgba(242,232,160,0.09)';
  g.beginPath(); g.moveTo(x - 17, y - h - 3); g.lineTo(x - 34, y + 2); g.lineTo(x + 8, y + 2); g.lineTo(x - 9, y - h - 3); g.fill();
  if (R() < 0.4) { g.fillStyle = '#c8302a'; g.fillRect(x + 4, y - h * 0.55, 10, 7);   // a flyer taped on
    ptext(g, '!', x + 8, y - h * 0.55 + 1, '#fff'); }
}
function busShelter(g, x, y, R) {
  g.fillStyle = '#16141c'; g.fillRect(x, y - 38, 54, 3);
  g.fillRect(x, y - 38, 2, 38); g.fillRect(x + 52, y - 38, 2, 38);
  g.fillStyle = 'rgba(170,210,255,0.14)'; g.fillRect(x + 2, y - 35, 50, 33);
  g.fillStyle = 'rgba(255,255,255,0.08)'; g.fillRect(x + 6, y - 34, 4, 31);
  // lit advert panel
  g.fillStyle = '#16141c'; g.fillRect(x + 36, y - 34, 17, 30);
  g.fillStyle = pick2(R, ['#e8b8c0', '#b8d8e8', '#e8d8a0']); g.fillRect(x + 37, y - 33, 15, 28);
  g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x + 39, y - 26, 11, 14);
  g.fillStyle = '#16141c'; g.fillRect(x + 4, y - 12, 28, 3);   // bench
  g.fillRect(x + 6, y - 9, 2, 9); g.fillRect(x + 28, y - 9, 2, 9);
}
function parkedCar(g, x, y, R, col) {
  const c = col || pick2(R, ['#7a2a30', '#2a4a6a', '#3a3a42', '#6a6a58', '#2a5a4a', '#8a7a30']);
  const O = '#120a14';
  g.fillStyle = O; g.fillRect(x - 30, y - 20, 60, 16);
  g.fillStyle = c; g.fillRect(x - 29, y - 19, 58, 14);
  g.fillStyle = O; g.fillRect(x - 17, y - 28, 32, 9);
  g.fillStyle = c; g.fillRect(x - 16, y - 27, 30, 8);
  g.fillStyle = '#1e2a3a'; g.fillRect(x - 14, y - 26, 12, 6); g.fillRect(x + 1, y - 26, 12, 6);
  g.fillStyle = 'rgba(255,255,255,0.14)'; g.fillRect(x - 29, y - 19, 58, 1);
  g.fillStyle = O; g.fillRect(x - 30, y - 8, 60, 3);
  for (const wx of [-19, 18]) { g.fillStyle = O; g.beginPath(); g.arc(x + wx, y - 4, 6, 0, 7); g.fill();
    g.fillStyle = '#4a4a52'; g.beginPath(); g.arc(x + wx, y - 4, 2.6, 0, 7); g.fill(); }
  g.fillStyle = '#e8e0b0'; g.fillRect(x - 31, y - 15, 3, 4);
  g.fillStyle = '#c83030'; g.fillRect(x + 28, y - 15, 3, 4);
}
function steamGrate(g, x, y, frames, R) {
  g.fillStyle = '#1a1820'; g.fillRect(x - 12, y - 2, 24, 5);
  for (let k = -11; k < 11; k += 3) { g.fillStyle = '#3a3844'; g.fillRect(x + k, y - 1, 2, 3); }
}
function trafficLight(g, x, y, R, phase = 0) {
  g.fillStyle = '#16141c';
  g.fillRect(x, y - 86, 4, 86); g.fillRect(x - 3, y - 2, 10, 3);
  g.fillRect(x + 2, y - 86, 34, 3);
  g.fillRect(x + 30, y - 86, 9, 24);
  const on = ['#e02a3a', '#e8c040', '#3ae05a'][phase % 3];
  for (let k = 0; k < 3; k++) { g.fillStyle = k === phase % 3 ? on : '#201c24';
    g.beginPath(); g.arc(x + 34.5, y - 80 + k * 7, 2.6, 0, 7); g.fill(); }
  g.fillStyle = 'rgba(224,42,58,0.10)';
  g.beginPath(); g.arc(x + 34.5, y - 80 + (phase % 3) * 7, 7, 0, 7); g.fill();
}
function crates(g, x, y, R, n = 3) {
  for (let k = 0; k < n; k++) {
    const w = 11 + R() * 5, h = 8 + R() * 4, cx = x + k * 12, cy = y - (k % 2) * h;
    g.fillStyle = '#16121c'; g.fillRect(cx - 1, cy - h - 1, w + 2, h + 2);
    g.fillStyle = pick2(R, ['#7a5a34', '#6a4a2a', '#8a6a40']); g.fillRect(cx, cy - h, w, h);
    g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(cx, cy - h * 0.55, w, 1.5);
    g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(cx, cy - h, w, 1);
  }
}
function dumpster(g, x, y, R) {
  g.fillStyle = '#120e14'; g.fillRect(x, y - 30, 52, 30);
  g.fillStyle = pick2(R, ['#2a5a3a', '#2a4a6a', '#6a3a2a']); g.fillRect(x + 1, y - 28, 50, 27);
  g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x + 1, y - 28, 50, 5);
  g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(x + 1, y - 28, 50, 1);
  g.fillStyle = '#e8e0d0'; g.fillRect(x + 20, y - 18, 12, 5);
  g.fillStyle = '#120e14'; g.beginPath(); g.arc(x + 8, y - 1, 3, 0, 7); g.arc(x + 44, y - 1, 3, 0, 7); g.fill();
  if (R() < 0.6) trashBags(g, x + 54, y, R, 2);
}
function pigeon(g, x, y, R, col = '#4a4a56') {
  g.fillStyle = col; g.beginPath(); g.ellipse(x, y - 2, 3, 2, 0, 0, 7); g.fill();
  g.beginPath(); g.arc(x + 2.4, y - 4, 1.4, 0, 7); g.fill();
  g.fillStyle = '#c8a040'; g.fillRect(x + 3.6, y - 4, 1.5, 1);
  g.fillStyle = 'rgba(255,255,255,0.22)'; g.fillRect(x - 1, y - 3, 2, 1);
}
function puddles(g, R, w, y0, y1, n = 10, col = 'rgba(120,140,200,0.25)') {
  for (let k = 0; k < n; k++) { g.fillStyle = col;
    g.beginPath(); g.ellipse(R() * w, y0 + R() * (y1 - y0), 10 + R() * 16, 2 + R() * 3, 0, 0, 7); g.fill(); }
}
function graffiti(g, x, y, R, w = 40) {
  g.strokeStyle = pick2(R, ['#e84a8a', '#4ae88a', '#e8e84a', '#8ab8ff', '#ff8a2a']);
  g.lineWidth = 2 + R() * 1.5;
  g.beginPath(); let gx = x, gy = y; g.moveTo(gx, gy);
  for (let k = 0; k < 7; k++) { gx += w / 7; g.lineTo(gx, gy + (R() - 0.5) * 14); }
  g.stroke();
}

// (ground contract declared at the top of this file)

function bldgBrownstone(g, x, w, R) {
  const top = 12 + R() * 16;
  const wall = pick2(R, ['#6a3a2e', '#5a3228', '#73402f', '#4e3630']);
  brick(g, x, top, w, GROUND - top, wall, R, { course: 4, bw: 10 });
  cornice(g, x, top, w, '#7d4a38', 6);
  // tall sash windows in two storeys, stone lintels above each
  for (let row = 0; row < 2; row++) {
    const wy = top + 16 + row * 34;
    const n = Math.max(2, Math.floor(w / 26));
    for (let i = 0; i < n; i++) {
      const wx = x + 8 + i * ((w - 16) / n);
      g.fillStyle = '#8a6a58'; g.fillRect(wx - 3, wy - 4, 16, 3);
      windowUnit(g, wx, wy, 10, 20, R, { litRate: 0.45, sill: '#8a6a58' });
    }
  }
  // parlour floor: door up a stoop, garden level below it
  const dx = x + w * 0.58;
  g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(x, GROUND - 34, w, 34);
  doorway(g, dx, GROUND - 40, 15, 28, R, { col: '#3a2418' });
  stoop(g, dx - 4, GROUND, 23, R);
  g.fillStyle = '#16121c'; g.fillRect(x + 6, GROUND - 20, 14, 18);     // garden-level window
  g.fillStyle = R() < 0.5 ? '#e8c060' : '#241f38'; g.fillRect(x + 8, GROUND - 18, 10, 14);
  for (let k = 8; k < 19; k += 3) { g.fillStyle = '#16121c'; g.fillRect(x + k, GROUND - 19, 1, 16); }  // bars
  if (R() < 0.5) fireEscape(g, x + 4, top + 30, 18, 2, R);
}

function bldgBodega(g, x, w, R) {
  const top = 26 + R() * 14;
  stucco(g, x, top, w, GROUND - top, pick2(R, ['#8a6a3a', '#7a5a4a', '#6a6a52']), R);
  cornice(g, x, top, w, '#4a3a2a', 4);
  windowGrid(g, x + 6, top + 12, w - 12, 34, Math.max(2, Math.round(w / 30)), 1, R, { litRate: 0.5 });
  // shopfront: awning, window full of goods, door, crates and a cooler outside
  const sx = x + 4, sw = w - 8;
  g.fillStyle = '#16121c'; g.fillRect(sx, GROUND - 58, sw, 58);
  awning(g, sx, GROUND - 60, sw, R);
  shopWindow(g, sx + 4, GROUND - 42, sw * 0.56, 34, R, { inner: '#3a4a2a' });
  doorway(g, sx + sw * 0.68, GROUND - 42, 17, 40, R);
  const word = pick2(R, ['MARKET', 'GROCERY', 'DELI', 'BODEGA', 'FRUIT']);
  g.fillStyle = '#0c0a12'; g.fillRect(sx + 2, GROUND - 72, sw - 4, 11);
  neonText(g, word, sx + sw / 2 - tw(word) / 2, GROUND - 70, pick2(R, ['#ff4a8a', '#4ae8ff', '#e8ff4a', '#ff8a2a']));
  crates(g, x + w * 0.1, WALK + 44, R, 3);
  g.fillStyle = '#d8d0c8'; g.fillRect(x + w * 0.64, WALK + 30, 14, 16);   // ice cooler
  g.fillStyle = '#2a6ac8'; g.fillRect(x + w * 0.64, WALK + 30, 14, 5);
  ptext(g, 'ICE', x + w * 0.64 + 1, WALK + 36, '#e8f0ff');
}

function bldgTheatre(g, x, w, R) {
  const top = 8;
  g.fillStyle = '#3a2a3e'; g.fillRect(x, top, w, GROUND - top);
  for (let k = 0; k < 40; k++) { g.fillStyle = 'rgba(0,0,0,0.08)'; g.fillRect(x + R() * w, top + R() * (GROUND - top), 4 + R() * 16, 2 + R() * 7); }
  cornice(g, x, top, w, '#5a4460', 7);
  // arched upper windows, mostly dark - the place is half shut
  const n = Math.max(3, Math.round(w / 34));
  for (let i = 0; i < n; i++) {
    const wx = x + 10 + i * ((w - 20) / n), wy = top + 20;
    g.fillStyle = '#16121c'; g.beginPath(); g.moveTo(wx, wy + 26); g.lineTo(wx, wy + 8);
    g.arc(wx + 7, wy + 8, 7, Math.PI, 0); g.lineTo(wx + 14, wy + 26); g.fill();
    g.fillStyle = R() < 0.22 ? '#c8a050' : '#221c30';
    g.beginPath(); g.moveTo(wx + 2, wy + 24); g.lineTo(wx + 2, wy + 8);
    g.arc(wx + 7, wy + 8, 5, Math.PI, 0); g.lineTo(wx + 12, wy + 24); g.fill();
  }
  // vertical blade sign, half its bulbs dead
  const bx = x + w * 0.12;
  g.fillStyle = '#12101a'; g.fillRect(bx - 11, top + 2, 22, 78);
  const title = pick2(R, ['ORPHEUM', 'RIALTO', 'ROXY', 'PALACE']);
  neonCol(g, title.slice(0, 7), bx - 3, top + 8, '#ff3a6a', 1);
  for (let k = 0; k < 9; k++) {
    const on = R() < 0.62;
    g.fillStyle = on ? '#ffe08a' : '#2a2430';
    g.fillRect(bx - 10, top + 8 + k * 8, 2, 2); g.fillRect(bx + 8, top + 8 + k * 8, 2, 2);
  }
  // marquee over the pavement
  const mx = x + 6, mw = w - 12, my = GROUND - 56;
  g.fillStyle = '#16121c'; g.fillRect(mx, my, mw, 20);
  g.fillStyle = '#241c2e'; g.fillRect(mx + 2, my + 2, mw - 4, 16);
  for (let k = mx + 3; k < mx + mw - 3; k += 6) {
    g.fillStyle = R() < 0.7 ? '#ffe08a' : '#3a3040';
    g.fillRect(k, my - 2, 3, 3); g.fillRect(k, my + 19, 3, 3);
  }
  const line = pick2(R, ['CLOSED', 'ONE NIGHT', 'TONIGHT', 'SOLD OUT']);
  ptext(g, line, mx + mw / 2 - tw(line) / 2, my + 7, '#e8d8a0');
  // boarded doors and poster cases
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x, GROUND - 36, w, 36);
  for (let k = 0; k < 3; k++) {
    const dx = x + w * (0.3 + k * 0.17);
    g.fillStyle = '#2a1e24'; g.fillRect(dx, GROUND - 34, 14, 34);
    g.fillStyle = '#6a5a44';
    g.save(); g.translate(dx + 7, GROUND - 17); g.rotate(-0.22); g.fillRect(-10, -2, 20, 4); g.restore();
  }
  for (let k = 0; k < 2; k++) {
    const px_ = x + w * (0.06 + k * 0.78);
    g.fillStyle = '#16121c'; g.fillRect(px_, GROUND - 44, 16, 26);
    g.fillStyle = pick2(R, ['#8a2a3a', '#2a4a8a', '#6a2a6a']); g.fillRect(px_ + 1, GROUND - 43, 14, 24);
    g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(px_ + 3, GROUND - 38, 10, 12);
  }
}

function bldgTenement(g, x, w, R) {
  const top = 4 + R() * 10;
  const wall = pick2(R, ['#5a4a52', '#4a4458', '#63483e', '#41404f']);
  brick(g, x, top, w, GROUND - top, wall, R, { course: 5, bw: 11 });
  cornice(g, x, top, w, '#2e2836', 5);
  if (R() < 0.45) ghostSign(g, x + 6, top + 14, w - 12, 30, pick2(R, ['COAL', 'CIGARS', 'HOTEL', 'TONIC']), R);
  const cols = Math.max(3, Math.round(w / 22)), rows = 4;
  windowGrid(g, x + 4, top + 12, w - 8, GROUND - top - 50, cols, rows, R, { litRate: 0.42, acRate: 0.2, blindRate: 0.34 });
  // fire escapes are the signature - two zig-zag runs down the face
  fireEscape(g, x + w * 0.16, top + 30, 22, 3, R);
  if (w > 120) fireEscape(g, x + w * 0.62, top + 30, 22, 3, R);
  // street level: a shuttered shop and a stair down to a basement door
  g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(x, GROUND - 38, w, 38);
  const sx = x + 8, sw = w * 0.42;
  g.fillStyle = '#2a2830'; g.fillRect(sx, GROUND - 34, sw, 34);
  for (let k = 0; k < sw; k += 4) { g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(sx + k, GROUND - 34, 2, 34); }
  graffiti(g, sx + 4, GROUND - 16, R, sw - 10);
  doorway(g, x + w * 0.62, GROUND - 34, 16, 34, R, { col: '#2a3a3a' });
}

function bldgGarage(g, x, w, R) {
  const top = 18;
  concrete(g, x, top, w, GROUND - top, '#4e4a54', R);
  // open parking decks - rows of dark slots with a car or two parked in them
  for (let row = 0; row < 3; row++) {
    const ry = top + 12 + row * 30;
    g.fillStyle = '#100e16'; g.fillRect(x + 4, ry, w - 8, 20);
    g.fillStyle = '#2a2833'; g.fillRect(x + 4, ry + 17, w - 8, 3);
    for (let k = 0; k < 3; k++) if (R() < 0.55) {
      const cx = x + 12 + k * ((w - 24) / 3);
      g.fillStyle = pick2(R, ['#5a2a30', '#2a3a5a', '#3a3a42']); g.fillRect(cx, ry + 9, 20, 7);
      g.fillStyle = 'rgba(0,0,0,0.5)'; g.fillRect(cx + 3, ry + 5, 13, 5);
    }
    g.fillStyle = '#6a6a78'; g.fillRect(x + 4, ry + 20, w - 8, 2);      // deck edge
    g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(x + 4, ry + 20, w - 8, 1);
    if (R() < 0.7) { g.fillStyle = '#d8f0ff'; g.fillRect(x + 10 + R() * (w - 30), ry + 1, 12, 2);
      g.fillStyle = 'rgba(200,240,255,0.10)'; g.fillRect(x + 6, ry + 3, w - 12, 12); }
  }
  // the mouth: a ramp, a striped barrier and a booth
  const mx = x + w * 0.24, mw = w * 0.5;
  g.fillStyle = '#0c0a12'; g.fillRect(mx, GROUND - 40, mw, 40);
  g.fillStyle = '#16141e'; g.fillRect(mx + 3, GROUND - 37, mw - 6, 37);
  g.fillStyle = 'rgba(255,220,120,0.10)'; g.fillRect(mx + 3, GROUND - 24, mw - 6, 24);
  for (let k = 0; k < mw; k += 12) { g.fillStyle = (k / 12) % 2 ? '#e8b020' : '#1a1a1e'; g.fillRect(mx + k, GROUND - 43, 12, 4); }
  g.fillStyle = '#2a2a34'; g.fillRect(mx - 14, GROUND - 26, 13, 26);    // booth
  g.fillStyle = '#e8d070'; g.fillRect(mx - 12, GROUND - 22, 9, 9);
  g.fillStyle = '#c8302a'; g.fillRect(mx + mw + 2, GROUND - 20, 3, 20); // barrier post
  for (let k = 0; k < 22; k += 6) { g.fillStyle = (k / 6) % 2 ? '#e8e8e8' : '#c8302a'; g.fillRect(mx + mw + 5, GROUND - 18 + 0, 6, 3); }
  const price = '$' + (2 + Math.floor(R() * 8)) + '.00';
  g.fillStyle = '#12101a'; g.fillRect(x + w * 0.05, GROUND - 60, 46, 16);
  ptext(g, 'PARK', x + w * 0.05 + 4, GROUND - 58, '#e8e8f0');
  ptext(g, price, x + w * 0.05 + 4, GROUND - 50, '#f2c94c');
}

function bldgVacantLot(g, x, w, R) {
  // sky and the backs of the buildings behind - a hole in the block
  g.fillStyle = 'rgba(0,0,0,0)'; g.clearRect(x, 0, w, GROUND - 46);
  g.fillStyle = '#1a1630';
  for (let bx = x; bx < x + w; bx += 22 + R() * 18) {
    const bh = 40 + R() * 50; g.fillRect(bx, GROUND - 46 - bh, 16 + R() * 20, bh + 46);
  }
  for (let k = 0; k < 40; k++) { g.fillStyle = R() < 0.6 ? '#d8b050' : '#6aa0e0'; g.fillRect(x + R() * w, GROUND - 90 + R() * 44, 1, 1); }
  // the party wall of the surviving neighbour, with the ghost of stairs on it
  g.fillStyle = '#3a2e34'; g.fillRect(x + w - 10, 20, 10, GROUND - 20);
  g.fillStyle = 'rgba(255,255,255,0.05)';
  for (let k = 0; k < 6; k++) g.fillRect(x + w - 9, 40 + k * 16, 8, 9);
  // plywood hoarding, fly-posted
  g.fillStyle = '#6a5a44'; g.fillRect(x, GROUND - 46, w, 46);
  for (let k = 0; k < w; k += 15) { g.fillStyle = 'rgba(0,0,0,0.20)'; g.fillRect(x + k, GROUND - 46, 1, 46); }
  for (let k = 0; k < 5; k++) {
    const px_ = x + 4 + R() * (w - 26);
    g.save(); g.translate(px_, GROUND - 40 + R() * 16); g.rotate((R() - 0.5) * 0.18);
    g.fillStyle = pick2(R, ['#c8303a', '#2a5ac8', '#e8c030', '#2a8a5a', '#e8e8e8']);
    g.fillRect(0, 0, 15, 20);
    g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(2, 3, 11, 8);
    g.restore();
  }
  graffiti(g, x + 8, GROUND - 14, R, w - 20);
  g.fillStyle = '#2a3a22';                               // weeds through the gap
  for (let k = 0; k < 14; k++) { const wx = x + R() * w; g.fillRect(wx, GROUND - 4, 1, -3 - R() * 5); }
}

function bldgDiner(g, x, w, R) {
  const top = 46 + R() * 10;
  // low chrome-and-glass box, warm inside, the brightest thing on the block
  g.fillStyle = '#2a2e38'; g.fillRect(x, top, w, GROUND - top);
  g.fillStyle = '#c8ccd8'; g.fillRect(x, top, w, 5);
  g.fillStyle = '#8a90a0'; g.fillRect(x, top + 5, w, 2);
  for (let k = 0; k < w; k += 10) { g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(x + k, top + 1, 4, 3); }
  const band = top + 10;
  g.fillStyle = '#a02a36'; g.fillRect(x, band, w, 12);
  const name = pick2(R, ['MERCY DINER', 'ALL NITE', 'THE ANCHOR', 'CORNER CAFE']);
  neonText(g, name, x + w / 2 - tw(name) / 2, band + 3, '#ffe8c0');
  // the glass front: booths, a counter, backlit and full of people-shapes
  const gy = band + 16, gh = GROUND - gy - 4;
  g.fillStyle = '#16141c'; g.fillRect(x + 3, gy, w - 6, gh);
  g.fillStyle = '#e8c878'; g.fillRect(x + 5, gy + 2, w - 10, gh - 4);
  g.fillStyle = 'rgba(0,0,0,0.20)'; g.fillRect(x + 5, gy + gh * 0.6, w - 10, gh * 0.4);
  for (let k = 0; k < Math.floor(w / 26); k++) {
    const bx = x + 10 + k * 26;
    g.fillStyle = '#8a3a3a'; g.fillRect(bx, gy + gh * 0.34, 7, gh * 0.5);      // booth back
    if (R() < 0.7) { g.fillStyle = 'rgba(0,0,0,0.55)';                          // a customer
      g.fillRect(bx + 9, gy + gh * 0.42, 5, gh * 0.4);
      g.beginPath(); g.arc(bx + 11.5, gy + gh * 0.40, 2.6, 0, 7); g.fill(); }
  }
  g.fillStyle = 'rgba(255,255,255,0.18)'; g.fillRect(x + 8, gy + 2, 5, gh - 4);
  for (let k = 0; k < w; k += 18) { g.fillStyle = '#4a4e5a'; g.fillRect(x + k, gy, 2, gh); }
  // a neon COFFEE cup on the roof and stools at the window
  const cx = x + w * 0.8;
  neonText(g, 'OPEN', x + 8, top - 10, '#4ae8ff');
  g.fillStyle = '#12101a'; g.fillRect(cx - 12, top - 26, 26, 22);
  neonText(g, 'EAT', cx - 8, top - 20, '#ffe04a');
}

const STREET_BUILDINGS = [
  { f: bldgBrownstone, w: [118, 160] }, { f: bldgBodega, w: [104, 140] },
  { f: bldgTheatre, w: [150, 200] },    { f: bldgTenement, w: [132, 186] },
  { f: bldgGarage, w: [126, 168] },     { f: bldgVacantLot, w: [86, 120] },
  { f: bldgDiner, w: [116, 150] },
];
// Walk a block choosing buildings without repeating the last two, so the
// street never reads as one template stamped over and over.
function blockRun(g, from, to, R, r, pool = STREET_BUILDINGS) {
  let x = from; const recent = [];
  while (x < to) {
    let pick, guard = 0;
    do { pick = Math.floor(R() * pool.length); } while (recent.includes(pick) && guard++ < 12);
    recent.push(pick); if (recent.length > 2) recent.shift();
    const b = pool[pick], w = Math.min(r(b.w[0], b.w[1]), to - x + 40);
    b.f(g, x, w, R);
    x += w;
  }
}

function skyGrad(f, L, stops) {
  const sky = f.createLinearGradient(0, 0, 0, 150);
  stops.forEach(([p, c]) => sky.addColorStop(p, c));
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
}
function stars(f, L, R, r, n = 90, top = 74) {
  for (let i = 0; i < n; i++) { f.fillStyle = R() < 0.3 ? '#fff' : '#8a88b0'; f.fillRect(r(0, L.far.width), r(0, top), 1, 1); }
}
function skyline(f, L, R, r, base, col, lit, hMin = 40, hMax = 105) {
  for (let x = 0; x < L.far.width;) {
    const bw = r(18, 46), bh = r(hMin, hMax);
    f.fillStyle = col; f.fillRect(x, base - bh, bw, bh + 22);
    for (let wy = base - bh + 4; wy < base - 4; wy += 6) for (let wx = x + 3; wx < x + bw - 3; wx += 5)
      if (R() < 0.2) { f.fillStyle = R() < 0.7 ? lit : '#80c0e8'; f.fillRect(wx, wy, 2, 2); }
    if (R() < 0.18) { f.fillStyle = '#e8283a'; f.fillRect(x + bw / 2, base - bh - 6, 1, 6); f.fillRect(x + bw / 2 - 1, base - bh - 7, 3, 2); }
    x += bw + r(0, 7);
  }
}
// The pavement, kerb and carriageway. Every street option shares this contract
// so the walkable band never changes.
function paveAndRoad(n, L, R, r, opts = {}) {
  const P = opts.pave || '#4a4556', P2 = opts.pave2 || '#544e62', P3 = opts.pave3 || '#3a3644';
  n.fillStyle = P; n.fillRect(0, WALK, L.near.width, CURB - WALK + 3);
  // flagstones, with a few cracked and a few replaced in a different shade
  for (let y = WALK + 2; y < CURB; y += 13) n.fillStyle = P2, n.fillRect(0, y, L.near.width, 11);
  // individual flags: a few replaced, a few sunken, a few cracked right through
  for (let xx = 0; xx < L.near.width; xx += 26) {
    n.fillStyle = P3; n.fillRect(xx + ((xx / 26) % 2) * 6, WALK, 1, CURB - WALK);
    for (let fy = WALK + 2; fy < CURB; fy += 13) {
      const roll = R();
      if (roll < 0.10) { n.fillStyle = 'rgba(0,0,0,0.15)'; n.fillRect(xx, fy, 25, 11); }
      else if (roll < 0.17) { n.fillStyle = 'rgba(255,255,255,0.055)'; n.fillRect(xx, fy, 25, 11); }
      else if (roll < 0.22) { n.strokeStyle = 'rgba(0,0,0,0.30)'; n.lineWidth = 1;
        n.beginPath(); n.moveTo(xx + 2, fy + R() * 10); n.lineTo(xx + 12, fy + R() * 10); n.lineTo(xx + 23, fy + R() * 10); n.stroke(); }
    }
  }
  // gum, stains and litter - the grain that stops it reading as a flat slab
  for (let k = 0; k < L.near.width / 6; k++) {
    n.fillStyle = 'rgba(0,0,0,0.13)';
    n.beginPath(); n.arc(r(0, L.near.width), r(WALK + 6, CURB - 4), 1 + R() * 1.6, 0, 7); n.fill();
  }
  for (let k = 0; k < L.near.width / 40; k++) {
    n.fillStyle = pick2(R, ['rgba(220,214,196,0.5)', 'rgba(190,180,160,0.45)', 'rgba(150,170,180,0.4)']);
    n.save(); n.translate(r(0, L.near.width), r(WALK + 8, CURB - 6)); n.rotate(R() * 3);
    n.fillRect(0, 0, 3 + R() * 5, 2 + R() * 2); n.restore();
  }
  n.fillStyle = opts.kerbTop || '#3a3448'; n.fillRect(0, WALK, L.near.width, 2);
  // tree pits, grates and manhole covers punched into the pavement
  for (let xx = 40; xx < L.near.width; xx += 150 + R() * 90) {
    if (R() < 0.5) { n.fillStyle = '#231f28'; n.fillRect(xx, CURB - 20, 18, 14);
      for (let k = 0; k < 18; k += 3) { n.fillStyle = '#3a3642'; n.fillRect(xx + k, CURB - 19, 2, 12); } }
    else { n.fillStyle = '#2a2730'; n.beginPath(); n.ellipse(xx, CURB - 12, 9, 4, 0, 0, 7); n.fill();
      n.strokeStyle = '#4a4552'; n.lineWidth = 1; n.beginPath(); n.ellipse(xx, CURB - 12, 9, 4, 0, 0, 7); n.stroke(); }
  }
  n.fillStyle = opts.kerb || '#b8b0c0'; n.fillRect(0, CURB, L.near.width, 3);
  n.fillStyle = '#8a8298'; n.fillRect(0, CURB + 3, L.near.width, 2);
  n.fillStyle = opts.road || '#2a2834'; n.fillRect(0, ROAD, L.near.width, 240 - ROAD);
  for (let k = 0; k < L.near.width * 1.4; k++) { n.fillStyle = R() < 0.5 ? (opts.road2 || '#32303e') : (opts.road3 || '#24222e');
    n.fillRect(r(0, L.near.width), r(ROAD + 1, 240), 2, 1); }
  // worn tyre tracks down the lane, and drain grates at the kerb
  for (const ty of [214, 232]) for (let xx = 0; xx < L.near.width; xx += 2) {
    if (R() < 0.55) { n.fillStyle = 'rgba(255,255,255,0.028)'; n.fillRect(xx, ty, 2, 5); }
  }
  for (let xx = 60; xx < L.near.width; xx += 190 + R() * 120) {
    n.fillStyle = '#1c1a22'; n.fillRect(xx, ROAD + 1, 22, 6);
    for (let k = 0; k < 22; k += 4) { n.fillStyle = '#34323e'; n.fillRect(xx + k, ROAD + 2, 2, 4); }
    n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(xx - 6, ROAD + 5, 34, 4);
  }
  for (let k = 0; k < L.near.width / 260; k++) {                       // oil stains
    n.fillStyle = 'rgba(0,0,0,0.26)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(ROAD + 8, 234), 12 + R() * 16, 4 + R() * 4, 0, 0, 7); n.fill();
  }
  // patched repairs and a worn centre line
  for (let k = 0; k < L.near.width / 200; k++) { n.fillStyle = 'rgba(0,0,0,0.22)';
    n.fillRect(r(0, L.near.width), r(ROAD + 4, 232), 30 + R() * 50, 8 + R() * 10); }
  if (opts.line !== false) { n.fillStyle = opts.lineCol || '#e8c040';
    for (let xx = 0; xx < L.near.width; xx += 40) n.fillRect(xx, 226, 22, 2); }
}
// A crossing: the stripes, a light on the corner and a change of rhythm.
function crossing(n, x, R, opts = {}) {
  n.fillStyle = 'rgba(232,232,224,0.85)';
  for (let k = 0; k < 7; k++) n.fillRect(x + k * 9, ROAD + 4, 6, 240 - ROAD - 6);
  n.fillStyle = opts.kerb || '#b8b0c0'; n.fillRect(x - 6, CURB, 76, 3);
  // dropped kerb and a drain at the corner
  n.fillStyle = '#2a2730'; n.fillRect(x + 66, CURB - 4, 12, 5);
}

// ---- small street furniture
function g_mailbox(n, x, y, R) {
  n.fillStyle = '#120e16'; n.fillRect(x - 8, y - 24, 17, 24);
  n.fillStyle = '#2a5a8a'; n.fillRect(x - 7, y - 23, 15, 21);
  n.beginPath(); n.arc(x + 0.5, y - 23, 7.5, Math.PI, 0); n.fill();
  n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(x - 5, y - 20, 11, 3);
  n.fillStyle = '#16141c'; n.fillRect(x - 6, y - 2, 3, 2); n.fillRect(x + 4, y - 2, 3, 2);
}
function g_phonebooth(n, x, y, R) {
  n.fillStyle = '#16141c'; n.fillRect(x - 10, y - 46, 21, 46);
  n.fillStyle = '#1e3a5a'; n.fillRect(x - 9, y - 45, 19, 44);
  n.fillStyle = 'rgba(190,225,255,0.20)'; n.fillRect(x - 7, y - 40, 15, 30);
  n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(x - 5, y - 39, 4, 28);
  n.fillStyle = '#e8e8f0'; n.fillRect(x - 9, y - 50, 19, 5);
  ptext(n, 'PHONE', x - 8, y - 49, '#2a3a6a');
  n.fillStyle = '#12101a'; n.fillRect(x + 1, y - 30, 6, 12);
}


// ============================================================ STAGE 1-A: under the elevated
// ---- A3: UNDER THE ELEVATED ----------------------------------------------
// The street runs beneath an el line. Steel columns march past in the
// foreground, a train thunders over in the mid layer, and the light is all
// sodium pooling between the girders.
function elevatedBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#08060f'], [0.6, '#241a33'], [1, '#4a2a3e']]);
  stars(f, L, R, r, 60, 60);
  skyline(f, L, R, r, 126, '#120e22', '#d8a048', 30, 80);
  // mid: the underside of the elevated deck, seen further down the avenue.
  // The train itself is drawn live over the top, so it can actually pass.
  m.fillStyle = '#1a1622'; m.fillRect(0, 54, L.mid.width, 22);
  m.fillStyle = '#26202e'; m.fillRect(0, 54, L.mid.width, 3);
  for (let x = 0; x < L.mid.width; x += 12) { m.fillStyle = 'rgba(0,0,0,0.35)'; m.fillRect(x, 57, 2, 19); }
  for (let x = 0; x < L.mid.width; x += 150) {         // the far row of trestles
    m.fillStyle = '#151220'; m.fillRect(x, 76, 7, 74);
    m.strokeStyle = '#151220'; m.lineWidth = 3;
    m.beginPath(); m.moveTo(x + 3, 86); m.lineTo(x + 74, 78); m.stroke();
    m.beginPath(); m.moveTo(x + 3, 86); m.lineTo(x - 68, 78); m.stroke();
  }
  // buildings glimpsed between the trestles, so the middle distance is not empty
  for (let x = 0; x < L.mid.width;) {
    const bw = r(44, 82), bh = r(40, 74);
    m.fillStyle = '#211a34'; m.fillRect(x, 150 - bh, bw, bh);
    for (let wy = 150 - bh + 6; wy < 146; wy += 10) for (let wx = x + 5; wx < x + bw - 6; wx += 9)
      if (R() < 0.26) { m.fillStyle = '#c8a860'; m.fillRect(wx, wy, 4, 5); }
    x += bw + r(6, 22);
  }
  blockRun(n, 0, len - 300, R, r);
  // the end of the run: the line widens into a station, and the fight happens
  // in the lit space underneath it with the stair coming down into the street.
  const u0 = len - 320;
  n.fillStyle = '#0c0a14'; n.fillRect(u0, 0, L.near.width - u0, GROUND);
  for (let k = 0; k < 50; k++) { n.fillStyle = '#c8a048'; n.fillRect(r(u0, L.near.width), r(46, 118), 1, 1); }
  // the platform box overhead, its underside lit, adverts along the fascia
  n.fillStyle = '#1c1826'; n.fillRect(u0 - 20, 40, L.near.width - u0 + 40, 40);
  n.fillStyle = '#2a2434'; n.fillRect(u0 - 20, 6, L.near.width - u0 + 40, 4);
  n.fillStyle = '#100d18'; n.fillRect(u0 - 20, 80, L.near.width - u0 + 40, 6);
  for (let ax = u0; ax < L.near.width; ax += 88) {
    n.fillStyle = '#16131e'; n.fillRect(ax, 46, 62, 28);
    n.fillStyle = pick2(R, ['#b8485a', '#3a6a9a', '#c8a030', '#3a8a6a']); n.fillRect(ax + 2, 48, 58, 24);
    n.fillStyle = 'rgba(0,0,0,0.32)'; n.fillRect(ax + 6, 53, 30, 14);
    n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(ax + 2, 48, 58, 2);
  }
  for (let lx = u0 + 24; lx < L.near.width; lx += 64) {   // strip lights under the platform
    n.fillStyle = '#ffeec0'; n.fillRect(lx, 82, 34, 3);
    n.fillStyle = 'rgba(255,238,192,0.09)'; n.fillRect(lx - 14, 85, 62, 58);
  }
  // the stair down from the platform, and the station name board
  const sx0 = u0 + 40;
  n.fillStyle = '#171420'; n.fillRect(sx0, 86, 76, 56);
  n.fillStyle = '#221d2c'; n.fillRect(sx0 + 3, 89, 70, 53);
  for (let k = 0; k < 11; k++) { n.fillStyle = k % 2 ? '#2e2838' : '#262030';
    n.fillRect(sx0 + 5, 92 + k * 4.6, 66, 3); }
  n.fillStyle = '#16121c'; n.fillRect(sx0 - 3, 86, 4, 56); n.fillRect(sx0 + 74, 86, 4, 56);
  n.fillStyle = 'rgba(255,238,192,0.10)'; n.fillRect(sx0, 90, 76, 52);
  n.fillStyle = '#1e5a3a'; n.fillRect(u0 + 150, 90, 116, 18);
  ptext(n, 'FRANKLIN AV', u0 + 158, 95, '#e8f0e8', 1);
  neonText(n, 'TRAINS', u0 + 152, 114, '#4ae8ff');
  paveAndRoad(n, L, R, r, { pave: '#4e4a58', pave2: '#5a5666', road: '#262430', lineCol: '#d8b038' });
  // The structure itself, in front of everything. It sits low enough that the
  // train on top of it clears the HUD band (the top 34 rows) and high enough
  // that the shopfronts underneath stay readable.
  const DECK = 56;                                   // top of the girder deck
  n.fillStyle = '#1a1620'; n.fillRect(0, DECK, L.near.width, 10);
  n.fillStyle = '#2b2536'; n.fillRect(0, DECK, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 9) { n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, DECK + 3, 3, 7); }
  n.fillStyle = '#141119'; n.fillRect(0, DECK + 10, L.near.width, 5);
  n.strokeStyle = '#211c2a'; n.lineWidth = 2;                          // lattice web
  for (let x = 0; x < L.near.width; x += 22) {
    n.beginPath(); n.moveTo(x, DECK + 10); n.lineTo(x + 11, DECK + 15); n.lineTo(x + 22, DECK + 10); n.stroke();
  }
  n.fillStyle = '#1a1620'; n.fillRect(0, DECK + 15, L.near.width, 8);
  n.fillStyle = '#252031'; n.fillRect(0, DECK + 15, L.near.width, 2);
  for (let x = 4; x < L.near.width; x += 16) { n.fillStyle = '#453d52'; n.fillRect(x, DECK + 18, 2, 2); }
  n.fillStyle = 'rgba(0,0,0,0.45)'; n.fillRect(0, DECK + 23, L.near.width, 4);
  // water finding its way through the deck, streaking the air below it
  for (let k = 0; k < L.near.width / 120; k++) {
    const dx = r(0, L.near.width);
    n.fillStyle = 'rgba(150,180,220,0.16)'; n.fillRect(dx, DECK + 27, 1, 18 + R() * 40);
    n.fillStyle = 'rgba(150,180,220,0.09)'; n.fillRect(dx - 1, DECK + 27, 3, 12);
  }
  for (let x = 20; x < L.near.width; x += 108) {
    n.fillStyle = '#1e1a26'; n.fillRect(x, DECK + 27, 9, WALK - DECK - 27);
    n.fillStyle = '#2c2636'; n.fillRect(x + 1, DECK + 27, 3, WALK - DECK - 27);
    n.fillStyle = '#100d16'; n.fillRect(x - 5, WALK - 4, 19, 5);       // base plate
    for (let k = 0; k < 5; k++) { n.fillStyle = '#4a4254'; n.fillRect(x - 3, WALK - 3, 2, 2); n.fillRect(x + 11, WALK - 3, 2, 2); }
    // riveted bracing up to the deck
    n.strokeStyle = '#1e1a26'; n.lineWidth = 4;
    n.beginPath(); n.moveTo(x + 4, DECK + 40); n.lineTo(x + 54, DECK + 28); n.stroke();
    n.beginPath(); n.moveTo(x + 4, DECK + 40); n.lineTo(x - 46, DECK + 28); n.stroke();
    n.fillStyle = '#171420'; n.fillRect(x - 4, DECK + 27, 17, 5);      // capital plate
    for (let k = 0; k < 4; k++) { n.fillStyle = '#4a4254';
      n.fillRect(x + 1, DECK + 34 + k * 12, 2, 2); n.fillRect(x + 6, DECK + 40 + k * 12, 2, 2); }
    // rubbish drifts against the base of a column, and someone has tagged it
    if (R() < 0.5) trashBags(n, x + 12, WALK + 8, R, 1 + Math.floor(R() * 2));
    // flyposters pasted round the column and torn back off again
    if (R() < 0.6) for (let k = 0; k < 2 + Math.floor(R() * 2); k++) {
      const py2 = DECK + 44 + k * 15 + R() * 6;
      if (py2 > WALK - 14) break;
      n.fillStyle = pick2(R, ['#c8303a', '#2a5ac8', '#e8c030', '#e8e8e8', '#2a8a5a']);
      n.fillRect(x - 1, py2, 11, 11);
      n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 1, py2 + 2, 7, 4);
      n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x - 1, py2 + 9, 11, 2);
    }
    n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x - 10, WALK - 1, 29, 4);   // grime at the foot
    // the lamp bolted to every third column, and the pool it throws
    if ((x / 108) % 3 === 0) {
      n.fillStyle = '#2a2433'; n.fillRect(x - 5, DECK + 32, 19, 4);
      n.fillStyle = '#ffd68a'; n.fillRect(x - 3, DECK + 36, 15, 4);
      n.fillStyle = 'rgba(255,214,138,0.13)';
      n.beginPath(); n.moveTo(x - 3, DECK + 40); n.lineTo(x - 42, 240); n.lineTo(x + 52, 240); n.lineTo(x + 12, DECK + 40); n.fill();
      n.fillStyle = 'rgba(255,214,138,0.09)';
      n.beginPath(); n.ellipse(x + 5, CURB - 16, 40, 13, 0, 0, 7); n.fill();
    }
  }
  let pi = 0;
  const props = [(x) => newsBox(n, x, WALK + 50, R), (x) => trashBags(n, x, WALK + 50, R, 3),
    (x) => hydrant(n, x, WALK + 50), (x) => crates(n, x, WALK + 48, R, 2), (x) => g_mailbox(n, x, WALK + 50, R)];
  for (let x = 70; x < L.near.width - 40; x += 104 + R() * 60) { props[pi % props.length](x); pi++; }
  for (let x = 180; x < L.near.width - 80; x += 240 + R() * 130) parkedCar(n, x, 236, R);
}


// ============================================================ STAGE 1-B: the rooftops
// ---- B4: THE ROOFTOPS -----------------------------------------------------
// The wildcard: the alley goes up instead of along. Tar roofs, water towers,
// laundry lines and the whole skyline behind you.
function roofsBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#050418'], [0.42, '#291646'], [0.78, '#7a2a52'], [1, '#c85a48']]);
  stars(f, L, R, r, 70, 60);
  f.fillStyle = '#e8e2c8'; f.beginPath(); f.arc(340, 34, 13, 0, 7); f.fill();
  f.fillStyle = '#291646'; f.beginPath(); f.arc(346, 30, 12, 0, 7); f.fill();
  skyline(f, L, R, r, 150, '#100c24', '#e8c860', 50, 132);
  // mid: the next rank of roofs, close enough to see their water tanks
  for (let x = 0; x < L.mid.width; x += r(70, 130)) {
    const h = r(30, 78);
    m.fillStyle = '#1a1430'; m.fillRect(x, 150 - h, 118, h + 20);
    m.fillStyle = '#241c42'; m.fillRect(x, 150 - h, 118, 4);
    for (let k = 0; k < 5; k++) if (R() < 0.5) { m.fillStyle = '#d8b050'; m.fillRect(x + 8 + R() * 100, 150 - h + 10 + R() * (h - 14), 3, 4); }
    if (R() < 0.6) { const tx = x + 20 + R() * 70;
      m.fillStyle = '#2a2030'; m.fillRect(tx, 150 - h - 20, 17, 14);
      m.beginPath(); m.moveTo(tx - 2, 150 - h - 20); m.lineTo(tx + 8.5, 150 - h - 28); m.lineTo(tx + 19, 150 - h - 20); m.fill();
      m.fillRect(tx + 2, 150 - h - 6, 2, 6); m.fillRect(tx + 13, 150 - h - 6, 2, 6); }
  }
  // near: the roof you fight on, stepping up and down between blocks.
  // The last stretch is one big open roof under a billboard - the boss arena.
  const arena = len - 330;
  let x = 0;
  while (x < arena) {
    const bw = r(150, 260), lift = r(-8, 10);
    const top = WALK + lift;
    n.fillStyle = '#2a2430'; n.fillRect(x, top, bw, 240 - top);       // tar
    for (let k = 0; k < bw * 1.4; k++) { n.fillStyle = R() < 0.5 ? '#332c3a' : '#241f2b'; n.fillRect(x + R() * bw, top + 4 + R() * (236 - top), 3, 1); }
    for (let sy = top + 12; sy < 240; sy += 17) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(x, sy, bw, 2); }  // rolled seams
    n.fillStyle = '#4a4254'; n.fillRect(x, top - 12, bw, 13);          // parapet
    n.fillStyle = '#5e5668'; n.fillRect(x, top - 12, bw, 3);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x, top + 1, bw, 3);
    if (R() < 0.6) { n.fillStyle = '#2a2430'; n.fillRect(x + bw - 4, top - 12, 5, 250 - top); }  // party wall between roofs
    // what lives on a roof
    const put = [];
    if (R() < 0.75) put.push(() => {                                   // water tower
      const tx = x + 20 + R() * (bw - 70);
      n.fillStyle = '#16121c'; n.fillRect(tx + 3, top - 8, 3, 12); n.fillRect(tx + 34, top - 8, 3, 12);
      n.fillStyle = '#3a2a20'; n.fillRect(tx, top - 44, 40, 38);
      for (let k = 0; k < 40; k += 5) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(tx + k, top - 44, 1.5, 38); }
      n.fillStyle = '#5a4432'; n.fillRect(tx, top - 34, 40, 2); n.fillRect(tx, top - 20, 40, 2);
      n.fillStyle = '#2a2028'; n.beginPath(); n.moveTo(tx - 3, top - 44); n.lineTo(tx + 20, top - 60); n.lineTo(tx + 43, top - 44); n.fill();
    });
    if (R() < 0.7) put.push(() => {                                    // AC plant
      const ax = x + 20 + R() * (bw - 60);
      n.fillStyle = '#1e1c26'; n.fillRect(ax, top - 26, 48, 27);
      n.fillStyle = '#2e2c3a'; n.fillRect(ax + 2, top - 24, 44, 23);
      n.fillStyle = '#16141c'; n.beginPath(); n.arc(ax + 24, top - 12, 10, 0, 7); n.fill();
      for (let k = 0; k < 4; k++) { n.fillStyle = '#4a4858'; n.save(); n.translate(ax + 24, top - 12);
        n.rotate(k * 0.78); n.fillRect(-1.5, -9, 3, 18); n.restore(); }
    });
    if (R() < 0.6) put.push(() => {                                    // pigeon coop
      const cx = x + 20 + R() * (bw - 50);
      n.fillStyle = '#5a4a32'; n.fillRect(cx, top - 24, 40, 25);
      n.fillStyle = '#3a2e1e'; n.fillRect(cx, top - 28, 44, 5);
      for (let k = 0; k < 40; k += 4) { n.fillStyle = 'rgba(0,0,0,0.4)'; n.fillRect(cx + k, top - 20, 1, 16); }
      for (let k = 0; k < 3; k++) pigeon(n, cx + 6 + k * 14, top - 29, R);
    });
    if (R() < 0.5) put.push(() => {                                    // laundry on a line
      const lx = x + 16 + R() * (bw - 90);
      n.fillStyle = '#16121c'; n.fillRect(lx, top - 34, 2, 35); n.fillRect(lx + 76, top - 34, 2, 35);
      n.strokeStyle = 'rgba(200,200,210,0.5)'; n.lineWidth = 1;
      n.beginPath(); n.moveTo(lx, top - 32); n.quadraticCurveTo(lx + 38, top - 22, lx + 76, top - 32); n.stroke();
      for (let k = 0; k < 5; k++) { n.fillStyle = pick2(R, ['#d8d0c0', '#8ab8d8', '#d88a9a', '#e8d070', '#a8c8a0']);
        n.fillRect(lx + 8 + k * 13, top - 30 + Math.sin(k) * 2 + k, 9, 12); }
    });
    if (R() < 0.45) put.push(() => {                                   // satellite dishes
      const dx = x + 20 + R() * (bw - 40);
      for (let k = 0; k < 2; k++) { n.fillStyle = '#c8c4cc';
        n.beginPath(); n.ellipse(dx + k * 18, top - 14, 8, 9, 0.4, 0, 7); n.fill();
        n.fillStyle = '#16141c'; n.fillRect(dx + k * 18 - 1, top - 8, 2, 9); n.fillRect(dx + k * 18 - 4, top, 8, 2); }
    });
    // every few blocks the buildings do not meet: a slot you can see down into
    if (R() < 0.3 && x > 200) {
      const gw = 20 + R() * 16;
      n.clearRect(x + bw - gw, top - 12, gw, 252 - top);
      n.fillStyle = '#0a0812'; n.fillRect(x + bw - gw, top - 12, gw, 252 - top);
      n.fillStyle = '#141024'; n.fillRect(x + bw - gw, top - 12, 3, 252 - top);
      n.fillStyle = '#100c1c'; n.fillRect(x + bw - 3, top - 12, 3, 252 - top);
      for (let k = 0; k < 5; k++) if (R() < 0.5) { n.fillStyle = '#c8a048';
        n.fillRect(x + bw - gw + 5 + R() * (gw - 12), top + 20 + k * 22, 3, 4); }
      n.fillStyle = '#4a4254'; n.fillRect(x + bw - gw - 2, top - 14, gw + 4, 3);
    }
    put.forEach(fn => fn());
    if (R() < 0.6) { const sx = x + 30 + R() * (bw - 60);              // stair bulkhead with a lit door
      n.fillStyle = '#382f40'; n.fillRect(sx, top - 40, 34, 41);
      n.fillStyle = '#463c50'; n.fillRect(sx - 2, top - 44, 38, 5);
      doorway(n, sx + 9, top - 28, 16, 29, R, { col: '#2a3a3a', light: false });
      n.fillStyle = '#e8c860'; n.fillRect(sx + 11, top - 26, 12, 4);
      n.fillStyle = 'rgba(232,200,96,0.10)'; n.fillRect(sx + 4, top - 24, 26, 24); }
    x += bw;
  }
  // the arena: one long unbroken roof, a billboard lighting it, the drop behind
  const atop = WALK + 2;
  n.fillStyle = '#2a2430'; n.fillRect(arena, atop, L.near.width - arena, 240 - atop);
  for (let k = 0; k < (L.near.width - arena) * 1.6; k++) { n.fillStyle = R() < 0.5 ? '#332c3a' : '#241f2b';
    n.fillRect(arena + R() * (L.near.width - arena), atop + 4 + R() * (236 - atop), 3, 1); }
  for (let sy = atop + 12; sy < 240; sy += 17) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(arena, sy, L.near.width - arena, 2); }
  n.fillStyle = '#4a4254'; n.fillRect(arena, atop - 12, L.near.width - arena, 13);
  n.fillStyle = '#5e5668'; n.fillRect(arena, atop - 12, L.near.width - arena, 3);
  n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(arena, atop + 1, L.near.width - arena, 3);
  // the billboard: a steel frame on the parapet with its own floodlights
  const bx0 = arena + 70, bw2 = 250;
  n.fillStyle = '#16121c';
  for (let k = 0; k < 5; k++) n.fillRect(bx0 + 10 + k * 58, atop - 74, 5, 72);
  n.strokeStyle = '#16121c'; n.lineWidth = 3;
  for (let k = 0; k < 4; k++) { n.beginPath(); n.moveTo(bx0 + 12 + k * 58, atop - 10);
    n.lineTo(bx0 + 68 + k * 58, atop - 62); n.stroke(); }
  n.fillStyle = '#1a1526'; n.fillRect(bx0, atop - 112, bw2, 44);
  n.fillStyle = '#c8203a'; n.fillRect(bx0 + 3, atop - 109, bw2 - 6, 38);
  n.fillStyle = '#8a1428'; n.fillRect(bx0 + 3, atop - 88, bw2 - 6, 17);
  neonText(n, 'DUVALL', bx0 + 16, atop - 104, '#ffe8a0', 3);
  ptext(n, 'WHISKEY - SINCE 1911', bx0 + 18, atop - 84, '#f0d8a8', 1);
  for (let k = 0; k < 4; k++) {                      // floods on booms under the board
    const lx = bx0 + 28 + k * 64;
    n.fillStyle = '#16121c'; n.fillRect(lx, atop - 64, 3, 9); n.fillRect(lx - 5, atop - 68, 14, 5);
    n.fillStyle = '#fff2c0'; n.fillRect(lx - 4, atop - 67, 12, 3);
    n.fillStyle = 'rgba(255,242,192,0.08)';
    n.beginPath(); n.moveTo(lx - 4, atop - 64); n.lineTo(lx - 34, atop - 110); n.lineTo(lx + 38, atop - 110); n.lineTo(lx + 8, atop - 64); n.fill();
  }
  n.fillStyle = 'rgba(255,230,170,0.07)'; n.fillRect(arena, atop, L.near.width - arena, 240 - atop);
  // a water tower and a stair head at the far end, so the arena is not bare
  {
    const tx = L.near.width - 150;
    n.fillStyle = '#16121c'; n.fillRect(tx + 4, atop - 10, 4, 14); n.fillRect(tx + 44, atop - 10, 4, 14);
    n.fillStyle = '#3a2a20'; n.fillRect(tx, atop - 56, 52, 48);
    for (let k = 0; k < 52; k += 6) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(tx + k, atop - 56, 2, 48); }
    n.fillStyle = '#5a4432'; n.fillRect(tx, atop - 44, 52, 3); n.fillRect(tx, atop - 26, 52, 3);
    n.fillStyle = '#2a2028'; n.beginPath(); n.moveTo(tx - 4, atop - 56); n.lineTo(tx + 26, atop - 76); n.lineTo(tx + 56, atop - 56); n.fill();
    n.fillStyle = '#16121c'; n.fillRect(tx + 54, atop - 52, 2, 56);
    for (let k = 0; k < 52; k += 7) n.fillRect(tx + 50, atop - 50 + k, 9, 1.5);
  }
  // the pipes and vents underfoot, and a skylight or two you can see down into
  for (let px_ = 60; px_ < L.near.width; px_ += 130 + R() * 80) {
    if (R() < 0.5) { n.fillStyle = '#2a2a32'; n.fillRect(px_, 196, 34, 6);
      n.fillStyle = '#3a3a46'; n.fillRect(px_, 196, 34, 2);
      n.fillStyle = '#20202a'; n.fillRect(px_ - 3, 194, 5, 10); n.fillRect(px_ + 32, 194, 5, 10); }
    else { n.fillStyle = '#16141c'; n.fillRect(px_, 190, 30, 16);
      n.fillStyle = 'rgba(255,220,140,0.30)'; n.fillRect(px_ + 2, 192, 26, 12);
      for (let k = 0; k < 30; k += 7) { n.fillStyle = '#16141c'; n.fillRect(px_ + k, 190, 2, 16); } }
  }
  for (let k = 0; k < 24; k++) pigeon(n, r(0, L.near.width), r(200, 236), R);
  // the way you got up here: a fire-escape head over the parapet at the start
  n.fillStyle = '#16121c';
  n.fillRect(10, WALK - 26, 2, 34); n.fillRect(48, WALK - 26, 2, 34);
  n.fillRect(10, WALK - 27, 40, 2);
  for (let k = 0; k < 40; k += 5) n.fillRect(10 + k, WALK - 26, 1, 12);
  n.fillRect(14, WALK + 6, 2, 26); n.fillRect(40, WALK + 6, 2, 26);
  for (let k = 0; k < 26; k += 5) n.fillRect(14, WALK + 8 + k, 28, 1.5);
  ptext(n, 'UP', 20, WALK - 40, 'rgba(200,190,210,0.35)');
}

// ------------------------------------------------------------ live overlays
// A train crossing the elevated deck. Baking it into the parallax layer would
// leave it parked forever, so it is drawn live over the top of the structure -
// the same way the dance floor is - and it runs on a fixed cycle.
const EL_PERIOD = 780, EL_RUN = 260;
function elTrainPhase() { const p = G.frames % EL_PERIOD; return p < EL_RUN ? p : -1; }
function drawElTrain(cx) {
  const p = elTrainPhase();
  if (p < 0) return;
  const dir = Math.floor(G.frames / EL_PERIOD) % 2 ? -1 : 1;
  const span = 470;
  const travel = W + span + 40;
  const x0 = dir > 0 ? -span - 20 + (p / EL_RUN) * travel : W + 20 - (p / EL_RUN) * travel;
  const lit = Math.floor(G.frames / 3) % 2;
  // The visible strip runs from just under the HUD down to the deck, so what
  // you see is a band of lit windows and the skirt riding past overhead.
  const TOP = 34, BOT = 56;
  ctx.save();
  ctx.beginPath(); ctx.rect(0, TOP, W, BOT - TOP); ctx.clip();
  for (let c = 0; c < 4; c++) {
    const bx = x0 + c * 118;
    if (bx > W + 10 || bx + 112 < -10) continue;
    ctx.fillStyle = '#12101a'; ctx.fillRect(bx, TOP - 16, 112, BOT - TOP + 16);
    ctx.fillStyle = '#4e5766'; ctx.fillRect(bx + 1, TOP - 15, 110, BOT - TOP + 14);
    ctx.fillStyle = '#39414e'; ctx.fillRect(bx + 1, BOT - 8, 110, 8);
    ctx.fillStyle = '#c83030'; ctx.fillRect(bx + 1, BOT - 11, 110, 3);
    for (let wx = bx + 7; wx < bx + 104; wx += 20) {
      ctx.fillStyle = '#0e1620'; ctx.fillRect(wx, TOP - 1, 15, 14);
      ctx.fillStyle = '#ffeab0'; ctx.fillRect(wx + 1, TOP, 13, 12);
      if ((Math.round(wx) + c) % 3 === 0) { ctx.fillStyle = 'rgba(0,0,0,0.5)';
        ctx.fillRect(wx + 5, TOP + 4, 5, 8); ctx.beginPath(); ctx.arc(wx + 7.5, TOP + 3, 2.4, 0, 7); ctx.fill(); }
    }
    ctx.fillStyle = '#20252e'; ctx.fillRect(bx + 10, BOT - 6, 22, 6); ctx.fillRect(bx + 80, BOT - 6, 22, 6);
    ctx.fillStyle = lit ? '#6a7484' : '#525c6c'; ctx.fillRect(bx + 12, BOT - 3, 18, 3); ctx.fillRect(bx + 82, BOT - 3, 18, 3);
    // the gap between one car and the next
    ctx.fillStyle = '#0b0a10'; ctx.fillRect(bx + 112, TOP - 16, 6, BOT - TOP + 16);
  }
  ctx.restore();
  // light spilling down between the girders as it goes over
  ctx.fillStyle = 'rgba(255,234,176,0.07)';
  for (let k = 0; k < 5; k++) {
    const gx = x0 + 40 + k * 118;
    if (gx < -60 || gx > W + 60) continue;
    ctx.beginPath(); ctx.moveTo(gx, 83); ctx.lineTo(gx - 30, 240); ctx.lineTo(gx + 66, 240); ctx.lineTo(gx + 36, 83); ctx.fill();
  }
}

// A rooftop steam riser: the hydrant's mechanic, wearing something that makes
// sense four storeys up.
function drawVent(hz, x, y) {
  const O = '#120a14';
  px(x - 9, y - 13, 18, 13, O); px(x - 8, y - 12, 16, 12, '#4a4e58');
  px(x - 8, y - 12, 16, 2, '#69707c');
  px(x - 5, y - 22, 10, 10, O); px(x - 4, y - 21, 8, 9, '#5a616d');
  px(x - 7, y - 24, 14, 3, O); px(x - 6, y - 23, 12, 2, '#7a838f');
  px(x - 3, y - 20, 2, 8, 'rgba(255,255,255,0.20)');
  px(x + 6, y - 18, 6, 3, '#39414e');
  if (hz.spray > 0) {
    const len = 80 * Math.min(1, (180 - hz.spray) / 10 + 0.2);
    const x0 = hz.dir > 0 ? x + 7 : x - 7 - len;
    for (let i = 0; i < 7; i++) {
      const k = i / 7;
      ctx.fillStyle = `rgba(226,230,240,${0.42 - k * 0.26})`;
      ctx.beginPath();
      ctx.arc(x0 + (hz.dir > 0 ? k * len : (1 - k) * len), y - 18 + Math.sin(G.frames / 3 + i) * 2, 3 + k * 7, 0, 7);
      ctx.fill();
    }
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.fillRect(hz.dir > 0 ? x + 7 : x - 11, y - 19, 5, 3);
  }
}


// ============================================================ STAGE 2: club interior helpers
// a crowd of silhouettes packed behind a rail, the thing that sells a club
function crowd(g, x0, x1, y, R, h = 26, col = 'rgba(0,0,0,0.62)') {
  for (let x = x0; x < x1; x += 5 + R() * 4) {
    const hh = h * (0.8 + R() * 0.4), bob = Math.sin(x * 0.7) * 2;
    g.fillStyle = col;
    g.fillRect(x, y - hh + bob, 5, hh);
    g.beginPath(); g.arc(x + 2.5, y - hh + bob - 2, 3, 0, 7); g.fill();
    if (R() < 0.3) { g.fillRect(x + 4, y - hh + bob - 8, 1.6, 9); }   // an arm up
  }
}
function trussRig(g, x0, x1, y, R, cols) {
  g.fillStyle = '#2a2a34'; g.fillRect(x0, y, x1 - x0, 4); g.fillRect(x0, y + 10, x1 - x0, 4);
  g.strokeStyle = '#3a3a46'; g.lineWidth = 2;
  for (let x = x0; x < x1; x += 16) { g.beginPath(); g.moveTo(x, y + 4); g.lineTo(x + 8, y + 10); g.lineTo(x + 16, y + 4); g.stroke(); }
  for (let x = x0 + 14; x < x1 - 10; x += 44) {
    g.fillStyle = '#16161e'; g.fillRect(x, y + 14, 11, 12);
    const c = cols[Math.floor(R() * cols.length)];
    g.save(); g.shadowColor = c; g.shadowBlur = 9; g.fillStyle = c; g.fillRect(x + 1, y + 25, 9, 4); g.restore();
  }
}


// ============================================================ STAGE 2-A: the neon canyon
// ---- A3: THE NEON CANYON --------------------------------------------------
// Signs stacked four deep over a street narrow enough to touch both sides, a
// gate you fight under, and tiled eaves above the shopfronts.
function canyonBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  skyGrad(f, L, [[0, '#08040e'], [0.6, '#2a0a22'], [1, '#5a1230']]);
  stars(f, L, R, r, 30, 40);
  f.fillStyle = '#12081a'; f.fillRect(0, 100, L.far.width, 56);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 54) {
    m.fillStyle = '#1a0c1e'; m.fillRect(x, 0, 50, 150);
    for (let k = 0; k < 6; k++) if (R() < 0.55) {
      const c = pick2(R, ['#ff2a6a', '#2affc8', '#ffd82a', '#6a8aff', '#ff8a2a']);
      m.save(); m.shadowColor = c; m.shadowBlur = 5; m.fillStyle = c;
      if (R() < 0.5) m.fillRect(x + 4 + R() * 30, 12 + k * 23, 16 + R() * 16, 4);
      else m.fillRect(x + 6 + R() * 34, 10 + k * 23, 5, 16);
      m.restore();
    }
  }
  // near: the street wall. Each building gets its own height, material and
  // upper floors, so the canyon is not one shopfront stamped along a row.
  let x = 0, seq = 0;
  while (x < len - 320) {
    const bw = 88 + R() * 54;
    const wall = pick2(R, ['#3a1c22', '#2e222c', '#402828', '#28242e', '#332030']);
    n.fillStyle = wall; n.fillRect(x, 0, bw, GROUND);
    for (let k = 0; k < 26; k++) { n.fillStyle = 'rgba(0,0,0,0.10)'; n.fillRect(x + R() * bw, R() * GROUND, 6 + R() * 18, 3 + R() * 8); }
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x + bw - 3, 0, 3, GROUND);
    // Only y 34..86 is actually visible above the shopfronts (the HUD owns the
    // top 34 rows), so the storeys live in that band rather than behind it.
    const storeys = 2;
    for (let f2 = 0; f2 < storeys; f2++) {
      const fy = 36 + f2 * 25;
      if (fy + 22 > 88) break;
      const style = (seq + f2) % 3;
      if (style === 0) {
        for (let k = 0; k < 2; k++) {
          const wx = x + 10 + k * (bw - 26);
          n.fillStyle = '#120e16'; n.fillRect(wx - 2, fy - 2, 20, 22);
          const on = R() < 0.55;
          n.fillStyle = on ? '#f0c470' : '#231d2c'; n.fillRect(wx, fy, 16, 18);
          for (let b = 0; b < 18; b += 3) { n.fillStyle = 'rgba(18,14,22,0.68)'; n.fillRect(wx, fy + b, 16, 1.5); }
          if (on) { n.fillStyle = 'rgba(240,196,112,0.12)'; n.fillRect(wx - 6, fy - 2, 28, 26); }
        }
      } else if (style === 1) {
        n.fillStyle = '#1a1620'; n.fillRect(x + 5, fy + 18, bw - 10, 3);
        for (let k = 0; k < bw - 12; k += 5) { n.fillStyle = '#2c2534'; n.fillRect(x + 6 + k, fy + 9, 1.5, 9); }
        n.fillStyle = '#332b3c'; n.fillRect(x + 5, fy + 8, bw - 10, 2);
        n.fillStyle = '#120e16'; n.fillRect(x + bw / 2 - 11, fy - 4, 22, 22);
        const lit2 = R() < 0.6;
        n.fillStyle = lit2 ? '#f0c878' : '#241d30'; n.fillRect(x + bw / 2 - 9, fy - 2, 18, 20);
        if (lit2) { n.fillStyle = 'rgba(240,200,120,0.13)'; n.fillRect(x + bw / 2 - 18, fy - 4, 36, 26); }
        for (let k = 0; k < 3; k++) if (R() < 0.6) { n.fillStyle = '#2a6a3a';
          n.fillRect(x + 10 + k * 18, fy + 14, 6, 6); n.fillRect(x + 11 + k * 18, fy + 10, 4, 5); }
        if (R() < 0.6) { n.strokeStyle = 'rgba(190,190,205,0.45)'; n.lineWidth = 1;
          n.beginPath(); n.moveTo(x + 6, fy + 6); n.quadraticCurveTo(x + bw / 2, fy + 12, x + bw - 6, fy + 6); n.stroke();
          for (let k = 0; k < 4; k++) { n.fillStyle = pick2(R, ['#d8d0c0', '#8ab8d8', '#d88a9a', '#e8d070']);
            n.fillRect(x + 12 + k * (bw - 26) / 4, fy + 8 + k, 7, 10); } }
      } else {
        n.fillStyle = '#39414e'; n.fillRect(x + 8 + R() * (bw - 30), fy - 6, 5, 34);
        n.fillStyle = '#2a2a32'; n.fillRect(x + bw - 30, fy + 4, 20, 14);
        n.fillStyle = '#3d3d47'; n.fillRect(x + bw - 29, fy + 5, 18, 5);
        n.fillStyle = '#16121c'; n.fillRect(x + 12, fy + 2, 14, 18);
        n.fillStyle = R() < 0.3 ? '#c8a850' : '#191520'; n.fillRect(x + 14, fy + 4, 10, 14);
      }
    }
    // The deep tiled eave over the shopfront: the piece of architecture that
    // says this is not the same street as stage 1, so it has to read.
    for (const ey of [86, 34]) {
      n.fillStyle = '#1a0f12'; n.fillRect(x - 5, ey, bw + 10, 6);
      for (let tx = x - 5; tx < x + bw + 5; tx += 8) {
        n.fillStyle = pick2(R, ['#7a3a34', '#8c453c', '#6a322e', '#94514a']);
        n.beginPath(); n.moveTo(tx, ey + 1); n.lineTo(tx + 4, ey - 7); n.lineTo(tx + 8, ey + 1); n.fill();
        n.fillStyle = 'rgba(255,200,170,0.14)'; n.fillRect(tx + 3, ey - 6, 1.5, 7);
      }
      n.fillStyle = '#c08a5a'; n.fillRect(x - 5, ey + 1, bw + 10, 1.5);
      n.fillStyle = 'rgba(0,0,0,0.45)'; n.fillRect(x - 5, ey + 6, bw + 10, 4);
    }
    const sfTop = 90 + (seq % 3) * 4;
    n.fillStyle = '#16101a'; n.fillRect(x + 3, sfTop, bw - 6, GROUND - sfTop);
    if (R() < 0.18) {
      n.fillStyle = '#2a2430'; n.fillRect(x + 6, sfTop + 4, bw - 12, GROUND - sfTop - 4);
      for (let k = 0; k < bw - 12; k += 4) { n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x + 6 + k, sfTop + 4, 2, GROUND - sfTop - 4); }
      graffiti(n, x + 12, GROUND - 24, R, bw - 28);
    } else {
      n.fillStyle = pick2(R, ['#e8c878', '#d8a850', '#c8d8a0', '#e8b070']);
      n.fillRect(x + 6, sfTop + 5, bw - 12, GROUND - sfTop - 7);
      n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x + 6, sfTop + 5, bw - 12, 6);
      const trade = seq % 4;
      if (trade === 0) {
        for (let k = 0; k < 5; k++) { n.fillStyle = '#a8461f'; n.fillRect(x + 12 + k * 13, GROUND - 42, 7, 15);
          n.fillStyle = '#7d3216'; n.fillRect(x + 14 + k * 13, GROUND - 44, 2, 3); }
        n.fillStyle = '#b8bcc4'; for (let k = 0; k < 4; k++) n.fillRect(x + bw - 34, GROUND - 26 - k * 6, 24, 5);
        n.fillStyle = 'rgba(240,240,250,0.18)'; n.fillRect(x + bw - 36, GROUND - 40, 28, 14);
      } else if (trade === 1) {
        for (let k = 0; k < 4; k++) { n.fillStyle = pick2(R, ['#8a6a40', '#6a4a2a']);
          n.fillRect(x + 10 + k * 16, GROUND - 26, 14, 16);
          n.fillStyle = pick2(R, ['#c8703a', '#8aa83a', '#d8b83a']); n.fillRect(x + 12 + k * 16, GROUND - 29, 10, 4); }
        n.fillStyle = '#7a6a4a'; n.fillRect(x + bw - 30, GROUND - 30, 18, 20);
      } else if (trade === 2) {
        n.fillStyle = 'rgba(210,235,245,0.22)'; n.fillRect(x + 10, GROUND - 42, bw - 20, 18);
        for (let k = 0; k < 3; k++) { n.fillStyle = '#2a2a34'; n.fillRect(x + 16 + k * 22, GROUND - 24, 12, 14);
          n.fillStyle = '#5a2a2a'; n.fillRect(x + 16 + k * 22, GROUND - 28, 12, 5); }
      } else {
        n.fillStyle = '#6a4a2a'; n.fillRect(x + 8, GROUND - 24, bw - 16, 5);
        n.fillStyle = '#4a3220'; n.fillRect(x + 8, GROUND - 19, bw - 16, 9);
        for (let k = 0; k < 6; k++) { n.fillStyle = pick2(R, ['#d8d0c0', '#c8b8a0']); n.fillRect(x + 12 + k * 12, GROUND - 29, 7, 5); }
      }
      for (let k = 0; k < 4; k++) if (R() < 0.55) {
        const sx2 = x + 12 + k * (bw - 24) / 4;
        n.fillStyle = 'rgba(0,0,0,0.5)';
        n.fillRect(sx2, GROUND - 30, 6, 24); n.beginPath(); n.arc(sx2 + 3, GROUND - 32, 3.4, 0, 7); n.fill();
      }
      n.fillStyle = 'rgba(255,220,150,0.12)'; n.fillRect(x + 6, sfTop + 5, bw - 12, GROUND - sfTop - 7);
      for (let k = 0; k < bw - 12; k += 9) { n.fillStyle = pick2(R, ['#1e3a5a', '#5a1e2a', '#2a4a36']);
        n.fillRect(x + 6 + k, sfTop + 5, 8, 10); }
      n.fillStyle = 'rgba(255,214,150,0.10)';
      n.beginPath(); n.ellipse(x + bw / 2, WALK + 14, bw * 0.55, 15, 0, 0, 7); n.fill();
    }
    n.fillStyle = '#2a1a1e'; n.fillRect(x + 3, sfTop, bw - 6, 5);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 3, GROUND - 8, bw - 6, 8);
    // the blade sign bracketed off this building's own face
    if (R() < 0.85) {
      const sy = 16 + (seq % 3) * 16, h = 40 + R() * 24;
      const c = pick2(R, ['#ff2a6a', '#2affc8', '#ffd82a', '#6a8aff', '#ff8a2a', '#ff2aff']);
      const side = seq % 2 ? x + bw - 24 : x + 8;
      n.fillStyle = '#241e2a'; n.fillRect(side + 5, sy - 5, 6, 5);
      n.fillStyle = '#0e0810'; n.fillRect(side, sy, 16, h);
      n.save(); n.shadowColor = c; n.shadowBlur = 8; n.fillStyle = c;
      for (let k = 0; k < Math.floor(h / 11); k++) n.fillRect(side + 4, sy + 5 + k * 11, 8, 7);
      n.restore();
    }
    x += bw; seq++;
  }
  // the gate across the street, and the club behind it
  const g0 = len - 320, gw = L.near.width - g0;
  n.fillStyle = '#180a1c'; n.fillRect(g0, 0, gw, GROUND);
  for (let k = 0; k < 40; k++) { n.fillStyle = pick2(R, ['#ff2a6a', '#ffd82a', '#2affc8']);
    n.fillRect(g0 + R() * gw, 20 + R() * 100, 3, 3); }
  n.fillStyle = '#7a1a28'; n.fillRect(g0 + 28, 30, 16, GROUND - 30); n.fillRect(g0 + gw - 44, 30, 16, GROUND - 30);
  n.fillStyle = '#9a2a34'; n.fillRect(g0 + 30, 30, 5, GROUND - 30); n.fillRect(g0 + gw - 42, 30, 5, GROUND - 30);
  n.fillStyle = '#7a1a28'; n.fillRect(g0 + 20, 22, gw - 40, 12);
  for (let tx = g0 + 14; tx < g0 + gw - 14; tx += 8) { n.fillStyle = '#c8a030';
    n.beginPath(); n.moveTo(tx, 22); n.lineTo(tx + 4, 14); n.lineTo(tx + 8, 22); n.fill(); }
  n.fillStyle = '#c8a030'; n.fillRect(g0 + 14, 34, gw - 28, 3);
  neonText(n, 'CLUB VELVET', g0 + gw / 2 - tw('CLUB VELVET', 2) / 2, 42, '#ffd82a', 2);
  n.fillStyle = '#2a0a1a'; n.fillRect(g0 + gw / 2 - 30, GROUND - 58, 60, 58);
  n.fillStyle = 'rgba(255,42,106,0.20)'; n.fillRect(g0 + gw / 2 - 30, GROUND - 58, 60, 58);
  // the ground: tight wet setts, no kerb, no carriageway
  n.fillStyle = '#2f2830'; n.fillRect(0, WALK, L.near.width, 240 - WALK);
  for (let sy = WALK; sy < 240; sy += 9) for (let sx2 = 0; sx2 < L.near.width; sx2 += 12) {
    const t2 = R();
    n.fillStyle = t2 < 0.33 ? '#342d36' : t2 < 0.66 ? '#2d262e' : '#393240';
    n.fillRect(sx2 + ((Math.round(sy / 9)) % 2) * 6, sy, 11, 8);
    if (t2 > 0.94) { n.fillStyle = 'rgba(255,255,255,0.05)'; n.fillRect(sx2 + ((Math.round(sy / 9)) % 2) * 6, sy, 11, 2); }
  }
  n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(0, WALK, L.near.width, 3);
  n.fillStyle = '#20242e'; n.fillRect(L.near.width * 0, 214, L.near.width, 6);      // the drain channel
  for (let k = 0; k < L.near.width; k += 6) { n.fillStyle = '#2e3440'; n.fillRect(k, 215, 3, 4); }
  puddles(n, R, L.near.width, WALK + 10, 236, 40, 'rgba(255,120,180,0.13)');
  puddles(n, R, L.near.width, WALK + 10, 236, 24, 'rgba(90,200,220,0.12)');
  // THE signs: hung right across the street, four deep, overlapping
  for (let x2 = 10; x2 < L.near.width; x2 += 34 + R() * 26) {
    const c = pick2(R, ['#ff2a6a', '#2affc8', '#ffd82a', '#6a8aff', '#ff8a2a', '#ff2aff']);
    const kind = 1 + Math.floor(R() * 2);
    n.fillStyle = '#0e0810';
    if (kind === 1) {                                   // horizontal box
      const w2 = 40 + R() * 40, y0 = 12 + R() * 60;
      n.fillRect(x2, y0, w2, 16);
      n.save(); n.shadowColor = c; n.shadowBlur = 8; n.strokeStyle = c; n.lineWidth = 2;
      n.strokeRect(x2 + 3, y0 + 3, w2 - 6, 10); n.restore();
      neonText(n, pick2(R, ['BAR', 'KTV', 'NOODLE', 'PARLOUR', 'HOTEL']), x2 + 6, y0 + 5, c);
    } else {                                            // a hanging lantern cluster
      const y0 = 14 + R() * 30;
      n.fillStyle = '#2a1a22'; n.fillRect(x2 + 6, 0, 2, y0);
      for (let k = 0; k < 3; k++) {
        n.save(); n.shadowColor = '#ff5a3a'; n.shadowBlur = 8; n.fillStyle = pick2(R, ['#ff5a3a', '#ffb83a']);
        n.beginPath(); n.ellipse(x2 + 7, y0 + 10 + k * 17, 6, 8, 0, 0, 7); n.fill(); n.restore();
        n.fillStyle = '#c89030'; n.fillRect(x2 + 6, y0 + 1 + k * 17, 2, 3);
      }
    }
  }
  // the cables it all hangs from
  n.strokeStyle = 'rgba(30,24,36,0.9)'; n.lineWidth = 1;
  for (let x2 = 0; x2 < L.near.width; x2 += 80) {
    n.beginPath(); n.moveTo(x2, 8 + R() * 8); n.quadraticCurveTo(x2 + 40, 20 + R() * 10, x2 + 80, 8 + R() * 8); n.stroke();
  }
}


// ============================================================ STAGE 2-B: the basement
// ---- B2: THE BASEMENT -----------------------------------------------------
// Raw concrete, a scaffold rig and a wall of speakers. Colder, harder, and lit
// by strobe rather than colour.
function basementBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#07080c'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 90) {           // the back of the room, lost in the dark
    m.fillStyle = '#0d0f14'; m.fillRect(x, 40, 84, 110);
    if (R() < 0.4) { m.fillStyle = '#161a22'; m.fillRect(x + 10, 60, 64, 50); }
  }
  crowd(m, 0, L.mid.width, 150, R, 34, 'rgba(0,0,0,0.75)');
  concrete(n, 0, 0, L.near.width, 150, '#2e3138', R);
  // Openings into the next room so the crowd in the mid layer actually shows:
  // a raised area behind a rail, glimpsed between the structure.
  // Placed in the gaps between the speaker stacks (which sit at 60, 260, 460...)
  // so the openings are not painted over by them.
  for (let ox = 158; ox < len - 400; ox += 200) {
    const ow = 84;
    n.clearRect(ox, 54, ow, 88);
    n.fillStyle = 'rgba(10,12,16,0.55)'; n.fillRect(ox, 54, ow, 88);
    crowd(n, ox + 2, ox + ow - 2, 140, R, 32, 'rgba(0,0,0,0.80)');
    crowd(n, ox + 6, ox + ow - 6, 126, R, 26, 'rgba(0,0,0,0.92)');
    n.fillStyle = '#39414e'; n.fillRect(ox - 4, 120, ow + 8, 4);           // the rail they lean on
    n.fillStyle = '#4e5866'; n.fillRect(ox - 4, 120, ow + 8, 1.5);
    for (let k = 0; k < ow + 8; k += 22) { n.fillStyle = '#2b323c'; n.fillRect(ox - 4 + k, 120, 3, 22); }
    n.fillStyle = '#20242c'; n.fillRect(ox - 6, 48, ow + 12, 7);           // the lintel over it
    n.fillStyle = '#2e343e'; n.fillRect(ox - 6, 48, ow + 12, 2);
    n.fillStyle = 'rgba(58,255,138,0.05)'; n.fillRect(ox, 54, ow, 88);
  }
  // structural columns and the scaffold rig bolted between them
  for (let x = 30; x < L.near.width; x += 210) {
    concrete(n, x, 0, 34, 150, '#353942', R);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 30, 0, 4, 150);
    graffiti(n, x + 2, 96 + R() * 30, R, 30);
  }
  for (let y = 12; y < 44; y += 20) {
    n.fillStyle = '#4a4e58'; n.fillRect(0, y, L.near.width, 4);
    for (let x = 0; x < L.near.width; x += 46) { n.fillStyle = '#5c616d'; n.fillRect(x, y - 1, 5, 6); }
  }
  for (let x = 0; x < L.near.width; x += 46) { n.fillStyle = '#4a4e58'; n.fillRect(x, 12, 4, 34); }
  for (let x = 20; x < L.near.width; x += 56) {
    n.fillStyle = '#16161c'; n.fillRect(x, 44, 12, 13);
    n.fillStyle = R() < 0.5 ? '#e8f4ff' : '#0f1014'; n.fillRect(x + 1, 55, 10, 4);
  }
  // the wall of speakers: the reason anybody came
  for (let x = 60; x < len - 360; x += 200) {
    for (let c = 0; c < 2; c++) for (let s = 0; s < 4; s++) {
      const sx = x + c * 46, sy = 64 + s * 21;
      n.fillStyle = '#0a0a0e'; n.fillRect(sx, sy, 44, 20);
      n.fillStyle = '#1a1a20'; n.fillRect(sx + 1, sy + 1, 42, 18);
      n.fillStyle = '#26262e'; n.beginPath(); n.arc(sx + 13, sy + 10, 7, 0, 7); n.arc(sx + 31, sy + 10, 7, 0, 7); n.fill();
      n.fillStyle = '#0e0e12'; n.beginPath(); n.arc(sx + 13, sy + 10, 3, 0, 7); n.arc(sx + 31, sy + 10, 3, 0, 7); n.fill();
    }
    n.fillStyle = '#3a3a46'; n.fillRect(x - 4, 148, 96, 4);
  }
  // chain-link penning off the far side, and a van somebody drove in
  for (let x = len - 700; x < len - 380; x += 6) {
    n.strokeStyle = 'rgba(130,142,164,0.16)'; n.lineWidth = 1;
    n.beginPath(); n.moveTo(x, 58); n.lineTo(x + 46, 150); n.stroke();
    n.beginPath(); n.moveTo(x, 58); n.lineTo(x - 46, 150); n.stroke();
  }
  const vanX = len - 620;
  n.fillStyle = '#0e1016'; n.fillRect(vanX, 82, 132, 62);
  n.fillStyle = '#4c5866'; n.fillRect(vanX + 2, 84, 128, 58);
  n.fillStyle = '#5c697a'; n.fillRect(vanX + 2, 84, 128, 4);               // roof line
  n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(vanX + 2, 128, 128, 14);    // sill shadow
  for (let k = 0; k < 128; k += 9) { n.fillStyle = 'rgba(0,0,0,0.14)'; n.fillRect(vanX + 2 + k, 90, 2, 38); }
  n.fillStyle = '#2b3542'; n.fillRect(vanX + 6, 96, 42, 30);               // the open back doors
  n.fillStyle = '#121820'; n.fillRect(vanX + 9, 99, 36, 24);
  n.fillStyle = 'rgba(58,255,138,0.10)'; n.fillRect(vanX + 9, 99, 36, 24);
  for (let k = 0; k < 3; k++) { n.fillStyle = '#0a0a0e'; n.fillRect(vanX + 12 + k * 11, 104, 9, 18);
    n.fillStyle = '#26262e'; n.beginPath(); n.arc(vanX + 16.5 + k * 11, 111, 3.4, 0, 7); n.fill(); }
  n.fillStyle = '#1c2430'; n.fillRect(vanX + 90, 92, 36, 22);              // cab window
  n.fillStyle = 'rgba(150,190,230,0.14)'; n.fillRect(vanX + 93, 94, 14, 18);
  n.fillStyle = '#39414e'; n.fillRect(vanX + 88, 116, 42, 4);
  graffiti(n, vanX + 54, 118, R, 30);
  n.fillStyle = '#0e1016'; n.fillRect(vanX + 12, 142, 108, 8);
  n.fillStyle = '#16181f'; n.beginPath(); n.arc(vanX + 30, 148, 10, 0, 7); n.arc(vanX + 104, 148, 10, 0, 7); n.fill();
  n.fillStyle = '#343a44'; n.beginPath(); n.arc(vanX + 30, 148, 4, 0, 7); n.arc(vanX + 104, 148, 4, 0, 7); n.fill();
  // the end of the room: the rig, a riser, and one red exit sign
  const r0 = len - 360;
  n.fillStyle = '#0c0e13'; n.fillRect(r0, 0, L.near.width - r0, 150);
  trussRig(n, r0 + 10, L.near.width - 10, 34, R, ['#e8f4ff', '#e8f4ff', '#3aff8a', '#ff2a4a']);
  n.fillStyle = '#1a1e26'; n.fillRect(r0 + 40, 104, L.near.width - r0 - 80, 46);
  n.fillStyle = '#252b36'; n.fillRect(r0 + 40, 104, L.near.width - r0 - 80, 4);
  for (let k = 0; k < 6; k++) { n.fillStyle = '#0a0a0e'; n.fillRect(r0 + 56 + k * 40, 66, 32, 36);
    n.fillStyle = '#26262e'; n.beginPath(); n.arc(r0 + 72 + k * 40, 84, 10, 0, 7); n.fill(); }
  n.fillStyle = '#2a0e12'; n.fillRect(L.near.width - 70, 40, 44, 18);
  n.save(); n.shadowColor = '#ff2a3a'; n.shadowBlur = 9; ptext(n, 'EXIT', L.near.width - 64, 45, '#ff4a56'); n.restore();
  // the floor: bare slab, taped lines, spilled everything
  n.fillStyle = '#23262c'; n.fillRect(0, 150, L.near.width, 90);
  for (let k = 0; k < L.near.width * 1.6; k++) { n.fillStyle = R() < 0.5 ? '#2a2e35' : '#1c1f25';
    n.fillRect(r(0, L.near.width), r(152, 240), 3, 1); }
  for (let x = 0; x < L.near.width; x += 74) { n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x, 150, 2, 90); }
  for (let k = 0; k < L.near.width / 90; k++) { n.fillStyle = 'rgba(0,0,0,0.28)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(160, 234), 12 + R() * 20, 4 + R() * 5, 0, 0, 7); n.fill(); }
  for (let k = 0; k < L.near.width / 16; k++) {
    n.fillStyle = pick2(R, ['rgba(190,200,210,0.35)', 'rgba(140,170,120,0.3)', 'rgba(200,150,90,0.3)']);
    n.save(); n.translate(r(0, L.near.width), r(156, 236)); n.rotate(R() * 3); n.fillRect(0, 0, 3 + R() * 5, 2); n.restore();
  }
  n.fillStyle = 'rgba(232,200,40,0.5)'; n.fillRect(0, 226, L.near.width, 3);
  L.strobe = 1; L.haze = 1;
}


// ------------------------------------------------------------ live overlay
// The basement is lit by its rig rather than by daylight, so the light has to
// move. Deliberately kept off a hard full-screen white flash: it is a long
// fight, and SAVE.options.flashing turns even this much down for anyone who
// wants it off.
function drawClubStrobe() {
  if (!SAVE.options.flashing) return;
  const t = G.frames;
  const beat = t % 74;
  if (beat < 3) { ctx.fillStyle = 'rgba(226,240,255,0.16)'; ctx.fillRect(0, 0, W, 150); }
  else if (beat < 7) { ctx.fillStyle = 'rgba(226,240,255,0.07)'; ctx.fillRect(0, 0, W, 150); }
  for (let k = 0; k < 4; k++) {
    const a = t * 0.017 + k * 1.6;
    const x = W / 2 + Math.sin(a) * (W / 2 + 40);
    ctx.fillStyle = k % 2 ? 'rgba(58,255,138,0.055)' : 'rgba(226,240,255,0.045)';
    ctx.beginPath(); ctx.moveTo(x, 48); ctx.lineTo(x - 40, 240); ctx.lineTo(x + 26, 240); ctx.lineTo(x + 8, 48); ctx.fill();
  }
  // haze so the beams have something to land on
  for (let i = 0; i < 6; i++) {
    const seed = i * 211;
    const x = ((seed * 37 + t * (0.22 + (i % 3) * 0.1)) % (W + 200)) - 100;
    ctx.fillStyle = `rgba(200,210,235,${0.026 + (i % 3) * 0.010})`;
    ctx.beginPath(); ctx.ellipse(x, 122 + (seed % 66) , 58 + (i % 4) * 20, 15 + (i % 3) * 6, 0, 0, 7); ctx.fill();
  }
}


// ============================================================ STAGE 3 helpers
function siteDirt(n, L, R, r, base, a, b, c) {
  n.fillStyle = a; n.fillRect(0, base, L.near.width, 240 - base);
  for (let k = 0; k < L.near.width * 1.6; k++) { n.fillStyle = R() < 0.5 ? b : c;
    n.fillRect(r(0, L.near.width), r(base + 2, 240), 2, 1); }
  // tyre ruts churned down the length, and water standing in them
  for (const ry of [base + 26, base + 58]) for (let x = 0; x < L.near.width; x += 3) {
    n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x, ry + Math.sin(x * 0.04) * 3, 3, 7);
  }
  for (let k = 0; k < L.near.width / 120; k++) { n.fillStyle = 'rgba(90,110,130,0.26)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(base + 20, 236), 14 + R() * 22, 4 + R() * 4, 0, 0, 7); n.fill(); }
  n.fillStyle = c; n.fillRect(0, base, L.near.width, 3);
}
function towerCrane(m, x, R, h = 120, col = '#3a1a2a') {
  m.fillStyle = col;
  m.fillRect(x, 150 - h, 7, h);
  for (let k = 0; k < h; k += 11) { m.strokeStyle = col; m.lineWidth = 1.5;
    m.beginPath(); m.moveTo(x, 150 - h + k); m.lineTo(x + 7, 150 - h + k + 11); m.stroke();
    m.beginPath(); m.moveTo(x + 7, 150 - h + k); m.lineTo(x, 150 - h + k + 11); m.stroke(); }
  m.fillRect(x - 46, 150 - h - 8, 150, 4);
  m.fillRect(x - 46, 150 - h - 4, 6, 4);
  for (let k = -44; k < 102; k += 12) { m.strokeStyle = col; m.lineWidth = 1;
    m.beginPath(); m.moveTo(x + k, 150 - h - 4); m.lineTo(x + k + 6, 150 - h - 12); m.lineTo(x + k + 12, 150 - h - 4); m.stroke(); }
  m.fillRect(x - 4, 150 - h - 20, 15, 12);
  m.fillStyle = '#e8c860'; m.fillRect(x - 2, 150 - h - 18, 10, 5);
  // the hook, on its cable, with something on it
  const hx = x + 54;
  m.fillStyle = col; m.fillRect(hx, 150 - h - 4, 1.5, 40);
  m.fillStyle = '#e8b020'; m.fillRect(hx - 6, 150 - h + 36, 13, 7);
}

function cityBelow(f, L, R, r, top) {
  f.fillStyle = '#2a1c3c'; f.fillRect(0, top, L.far.width, 240 - top);
  for (let x = 0; x < L.far.width; x += 7) { f.fillStyle = R() < 0.4 ? '#3a2a4e' : '#241a34';
    f.fillRect(x, top + R() * 10, 6, 240 - top); }
  for (let k = 0; k < L.far.width * 2.2; k++) { f.fillStyle = R() < 0.6 ? '#f2d070' : '#7ab8f0';
    f.fillRect(r(0, L.far.width), r(top + 4, 238), 1, 1); }
}
function duskSky(f, L, R, r) {
  const sky = f.createLinearGradient(0, 0, 0, 170);
  sky.addColorStop(0, '#1a1440'); sky.addColorStop(0.42, '#5a2a6a'); sky.addColorStop(0.76, '#e0704a'); sky.addColorStop(1, '#ffc068');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  for (let i = 0; i < 46; i++) { f.fillStyle = 'rgba(255,255,255,0.45)'; f.fillRect(r(0, L.far.width), r(0, 46), 1, 1); }
  for (let k = 0; k < 10; k++) { f.fillStyle = 'rgba(255,200,180,0.16)'; f.fillRect(r(0, L.far.width), r(28, 96), r(50, 110), 4); }
}


// ============================================================ STAGE 3-A: the foundation
// ---- A1: THE FOUNDATION ---------------------------------------------------
function foundationBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const sky = f.createLinearGradient(0, 0, 0, 160);
  sky.addColorStop(0, '#2a1a3a'); sky.addColorStop(0.55, '#a8506a'); sky.addColorStop(1, '#f0a060');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  f.fillStyle = '#ffe0a0'; f.beginPath(); f.arc(330, 96, 16, 0, 7); f.fill();
  for (let k = 0; k < 9; k++) { f.fillStyle = 'rgba(255,220,200,0.18)'; f.fillRect(r(0, L.far.width), r(20, 90), r(40, 90), 3); }
  skyline(f, L, R, r, 140, '#4a2a4a', '#ffd070', 30, 92);
  for (let x = 40; x < L.mid.width; x += 250) towerCrane(m, x, R, 100 + R() * 34);
  // mid: the steel skeletons of the next plots
  for (let x = 0; x < L.mid.width; x += 150) {
    const h = 60 + R() * 54;
    m.strokeStyle = '#5a2a2a'; m.lineWidth = 2;
    for (let yy = 150; yy > 150 - h; yy -= 16) { m.beginPath(); m.moveTo(x, yy); m.lineTo(x + 66, yy); m.stroke(); }
    m.beginPath(); m.moveTo(x, 150); m.lineTo(x, 150 - h); m.moveTo(x + 66, 150); m.lineTo(x + 66, 150 - h); m.stroke();
    for (let yy = 150; yy > 166 - h; yy -= 16) { m.beginPath(); m.moveTo(x, yy); m.lineTo(x + 66, yy - 16); m.stroke(); }
  }
  // near: the perimeter. Real sites change their boundary as they go - plywood
  // hoarding here, mesh panels there, an open gap where the plant drives in -
  // so the run is not one continuous fence.
  let hx = 0, hs = 0;
  while (hx < L.near.width) {
    const hw = 170 + R() * 130, kind = hs % 3;
    if (kind === 0) {                                   // plywood hoarding, fly-posted
      n.fillStyle = '#6a5a44'; n.fillRect(hx, 58, hw, 84);
      for (let k = 0; k < hw; k += 17) { n.fillStyle = 'rgba(0,0,0,0.18)'; n.fillRect(hx + k, 58, 1.5, 84); }
      n.fillStyle = '#7d6c52'; n.fillRect(hx, 58, hw, 3);
      n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(hx, 136, hw, 6);
      for (let k = 0; k < 5; k++) {
        const px_ = hx + 8 + R() * (hw - 30);
        n.save(); n.translate(px_, 74 + R() * 42); n.rotate((R() - 0.5) * 0.18);
        n.fillStyle = pick2(R, ['#c8303a', '#2a5ac8', '#e8c030', '#2a8a5a', '#e8e8e8']);
        n.fillRect(0, 0, 17, 23);
        n.fillStyle = 'rgba(0,0,0,0.32)'; n.fillRect(2, 4, 13, 9); n.restore();
      }
      graffiti(n, hx + 14, 124, R, hw - 40);
    } else if (kind === 1) {                            // mesh panels with debris netting behind
      n.fillStyle = 'rgba(30,40,30,0.45)'; n.fillRect(hx, 58, hw, 84);
      n.strokeStyle = 'rgba(180,180,190,0.26)'; n.lineWidth = 1;
      for (let x2 = hx; x2 < hx + hw + 80; x2 += 7) {
        n.beginPath(); n.moveTo(x2, 58); n.lineTo(x2 + 70, 142); n.stroke();
        n.beginPath(); n.moveTo(x2, 58); n.lineTo(x2 - 70, 142); n.stroke();
      }
      for (let x2 = hx; x2 < hx + hw; x2 += 62) { n.fillStyle = '#7a7a86'; n.fillRect(x2, 54, 4, 90);
        n.fillStyle = '#9a9aa6'; n.fillRect(x2, 54, 4, 2);
        n.fillStyle = '#2a2a32'; n.fillRect(x2 - 5, 138, 14, 5); }
    } else {                                            // the gate: plant drives through here
      n.fillStyle = '#1c1826'; n.fillRect(hx, 58, hw, 84);
      for (let bx = hx + 8; bx < hx + hw; bx += 30) {   // the excavation seen through the gap
        const bh = 20 + R() * 40;
        n.fillStyle = '#2a2233'; n.fillRect(bx, 142 - bh, 26, bh);
      }
      n.fillStyle = '#7a7a86'; n.fillRect(hx, 50, 5, 94); n.fillRect(hx + hw - 5, 50, 5, 94);
      n.fillStyle = '#c8302a'; n.fillRect(hx + 10, 72, 46, 30);
      ptext(n, 'STOP', hx + 18, 82, '#f0e8e0', 1);
      n.fillStyle = '#e8c020'; n.fillRect(hx + hw - 70, 72, 58, 30);
      ptext(n, 'HARD', hx + hw - 64, 76, '#1a1a1e', 1);
      ptext(n, 'HATS', hx + hw - 64, 88, '#1a1a1e', 1);
    }
    hx += hw; hs++;
  }
  for (let x = 30; x < L.near.width; x += 400) {
    n.fillStyle = '#1e5a3a'; n.fillRect(x, 66, 150, 52);
    n.fillStyle = '#2a7a4a'; n.fillRect(x, 66, 150, 3);
    ptext(n, 'SYNDICATE', x + 14, 76, '#e8e8e0', 1);
    ptext(n, 'DEVELOPMENTS', x + 14, 88, '#e8b020', 1);
    ptext(n, 'NO ADMITTANCE', x + 14, 104, '#8ab8a0', 1);
  }
  // site huts stacked two high, a concrete pump, rebar cages, a skip
  let si = 0;
  for (let x = 170; x < L.near.width - 120; x += 260) {
    const kind = si % 4; si++;
    if (kind === 0) {                                  // stacked cabins
      for (let s = 0; s < 2; s++) {
        const cy = 142 - 34 - s * 32;
        n.fillStyle = '#16141c'; n.fillRect(x, cy, 118, 33);
        n.fillStyle = pick2(R, ['#8a9aa8', '#c8c0a8', '#6a8a7a']); n.fillRect(x + 2, cy + 2, 114, 29);
        for (let k = 0; k < 114; k += 8) { n.fillStyle = 'rgba(0,0,0,0.12)'; n.fillRect(x + 2 + k, cy + 2, 2, 29); }
        n.fillStyle = '#2a3a4a'; n.fillRect(x + 12, cy + 8, 22, 14); n.fillRect(x + 76, cy + 8, 22, 14);
        n.fillStyle = 'rgba(200,230,255,0.25)'; n.fillRect(x + 13, cy + 9, 20, 12);
        n.fillStyle = '#3a2418'; n.fillRect(x + 48, cy + 6, 16, 25);
      }
      n.fillStyle = '#4a4a54'; n.fillRect(x + 40, 130, 34, 4);        // the stair to the top one
      for (let k = 0; k < 4; k++) n.fillRect(x + 40, 116 + k * 5, 26, 3);
    } else if (kind === 1) {                           // concrete pump with its boom folded
      n.fillStyle = '#16141c'; n.fillRect(x, 106, 106, 36);
      n.fillStyle = '#c8501e'; n.fillRect(x + 2, 108, 102, 32);
      n.fillStyle = '#e06a2e'; n.fillRect(x + 2, 108, 102, 3);
      n.fillStyle = '#8a3414'; n.fillRect(x + 2, 128, 102, 12);
      n.fillStyle = '#2a2a32'; n.fillRect(x + 8, 116, 30, 18);            // the hopper
      n.fillStyle = '#3e3e48'; n.fillRect(x + 10, 118, 26, 5);
      for (let k = 0; k < 4; k++) { n.fillStyle = '#4a4a54'; n.fillRect(x + 46 + k * 13, 114, 9, 22); }  // outriggers
      n.fillStyle = '#e8c020'; n.fillRect(x + 44, 110, 56, 4);
      n.fillStyle = '#2a2a32'; n.fillRect(x + 20, 94, 64, 14);            // the turret
      n.fillStyle = '#3e3e48'; n.fillRect(x + 22, 96, 60, 4);
      n.strokeStyle = '#8a3414'; n.lineWidth = 8;                          // the boom, folded back
      n.beginPath(); n.moveTo(x + 52, 94); n.lineTo(x + 32, 62); n.lineTo(x + 100, 54); n.stroke();
      n.strokeStyle = '#c8501e'; n.lineWidth = 5; n.stroke();
      n.fillStyle = '#39414e'; n.fillRect(x + 96, 50, 10, 10);
      n.strokeStyle = '#2a2a32'; n.lineWidth = 3;                          // the delivery line down it
      n.beginPath(); n.moveTo(x + 100, 58); n.quadraticCurveTo(x + 120, 96, x + 112, 140); n.stroke();
      n.fillStyle = '#16141c'; n.beginPath(); n.arc(x + 22, 140, 8, 0, 7); n.arc(x + 82, 140, 8, 0, 7); n.fill();
      n.fillStyle = '#3a3a42'; n.beginPath(); n.arc(x + 22, 140, 3, 0, 7); n.arc(x + 82, 140, 3, 0, 7); n.fill();
    } else if (kind === 2) {                           // rebar cages and a bundle of bar
      for (let s = 0; s < 3; s++) {
        const cx = x + s * 34;
        n.strokeStyle = '#6a5a4a'; n.lineWidth = 1.5;
        for (let k = 0; k < 5; k++) { n.beginPath(); n.moveTo(cx + k * 6, 100); n.lineTo(cx + k * 6, 142); n.stroke(); }
        for (let k = 0; k < 4; k++) { n.beginPath(); n.moveTo(cx, 104 + k * 11); n.lineTo(cx + 24, 104 + k * 11); n.stroke(); }
      }
      n.fillStyle = '#5a4a3a'; n.fillRect(x - 10, 134, 110, 8);
      for (let k = 0; k < 110; k += 5) { n.fillStyle = '#7a6a56'; n.fillRect(x - 10 + k, 134, 2, 8); }
    } else {                                           // skip full of broken brick
      n.fillStyle = '#16141c'; n.fillRect(x, 112, 116, 30);
      n.fillStyle = '#c8a020'; n.fillRect(x + 2, 114, 112, 26);
      n.fillStyle = '#8a6a14'; n.fillRect(x + 2, 114, 112, 4);
      for (let k = 0; k < 40; k++) { n.fillStyle = pick2(R, ['#8a4a3a', '#6a3a2e', '#a8a09a', '#5a5a52']);
        n.fillRect(x + 6 + R() * 104, 106 + R() * 10, 5, 4); }
    }
  }
  // floodlight masts, the thing that lights a site at night
  for (let x = 90; x < L.near.width; x += 300) {
    n.fillStyle = '#16141c'; n.fillRect(x, 40, 4, 102); n.fillRect(x - 12, 36, 28, 5);
    n.fillStyle = '#fff8d0'; n.fillRect(x - 11, 41, 11, 3); n.fillRect(x + 4, 41, 10, 3);
    n.fillStyle = 'rgba(255,248,208,0.08)';
    n.beginPath(); n.moveTo(x - 11, 44); n.lineTo(x - 74, 240); n.lineTo(x + 78, 240); n.lineTo(x + 14, 44); n.fill();
  }
  siteDirt(n, L, R, r, 142, '#6a4a34', '#7a5a40', '#4a3424');
  // tracked plant has been over this all day: crawler prints, dropped bar,
  // boot-churned mud and the floodlights pooling on the wet patches
  for (let k = 0; k < L.near.width / 70; k++) {
    const tx = r(0, L.near.width), ty = r(152, 224);
    for (let s2 = 0; s2 < 8; s2++) { n.fillStyle = 'rgba(0,0,0,0.20)';
      n.fillRect(tx + s2 * 7, ty + s2 * 1.4, 5, 9); }
  }
  for (let k = 0; k < L.near.width / 90; k++) {
    n.fillStyle = pick2(R, ['#6a5a4a', '#7a6a56', '#5a4a3a']);
    n.save(); n.translate(r(0, L.near.width), r(150, 232)); n.rotate(R() * 3);
    n.fillRect(0, 0, 20 + R() * 26, 3); n.restore();
  }
  for (let k = 0; k < L.near.width / 130; k++) {
    n.fillStyle = pick2(R, ['#8a8a94', '#a8a096', '#6a6a72']);
    n.fillRect(r(0, L.near.width), r(154, 230), 7 + R() * 10, 5);
  }
  for (let x = 90; x < L.near.width; x += 300) {
    n.fillStyle = 'rgba(255,248,208,0.07)';
    n.beginPath(); n.ellipse(x + 2, 196, 96, 34, 0, 0, 7); n.fill();
  }
  // the excavation: the shaft hazard is a real hole with a ladder in it
  for (let x = 60; x < L.near.width; x += 230) {
    n.fillStyle = '#e8d020'; n.beginPath(); n.moveTo(x, 162); n.lineTo(x + 6, 146); n.lineTo(x + 12, 162); n.fill();
    n.fillStyle = '#1a1a1e'; n.fillRect(x + 5, 151, 2, 7); n.fillRect(x + 5, 159, 2, 2);
  }
  for (let x = 0; x < L.near.width; x += 14) { n.fillStyle = (Math.round(x / 14) % 2) ? '#e8b020' : '#1a1a1e'; n.fillRect(x, 232, 14, 4); }
}


// ============================================================ STAGE 3-B: the curtain wall
// ---- B4: THE CURTAIN WALL -------------------------------------------------
// The wildcard. The floor is being glazed: panels in, panels stacked, one bay
// still open to the sky, and the whole sunset doubled in the glass.
function glassBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  duskSky(f, L, R, r);
  cityBelow(f, L, R, r, 152);
  for (let x = 0; x < L.far.width; x += 84) { const h = 28 + R() * 54;
    f.fillStyle = '#2a2048'; f.fillRect(x, 152 - h, 38, h);
    for (let k = 0; k < 16; k++) if (R() < 0.3) { f.fillStyle = '#e8c060'; f.fillRect(x + 4 + R() * 30, 152 - h + 4 + R() * (h - 8), 3, 3); } }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  // near: the mullion grid, most bays glazed, some open, some with panels on a trolley
  const HEAD = 34, SILL = 142;
  n.fillStyle = '#39414e'; n.fillRect(0, HEAD - 10, L.near.width, 12);
  n.fillStyle = '#4e5a6a'; n.fillRect(0, HEAD - 10, L.near.width, 3);
  let x = 0, seq = 0;
  while (x < len - 320) {
    const bw = 76;
    const state = seq % 7 === 3 ? 'open' : (seq % 7 === 6 ? 'part' : 'glazed');
    if (state === 'glazed') {
      // the glass: the sky reflected, but shifted and cooler than the real one
      const g = n.createLinearGradient(0, HEAD, 0, SILL);
      g.addColorStop(0, '#2c2a58'); g.addColorStop(0.44, '#6a3a72'); g.addColorStop(0.78, '#c06a52'); g.addColorStop(1, '#e0a068');
      n.fillStyle = g; n.fillRect(x + 4, HEAD, bw - 8, SILL - HEAD);
      n.fillStyle = 'rgba(255,255,255,0.10)';                     // the sheen band
      n.beginPath(); n.moveTo(x + 4, SILL); n.lineTo(x + 30, HEAD); n.lineTo(x + 46, HEAD); n.lineTo(x + 20, SILL); n.fill();
      for (let k = 0; k < 16; k++) { n.fillStyle = 'rgba(242,208,112,0.45)';   // the city's lights, reflected
        n.fillRect(x + 8 + R() * (bw - 20), HEAD + 66 + R() * 42, 2, 2); }
      n.fillStyle = 'rgba(120,150,210,0.10)'; n.fillRect(x + 4, HEAD, bw - 8, SILL - HEAD);
      if (R() < 0.3) {                                            // a panel still carrying its protective film
        n.fillStyle = 'rgba(190,200,210,0.30)'; n.fillRect(x + 4, HEAD, bw - 8, SILL - HEAD);
        n.fillStyle = '#c8302a'; n.fillRect(x + 14, HEAD + 40, bw - 28, 8);
      }
    } else if (state === 'open') {
      n.fillStyle = 'rgba(0,0,0,0)'; n.clearRect(x + 4, HEAD, bw - 8, SILL - HEAD);
      n.fillStyle = '#c87a20'; n.fillRect(x + 4, SILL - 26, bw - 8, 4);       // the barrier across the hole
      n.fillRect(x + 4, SILL - 12, bw - 8, 4);
      for (let k = 0; k < bw - 8; k += 12) { n.fillStyle = '#1a1a1e'; n.fillRect(x + 4 + k, SILL - 26, 6, 4); n.fillRect(x + 4 + k, SILL - 12, 6, 4); }
      n.fillStyle = 'rgba(255,190,120,0.10)'; n.fillRect(x + 4, HEAD, bw - 8, SILL - HEAD - 26);
    } else {
      n.fillStyle = '#1c2029'; n.fillRect(x + 4, HEAD, bw - 8, SILL - HEAD);  // backing board, panel not yet on
      for (let k = 0; k < SILL - HEAD; k += 14) { n.fillStyle = '#262b36'; n.fillRect(x + 4, HEAD + k, bw - 8, 3); }
      n.fillStyle = '#39414e'; n.fillRect(x + 4, HEAD + 40, bw - 8, 5);
    }
    // the mullion itself, and the transom band across the middle
    n.fillStyle = '#39414e'; n.fillRect(x, HEAD - 4, 6, SILL - HEAD + 10);
    n.fillStyle = '#556172'; n.fillRect(x + 1, HEAD - 4, 2, SILL - HEAD + 10);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 4, HEAD - 4, 2, SILL - HEAD + 10);
    n.fillStyle = '#39414e'; n.fillRect(x, HEAD + 52, bw, 6);
    n.fillStyle = '#4e5a6a'; n.fillRect(x, HEAD + 52, bw, 2);
    x += bw; seq++;
  }
  // a stillage of glass waiting to go in, and a vacuum lifter
  for (let px_ = 120; px_ < len - 360; px_ += 380) {
    n.fillStyle = '#2a2e36'; n.fillRect(px_, 108, 90, 34);
    n.fillStyle = '#c8302a'; n.fillRect(px_, 104, 90, 5);
    for (let k = 0; k < 6; k++) { n.fillStyle = `rgba(150,190,200,${0.55 - k * 0.06})`;
      n.save(); n.translate(px_ + 10 + k * 5, 106); n.rotate(0.10); n.fillRect(0, -44, 4, 44); n.restore(); }
    n.fillStyle = '#39414e'; n.fillRect(px_ - 4, 140, 98, 4);
  }
  // the arena: the corner of the building, glazed on both faces
  const a0 = len - 320;
  n.fillStyle = '#39414e'; n.fillRect(a0, HEAD - 10, L.near.width - a0, 12);
  const g2 = n.createLinearGradient(0, HEAD, 0, SILL);
  g2.addColorStop(0, '#26244e'); g2.addColorStop(0.44, '#5e3468'); g2.addColorStop(0.8, '#b8604c'); g2.addColorStop(1, '#d89864');
  n.fillStyle = g2; n.fillRect(a0 + 6, HEAD, L.near.width - a0 - 6, SILL - HEAD);
  for (let k = 0; k < 90; k++) { n.fillStyle = 'rgba(242,208,112,0.40)';
    n.fillRect(a0 + 10 + R() * (L.near.width - a0 - 20), HEAD + 60 + R() * 48, 2, 2); }
  for (let mx = a0; mx < L.near.width; mx += 76) {
    n.fillStyle = '#39414e'; n.fillRect(mx, HEAD - 4, 6, SILL - HEAD + 10);
    n.fillStyle = '#556172'; n.fillRect(mx + 1, HEAD - 4, 2, SILL - HEAD + 10);
  }
  n.fillStyle = '#39414e'; n.fillRect(a0, HEAD + 52, L.near.width - a0, 6);
  n.fillStyle = 'rgba(255,255,255,0.09)';
  n.beginPath(); n.moveTo(a0 + 20, SILL); n.lineTo(a0 + 120, HEAD); n.lineTo(a0 + 160, HEAD); n.lineTo(a0 + 60, SILL); n.fill();
  // the floor: polished screed that picks the sunset up off the glass
  n.fillStyle = '#4a4c56'; n.fillRect(0, SILL, L.near.width, 98);
  for (let k = 0; k < L.near.width * 1.3; k++) { n.fillStyle = R() < 0.5 ? '#53555f' : '#41434c';
    n.fillRect(r(0, L.near.width), r(SILL + 2, 240), 3, 1); }
  for (let x2 = 0; x2 < L.near.width; x2 += 76) { n.fillStyle = 'rgba(0,0,0,0.13)'; n.fillRect(x2, SILL, 2, 98); }
  n.fillStyle = 'rgba(224,160,104,0.13)'; n.fillRect(0, SILL, L.near.width, 40);
  for (let x2 = 0; x2 < L.near.width; x2 += 76) { n.fillStyle = 'rgba(255,200,140,0.10)'; n.fillRect(x2 + 10, SILL, 54, 74); }
  n.fillStyle = '#343640'; n.fillRect(0, SILL, L.near.width, 3);
  n.fillStyle = '#e8b020'; n.fillRect(0, 236, L.near.width, 4);
}


// ============================================================ STAGE 4 helpers
function railPair(n, L, R, ry, sleeper = '#3a3028', rail = '#8a8a96', shine = '#c8c8d4') {
  for (let x = 0; x < L.near.width; x += 22) {
    n.fillStyle = sleeper; n.fillRect(x, ry - 4, 16, 9);
    n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(x, ry + 4, 16, 2);
  }
  n.fillStyle = rail; n.fillRect(0, ry - 5, L.near.width, 2); n.fillRect(0, ry + 4, L.near.width, 2);
  n.fillStyle = shine; n.fillRect(0, ry - 5, L.near.width, 1); n.fillRect(0, ry + 4, L.near.width, 1);
}

// ============================================================ STAGE 4-A: the roundhouse
// ---- A2: THE ROUNDHOUSE ---------------------------------------------------
// Inside the engine shed: a turntable, locomotives nose-in around it, smoke
// vents in a curved roof, inspection pits in the floor.
function roundhouseBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0d0a10'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 120) {          // the far wall of the shed, lost in soot
    m.fillStyle = '#17131a'; m.fillRect(x, 40, 112, 110);
    m.fillStyle = '#1e1920'; m.fillRect(x + 8, 52, 40, 40);
  }
  // near: the roof structure. It has to clear the HUD band (the top 34 rows),
  // so the trusses and vents sit between 36 and 66 with the locos below them.
  n.fillStyle = '#1a1620'; n.fillRect(0, 0, L.near.width, 150);
  n.fillStyle = '#131019'; n.fillRect(0, 0, L.near.width, 36);
  for (let x = 0; x < L.near.width; x += 150) {
    n.fillStyle = '#2a2430'; n.fillRect(x, 0, 6, 150);                       // the column
    n.fillStyle = '#382f40'; n.fillRect(x + 1, 0, 2, 150);
    n.strokeStyle = '#2a2430'; n.lineWidth = 4;                              // the truss
    n.beginPath(); n.moveTo(x, 64); n.lineTo(x + 75, 40); n.lineTo(x + 150, 64); n.stroke();
    n.strokeStyle = '#241f2c'; n.lineWidth = 2;
    for (let k = 0; k < 5; k++) { n.beginPath(); n.moveTo(x + 15 + k * 30, 64); n.lineTo(x + 40 + k * 22, 46); n.stroke(); }
    n.fillStyle = '#2a2430'; n.fillRect(x, 64, 150, 4);
    // the smoke vent, with the night sky showing through it
    n.fillStyle = '#0a0812'; n.fillRect(x + 54, 34, 44, 12);
    for (let k = 0; k < 40; k += 6) { n.fillStyle = '#2a2430'; n.fillRect(x + 56 + k, 34, 3, 12); }
    n.fillStyle = 'rgba(160,180,220,0.06)'; n.fillRect(x + 50, 46, 52, 30);
    // lamps on hooks down the roads
    n.fillStyle = '#16121c'; n.fillRect(x + 72, 66, 2, 12);
    n.fillStyle = '#ffe8a0'; n.beginPath(); n.arc(x + 73, 81, 5, 0, 7); n.fill();
    n.fillStyle = 'rgba(255,232,160,0.10)'; n.beginPath(); n.arc(x + 73, 84, 22, 0, 7); n.fill();
  }
  // the locomotives, nose-in on their roads
  for (let x = 20; x < len - 340; x += 190) {
    const c = pick2(R, ['#1e2a22', '#2a1e1e', '#1e2230', '#2a2418']);
    n.fillStyle = '#0a080e'; n.fillRect(x - 2, 72, 130, 78);
    n.fillStyle = c; n.fillRect(x, 74, 126, 74);
    n.fillStyle = 'rgba(255,255,255,0.07)'; n.fillRect(x, 74, 126, 3);
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, 134, 126, 14);
    n.fillStyle = '#12100f'; n.beginPath(); n.arc(x + 63, 112, 28, 0, 7); n.fill();   // smokebox door
    n.fillStyle = '#26242a'; n.beginPath(); n.arc(x + 63, 112, 24, 0, 7); n.fill();
    n.fillStyle = '#4a4650'; n.beginPath(); n.arc(x + 63, 112, 5, 0, 7); n.fill();
    n.fillStyle = '#6a5a3a'; n.fillRect(x + 60, 106, 6, 14);
    n.fillStyle = '#e8d070'; n.fillRect(x + 50, 80, 26, 9);                          // the lamp
    n.fillStyle = 'rgba(232,208,112,0.14)'; n.fillRect(x + 34, 88, 58, 52);
    n.fillStyle = '#c8302a'; n.fillRect(x + 20, 128, 86, 7);                          // buffer beam
    for (const bx of [x + 14, x + 106]) { n.fillStyle = '#39414e'; n.beginPath(); n.arc(bx, 131, 6, 0, 7); n.fill(); }
    n.fillStyle = '#2a2830'; n.fillRect(x + 16, 140, 94, 8);
  }
  // the turntable at the end: the pit, the deck and its girder
  const t0 = len - 340;
  n.fillStyle = '#100d14'; n.fillRect(t0, 70, L.near.width - t0, 80);
  n.fillStyle = 'rgba(180,200,240,0.05)'; n.fillRect(t0, 70, L.near.width - t0, 52);
  n.fillStyle = '#2a2632'; n.fillRect(t0 + 20, 126, L.near.width - t0 - 40, 24);
  n.fillStyle = '#39414e'; n.fillRect(t0 + 20, 126, L.near.width - t0 - 40, 4);
  n.strokeStyle = '#4a4450'; n.lineWidth = 3;
  n.beginPath(); n.moveTo(t0 + 30, 126); n.lineTo(t0 + 110, 96); n.lineTo(t0 + 190, 126); n.stroke();
  neonText(n, 'SHED 3', t0 + 60, 82, '#e8b020', 2);
  // the floor: oily setts, inspection pits and the rails into every road
  n.fillStyle = '#26232a'; n.fillRect(0, 150, L.near.width, 90);
  for (let y = 150; y < 240; y += 8) for (let x2 = 0; x2 < L.near.width; x2 += 11) {
    n.fillStyle = R() < 0.5 ? '#2c2930' : '#211e26';
    n.fillRect(x2 + ((Math.round(y / 8)) % 2) * 5, y, 10, 7);
  }
  for (let px_ = 40; px_ < L.near.width; px_ += 190) {                        // inspection pits
    n.fillStyle = '#0a090d'; n.fillRect(px_, 180, 96, 24);
    n.fillStyle = '#16141a'; n.fillRect(px_ + 3, 183, 90, 18);
    n.fillStyle = 'rgba(232,208,112,0.10)'; n.fillRect(px_ + 8, 186, 80, 12);
    n.fillStyle = '#4a4450'; n.fillRect(px_, 178, 96, 3); n.fillRect(px_, 203, 96, 3);
  }
  for (const ry of [172, 212]) railPair(n, L, R, ry, '#2a2520', '#7a7a86', '#a8a8b4');
  for (let k = 0; k < L.near.width / 90; k++) { n.fillStyle = 'rgba(0,0,0,0.34)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(158, 234), 16 + R() * 18, 5 + R() * 4, 0, 0, 7); n.fill(); }
  L.steamShed = 1;
}


// ============================================================ STAGE 4-B: the bridge run
// ---- B4: THE BRIDGE RUN ---------------------------------------------------
// The wildcard: the train is crossing a long girder bridge. The structure
// whips past on both sides, the river is a long way down, and the arena is the
// middle of the span where the steel opens out.
function bridgeBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  nightSky(f, L, R, r, '#04040f', '#121036', '#38224e');
  // far: the far bank and the water, a long way below
  f.fillStyle = '#0c0a1c'; f.fillRect(0, 108, L.far.width, 18);
  for (let x = 0; x < L.far.width; x += 30) { const h = 6 + R() * 18;
    f.fillStyle = '#141028'; f.fillRect(x, 108 - h, 26, h + 12);
    if (R() < 0.45) { f.fillStyle = '#c8a048'; f.fillRect(x + 6 + R() * 14, 112 - h, 2, 2); } }
  f.fillStyle = '#080a1c'; f.fillRect(0, 126, L.far.width, 114);
  for (let k = 0; k < L.far.width * 1.6; k++) {
    f.fillStyle = R() < 0.14 ? 'rgba(170,190,240,0.20)' : 'rgba(22,30,64,0.55)';
    f.fillRect(r(0, L.far.width), r(128, 238), 6 + R() * 12, 1);
  }
  for (let k = 0; k < 120; k++) { f.fillStyle = 'rgba(232,200,120,0.16)';      // the lights' reflection
    f.fillRect(r(0, L.far.width), r(130, 210), 3, 1); }
  // mid: the far truss of the bridge, and the piers going down into the water
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 96) {
    m.fillStyle = '#1c1826'; m.fillRect(x, 46, 6, 104);
    m.strokeStyle = '#1c1826'; m.lineWidth = 4;
    m.beginPath(); m.moveTo(x + 3, 46); m.lineTo(x + 48, 96); m.lineTo(x + 96, 46); m.stroke();
    m.beginPath(); m.moveTo(x + 3, 96); m.lineTo(x + 48, 46); m.stroke();
  }
  m.fillStyle = '#1c1826'; m.fillRect(0, 40, L.mid.width, 8);
  m.fillStyle = '#272132'; m.fillRect(0, 40, L.mid.width, 2);
  L.speed = 1.5;
  // near: the deck you are on, and the near truss whipping past in front
  n.fillStyle = '#2f3641'; n.fillRect(0, 150, L.near.width, 90);
  for (let px_ = 0; px_ < L.near.width; px_ += 14) {                            // the deck: transverse timbers
    n.fillStyle = R() < 0.5 ? '#39414e' : '#333b47'; n.fillRect(px_, 150, 13, 90);
    n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(px_ + 13, 150, 2, 90);
  }
  n.fillStyle = '#242a34'; n.fillRect(0, 150, L.near.width, 4);
  for (const ry of [176, 214]) {                                                // the rails you are walking between
    n.fillStyle = '#8a8a96'; n.fillRect(0, ry, L.near.width, 4);
    n.fillStyle = '#c8c8d4'; n.fillRect(0, ry, L.near.width, 1.5);
    n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(0, ry + 4, L.near.width, 2);
  }
  // the near truss: verticals and diagonals in front of the fight, at speed
  // The near truss sits in front of the fight, so it is deliberately dark and
  // low-contrast - it reads as structure whipping past without competing with
  // the sprites for attention. The diagonals stop short of the walkable band.
  for (let x = 0; x < L.near.width; x += 96) {
    n.fillStyle = '#2a2028'; n.fillRect(x, 14, 10, 136);
    n.fillStyle = '#352a31'; n.fillRect(x + 1, 14, 3, 136);
    n.fillStyle = 'rgba(0,0,0,0.42)'; n.fillRect(x + 7, 14, 3, 136);
    n.strokeStyle = '#2a2028'; n.lineWidth = 6;
    n.beginPath(); n.moveTo(x + 5, 20); n.lineTo(x + 48, 82); n.lineTo(x + 96, 20); n.stroke();
    n.strokeStyle = '#231a21'; n.lineWidth = 4;
    n.beginPath(); n.moveTo(x + 5, 82); n.lineTo(x + 48, 20); n.stroke();
    for (let k = 0; k < 130; k += 18) { n.fillStyle = '#463945'; n.fillRect(x + 2, 20 + k, 2, 2); }
    n.fillStyle = '#20202a'; n.fillRect(x - 3, 146, 16, 5);                     // the shoe on the deck
  }
  n.fillStyle = '#2a2028'; n.fillRect(0, 8, L.near.width, 11);                  // the top chord, overhead
  n.fillStyle = '#382c35'; n.fillRect(0, 8, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 22) { n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, 19, 6, 4); }
  // the middle of the span: the steel opens out for the fight
  const a0 = len - 320;
  n.clearRect(a0 + 20, 8, 240, 142);
  n.fillStyle = '#2a2028'; n.fillRect(a0 + 20, 8, 240, 11);
  n.fillStyle = '#382c35'; n.fillRect(a0 + 20, 8, 240, 3);
  for (const px_ of [a0 + 20, a0 + 250]) {
    n.fillStyle = '#2a2028'; n.fillRect(px_, 14, 12, 136);
    n.fillStyle = '#352a31'; n.fillRect(px_ + 1, 14, 3, 136);
  }
  n.strokeStyle = '#2a2028'; n.lineWidth = 6;
  n.beginPath(); n.moveTo(a0 + 30, 22); n.lineTo(a0 + 136, 66); n.lineTo(a0 + 250, 22); n.stroke();
  n.fillStyle = '#c8302a'; n.fillRect(a0 + 110, 30, 58, 22);
  ptext(n, 'SPAN 7', a0 + 118, 37, '#f0e8e0', 1);
  n.fillStyle = '#2f3641'; n.fillRect(a0 + 20, 150, 240, 90);
  for (let px_ = a0 + 20; px_ < a0 + 260; px_ += 14) {
    n.fillStyle = R() < 0.5 ? '#39414e' : '#333b47'; n.fillRect(px_, 150, 13, 90);
    n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(px_ + 13, 150, 2, 90);
  }
  for (const ry of [176, 214]) {
    n.fillStyle = '#8a8a96'; n.fillRect(a0 + 20, ry, 240, 4);
    n.fillStyle = '#c8c8d4'; n.fillRect(a0 + 20, ry, 240, 1.5);
  }
}

// ------------------------------------------------------------ live overlay
// Steam drifting up off the locomotives in the shed.
function drawShedSteam(cx) {
  for (let i = 0; i < 8; i++) {
    const seed = i * 193;
    const life = (G.frames * 0.42 + seed) % 200;
    const x = ((seed * 31) % 1600) - (cx % 1600);
    if (x < -50 || x > W + 50) continue;
    const a = Math.max(0, 0.22 * (1 - life / 200));
    ctx.fillStyle = `rgba(226,226,236,${a})`;
    ctx.beginPath(); ctx.arc(x + Math.sin(life / 26) * 10, 150 - life * 0.62, 7 + life * 0.13, 0, 7); ctx.fill();
  }
}


// ============================================================ STAGE 5 helpers
function asphalt(n, L, R, r, top, a, b, c, opts = {}) {
  n.fillStyle = a; n.fillRect(0, top, L.near.width, 240 - top);
  for (let k = 0; k < L.near.width * 1.5; k++) { n.fillStyle = R() < 0.5 ? b : c;
    n.fillRect(r(0, L.near.width), r(top + 1, 240), 3, 1); }
  for (let k = 0; k < L.near.width / 170; k++) {                      // patched repairs
    n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(r(0, L.near.width), r(top + 4, 232), 34 + R() * 60, 9 + R() * 12); }
  for (const ty of [top + 26, top + 62]) for (let x = 0; x < L.near.width; x += 2) {
    if (R() < 0.5) { n.fillStyle = 'rgba(255,255,255,0.025)'; n.fillRect(x, ty, 2, 6); }
  }
  n.fillStyle = opts.edge || '#3a3a44'; n.fillRect(0, top, L.near.width, 2);
}
function laneMarks(n, L, ys, col = '#e8e4c8', dash = 28, gap = 26) {
  for (const ly of ys) for (let x = 0; x < L.near.width; x += dash + gap) { n.fillStyle = col; n.fillRect(x, ly, dash, 3); }
}
function guardrail(n, L, R, y, opts = {}) {
  n.fillStyle = opts.dark || '#3a3e48'; n.fillRect(0, y + 6, L.near.width, 4);
  n.fillStyle = '#8a8e9a'; n.fillRect(0, y, L.near.width, 7);
  n.fillStyle = '#c8ccd8'; n.fillRect(0, y, L.near.width, 2);
  n.fillStyle = 'rgba(0,0,0,0.28)'; n.fillRect(0, y + 5, L.near.width, 2);
  for (let x = 0; x < L.near.width; x += 34) {
    n.fillStyle = '#4a4e5a'; n.fillRect(x, y + 7, 5, 15);
    if (R() < 0.07) { n.fillStyle = '#6a6e7a'; n.fillRect(x - 6, y - 2, 20, 10); }   // a bent length
  }
  for (let x = 12; x < L.near.width; x += 68) { n.fillStyle = '#e8342a'; n.fillRect(x, y + 1, 3, 3); }  // reflectors
}

// lane markings that streak rather than sit still - drawn short and low
// contrast so they read as speed without fighting the sprites
function rideLanes(n, L, ys, col, dash = 22, gap = 34) {
  for (const ly of ys) for (let x = 0; x < L.near.width; x += dash + gap) {
    n.fillStyle = col; n.fillRect(x, ly, dash, 3);
    n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(x + dash, ly + 1, gap * 0.4, 1);
  }
}


// ============================================================ STAGE 5-A: the tunnel
// ---- A3: THE TUNNEL -------------------------------------------------------
function tunnelBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#07070a'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  // the opposite bore, seen through the piers between the carriageways
  for (let x = 0; x < L.mid.width; x += 56) {
    m.fillStyle = '#101218'; m.fillRect(x, 52, 44, 92);
    m.fillStyle = '#171a22'; m.fillRect(x + 4, 56, 36, 42);
    if (R() < 0.3) { m.fillStyle = '#e8c860'; m.fillRect(x + 12 + R() * 20, 104, 5, 3); }
  }
  // near: the bore. Tiled walls, a haunch above, and the sodium ribbon.
  n.fillStyle = '#14161c'; n.fillRect(0, 0, L.near.width, 150);
  n.fillStyle = '#1c2029'; n.fillRect(0, 34, L.near.width, 8);
  // Sodium-lit tile, not daylight tile: warm, mid-toned and a good step darker
  // than the fighters, so the sprites read against it rather than into it.
  for (let ty = 42; ty < 128; ty += 11) for (let tx = 0; tx < L.near.width; tx += 15) {
    const t2 = R();
    n.fillStyle = t2 < 0.06 ? '#4e4a3e' : t2 < 0.5 ? '#8d8874' : '#84806d';
    n.fillRect(tx, ty, 14, 10);
  }
  n.fillStyle = 'rgba(30,20,8,0.22)'; n.fillRect(0, 42, L.near.width, 86);
  n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(0, 42, L.near.width, 86);
  for (let k = 0; k < L.near.width / 10; k++) { n.fillStyle = 'rgba(40,34,26,0.35)';   // grime up the tiles
    n.fillRect(r(0, L.near.width), r(96, 128), 12 + R() * 26, 6 + R() * 14); }
  n.fillStyle = '#2a2e36'; n.fillRect(0, 128, L.near.width, 8);
  n.fillStyle = '#3a404a'; n.fillRect(0, 128, L.near.width, 2);
  // the light ribbon, running the whole length just under the haunch
  n.fillStyle = '#1a1e26'; n.fillRect(0, 44, L.near.width, 9);
  for (let x = 0; x < L.near.width; x += 44) {
    const dead = R() < 0.08;
    n.fillStyle = dead ? '#3a3a40' : '#ffca6a'; n.fillRect(x + 3, 46, 36, 5);
    if (!dead) { n.fillStyle = 'rgba(255,202,106,0.10)'; n.fillRect(x - 6, 51, 56, 80); }
  }
  // ventilation fans and emergency niches let into the wall
  for (let x = 120; x < L.near.width; x += 300) {
    n.fillStyle = '#1a1e26'; n.fillRect(x, 56, 44, 44);
    n.fillStyle = '#242a34'; n.fillRect(x + 3, 59, 38, 38);
    n.fillStyle = '#12151b'; n.beginPath(); n.arc(x + 22, 78, 16, 0, 7); n.fill();
    for (let k = 0; k < 5; k++) { n.fillStyle = '#39414e'; n.save(); n.translate(x + 22, 78);
      n.rotate(k * 0.63); n.fillRect(-2, -15, 4, 30); n.restore(); }
    n.fillStyle = '#4a5260'; n.beginPath(); n.arc(x + 22, 78, 4, 0, 7); n.fill();
  }
  for (let x = 260; x < L.near.width; x += 300) {
    n.fillStyle = '#0e1016'; n.fillRect(x, 84, 30, 44);
    n.fillStyle = '#c8302a'; n.fillRect(x + 2, 86, 26, 14);
    ptext(n, 'SOS', x + 7, 89, '#f0e8e0', 1);
    n.fillStyle = '#2a2e36'; n.fillRect(x + 6, 104, 18, 22);
    n.fillStyle = '#e8c020'; n.fillRect(x + 9, 108, 12, 9);
  }
  // the service walkway along the wall, then the carriageway
  n.fillStyle = '#4a4e58'; n.fillRect(0, 136, L.near.width, 14);
  n.fillStyle = '#5a5f6a'; n.fillRect(0, 136, L.near.width, 3);
  for (let x = 0; x < L.near.width; x += 34) { n.fillStyle = 'rgba(0,0,0,0.20)'; n.fillRect(x, 138, 2, 12); }
  n.fillStyle = '#c8b030'; n.fillRect(0, 148, L.near.width, 3);
  asphalt(n, L, R, r, 151, '#24242a', '#2c2c34', '#1c1c22');
  laneMarks(n, L, [190, 222], 'rgba(232,228,200,0.85)');
  // The ribbon lays a continuous wash down the road rather than a row of discs -
  // discrete pools read as blobs under a light that is itself continuous.
  n.fillStyle = 'rgba(255,202,106,0.05)'; n.fillRect(0, 151, L.near.width, 89);
  const gw = n.createLinearGradient(0, 151, 0, 240);
  gw.addColorStop(0, 'rgba(255,202,106,0.13)');
  gw.addColorStop(0.55, 'rgba(255,190,90,0.06)');
  gw.addColorStop(1, 'rgba(255,180,80,0.02)');
  n.fillStyle = gw; n.fillRect(0, 151, L.near.width, 89);
  for (let x = 0; x < L.near.width; x += 44) {      // a faint brightening under each fitting
    n.fillStyle = 'rgba(255,214,130,0.045)';
    n.beginPath(); n.ellipse(x + 20, 176, 30, 22, 0, 0, 7); n.fill();
  }
  L.tunnelHum = 1;
}


// ============================================================ STAGE 5-B: the dawn highway
// ---- B1: DAWN HIGHWAY -----------------------------------------------------
function dawnRoadBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const sky = f.createLinearGradient(0, 0, 0, 150);
  sky.addColorStop(0, '#1a1440'); sky.addColorStop(0.5, '#8a3a6a'); sky.addColorStop(1, '#f0a050');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  f.fillStyle = '#ffe0a0'; f.beginPath(); f.arc(L.far.width * 0.42, 120, 26, 0, 7); f.fill();
  f.fillStyle = 'rgba(255,224,160,0.20)'; f.beginPath(); f.arc(L.far.width * 0.42, 120, 52, 0, 7); f.fill();
  for (let k = 0; k < 12; k++) { f.fillStyle = 'rgba(255,200,170,0.18)'; f.fillRect(r(0, L.far.width), r(30, 100), r(60, 130), 4); }
  skyline(f, L, R, r, 128, '#3a2044', '#ffd890', 24, 74);
  // mid: sound walls and lamp standards whipping past
  for (let x = 0; x < L.mid.width; x += 46) {
    m.fillStyle = (Math.round(x / 46) % 2) ? '#221c34' : '#1c1730'; m.fillRect(x, 96, 46, 54);
    m.fillStyle = 'rgba(255,255,255,0.05)'; m.fillRect(x, 96, 46, 2);
  }
  for (let x = 0; x < L.mid.width; x += 184) {
    m.fillStyle = '#14101e'; m.fillRect(x, 26, 4, 74); m.fillRect(x, 26, 22, 4);
    m.fillStyle = '#ffe8a0'; m.fillRect(x + 16, 30, 8, 3);
    m.fillStyle = 'rgba(255,232,160,0.09)'; m.beginPath(); m.moveTo(x + 16, 33); m.lineTo(x - 20, 150); m.lineTo(x + 60, 150); m.lineTo(x + 24, 33); m.fill();
  }
  L.speed = 1.6;
  // Near layer. The traffic has to sit BEYOND the barrier, on the opposite
  // carriageway: anything painted inside the walkable band (150..230) would be
  // walked straight through, and on a board run that reads as a bug.
  n.fillStyle = '#23232a'; n.fillRect(0, 104, L.near.width, 28);
  for (let k = 0; k < L.near.width; k++) { n.fillStyle = R() < 0.5 ? '#2a2a32' : '#1d1d24';
    n.fillRect(r(0, L.near.width), r(106, 130), 3, 1); }
  n.fillStyle = '#e8e4c8'; for (let x = 0; x < L.near.width; x += 54) n.fillRect(x, 118, 26, 2);
  // oncoming traffic, small and high, with headlights coming at you
  for (let x = 40; x < L.near.width; x += 190 + R() * 140) {
    const c = pick2(R, ['#7a2a30', '#2a4a6a', '#3a3a42', '#6a6a58', '#2a5a4a', '#8a7a30']);
    n.fillStyle = '#0e0c14'; n.fillRect(x - 24, 108, 50, 15);
    n.fillStyle = c; n.fillRect(x - 23, 109, 48, 13);
    n.fillStyle = 'rgba(255,255,255,0.12)'; n.fillRect(x - 23, 109, 48, 2);
    n.fillStyle = '#1e2a3a'; n.fillRect(x - 15, 111, 30, 6);
    n.fillStyle = '#fff4c0'; n.fillRect(x - 26, 116, 5, 4); n.fillRect(x + 21, 116, 5, 4);
    n.fillStyle = 'rgba(255,244,192,0.16)'; n.fillRect(x - 46, 114, 24, 8); n.fillRect(x + 24, 114, 24, 8);
    n.fillStyle = '#0e0c14'; n.fillRect(x - 20, 123, 42, 3);
  }
  // the central barrier, then your carriageway - and nothing on it
  n.fillStyle = '#2e2036'; n.fillRect(0, 132, L.near.width, 16);
  guardrail(n, L, R, 130);
  asphalt(n, L, R, r, 148, '#26262c', '#2e2e36', '#1e1e24');
  rideLanes(n, L, [192, 224], 'rgba(232,228,200,0.75)');
  n.fillStyle = '#e8c020'; n.fillRect(0, 236, L.near.width, 3);
  n.fillStyle = 'rgba(255,190,120,0.07)'; n.fillRect(0, 148, L.near.width, 92);
}



// ============================================================ STAGE 6 helpers
function heatWash(n, L, y0, y1, col = 'rgba(255,140,40,0.10)') {
  const g = n.createLinearGradient(0, y0, 0, y1);
  g.addColorStop(0, col); g.addColorStop(1, 'rgba(255,120,20,0)');
  n.fillStyle = g; n.fillRect(0, y0, L.near.width, y1 - y0);
}
function gantry(n, L, R, y, col = '#39414e', hi = '#4e5a6a') {
  n.fillStyle = col; n.fillRect(0, y, L.near.width, 12);
  n.fillStyle = hi; n.fillRect(0, y, L.near.width, 3);
  n.strokeStyle = col; n.lineWidth = 3;
  for (let x = 0; x < L.near.width; x += 30) {
    n.beginPath(); n.moveTo(x, y + 12); n.lineTo(x + 15, y + 26); n.lineTo(x + 30, y + 12); n.stroke();
  }
  n.fillStyle = col; n.fillRect(0, y + 26, L.near.width, 7);
  n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(0, y + 33, L.near.width, 4);
  for (let x = 6; x < L.near.width; x += 14) { n.fillStyle = hi; n.fillRect(x, y + 4, 2, 2); }
}
function pipeRun(n, L, R, ys, cool) {
  for (const py of ys) {
    n.fillStyle = cool ? '#39414e' : '#4a3028'; n.fillRect(0, py, L.near.width, 9);
    n.fillStyle = cool ? '#4e5a6a' : '#5e3c30'; n.fillRect(0, py, L.near.width, 2);
    n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(0, py + 7, L.near.width, 2);
    for (let x = 0; x < L.near.width; x += 130) { n.fillStyle = '#20242c'; n.fillRect(x, py - 2, 8, 13); }
    for (let x = 60; x < L.near.width; x += 260) {                       // a valve wheel on the run
      n.fillStyle = '#2a2e36'; n.fillRect(x, py - 8, 5, 8);
      n.strokeStyle = '#5a6270'; n.lineWidth = 2;
      n.beginPath(); n.arc(x + 2.5, py - 11, 6, 0, 7); n.stroke();
    }
  }
}
function plateFloor(n, L, R, r, top, a, b, c, diamond) {
  n.fillStyle = a; n.fillRect(0, top, L.near.width, 240 - top);
  for (let k = 0; k < L.near.width * 1.3; k++) { n.fillStyle = R() < 0.5 ? b : c;
    n.fillRect(r(0, L.near.width), r(top + 2, 240), 3, 1); }
  for (let x = 0; x < L.near.width; x += 46) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x, top, 2, 240 - top); }
  for (let y = top + 22; y < 240; y += 24) { n.fillStyle = 'rgba(0,0,0,0.16)'; n.fillRect(0, y, L.near.width, 2); }
  if (diamond) for (let y = top + 6; y < 240; y += 10) for (let x = (Math.round(y / 10) % 2) * 6; x < L.near.width; x += 12) {
    n.fillStyle = 'rgba(255,255,255,0.045)'; n.fillRect(x, y, 5, 3);
  }
  n.fillStyle = c; n.fillRect(0, top, L.near.width, 3);
}
// (the yard-ballast helper, needed by the torpedo option)
function ballast(n, L, R, r, base, a, b, c) {
  n.fillStyle = a; n.fillRect(0, base, L.near.width, 240 - base);
  for (let k = 0; k < L.near.width * 2.2; k++) { n.fillStyle = R() < 0.5 ? b : c;
    n.fillRect(r(0, L.near.width), r(base + 2, 240), 2, 2); }
  n.fillStyle = c; n.fillRect(0, base, L.near.width, 3);
}
function grating(n, L, top, h, a = '#2a3038', b = '#3e4650') {
  n.fillStyle = a; n.fillRect(0, top, L.near.width, h);
  for (let x = 0; x < L.near.width; x += 7) { n.fillStyle = b; n.fillRect(x, top, 4, h);
    n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(x + 4, top, 3, h); }
  for (let y = top; y < top + h; y += 16) { n.fillStyle = '#4e5a6a'; n.fillRect(0, y, L.near.width, 2); }
}
function moltenRun(n, L, R, r, x0, x1, y, h) {
  n.fillStyle = '#1a0e0a'; n.fillRect(x0, y - 3, x1 - x0, h + 6);
  const g = n.createLinearGradient(0, y, 0, y + h);
  g.addColorStop(0, '#fff0a0'); g.addColorStop(0.35, '#ffb020'); g.addColorStop(0.75, '#e0500c'); g.addColorStop(1, '#a01e04');
  n.fillStyle = g; n.fillRect(x0, y, x1 - x0, h);
  for (let k = 0; k < (x1 - x0) / 6; k++) { n.fillStyle = 'rgba(0,0,0,0.20)';
    n.fillRect(r(x0, x1), y + r(0, h), 4 + R() * 10, 2); }
  for (let k = 0; k < (x1 - x0) / 14; k++) { n.fillStyle = 'rgba(255,255,220,0.55)';
    n.fillRect(r(x0, x1), y + r(1, h - 2), 3 + R() * 7, 1); }
  n.fillStyle = 'rgba(255,150,40,0.16)'; n.fillRect(x0 - 16, y - 40, x1 - x0 + 32, h + 46);
}


// ============================================================ 6-A: the cast house
// ---- A1: THE CAST HOUSE ---------------------------------------------------
function castHouseBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#1a0c08'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 130) {
    const g = f.createLinearGradient(0, 0, 0, 150);
    g.addColorStop(0, '#2a1008'); g.addColorStop(0.7, '#6a2008'); g.addColorStop(1, '#e06a10');
    f.fillStyle = g; f.fillRect(x, 30, 108, 120);
    f.fillStyle = '#140804'; f.fillRect(x + 108, 0, 22, 150);
  }
  // mid: the furnace stack itself, with its gas offtakes and stove line
  m.fillStyle = '#2a1a16'; m.fillRect(L.mid.width * 0.34, 0, 150, 150);
  m.fillStyle = '#3a241e'; m.fillRect(L.mid.width * 0.34 + 8, 0, 26, 150);
  for (let k = 0; k < 5; k++) { m.fillStyle = '#1e1310'; m.fillRect(L.mid.width * 0.34, 20 + k * 30, 150, 7); }
  for (let x = 0; x < L.mid.width; x += 260) {
    m.fillStyle = '#241713'; m.fillRect(x, 26, 44, 124);
    m.fillStyle = '#31201a'; m.fillRect(x + 4, 26, 12, 124);
    m.beginPath(); m.moveTo(x - 4, 26); m.lineTo(x + 22, 8); m.lineTo(x + 48, 26); m.fill();
  }
  for (let y = 0; y < 48; y += 16) { m.fillStyle = '#2a1e1a'; m.fillRect(0, y, L.mid.width, 6);
    m.fillStyle = '#3c2a24'; m.fillRect(0, y, L.mid.width, 1); }
  // near: the cast house. Gantry over, pipes, the tap hole and the runner.
  gantry(n, L, R, 40, '#3a2620', '#54372c');
  pipeRun(n, L, R, [80, 98], false);
  for (let x = 0; x < L.near.width; x += 176) {
    n.fillStyle = '#2e1c14'; n.fillRect(x, 0, 42, 150);
    n.fillStyle = '#40261c'; n.fillRect(x + 3, 0, 11, 150);
    n.fillStyle = 'rgba(0,0,0,0.38)'; n.fillRect(x + 38, 0, 5, 150);
    n.fillStyle = '#ff8a10'; n.fillRect(x + 12, 118, 18, 5);
    n.fillStyle = 'rgba(255,138,16,0.14)';
    n.beginPath(); n.moveTo(x + 12, 123); n.lineTo(x - 20, 240); n.lineTo(x + 62, 240); n.lineTo(x + 30, 123); n.fill();
  }
  // the tap hole, with iron running out of it down a sand runner
  const t0 = 240;
  n.fillStyle = '#2a1410'; n.fillRect(t0 - 40, 70, 120, 54);
  n.fillStyle = '#3a1c16'; n.fillRect(t0 - 34, 74, 108, 46);
  n.fillStyle = '#0e0604'; n.beginPath(); n.arc(t0 + 20, 100, 15, 0, 7); n.fill();
  n.save(); n.shadowColor = '#ffd060'; n.shadowBlur = 16;
  n.fillStyle = '#fff0a0'; n.beginPath(); n.arc(t0 + 20, 100, 9, 0, 7); n.fill(); n.restore();
  // The runner sits ABOVE the walkable band (150..230) - iron painted inside it
  // would be walked through, which is worse than not having it at all.
  n.fillStyle = '#1e120c'; n.fillRect(0, 124, len - 300, 24);
  n.fillStyle = '#2a1a12'; n.fillRect(0, 124, len - 300, 3);
  moltenRun(n, L, R, r, 0, len - 300, 130, 13);
  n.fillStyle = '#241610'; n.fillRect(0, 145, len - 300, 5);            // the runner's sand bank
  // ladle cars on their rails behind the runner
  for (let x = 120; x < len - 320; x += 300) {
    n.fillStyle = '#1a1014'; n.fillRect(x, 78, 108, 40);
    n.fillStyle = '#3a2a2a'; n.fillRect(x + 4, 80, 100, 36);
    n.fillStyle = '#4a3636'; n.fillRect(x + 4, 80, 100, 4);
    n.fillStyle = '#ffb020'; n.fillRect(x + 14, 74, 80, 6);
    n.fillStyle = 'rgba(255,176,32,0.16)'; n.fillRect(x - 4, 64, 118, 24);
    n.fillStyle = '#16121a'; n.beginPath(); n.arc(x + 22, 118, 7, 0, 7); n.arc(x + 86, 118, 7, 0, 7); n.fill();
  }
  // the pouring bay at the end: the arena
  const a0 = len - 300;
  n.fillStyle = '#1e0f0b'; n.fillRect(a0, 0, L.near.width - a0, 150);
  n.fillStyle = '#2e1a14'; n.fillRect(a0 + 20, 30, L.near.width - a0 - 40, 116);
  for (let k = 0; k < 40; k++) { n.fillStyle = 'rgba(255,150,40,0.10)';
    n.fillRect(r(a0, L.near.width), r(40, 140), 10 + R() * 22, 5); }
  n.fillStyle = '#2a2028'; n.fillRect(a0 + 60, 18, 120, 56);
  n.fillStyle = '#3a2c30'; n.fillRect(a0 + 60, 18, 120, 5);
  n.fillStyle = '#ffb020'; n.fillRect(a0 + 74, 72, 92, 7);
  n.fillStyle = 'rgba(255,176,32,0.20)'; n.fillRect(a0 + 50, 78, 140, 62);
  plateFloor(n, L, R, r, 148, '#3a2a22', '#463229', '#241810', false);
  for (let k = 0; k < 26; k++) { n.fillStyle = 'rgba(255,140,30,0.16)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(160, 234), 10 + R() * 20, 3 + R() * 4, 0, 0, 7); n.fill(); }
  heatWash(n, L, 150, 240, 'rgba(255,140,40,0.13)');
  L.heat = 1;
}


// ============================================================ 6-B: the assembly line
// ---- B1: THE LINE ---------------------------------------------------------
function assemblyLineBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0c0e16'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 120) {
    const g = f.createLinearGradient(0, 0, 0, 150);
    g.addColorStop(0, '#12161f'); g.addColorStop(1, '#1c2430');
    f.fillStyle = g; f.fillRect(x, 40, 100, 110);
    f.fillStyle = '#080a10'; f.fillRect(x + 100, 0, 20, 150);
  }
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 150) {                    // the next line over
    m.fillStyle = '#141b26'; m.fillRect(x, 84, 140, 14);
    m.fillStyle = '#1e2836'; m.fillRect(x, 84, 140, 3);
    for (let k = 0; k < 6; k++) { m.fillStyle = '#26303e'; m.fillRect(x + 10 + k * 22, 70, 14, 14); }
  }
  gantry(n, L, R, 20, '#2a323c', '#3e4a58');
  pipeRun(n, L, R, [62], true);
  for (let x = 0; x < L.near.width; x += 178) {
    n.fillStyle = '#1c2230'; n.fillRect(x, 0, 40, 150);
    n.fillStyle = '#2a3546'; n.fillRect(x + 3, 0, 10, 150);
    n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(x + 36, 0, 5, 150);
    n.fillStyle = '#2ad0f0'; n.fillRect(x + 12, 96, 16, 4);
    n.fillStyle = 'rgba(42,208,240,0.10)';
    n.beginPath(); n.moveTo(x + 12, 100); n.lineTo(x - 18, 240); n.lineTo(x + 58, 240); n.lineTo(x + 28, 100); n.fill();
  }
  // the conveyor, carrying half-built units, and the arms working on them
  const CONV = 104;
  n.fillStyle = '#2e3a4a'; n.fillRect(0, CONV, L.near.width, 14);
  n.fillStyle = '#48586c'; n.fillRect(0, CONV, L.near.width, 2);
  for (let k = 0; k < L.near.width; k += 10) { n.fillStyle = '#1a222c'; n.fillRect(k, CONV + 2, 4, 10); }
  n.fillStyle = '#1a222c'; n.fillRect(0, CONV + 14, L.near.width, 5);
  for (let x = 20; x < L.near.width; x += 84) {                   // the units on it
    n.fillStyle = '#39414e'; n.fillRect(x, CONV - 26, 34, 26);
    n.fillStyle = '#4e5a6a'; n.fillRect(x + 2, CONV - 24, 30, 5);
    n.fillStyle = '#1c2029'; n.fillRect(x + 6, CONV - 18, 22, 10);
    const lit = R() < 0.5;
    n.fillStyle = lit ? '#e8283a' : '#2a3038'; n.fillRect(x + 9, CONV - 15, 5, 4);
    n.fillStyle = lit ? '#e8283a' : '#2a3038'; n.fillRect(x + 20, CONV - 15, 5, 4);
    n.fillStyle = '#2a3038'; n.fillRect(x + 4, CONV - 6, 8, 6); n.fillRect(x + 22, CONV - 6, 8, 6);
  }
  for (let x = 60; x < len - 320; x += 150) {                     // ceiling arms reaching down
    n.fillStyle = '#2a3442'; n.fillRect(x, 30, 12, 32);
    n.fillStyle = '#3e4c5e'; n.fillRect(x - 5, 58, 22, 12);
    n.save(); n.translate(x + 6, 68); n.rotate(0.5 + (x % 5) * 0.16);
    n.fillStyle = '#4a5a6e'; n.fillRect(-4, 0, 8, 34);
    n.fillStyle = '#5e7186'; n.fillRect(-4, 0, 3, 34);
    n.fillStyle = '#2a3442'; n.fillRect(-6, 30, 12, 8);
    n.save(); n.shadowColor = '#8ef0ff'; n.shadowBlur = 10;
    n.fillStyle = '#d8f8ff'; n.fillRect(-2, 38, 4, 5); n.restore();
    n.restore();
    for (let k = 0; k < 6; k++) { n.fillStyle = pick2(R, ['#ffd060', '#8ef0ff', '#ffffff']);
      n.fillRect(x + (R() - 0.5) * 26, 96 + R() * 18, 2, 2); }
  }
  for (let x = 40; x < L.near.width; x += 300) {                  // andon light and a parts bin
    n.fillStyle = '#1a222c'; n.fillRect(x, 40, 12, 34);
    for (let k = 0; k < 3; k++) { n.fillStyle = k === 1 ? '#e8c020' : (k === 0 ? '#3a1a1a' : '#1a3a1a');
      n.beginPath(); n.arc(x + 6, 48 + k * 10, 4, 0, 7); n.fill(); }
    n.fillStyle = '#3a4250'; n.fillRect(x + 30, 122, 54, 28);
    n.fillStyle = '#4c5666'; n.fillRect(x + 30, 122, 54, 3);
    for (let k = 0; k < 5; k++) { n.fillStyle = pick2(R, ['#6a7484', '#8a5a3a', '#4a5a6a']);
      n.fillRect(x + 34 + k * 10, 116 + R() * 6, 7, 7); }
  }
  const a0 = len - 320;
  n.fillStyle = '#141a24'; n.fillRect(a0, 0, L.near.width - a0, 150);
  n.fillStyle = '#1e2836'; n.fillRect(a0 + 20, 40, L.near.width - a0 - 40, 110);
  for (let k = 0; k < 4; k++) { n.fillStyle = '#26303e'; n.fillRect(a0 + 40 + k * 70, 60, 50, 86);
    n.fillStyle = '#2ad0f0'; n.fillRect(a0 + 46 + k * 70, 66, 38, 4);
    n.fillStyle = 'rgba(42,208,240,0.09)'; n.fillRect(a0 + 40 + k * 70, 70, 50, 76); }
  neonText(n, 'FINAL ASSEMBLY', a0 + 46, 24, '#2ad0f0', 2);
  plateFloor(n, L, R, r, 148, '#2a3140', '#333c4c', '#1c222c', true);
  for (let x = 0; x < L.near.width; x += 120) { n.fillStyle = 'rgba(232,200,60,0.40)'; n.fillRect(x, 224, 60, 3); }
}


// ============================================================ 6-C: the torpedo yard
// ---- C2: THE TORPEDO YARD -------------------------------------------------
function torpedoBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#100a10'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 100) { f.fillStyle = '#171020'; f.fillRect(x, 30, 84, 120);
    if (R() < 0.5) { f.fillStyle = '#c8a040'; f.fillRect(x + 12 + R() * 56, 44 + R() * 80, 3, 3); } }
  f.fillStyle = 'rgba(255,150,60,0.08)'; f.fillRect(0, 90, L.far.width, 60);
  m.fillStyle = 'rgba(0,0,0,0)'; m.fillRect(0, 0, 1, 1);
  for (let x = 0; x < L.mid.width; x += 150) {                    // more torpedo cars, further off
    m.fillStyle = '#1e1a24'; m.beginPath(); m.ellipse(x + 62, 122, 62, 18, 0, 0, 7); m.fill();
    m.save(); m.shadowColor = '#ff8a20'; m.shadowBlur = 10; m.fillStyle = '#ffb040';
    m.fillRect(x + 118, 116, 8, 7); m.restore();
  }
  gantry(n, L, R, 18, '#2a2630', '#3e3846');
  pipeRun(n, L, R, [60], true);
  // the cars themselves: long cigars on bogies, glowing at the mouth
  let x = -40;
  while (x < len - 280) {
    const w2 = 250;
    n.fillStyle = '#161219'; n.beginPath(); n.ellipse(x + w2 / 2, 116, w2 / 2, 30, 0, 0, 7); n.fill();
    // Shade it hard as a cylinder: a bright band near the top, a broad mid tone,
    // then a deep shadow under the belly. A flat fill reads as a dark blob.
    const g = n.createLinearGradient(0, 89, 0, 143);
    g.addColorStop(0, '#6a6474'); g.addColorStop(0.14, '#5a5462');
    g.addColorStop(0.42, '#3e3946'); g.addColorStop(0.72, '#2a2530');
    g.addColorStop(1, '#171320');
    n.fillStyle = g; n.beginPath(); n.ellipse(x + w2 / 2, 116, w2 / 2 - 4, 27, 0, 0, 7); n.fill();
    // the binding rings, which curve with the barrel
    for (let k = 26; k < w2 - 26; k += 40) {
      const t3 = (k - w2 / 2) / (w2 / 2);
      const rh = 26 * Math.sqrt(Math.max(0, 1 - t3 * t3));
      n.fillStyle = 'rgba(0,0,0,0.26)'; n.fillRect(x + k, 116 - rh, 4, rh * 2);
      n.fillStyle = 'rgba(255,255,255,0.09)'; n.fillRect(x + k + 4, 116 - rh, 1.5, rh * 2);
    }
    n.fillStyle = 'rgba(255,255,255,0.16)';
    n.beginPath(); n.ellipse(x + w2 / 2, 100, w2 / 2 - 30, 5, 0, 0, 7); n.fill();
    n.fillStyle = 'rgba(0,0,0,0.30)';
    n.beginPath(); n.ellipse(x + w2 / 2, 138, w2 / 2 - 18, 6, 0, 0, 7); n.fill();
    // the charging mouth on top: a raised collar with the heat coming out of it
    n.fillStyle = '#14111a'; n.fillRect(x + w2 / 2 - 30, 82, 60, 14);
    n.fillStyle = '#2f2a38'; n.fillRect(x + w2 / 2 - 28, 84, 56, 10);
    n.fillStyle = '#413b4c'; n.fillRect(x + w2 / 2 - 28, 84, 56, 2);
    n.fillStyle = '#0d0a10'; n.fillRect(x + w2 / 2 - 22, 86, 44, 8);
    n.save(); n.shadowColor = '#ffb020'; n.shadowBlur = 16;
    n.fillStyle = '#ffd060'; n.fillRect(x + w2 / 2 - 20, 86, 40, 6);
    n.fillStyle = '#fff0b0'; n.fillRect(x + w2 / 2 - 14, 87, 28, 3); n.restore();
    n.fillStyle = 'rgba(255,176,32,0.16)'; n.fillRect(x + w2 / 2 - 50, 66, 100, 40);
    // the end spout, dribbling
    n.fillStyle = '#2a2430'; n.fillRect(x + w2 - 26, 106, 30, 16);
    n.save(); n.shadowColor = '#ff8a20'; n.shadowBlur = 10;
    n.fillStyle = '#ffb040'; n.fillRect(x + w2 - 2, 110, 8, 7); n.restore();
    // the bogies underneath
    for (const bx of [x + 40, x + w2 - 70]) {
      n.fillStyle = '#16141c'; n.fillRect(bx, 140, 40, 10);
      for (const wx of [bx + 8, bx + 30]) { n.fillStyle = '#26242c'; n.beginPath(); n.arc(wx, 152, 7, 0, 7); n.fill();
        n.fillStyle = '#3c3a46'; n.beginPath(); n.arc(wx, 152, 3, 0, 7); n.fill(); }
    }
    x += w2 + 18;
  }
  ballast(n, L, R, r, 148, '#2c2830', '#3a343e', '#201c26');
  railPair(n, L, R, 186, '#3a3028', '#8a8a96', '#c8c8d4');
  railPair(n, L, R, 220, '#3a3028', '#8a8a96', '#c8c8d4');
  for (let k = 0; k < 20; k++) { n.fillStyle = 'rgba(255,150,40,0.14)';
    n.beginPath(); n.ellipse(r(0, L.near.width), r(170, 232), 12 + R() * 18, 4, 0, 0, 7); n.fill(); }
  heatWash(n, L, 150, 240, 'rgba(255,140,40,0.09)');
  L.heat = 1;
}



// ============================================================ STAGE 7: the lab
// The lab under the works. Contract for every option in this file:
//   * nothing meaningful above y=34 - the HUD sits there
//   * the floor starts at y<=150 and NOTHING solid is painted in 150..230,
//     which is the band the fighters walk through
// The Vault carries a falling hazard, so all three C options need honest
// structure overhead; A and B carry trailing-cable hazards, so a cable run
// that has been torn open belongs somewhere in each of those.
const LAB_TOP = 148;                 // where every lab floor begins

// ---- surfaces ------------------------------------------------------------
// A glossy epoxy floor: flat colour, a bay grid, and a sheen that catches
// whatever is glowing above it. The sheen is what sells "clean room".
function epoxyFloor(n, L, R, r, top, base, seam, sheen) {
  const w = L.near.width;
  const g = n.createLinearGradient(0, top, 0, 240);
  g.addColorStop(0, sheen); g.addColorStop(0.35, base); g.addColorStop(1, base);
  n.fillStyle = g; n.fillRect(0, top, w, 240 - top);
  for (let x = 0; x < w; x += 58) { n.fillStyle = seam; n.fillRect(x, top, 1, 240 - top); }
  for (let y = top + 18; y < 240; y += 26) { n.fillStyle = seam; n.fillRect(0, y, w, 1); }
  for (let k = 0; k < w * 0.5; k++) {                      // scuffs, so it is not a flat wash
    n.fillStyle = R() < 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.07)';
    n.fillRect(r(0, w), r(top + 3, 240), 5 + R() * 14, 1);
  }
}
// A raised access floor instead: square panels with lifting slots.
function tileFloor(n, L, R, r, top, base, hi, lo, pitch = 34) {
  const w = L.near.width;
  n.fillStyle = base; n.fillRect(0, top, w, 240 - top);
  for (let y = top, row = 0; y < 240; y += pitch, row++) {
    for (let x = -((row % 2) * pitch / 2); x < w; x += pitch) {
      n.fillStyle = (row + Math.round(x / pitch)) % 2 ? hi : lo;
      n.fillRect(x + 1, y + 1, pitch - 2, pitch - 2);
      n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x + pitch / 2 - 3, y + 3, 6, 1);
    }
  }
  n.fillStyle = 'rgba(0,0,0,0.18)'; n.fillRect(0, top, w, 2);
}
// A gasketed wall panel run - the modular sandwich panel every clean room is
// built out of. Vertical seams with a bright bead of sealant down each one.
function panelWall(g, x, y, w, h, R, col, hi, seam, pitch = 44) {
  g.fillStyle = col; g.fillRect(x, y, w, h);
  for (let px = x; px < x + w; px += pitch) {
    g.fillStyle = seam; g.fillRect(px, y, 2, h);
    g.fillStyle = hi; g.fillRect(px + 2, y, 1, h);
  }
  g.fillStyle = hi; g.fillRect(x, y, w, 2);                    // coving at the top
  g.fillStyle = 'rgba(0,0,0,0.22)'; g.fillRect(x, y + h - 4, w, 4);
  for (let k = 0; k < w * 0.06; k++) {                          // grime along the skirting
    g.fillStyle = 'rgba(0,0,0,0.10)'; g.fillRect(x + R() * w, y + h - 12 - R() * 10, 8 + R() * 16, 2);
  }
}
// Yellow-and-black hazard banding.
function hazardBand(g, x, y, w, h, a = '#e8c040', b = '#181410') {
  g.fillStyle = b; g.fillRect(x, y, w, h);
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
  g.strokeStyle = a; g.lineWidth = 4;
  for (let k = -h; k < w + h; k += 10) { g.beginPath(); g.moveTo(x + k, y + h); g.lineTo(x + k + h, y); g.stroke(); }
  g.restore();
}
// A ceiling light strip with a real housing, repeated down the run.
function lightStrip(n, L, y, col, glow, period = 96, lit = 1) {
  const w = L.near.width;
  for (let x = 20; x < w; x += period) {
    n.fillStyle = '#2a3038'; n.fillRect(x, y, 66, 7);
    n.fillStyle = '#3a4450'; n.fillRect(x, y, 66, 2);
    const on = ((x / period) | 0) % 9 !== 7;                    // one tube in nine is dead
    n.fillStyle = on ? col : '#2e3440'; n.fillRect(x + 3, y + 4, 60, 4);
    if (on) {
      n.save(); n.shadowColor = col; n.shadowBlur = 10; n.fillStyle = col;
      n.fillRect(x + 3, y + 5, 60, 2); n.restore();
      const gr = n.createLinearGradient(0, y + 8, 0, y + 8 + 48 * lit);
      gr.addColorStop(0, glow); gr.addColorStop(1, 'rgba(0,0,0,0)');
      n.fillStyle = gr; n.fillRect(x - 14, y + 8, 94, 48 * lit);
    }
  }
}
// A cable tray - the hazard's alibi. Every so often a span has been torn open
// and the looms hang out of it.
function cableTray(n, L, R, y, col = '#39414e', torn = true) {
  const w = L.near.width;
  n.fillStyle = col; n.fillRect(0, y, w, 6);
  n.fillStyle = 'rgba(255,255,255,0.10)'; n.fillRect(0, y, w, 1);
  n.fillStyle = 'rgba(0,0,0,0.35)'; n.fillRect(0, y + 5, w, 2);
  for (let x = 0; x < w; x += 24) { n.fillStyle = '#20252c'; n.fillRect(x, y - 3, 3, 4); }
  const cols = ['#b03a3a', '#3a6ab0', '#c8b040', '#3a9a6a', '#8a8a96'];
  for (let x = 0; x < w; x += 3) {                              // the loom sitting in the tray
    n.fillStyle = cols[(x / 3 | 0) % 5]; n.fillRect(x, y - 3 + ((x / 3 | 0) % 3), 3, 2);
  }
  if (!torn) return;
  for (let x = 120; x < w; x += 340) {                          // a burst span, cables swinging
    n.fillStyle = '#12161c'; n.fillRect(x - 6, y - 5, 44, 12);
    for (let k = 0; k < 5; k++) {
      const c = cols[k % 5], hx = x + 2 + k * 8, drop = 16 + (k % 3) * 11;
      n.strokeStyle = c; n.lineWidth = 2;
      n.beginPath(); n.moveTo(hx, y + 4);
      n.quadraticCurveTo(hx + 4, y + drop * 0.7, hx - 3 + k, y + drop); n.stroke();
      n.fillStyle = '#e8e0b0'; n.fillRect(hx - 4 + k, y + drop, 2, 2);
    }
    n.fillStyle = 'rgba(180,220,255,0.10)'; n.fillRect(x - 12, y, 60, 34);
  }
}
// A pressure door with interlock lights: the punctuation of a corridor.
function bulkhead(g, x, y, w, h, R, col, hi, lit = '#5ad06a', label = '') {
  g.fillStyle = '#12161c'; g.fillRect(x - 5, y - 4, w + 10, h + 4);
  g.fillStyle = col; g.fillRect(x, y, w, h);
  g.fillStyle = hi; g.fillRect(x, y, w, 3); g.fillRect(x, y, 3, h);
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x + w - 4, y, 4, h);
  g.fillStyle = '#12161c'; g.fillRect(x + w / 2 - 1, y, 2, h);  // the split
  g.strokeStyle = hi; g.lineWidth = 2;
  g.beginPath(); g.arc(x + w / 2, y + h * 0.42, Math.min(w, h) * 0.26, 0, 7); g.stroke();
  hazardBand(g, x, y + h - 9, w, 9);
  g.save(); g.shadowColor = lit; g.shadowBlur = 7;
  g.fillStyle = lit; g.fillRect(x + 6, y + 7, 5, 5); g.fillRect(x + w - 11, y + 7, 5, 5);
  g.restore();
  if (label) ptext(g, label, x + w / 2 - tw(label) / 2, y + 16, 'rgba(210,230,245,0.65)');
}
// A window into the next room, with whatever is behind it already drawn.
function viewPane(g, x, y, w, h, tint, frame = '#2a323c') {
  g.fillStyle = frame; g.fillRect(x - 3, y - 3, w + 6, h + 6);
  g.fillStyle = tint; g.fillRect(x, y, w, h);
  g.fillStyle = 'rgba(255,255,255,0.10)';
  g.beginPath(); g.moveTo(x, y + h); g.lineTo(x + w * 0.45, y); g.lineTo(x + w * 0.62, y); g.lineTo(x + w * 0.16, y + h); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.16)'; g.fillRect(x, y, w, 1);
}
// A tall tank of fluid with something suspended in it.
function tank(g, x, y, w, h, R, fluid, glow, opts = {}) {
  g.fillStyle = '#1a2028'; g.fillRect(x - 4, y - 6, w + 8, 8);       // top collar
  g.fillStyle = '#242c36'; g.fillRect(x - 5, y + h, w + 10, 10);     // base
  g.fillStyle = '#323c48'; g.fillRect(x - 5, y + h, w + 10, 2);
  const gr = g.createLinearGradient(x, y, x, y + h);
  gr.addColorStop(0, glow); gr.addColorStop(0.5, fluid); gr.addColorStop(1, '#0b1410');
  g.fillStyle = gr; g.fillRect(x, y, w, h);
  if (opts.body !== false) {                                          // the silhouette inside
    const cx = x + w / 2, cy = y + h * 0.5;
    g.fillStyle = 'rgba(8,16,14,0.62)';
    g.beginPath(); g.ellipse(cx, cy - h * 0.17, w * 0.17, h * 0.075, 0, 0, 7); g.fill();
    g.fillRect(cx - w * 0.17, cy - h * 0.10, w * 0.34, h * 0.26);
    g.beginPath(); g.moveTo(cx - w * 0.17, cy + h * 0.16); g.lineTo(cx - w * 0.09, cy + h * 0.34);
    g.lineTo(cx + w * 0.09, cy + h * 0.34); g.lineTo(cx + w * 0.17, cy + h * 0.16); g.fill();
    g.fillRect(cx - w * 0.30, cy - h * 0.07, w * 0.13, h * 0.24);
    g.fillRect(cx + w * 0.17, cy - h * 0.07, w * 0.13, h * 0.24);
  }
  for (let k = 0; k < h * 0.5; k++) {                                 // bubbles caught in the glass
    g.fillStyle = 'rgba(220,255,240,0.18)';
    g.fillRect(x + 2 + R() * (w - 4), y + 4 + R() * (h - 8), 1, 1 + (R() < 0.3 ? 1 : 0));
  }
  g.fillStyle = 'rgba(255,255,255,0.13)'; g.fillRect(x + 4, y + 4, 4, h - 10);   // glass highlight
  g.fillStyle = 'rgba(255,255,255,0.05)'; g.fillRect(x + w - 8, y + 6, 2, h - 14);
  g.strokeStyle = '#2e3a44'; g.lineWidth = 2;
  for (let k = 1; k < 4; k++) { g.beginPath(); g.moveTo(x - 4, y + h * k / 4); g.lineTo(x + w + 4, y + h * k / 4); g.stroke(); }
  g.save(); g.shadowColor = glow; g.shadowBlur = 14; g.fillStyle = glow;
  g.fillRect(x + 2, y + h - 6, w - 4, 3); g.restore();
  if (opts.label) ptext(g, opts.label, x + w / 2 - tw(opts.label) / 2, y + h + 2, 'rgba(200,230,215,0.55)');
}
// A rack of blinking gear. Deterministic LEDs so a still frame still reads.
function rack(g, x, y, w, h, R, col = '#1a1e26', led = '#5ad06a') {
  g.fillStyle = '#10141a'; g.fillRect(x - 2, y - 2, w + 4, h + 4);
  g.fillStyle = col; g.fillRect(x, y, w, h);
  for (let ry = y + 3; ry < y + h - 4; ry += 7) {
    g.fillStyle = 'rgba(255,255,255,0.05)'; g.fillRect(x + 2, ry, w - 4, 5);
    g.fillStyle = 'rgba(0,0,0,0.40)'; g.fillRect(x + 2, ry + 5, w - 4, 1);
    for (let k = 0; k < 4; k++) {
      const on = ((ry * 7 + k * 13 + Math.round(x)) % 5) < 3;
      g.fillStyle = on ? (k === 3 ? '#e8a030' : led) : 'rgba(255,255,255,0.08)';
      g.fillRect(x + 4 + k * 4, ry + 2, 2, 2);
    }
  }
  g.save(); g.shadowColor = led; g.shadowBlur = 9; g.fillStyle = led;
  g.fillRect(x + 3, y + 3, 2, 2); g.restore();
}
// Overhead structure: a coffered slab with services hung under it. Reads as
// weight above the fight without stealing contrast from the sprites.
function ceilingSlab(n, L, y, d, col, hi, shade) {
  const w = L.near.width;
  n.fillStyle = col; n.fillRect(0, y, w, d);
  n.fillStyle = hi; n.fillRect(0, y, w, 2);
  n.fillStyle = shade; n.fillRect(0, y + d - 3, w, 3);
  for (let x = 0; x < w; x += 72) { n.fillStyle = shade; n.fillRect(x, y, 5, d); }
  for (let x = 30; x < w; x += 72) { n.fillStyle = 'rgba(0,0,0,0.25)'; n.fillRect(x, y + 3, 28, d - 8); }
}
// Insulated duct running the length of a ceiling.
function ductRun(n, L, y, h, col, hi) {
  const w = L.near.width;
  n.fillStyle = col; n.fillRect(0, y, w, h);
  n.fillStyle = hi; n.fillRect(0, y, w, 2);
  n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(0, y + h - 3, w, 3);
  for (let x = 0; x < w; x += 56) {
    n.fillStyle = hi; n.fillRect(x, y - 2, 4, h + 4);
    n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x + 4, y, 2, h);
  }
}
// A soft pool of light thrown onto the floor by something above it.
function floorGlow(n, L, x, top, w, col) {
  const g = n.createLinearGradient(0, top, 0, 240);
  g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)');
  n.save(); n.globalCompositeOperation = 'lighter'; n.fillStyle = g;
  n.beginPath(); n.moveTo(x - w * 0.3, top); n.lineTo(x + w * 0.3, top);
  n.lineTo(x + w * 0.62, 240); n.lineTo(x - w * 0.62, 240); n.fill();
  n.restore();
}
// Stencilled floor marking - a walkway lane or a keep-clear box. Paint only,
// so it never reads as something you would trip over.
function floorMark(n, x, y, w, h, col, label) {
  n.strokeStyle = col; n.lineWidth = 2; n.strokeRect(x, y, w, h);
  if (label) ptext(n, label, x + 6, y + 5, col);
}


// ---- 7-A: CLEAN CORRIDOR -------------------------------------------------
function corridorBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  // far: the corridor carrying on, blown out and out of focus
  const sky = f.createLinearGradient(0, 34, 0, 150);
  sky.addColorStop(0, '#e6eef3'); sky.addColorStop(1, '#a8b8c2');
  f.fillStyle = sky; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 128) {
    f.fillStyle = 'rgba(150,170,182,0.35)'; f.fillRect(x, 48, 40, 100);
    f.fillStyle = 'rgba(255,255,255,0.40)'; f.fillRect(x + 44, 40, 70, 8);
  }
  // mid: rooms on the far side of the glass, each a different colour of work
  const tints = ['#9fd8c0', '#a8c4de', '#cdd6a8', '#c6a8cc'];
  m.fillStyle = '#6d7e8a'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 176) {
    const t = tints[(x / 176 | 0) % 4];
    m.fillStyle = t; m.fillRect(x + 6, 40, 156, 108);
    m.fillStyle = 'rgba(255,255,255,0.50)'; m.fillRect(x + 14, 46, 140, 5);    // the room's own light strip
    m.fillStyle = 'rgba(0,0,0,0.26)';
    for (let k = 0; k < 4; k++) m.fillRect(x + 18 + k * 36, 96 + (k % 2) * 8, 26, 52);   // benches
    m.fillStyle = 'rgba(0,0,0,0.38)';
    for (let k = 0; k < 3; k++) m.fillRect(x + 26 + k * 46, 66 + (k % 2) * 7, 16, 26);   // gear on them
    m.fillStyle = 'rgba(255,255,255,0.22)'; m.fillRect(x + 6, 40, 156, 2);
    m.fillStyle = 'rgba(0,0,0,0.28)'; m.fillRect(x + 162, 40, 14, 108);        // the wall between rooms
  }
  // near: the near wall with glazed bays, the ceiling services, the floor
  ceilingSlab(n, L, 34, 15, '#c2ccd4', '#e2ebf0', '#93a0aa');
  ductRun(n, L, 49, 11, '#b3bec7', '#d8e2e9');
  lightStrip(n, L, 62, '#f4fcff', 'rgba(228,244,255,0.26)', 108);
  cableTray(n, L, R, 92, '#8e9ba6', true);
  const W2 = L.near.width;
  for (let x = 0; x < W2; x += 176) {                            // glazed bays through to the labs
    n.fillStyle = '#b4c0c9'; n.fillRect(x, 60, 176, 6);           // the transom over the glass
    n.fillStyle = '#dbe5ec'; n.fillRect(x, 60, 176, 2);
    n.fillStyle = '#aeb9c2'; n.fillRect(x + 8, 66, 152, 3);       // the glazing frame
    n.fillStyle = '#aeb9c2'; n.fillRect(x + 8, 66, 4, 62);
    n.fillStyle = '#aeb9c2'; n.fillRect(x + 156, 66, 4, 62);
    n.fillStyle = '#aeb9c2'; n.fillRect(x + 80, 66, 3, 62);       // the mullion
    n.fillStyle = 'rgba(255,255,255,0.09)';                        // one soft reflection, not a slab
    n.beginPath(); n.moveTo(x + 12, 128); n.lineTo(x + 56, 69); n.lineTo(x + 68, 69); n.lineTo(x + 24, 128); n.fill();
    n.fillStyle = 'rgba(255,255,255,0.20)'; n.fillRect(x + 12, 66, 144, 1);
    panelWall(n, x, 128, 176, 20, R, '#d4dee5', '#eef5fa', '#aab6c0', 46);   // the dado under the glass
    n.fillStyle = '#9aa6b0'; n.fillRect(x + 160, 56, 16, 92);      // the pier between bays
    n.fillStyle = '#c4ced6'; n.fillRect(x + 160, 56, 5, 92);
    ptext(n, ['STERILE', 'ZONE 2', 'NO ENTRY', 'WASH'][(x / 176 | 0) % 4], x + 16, 132, 'rgba(70,92,106,0.75)');
    n.fillStyle = '#e4ebf0'; n.fillRect(x + 128, 130, 12, 16);
    n.fillStyle = '#4ac0e8'; n.fillRect(x + 130, 132, 8, 5);
  }
  for (let x = 250, i = 0; x < W2 - 200; x += 430, i++) {         // pressure doors down the run
    n.fillStyle = '#c2ccd4'; n.fillRect(x - 18, 56, 100, 92);
    n.fillStyle = '#e2ebf0'; n.fillRect(x - 18, 56, 100, 3);
    bulkhead(n, x, 68, 64, 80, R, '#aeb9c2', '#dde6ec', i % 2 ? '#5ad06a' : '#e8283a', 'D' + (i + 1));
  }
  epoxyFloor(n, L, R, r, LAB_TOP, '#aebcc6', 'rgba(110,130,144,0.45)', '#e6eef3');
  for (let x = 30; x < W2; x += 108) floorGlow(n, L, x + 33, LAB_TOP, 80, 'rgba(226,244,255,0.10)');
  floorMark(n, 0, 196, W2, 34, 'rgba(90,208,106,0.35)');
  for (let x = 0; x < W2; x += 240) ptext(n, 'WALKWAY', x + 40, 202, 'rgba(90,208,106,0.30)');
  L.labHum = 1;
}

// ---- 7-B: THE COLD STORE -------------------------------------------------
function coldStoreBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const g0 = f.createLinearGradient(0, 34, 0, 150);
  g0.addColorStop(0, '#16243a'); g0.addColorStop(1, '#2e4a66');
  f.fillStyle = g0; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 54) {                     // dewars in the far aisle
    f.fillStyle = '#1d3049'; f.fillRect(x + 8, 62, 34, 86);
    f.fillStyle = '#2b4462'; f.fillRect(x + 8, 62, 34, 4);
    f.fillStyle = 'rgba(200,232,255,0.16)'; f.fillRect(x + 12, 68, 8, 76);
  }
  f.fillStyle = 'rgba(180,215,245,0.10)'; f.fillRect(0, 34, L.far.width, 114);
  m.fillStyle = '#16263c'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 64) {                     // the drawer wall behind
    m.fillStyle = '#1e3350'; m.fillRect(x, 40, 58, 108);
    for (let y = 44; y < 146; y += 13) {
      m.fillStyle = '#25405f'; m.fillRect(x + 3, y, 52, 10);
      m.fillStyle = '#31527a'; m.fillRect(x + 3, y, 52, 2);
      m.fillStyle = 'rgba(200,232,255,0.30)'; m.fillRect(x + 24, y + 4, 12, 2);
    }
  }
  m.fillStyle = 'rgba(16,34,58,0.40)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  ceilingSlab(n, L, 34, 12, '#1a2c44', '#2a4364', '#101d2e');
  for (let x = 0; x < W2; x += 76) {                              // frosted chill lines and vapour headers
    n.fillStyle = '#24405e'; n.fillRect(x, 46, 64, 7);
    n.fillStyle = 'rgba(214,240,255,0.50)'; n.fillRect(x, 46, 64, 2);
    for (let k = 0; k < 7; k++) { n.fillStyle = 'rgba(214,240,255,0.35)'; n.fillRect(x + 4 + k * 9, 53, 3, 4); }
  }
  ductRun(n, L, 60, 10, '#223854', '#35567c');
  cableTray(n, L, R, 78, '#1d3149', true);
  for (let x = 0, bi = 0; x < W2; x += 128, bi++) {               // the storage banks you walk past
    const kind = bi % 3;
    if (kind === 2) {                                              // every third bay is something else
      n.fillStyle = '#10203a'; n.fillRect(x, 74, 118, 74);
      viewPane(n, x + 12, 80, 94, 54, 'rgba(160,210,245,0.14)', '#1d3556');
      n.fillStyle = 'rgba(214,240,255,0.22)'; n.fillRect(x + 12, 80, 94, 3);
      for (let k = 0; k < 9; k++) {                                // frost feathering across the glass
        n.fillStyle = 'rgba(226,246,255,0.14)';
        n.beginPath(); n.ellipse(x + 20 + (k * 23) % 86, 86 + (k * 17) % 44, 9 + (k % 3) * 5, 4, 0, 0, 7); n.fill();
      }
      n.fillStyle = '#152741'; n.fillRect(x, 134, 118, 14);
      hazardBand(n, x + 8, 136, 102, 8, '#8fd0f0', '#10202f');
      ptext(n, 'CHAMBER ' + String(2 + bi), x + 14, 70, 'rgba(190,225,255,0.60)');
      floorGlow(n, L, x + 59, LAB_TOP, 104, 'rgba(150,215,255,0.10)');
      continue;
    }
    const rows = kind === 0 ? 4 : 3, pitch = kind === 0 ? 13 : 17, top = kind === 0 ? 88 : 80;
    n.fillStyle = '#152741'; n.fillRect(x, top, 118, 148 - top);
    n.fillStyle = '#20395c'; n.fillRect(x, top, 118, 3);
    for (let row = 0; row < rows; row++) for (let col = 0; col < 3; col++) {
      const dx = x + 6 + col * 37, dy = top + 6 + row * pitch;
      n.fillStyle = '#1e3557'; n.fillRect(dx, dy, 33, pitch - 2);
      n.fillStyle = '#2c4d79'; n.fillRect(dx, dy, 33, 2);
      n.fillStyle = '#0d1828'; n.fillRect(dx + 12, dy + 4, 10, 3);
      n.fillStyle = 'rgba(214,240,255,0.45)'; n.fillRect(dx + 2, dy + pitch - 3, 29, 1);   // frost on the lip
    }
    if (bi % 4 === 1) {                                            // one drawer pulled out, empty
      n.fillStyle = '#060d16'; n.fillRect(x + 43, top + 32, 33, 11);
      n.fillStyle = '#2c4d79'; n.fillRect(x + 43, top + 43, 36, 4);
      n.fillStyle = 'rgba(214,240,255,0.25)'; n.fillRect(x + 43, top + 32, 33, 2);
    }
    ptext(n, 'CS-' + String(40 + bi), x + 6, top - 6, 'rgba(190,225,255,0.55)');
    n.fillStyle = '#1b3050'; n.fillRect(x + 118, top - 4, 10, 152 - top);
    n.fillStyle = '#2a4770'; n.fillRect(x + 118, top - 4, 3, 152 - top);
  }
  for (let x = 250; x < W2 - 180; x += 520) {                     // a standing dewar, breathing
    n.fillStyle = '#132540'; n.fillRect(x, 74, 52, 74);
    n.fillStyle = '#1f3a5e'; n.fillRect(x + 4, 74, 12, 74);
    n.fillStyle = '#2c4d79'; n.fillRect(x - 4, 70, 60, 8);
    n.fillStyle = 'rgba(214,240,255,0.55)'; n.fillRect(x - 4, 70, 60, 2);
    hazardBand(n, x, 138, 52, 8, '#8fd0f0', '#10202f');
    ptext(n, 'LN2', x + 16, 86, 'rgba(214,240,255,0.65)');
    floorGlow(n, L, x + 26, LAB_TOP, 86, 'rgba(150,215,255,0.10)');
  }
  epoxyFloor(n, L, R, r, LAB_TOP, '#142640', 'rgba(110,170,220,0.20)', '#27476c');
  for (let k = 0; k < W2 * 0.08; k++) {                           // frost creeping out from the walls
    n.fillStyle = 'rgba(214,240,255,0.06)';
    n.beginPath(); n.ellipse(r(0, W2), LAB_TOP + r(0, 26), 14 + R() * 30, 3 + R() * 5, 0, 0, 7); n.fill();
  }
  n.fillStyle = 'rgba(150,200,240,0.05)'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  L.cryo = 1; L.labHum = 1;
}

// ---- 7-C: THE BIRTHING FLOOR ---------------------------------------------
function birthingBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  f.fillStyle = '#0a0713'; f.fillRect(0, 0, L.far.width, H);
  for (let x = 0; x < L.far.width; x += 36) {                     // the line curving away out of sight
    const g = f.createLinearGradient(0, 44, 0, 148);
    g.addColorStop(0, 'rgba(150,110,220,0.26)'); g.addColorStop(1, 'rgba(30,16,60,0.30)');
    f.fillStyle = g; f.fillRect(x + 6, 44, 22, 104);
    f.fillStyle = 'rgba(0,0,0,0.45)'; f.fillRect(x + 12, 70, 10, 52);
  }
  f.fillStyle = 'rgba(10,6,20,0.40)'; f.fillRect(0, 0, L.far.width, H);
  m.fillStyle = '#0d0918'; m.fillRect(0, 34, L.mid.width, 114);
  for (let x = 0; x < L.mid.width; x += 82) {                     // the second rank, three-quarter size
    tank(m, x + 16, 48, 44, 92, R, 'rgba(78,44,140,0.85)', 'rgba(186,148,255,0.85)', { body: R() < 0.8 });
  }
  m.fillStyle = '#131020'; m.fillRect(0, 34, L.mid.width, 12);    // the header they all hang off
  m.fillStyle = '#221a38'; m.fillRect(0, 34, L.mid.width, 2);
  m.fillStyle = 'rgba(10,6,20,0.35)'; m.fillRect(0, 34, L.mid.width, 114);
  const W2 = L.near.width;
  // near: the feed header overhead - this is what the falling hazard comes off
  ceilingSlab(n, L, 34, 13, '#140f22', '#221a38', '#0a0714');
  n.fillStyle = '#1b1430'; n.fillRect(0, 47, W2, 12);
  n.fillStyle = '#2d2350'; n.fillRect(0, 47, W2, 3);
  n.fillStyle = 'rgba(0,0,0,0.40)'; n.fillRect(0, 57, W2, 3);
  for (let x = 0; x < W2; x += 96) {                              // umbilicals dropping to each capsule
    for (let k = 0; k < 3; k++) {
      n.strokeStyle = ['#6a4aa8', '#3f7fa8', '#8a5a4a'][k]; n.lineWidth = 3;
      n.beginPath(); n.moveTo(x + 30 + k * 10, 59);
      n.quadraticCurveTo(x + 26 + k * 10, 70, x + 34 + k * 8, 80); n.stroke();
    }
    n.fillStyle = '#100c1c'; n.fillRect(x + 24, 56, 40, 7);
    n.save(); n.shadowColor = '#b894ff'; n.shadowBlur = 8; n.fillStyle = '#b894ff';
    n.fillRect(x + 58, 58, 4, 4); n.restore();
  }
  cableTray(n, L, R, 70, '#1c1530', false);
  for (let x = 0; x < W2; x += 96) {                              // the capsules, part-finished bodies inside
    const stage = (x / 96 | 0) % 4;
    n.fillStyle = '#0a0714'; n.fillRect(x, 80, 90, 68);
    tank(n, x + 18, 82, 54, 66, R, 'rgba(70,40,130,0.92)', 'rgba(198,162,255,0.95)',
      { body: stage !== 0, label: 'U-' + String(30 + (x / 96 | 0)) });
    if (stage === 0) {                                             // an empty one, hatch stood open
      n.fillStyle = '#050310'; n.fillRect(x + 18, 82, 54, 66);
      n.fillStyle = '#1d1636'; n.fillRect(x + 72, 78, 7, 74);
      n.fillStyle = '#2f2554'; n.fillRect(x + 72, 78, 2, 74);
    }
    if (stage === 2) { n.fillStyle = 'rgba(232,40,58,0.16)'; n.fillRect(x + 18, 82, 54, 66);
      ptext(n, 'REJECT', x + 22, 106, 'rgba(232,40,58,0.70)'); }
    n.fillStyle = '#150f26'; n.fillRect(x + 12, 140, 66, 8);      // the carrier it stands on
    n.fillStyle = '#251c42'; n.fillRect(x + 12, 140, 66, 2);
    floorGlow(n, L, x + 45, LAB_TOP, 74, 'rgba(160,120,240,0.09)');
  }
  // mid-scene: the finished one, closed and gold
  const P = Math.min(700, len - 300);
  n.fillStyle = '#07040f'; n.fillRect(P - 70, 68, 140, 80);
  n.fillStyle = '#1c1530'; n.fillRect(P - 44, 70, 88, 78);
  n.fillStyle = '#2d2350'; n.fillRect(P - 44, 70, 88, 3);
  // Deliberately EMPTY. The Unit-9 capsule is a breakable the game spawns at
  // this exact x, so the background paints the lit berth it stands in - paint a
  // figure here too and the player sees two capsules side by side.
  const gg = n.createLinearGradient(P - 34, 76, P - 34, 144);
  gg.addColorStop(0, 'rgba(255,236,176,0.55)'); gg.addColorStop(0.55, 'rgba(214,166,58,0.34)');
  gg.addColorStop(1, 'rgba(70,48,14,0.50)');
  n.save(); n.shadowColor = '#f2c94c'; n.shadowBlur = 24;
  n.fillStyle = gg; n.fillRect(P - 34, 76, 68, 68); n.restore();
  for (let k = 0; k < 5; k++) {                                    // the berth's own backlights
    n.fillStyle = 'rgba(255,240,190,0.30)'; n.fillRect(P - 30, 82 + k * 14, 60, 2);
  }
  n.fillStyle = 'rgba(40,28,8,0.30)'; n.fillRect(P - 34, 76, 68, 68);
  n.fillStyle = '#2d2350'; n.fillRect(P - 40, 72, 80, 5);          // the berth head
  n.fillStyle = '#463a72'; n.fillRect(P - 40, 72, 80, 2);
  for (let k = 0; k < 3; k++) {                                    // feeds hanging into it, unplugged
    n.strokeStyle = ['#6a4aa8', '#3f7fa8', '#8a5a4a'][k]; n.lineWidth = 2;
    n.beginPath(); n.moveTo(P - 14 + k * 14, 77);
    n.quadraticCurveTo(P - 18 + k * 14, 88, P - 10 + k * 12, 98); n.stroke();
  }
  hazardBand(n, P - 44, 140, 88, 8);
  ptext(n, 'UNIT 9 - COMPLETE', P - tw('UNIT 9 - COMPLETE') / 2, 62, 'rgba(242,201,76,0.80)');
  floorGlow(n, L, P, LAB_TOP, 140, 'rgba(242,201,76,0.14)');
  epoxyFloor(n, L, R, r, LAB_TOP, '#1c1533', 'rgba(150,120,210,0.20)', '#35275c');
  n.fillStyle = '#171128'; n.fillRect(0, 190, W2, 5);             // the carrier rail, flat paint on the floor
  for (let x = 0; x < W2; x += 22) { n.fillStyle = 'rgba(0,0,0,0.30)'; n.fillRect(x, 190, 3, 5); }
  n.fillStyle = 'rgba(12,6,24,0.14)'; n.fillRect(0, LAB_TOP, W2, 240 - LAB_TOP);
  L.bubbles = 96; L.labHum = 1;
}

// ------------------------------------------------------------ live overlays
// A lab is never quite still: the tubes hum and the brightness breathes. Kept
// far under the level that would read as a flash, and off entirely for anyone
// who has turned flashing lights off.
function drawLabHum() {
  if (!SAVE.options.flashing) return;
  const k = 0.012 + Math.abs(Math.sin(G.frames / 96)) * 0.012;
  ctx.fillStyle = `rgba(210,230,245,${k})`;
  ctx.fillRect(0, 34, W, 116);
}
// Cryogenic vapour is heavier than air, so it rolls along the floor rather
// than rising. Drawn over the fighters' feet, which is where it belongs.
function drawCryoFog(cx) {
  for (let i = 0; i < 16; i++) {
    const seed = i * 149;
    const x = ((seed * 37 + G.frames * (0.28 + (i % 4) * 0.16)) % (W + 220)) - 110;
    const y = 192 + ((seed % 40)) + Math.sin(G.frames / 70 + i) * 4;
    ctx.fillStyle = `rgba(214,240,255,${0.030 + (i % 3) * 0.014})`;
    ctx.beginPath(); ctx.ellipse(x, y, 40 + (i % 5) * 26, 7 + (i % 3) * 5, 0, 0, 7); ctx.fill();
  }
  ctx.fillStyle = 'rgba(190,225,255,0.030)'; ctx.fillRect(0, 34, W, 206);
}
// Bubbles rising inside the capsules. The pitch is the capsule spacing of the
// birthing floor, so the columns line up with the glass rather than drifting
// across it.
function drawCapsuleBubbles(cx) {
  const pitch = 96;
  const first = Math.floor(cx / pitch) - 1;
  for (let i = first; i < first + Math.ceil(W / pitch) + 2; i++) {
    const bx = i * pitch - cx;
    if (bx < -pitch || bx > W + pitch) continue;
    for (let k = 0; k < 5; k++) {
      const seed = i * 53 + k * 29;
      const life = (G.frames * (0.5 + (seed % 4) * 0.18) + seed * 7) % 62;
      const y = 142 - life;
      if (y < 86) continue;
      ctx.fillStyle = `rgba(226,236,255,${0.09 + (1 - life / 62) * 0.20})`;
      ctx.fillRect(bx + 26 + (seed % 38) + Math.sin(life / 7 + k) * 2, y, 2, 2);
    }
  }
}

// ============================================================ STAGE 8: the tower
// Eighty floors up. Same contract as the lab: nothing meaningful above y=34
// (the HUD), and nothing solid painted in 150..230 (the walkable band), which
// leaves y 34..148 to carry the whole stage.
const FLOOR8 = 148;                  // interior floors
const DECK8  = 146;                  // roof decks
const A8_PIT = 960;                  // where the atrium's pit hazard stands

// The city seen through a window from inside: flat, dim, glass in front of it.
function cityPlate(g, x, y, w, h, R, r, dark = '#0b0a18') {
  g.fillStyle = dark; g.fillRect(x, y, w, h);
  for (let bx = x; bx < x + w; bx += 11) {
    const bh = 8 + ((bx * 13) % 26);
    g.fillStyle = ((bx / 11) | 0) % 2 ? '#171426' : '#12101f';
    g.fillRect(bx, y + h - bh, 10, bh);
  }
  for (let k = 0; k < w * h * 0.010; k++) {
    g.fillStyle = R() < 0.6 ? 'rgba(226,190,96,0.75)' : 'rgba(112,168,232,0.70)';
    g.fillRect(r(x + 1, x + w - 1), r(y + h * 0.35, y + h - 1), 1, 1);
  }
  for (let k = 0; k < 3; k++) {
    g.fillStyle = 'rgba(232,58,58,0.8)'; g.fillRect(r(x, x + w), r(y + 2, y + h * 0.4), 1, 2);
  }
}
// A curtain wall: mullions, transoms, and glass that reflects the room as much
// as it shows the outside.
function curtainWall(n, L, x, w, y, h, R, r, opts = {}) {
  const bay = opts.bay || 64, frame = opts.frame || '#2a2740', hi = opts.hi || '#454065';
  const tran = opts.transom !== false;
  n.save(); n.beginPath(); n.rect(x, y, w, h); n.clip();
  for (let bx = x; bx < x + w; bx += bay) {
    const bw = Math.min(bay - 7, x + w - bx - 7);
    if (bw < 6) break;
    cityPlate(n, bx, y, bw, h, R, r, opts.dark);
    n.fillStyle = 'rgba(150,190,255,0.055)'; n.fillRect(bx, y, bw, h);
    n.fillStyle = 'rgba(190,220,255,0.07)';
    n.beginPath(); n.moveTo(bx, y + h); n.lineTo(bx + bw * 0.5, y);
    n.lineTo(bx + bw * 0.78, y); n.lineTo(bx + bw * 0.2, y + h); n.fill();
    n.fillStyle = frame; n.fillRect(bx + bw, y, 7, h);
    n.fillStyle = hi; n.fillRect(bx + bw, y, 2, h);
    if (tran) { n.fillStyle = frame; n.fillRect(bx, y + Math.round(h * 0.38), bw, 3); }
  }
  n.restore();
  n.fillStyle = frame; n.fillRect(x, y - 4, w, 5);
  n.fillStyle = hi; n.fillRect(x, y - 4, w, 2);
  n.fillStyle = frame; n.fillRect(x, y + h - 2, w, 5);
}
// Polished stone: big slabs, veining, and a reflection of whatever is lit above.
function stoneFloor(n, L, R, r, top, base, vein, sheen, slab = 62) {
  const w = L.near.width;
  const g = n.createLinearGradient(0, top, 0, 240);
  g.addColorStop(0, sheen); g.addColorStop(0.4, base); g.addColorStop(1, base);
  n.fillStyle = g; n.fillRect(0, top, w, 240 - top);
  for (let x = 0; x < w; x += slab) { n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(x, top, 1, 240 - top); }
  for (let y = top + 20; y < 240; y += 28) { n.fillStyle = 'rgba(0,0,0,0.18)'; n.fillRect(0, y, w, 1); }
  for (let k = 0; k < w * 0.30; k++) {
    const vx = r(0, w), vy = r(top + 2, 238);
    n.strokeStyle = vein; n.lineWidth = 1;
    n.beginPath(); n.moveTo(vx, vy);
    n.quadraticCurveTo(vx + r(-14, 14), vy + r(-5, 5), vx + r(-26, 26), vy + r(-8, 8)); n.stroke();
  }
  n.fillStyle = 'rgba(255,255,255,0.05)'; n.fillRect(0, top, w, 2);
}
// A roof deck of concrete pavers on pedestals, with the joints open.
function deckFloor(n, L, R, r, top, base, hi, seam, pitch = 40) {
  const w = L.near.width;
  n.fillStyle = base; n.fillRect(0, top, w, 240 - top);
  for (let y = top, row = 0; y < 240; y += pitch, row++) {
    for (let x = -((row % 2) * 12); x < w; x += pitch) {
      n.fillStyle = (row + Math.round(x / pitch)) % 3 ? base : hi;
      n.fillRect(x + 1, y + 1, pitch - 2, pitch - 2);
      n.fillStyle = seam; n.fillRect(x, y, 1, pitch); n.fillRect(x, y, pitch, 1);
    }
  }
  for (let k = 0; k < w * 0.8; k++) {
    n.fillStyle = R() < 0.5 ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.10)';
    n.fillRect(r(0, w), r(top, 240), 3 + R() * 9, 1);
  }
  n.fillStyle = hi; n.fillRect(0, top, w, 2);
}
// A void through the floor plate - the pit's alibi. Painted ABOVE the walkable
// band only: the edge nosing at `top`, then darkness the pit prop stands in.
function floorVoid(n, x, top, w, R, r, deep = '#07060e') {
  n.fillStyle = deep; n.fillRect(x, top - 26, w, 26);
  for (let d = 0; d < 3; d++) {
    n.fillStyle = `rgba(90,110,160,${0.08 - d * 0.02})`;
    n.fillRect(x + 4 + d * 3, top - 22 + d * 7, w - 8 - d * 6, 2);
  }
  for (let k = 0; k < w * 0.2; k++) {
    n.fillStyle = 'rgba(226,190,96,0.35)'; n.fillRect(r(x + 3, x + w - 3), r(top - 24, top - 3), 1, 1);
  }
  n.fillStyle = '#3a3552'; n.fillRect(x - 3, top - 4, w + 6, 4);
  n.fillStyle = '#585070'; n.fillRect(x - 3, top - 4, w + 6, 1);
  hazardBand(n, x - 3, top - 10, w + 6, 6);
}
// A handrail with balusters: an edge you can see over.
function railing(g, x, y, w, col = '#4a4660', hi = '#6a6688', pitch = 22) {
  g.fillStyle = col; g.fillRect(x, y, w, 3);
  g.fillStyle = hi; g.fillRect(x, y, w, 1);
  g.fillStyle = col; g.fillRect(x, y + 13, w, 2);
  for (let px = x; px < x + w; px += pitch) { g.fillStyle = col; g.fillRect(px, y, 2, 24); }
  g.fillStyle = 'rgba(160,200,255,0.035)'; g.fillRect(x, y + 3, w, 21);
}
// A rooftop plant box: chiller, cooling tower, riser cluster.
function plantBox(g, x, y, w, h, R, r, col = '#1e1c26', hi = '#33303e') {
  g.fillStyle = col; g.fillRect(x, y, w, h);
  g.fillStyle = hi; g.fillRect(x, y, w, 3);
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x + w - 4, y, 4, h);
  for (let k = x + 5; k < x + w - 8; k += 9) { g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(k, y + 6, 5, h - 12); }
  g.fillStyle = hi; g.fillRect(x - 3, y + h - 4, w + 6, 4);
  g.fillStyle = '#4a4858';
  g.beginPath(); g.arc(x + w * 0.5, y + h * 0.4, Math.min(w, h) * 0.22, 0, 7); g.fill();
  g.fillStyle = col; g.beginPath(); g.arc(x + w * 0.5, y + h * 0.4, Math.min(w, h) * 0.18, 0, 7); g.fill();
}
// A lattice mast with its aircraft beacon.
function mast(g, x, top, bot, col = '#16121e', beacon = '#ff3a3a', wide = 10) {
  g.fillStyle = col; g.fillRect(x - 1, top, 3, bot - top); g.fillRect(x + wide - 1, top, 3, bot - top);
  for (let y = top + 6; y < bot; y += 13) {
    g.fillRect(x, y, wide, 2);
    g.strokeStyle = col; g.lineWidth = 1.5;
    g.beginPath(); g.moveTo(x, y + 13); g.lineTo(x + wide, y); g.stroke();
  }
  g.save(); g.shadowColor = beacon; g.shadowBlur = 8; g.fillStyle = beacon;
  g.fillRect(x + wide / 2 - 2, top - 5, 5, 5); g.restore();
}
// The pad marking: a circle and an H, painted flat so nobody trips on it.
function padMark(n, cx, cy, rad, col = '#e8e8f0', lw = 5) {
  n.strokeStyle = col; n.lineWidth = lw;
  n.beginPath(); n.arc(cx, cy, rad, 0, 7); n.stroke();
  const bh = rad * 0.78, bw = rad * 0.40, t = lw + 3;
  n.fillStyle = col;
  n.fillRect(cx - bw - t / 2, cy - bh / 2, t, bh);
  n.fillRect(cx + bw - t / 2, cy - bh / 2, t, bh);
  n.fillRect(cx - bw, cy - t / 2, bw * 2, t);
}
// Perimeter lights along a roof edge, with their falloff.
function edgeLights(n, L, y, col = '#ffdc60', pitch = 70) {
  const w = L.near.width;
  for (let x = 20; x < w; x += pitch) {
    n.fillStyle = col; n.fillRect(x, y, 4, 3);
    const g = n.createRadialGradient(x + 2, y + 1, 0, x + 2, y + 1, 16);
    g.addColorStop(0, 'rgba(255,220,96,0.30)'); g.addColorStop(1, 'rgba(255,220,96,0)');
    n.fillStyle = g; n.fillRect(x - 14, y - 15, 32, 32);
  }
}
// Everything painted onto a roof deck: approach chevrons, a painted edge line,
// tie-down rings, a stencilled number. Paint only - nothing to trip over.
function deckMarks(n, L, R, r, top, hx, col = 'rgba(232,232,240,0.30)', warm = 'rgba(255,200,90,0.22)') {
  const w = L.near.width;
  n.fillStyle = col; n.fillRect(0, top + 8, w, 2);
  n.fillStyle = 'rgba(232,160,48,0.22)'; n.fillRect(0, 232, w, 2);
  for (let x = 40; x < w; x += 132) {
    n.fillStyle = 'rgba(0,0,0,0.38)'; n.beginPath(); n.ellipse(x, 176 + ((x * 7) % 46), 6, 3, 0, 0, 7); n.fill();
    n.strokeStyle = 'rgba(190,190,205,0.35)'; n.lineWidth = 1.5;
    n.beginPath(); n.ellipse(x, 175 + ((x * 7) % 46), 5, 2.5, 0, 0, 7); n.stroke();
  }
  for (let k = 0; k < 5; k++) {
    const cx = hx - 300 + k * 46;
    n.strokeStyle = warm; n.lineWidth = 4;
    n.beginPath(); n.moveTo(cx, 196); n.lineTo(cx + 18, 208); n.lineTo(cx, 220); n.stroke();
  }
  for (let x = 90; x < w; x += 296) {
    n.strokeStyle = 'rgba(232,232,240,0.16)'; n.lineWidth = 2;
    n.strokeRect(x, 188, 74, 38);
    ptext(n, String(80 + ((x / 296) | 0)), x + 6, 192, 'rgba(232,232,240,0.22)', 2);
  }
  for (let k = 0; k < w * 0.4; k++) {
    n.fillStyle = R() < 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.09)';
    n.fillRect(r(0, w), r(top + 4, 238), 8 + R() * 22, 1 + (R() < 0.3 ? 1 : 0));
  }
}
// The aircraft: side-on, skids down. Sits high enough that a fighter standing
// at the back of the walkable band reads as being in front of it.
function chopper(n, cx, cy, R) {
  n.fillStyle = 'rgba(0,0,0,0.30)'; n.beginPath(); n.ellipse(cx, DECK8 + 4, 78, 7, 0, 0, 7); n.fill();
  n.fillStyle = '#1e2a34'; n.beginPath();
  n.moveTo(cx + 14, cy - 2); n.lineTo(cx + 92, cy + 2); n.lineTo(cx + 92, cy + 9); n.lineTo(cx + 14, cy + 14); n.fill();
  n.fillStyle = '#2c3d4c'; n.fillRect(cx + 14, cy - 2, 78, 3);
  n.fillStyle = '#1a252e'; n.beginPath();
  n.moveTo(cx + 84, cy + 4); n.lineTo(cx + 100, cy - 16); n.lineTo(cx + 106, cy - 14); n.lineTo(cx + 96, cy + 8); n.fill();
  n.strokeStyle = 'rgba(200,220,235,0.25)'; n.lineWidth = 2;
  n.beginPath(); n.arc(cx + 100, cy - 6, 11, 0, 7); n.stroke();
  n.fillStyle = '#24323e'; n.beginPath();
  n.moveTo(cx - 40, cy + 2); n.quadraticCurveTo(cx - 44, cy + 22, cx - 20, cy + 26);
  n.lineTo(cx + 18, cy + 22); n.lineTo(cx + 20, cy - 4); n.quadraticCurveTo(cx - 6, cy - 12, cx - 40, cy + 2); n.fill();
  n.fillStyle = '#35495a'; n.beginPath();
  n.moveTo(cx - 40, cy + 2); n.quadraticCurveTo(cx - 6, cy - 12, cx + 20, cy - 4); n.lineTo(cx + 20, cy - 1);
  n.quadraticCurveTo(cx - 6, cy - 9, cx - 39, cy + 5); n.fill();
  n.fillStyle = 'rgba(150,200,240,0.55)'; n.beginPath();
  n.moveTo(cx - 38, cy + 4); n.quadraticCurveTo(cx - 40, cy + 18, cx - 22, cy + 21);
  n.lineTo(cx - 4, cy + 18); n.lineTo(cx - 6, cy + 1); n.fill();
  n.fillStyle = 'rgba(210,235,255,0.30)'; n.beginPath();
  n.moveTo(cx - 36, cy + 5); n.lineTo(cx - 22, cy + 18); n.lineTo(cx - 14, cy + 17); n.lineTo(cx - 30, cy + 3); n.fill();
  n.fillStyle = '#8a1a2a'; n.fillRect(cx - 2, cy + 6, 18, 5);
  n.fillStyle = '#f2c94c'; n.fillRect(cx - 2, cy + 11, 18, 2);
  n.fillStyle = '#1a252e'; n.fillRect(cx - 34, cy + 28, 5, 12); n.fillRect(cx + 6, cy + 28, 5, 12);
  n.fillStyle = '#26333e'; n.fillRect(cx - 42, cy + 38, 62, 4);
  n.fillStyle = '#16202a'; n.fillRect(cx - 12, cy - 10, 8, 10);
  n.fillStyle = '#2c3d4c'; n.fillRect(cx - 14, cy - 12, 12, 4);
}

// ---- STAGE 8 scene 1: THE BLACKOUT LOBBY ---------------------------------
// They cut the power to the lower floors to slow you down. The only light
// inside is the emergency fittings; everything bright is the city, outside.
function blackoutBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  f.fillStyle = '#04040c'; f.fillRect(0, 0, W1, H);
  for (let x = 0; x < W1; x += 15) {
    const bh = 28 + ((x * 23) % 74);
    f.fillStyle = ((x / 15) | 0) % 2 ? '#0f0d1c' : '#0a0916'; f.fillRect(x, 150 - bh, 14, bh + 4);
    for (let k = 0; k < 14; k++) {
      f.fillStyle = R() < 0.55 ? 'rgba(232,196,104,0.80)' : 'rgba(118,172,236,0.75)';
      f.fillRect(x + 1 + R() * 12, 150 - bh + 2 + R() * (bh - 4), 1, 1);
    }
  }
  curtainWall(m, L, 0, WM, 36, 112, R, r, { bay: 72, frame: '#141222', hi: '#241f38', dark: '#07060f' });
  for (let x = 0; x < WM; x += 72) {                   // light thrown in across the floor
    const g = m.createLinearGradient(0, 100, 0, 150);
    g.addColorStop(0, 'rgba(180,200,255,0.10)'); g.addColorStop(1, 'rgba(180,200,255,0)');
    m.fillStyle = g; m.fillRect(x, 100, 62, 50);
  }
  n.fillStyle = '#0a0812'; n.fillRect(0, 34, W2, 16);
  for (let x = 40; x < W2; x += 232) {                 // marble columns, unlit
    n.fillStyle = '#100d1e'; n.fillRect(x - 5, 34, 40, 114);
    n.fillStyle = '#1d1832'; n.fillRect(x, 40, 30, 108);
    n.fillStyle = '#292342'; n.fillRect(x + 3, 40, 7, 108);
    n.fillStyle = 'rgba(0,0,0,0.45)'; n.fillRect(x + 23, 40, 7, 108);
    n.fillStyle = '#0d0a18'; n.fillRect(x - 7, 36, 44, 8); n.fillRect(x - 7, 138, 44, 10);
  }
  for (let x = 74; x < W2; x += 116) {                 // emergency fittings, green and weak
    n.fillStyle = '#1a2620'; n.fillRect(x, 52, 20, 8);
    n.fillStyle = '#5ad06a'; n.fillRect(x + 2, 55, 16, 3);
    const g = n.createRadialGradient(x + 10, 58, 0, x + 10, 58, 60);
    g.addColorStop(0, 'rgba(90,208,106,0.20)'); g.addColorStop(1, 'rgba(90,208,106,0)');
    n.fillStyle = g; n.fillRect(x - 50, 8, 120, 120);
  }
  for (let x = 160; x < W2; x += 348) {                // running-man exit signs
    n.fillStyle = '#0c1a12'; n.fillRect(x, 64, 26, 12);
    n.fillStyle = '#2aa04a'; n.fillRect(x + 1, 65, 24, 10);
    n.fillStyle = '#d8ffe0'; n.fillRect(x + 6, 67, 4, 6); n.fillRect(x + 13, 68, 8, 2);
  }
  for (let x = 112; x < W2; x += 232) {                // security shutters, half dropped
    const drop = 40 + ((x * 11) % 34);
    n.fillStyle = '#16131f'; n.fillRect(x, 44, 96, drop);
    for (let y = 44; y < 44 + drop; y += 5) { n.fillStyle = ((y / 5) | 0) % 2 ? '#211c2e' : '#191523'; n.fillRect(x, y, 96, 4); }
    n.fillStyle = '#2c2640'; n.fillRect(x, 44 + drop, 96, 4);
    n.fillStyle = 'rgba(0,0,0,0.55)'; n.fillRect(x, 44 + drop + 4, 96, 10);
  }
  n.fillStyle = '#15112a'; n.fillRect(180, 108, 168, 40);     // reception, abandoned mid-shift
  n.fillStyle = '#221b3e'; n.fillRect(180, 108, 168, 4);
  for (let k = 0; k < 3; k++) { n.fillStyle = 'rgba(74,192,232,0.25)'; n.fillRect(200 + k * 44, 118, 14, 9); }
  n.fillStyle = 'rgba(232,240,255,0.30)'; n.fillRect(262, 112, 10, 7);
  n.fillStyle = '#0d0a18'; n.fillRect(206, 62, 116, 40);
  ptext(n, 'DRAY', 232, 72, 'rgba(242,201,76,0.30)', 2);
  // the forced lift shaft, doors levered apart, exactly where the pit stands
  n.fillStyle = '#100d1c'; n.fillRect(A8_PIT - 78, 52, 156, 96);
  n.fillStyle = '#1e1930'; n.fillRect(A8_PIT - 78, 52, 156, 5);
  n.fillStyle = '#2b2442'; n.fillRect(A8_PIT - 78, 52, 6, 96); n.fillRect(A8_PIT + 72, 52, 6, 96);
  n.fillStyle = '#26203c'; n.fillRect(A8_PIT - 70, 60, 58, 88);
  n.fillStyle = '#332b4e'; n.fillRect(A8_PIT - 70, 60, 4, 88);
  n.fillStyle = '#26203c'; n.fillRect(A8_PIT + 22, 60, 48, 88);
  n.fillStyle = '#332b4e'; n.fillRect(A8_PIT + 22, 60, 4, 88);
  n.fillStyle = '#05040a'; n.fillRect(A8_PIT - 12, 60, 34, 88);
  n.fillStyle = '#1a1628'; n.fillRect(A8_PIT - 6, 60, 4, 88);
  n.fillStyle = 'rgba(90,208,106,0.35)'; n.fillRect(A8_PIT + 4, 72, 3, 3);
  floorVoid(n, A8_PIT - 52, FLOOR8, 104, R, r, '#030309');
  stoneFloor(n, L, R, r, FLOOR8, '#1d1938', 'rgba(150,150,200,0.09)', '#2a2352', 64);
  for (let x = 74; x < W2; x += 116) {
    const g = n.createLinearGradient(0, FLOOR8, 0, 240);
    g.addColorStop(0, 'rgba(90,208,106,0.10)'); g.addColorStop(1, 'rgba(90,208,106,0)');
    n.fillStyle = g; n.fillRect(x - 40, FLOOR8, 100, 92);
  }
  n.fillStyle = 'rgba(180,200,255,0.07)'; n.fillRect(0, FLOOR8, W2, 92);
}

// ---- STAGE 8 scene 2: THE MODEL ROOM -------------------------------------
// His collection floor: the city he bought, in miniature, under glass. You
// walk the length of it past every place you have already fought through.
function modelRoomBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  f.fillStyle = '#080610'; f.fillRect(0, 0, W1, H);
  for (let k = 0; k < W1 * 0.4; k++) { f.fillStyle = 'rgba(200,170,110,0.13)'; f.fillRect(r(0, W1), r(40, 148), 1, 1); }
  // The back wall stays a dark panelled backdrop: the cases in the near layer
  // are the subject of this room, and anything bright back here fights them.
  m.fillStyle = '#120e1c'; m.fillRect(0, 34, WM, 116);
  m.fillStyle = '#1c1628'; m.fillRect(0, 34, WM, 4);
  for (let x = 0; x < WM; x += 58) {
    m.fillStyle = ((x / 58) | 0) % 2 ? '#161121' : '#131020'; m.fillRect(x, 38, 54, 110);
    m.fillStyle = '#221a30'; m.fillRect(x + 54, 34, 4, 114);
    m.fillStyle = 'rgba(255,224,170,0.025)'; m.fillRect(x, 38, 26, 110);
  }
  for (let x = 0; x < WM; x += 232) {                        // a dim framed plan every so often
    const h = 34 + ((x * 13) % 16), y = 46 + ((x * 7) % 8);
    m.fillStyle = '#2e2412'; m.fillRect(x + 8, y - 2, 58, h + 4);
    m.fillStyle = '#39352a'; m.fillRect(x + 11, y, 52, h);
    m.fillStyle = 'rgba(20,18,14,0.55)';
    for (let k = 0; k < 12; k++) m.fillRect(x + 14 + R() * 44, y + 4 + R() * (h - 8), 2 + R() * 18, 1);
    m.fillStyle = 'rgba(140,26,42,0.25)'; m.fillRect(x + 14, y + h - 7, 12, 3);
  }
  m.fillStyle = 'rgba(8,6,14,0.35)'; m.fillRect(0, 34, WM, 116);
  n.fillStyle = '#0e0b18'; n.fillRect(0, 34, W2, 12);
  for (let x = 0; x < W2; x += 92) {                          // track lighting the whole length
    n.fillStyle = '#211c30'; n.fillRect(x, 42, 76, 4);
    n.fillStyle = '#c8a24c'; n.fillRect(x + 10, 46, 8, 5); n.fillRect(x + 48, 46, 8, 5);
    for (const lx of [x + 14, x + 52]) {
      const g = n.createLinearGradient(0, 50, 0, 140);
      g.addColorStop(0, 'rgba(255,224,170,0.19)'); g.addColorStop(1, 'rgba(255,224,170,0)');
      n.fillStyle = g; n.beginPath(); n.moveTo(lx - 5, 50); n.lineTo(lx + 5, 50);
      n.lineTo(lx + 26, 140); n.lineTo(lx - 26, 140); n.fill();
    }
  }
  const CASES = ['el', 'neon', 'frame', 'yard', 'road', 'works', 'lab'];
  for (let i = 0; i < 9; i++) {
    const cx = 90 + i * 180;
    if (cx > W2 - 40) break;
    n.fillStyle = '#17121f'; n.fillRect(cx - 62, 112, 124, 36);
    n.fillStyle = '#241d30'; n.fillRect(cx - 62, 112, 124, 3);
    n.fillStyle = '#c8a24c'; n.fillRect(cx - 62, 115, 124, 1);
    n.fillStyle = 'rgba(200,162,76,0.45)'; n.fillRect(cx - 26, 128, 52, 4);
    n.fillStyle = '#0e0b18'; n.fillRect(cx - 24, 129, 48, 2);
    n.fillStyle = '#0c0a14'; n.fillRect(cx - 58, 62, 116, 50);
    modelCity(n, cx, 62, 116, 50, CASES[i % CASES.length], R, r);
    n.fillStyle = 'rgba(170,210,255,0.08)'; n.fillRect(cx - 58, 62, 116, 50);
    n.fillStyle = 'rgba(210,235,255,0.10)';
    n.beginPath(); n.moveTo(cx - 58, 112); n.lineTo(cx - 14, 62); n.lineTo(cx + 2, 62); n.lineTo(cx - 42, 112); n.fill();
    n.fillStyle = '#3a3350'; n.fillRect(cx - 61, 59, 122, 4);
    n.fillStyle = '#4e4668'; n.fillRect(cx - 61, 59, 122, 1);
    n.fillStyle = '#3a3350'; n.fillRect(cx - 61, 62, 3, 50); n.fillRect(cx + 58, 62, 3, 50);
  }
  // the centrepiece: this tower, twice the height of the rest, lit gold
  const tx = Math.min(1060, len - 320);
  n.fillStyle = '#1a1424'; n.fillRect(tx - 46, 100, 92, 48);
  n.fillStyle = '#292038'; n.fillRect(tx - 46, 100, 92, 3);
  n.fillStyle = '#f2c94c'; n.fillRect(tx - 46, 103, 92, 1);
  n.fillStyle = '#0b0912'; n.fillRect(tx - 40, 48, 80, 52);
  for (let k = 0; k < 5; k++) {
    const tw2 = 30 - k * 4;
    n.fillStyle = k === 4 ? '#c8a24c' : '#4a4266';
    n.fillRect(tx - tw2 / 2, 96 - k * 11, tw2, 11);
    n.fillStyle = k === 4 ? '#f2d878' : '#5e5480'; n.fillRect(tx - tw2 / 2, 96 - k * 11, tw2, 2);
    n.fillStyle = 'rgba(0,0,0,0.3)'; n.fillRect(tx + tw2 / 2 - 4, 96 - k * 11, 4, 11);
  }
  n.fillStyle = '#ff3a3a'; n.fillRect(tx - 1, 38, 3, 3);
  const tg = n.createRadialGradient(tx, 70, 0, tx, 70, 64);
  tg.addColorStop(0, 'rgba(242,201,76,0.22)'); tg.addColorStop(1, 'rgba(242,201,76,0)');
  n.fillStyle = tg; n.fillRect(tx - 64, 34, 128, 114);
  n.fillStyle = 'rgba(170,210,255,0.07)'; n.fillRect(tx - 40, 48, 80, 52);
  n.fillStyle = '#f2c94c'; n.fillRect(tx - 34, 126, 68, 6);
  ptext(n, 'PHASE TWO', tx - 30, 127, '#0e0b18');
  stoneFloor(n, L, R, r, FLOOR8, '#191426', 'rgba(150,130,180,0.08)', '#2a2140', 70);
  for (let i = 0; i < 9; i++) {
    const cx = 90 + i * 180; if (cx > W2 - 40) break;
    const g = n.createLinearGradient(0, FLOOR8, 0, 220);
    g.addColorStop(0, 'rgba(170,210,255,0.09)'); g.addColorStop(1, 'rgba(170,210,255,0)');
    n.fillStyle = g; n.fillRect(cx - 62, FLOOR8, 124, 72);
  }
  n.fillStyle = 'rgba(200,162,76,0.30)'; n.fillRect(0, FLOOR8, W2, 1);
  n.fillStyle = 'rgba(0,0,0,0.22)'; n.fillRect(0, FLOOR8 + 1, W2, 4);
}
// The contents of one vitrine: a little piece of a place you have been.
function modelCity(g, cx, y, w, h, kind, R, r) {
  const base = y + h - 6;
  g.fillStyle = '#15121e'; g.fillRect(cx - w / 2 + 3, base, w - 6, 6);
  if (kind === 'el') {                                   // stage 1 - under the el
    for (let x = cx - w / 2 + 6; x < cx + w / 2 - 6; x += 9) {
      const bh = 10 + ((x * 7) % 18);
      g.fillStyle = '#3a3450'; g.fillRect(x, base - bh, 8, bh);
      for (let k = 0; k < 3; k++) { g.fillStyle = 'rgba(242,201,76,0.6)'; g.fillRect(x + 2 + (k % 2) * 4, base - bh + 3 + k * 5, 1, 1); }
    }
    g.fillStyle = '#5a4e30'; g.fillRect(cx - w / 2 + 4, base - 24, w - 8, 3);
    for (let x = cx - w / 2 + 8; x < cx + w / 2 - 6; x += 16) g.fillRect(x, base - 21, 3, 21);
  } else if (kind === 'neon') {                          // stage 2 - the strip
    for (let x = cx - w / 2 + 6; x < cx + w / 2 - 6; x += 11) {
      const bh = 12 + ((x * 11) % 22);
      g.fillStyle = '#332c48'; g.fillRect(x, base - bh, 10, bh);
      g.fillStyle = ['#e8283a', '#4ac0e8', '#c86aff'][((x / 11) | 0) % 3];
      g.fillRect(x + 1, base - bh + 3, 8, 2); g.fillRect(x + 3, base - bh + 8, 2, 6);
    }
  } else if (kind === 'frame') {                         // stage 3 - the tower site
    for (let k = 0; k < 6; k++) { g.fillStyle = '#5a5060'; g.fillRect(cx - 22 + k * 9, base - 34, 3, 34); }
    for (let k = 0; k < 5; k++) { g.fillStyle = '#4a4250'; g.fillRect(cx - 24, base - 32 + k * 7, 50, 2); }
    g.fillStyle = '#e8a030'; g.fillRect(cx + 26, base - 42, 3, 42);
    g.fillStyle = '#e8a030'; g.fillRect(cx - 4, base - 42, 34, 2);
  } else if (kind === 'yard') {                          // stage 4 - the rail yard
    for (let k = 0; k < 4; k++) { g.fillStyle = '#2e2a3a'; g.fillRect(cx - w / 2 + 6, base - 6 - k * 7, w - 12, 2); }
    for (let x = cx - 30; x < cx + 26; x += 14) { g.fillStyle = '#4a4258'; g.fillRect(x, base - 20, 12, 8); }
    g.fillStyle = '#8a3030'; g.fillRect(cx - 34, base - 21, 18, 9);
  } else if (kind === 'road') {                          // stage 5 - the interchange
    g.strokeStyle = '#4a4458'; g.lineWidth = 4;
    g.beginPath(); g.moveTo(cx - w / 2 + 4, base - 8); g.quadraticCurveTo(cx, base - 34, cx + w / 2 - 4, base - 12); g.stroke();
    g.strokeStyle = '#3a3448'; g.lineWidth = 3;
    g.beginPath(); g.moveTo(cx - w / 2 + 4, base - 22); g.quadraticCurveTo(cx + 6, base - 4, cx + w / 2 - 4, base - 26); g.stroke();
    for (let k = 0; k < 7; k++) { g.fillStyle = 'rgba(248,170,80,0.7)'; g.fillRect(cx - 24 + k * 8, base - 14 - (k % 3) * 5, 2, 1); }
  } else if (kind === 'works') {                         // stage 6 - the works
    g.fillStyle = '#332c3a'; g.fillRect(cx - w / 2 + 6, base - 22, w - 12, 22);
    for (let k = 0; k < 3; k++) { g.fillStyle = '#2a2430'; g.fillRect(cx - 26 + k * 20, base - 34, 9, 12); }
    g.fillStyle = 'rgba(232,120,40,0.65)'; g.fillRect(cx - 20, base - 12, 40, 4);
    for (let k = 0; k < 3; k++) { g.fillStyle = 'rgba(255,160,60,0.45)'; g.fillRect(cx - 24 + k * 20, base - 38, 5, 5); }
  } else {                                               // stage 7 - the lab
    g.fillStyle = '#20263a'; g.fillRect(cx - w / 2 + 6, base - 26, w - 12, 26);
    for (let k = 0; k < 6; k++) { g.fillStyle = 'rgba(90,208,180,0.55)'; g.fillRect(cx - 26 + k * 10, base - 22, 5, 14); }
    g.fillStyle = '#2e3850'; g.fillRect(cx - w / 2 + 6, base - 28, w - 12, 3);
  }
}

// ---- STAGE 8 scene 3: THE HELIPAD ----------------------------------------
// The weather turned, which is exactly why he is still on the roof: his
// aircraft cannot lift. It is strapped down on the pad behind the fight.
function stormPadBg(L, R, r, len) {
  const f = L.far.getContext('2d'), m = L.mid.getContext('2d'), n = L.near.getContext('2d');
  const W1 = L.far.width, WM = L.mid.width, W2 = L.near.width;
  const sky = f.createLinearGradient(0, 0, 0, 180);
  sky.addColorStop(0, '#090b18'); sky.addColorStop(0.45, '#16203a');
  sky.addColorStop(0.78, '#2a3350'); sky.addColorStop(1, '#3d4460');
  f.fillStyle = sky; f.fillRect(0, 0, W1, H);
  for (let k = 0; k < W1 * 0.06; k++) {                  // the cloud base, torn and moving
    const y = r(34, 130), cw = r(70, 220);
    f.fillStyle = `rgba(20,26,46,${0.25 + R() * 0.35})`;
    f.beginPath(); f.ellipse(r(0, W1), y, cw, 7 + R() * 12, 0, 0, 7); f.fill();
  }
  for (let k = 0; k < W1 * 0.02; k++) {
    f.fillStyle = `rgba(120,140,190,${0.05 + R() * 0.07})`;
    f.beginPath(); f.ellipse(r(0, W1), r(40, 120), r(50, 150), 5 + R() * 8, 0, 0, 7); f.fill();
  }
  f.fillStyle = '#121828'; f.fillRect(0, 152, W1, 88);   // the city, only where it burns through
  for (let k = 0; k < W1 * 0.30; k++) {
    f.fillStyle = R() < 0.6 ? 'rgba(232,190,110,0.28)' : 'rgba(120,170,230,0.24)';
    f.fillRect(r(0, W1), r(156, 236), 1, 1);
  }
  f.fillStyle = 'rgba(40,52,84,0.55)'; f.fillRect(0, 148, W1, 92);
  for (let x = 0; x < WM; x += 220) {                    // neighbours as grey ghosts
    const th = 34 + ((x * 17) % 40);
    m.fillStyle = 'rgba(26,34,56,0.55)'; m.fillRect(x, 152 - th, 26, th + 30);
    m.fillStyle = 'rgba(232,58,58,0.45)'; m.fillRect(x + 12, 152 - th - 4, 2, 3);
  }
  deckFloor(n, L, R, r, DECK8, '#2b2f3e', '#343948', 'rgba(0,0,0,0.30)', 40);
  n.fillStyle = 'rgba(120,150,200,0.10)'; n.fillRect(0, DECK8, W2, 240 - DECK8);
  for (let k = 0; k < W2 * 0.6; k++) {                   // standing water catching the sky
    n.fillStyle = 'rgba(150,180,230,0.09)';
    n.beginPath(); n.ellipse(r(0, W2), r(DECK8 + 6, 236), 9 + R() * 26, 3 + R() * 4, 0, 0, 7); n.fill();
  }
  n.fillStyle = '#3e4356'; n.fillRect(0, DECK8 - 6, W2, 6);
  n.fillStyle = '#525872'; n.fillRect(0, DECK8 - 6, W2, 2);
  for (let x = 40; x < W2 - 480; x += 236) {             // plant, streaming wet
    plantBox(n, x, 100, 66, 46, R, r, '#1d2028', '#2e323e');
    n.fillStyle = 'rgba(160,190,240,0.13)'; n.fillRect(x, 100, 66, 3);
    for (let k = 0; k < 6; k++) { n.fillStyle = 'rgba(180,210,250,0.20)'; n.fillRect(x + 6 + k * 10, 146, 1, 4); }
    plantBox(n, x + 80, 116, 40, 30, R, r, '#1d2028', '#2e323e');
  }
  for (let x = 20; x < W2; x += 128) {                   // a windsock standing straight out
    if (((x / 128) | 0) % 4) continue;
    n.fillStyle = '#2c303c'; n.fillRect(x, 84, 3, 62);
    n.fillStyle = '#e8681a'; n.beginPath();
    n.moveTo(x + 3, 86); n.lineTo(x + 40, 92); n.lineTo(x + 40, 100); n.lineTo(x + 3, 100); n.fill();
    n.fillStyle = '#f2f2f2'; n.beginPath();
    n.moveTo(x + 22, 89); n.lineTo(x + 31, 90.5); n.lineTo(x + 31, 100); n.lineTo(x + 22, 100); n.fill();
  }
  deckMarks(n, L, R, r, DECK8, len - 300, 'rgba(200,220,250,0.22)', 'rgba(255,176,64,0.20)');
  railing(n, 0, 116, W2, '#3a3f52', '#565d76', 26);
  edgeLights(n, L, DECK8 - 9, '#ffb040', 64);
  const hx = len - 300;                                  // the pad, streaming
  n.fillStyle = '#262a38'; n.beginPath(); n.arc(hx, 196, 98, 0, 7); n.fill();
  padMark(n, hx, 196, 62, 'rgba(226,232,244,0.75)', 5);
  n.fillStyle = 'rgba(140,175,225,0.10)'; n.beginPath(); n.arc(hx, 196, 98, 0, 7); n.fill();
  for (let k = 0; k < 16; k++) {
    const a = k / 16 * 6.283, lx = hx + Math.cos(a) * 94, ly = 196 + Math.sin(a) * 46;
    if (ly < DECK8) continue;
    n.fillStyle = '#ffb040'; n.fillRect(lx, ly, 3, 2);
    const g = n.createRadialGradient(lx, ly, 0, lx, ly, 22);
    g.addColorStop(0, 'rgba(255,176,64,0.24)'); g.addColorStop(1, 'rgba(255,176,64,0)');
    n.fillStyle = g; n.fillRect(lx - 22, ly - 22, 44, 44);
  }
  chopper(n, hx - 14, 108, R);                           // going nowhere, and tied down
  for (let k = 0; k < 3; k++) {
    n.strokeStyle = 'rgba(232,160,48,0.75)'; n.lineWidth = 2;
    n.beginPath(); n.moveTo(hx - 50 + k * 44, 136); n.lineTo(hx - 74 + k * 56, DECK8 - 2); n.stroke();
  }
  mast(n, 120, 34, 146, '#1a1e2a', '#ff3a3a', 12);
}

// ---- STAGE 8 live overlays -----------------------------------------------
// Emergency lighting settling and lifting, never blinking.
function drawEmergPulse() {
  if (!SAVE.options.flashing) return;
  const k = 0.016 + Math.abs(Math.sin(G.frames / 82)) * 0.018;
  ctx.fillStyle = `rgba(90,208,106,${k})`; ctx.fillRect(0, 34, W, 206);
}
// Guards sweeping torches across a dead lobby.
function drawTorchBeams(cam) {
  for (let i = 0; i < 3; i++) {
    const home = 280 + i * 520;
    const x = home - cam + Math.sin(G.frames / (150 + i * 40) + i * 401) * 120;
    if (x < -120 || x > W + 120) continue;
    const a = Math.sin(G.frames / (90 + i * 30) + i) * 0.5;
    ctx.save(); ctx.translate(x, 96); ctx.rotate(a);
    const gr = ctx.createLinearGradient(0, 0, 130, 0);
    gr.addColorStop(0, 'rgba(255,240,200,0.20)'); gr.addColorStop(1, 'rgba(255,240,200,0)');
    ctx.fillStyle = gr;
    ctx.beginPath(); ctx.moveTo(0, -3); ctx.lineTo(130, -26); ctx.lineTo(130, 26); ctx.lineTo(0, 3); ctx.fill();
    ctx.restore();
    ctx.fillStyle = 'rgba(255,248,220,0.55)'; ctx.fillRect(x - 1, 95, 3, 3);
  }
}
// A glint travelling across the vitrine glass as you move down the room.
function drawCaseGlint(cam) {
  for (let i = 0; i < 10; i++) {
    const cx = 90 + i * 180 - cam;
    if (cx < -80 || cx > W + 80) continue;
    const ph = (G.frames / 60 + i * 0.7) % 3;
    if (ph > 1) continue;
    const gx = cx - 58 + ph * 116;
    ctx.save(); ctx.beginPath(); ctx.rect(cx - 58, 62, 116, 50); ctx.clip();
    const gr = ctx.createLinearGradient(gx - 16, 0, gx + 16, 0);
    gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(230,245,255,0.13)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gr; ctx.fillRect(gx - 20, 62, 40, 50);
    ctx.restore();
  }
}
// Rain: near streaks moving fast, far ones slow, and splashes off the deck.
function drawRain() {
  const t = G.frames;
  for (let i = 0; i < 120; i++) {
    const seed = i * 137, depth = (i % 3) + 1, sp = 6 + depth * 4;
    const x = ((seed * 43 + t * (sp * 2.2)) % (W + 260)) - 130;
    const y = ((seed * 17 + t * sp * 3.4) % 240);
    if (y < 34) continue;
    ctx.fillStyle = `rgba(190,215,250,${0.10 + depth * 0.055})`;
    ctx.fillRect(x, y, 1 + (depth > 2 ? 1 : 0), 6 + depth * 4);
  }
  for (let i = 0; i < 16; i++) {
    const seed = i * 223;
    const x = ((seed * 53) % (W + 60)) - 30 + Math.sin(t / 30 + i) * 4;
    const ph = (t * 1.4 + seed) % 46;
    if (ph > 10) continue;
    ctx.fillStyle = `rgba(200,225,255,${0.20 * (1 - ph / 10)})`;
    ctx.beginPath(); ctx.ellipse(x, 168 + (seed % 56), 3 + ph, 1.5, 0, 0, 7); ctx.fill();
  }
  ctx.fillStyle = 'rgba(120,150,200,0.045)'; ctx.fillRect(0, 34, W, 206);
}
// Lightning: rare, bright, short. Off entirely when flashing effects are off.
function drawLightning() {
  if (!SAVE.options.flashing) return;
  const ph = G.frames % 420;
  if (ph > 16) return;
  const a = ph < 3 ? 0.30 : (ph < 6 ? 0.06 : (ph < 10 ? 0.22 : 0.05));
  ctx.fillStyle = `rgba(210,228,255,${a})`; ctx.fillRect(0, 34, W, 206);
}
