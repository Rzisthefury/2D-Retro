// ============================================================ PROPS & ITEMS
// ------------------------------------------------------------ props & items
function px(x, y, w, h, c) { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), w, h); }
function drawShadow(x, y, w) {
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.beginPath(); ctx.ellipse(Math.round(x), Math.round(y), w, Math.max(2, w * 0.28), 0, 0, Math.PI * 2); ctx.fill();
}
const ITEM_DRAW = {
  apple(x, y) { px(x - 4, y - 8, 9, 8, '#120a14'); px(x - 3, y - 7, 7, 6, '#d8283a'); px(x - 2, y - 6, 2, 2, '#ff8a8a'); px(x, y - 10, 1, 3, '#5a3a1a'); px(x + 1, y - 10, 3, 2, '#3aa84a'); },
  roast(x, y) {
    px(x - 9, y - 3, 18, 3, '#120a14'); px(x - 8, y - 3, 16, 2, '#e8e8f0');
    px(x - 6, y - 10, 12, 8, '#120a14'); px(x - 5, y - 9, 10, 6, '#b8642a'); px(x - 4, y - 9, 5, 2, '#e8a060');
    px(x + 4, y - 11, 4, 3, '#120a14'); px(x + 5, y - 10, 2, 1, '#f0e8d8');
  },
  cash(x, y) { px(x - 7, y - 6, 14, 6, '#120a14'); px(x - 6, y - 5, 12, 4, '#4ab04a'); px(x - 2, y - 5, 4, 4, '#2a7a2a'); px(x - 1, y - 4, 2, 2, '#9ae09a'); },
  gold(x, y) { px(x - 7, y - 6, 14, 6, '#120a14'); px(x - 6, y - 5, 12, 4, '#f2c94c'); px(x - 5, y - 5, 5, 1, '#fff0a0'); px(x - 6, y - 2, 12, 1, '#b08a20'); },
  pipe(x, y) { px(x - 11, y - 4, 23, 4, '#120a14'); px(x - 10, y - 3, 21, 2, '#9aa3ad'); px(x - 10, y - 3, 3, 2, '#6d7580'); },
  knife(x, y) { px(x - 6, y - 3, 12, 3, '#120a14'); px(x - 5, y - 2, 4, 1, '#4a2d1a'); px(x - 1, y - 2, 6, 1, '#e6eef5'); },
  power(x, y, it) {
    const t = Input.frame;
    const cols = { rage: '#e8283a', iron: '#9aa8b8', overdrive: '#30c0e0', refill: '#9a4ae8', starup: '#f2c94c', oneup: '#3ac84a' };
    const lab = { rage: 'R', iron: 'I', overdrive: 'O', refill: 'M', starup: '★', oneup: '1' };
    const bob = Math.round(Math.sin(t / 8) * 1.5);
    px(x - 6, y - 13 + bob, 12, 12, '#120a14');
    px(x - 5, y - 12 + bob, 10, 10, cols[it.power]);
    px(x - 4, y - 11 + bob, 3, 2, 'rgba(255,255,255,0.6)');
    text(lab[it.power], x - 2, y - 10 + bob, '#fff', 1, 0, '#120a14');
    if (it.power === 'oneup') text('UP', x, y - 20 + bob, '#3ac84a', 1, 1);
  },
};
function drawBreakable(b, sx, sy) {
  const f = b.flash > 0;
  const O = '#120a14';
  if (b.kind === 'can') {
    px(sx - 8, sy - 20, 16, 20, O);
    px(sx - 7, sy - 19, 14, 18, f ? '#fff' : '#7a8490');
    px(sx - 7, sy - 14, 14, 1, '#56606a'); px(sx - 7, sy - 8, 14, 1, '#56606a');
    px(sx - 9, sy - 22, 18, 4, O); px(sx - 8, sy - 21, 16, 2, f ? '#fff' : '#9aa4b0');
    px(sx - 5, sy - 18, 2, 14, 'rgba(255,255,255,0.25)');
  } else if (b.kind === 'crate') {
    px(sx - 11, sy - 20, 22, 20, O);
    px(sx - 10, sy - 19, 20, 18, f ? '#fff' : '#a8743a');
    px(sx - 10, sy - 19, 20, 2, '#c8944a'); px(sx - 10, sy - 3, 20, 2, '#7a5020');
    ctx.strokeStyle = '#7a5020'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(sx - 9, sy - 3); ctx.lineTo(sx + 9, sy - 18); ctx.stroke();
  } else if (b.kind === 'capsule') {
    const t = Input.frame;
    px(sx - 13, sy - 50, 26, 50, O);
    px(sx - 12, sy - 49, 24, 48, f ? '#fff' : '#1b2a34');
    px(sx - 10, sy - 46, 20, 42, f ? '#fff' : 'rgba(60,224,192,0.45)');
    px(sx - 9, sy - 46, 4, 42, 'rgba(255,255,255,0.22)');
    // the shape asleep inside
    ctx.fillStyle = 'rgba(12,22,30,0.8)'; ctx.beginPath(); ctx.ellipse(sx, sy - 26, 6, 15, 0, 0, 7); ctx.fill();
    px(sx - 4, sy - 34, 2, 2, Math.floor(t / 20) % 4 ? '#8ef0e0' : '#1b2a34');
    px(sx + 1, sy - 34, 2, 2, Math.floor(t / 20) % 4 ? '#8ef0e0' : '#1b2a34');
    px(sx - 15, sy - 54, 30, 6, O); px(sx - 14, sy - 53, 28, 4, '#3a4a58');
    px(sx - 15, sy - 6, 30, 6, O); px(sx - 14, sy - 5, 28, 4, '#3a4a58');
    px(sx - 14, sy - 53, 28, 1, '#7a8a98');
    text('UNIT-9', sx, sy - 62, Math.floor(t / 16) % 2 ? '#3ae0c0' : '#8ef0e0', 1, 1);
  } else if (b.kind === 'barrel') {
    px(sx - 9, sy - 24, 18, 24, O);
    px(sx - 8, sy - 23, 16, 22, f ? '#fff' : '#b8402a');
    px(sx - 8, sy - 18, 16, 2, '#6a2014'); px(sx - 8, sy - 7, 16, 2, '#6a2014');
    px(sx - 5, sy - 22, 2, 20, 'rgba(255,255,255,0.2)');
  }
}
// small head portrait for HUD
