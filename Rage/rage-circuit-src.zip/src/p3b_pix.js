// ============================================================ PIXEL SPRITE BAKER
// Fighters are posed on the skeleton, painted at 3x with discrete palette ramps
// (highlight / base / shade / deep), then reduced to 1x by majority vote so every
// output pixel is a palette colour. An outline and material ink lines are added,
// and the result is cached as a fixed sprite frame, like a hand-made sprite sheet.
const SS = 3;
// 'built' = constructed skull/jaw/hair, 'stamp' = the old 12x14 hand-pixeled faces
const HEADS = 'built';

// ------------------------------------------------------------ colour
function hexRgb(h) { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function rgbHex(r, g, b) { return '#' + ((1 << 24) | (clamp(Math.round(r), 0, 255) << 16) | (clamp(Math.round(g), 0, 255) << 8) | clamp(Math.round(b), 0, 255)).toString(16).slice(1); }
function rgb2hsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, s = 0; const l = (mx + mn) / 2;
  if (mx !== mn) {
    const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60;
  }
  return [h, s, l];
}
function hsl2rgb(h, s, l) {
  h = ((h % 360) + 360) % 360; s = clamp(s, 0, 1); l = clamp(l, 0, 1);
  const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
  const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
  return [(r + m) * 255, (g + m) * 255, (b + m) * 255];
}
function hueToward(h, target, amt) { let d = ((target - h + 540) % 360) - 180; return h + Math.sign(d) * Math.min(Math.abs(d), amt); }
function ramp(hex) {
  const [h, s, l] = rgb2hsl(...hexRgb(hex));
  const mk = (hh, ss, ll) => rgbHex(...hsl2rgb((hh % 360 + 360) % 360, clamp(ss, 0, 1), clamp(ll, 0, 1)));
  return [
    mk(hueToward(h, 48, 10), Math.min(1, s * 1.02), Math.min(0.96, l + 0.22)),
    mk(h, Math.min(1, s * 1.12), Math.min(0.9, l * 1.06)),
    // Shadows cool and DESATURATE. The old ramp pushed saturation up and let
    // hueToward take the short way round, so every warm tone hit pure red at
    // the shade step - fine under uniform tube limbs, glaring once the forms
    // have real volume and the shade covers half of every limb.
    mk(h - 8, s * 0.84, l * 0.64),
    mk(h - 20, s * 0.76, l * 0.36),
  ];
}
const lum = hex => { const [r, g, b] = hexRgb(hex); return r * 0.3 + g * 0.59 + b * 0.11; };

// ------------------------------------------------------------ head stamps (face right, 12 wide, centre 6,7)
const STAMPS = {
  cole: [
    '...HHHHH....', '.HHhhhhhHH..', 'Hhhjjjjhhhh.', 'Hhjjhhhhhhhh', 'Hhhhhhhhhhhh', 'HhhhhHszzzs.', 'HhhhHsssHHs.',
    'HhhHSsszwpss', 'HhHHSSssssss', '.HHHssssssS.', '..HHsssSsmm.', '...HSsHsHss.', '....SSHHHS..', '.....SSSS...'],
  clean: [
    '...HHHHH....', '.HHhhhhhHH..', 'Hhhjjjjhhhh.', 'Hhjjhhhhhhhh', 'Hhhhhhhhhhhh', 'HhhhhHszzzs.', 'HhhhHsssHHs.',
    'HhhHSsszwpss', 'HhHHSSssssss', '.HHHssssssS.', '..HHsssSsmm.', '...HSssSsss.', '....SSsssS..', '.....SSSS...'],
  anita: [
    '....hhhhh...', '..hhjjjjhh..', '.hhjjjjhhhh.', 'hhjjhhhhhhhh', 'hhhhhhhhhhhH', 'hhhhhHhzzhH.', 'hhhhHsszppz.',
    'hhhHSsszwps.', 'hhhHSSssssss', 'hhhhgsssssS.', 'hhhhgsssSmm.', 'Hhhh..SsSs..', 'Hhhh...SS...', 'HHhh..SSS...',
    '.Hhh........', '.HHh........', '..HH........', '...H........'],
  mohawk: [
    '....hhh.....', '...hjjhh....', '...hjhhh....', '..Hhhhhhh...', '.SSHhhhHSS..', 'SSSsHHHszzs.', 'SSsssssHHHs.',
    'SSsSSsszwpss', 'SsSSSsssssss', '.SssssssssS.', '..SsssSSsmm.', '...SsssSsss.', '....SSsssS..', '.....SSSS...'],
  cap: [
    '...AAAAA....', '.AAaaaaaA...', 'Aaaqqqaaaa..', 'Aaqqaaaaaaa.', 'AAaaaaaaaaAA', 'HhhAAAszzzs.', 'HhhhSsssHHs.',
    'HhhHSsszwpss', '.hHHSSssssss', '..HHssssssS.', '...HsssSsmm.', '....SssSsss.', '....SSsssS..', '.....SSSS...'],
  spiky: [
    '.h..j..h....', '.hh.jj.hh.h.', 'Hhhjjjjhhhh.', 'Hhjjhhhhhhhh', 'HhhhhhhhhhhH', 'HhhhhHszzzs.', 'HhhhHsssHHs.',
    'HhhHSsszwpss', 'HhHHSSssssss', '.HHHssssssS.', '..HHsssSsmm.', '...HSssSsss.', '....SSsssS..', '.....SSSS...'],
  band: [
    '...HHHHH....', '.HHhhhhhHH..', 'Hhhjjjjhhhh.', 'Hhjjhhhhhhhh', 'aaaaaaaaaaaa', 'HhhhhAszzzs.', 'HhhhHsssHHs.',
    'HhhHSsszwpss', 'HhHHSSssssss', 'HHhHssssssS.', 'HhhHsssSsmm.', 'HhhHSssSsss.', 'HHh.SSsssS..', '.HH..SSSS...', '.H..........'],
  bandana: [
    '....aaaaa...', '..aaqqqqaa..', '.aaqqaaaaaa.', 'Haaaaaaaaaaa', 'HHhhhhhhhhhh', 'HhhhhHhzzhH.', 'hHhhHsszppz.',
    'hHhHSsszwps.', '.hhHSSssssss', '..hhSsssssS.', '...h.sssSmm.', '......SsSs..', '......SSS...', '.....SSSS...'],
  pony: [
    '....hhhhh...', '..hhjjjjhh..', '.hhjjhhhhhh.', 'Hhhhhhhhhhhh', 'HHhhhhhhhhhh', 'HhhhhHhzzhH.', 'hHhhHsszppz.',
    'hHhHSsszwps.', '.hhHSSssssss', '..hhSsssssS.', '...h.sssSmm.', '......SsSs..', '......SSS...', '.....SSSS...'],
  bald: [
    '...SSSSS....', '.SSssszzSS..', 'SsszzzzsssS.', 'SszzssssssSS', 'Ssssssssssss', 'SsssssszzzS.', 'SsssSsssHHs.',
    'SssSSsszwpss', 'SsSSSSssssss', '.SSSsHssssS.', '..SSHhhhhmh.', '...HhhhhhhH.', '....HhhhhH..', '.....HHHH...'],
  shades: [
    '...SSSSS....', '.SSssszzSS..', 'SsszzzzsssS.', 'SszzssssssSS', 'Ssssssssssss', 'SsssssszzzS.', 'SsssSsssHHs.',
    'SssSSsAqAAAA', 'SsSSSSsAAAAs', '.SSSsHssssS.', '..SSHhhhhmh.', '...HhhhhhhH.', '....HhhhhH..', '.....HHHH...'],
  dummy: [
    '...SSSSS....', '.SSssszzSS..', 'SsszzzzsssS.', 'SszzssssssSS', 'Ssssssssssss', 'SsssssszzzS.', 'SsssSsssssS.',
    'SssSSsssaass', 'SsSSSSssssss', '.SSSsssaaaS.', '..SSsssSsss.', '...SSsssSs..', '....SSsssS..', '.....SSSS...'],
  bob: [
    '...hhhhhh...', '.hhjjjjjhh..', 'hhjjhhhhhhh.', 'hjhhhhhhhhhh', 'hhhhhhhhhhhh', 'hhhhhhhzzhh.', 'hhhhHsszppz.',
    'hhhHSsszwps.', 'hhhHSSssssss', 'hhhhSsssssS.', 'hhhH.sssSmm.', '.hHH..SsSs..', '......SSS...', '.....SSSS...'],
  bun: [
    '....hhh.....', '...hjjhh....', '...hhhhh....', '..HhhhhhhH..', '.hhjjjhhhhh.', 'hhjhhhhzzhh.', 'hhhhHsszppz.',
    'hhhHSsszwps.', 'hhHgSSssssss', '.hHgSsssssS.', '..H..sssSmm.', '......SsSs..', '......SSS...', '.....SSSS...'],
  robot: [
    '...AAAAA....', '.AAaaaaaAA..', 'Aaaqqqqaaaa.', 'Aaqqaaaaaaaa', 'Aaaaaaaaaaaa', 'AaaaAAAAAAAA', 'AaaAkkkkkkkk',
    'AaaAkeeeeeek', 'AaaAkkkkkkkk', 'AaaaAaaaaaA.', '.AaaaaaAAaA.', '..AAaaAAaAA.', '...AAAAAAA..', '.....kkkk...'],
  flattop: [
    '..HHHHHHH...', '.HHHHHHHHH..', '.Hhhhhhhhhh.', '.Hhhhhhhhhhh', 'HhhhhhhhhhhH', 'HhhhhHszzzs.', 'HhhhSssHHHs.',
    'HhhSSsszwpss', 'HSSSSSssssss', '.SSSsssssss.', '..SSsssSsmm.', '..SSsssSsss.', '...SSsssSS..', '....SSSSS...'],
  goggles: [
    '...hhhhhh...', '..hjjjjjhh..', '.hhjjhhhhhh.', '.hhhhhhhhhh.', 'AAAAAAAAAAAA', 'AaaaaqqqqqaA', 'hhhhHsssHHs.',
    'hhhHSsszwpss', 'hhHHSSssssss', '.HHHssssssS.', '..HHsssSsmm.', '...HSssSsss.', '....SSsssS..', '.....SSSS...'],
  slick: [
    '...HHHHH....', '.HHhhhhhHH..', 'HhhhhhhhhhH.', 'Hhhhhhhhhhhh', 'HhhhhhhhhhhH', 'HhhhhHszzzs.', 'HhhhHsssHHs.',
    'HhhHSsszwpss', 'HhHHSSssssss', '.HHHssssssS.', '..HHsssSsmm.', '...HSssSsss.', '...SSSsssS..', '..SSSSSSS...'],
  helm: [
    '...AAAAA....', '.AAaaaaaAA..', 'Aaaqqqqaaaa.', 'Aaqqaaaaaaaa', 'AaaaaaaaaaaA', 'AaaaAkkkkkkk', 'AaaAkeeeeeek',
    'AaaAkkkkkkkk', 'AaaAAaaaaaaA', 'AaaaAaaaaaA.', '.AaaaaaAAaA.', '..AAaaAAaAA.', '...AAAAAAA..', '....kkkkk...'],
  masked: [
    '...HHHHH....', '.HHhhhhhHH..', 'Hhhhhhhhhhh.', 'Hhhhhhhhhhhh', 'Hhhhhhhhhhhh', 'HhhhhAAAAAAA', 'HhhhAAeeeAAA',
    'HhhAAAAAAAAA', 'HhAAAAAAAAAA', '.HAAAAAAAAA.', '..AAAAAAAAA.', '...AAAAAAAA.', '....AAAAAA..', '.....SSSS...'],
  hardhat: [
    '...AAAAAA...', '.AAaaaaaaAA.', 'Aaqqqqaaaaa.', 'Aaqwwkwwaaa.', 'AAAAAAAAAAAA', 'HhhhhSszzzs.', 'HhhhSsssHHs.',
    'HhhSSsszwpss', 'HhSSSSssssss', '.HSSsssHHHS.', '..SSsssHHHm.', '...SsssSsss.', '....SSsssS..', '.....SSSS...'],
};
const STAMP_KEYS = { s: ['skin', 1], S: ['skin', 2], z: ['skin', 0], Z: ['skin', 3], h: ['hair', 1], H: ['hair', 2], j: ['hair', 0], J: ['hair', 3],
  a: ['acc', 1], A: ['acc', 2], q: ['acc', 0], Q: ['acc', 3] };

// ------------------------------------------------------------ looks
let LOOK_ID = 0;
const FLAT = { eyeW: '#f2eef2', pupil: '#1a1020', glow: '#ff2a4a', gold: '#f2c94c' };
function mkLook(o) {
  const L = Object.assign({ skin: '#e0a47a', hair: '#3a2418', top: '#555555', inner: '#dddddd', pants: '#333355', boots: '#222222',
    gloves: null, acc: '#aa3333', belt: '#2a1a14', lip: '#b8484a', metal: '#a8b0bc', wood: '#9a6a38', head: 'clean', scale: 1, girth: 1 }, o);
  L.id = ++LOOK_ID;
  L.P = {};
  for (const k of ['skin', 'hair', 'top', 'inner', 'pants', 'boots', 'acc', 'belt', 'metal', 'wood', 'pole', 'stripe']) {
    const c = k === 'pole' ? '#3a7048' : L[k];
    if (c) L.P[k] = ramp(c);
  }
  L.P.gloves = L.gloves ? ramp(L.gloves) : L.P.skin;
  // flat detail colours
  L.F = Object.assign({}, FLAT, { lip: L.lip });
  // palette list: index 0 transparent
  const list = [null], seen = new Map();
  const add = (hex, mat, tone, detail) => {
    if (seen.has(hex)) return;
    const [r, g, b] = hexRgb(hex);
    seen.set(hex, list.length);
    list.push({ hex, r, g, b, mat, tone, detail: !!detail, lum: lum(hex) });
  };
  for (const m in L.P) L.P[m].forEach((c, t) => add(c, m, t, false));
  for (const f in L.F) add(L.F[f], f, 1, true);
  add(OUTLINE, 'ink', 3, true);
  L.list = list; L.cmap = new Map();
  L.ink = {};
  for (const m in L.P) { const [r, g, b] = hexRgb(L.P[m][3]); L.ink[m] = rgbHex(r * 0.42, g * 0.38, b * 0.5); }
  return L;
}
function recolor(base, over) {
  const o = {};
  for (const k in base) if (!['id', 'P', 'F', 'list', 'cmap', 'ink'].includes(k)) o[k] = base[k];
  return mkLook(Object.assign(o, over));
}
const LOOKS = {};
// Build 3 cast: bold saturated palettes, heroic comic build. All designs original.
LOOKS.cole = mkLook({ name: 'cole', head: 'cole', beard: true, skin: '#f0b184', hair: '#6b3a1a', top: '#2a62c8', inner: '#f2f2ea', pants: '#3a3f4c',
  boots: '#8a4418', gloves: '#c82a2a', belt: '#f2c94c', acc: '#c82a2a', sleeve: 'elbow', jacket: true, cuffs: true });
LOOKS.coleCPU = recolor(LOOKS.cole, { top: '#2aa05a', gloves: '#f2c94c', hair: '#241a18', pants: '#4a3a2a' });
LOOKS.anita = mkLook({ name: 'anita', head: 'anita', fem: true, skin: '#f7c39a', hair: '#b8341a', top: '#e01a5a', inner: '#1a1420',
  pants: '#1a1420', boots: '#241a2e', gloves: '#241a2e', acc: '#e01a5a', belt: '#f2c94c', lip: '#ff4a78', sleeve: 'elbow',
  jacket: true, crop: true, skirt: true, bare: 'legs', tallBoots: true, legs: 1.08, girth: 0.86, cuffs: true, torso: 0.96 });
LOOKS.anitaCPU = recolor(LOOKS.anita, { top: '#7a3ae0', acc: '#7a3ae0', hair: '#f0c860' });
LOOKS.punkA = mkLook({ name: 'punkA', head: 'mohawk', skin: '#d99a70', hair: '#ff3a2a', top: '#2e2e3a', pants: '#2a8ad0', boots: '#141418',
  sleeve: 'none', stripe: '#f2f2ea', inner: null, spikes: true, bare: 'arms' });
LOOKS.punkB = mkLook({ name: 'punkB', head: 'cap', skin: '#9a6242', hair: '#1a141a', acc: '#f24a2a', top: '#f2efe2', inner: null,
  sleeve: 'short', pants: '#2a5ad8', boots: '#f2f2f2' });
LOOKS.punkC = mkLook({ name: 'punkC', head: 'spiky', skin: '#f2c199', hair: '#ffd23a', top: '#2ab05a', inner: null, sleeve: 'none',
  pants: '#2a2a34', boots: '#8a4a20', stripe: '#141418', bare: 'arms' });
LOOKS.bladeA = mkLook({ name: 'bladeA', head: 'band', skin: '#e0a87e', hair: '#1c1a1e', acc: '#f2f2f2', top: '#8a2ae0', inner: '#141018',
  sleeve: 'long', pants: '#1c1c28', boots: '#6a3a1a', legs: 1.05, vest: true });
LOOKS.bladeB = mkLook({ name: 'bladeB', head: 'bandana', fem: true, skin: '#b87a54', hair: '#d82a4a', acc: '#f2c020', top: '#1aa8c8',
  inner: '#f2e2a0', sleeve: 'long', pants: '#26262e', boots: '#141418', legs: 1.05, girth: 0.9 });
LOOKS.bruiserA = mkLook({ name: 'bruiserA', head: 'bald', skin: '#d89a6a', hair: '#2a1a10', top: '#3ab04a', inner: null, sleeve: 'none',
  pants: '#4a4a5a', boots: '#16161a', scale: 1.16, girth: 1.22, arms: 0.88, belly: 2.5, fist: 3.2, heavy: true, bare: 'arms', tank: true });
LOOKS.bruiserB = mkLook({ name: 'bruiserB', head: 'clean', skin: '#8a5334', hair: '#141214', top: '#e0402a', inner: '#f2f2ea',
  sleeve: 'none', pants: '#2a4a8a', boots: '#5a3a1a', scale: 1.16, girth: 1.22, arms: 0.88, belly: 2.5, fist: 3.2, heavy: true, vest: true });
LOOKS.kickerA = mkLook({ name: 'kickerA', head: 'pony', fem: true, skin: '#f2c199', hair: '#1a1a1a', top: '#f2f2f2', inner: '#e01a5a',
  sleeve: 'none', pants: '#1a1a26', boots: '#e01a5a', bare: 'legs', shorts: true, legs: 1.1, girth: 0.88, tallBoots: true, crop: true });
LOOKS.kickerB = mkLook({ name: 'kickerB', head: 'clean', skin: '#c08458', hair: '#f2f2f2', top: '#1a1a20', inner: '#2ad0f0',
  sleeve: 'none', pants: '#3a3ad0', boots: '#f0f0f0', legs: 1.1, girth: 0.9, stripe: '#2ad0f0', bare: 'arms' });
LOOKS.brick = mkLook({ name: 'brick', head: 'shades', beard: true, skin: '#e0a070', hair: '#241410', acc: '#101014', top: '#1a1a1e', inner: null,
  sleeve: 'none', pants: '#4a4a54', boots: '#241a14', belt: '#f2c94c', scale: 1.42, girth: 1.28, arms: 1.0, belly: 3.5,
  fist: 3.3, arms: 0.88, heavy: true, chain: true, bare: 'arms', tank: true, headScale: 1 });
LOOKS.dummy = mkLook({ name: 'dummy', head: 'dummy', skin: '#d8b070', hair: '#a88850', acc: '#e0402a', top: '#c89a5a', inner: null,
  sleeve: 'none', pants: '#b08a50', boots: '#6a5030', stripe: '#e0402a' });
LOOKS.whipA = mkLook({ name: 'whipA', head: 'bob', fem: true, skin: '#f7c8ac', hair: '#7a1ad0', lip: '#ff2a6a', top: '#2a1030',
  inner: '#c81a6a', sleeve: 'none', pants: '#2a1030', boots: '#2a1030', gloves: '#c81a6a', bare: 'legs', shorts: true,
  tallBoots: true, legs: 1.08, girth: 0.86, corset: true });
LOOKS.whipB = recolor(LOOKS.whipA, { hair: '#f0e8f8', skin: '#b87a54', top: '#5a0a18', inner: '#f03a3a', boots: '#5a0a18', gloves: '#f03a3a', pants: '#5a0a18' });
LOOKS.robot = mkLook({ name: 'robot', head: 'robot', robot: true, skin: '#8a98ac', hair: '#3a404a', acc: '#b8c4d4', top: '#6a7686',
  inner: '#ff8a10', pants: '#56606e', boots: '#2e343c', gloves: '#3a404a', sleeve: 'long', scale: 1.08, girth: 1.18, arms: 1.0, fist: 3.6 });
LOOKS.ruby = mkLook({ name: 'ruby', head: 'bun', fem: true, skin: '#f2bc92', hair: '#f0344a', top: '#e01028', inner: '#f2c94c',
  pants: '#1c1018', boots: '#e01028', gloves: '#1c1018', sleeve: 'none', bare: 'arms', legs: 1.12, girth: 0.84, tallBoots: true,
  leotard: true, scale: 1.04 });
LOOKS.onyx = recolor(LOOKS.ruby, { hair: '#2a1a3a', top: '#6a1ad0', inner: '#c0a8ff', boots: '#6a1ad0', skin: '#c08a66' });
LOOKS.rivet = mkLook({ name: 'rivet', head: 'hardhat', skin: '#e8ac82', hair: '#4a3020', acc: '#f2c020', top: '#ff8a10', inner: '#2a6ad0',
  pants: '#3a4a6a', boots: '#5a3a20', gloves: '#c8a060', sleeve: 'short', scale: 1.1, girth: 1.14, belly: 2, vest: true });
LOOKS.vex = mkLook({ name: 'vex', head: 'bandana', fem: true, skin: '#d09878', hair: '#f2f2f8', lip: '#e0304a', acc: '#e01028',
  top: '#3a2440', inner: '#ff2a4a', pants: '#241828', boots: '#e01028', gloves: '#e01028', belt: '#f2c94c', sleeve: 'none',
  corset: true, bare: 'legs', shorts: true, tallBoots: true, legs: 1.08, girth: 0.88, scale: 1.02, stripe: '#ff2a4a' });
LOOKS.vexCPU = recolor(LOOKS.vex, { inner: '#2ad0f0', acc: '#2ad0f0', hair: '#1c1420' });

LOOKS.tank = mkLook({ name: 'tank', head: 'flattop', pmap: 'tank', skin: '#e8a878', hair: '#c8a020', top: '#e0502a', inner: null,
  sleeve: 'none', pants: '#2a3a72', boots: '#6a3a18', gloves: '#f2e2c0', belt: '#f2c94c', acc: '#e0502a', stripe: '#f2c94c',
  scale: 1.2, girth: 1.24, arms: 0.9, belly: 2.0, fist: 3.3, heavy: true, tank: true, bare: 'arms', torso: 0.98 });
LOOKS.tankCPU = recolor(LOOKS.tank, { top: '#8a2ad0', stripe: '#2ad0f0', pants: '#241a2e', hair: '#f0f0f0' });
LOOKS.jett = mkLook({ name: 'jett', head: 'goggles', pmap: 'jett', skin: '#c07a48', hair: '#2a1a18', acc: '#ff6a10', top: '#18c0d8',
  inner: '#f2f2ea', sleeve: 'elbow', pants: '#3a3f52', boots: '#ff6a10', gloves: '#1a1a24', belt: '#f2c94c',
  stripe: '#f2f2ea', jacket: true, cuffs: true, scale: 0.97, girth: 0.92, legs: 1.06, fist: 2.8 });
LOOKS.jettCPU = recolor(LOOKS.jett, { top: '#3ad06a', acc: '#f2c94c', boots: '#f2c94c', hair: '#4a2a18' });
// ---- stage 4-8 bosses
LOOKS.gauge = mkLook({ name: 'gauge', head: 'bald', skin: '#c88a5a', hair: '#2a1a12', acc: '#f2c020', top: '#3a4a5a', inner: null,
  sleeve: 'none', pants: '#5a4a2a', boots: '#241810', belt: '#a8621a', stripe: '#f2c020', scale: 1.36, girth: 1.26, arms: 0.88,
  belly: 3.0, fist: 3.3, heavy: true, bare: 'arms', tank: true, chain: true });
LOOKS.slag = mkLook({ name: 'slag', head: 'masked', skin: '#b87040', hair: '#1a1418', acc: '#ff6a10', top: '#2a2028', inner: '#ff8a10',
  sleeve: 'none', pants: '#3a2a2a', boots: '#1c1418', belt: '#c8302a', stripe: '#ff6a10', scale: 1.44, girth: 1.3, arms: 0.88,
  belly: 3.4, fist: 3.4, heavy: true, bare: 'arms', vest: true });
LOOKS.warden = mkLook({ name: 'warden', head: 'helm', robot: true, skin: '#8a94a8', hair: '#2e3440', acc: '#c8d2e0', top: '#4a5668',
  inner: '#ff2a4a', pants: '#3a4454', boots: '#20262e', gloves: '#2e3440', metal: '#c0c8d8', sleeve: 'long', scale: 1.32,
  girth: 1.26, arms: 0.94, fist: 3.8, heavy: true });
LOOKS.dray = mkLook({ name: 'dray', head: 'slick', skin: '#e0b48a', hair: '#e8e8f0', top: '#f0ece0', inner: '#8a1a2a', pants: '#f0ece0',
  boots: '#1a1418', gloves: '#1a1418', acc: '#8a1a2a', belt: '#1a1418', sleeve: 'long', vest: true, scale: 1.06, girth: 0.98 });
LOOKS.drayx = mkLook({ name: 'drayx', head: 'helm', skin: '#e0b48a', hair: '#e8e8f0', acc: '#f2c94c', top: '#1a1626', inner: '#c82a4a',
  pants: '#1a1626', boots: '#0e0c14', gloves: '#0e0c14', metal: '#f2c94c', sleeve: 'long', scale: 1.28, girth: 1.2, arms: 0.94,
  fist: 3.4, heavy: true, vest: true, spikes: true });
LOOKS.unit9 = mkLook({ name: 'unit9', head: 'robot', robot: true, skin: '#9aa6b8', hair: '#3a4250', acc: '#d8e0ee', top: '#2a7a9a',
  inner: '#3ae0c0', pants: '#46505e', boots: '#262c34', gloves: '#3a4250', metal: '#c0c8d8', sleeve: 'long', scale: 1.06,
  girth: 1.14, arms: 0.96, fist: 3.4 });
LOOKS.unit9CPU = recolor(LOOKS.unit9, { top: '#9a3a2a', inner: '#ffc040' });
// ---- stage 4-8 enemies
LOOKS.suitA = mkLook({ name: 'suitA', head: 'slick', skin: '#d09a70', hair: '#1c1418', top: '#2a2a3a', inner: '#f2f2ea',
  pants: '#2a2a3a', boots: '#16141a', acc: '#c82a4a', sleeve: 'long', vest: true });
LOOKS.suitB = recolor(LOOKS.suitA, { top: '#4a3a5a', inner: '#f2c94c', skin: '#9a6242', hair: '#f0e8d8', pants: '#4a3a5a' });
LOOKS.guardA = mkLook({ name: 'guardA', head: 'helm', skin: '#c88a5a', hair: '#2a2028', acc: '#5a6472', top: '#2a3a52', inner: '#2ad0f0',
  pants: '#26303e', boots: '#181c22', gloves: '#181c22', sleeve: 'long', stripe: '#2ad0f0', girth: 1.08, scale: 1.05 });
LOOKS.guardB = recolor(LOOKS.guardA, { top: '#52304a', stripe: '#ff6a10', inner: '#ff6a10', acc: '#6a5a62' });
LOOKS.bikerA = mkLook({ name: 'bikerA', head: 'goggles', skin: '#b87a54', hair: '#1a1418', acc: '#e8e8f0', top: '#c8202a',
  inner: '#1a1418', pants: '#1c1c24', boots: '#3a2a1a', sleeve: 'long', gloves: '#1a1418', vest: true, stripe: '#e8e8f0' });
LOOKS.bikerB = recolor(LOOKS.bikerA, { top: '#2a6ad0', hair: '#d8a020', acc: '#f2c020', skin: '#e8b88a' });
LOOKS.robotB = recolor(LOOKS.robot, { top: '#8a5a3a', inner: '#3ae0c0', acc: '#d8c0a0', pants: '#6a4a30' });


// ------------------------------------------------------------ per-character builds
// Each fighter is authored rather than inheriting an archetype from his girth.
// [build, face, build overrides, face overrides]
//   build  limb thickness profile, torso silhouette, shoulder width
//   face   skull and jaw shape
// Overrides are the places a character needs to differ from his archetype:
// Jett is wiry but broad-shouldered, Vex is lean with a fighter's shoulders,
// Rivet is a working heavy rather than a brawler.
const CAST_BUILD = {
  // ---- playable
  cole: ['heroic', 'square', { sh: 10.1, chest: 8.7, waist: 4.8 }],
  anita: ['lean', 'fine', { sh: 7.6, leg: [7.5, 4.9, 3.4], swell: 0.68 }],
  tank: ['blocky', 'box', { sh: 11.8, chest: 10.4, trap: 1.5, arm: [7.8, 5.5, 3.3], neck: 5.6 }],
  jett: ['wiry', 'long', { sh: 9.2, chest: 7.4, waist: 3.9, leg: [7.3, 4.7, 3.3], swell: 0.78 }],
  vex: ['lean', 'fine', { sh: 7.8, chest: 6.9, waist: 3.8, swell: 0.72, foot: 5.7 }],
  unit9: ['robot', 'box', { sh: 10.0, arm: [6.5, 4.8, 3.4] }],
  // ---- street
  punkA: ['wiry', 'long', { sh: 9.1, swell: 0.80 }],
  punkB: ['heroic', 'round', { sh: 9.4, chest: 8.0, swell: 0.85 }],
  punkC: ['wiry', 'square', { sh: 9.0 }],
  bladeA: ['wiry', 'long', { arm: [5.5, 3.9, 2.4], leg: [7.4, 4.8, 3.3] }],
  bladeB: ['lean', 'fine', { sh: 7.4, swell: 0.66 }],
  bruiserA: ['blocky', 'heavy', { waist: 8.2, swell: 1.4 }],
  bruiserB: ['blocky', 'heavy', { waist: 8.2, swell: 1.4 }],
  kickerA: ['lean', 'fine', { leg: [7.8, 5.1, 3.5], swell: 0.72, hip: 6.6 }],
  kickerB: ['wiry', 'square', { leg: [7.6, 5.0, 3.5], sh: 9.0 }],
  whipA: ['lean', 'fine', { sh: 7.0, waist: 3.8 }],
  whipB: ['lean', 'fine', { sh: 7.0, waist: 3.8 }],
  suitA: ['suit', 'long', { sh: 9.2 }],
  suitB: ['suit', 'round', { sh: 9.2 }],
  guardA: ['suit', 'square', { sh: 9.8, chest: 8.6, arm: [6.4, 4.9, 3.2], swell: 0.5 }],
  guardB: ['suit', 'square', { sh: 9.8, chest: 8.6, arm: [6.4, 4.9, 3.2], swell: 0.5 }],
  bikerA: ['heroic', 'square', { sh: 10.0, waist: 5.4, swell: 0.9 }],
  bikerB: ['heroic', 'round', { sh: 10.0, waist: 5.4, swell: 0.9 }],
  robot: ['robot', 'box', {}],
  robotB: ['robot', 'box', {}],
  dummy: ['box', 'box', { swell: 0 }],
  // ---- bosses
  brick: ['blocky', 'heavy', { sh: 11.6, chest: 10.6, waist: 8.4, arm: [7.8, 5.6, 3.4], trap: 1.5, neck: 5.6, swell: 1.4 }],
  ruby: ['lean', 'fine', { sh: 7.6, waist: 3.8, leg: [7.6, 5.0, 3.4] }],
  onyx: ['lean', 'fine', { sh: 7.6, waist: 3.8, leg: [7.6, 5.0, 3.4] }],
  rivet: ['blocky', 'square', { sh: 10.6, chest: 9.4, waist: 7.2, swell: 1.0, trap: 1.1 }],
  gauge: ['blocky', 'heavy', { sh: 11.4, waist: 8.6, swell: 1.35, trap: 1.4 }],
  slag: ['blocky', 'box', { sh: 12.0, chest: 10.8, waist: 8.8, arm: [8.2, 5.8, 3.4], trap: 1.5, neck: 5.8 }],
  warden: ['robot', 'box', { sh: 11.0, chest: 9.8, arm: [7.2, 5.3, 3.8], trap: 1.2 }],
  dray: ['suit', 'long', { sh: 9.0, waist: 6.6, swell: 0.2 }],
  drayx: ['suit', 'long', { sh: 10.6, chest: 9.2, waist: 7.2, arm: [6.8, 5.1, 3.2], swell: 0.6, trap: 1.1 }],
};

// ------------------------------------------------------------ painting helpers (discrete colours only)
function col(look, mat, tone) { const r = look.P[mat] || look.P.top; return r[clamp(tone, 0, 3)]; }
function segLine(g, a, b, w, c) { g.strokeStyle = c; g.lineWidth = w; g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); }
function disc(g, p, r, c) { g.fillStyle = c; g.beginPath(); g.arc(p[0], p[1], Math.max(0.5, r), 0, Math.PI * 2); g.fill(); }
const LIGHT = [-0.55, -0.83];
function perpLight(a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1;
  let nx = -dy / l, ny = dx / l;
  if (nx * LIGHT[0] + ny * LIGHT[1] < 0) { nx = -nx; ny = -ny; }
  return [nx, ny];
}
// a shaded limb segment
function seg3(g, look, a, b, w, mat, back) {
  const t0 = back ? 1 : 0;
  const n = perpLight(a, b);
  segLine(g, a, b, w, col(look, mat, t0 + 2));
  const o1 = w * 0.15, o2 = w * 0.3;
  segLine(g, [a[0] + n[0] * o1, a[1] + n[1] * o1], [b[0] + n[0] * o1, b[1] + n[1] * o1], w * 0.6, col(look, mat, t0 + 1));
  if (w >= 4) segLine(g, [a[0] + n[0] * o2, a[1] + n[1] * o2], [b[0] + n[0] * o2, b[1] + n[1] * o2], Math.max(1, w * 0.2), col(look, mat, t0));
}
function ball(g, look, p, r, mat, back) {
  const t0 = back ? 1 : 0;
  disc(g, p, r, col(look, mat, t0 + 2));
  disc(g, [p[0] - r * 0.14, p[1] - r * 0.18], r * 0.72, col(look, mat, t0 + 1));
  if (r > 2.5) disc(g, [p[0] - r * 0.35, p[1] - r * 0.4], r * 0.28, col(look, mat, t0));
}
const lp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
const add2 = (a, n, k) => [a[0] + n[0] * k, a[1] + n[1] * k];
function poly(g, pts, c) { g.fillStyle = c; g.beginPath(); g.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]); g.closePath(); g.fill(); }

// ------------------------------------------------------------ character builds
// Every fighter is constructed from his own numbers instead of one shared doll.
// Widths are rig units, applied before the character's own scale.
//   sh/chest/rib/waist/hip   torso silhouette control widths
//   arm [shoulder, elbow, wrist]      leg [hip, knee, ankle]
//   swell  how far a muscle belly bows out of the taper (0 = mechanical)
//   foot   boot length      trap  trapezius slope into the neck
//   neck   neck column width
const BUILDS = {
  // the default heroic comic build: wide shoulders, deep chest, tapered waist,
  // big hands and boots.
  heroic: { sh: 9.8, chest: 8.5, rib: 7.4, waist: 4.9, hip: 6.1,
    arm: [6.2, 4.4, 2.7], leg: [8.4, 5.5, 3.9], swell: 1.00, foot: 6.4, trap: 1.00, neck: 4.6 },
  // heavies: depth instead of taper, short thick neck, slab shoulders
  blocky: { sh: 11.2, chest: 10.0, rib: 9.3, waist: 7.5, hip: 7.4,
    arm: [7.4, 5.3, 3.2], leg: [9.6, 6.4, 4.5], swell: 1.30, foot: 7.3, trap: 1.35, neck: 5.2 },
  // speed types: narrow ribcage, long light limbs, sharp waist
  wiry: { sh: 8.9, chest: 7.2, rib: 6.1, waist: 4.1, hip: 5.4,
    arm: [5.3, 3.8, 2.4], leg: [7.2, 4.7, 3.4], swell: 0.70, foot: 6.1, trap: 0.78, neck: 4.2 },
  // women: narrower shoulders, a real waist, wider pelvis
  lean: { sh: 7.2, chest: 6.7, rib: 5.8, waist: 4.0, hip: 6.9,
    arm: [5.0, 3.7, 2.3], leg: [7.3, 4.8, 3.4], swell: 0.60, foot: 5.5, trap: 0.68, neck: 3.7 },
  // tailoring rather than muscle: straight sides, padded shoulders
  suit: { sh: 9.4, chest: 8.2, rib: 7.8, waist: 7.0, hip: 6.6,
    arm: [6.0, 4.7, 3.0], leg: [7.9, 5.7, 4.1], swell: 0.22, foot: 6.2, trap: 0.90, neck: 4.4 },
  // machines: no bellies, hard joints, boxy chest
  robot: { sh: 10.4, chest: 9.2, rib: 8.8, waist: 7.4, hip: 7.0,
    arm: [6.8, 5.0, 3.6], leg: [9.2, 6.1, 4.6], swell: 0, foot: 7.2, trap: 1.10, neck: 5.0 },
};
function buildOf(look) {
  if (look._bd) return look._bd;
  const name = look.build || (look.robot ? 'robot' : look.fem ? 'lean'
    : (look.girth || 1) > 1.12 ? 'blocky' : 'heroic');
  const base = BUILDS[name] || BUILDS.heroic;
  const b = Object.assign({}, base);
  b.arm = base.arm.slice(); b.leg = base.leg.slice();
  if (look.bld) for (const k in look.bld) { const v = look.bld[k]; b[k] = Array.isArray(v) ? v.slice() : v; }
  look._bd = b;
  return b;
}
// 'box' is a build as well as a face for the training dummy
BUILDS.box = { sh: 9.0, chest: 8.4, rib: 8.2, waist: 7.8, hip: 7.6,
  arm: [6.4, 5.6, 4.6], leg: [8.2, 6.6, 5.2], swell: 0, foot: 6.0, trap: 0.8, neck: 4.6 };
for (const k in LOOKS) {
  const e = CAST_BUILD[k] || CAST_BUILD[k.replace(/(CPU|[AB])$/, '')];
  if (!e) continue;
  const [b, f, ov, fov] = e;
  const L = LOOKS[k];
  L.build = b; if (f) L.face = f;
  if (ov) L.bld = ov;
  if (fov) L.fc = fov;
  L._bd = null; L._fc = null;
}
// girth still widens a fighter, but the build already carries most of the bulk,
// so it only nudges from here.
const girthK = look => 1 + ((look.girth || 1) - 1) * 0.35;

// ------------------------------------------------------------ shape helpers
const nrm = (a, b) => { const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1; return [dx / l, dy / l]; };
const perp = d => [-d[1], d[0]];
// a limb that TAPERS from w0 to w1 with a muscle belly, not a uniform tube
function taper(g, look, a, b, w0, w1, mat, back, bulge = 0) {
  const d = nrm(a, b);
  let n = perp(d);
  if (n[0] * LIGHT[0] + n[1] * LIGHT[1] < 0) n = [-n[0], -n[1]];
  const t0 = back ? 1 : 0;
  const m = lp(a, b, 0.42), wm = (w0 + w1) / 2 + bulge;
  // n points at the light. The limb is BASE tone all over, with a shadow band
  // hugging the far edge and a highlight strip inside the lit edge - the whole
  // form lit, rather than a shade-coloured limb with one lit half.
  const at = (p, w, f) => add2(p, n, w * f);
  poly(g, [at(a, w0, 0.5), at(m, wm, 0.5), at(b, w1, 0.5),
    at(b, w1, -0.5), at(m, wm, -0.5), at(a, w0, -0.5)], col(look, mat, t0 + 1));
  poly(g, [at(a, w0, -0.5), at(m, wm, -0.5), at(b, w1, -0.5),
    at(b, w1, -0.16), at(m, wm, -0.12), at(a, w0, -0.14)], col(look, mat, t0 + 2));
  if (Math.min(w0, w1) > 2.6)
    segLine(g, at(a, w0, 0.34), at(b, w1, 0.32), Math.max(1, Math.min(w0, w1) * 0.2), col(look, mat, t0));
}
// A hard contour under a limb that passes in front of the body. Without it a
// blue sleeve over a blue torso is one flat shape.
function inkLimb(g, pts, endR) {
  const pad = 2.0;                       // total, so 1 px of rim on each side
  // Walk one side and back up the other: a single polygon, so there are no
  // round caps spilling onto the torso at the shoulder.
  const A = [], B = [];
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i][0];
    const d = i < pts.length - 1 ? nrm(p, pts[i + 1][0]) : nrm(pts[i - 1][0], p);
    const n = perp(d), w = pts[i][1] / 2 + pad / 2;
    A.push(add2(p, n, w)); B.unshift(add2(p, n, -w));
    if (i > 0 && i < pts.length - 1) disc(g, p, w, OUTLINE);   // round the bend
  }
  poly(g, A.concat(B), OUTLINE);
  if (endR) disc(g, pts[pts.length - 1][0], endR + pad / 2, OUTLINE);
}
// rounded joint so two segments read as one limb
function joint(g, look, p, r, mat, back) {
  const t0 = back ? 1 : 0;
  disc(g, p, r, col(look, mat, t0 + 1));
  disc(g, add2(p, LIGHT, -r * 0.30), r * 0.74, col(look, mat, t0 + 2));
  disc(g, add2(p, LIGHT, r * 0.34), r * 0.36, col(look, mat, t0 + 1));
}
// hand: a closed fist - roughly as long as it is wide, with a knuckle ridge on
// the far face and the thumb folded across. Big, but still a fist.
function hand2(g, look, A, r, mat, back) {
  const d = nrm(A.el, A.hd);
  let n = perp(d);
  if (n[0] * LIGHT[0] + n[1] * LIGHT[1] < 0) n = [-n[0], -n[1]];
  const t0 = back ? 1 : 0;
  const c = add2(A.hd, d, r * 0.16);
  const tip = add2(c, d, r * 0.74), root = add2(c, d, -r * 0.76);
  const w = r * 0.62;                       // half-width of the fist
  poly(g, [add2(root, n, w * 0.92), add2(add2(root, d, r * 0.18), n, w),
    add2(add2(tip, d, -r * 0.16), n, w * 0.94), add2(tip, n, w * 0.60),
    add2(tip, n, -w * 0.62), add2(add2(tip, d, -r * 0.16), n, -w * 0.96),
    add2(add2(root, d, r * 0.18), n, -w), add2(root, n, -w * 0.88)], col(look, mat, t0 + 2));
  poly(g, [add2(root, n, w * 0.92), add2(add2(root, d, r * 0.18), n, w),
    add2(add2(tip, d, -r * 0.16), n, w * 0.94), add2(tip, n, w * 0.60),
    add2(tip, n, w * 0.02), add2(root, n, w * 0.06)], col(look, mat, t0 + 1));
  // knuckle ridge
  segLine(g, add2(add2(tip, d, -r * 0.10), n, w * 0.52), add2(add2(tip, d, -r * 0.10), n, -w * 0.52), Math.max(0.8, r * 0.16), col(look, mat, t0 + 2));
  // thumb folded across the shadow side
  segLine(g, add2(add2(c, d, -r * 0.30), n, -w * 0.72), add2(add2(c, d, r * 0.26), n, -w * 0.52), Math.max(0.9, r * 0.3), col(look, mat, t0 + 1));
}
// boot: a wedge with a sole, not a stroke
function boot2(g, look, an, ft, w, back, heel) {
  const d = nrm(an, ft);
  let n = perp(d);
  if (n[0] * LIGHT[0] + n[1] * LIGHT[1] < 0) n = [-n[0], -n[1]];
  const t0 = back ? 1 : 0;
  const bk = add2(an, d, -w * 0.42), toe = add2(ft, d, w * 0.1);
  poly(g, [add2(bk, n, w * 0.60), add2(toe, n, w * 0.30), add2(toe, n, -w * 0.34), add2(bk, n, -w * 0.52)], col(look, 'boots', t0 + 2));
  poly(g, [add2(bk, n, w * 0.60), add2(toe, n, w * 0.30), add2(toe, n, w * 0.02), add2(bk, n, w * 0.10)], col(look, 'boots', t0 + 1));
  segLine(g, add2(bk, n, -w * 0.44), add2(toe, n, -w * 0.30), Math.max(1, w * 0.2), col(look, 'boots', 3));
  if (heel) segLine(g, add2(bk, n, -w * 0.2), add2(bk, n, -w * 0.5), Math.max(1, w * 0.22), col(look, 'boots', 3));
}

// ------------------------------------------------------------ arm
function paintArm(g, look, A, back, s) {
  const B = buildOf(look), ar = look.arms || 1, k = s * girthK(look) * ar;
  const wSh = B.arm[0] * k, wEl = B.arm[1] * k, wWr = B.arm[2] * k;
  const sw = B.swell * k;
  const sl = look.sleeve || 'short';
  const upMat = sl === 'none' ? 'skin' : 'top';
  const loMat = sl === 'long' ? 'top' : 'skin';
  const t0 = back ? 1 : 0;
  const fist = (look.fist || 3.0) * Math.pow(s, 0.72) * ar * 1.34;
  // A sleeve sits over the upper arm and is wider than the arm itself; the
  // contour below has to clear it or it gets painted out.
  const cuffW = sl === 'short' ? 1.0 * k : (sl === 'elbow' && look.cuffs) ? 1.1 * k : 0;
  // The front arm crosses the torso in the same material, so lay a hard contour
  // under it first: OUTLINE is a detail colour, so it survives the downsample
  // and becomes the line that makes the arm read as a separate limb.
  if (!back) inkLimb(g, [[lp(A.sh, A.el, 0.14), wSh + cuffW], [A.el, wEl + cuffW * 0.9], [A.hd, wWr]], fist * 0.76);
  taper(g, look, A.sh, A.el, wSh, wEl, upMat, back, sw * 1.3);        // biceps belly
  joint(g, look, A.el, wEl * 0.46, loMat, back);
  taper(g, look, A.el, A.hd, wEl * 0.86, wWr, loMat, back, sw * 0.9); // forearm belly
  if (look.gloves && loMat === 'skin') {
    // the glove is a cuff at the wrist, not the whole forearm
    taper(g, look, lp(A.el, A.hd, 0.78), A.hd, wWr * 1.16, wWr * 1.04, 'gloves', back, 0);
  }
  if (sl === 'short') {
    const cuff = lp(A.sh, A.el, 0.46);
    taper(g, look, A.sh, cuff, wSh + 0.9 * k, wEl + 1.0 * k, 'top', back, 0);
    const n = perp(nrm(A.sh, A.el));
    segLine(g, add2(cuff, n, wEl * 0.6), add2(cuff, n, -wEl * 0.6), 1, col(look, 'top', t0 + 2));
  } else if (sl === 'elbow' && look.cuffs) {
    taper(g, look, lp(A.sh, A.el, 0.55), lp(A.sh, A.el, 0.92), wSh * 0.96 + 0.9 * k, wEl + 1.1 * k, 'top', back, 0);
  }
  if (back) joint(g, look, A.sh, wSh * 0.52, sl === 'none' ? 'skin' : 'top', back);   // deltoid cap
  if (look.robot) disc(g, A.el, wEl * 0.5, col(look, 'hair', back ? 3 : 2));
  // wrist break: without it a dark glove and a dark sleeve are one shape
  segLine(g, add2(A.hd, nrm(A.el, A.hd), -fist * 0.62), add2(A.hd, nrm(A.el, A.hd), -fist * 0.50),
    wWr * 1.15, look.ink[look.gloves ? 'gloves' : 'skin'] || OUTLINE);
  hand2(g, look, A, fist, look.gloves ? 'gloves' : 'skin', back);
}
// ------------------------------------------------------------ leg
function paintLeg(g, look, Lg, back, s) {
  const B = buildOf(look), k = s * girthK(look);
  const wHip = B.leg[0] * k, wKn = B.leg[1] * k, wAn = B.leg[2] * k;
  const sw = B.swell * k;
  const bare = look.bare === 'legs' || look.shorts;
  const mat = bare ? 'skin' : 'pants';
  taper(g, look, Lg.hp, Lg.kn, wHip, wKn, mat, back, sw * 1.5);       // quad belly
  if (look.shorts) taper(g, look, Lg.hp, lp(Lg.hp, Lg.kn, 0.38), wHip + 1.1 * k, wKn + 1.5 * k, 'pants', back, 0);
  joint(g, look, Lg.kn, wKn * 0.5, mat, back);
  taper(g, look, Lg.kn, Lg.an, wKn * 0.96, wAn, mat, back, sw * 1.6); // calf, belly high on the shin
  const bootTop = look.tallBoots ? 0.06 : 0.62;
  taper(g, look, lp(Lg.kn, Lg.an, bootTop), Lg.an,
    (look.tallBoots ? wKn * 0.98 : wAn * 1.35) + 0.7 * k, wAn + 0.8 * k, 'boots', back, 0);
  if (look.tallBoots) segLine(g, lp(Lg.kn, Lg.an, 0.04), lp(Lg.kn, Lg.an, 0.14), wKn + 1.4 * k, col(look, 'boots', back ? 1 : 0));
  boot2(g, look, Lg.an, Lg.ft, B.foot * k, back, !look.robot);
  if (look.robot) disc(g, Lg.kn, wKn * 0.55, col(look, 'hair', back ? 3 : 2));
}
// ------------------------------------------------------------ torso
// pelvis -> waist pinch -> ribcage flare -> deltoids -> trapezius slope
function paintTorso(g, look, J, s) {
  const B = buildOf(look), fem = look.fem;
  const hip = J.hip, sh = J.sh, u = J.up, n = [-u[1], u[0]];
  const Lt = Math.hypot(sh[0] - hip[0], sh[1] - hip[1]);
  const P = (t, k) => [hip[0] + u[0] * Lt * t + n[0] * k, hip[1] + u[1] * Lt * t + n[1] * k];
  const g0 = s * girthK(look);
  const belly = (look.belly || 0) * s * 0.42;
  const hipW = B.hip * g0, waistW = B.waist * g0 + belly;
  const ribW = B.rib * g0 + belly * 0.7, chestW = B.chest * g0, shW = B.sh * g0;
  const front = [P(-0.04, hipW * 0.86), P(0.10, hipW), P(0.30, waistW * 1.06), P(0.44, waistW),
    P(0.62, ribW), P(0.80, chestW), P(0.94, shW * 0.92), P(1.03, shW * 0.72), P(1.10, shW * 0.34)];
  const rear = [P(1.10, -shW * 0.36), P(1.03, -shW * 0.76), P(0.94, -shW * 0.96), P(0.78, -chestW * 0.96),
    P(0.60, -ribW * 0.98), P(0.44, -waistW * 1.02), P(0.30, -waistW * 1.1), P(0.10, -hipW * 0.98), P(-0.04, -hipW * 0.84)];
  const outline = front.concat(rear);
  const mat = look.bare === 'chest' ? 'skin' : 'top';
  poly(g, outline, col(look, mat, 1));
  // The key light comes over the back shoulder, so the shadow is a band down
  // the front of the body and the highlight a rim along the back.
  const F = 0.34;   // how far the shadow reaches back from the front edge
  poly(g, front.concat([P(1.06, shW * F * 0.5), P(0.88, chestW * F), P(0.68, ribW * F),
    P(0.48, waistW * F), P(0.28, waistW * F), P(0.08, hipW * F)]), col(look, mat, 2));
  segLine(g, P(0.30, -waistW * 0.86), P(0.62, -ribW * 0.84), 1.1, col(look, mat, 0));
  segLine(g, P(0.80, -chestW * 0.84), P(1.02, -shW * 0.72), 1.3, col(look, mat, 0));
  // anatomy
  if (!fem) {
    segLine(g, P(0.86, chestW * 0.12), P(0.86, -chestW * 0.12), 1.1 * g0, col(look, mat, 2));   // sternum
    segLine(g, P(0.80, chestW * 0.82), P(0.90, chestW * 0.2), 1, col(look, mat, 2));            // pec
    if (B.swell > 0.5) for (let i = 0; i < 2; i++)
      segLine(g, P(0.52 - i * 0.14, waistW * 0.55), P(0.52 - i * 0.14, -waistW * 0.55), 0.9, col(look, mat, 2));
  } else {
    segLine(g, P(0.78, chestW * 0.86), P(0.86, chestW * 0.2), 1, col(look, mat, 2));
    disc(g, P(0.80, chestW * 0.52), 1.5 * g0, col(look, mat, 1));
  }
  segLine(g, P(0.92, -chestW * 0.5), P(0.62, -ribW * 0.9), 1, col(look, mat, 2));               // lat
  poly(g, [P(1.00, shW * 0.58), P(1.06 + 0.07 * B.trap, shW * 0.20), P(1.06 + 0.07 * B.trap, -shW * 0.22), P(1.00, -shW * 0.62)], col(look, mat, 1));
  // ---- clothing layers on the new silhouette
  if (look.tank) {
    poly(g, [P(1.04, shW * 0.9), P(1.14, shW * 0.3), P(0.96, shW * 0.42), P(0.90, shW * 0.86)], col(look, 'skin', 1));
    poly(g, [P(1.04, -shW * 0.92), P(1.14, -shW * 0.32), P(0.96, -shW * 0.46), P(0.90, -shW * 0.9)], col(look, 'skin', 2));
  }
  if (look.crop) {
    poly(g, [P(0.04, hipW * 0.98), P(0.30, waistW * 1.06), P(0.46, waistW), P(0.46, -waistW), P(0.30, -waistW * 1.1), P(0.04, -hipW * 0.96)], col(look, 'skin', 1));
    segLine(g, P(0.24, waistW * 0.5), P(0.38, waistW * 0.5), 0.8, col(look, 'skin', 2));
  }
  if (look.jacket && look.inner) {
    const lo = look.crop ? 0.46 : 0.06;
    const pan = [P(lo, waistW * 0.80), P(0.66, ribW * 0.78), P(0.88, chestW * 0.70), P(1.03, shW * 0.34), P(1.03, shW * 0.02), P(lo, waistW * 0.16)];
    poly(g, pan, col(look, 'inner', 2));
    poly(g, pan.map(p => [p[0] - 0.5, p[1] - 0.6]), col(look, 'inner', 1));
    segLine(g, P(1.02, shW * 0.46), P(0.66, chestW * 0.96), 1.3, col(look, 'top', 0));
  } else if (look.vest && look.inner) {
    poly(g, [P(0.08, waistW * 0.9), P(0.80, chestW * 0.86), P(1.02, shW * 0.36), P(0.08, waistW * 0.2)], col(look, 'inner', 1));
  } else if (look.corset || look.leotard) {
    poly(g, [P(0.18, waistW * 0.92), P(0.74, chestW * 0.9), P(0.74, chestW * 0.26), P(0.18, waistW * 0.26)], col(look, 'inner', 1));
    for (let k = 0; k < 3; k++) segLine(g, P(0.3 + k * 0.14, waistW * 0.32), P(0.3 + k * 0.14, waistW * 0.82), 0.8, col(look, 'inner', 3));
  }
  if (look.stripe) segLine(g, P(0.56, -chestW * 0.92), P(0.56, chestW * 0.92), 2.1 * g0, col(look, 'stripe', 1));
  if (look.chain) {
    g.strokeStyle = FLAT.gold; g.lineWidth = 1.1;
    g.beginPath(); g.moveTo(...P(1.0, chestW * 0.6)); g.quadraticCurveTo(...P(0.72, chestW * 0.74), ...P(0.76, chestW * 0.06)); g.stroke();
  }
  if (look.robot) {
    poly(g, [P(0.5, waistW * 0.9), P(0.86, chestW * 0.8), P(0.86, chestW * 0.1), P(0.5, waistW * 0.1)], col(look, 'inner', 1));
    disc(g, P(0.70, chestW * 0.46), 1.4 * g0, FLAT.glow);
  }
  // belt sits on the pelvis and follows the hip line
  const bm = look.P.belt ? 'belt' : 'acc';
  poly(g, [P(0.05, hipW * 0.93), P(0.14, hipW * 0.97), P(0.14, -hipW * 0.95), P(0.05, -hipW * 0.89)], col(look, bm, 1));
  segLine(g, P(0.14, hipW * 0.95), P(0.14, -hipW * 0.93), 0.8, col(look, bm, 2));
  if (!fem) disc(g, P(0.095, hipW * 0.42), 1.3, FLAT.gold);
  if (look.spikes) for (let k = 0; k < 3; k++) disc(g, P(1.06, -shW * (0.84 - k * 0.28)), 0.9, look.P.metal[0]);
}
function paintSkirt(g, look, J, s) {
  const gr = look.girth || 1;
  const u = J.up, n = [-u[1], u[0]];
  const hw = 7 * s * gr;
  const a = [J.hip[0] + u[0] * 2 + n[0] * hw, J.hip[1] + u[1] * 2 + n[1] * hw];
  const b = [J.hip[0] + u[0] * 2 - n[0] * hw, J.hip[1] + u[1] * 2 - n[1] * hw];
  const k1 = lp(J.l2.hp, J.l2.kn, 0.42), k2 = lp(J.l1.hp, J.l1.kn, 0.42);
  const spread = 2.4 * s;
  const d1 = perpLight(J.l2.hp, J.l2.kn), d2 = perpLight(J.l1.hp, J.l1.kn);
  const pts = [b, a, add2(k1, d1, -spread), add2(k1, d1, spread), add2(k2, d2, spread), add2(k2, d2, -spread)];
  poly(g, pts, col(look, 'acc', 2));
  poly(g, [a, b, lp(b, k2, 0.7), lp(a, k1, 0.7)], col(look, 'acc', 1));
  segLine(g, lp(a, k1, 0.3), lp(b, k2, 0.3), 1, col(look, 'acc', 0));
  segLine(g, a, b, 1.6, col(look, 'belt', 1));
}
function paintStamp(g, look, name, cx, cy, sc) {
  const rows = STAMPS[name] || STAMPS.clean;
  for (let y = 0; y < rows.length; y++) {
    const r = rows[y];
    for (let x = 0; x < r.length; x++) {
      const ch = r[x];
      if (ch === '.') continue;
      let c;
      if (STAMP_KEYS[ch]) { const [m, t] = STAMP_KEYS[ch]; c = col(look, m, t); }
      else if (ch === 'w') c = FLAT.eyeW;
      else if (ch === 'p') c = FLAT.pupil;
      else if (ch === 'm') c = look.lip;
      else if (ch === 'e') c = FLAT.glow;
      else if (ch === 'g') c = FLAT.gold;
      else if (ch === 'k') c = OUTLINE;
      else continue;
      g.fillStyle = c;
      g.fillRect(cx + (x - 6) * sc, cy + (y - 7) * sc, sc + 0.02, sc + 0.02);
    }
  }
}
// ------------------------------------------------------------ constructed head
// At 426x240 a head was 13 px and a hand-pixeled stamp beat anything procedural.
// At 854x480 it is ~27 px, which is enough room to build a skull: cranium, brow,
// cheekbone, jaw and chin, each shaped per character, with the hair as a mass
// that has its own silhouette.
const FACES = {
  // cran  cranium width      jaw   jaw width at the cheekbone
  // chin  chin width         tall  skull height       brow  brow ridge weight
  // nose  nose projection    hood  heavy brow/eye shadow
  square: { cran: 0.92, jaw: 0.90, chin: 0.52, tall: 0.96, brow: 1.15, nose: 1.00 },
  round: { cran: 0.95, jaw: 0.80, chin: 0.46, tall: 0.90, brow: 0.90, nose: 0.92 },
  long: { cran: 0.84, jaw: 0.76, chin: 0.44, tall: 1.06, brow: 1.00, nose: 1.08 },
  heavy: { cran: 0.98, jaw: 1.00, chin: 0.62, tall: 0.92, brow: 1.35, nose: 1.05, hood: 1 },
  fine: { cran: 0.86, jaw: 0.70, chin: 0.38, tall: 0.94, brow: 0.70, nose: 0.86 },
  box: { cran: 1.00, jaw: 0.98, chin: 0.74, tall: 0.94, brow: 1.10, nose: 0.80 },
};
// which head style implies which skull, unless the look overrides it
const HEAD_FACE = { anita: 'fine', bob: 'fine', pony: 'fine', bun: 'fine', bandana: 'fine',
  bald: 'heavy', shades: 'heavy', flattop: 'box', hardhat: 'square', helm: 'box',
  robot: 'box', masked: 'box', dummy: 'box', mohawk: 'long', spiky: 'long', slick: 'long' };
function faceOf(look) {
  if (look._fc) return look._fc;
  const base = FACES[look.face || HEAD_FACE[look.head] || (look.fem ? 'fine' : (look.girth || 1) > 1.14 ? 'heavy' : 'square')] || FACES.square;
  const f = Object.assign({}, base);
  if (look.fc) Object.assign(f, look.fc);
  look._fc = f;
  return f;
}
// hair and headgear: each one is a mass with a silhouette, drawn over the skull
function paintHair(g, look, r, F) {
  const H = look.head || 'clean';
  const HA = 'hair', A = 'acc';
  // cap(width, height, centreY): an ellipse of hair over the cranium. It has to
  // stop above the brow - a cap that reaches the eyes turns the face into a blob.
  const cap = (ex, ey, cy, mat, tone) => {
    g.fillStyle = col(look, mat, tone);
    g.beginPath(); g.ellipse(-r * 0.06, -r * cy, r * F.cran * ex, r * F.tall * ey, 0, 0, 7); g.fill();
  };
  const back = (w, dn, mat) => poly(g, [[-r * F.cran * 0.92, -r * 0.44], [-r * F.cran * (0.92 + w), r * dn],
    [-r * (0.30 + w * 0.5), r * (dn + 0.12)], [-r * 0.40, -r * 0.30]], col(look, mat, 2));
  if (H === 'hardhat') {
    // a hat, not a mask: the brim rides above the brow and the face stays
    cap(1.02, 0.52, 1.00, A, 1);
    cap(0.74, 0.34, 1.12, A, 0);
    poly(g, [[-r * 1.02, -r * 0.54], [r * 1.30, -r * 0.62], [r * 1.26, -r * 0.40], [-r * 0.98, -r * 0.30]], col(look, A, 2));
    return 1;
  }
  if (H === 'robot') {
    // a machine: the whole head is shell, with a jaw plate and a visor band
    const m = 'metal';
    g.fillStyle = col(look, m, 1);
    g.beginPath(); g.ellipse(0, -r * 0.24, r * F.cran * 1.04, r * F.tall * 1.00, 0, 0, 7); g.fill();
    poly(g, [[-r * 0.62, r * 0.14], [r * 0.90, r * 0.02], [r * 0.80, r * 0.56], [-r * 0.22, r * 0.74], [-r * 0.60, r * 0.48]], col(look, m, 2));
    segLine(g, [-r * 0.30, r * 0.44], [r * 0.74, r * 0.28], r * 0.12, col(look, m, 3));
    g.fillStyle = col(look, m, 0);
    g.beginPath(); g.ellipse(-r * 0.26, -r * 0.94, r * 0.42, r * 0.18, 0, 0, 7); g.fill();
    poly(g, [[r * 0.00, -r * 0.44], [r * 0.96, -r * 0.30], [r * 0.90, r * 0.06], [-r * 0.02, -r * 0.04]], OUTLINE);
    poly(g, [[r * 0.10, -r * 0.34], [r * 0.86, -r * 0.22], [r * 0.80, -r * 0.02], [r * 0.10, -r * 0.12]], FLAT.glow);
    segLine(g, [r * 0.16, -r * 0.28], [r * 0.74, -r * 0.17], r * 0.08, '#fff4ff');
    return 1;
  }
  if (H === 'helm') {
    // a helmet, not a bucket: brow guard, cheek plate, jaw and mouth left bare
    const m = 'metal';
    poly(g, [[-r * F.cran * 1.04, -r * 0.30], [-r * 0.84, -r * F.tall * 0.94], [r * 0.22, -r * F.tall * 1.18],
      [r * F.cran * 1.00, -r * 0.62], [r * F.cran * 1.02, -r * 0.14], [r * 0.52, -r * 0.30],
      [r * 0.10, -r * 0.40], [-r * 0.60, -r * 0.24]], col(look, m, 1));
    poly(g, [[-r * 0.70, -r * 0.74], [r * 0.16, -r * F.tall * 1.10], [r * 0.90, -r * 0.60],
      [r * 0.20, -r * 0.84], [-r * 0.40, -r * 0.66]], col(look, m, 0));
    // cheek guard down the side of the face
    poly(g, [[r * 0.60, -r * 0.30], [r * F.cran * 1.02, -r * 0.16], [r * 0.94, r * 0.34], [r * 0.58, r * 0.22]], col(look, m, 2));
    // brow line
    segLine(g, [-r * 0.94, -r * 0.26], [r * 0.96, -r * 0.18], r * 0.13, col(look, m, 3));
    if (look.spikes) for (let k = 0; k < 3; k++)
      poly(g, [[-r * (0.5 - k * 0.34), -r * 1.02], [-r * (0.44 - k * 0.34), -r * 1.52], [-r * (0.26 - k * 0.34), -r * 1.00]], col(look, m, 0));
    return 1;
  }
  if (H === 'masked') {
    // mask over the upper face, mouth grille, jaw still readable as a jaw
    poly(g, [[-r * F.cran * 1.02, -r * 0.24], [-r * 0.80, -r * F.tall * 0.98], [r * 0.24, -r * F.tall * 1.14],
      [r * F.cran * 1.00, -r * 0.54], [r * F.cran * 0.98, r * 0.14], [r * 0.30, r * 0.04], [-r * 0.66, -r * 0.14]], col(look, A, 1));
    poly(g, [[-r * 0.66, -r * 0.70], [r * 0.18, -r * F.tall * 1.06], [r * 0.86, -r * 0.54], [r * 0.16, -r * 0.80]], col(look, A, 0));
    // eye slit
    poly(g, [[r * 0.14, -r * 0.40], [r * 0.94, -r * 0.26], [r * 0.90, -r * 0.02], [r * 0.14, -r * 0.16]], OUTLINE);
    g.fillStyle = FLAT.glow; g.fillRect(r * 0.40, -r * 0.34, r * 0.46, r * 0.16);
    // grille over the mouth
    for (let k = 0; k < 3; k++) segLine(g, [r * 0.30, r * (0.30 + k * 0.16)], [r * 0.86, r * (0.24 + k * 0.16)], r * 0.07, col(look, A, 3));
    return 1;
  }
  if (H === 'bald') { cap(0.46, 0.20, 1.02, 'skin', 0); return 0; }
  if (H === 'shades') { cap(0.44, 0.18, 1.02, 'skin', 0); return 0; }
  // hair mass
  const long = H === 'anita' || H === 'bob' || H === 'bandana';
  const pony = H === 'pony' || H === 'bun';
  if (long) back(H === 'bob' ? 0.26 : 0.40, H === 'bob' ? 0.55 : 1.45, HA);
  if (pony) poly(g, [[-r * 0.80, -r * 0.50], [-r * 1.55, -r * 0.30], [-r * 1.62, r * 0.34],
    [-r * 0.94, r * 0.10], [-r * 0.62, -r * 0.22]], col(look, HA, 2));
  if (H === 'mohawk') {
    // shaved sides: a narrow crest, not a full cap
    cap(0.94, 0.26, 1.06, 'skin', 2);
    poly(g, [[-r * 0.72, -r * 0.94], [-r * 0.60, -r * 1.42], [r * 0.46, -r * 1.48], [r * 0.66, -r * 0.92]], col(look, HA, 2));
    for (let k = 0; k < 5; k++) {
      const t = -0.66 + k * 0.30;
      poly(g, [[r * t, -r * 1.10], [r * (t + 0.08), -r * (1.78 + (k % 2) * 0.18)], [r * (t + 0.22), -r * 1.06]], col(look, HA, 1));
    }
    segLine(g, [-r * 0.52, -r * 1.34], [r * 0.40, -r * 1.38], r * 0.12, col(look, HA, 0));
    return 0;
  }
  cap(1.08, 0.60, 0.94, HA, 2);
  cap(0.82, 0.42, 1.06, HA, 1);
  // fringe over the brow, stopping short so the face still reads
  poly(g, [[-r * F.cran * 1.02, -r * 0.42], [r * 0.20, -r * F.tall * 1.12], [r * F.cran * 0.98, -r * 0.46],
    [r * 0.52, -r * 0.58], [r * 0.02, -r * 0.82], [-r * 0.54, -r * 0.44]], col(look, HA, 2));
  segLine(g, [-r * 0.46, -r * F.tall * 0.94], [r * 0.24, -r * F.tall * 1.02], r * 0.12, col(look, HA, 0));
  if (H === 'spiky') for (let k = 0; k < 4; k++) {
    const t = -0.86 + k * 0.52;
    poly(g, [[r * t, -r * 0.86], [r * (t + 0.26), -r * 1.42], [r * (t + 0.34), -r * 0.82]], col(look, HA, 1));
  } else if (H === 'flattop') {
    poly(g, [[-r * 0.98, -r * 0.92], [-r * 0.96, -r * 1.34], [r * 0.90, -r * 1.30], [r * 0.94, -r * 0.84]], col(look, HA, 2));
    segLine(g, [-r * 0.90, -r * 1.24], [r * 0.84, -r * 1.20], r * 0.14, col(look, HA, 0));
  } else if (H === 'slick') {
    segLine(g, [-r * 0.9, -r * 0.62], [r * 0.9, -r * 0.86], r * 0.12, col(look, HA, 0));
    segLine(g, [-r * 0.9, -r * 0.40], [r * 0.86, -r * 0.62], r * 0.10, col(look, HA, 0));
  }
  // headband / cap / goggles ride on the brow
  if (H === 'band' || H === 'bandana') poly(g, [[-r * 1.02, -r * 0.40], [r * 0.98, -r * 0.34], [r * 0.94, -r * 0.66], [-r * 1.02, -r * 0.72]], col(look, A, 1));
  if (H === 'cap') {
    poly(g, [[-r * 1.02, -r * 0.46], [r * 0.30, -r * 1.16], [r * 0.98, -r * 0.52], [-r * 0.98, -r * 0.40]], col(look, A, 1));
    poly(g, [[r * 0.34, -r * 0.62], [r * 1.34, -r * 0.44], [r * 1.30, -r * 0.24], [r * 0.30, -r * 0.40]], col(look, A, 2));
  }
  if (H === 'goggles') {
    poly(g, [[-r * 1.02, -r * 0.34], [r * 0.98, -r * 0.30], [r * 0.94, -r * 0.74], [-r * 1.02, -r * 0.78]], col(look, A, 2));
    disc(g, [r * 0.56, -r * 0.52], r * 0.30, OUTLINE);
    disc(g, [r * 0.56, -r * 0.52], r * 0.20, col(look, A, 0));
    return 1;
  }
  return 0;
}
// the head itself
function paintHead(g, look, J) {
  const r = J.hr, F = faceOf(look), fem = look.fem;
  g.save();
  g.translate(J.head[0], J.head[1]);
  g.rotate(J.headA * DEG);
  const SK = 'skin';
  const rx = r * F.cran, ry = r * F.tall;
  // --- cranium
  g.fillStyle = col(look, SK, 1);
  g.beginPath(); g.ellipse(0, -r * 0.16, rx, ry, 0, 0, 7); g.fill();
  // --- jaw: cheekbone -> jaw angle -> chin
  const chinY = ry * 0.98, chinX = rx * F.chin;
  poly(g, [[-rx * 0.70, ry * 0.16], [rx * F.jaw, -ry * 0.02], [rx * F.jaw * 0.96, ry * 0.44],
    [chinX, chinY], [-rx * 0.16, chinY * 0.98], [-rx * 0.66, ry * 0.52]], col(look, SK, 1));
  // --- shadow side: the light is over the back shoulder, so the front of the
  //     face and under the jaw fall away
  poly(g, [[rx * 0.30, -ry * 0.70], [rx * F.jaw * 1.02, -ry * 0.02], [rx * F.jaw * 0.96, ry * 0.44],
    [chinX, chinY], [rx * 0.02, chinY * 0.96], [rx * 0.06, -ry * 0.40]], col(look, SK, 2));
  segLine(g, [-rx * 0.20, ry * 0.86], [chinX * 0.9, chinY * 0.94], r * 0.16, col(look, SK, 2));
  // --- lit rim along the back of the skull
  segLine(g, [-rx * 0.74, -ry * 0.44], [-rx * 0.30, -ry * 0.92], r * 0.18, col(look, SK, 0));
  // --- brow ridge and the socket under it
  segLine(g, [rx * 0.10, -ry * 0.34], [rx * 0.94, -ry * 0.22], r * 0.20 * F.brow, col(look, SK, 2));
  if (F.hood) segLine(g, [rx * 0.16, -ry * 0.20], [rx * 0.90, -ry * 0.10], r * 0.18, col(look, SK, 3));
  // --- nose
  const nx = rx * (0.74 + 0.18 * F.nose);
  poly(g, [[rx * 0.66, -ry * 0.16], [nx, ry * 0.12], [rx * 0.60, ry * 0.16]], col(look, SK, 1));
  segLine(g, [nx * 0.98, ry * 0.12], [rx * 0.62, ry * 0.17], r * 0.11, col(look, SK, 2));
  // --- eye
  const ex = rx * 0.50, ey = -ry * 0.04, ew = r * 0.30, eh = r * 0.20;
  poly(g, [[ex - r * 0.06, ey], [ex + ew * 0.35, ey - eh * 0.95], [ex + ew * 1.06, ey - eh * 0.5],
    [ex + ew * 1.02, ey + eh * 0.55], [ex + ew * 0.2, ey + eh * 0.7]], FLAT.eyeW);
  g.fillStyle = FLAT.pupil; g.fillRect(ex + ew * 0.42, ey - eh * 0.75, ew * 0.56, eh * 1.4);
  // upper lid line, then the brow above it
  segLine(g, [ex - r * 0.08, ey - eh * 0.4], [ex + ew * 1.06, ey - eh * 0.75], r * 0.11, col(look, SK, 3));
  segLine(g, [ex - r * 0.12, ey - eh * 1.9], [ex + ew * 1.15, ey - eh * 1.55], r * 0.15, col(look, 'hair', 2));
  // --- mouth: a set line with the lower lip catching light
  segLine(g, [rx * 0.40, ry * 0.54], [rx * 0.82, ry * 0.50], r * 0.12, fem && look.lip ? look.lip : col(look, SK, 3));
  if (!fem) segLine(g, [rx * 0.44, ry * 0.64], [rx * 0.76, ry * 0.60], r * 0.09, col(look, SK, 1));
  // --- facial hair
  if (look.beard) {
    poly(g, [[-rx * 0.52, ry * 0.30], [rx * 0.86, ry * 0.18], [rx * F.jaw * 0.94, ry * 0.46],
      [chinX * 1.06, chinY * 1.06], [-rx * 0.18, chinY * 1.04], [-rx * 0.60, ry * 0.60]], col(look, 'hair', 2));
    segLine(g, [rx * 0.34, ry * 0.42], [rx * 0.84, ry * 0.36], r * 0.13, col(look, 'hair', 1));
    segLine(g, [rx * 0.40, ry * 0.54], [rx * 0.80, ry * 0.50], r * 0.11, col(look, SK, 3));
  } else if (look.tash) {
    segLine(g, [rx * 0.38, ry * 0.40], [rx * 0.84, ry * 0.34], r * 0.18, col(look, 'hair', 2));
  }
  // --- ear
  disc(g, [-rx * 0.26, ry * 0.06], r * 0.20, col(look, SK, 1));
  disc(g, [-rx * 0.22, ry * 0.08], r * 0.10, col(look, SK, 2));
  paintHair(g, look, r, F);
  if ((look.head || '') === 'shades') {
    poly(g, [[rx * 0.04, -ry * 0.34], [rx * 1.00, -ry * 0.24], [rx * 0.96, ry * 0.02], [rx * 0.04, -ry * 0.10]], OUTLINE);
    segLine(g, [rx * 0.16, -ry * 0.26], [rx * 0.52, -ry * 0.21], r * 0.09, '#5a5a74');
    segLine(g, [-rx * 0.60, -ry * 0.30], [rx * 0.06, -ry * 0.26], r * 0.10, OUTLINE);
  }
  g.restore();
}

const WEAPON_GEO = { pipe: { len: 24, w: 3, mat: 'metal' }, knife: { len: 10, w: 2, mat: 'metal', grip: true }, pole: { len: 56, w: 4, mat: 'pole' } };
function weaponTip(J, look, w) {
  const G = WEAPON_GEO[w]; if (!G) return null;
  const d = dn(J.a2.fa), hd = J.a2.hd, s = J.s;
  return { b: [hd[0] - d[0] * 3 * s, hd[1] - d[1] * 3 * s], e: [hd[0] + d[0] * G.len * s, hd[1] + d[1] * G.len * s], G };
}
function paintFigure(g, look, J, weapon) {
  const s = J.s;
  paintArm(g, look, J.a1, true, s);
  paintLeg(g, look, J.l1, true, s);
  paintTorso(g, look, J, s);
  paintLeg(g, look, J.l2, false, s);
  if (look.skirt) paintSkirt(g, look, J, s);
  // neck
  const nk = buildOf(look).neck * s * girthK(look);
  taper(g, look, lp(J.sh, J.neck, 0.1), lp(J.neck, J.head, 0.42), nk * 1.06, nk * 0.9, 'skin', false, 0);
  if (HEADS === 'built') paintHead(g, look, J);
  else paintStamp(g, look, look.head, Math.round(J.head[0]), Math.round(J.head[1]), J.hs);
  const wt = weapon && weaponTip(J, look, weapon);
  if (wt) {
    seg3(g, look, wt.b, wt.e, wt.G.w * s * 0.8, wt.G.mat, false);
    if (wt.G.grip) segLine(g, wt.b, lp(wt.b, wt.e, 0.35), wt.G.w * s, col(look, 'wood', 2));
    if (weapon === 'pole') { disc(g, wt.e, 3 * s, col(look, 'metal', 1)); disc(g, wt.e, 1.6 * s, '#fff4b0'); }
  }
  paintArm(g, look, J.a2, false, s);
}

// ------------------------------------------------------------ bake
const BAKE = document.createElement('canvas');
const bctx = BAKE.getContext('2d', { willReadFrequently: true });
const FRAMES = new Map();
let bakeCount = 0;
function palIndex(look, r, g, b) {
  const key = (r << 16) | (g << 8) | b;
  let i = look.cmap.get(key);
  if (i !== undefined) return i;
  let best = 1, bd = 1e9;
  const L = look.list;
  for (let k = 1; k < L.length; k++) {
    const e = L[k], d = (e.r - r) * (e.r - r) * 3 + (e.g - g) * (e.g - g) * 4 + (e.b - b) * (e.b - b) * 2;
    if (d < bd) { bd = d; best = k; }
  }
  look.cmap.set(key, best);
  return best;
}
// generic: bbox = [x0,y0,x1,y1] in output pixels relative to the ground origin; paint(g) draws in output units
function bakeGeneric(look, bbox, paint, opts = {}) {
  const pad = 2;
  // bbox is in logical units; the sprite is rasterised at PX pixels per logical
  // unit, supersampled a further SS times and majority-voted back down, so the
  // palette stays discrete while the sprite carries PX times the detail.
  const x0 = Math.floor(bbox[0]) - pad, y0 = Math.floor(bbox[1]) - pad;
  const w = (Math.ceil(bbox[2]) - x0 + pad) * PX, h = (Math.ceil(bbox[3]) - y0 + pad) * PX;
  const W3 = w * SS, H3 = h * SS;
  if (BAKE.width < W3 || BAKE.height < H3) { BAKE.width = Math.max(BAKE.width, W3); BAKE.height = Math.max(BAKE.height, H3); }
  const g = bctx;
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.clearRect(0, 0, W3, H3);
  const F = SS * PX;
  g.setTransform(F, 0, 0, F, -x0 * F, -y0 * F);
  g.lineCap = 'round'; g.lineJoin = 'round';
  paint(g);
  g.setTransform(1, 0, 0, 1, 0, 0);
  const src = g.getImageData(0, 0, W3, H3).data;
  const L = look.list;
  const idx3 = new Uint8Array(W3 * H3);
  for (let i = 0, p = 0; i < idx3.length; i++, p += 4) {
    if (src[p + 3] < 128) continue;
    idx3[i] = palIndex(look, src[p], src[p + 1], src[p + 2]);
  }
  // majority vote per 3x3 block
  const idx = new Uint8Array(w * h);
  const cnt = new Uint8Array(L.length + 1);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    let best = 0, bc = 0, base = y * SS * W3 + x * SS;
    const touched = [];
    for (let dy = 0; dy < SS; dy++) for (let dx = 0; dx < SS; dx++) {
      const v = idx3[base + dy * W3 + dx];
      if (cnt[v] === 0) touched.push(v);
      cnt[v]++;
      // details win ties and need only 3 votes so eyes survive
      const need = v && L[v].detail ? 3 : 0;
      if (cnt[v] > bc || (need && cnt[v] >= need && !(best && L[best].detail))) { bc = cnt[v]; best = v; }
    }
    for (const v of touched) cnt[v] = 0;
    idx[y * w + x] = best;
  }
  // output with ink lines + outline
  const out = new ImageData(w, h), d = out.data;
  const at = (x, y) => (x < 0 || y < 0 || x >= w || y >= h) ? 0 : idx[y * w + x];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const v = idx[y * w + x], o = (y * w + x) * 4;
    let hex = null;
    if (v) {
      const e = L[v];
      hex = e.hex;
      // rim light: the lit edge of the silhouette takes the brightest tone
      if (!e.detail && !opts.noRim && e.tone >= 1 && (!at(x - 1, y) || !at(x, y - 1))) {
        const up = L.find(q => q && q.mat === e.mat && q.tone === e.tone - 1);
        if (up) hex = up.hex;
      }
      if (!e.detail && e.mat !== 'hair' && !opts.noInk) {
        for (const [nx, ny] of [[x + 1, y], [x, y + 1], [x - 1, y], [x, y - 1]]) {
          const q = at(nx, ny);
          if (!q) continue;
          const f = L[q];
          if (f.detail || f.mat === e.mat || f.mat === 'hair') continue;
          if (e.lum < f.lum - 18 && e.tone >= 1) { hex = look.ink[e.mat] || OUTLINE; break; }
        }
      }
    } else {
      // outline: 1 px all round (8-way), plus a second pixel on the shaded side
      for (const [nx, ny] of [[x + 1, y], [x, y + 1], [x - 1, y], [x, y - 1], [x + 1, y + 1], [x - 1, y + 1], [x + 1, y - 1], [x - 1, y - 1]]) {
        const q = at(nx, ny);
        if (q) { const f = L[q]; hex = f.detail ? OUTLINE : (look.ink[f.mat] || OUTLINE); break; }
      }
      if (!hex && (at(x - 1, y - 1) || at(x - 2, y) || at(x, y - 2))) hex = OUTLINE;
    }
    if (hex) { const [r, g2, b] = hexRgb(hex); d[o] = r; d[o + 1] = g2; d[o + 2] = b; d[o + 3] = 255; }
  }
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  cv.getContext('2d').putImageData(out, 0, 0);
  bakeCount++;
  return { cv, ox: -x0 * PX, oy: -y0 * PX, w, h, white: null };
}
function figureBBox(look, J, weapon) {
  const pts = [J.hip, J.sh, J.head, J.a1.el, J.a1.hd, J.a2.el, J.a2.hd, J.l1.kn, J.l1.an, J.l1.ft, J.l2.kn, J.l2.an, J.l2.ft];
  const wt = weapon && weaponTip(J, look, weapon);
  if (wt) pts.push(wt.e, wt.b);
  const r = J.rot * DEG, c = Math.cos(r), sn = Math.sin(r);
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  const padB = 9 * J.s * (look.girth || 1), padH = 10 * J.hs;
  pts.forEach((p, i) => {
    const X = p[0] * c - p[1] * sn, Y = p[0] * sn + p[1] * c + J.snap;
    const pd = i === 2 ? padH + (STAMPS[look.head] || []).length * 0.4 * J.hs : padB;
    x0 = Math.min(x0, X - pd); x1 = Math.max(x1, X + pd); y0 = Math.min(y0, Y - pd); y1 = Math.max(y1, Y + pd);
  });
  return [x0, y0, x1, y1];
}
function getFrame(look, poseName, rotOverride, weapon) {
  const rb = rotOverride === null || rotOverride === undefined ? '' : ((Math.round(rotOverride / 45) % 8) + 8) % 8;
  const key = look.id + '|' + poseName + '|' + rb + '|' + (weapon || '');
  let f = FRAMES.get(key);
  if (f) return f;
  const base = POSES[poseName] || POSES.idle;
  let P = base;
  if (rb !== '') { P = base.slice(); P[10] = rb * 45; }
  const J = solvePose(P, look);
  const bb = figureBBox(look, J, weapon);
  f = bakeGeneric(look, bb, g => {
    g.translate(0, J.snap);
    g.rotate(J.rot * DEG);
    paintFigure(g, look, J, weapon);
  });
  f.J = J;
  FRAMES.set(key, f);
  return f;
}
function whiteOf(f) {
  if (f.white) return f.white;
  const c = document.createElement('canvas'); c.width = f.w; c.height = f.h;
  const g = c.getContext('2d');
  g.drawImage(f.cv, 0, 0); g.globalCompositeOperation = 'source-in'; g.fillStyle = '#ffffff'; g.fillRect(0, 0, f.w, f.h);
  f.white = c;
  return c;
}
const TINT = document.createElement('canvas');
function blitFrame(f, x, y, facing, o = {}) {
  let img = o.flash ? whiteOf(f) : f.cv;
  if (o.tint && !o.flash) {
    if (TINT.width < f.w || TINT.height < f.h) { TINT.width = Math.max(TINT.width, f.w); TINT.height = Math.max(TINT.height, f.h); }
    const t = TINT.getContext('2d');
    t.globalCompositeOperation = 'source-over'; t.clearRect(0, 0, TINT.width, TINT.height);
    t.drawImage(f.cv, 0, 0);
    t.globalCompositeOperation = 'source-atop'; t.fillStyle = o.tint; t.fillRect(0, 0, f.w, f.h);
    t.globalCompositeOperation = 'source-over';
    img = TINT;
  }
  const sc = o.scale || 1;
  const a = o.alpha === undefined ? 1 : o.alpha;
  if (a <= 0) return;
  ctx.globalAlpha = a;
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  ctx.translate(RP(x), RP(y));
  if (facing < 0) ctx.scale(-1, 1);
  // frame metrics are sprite pixels; /PX puts them back into logical units,
  // rounding first so one sprite pixel lands on one device pixel.
  ctx.drawImage(img, 0, 0, f.w, f.h,
    -Math.round(f.ox * sc) / PX, -Math.round(f.oy * sc) / PX,
    Math.round(f.w * sc) / PX, Math.round(f.h * sc) / PX);
  ctx.restore();
  ctx.globalAlpha = 1;
}
// public: draw a posed fighter by pose name
function drawFigure(x, y, facing, poseName, look, o = {}) {
  const f = getFrame(look, poseName, o.rot, o.weapon);
  blitFrame(f, x, y, facing, o);
  return f;
}
// head portrait for the HUD
const PORTRAITS = new Map();
function drawPortrait(x, y, look, w = 22, h = 22) {
  px(x - 1, y - 1, w + 2, h + 2, '#120a14');
  px(x, y, w, h, '#2a2440');
  let p = PORTRAITS.get(look.id);
  if (!p) {
    p = HEADS === 'built'
      ? bakeGeneric(look, [-11, -13, 11, 12], g => paintHead(g, look, Object.assign({}, solvePose(POSES.idle, look), { head: [0, 0], headA: 0 })), { noInk: true })
      : bakeGeneric(look, [-9, -10, 9, 10], g => { paintStamp(g, look, look.head, 0, 0, 1); }, { noInk: true });
    PORTRAITS.set(look.id, p);
  }
  ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
  ctx.imageSmoothingEnabled = false;
  const sc = 2 / PX;
  ctx.drawImage(p.cv, RP(x + w / 2 - p.ox * sc + 1), RP(y + h / 2 - p.oy * sc + 3), p.w * sc, p.h * sc);
  ctx.restore();
}
// warm the cache over several frames; returns true when done
function prewarm(list, budgetMs = 10) {
  const t0 = performance.now();
  while (list.length && performance.now() - t0 < budgetMs) {
    const [look, pose, weapon] = list.pop();
    if (pose.startsWith('mech:')) getMechFrame(pose.slice(5));
    else getFrame(look, pose, null, weapon);
  }
  return list.length === 0;
}

const FEM_MAP = { idle: 'aIdle', idle2: 'aIdle2', walk1: 'aWalk1', walk2: 'aWalk2', walk3: 'aWalk3', walk4: 'aWalk4', victory: 'aVictory' };
// per-look pose remaps, so each fighter stands and walks like himself
const POSE_MAPS = {
  tank: { idle: 'kIdle', idle2: 'kIdle2', walk1: 'kWalk1', walk2: 'kWalk2', walk3: 'kWalk3', walk4: 'kWalk4', victory: 'kVictory',
    heavyIdle: 'kIdle', heavyIdle2: 'kIdle2' },
  jett: { idle: 'jIdle', idle2: 'jIdle2', walk1: 'jWalk1', walk2: 'jWalk2', walk3: 'jWalk3', walk4: 'jWalk4', victory: 'jVictory',
    run1: 'jRun1', run2: 'jRun2', run3: 'jRun1', run4: 'jRun2' },
};
function mapPose(look, p) {
  if (look.pmap && POSE_MAPS[look.pmap] && POSE_MAPS[look.pmap][p]) return POSE_MAPS[look.pmap][p];
  if (look.heavy && (p === 'idle' || p === 'idle2')) p = p === 'idle' ? 'heavyIdle' : 'heavyIdle2';
  if (look.fem) return FEM_MAP[p] || p;
  return p;
}

// ------------------------------------------------------------ Wrecker mech (custom body, same baker)
LOOKS.mech = mkLook({ name: 'mech', head: 'hardhat', skin: '#d8a078', hair: '#4a3020', acc: '#e8b020', top: '#e8b020',
  pants: '#4c505c', boots: '#2c2e36', inner: '#58c8e8', metal: '#a8b0bc', belt: '#c8302a', gloves: '#3a3c44' });
const MECH_POSES = ['idle', 'walk1', 'walk2', 'clawUp', 'clawDown', 'flameAim', 'flame', 'stompUp', 'stompDown', 'stall', 'break'];
const MECH_SHAPES = {
  idle:      { lift: 0, stride: 0, claw: 'rest', gun: 'rest', tilt: 0, bob: 0 },
  walk1:     { lift: 4, stride: 8, claw: 'rest', gun: 'rest', tilt: 0, bob: -1 },
  walk2:     { lift: 0, stride: -8, claw: 'rest', gun: 'rest', tilt: 0, bob: 1 },
  clawUp:    { lift: 0, stride: 0, claw: 'up', gun: 'rest', tilt: -4, bob: -1 },
  clawDown:  { lift: 0, stride: 4, claw: 'down', gun: 'rest', tilt: 6, bob: 2 },
  flameAim:  { lift: 0, stride: 0, claw: 'rest', gun: 'aim', tilt: 0, bob: 0 },
  flame:     { lift: 0, stride: 0, claw: 'rest', gun: 'aim', tilt: -2, bob: 0, fire: true },
  stompUp:   { lift: 22, stride: 6, claw: 'up', gun: 'rest', tilt: -6, bob: -3 },
  stompDown: { lift: 0, stride: 10, claw: 'down', gun: 'rest', tilt: 4, bob: 3 },
  stall:     { lift: 0, stride: 0, claw: 'limp', gun: 'limp', tilt: 8, bob: 5 },
  break:     { lift: 0, stride: 0, claw: 'limp', gun: 'limp', tilt: 14, bob: 8 },
};
function paintMech(g, look, S) {
  const L = look;
  const hipY = -50 + S.bob;
  // back leg
  const bk = [-16 - S.stride * 0.5, -26 + S.bob * 0.5], bf = [-12 - S.stride, -3];
  seg3(g, L, [-10, hipY], bk, 11, 'pants', true);
  seg3(g, L, bk, bf, 10, 'pants', true);
  poly(g, [[bf[0] - 10, 0], [bf[0] + 12, 0], [bf[0] + 10, -8], [bf[0] - 8, -8]], col(L, 'boots', 2));
  // front leg
  const fk = [18 + S.stride * 0.5, -28 - S.lift * 0.6 + S.bob * 0.5], ff = [14 + S.stride, -3 - S.lift];
  seg3(g, L, [10, hipY], fk, 12, 'pants', false);
  seg3(g, L, fk, ff, 11, 'pants', false);
  disc(g, fk, 5, col(L, 'pants', 3)); disc(g, fk, 3, col(L, 'metal', 1));
  poly(g, [[ff[0] - 11, ff[1] + 3], [ff[0] + 14, ff[1] + 3], [ff[0] + 12, ff[1] - 6], [ff[0] - 9, ff[1] - 6]], col(L, 'boots', 1));
  segLine(g, [ff[0] - 11, ff[1] + 2.5], [ff[0] + 14, ff[1] + 2.5], 1.5, col(L, 'boots', 3));
  // body (tilted)
  g.save();
  g.translate(0, hipY);
  g.rotate(S.tilt * DEG);
  // pelvis
  poly(g, [[-18, 6], [18, 6], [14, -6], [-14, -6]], col(L, 'pants', 2));
  // exhausts
  seg3(g, L, [-22, -58], [-22, -72], 5, 'metal', true);
  seg3(g, L, [-13, -58], [-13, -67], 4, 'metal', true);
  // flamethrower arm (behind the claw)
  const gun = S.gun === 'aim' ? { a: [12, -22], b: [30, -20], c: [50, -18] } : S.gun === 'limp' ? { a: [12, -22], b: [20, -8], c: [22, 6] } : { a: [12, -22], b: [26, -14], c: [34, -2] };
  seg3(g, L, gun.a, gun.b, 6, 'gloves', true);
  seg3(g, L, gun.b, gun.c, 7, 'metal', true);
  disc(g, gun.c, 3.2, col(L, 'boots', 3));
  if (S.fire) { disc(g, gun.c, 2.4, FLAT.gold); disc(g, [gun.c[0] + 3, gun.c[1]], 1.6, '#ffffff'); }
  else if (S.gun === 'aim') disc(g, gun.c, 1.4, FLAT.glow);
  // hull
  const hull = [[-30, -2], [26, -2], [30, -20], [28, -52], [16, -60], [-26, -60], [-32, -40]];
  poly(g, hull, col(L, 'top', 2));
  poly(g, hull.map(p => [p[0] * 0.86 - 2, p[1] * 0.9 - 3]), col(L, 'top', 1));
  poly(g, [[-22, -54], [8, -54], [4, -46], [-24, -46]], col(L, 'top', 0));
  // hazard stripes
  poly(g, [[-30, -2], [26, -2], [28, -10], [-31, -10]], col(L, 'boots', 2));
  for (let k = -28; k < 26; k += 8) poly(g, [[k, -2], [k + 4, -2], [k + 8, -10], [k + 4, -10]], col(L, 'top', 1));
  // rivets & panel lines
  segLine(g, [-30, -26], [28, -26], 1, col(L, 'top', 3));
  for (const x of [-26, -14, -2, 10, 22]) disc(g, [x, -30], 0.9, col(L, 'metal', 0));
  // warning light
  disc(g, [-20, -61], 2.6, col(L, 'belt', 1)); disc(g, [-20.6, -61.6], 1, col(L, 'belt', 0));
  // cockpit
  const glass = [[6, -52], [26, -50], [28, -32], [6, -30]];
  poly(g, glass, col(L, 'inner', 2));
  paintStamp(g, L, 'hardhat', 16, -40, 1);
  poly(g, [[6, -52], [26, -50], [26, -47], [6, -49]], col(L, 'inner', 0));
  segLine(g, [22, -48], [26, -36], 1, col(L, 'inner', 0));
  segLine(g, [6, -52], [6, -30], 1.6, col(L, 'boots', 2));
  // claw arm
  const cl = S.claw === 'up' ? { sh: [22, -40], el: [40, -70], wr: [60, -92], ang: -55 }
    : S.claw === 'down' ? { sh: [22, -40], el: [52, -34], wr: [80, -16], ang: 25 }
    : S.claw === 'limp' ? { sh: [22, -40], el: [34, -18], wr: [38, 4], ang: 80 }
    : { sh: [22, -40], el: [44, -38], wr: [58, -18], ang: 55 };
  disc(g, cl.sh, 9, col(L, 'gloves', 2));
  seg3(g, L, cl.sh, cl.el, 11, 'top', false);
  seg3(g, L, cl.el, cl.wr, 9, 'gloves', false);
  disc(g, cl.el, 4, col(L, 'metal', 1));
  const a = cl.ang * DEG, d1 = [Math.cos(a - 0.5), Math.sin(a - 0.5)], d2 = [Math.cos(a + 0.5), Math.sin(a + 0.5)];
  const p1 = add2(cl.wr, d1, 20), p2 = add2(cl.wr, d2, 20);
  seg3(g, L, cl.wr, p1, 6, 'metal', false);
  seg3(g, L, cl.wr, p2, 6, 'metal', false);
  segLine(g, p1, add2(p1, [Math.cos(a + 0.4), Math.sin(a + 0.4)], 5), 2.4, col(L, 'metal', 2));
  segLine(g, p2, add2(p2, [Math.cos(a - 0.4), Math.sin(a - 0.4)], 5), 2.4, col(L, 'metal', 2));
  if (S.claw === 'limp' || S.tilt > 10) { disc(g, [-4, -20], 2, FLAT.glow); segLine(g, [-10, -40], [-2, -34], 1, OUTLINE); }
  g.restore();
}
function getMechFrame(pose) {
  const key = 'mech|' + pose;
  let f = FRAMES.get(key);
  if (f) return f;
  const S = MECH_SHAPES[pose] || MECH_SHAPES.idle;
  f = bakeGeneric(LOOKS.mech, [-50, -140, 112, 6], g => paintMech(g, LOOKS.mech, S));
  FRAMES.set(key, f);
  return f;
}
