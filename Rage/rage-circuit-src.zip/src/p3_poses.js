// ============================================================ POSES + SKELETON
// A pose is 11 angles (degrees):
// [torso lean, head tilt, backUpperArm, backElbow, frontUpperArm, frontElbow,
//  backThigh, backKnee, frontThigh, frontKnee, bodyRotation]
// Limb angles are measured from straight down, positive = toward facing.
// Elbow: positive flexes the forearm forward/up. Knee: positive bends the shin back.
const GS = 1.3;            // GAMEPLAY scale: hitboxes, reach, body heights
// VISUAL trim, drawing only. The rebuilt rig is longer-legged and carries a
// proportional head, so the figure is scaled to keep the same on-screen size -
// and the same relationship to the hitboxes - as before the rebuild.
const VS = 0.715;
const OUTLINE = '#0d0710';
let HEAD_PROP = true;   // the head scales with the character
const POSES = {};
function defPose(name, t, h, ua1, la1, ua2, la2, th1, kn1, th2, kn2, rot = 0) {
  POSES[name] = [t, h, ua1, la1, ua2, la2, th1, kn1, th2, kn2, rot];
}
// ---- stance / movement
defPose('idle', 4, 0, 14, 92, 2, 104, -13, 6, 17, 10);
defPose('idle2', 6, 2, 12, 98, 0, 110, -13, 11, 17, 15);
defPose('walk1', 3, 0, 26, 104, -4, 118, -22, 10, 22, 4);
defPose('walk2', 4, 0, 16, 108, 2, 122, -5, 30, 8, 4);
defPose('walk3', 3, 0, 2, 114, 16, 110, 22, 4, -22, 10);
defPose('walk4', 4, 0, 16, 108, 2, 122, 8, 4, -5, 30);
defPose('run1', 18, 0, -40, 90, 60, 80, -35, 40, 45, 20);
defPose('run2', 20, 0, 10, 90, 10, 90, -10, 80, 10, 10);
defPose('run3', 18, 0, 60, 80, -40, 90, 45, 20, -35, 40);
defPose('run4', 20, 0, 10, 90, 10, 90, 10, 10, -10, 80);
defPose('jumpUp', 0, 0, -20, 60, 40, 60, -10, 60, 40, 70);
defPose('jumpFall', 5, 0, -40, 30, 60, 30, -5, 20, 20, 30);
defPose('land', 15, 5, 20, 60, 30, 60, -20, 50, 30, 60);
defPose('jumpKnee', -5, 0, -30, 60, 30, 100, -10, 50, 95, 120);
defPose('jumpKick', -20, 5, -60, 40, 20, 90, -30, 70, 95, 0);
defPose('elbowDrop', 20, 15, -30, 40, 100, 150, 20, 80, 50, 100);
// ---- strikes
defPose('jab1', 10, 0, 25, 110, 85, 5, -18, 6, 22, 12);
defPose('jab2', 12, 0, 88, 0, 20, 110, -18, 6, 22, 12);
defPose('straight', 20, 0, 92, 0, -10, 100, -25, 4, 30, 20);
defPose('hookA', 5, 0, 15, 110, -30, 100, -15, 10, 20, 20);
defPose('hook', 15, 5, 10, 110, 80, 70, -15, 10, 20, 20);
defPose('rhChamber', -10, 0, -20, 80, 40, 90, -5, 5, 80, 110);
defPose('roundhouse', -25, 10, -40, 60, 50, 80, -10, 5, 100, 5);
defPose('backElbow', -8, -10, -95, 165, 30, 90, -15, 8, 12, 8);
defPose('blitz1', 35, 0, -30, 60, 100, 20, -40, 30, 40, 40);
defPose('blitz2', -10, -5, -20, 80, 160, 10, -20, 10, 30, 60);
defPose('charge1', 15, 0, 40, 90, -60, 120, -25, 25, 30, 35);
defPose('charge2', 17, 2, 42, 88, -64, 124, -25, 28, 30, 38);
defPose('haymaker', 30, 0, -50, 40, 92, 0, -35, 5, 40, 30);
defPose('spin1', 0, 0, 100, 0, -100, 0, -10, 40, 30, 50);
defPose('spin2', 0, 0, -100, 0, 100, 0, -10, 40, 30, 50);
defPose('spin3', -5, -10, 150, 20, 170, 0, -10, 60, 20, 90);
defPose('dash', 40, 0, -60, 30, 95, 0, -50, 20, 50, 60);
defPose('crash', 30, 10, 60, 120, 40, 130, -40, 10, 35, 40);
// ---- grapples
defPose('grab', 10, 0, 54, 52, 58, 48, -12, 8, 18, 12);
defPose('kneePrep', 8, 0, 62, 45, 68, 40, -8, 8, 20, 40);
defPose('knee', 5, 0, 70, 60, 70, 50, -5, 5, 85, 100);
defPose('liftA', -15, -10, 150, 20, 150, 10, -10, 20, 20, 25);
defPose('liftB', 40, 10, 40, 10, 50, 0, -25, 10, 35, 30);
defPose('sup1', 0, 0, 80, 60, 80, 50, -10, 30, 15, 35);
defPose('sup2', -40, -10, 170, 20, 170, 10, -5, 20, 20, 20);
defPose('sup3', -40, -10, 180, 10, 180, 10, 0, 60, 10, 70, -70);
defPose('pileLift', 0, -10, 175, 10, 170, 10, -20, 10, 20, 10);
defPose('pileDrop', 10, 10, 120, 10, 120, 10, -40, 90, 40, 110);
// ---- reactions
defPose('hurt1', -15, -15, -20, 40, 10, 60, -15, 10, 15, 15);
defPose('hurt2', 30, 20, 20, 30, 30, 40, -20, 25, 15, 30);
defPose('fall', -20, -10, -150, 20, -120, 30, 20, 30, 40, 40, -60);
defPose('down', 0, 0, -170, 10, -150, 20, 5, 10, 15, 20, -90);
defPose('downFace', 0, 0, 170, 10, 150, 20, 5, 10, 15, 20, 90);
defPose('getup', 20, 0, 20, 10, 40, 10, 40, 100, 70, 120, -40);
defPose('roll', 60, 30, 60, 120, 70, 120, 90, 150, 100, 150);
defPose('pickup', 60, 10, 0, 10, 10, 0, -10, 60, 40, 80);
defPose('victory', -5, -5, -10, 20, 170, 10, -20, 0, 20, 0);
defPose('held', -10, -20, 10, 30, 20, 40, -10, 20, 10, 20);
defPose('dizzy', 10, 15, 0, 10, 5, 10, -10, 15, 15, 15);
defPose('dizzy2', 6, 20, 5, 12, 0, 8, -10, 15, 15, 15);
// ---- weapons
defPose('wpnWind', -10, 0, 30, 90, -120, 20, -15, 10, 20, 15);
defPose('wpnSwing', 25, 0, -20, 60, 95, -10, -25, 5, 30, 25);
defPose('wpnHigh', -5, -5, 30, 80, 175, 0, -10, 10, 15, 15);
defPose('wpnChop', 35, 10, -20, 60, 70, 0, -25, 10, 35, 35);
defPose('slash1', 5, 0, 30, 100, -60, 100, -15, 10, 20, 15);
defPose('slash2', 20, 0, 20, 100, 110, -20, -22, 5, 28, 20);
defPose('tossA', -10, 0, 40, 80, -150, 40, -15, 10, 15, 15);
defPose('tossB', 25, 0, -20, 60, 80, 0, -20, 5, 30, 20);
// ---- boss
defPose('roar', -20, -25, -60, 100, -50, 100, -25, 5, 25, 5);
defPose('slamUp', -10, -10, 175, 10, 170, 5, -20, 10, 20, 10);
defPose('slamDown', 45, 20, 70, 0, 75, 0, -30, 40, 40, 60);
defPose('paw1', 20, 5, 40, 80, 50, 70, -20, 10, 30, 60);
defPose('paw2', 22, 5, 40, 80, 50, 70, -20, 10, -10, 10);
defPose('charge', 45, 10, -30, 60, 50, 40, -35, 40, 45, 20);
defPose('charge2', 45, 10, -30, 60, 50, 40, 45, 20, -35, 40);
defPose('poleWind', -15, 0, 20, 90, -110, 0, -20, 10, 25, 15);
defPose('poleSwing', 30, 5, -30, 60, 95, 0, -30, 10, 40, 30);
defPose('reach', 20, 0, 80, 20, 85, 10, -20, 10, 30, 30);
// ---- cole upgrades
defPose('uppercut', -12, -8, -30, 60, 168, 25, -25, 20, 30, 45);
defPose('uppercutA', 25, 5, -20, 70, 40, 140, -30, 50, 40, 70);
defPose('jumpKick2', -20, 5, 20, 90, -50, 40, 95, 0, -30, 70);
// ---- anita (fem kicker)
defPose('aIdle', 2, 0, 18, 102, 6, 114, -15, 8, 19, 12);
defPose('aIdle2', 3, 2, 28, 82, 16, 92, -15, 13, 19, 17);
defPose('aWalk1', 2, 0, 22, 120, 2, 128, -24, 10, 24, 6);
defPose('aWalk2', 3, 0, 14, 122, 8, 130, -6, 32, 8, 6);
defPose('aWalk3', 2, 0, 4, 126, 20, 122, 24, 6, -24, 10);
defPose('aWalk4', 3, 0, 14, 122, 8, 130, 8, 6, -6, 32);
defPose('aJab', 8, 0, 30, 115, 86, 4, -16, 6, 22, 12);
defPose('aLowKick', -6, 0, 45, 110, 30, 120, -18, 10, 62, 8);
defPose('aMidKick', -14, 4, 50, 100, -10, 110, -16, 6, 88, 4);
defPose('aChamber', -8, 0, 40, 110, 20, 120, -12, 6, 70, 120);
defPose('aHighKick', -30, 10, 60, 80, -30, 100, -12, 4, 122, 0);
defPose('aHeel', -34, 12, 70, 60, -40, 90, -10, 6, 135, 25);
defPose('aBackKick', 30, -5, -20, 110, 40, 120, -100, 0, 20, 30);
defPose('aFlyKick', -26, 6, -50, 60, 30, 120, -40, 90, 96, 0);
defPose('aFlyKick2', -22, 6, 30, 120, -50, 60, 96, 0, -35, 85);
defPose('aSlide', -34, 8, -60, 40, 40, 100, -10, 100, 84, 0);
defPose('aTornado1', -10, 0, -95, 10, 95, 10, -20, 30, 95, 0);
defPose('aTornado2', -10, 0, 95, 10, -95, 10, 95, 0, -20, 30);
defPose('aHeli1', 0, 0, 160, 10, 160, 10, -95, 0, 95, 0);
defPose('aHeli2', 0, 0, -160, 10, -160, 10, 95, 0, -95, 0);
defPose('aDrive', 25, 0, -70, 40, -40, 60, -40, 40, 95, 130);
defPose('aAxeUp', -30, 8, 40, 90, -40, 90, -8, 4, 172, 0);
defPose('aAxeDown', 22, 8, 40, 90, -20, 90, -20, 10, 58, 0);
defPose('aScissor', -15, 0, -60, 30, 60, 30, -60, 0, 80, 0);
defPose('aAirThrow', 20, 5, -40, 60, 90, 0, -20, 80, 40, 90);
defPose('aTuck', 10, 10, 60, 120, 70, 120, 90, 150, 100, 150);
defPose('aVictory', -6, -6, 25, -95, 168, 10, -12, 2, 22, 4);
defPose('aRun1', 16, 0, -40, 90, 60, 80, -35, 45, 45, 20);
defPose('aRun2', 18, 0, 60, 80, -40, 90, 45, 20, -35, 45);
// ---- twins (dancers)
defPose('tIdle', -4, -4, -26, 86, 150, 30, -20, 4, 30, 30);
defPose('tIdle2', -2, -8, -40, 110, 160, 20, -20, 8, 30, 36);
defPose('tCrouch', 30, 10, -60, 20, -50, 30, -60, 110, 70, 130);
defPose('tCartA', 0, 0, 175, 5, 175, 5, -35, 0, 35, 0);
defPose('tSplit', -30, 10, 100, 10, -60, 40, -70, 0, 110, 0);
defPose('tKickHigh', -35, 12, 70, 30, -40, 60, -10, 4, 150, 0);
defPose('tTaunt', -4, -10, 30, -100, 170, 20, -10, 0, 20, 0);
// ---- whip
defPose('wWind', -12, -4, 30, 90, -160, 40, -18, 8, 24, 14);
defPose('wCrack', 18, 4, -20, 90, 84, 0, -26, 6, 34, 26);
defPose('splat', 0, 0, -125, 10, 125, -10, -30, 0, 30, 0);
defPose('heavyIdle', 6, 0, 18, 38, 24, 44, -15, 6, 18, 10);
defPose('heavyIdle2', 8, 2, 16, 44, 22, 50, -15, 10, 18, 14);
defPose('standUp', 0, 0, 10, 20, 15, 20, -8, 3, 8, 3);

// ---- tank (heavy grappler)
defPose('kIdle', 7, 0, 8, 62, 10, 72, -16, 6, 19, 10);
defPose('kIdle2', 9, 2, 14, 40, 20, 46, -16, 10, 19, 14);
defPose('kWalk1', 6, 0, 14, 78, 2, 88, -20, 8, 20, 4);
defPose('kWalk2', 8, 0, 10, 80, 6, 90, -4, 26, 8, 4);
defPose('kWalk3', 6, 0, 2, 84, 14, 82, 20, 4, -20, 8);
defPose('kWalk4', 8, 0, 10, 80, 6, 90, 8, 4, -4, 26);
defPose('kJabA', 8, 0, 14, 60, -20, 80, -18, 6, 22, 14);
defPose('kJab', 18, 0, 18, 56, 88, 4, -22, 6, 28, 16);
defPose('kHookA', 6, 0, 8, 74, -44, 86, -16, 8, 22, 18);
defPose('kHook', 22, 6, 4, 74, 86, 58, -20, 8, 28, 22);
defPose('kSlamA', -14, -10, 164, 14, 168, 8, -20, 10, 22, 12);
defPose('kSlam', 42, 16, 62, 0, 68, 0, -30, 36, 40, 54);
defPose('kBack', -6, -12, -100, 158, 26, 82, -16, 8, 14, 8);
defPose('kLariat1', 0, 0, 96, 4, -96, 4, -12, 20, 24, 26);
defPose('kLariat2', 0, 0, -96, 4, 96, 4, -12, 20, 24, 26);
defPose('kBull', 38, 12, -34, 50, 40, 46, -40, 34, 44, 22);
defPose('kBull2', 38, 12, -34, 50, 40, 46, 44, 22, -40, 34);
defPose('kGutA', 18, 0, 34, 80, -62, 114, -24, 24, 30, 32);
defPose('kGut', 26, 0, -46, 34, 96, 2, -32, 6, 38, 26);
defPose('kQuakeA', -20, -10, 150, 20, 154, 14, -18, 8, 20, 10);
defPose('kQuake', 44, 18, 68, 10, 74, 6, -34, 46, 44, 62);
defPose('kReach', 22, 0, 76, 14, 88, 6, -22, 10, 32, 30);
defPose('kClutch', 12, 0, 62, 34, 66, 30, -14, 8, 20, 14);
defPose('kSplash', 8, -8, -118, 18, 118, 18, -50, 18, 50, 18);
defPose('kKnee', -4, 0, -28, 48, 40, 88, -12, 44, 92, 114);
defPose('kLift', -18, -10, 158, 16, 158, 8, -12, 18, 20, 22);
defPose('kPress', -34, -8, 174, 6, 174, 6, -6, 14, 14, 16);
defPose('kVictory', -8, -6, -20, 30, 172, 12, -18, 2, 20, 4);
// ---- jett (speedster)
defPose('jIdle', 2, 0, 18, 98, 4, 110, -12, 8, 16, 12);
defPose('jIdle2', 4, 2, 28, 76, 16, 88, -12, 13, 16, 17);
defPose('jWalk1', 2, 0, 24, 110, -2, 116, -22, 9, 22, 5);
defPose('jWalk2', 3, 0, 16, 112, 4, 120, -5, 30, 8, 5);
defPose('jWalk3', 2, 0, 2, 116, 20, 110, 22, 5, -22, 9);
defPose('jWalk4', 3, 0, 16, 112, 4, 120, 8, 5, -5, 30);
defPose('jJab', 10, 0, 28, 104, 88, 2, -16, 6, 20, 12);
defPose('jJab2', 12, 0, 90, 0, 22, 104, -16, 6, 20, 12);
defPose('jElbow', 16, 4, 20, 98, 58, 128, -20, 6, 26, 16);
defPose('jLow', -6, 0, 40, 98, 24, 108, -16, 8, 58, 10);
defPose('jSpinA', -8, 0, -58, 40, 70, 40, -10, 6, 60, 88);
defPose('jSpin', -26, 10, -48, 40, 60, 58, -10, 5, 112, 4);
defPose('jUpperA', 22, 6, -24, 68, 36, 134, -28, 46, 38, 66);
defPose('jUpper', -14, -8, -32, 54, 170, 22, -26, 20, 30, 44);
defPose('jDash', -6, 0, -108, 20, -84, 30, -30, 30, 36, 34);
defPose('jSlide', -30, 6, -56, 36, 44, 94, -8, 94, 88, 0);
defPose('jRun1', 16, 0, -46, 86, 64, 76, -38, 44, 48, 18);
defPose('jRun2', 18, 0, 64, 76, -46, 86, 48, 18, -38, 44);
defPose('jFly', -24, 6, -54, 56, 28, 114, -36, 86, 98, 0);
defPose('jFly2', -20, 6, 28, 114, -54, 56, 98, 0, -32, 82);
defPose('jHeli1', 0, 0, 150, 14, 150, 14, -90, 0, 90, 0);
defPose('jHeli2', 0, 0, -150, 14, -150, 14, 90, 0, -90, 0);
defPose('jDrill', 30, 0, -68, 30, -48, 40, -46, 30, 92, 118);
defPose('jBack', 28, -6, -22, 102, 38, 114, -96, 0, 22, 28);
defPose('jVictory', -5, -5, 20, -90, 166, 12, -14, 3, 20, 5);
// ---- new boss poses
defPose('gaugeSwing', 28, 6, -26, 58, 92, -4, -28, 8, 36, 28);
defPose('gaugeWind', -16, -4, 26, 86, -114, 6, -20, 10, 26, 16);
defPose('vexReady', -2, -4, 24, 96, -34, 104, -14, 8, 20, 16);
defPose('vexLunge', 34, 6, -54, 40, 100, 4, -42, 22, 46, 26);
defPose('vexSpinA', -6, 0, 110, 10, -110, 10, -16, 30, 30, 40);
defPose('vexSpinB', -6, 0, -110, 10, 110, 10, -16, 30, 30, 40);
defPose('vexThrow', 16, 0, 40, 76, 108, -14, -20, 8, 26, 18);
defPose('vexBlink', 0, 0, -20, 40, 20, 40, -10, 40, 20, 50);
defPose('wardenAim', 4, 0, 90, 4, 88, 2, -16, 8, 20, 12);
defPose('wardenBeam', -8, -6, 96, 0, 96, 0, -18, 6, 22, 10);
defPose('drayCane', 12, -4, 22, 70, 78, 18, -16, 6, 22, 14);
defPose('drayPoint', -4, -8, 18, 66, 96, 0, -14, 6, 20, 12);
defPose('drayCape', -10, -10, -40, 70, 40, 70, -16, 8, 20, 14);

// Rebuilt proportions: longer legs, a shorter/denser torso and a real neck, so
// the figure reads as a constructed body instead of a stack of tubes.
const RIG = { thigh: 16.5, shin: 15.5, torso: 21, ua: 12, fa: 11.6, neck: 4.4 };
const dn = a => [Math.sin(a * DEG), Math.cos(a * DEG)];
function lookScale(look) { return (look.scale || 1) * GS * VS; }
function solvePose(P, look) {
  const s = lookScale(look), gr = look.girth || 1;
  const lg = look.legs || 1, tl = look.torso || 1;
  const L = { thigh: RIG.thigh * s * lg, shin: RIG.shin * s * lg, torso: RIG.torso * s * tl, ua: RIG.ua * s, fa: RIG.fa * s, neck: RIG.neck * s };
  const [t, h, ua1, la1, ua2, la2, th1, kn1, th2, kn2] = P;
  const J = { s };
  const up = [Math.sin(t * DEG), -Math.cos(t * DEG)];
  J.up = up;
  J.hip = [0, 0];
  J.sh = [up[0] * L.torso, up[1] * L.torso];
  // HEAD_PROP: let the head scale with the character instead of being a fixed
  // 14 px bitmap, so a 1.4x boss stops wearing a street punk's head.
  // The head scales with the whole sprite, so head-to-body stays fixed whatever
  // GS is - a 1.4x boss no longer wears a street punk's head.
  const hs = HEAD_PROP ? (look.headScale || 1) * (look.scale || 1) * GS * VS
    : Math.max(1, Math.round(look.headScale || 1));
  const hr = (look.headR || 7) * hs;
  J.hr = hr; J.hs = hs;
  J.neck = [J.sh[0] + up[0] * L.neck, J.sh[1] + up[1] * L.neck];
  J.head = [J.neck[0] + up[0] * hr * 0.95, J.neck[1] + up[1] * hr * 0.95];
  J.headA = t + h;
  const arm = (ua, la, off) => {
    const sh = [J.sh[0] + off[0], J.sh[1] + off[1]];
    const d1 = dn(ua), el = [sh[0] + d1[0] * L.ua, sh[1] + d1[1] * L.ua];
    const d2 = dn(ua + la), hd = [el[0] + d2[0] * L.fa, el[1] + d2[1] * L.fa];
    return { sh, el, hd, fa: ua + la, ua };
  };
  J.a1 = arm(ua1, la1, [-2.6 * gr * s, 1.8 * s]);
  J.a2 = arm(ua2, la2, [1.4 * gr * s, 1.8 * s]);
  const hipW = (look.fem ? 2.3 : 1.7) * gr * s;
  const leg = (th, kn, off) => {
    const hp = [off[0], off[1]];
    const d1 = dn(th), kn_ = [hp[0] + d1[0] * L.thigh, hp[1] + d1[1] * L.thigh];
    const sa = th - kn, d2 = dn(sa), an = [kn_[0] + d2[0] * L.shin, kn_[1] + d2[1] * L.shin];
    const d3 = dn(sa + 90), ft = [an[0] + d3[0] * 6.2 * s, an[1] + d3[1] * 6.2 * s];
    return { hp, kn: kn_, an, ft, sa, th };
  };
  J.l1 = leg(th1, kn1, [-hipW * 0.7, 0]);
  J.l2 = leg(th2, kn2, [hipW * 0.7, 0]);
  const r = P[10] * DEG, c = Math.cos(r), sn = Math.sin(r);
  let low = -1e9;
  const pts = [[J.hip, 5 * gr * s], [J.sh, 6 * gr * s], [J.head, hr], [J.a1.el, 3 * s], [J.a1.hd, 3 * s], [J.a2.el, 3 * s], [J.a2.hd, 3 * s],
    [J.l1.kn, 4 * s], [J.l1.an, 3 * s], [J.l1.ft, 2 * s], [J.l2.kn, 4 * s], [J.l2.an, 3 * s], [J.l2.ft, 2 * s]];
  for (const [p, pad] of pts) { const y = p[0] * sn + p[1] * c + pad; if (y > low) low = y; }
  J.snap = -low;
  J.rot = P[10];
  return J;
}
