'use strict';
// ============================================================ CORE
const W = 426, H = 240;          // logical (world) units - gameplay space, unchanged
const PX = 2;                    // device pixels per logical unit (854x480 backbuffer)
// round a logical coordinate onto the device pixel grid
const RP = v => Math.round(v * PX) / PX;
const FPS = 60, STEP = 1000 / FPS;
const cv = document.getElementById('cv');
cv.width = W * PX; cv.height = H * PX;
const ctx = cv.getContext('2d');
ctx.imageSmoothingEnabled = false;

const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const sign = v => v < 0 ? -1 : v > 0 ? 1 : 0;
const rand = (a, b) => a + Math.random() * (b - a);
const irand = (a, b) => Math.floor(rand(a, b + 1));
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const chance = p => Math.random() < p;
const approach = (v, t, d) => v < t ? Math.min(v + d, t) : Math.max(v - d, t);
const fmt = n => Math.floor(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const DEG = Math.PI / 180;

// ------------------------------------------------------------ canvas fit
function fitCanvas() {
  const sw = window.innerWidth - 32, sh = window.innerHeight - 20;
  let s = Math.min(sw / W, sh / H);
  if (s >= 1) s = Math.floor(s * PX) / PX;
  s = Math.max(s, 0.5);
  cv.style.width = Math.round(W * s) + 'px';
  cv.style.height = Math.round(H * s) + 'px';
}
window.addEventListener('resize', fitCanvas);
fitCanvas();

// ------------------------------------------------------------ bitmap font 5x7
const GLYPHS = {
  A:[14,17,17,31,17,17,17],B:[30,17,17,30,17,17,30],C:[14,17,16,16,16,17,14],D:[30,17,17,17,17,17,30],
  E:[31,16,16,30,16,16,31],F:[31,16,16,30,16,16,16],G:[14,17,16,23,17,17,15],H:[17,17,17,31,17,17,17],
  I:[14,4,4,4,4,4,14],J:[7,2,2,2,2,18,12],K:[17,18,20,24,20,18,17],L:[16,16,16,16,16,16,31],
  M:[17,27,21,21,17,17,17],N:[17,17,25,21,19,17,17],O:[14,17,17,17,17,17,14],P:[30,17,17,30,16,16,16],
  Q:[14,17,17,17,21,18,13],R:[30,17,17,30,20,18,17],S:[15,16,16,14,1,1,30],T:[31,4,4,4,4,4,4],
  U:[17,17,17,17,17,17,14],V:[17,17,17,17,17,10,4],W:[17,17,17,21,21,21,10],X:[17,17,10,4,10,17,17],
  Y:[17,17,10,4,4,4,4],Z:[31,1,2,4,8,16,31],
  '0':[14,17,19,21,25,17,14],'1':[4,12,4,4,4,4,14],'2':[14,17,1,2,4,8,31],'3':[30,1,1,14,1,1,30],
  '4':[2,6,10,18,31,2,2],'5':[31,16,30,1,1,17,14],'6':[6,8,16,30,17,17,14],'7':[31,1,2,4,8,8,8],
  '8':[14,17,17,14,17,17,14],'9':[14,17,17,15,1,2,12],
  '.':[0,0,0,0,0,12,12],',':[0,0,0,0,12,4,8],':':[0,12,12,0,12,12,0],'!':[4,4,4,4,4,0,4],
  '?':[14,17,1,2,4,0,4],'-':[0,0,0,31,0,0,0],'+':[0,4,4,31,4,4,0],'/':[1,1,2,4,8,16,16],
  "'":[4,4,8,0,0,0,0],'"':[10,10,0,0,0,0,0],'(':[2,4,8,8,8,4,2],')':[8,4,2,2,2,4,8],
  '%':[25,25,2,4,8,19,19],'*':[0,21,14,31,14,21,0],'#':[10,10,31,10,31,10,10],'<':[2,4,8,16,8,4,2],
  '>':[8,4,2,1,2,4,8],'=':[0,0,31,0,31,0,0],'&':[12,18,20,8,21,18,13],'_':[0,0,0,0,0,0,31],
  '[':[14,8,8,8,8,8,14],']':[14,2,2,2,2,2,14],'$':[4,15,20,14,5,30,4],
  '↑':[4,14,21,4,4,4,0],'↓':[0,4,4,4,21,14,4],'←':[0,4,8,31,8,4,0],'→':[0,4,2,31,2,4,0],
  '★':[4,4,31,14,14,27,17],'•':[0,0,14,14,14,0,0],'×':[0,17,10,4,10,17,0],
};
const FONT_KEYS = Object.keys(GLYPHS);
const fontCache = new Map();
function fontAtlas(color) {
  let c = fontCache.get(color);
  if (c) return c;
  c = document.createElement('canvas');
  c.width = FONT_KEYS.length * 6; c.height = 7;
  const g = c.getContext('2d');
  g.fillStyle = color;
  FONT_KEYS.forEach((k, i) => {
    const rows = GLYPHS[k];
    for (let y = 0; y < 7; y++) for (let x = 0; x < 5; x++)
      if (rows[y] & (16 >> x)) g.fillRect(i * 6 + x, y, 1, 1);
  });
  const idx = {}; FONT_KEYS.forEach((k, i) => idx[k] = i);
  c.idx = idx;
  fontCache.set(color, c);
  return c;
}
function textWidth(str, s = 1) { return str.length * 6 * s - s; }
// align: 0 left, 1 center, 2 right
function text(str, x, y, color = '#fff', s = 1, align = 0, shadow = '#000') {
  str = String(str).toUpperCase();
  const w = textWidth(str, s);
  let sx = align === 1 ? Math.round(x - w / 2) : align === 2 ? x - w : x;
  if (shadow) drawText(str, sx + s, y + s, shadow, s);
  drawText(str, sx, y, color, s);
}
function drawText(str, x, y, color, s) {
  const a = fontAtlas(color);
  for (let i = 0; i < str.length; i++) {
    const k = a.idx[str[i]];
    if (k !== undefined) ctx.drawImage(a, k * 6, 0, 5, 7, x + i * 6 * s, y, 5 * s, 7 * s);
  }
}

// ------------------------------------------------------------ save
const SAVE_KEY = 'ragecircuit_save_v1';
function defaultSave() {
  return {
    v: 1,
    bank: 0,
    chars: {
      cole: { atk: 0, hp: 0, meter: 0, def: 0, starlock: false, freesp: false, xp: 0, perks: [], moves: [] },
      anita: { atk: 0, hp: 0, meter: 0, def: 0, starlock: false, freesp: false, xp: 0, perks: [], moves: [] },
      tank: { atk: 0, hp: 0, meter: 0, def: 0, starlock: false, freesp: false, xp: 0, perks: [], moves: [] },
      jett: { atk: 0, hp: 0, meter: 0, def: 0, starlock: false, freesp: false, xp: 0, perks: [], moves: [] },
      vex: { atk: 0, hp: 0, meter: 0, def: 0, starlock: false, freesp: false, xp: 0, perks: [], moves: [] },
      unit9: { atk: 0, hp: 0, meter: 0, def: 0, starlock: false, freesp: false, xp: 0, perks: [], moves: [] },
    },
    perksOwned: [],
    slots: 2,
    consumables: { life: 0, weapon: 0, rage: 0 },
    cheatsOwned: [],
    reached: 1,
    grades: {},     // key `${mode}_${diff}_${stage}` -> grade letter
    best: {},       // key `${mode}_${diff}` -> score
    unlocks: { vex: false, unit9: false, bossrush: false },
    cleared: false,
    endings: {},
    bossRushTimes: {},
    stats: { kos: 0, clears: 0 },
    options: { music: 7, sfx: 8, vibration: true, friendly: false, scanlines: false, flashing: true,
      pad: null, keys: null },
  };
}
let SAVE = defaultSave();
let storageOK = true;
function loadSave() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      const d = JSON.parse(raw);
      const base = defaultSave();
      SAVE = Object.assign(base, d);
      SAVE.options = Object.assign(defaultSave().options, d.options || {});
      SAVE.chars = Object.assign(defaultSave().chars, d.chars || {});
      for (const k in SAVE.chars) { SAVE.chars[k] = Object.assign(defaultSave().chars.cole, SAVE.chars[k]); if (!Array.isArray(SAVE.chars[k].moves)) SAVE.chars[k].moves = []; }
      SAVE.consumables = Object.assign(defaultSave().consumables, d.consumables || {});
      SAVE.unlocks = Object.assign(defaultSave().unlocks, d.unlocks || {});
      SAVE.endings = Object.assign({}, d.endings || {});
      SAVE.stats = Object.assign(defaultSave().stats, d.stats || {});
    }
  } catch (e) { storageOK = false; }
}
function writeSave() {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(SAVE)); return true; }
  catch (e) { storageOK = false; return false; }
}
function eraseSave() {
  const opts = SAVE.options;
  SAVE = defaultSave();
  SAVE.options = opts;
  writeSave();
}

// ------------------------------------------------------------ input
const PAD_NAMES = ['A','B','X','Y','LB','RB','LT','RT','BACK','START','LS','RS','UP','DOWN','LEFT','RIGHT','HOME'];
const DEFAULT_PAD = { attack: 2, jump: 0, special: 1, back: 3, pick: 4, ally: 5, start: 9 };
const DEFAULT_KEYS = { attack: 'KeyJ', jump: 'KeyK', special: 'KeyL', back: 'KeyU', pick: 'KeyI', ally: 'KeyO', start: 'Enter' };
const REMAP_ACTIONS = ['attack', 'jump', 'special', 'back', 'pick', 'ally'];
const ACTIONS = ['up','down','left','right','attack','jump','special','back','pick','ally','start','confirm','cancel'];

const Input = {
  held: {}, pressed: {}, released: {}, dbl: {},
  prev: {}, keys: new Set(), keyEdges: new Set(),
  frame: 0, lastTap: {}, pad: null, padPrev: [], padNow: [],
  lastDevice: 'key', anyEdge: false, heldFrames: {},
  padMap() { return Object.assign({}, DEFAULT_PAD, SAVE.options.pad || {}); },
  keyMap() { return Object.assign({}, DEFAULT_KEYS, SAVE.options.keys || {}); },
  getPad() {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    let best = null;
    for (const p of pads) { if (p && p.connected) { if (!best || p.mapping === 'standard') best = p; } }
    return best;
  },
  poll() {
    this.frame++;
    const k = this.keys, e = this.keyEdges;
    const km = this.keyMap(), pm = this.padMap();
    const pad = this.getPad();
    this.pad = pad;
    this.padPrev = this.padNow;
    this.padNow = pad ? pad.buttons.map(b => b.pressed || b.value > 0.5) : [];
    const pb = i => !!this.padNow[i];
    const ax = pad ? (pad.axes[0] || 0) : 0, ay = pad ? (pad.axes[1] || 0) : 0;
    const kk = (...codes) => codes.some(c => k.has(c));
    const ke = (...codes) => codes.some(c => e.has(c));
    const now = {
      up: kk('ArrowUp','KeyW') || pb(12) || ay < -0.5,
      down: kk('ArrowDown','KeyS') || pb(13) || ay > 0.5,
      left: kk('ArrowLeft','KeyA') || pb(14) || ax < -0.5,
      right: kk('ArrowRight','KeyD') || pb(15) || ax > 0.5,
    };
    const edge = {
      up: ke('ArrowUp','KeyW'), down: ke('ArrowDown','KeyS'),
      left: ke('ArrowLeft','KeyA'), right: ke('ArrowRight','KeyD'),
    };
    for (const a of ['attack','jump','special','back','pick','ally','start']) {
      now[a] = k.has(km[a]) || pb(pm[a]);
      edge[a] = e.has(km[a]);
    }
    now.confirm = kk('Enter','Space') || k.has(km.jump) || k.has(km.attack) || pb(0);
    edge.confirm = ke('Enter','Space') || e.has(km.jump) || e.has(km.attack);
    now.cancel = kk('Escape','Backspace') || k.has(km.special) || pb(1);
    edge.cancel = ke('Escape','Backspace') || e.has(km.special);
    if (now.start === false && k.has('Escape')) now.start = false;
    this.anyEdge = false;
    for (const a of ACTIONS) {
      const h = !!now[a];
      this.pressed[a] = (h && !this.prev[a]) || !!edge[a];
      this.released[a] = !h && !!this.prev[a];
      this.held[a] = h;
      this.heldFrames[a] = h ? (this.heldFrames[a] || 0) + 1 : 0;
      this.prev[a] = h;
      if (this.pressed[a]) this.anyEdge = true;
    }
    // escape doubles as pause
    if (e.has('Escape')) this.pressed.start = true;
    // double taps
    for (const d of ['left','right','up','down']) {
      this.dbl[d] = false;
      if (this.pressed[d]) {
        const last = this.lastTap[d];
        if (last !== undefined && this.frame - last <= 14) { this.dbl[d] = true; this.lastTap[d] = undefined; }
        else this.lastTap[d] = this.frame;
        const opp = { left:'right', right:'left', up:'down', down:'up' }[d];
        this.lastTap[opp] = undefined;
      }
    }
    if (this.padNow.some((v, i) => v && !this.padPrev[i])) { this.lastDevice = 'pad'; tryResumeAudio(); }
    e.clear();
  },
  rawPadPressed() {
    for (let i = 0; i < this.padNow.length; i++) if (this.padNow[i] && !this.padPrev[i]) return i;
    return -1;
  },
  clearAll() { for (const a of ACTIONS) { this.pressed[a] = false; } },
  lastRawKey: null,
};
window.addEventListener('keydown', ev => {
  if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space','Tab','Backspace'].includes(ev.code)) ev.preventDefault();
  if (!ev.repeat) { Input.keyEdges.add(ev.code); Input.lastRawKey = ev.code; }
  Input.keys.add(ev.code);
  Input.lastDevice = 'key';
  tryResumeAudio();
});
window.addEventListener('keyup', ev => Input.keys.delete(ev.code));
window.addEventListener('blur', () => Input.keys.clear());
window.addEventListener('mousedown', () => { tryResumeAudio(); cv.focus(); });

// menu navigation with hold-repeat. A frame that moves never also changes a value.
const Nav = { t: {} };
function navRepeat(dir) {
  if (Input.pressed[dir]) { Nav.t[dir] = 20; return true; }
  if (Input.held[dir]) {
    Nav.t[dir] = (Nav.t[dir] || 0) - 1;
    if (Nav.t[dir] <= 0) { Nav.t[dir] = 6; return true; }
  }
  return false;
}
function navV() { const u = navRepeat('up'), d = navRepeat('down'); return u && !d ? -1 : d && !u ? 1 : 0; }
function navH() { const l = navRepeat('left'), r = navRepeat('right'); return l && !r ? -1 : r && !l ? 1 : 0; }

// ------------------------------------------------------------ rumble
function rumble(strong, weak, ms) {
  if (!SAVE.options.vibration) return;
  const p = Input.pad;
  try {
    if (p && p.vibrationActuator && p.vibrationActuator.playEffect)
      p.vibrationActuator.playEffect('dual-rumble', { duration: ms, strongMagnitude: strong, weakMagnitude: weak });
  } catch (e) {}
}
