// ============================================================ DATA
const TUNING = {
  walkX: 1.75, walkY: 1.15, runX: 3.7, runY: 1.3,
  jumpV: 5.4, gravity: 0.33, jumpX: 1.9, runJumpX: 3.6,
  bandTop: 150, bandBot: 230,
  depthTol: 11,
  comboWindow: 16,      // frames a hit keeps the chain alive
  bufferFrames: 8,
  hitstopL: 3, hitstopH: 5, hitstopK: 7,
  hurtL: 14, hurtH: 18,
  downTime: 42, getupTime: 22, respawnInv: 120, getupInv: 44,
  // Anti-loop: standing up arms wakeGuard frames during which a knockdown hit
  // degrades to a heavy stun, so you can never be held in a knockdown loop.
  wakeGuard: 46,
  grabContact: 5, grabHold: 110, grabReach: 20,
  meterRefill: 1 / (60 * 7),   // full bar in 7 s
  specialHpCost: 7,
  comboTimeout: 75,
  oneUpEvery: 50000,
  starScores: [0, 30000, 80000],
  maxOnScreen: 6,
  powerTime: { rage: 900, iron: 900, overdrive: 720 },
};

// move helper. seq = [[pose, frames]...], hits = [{f:[a,b], x:[a,b], z:[a,b], dmg, type, kx, kz}]
function M(seq, hits = [], o = {}) {
  let total = 0; const at = [];
  for (const [p, n] of seq) { at.push([total, p, n]); total += n; }
  return Object.assign({ seq, at, total, hits: Array.isArray(hits) ? hits : [hits], cancel: total - 3 }, o);
}
function poseAt(mv, f) {
  for (let i = mv.at.length - 1; i >= 0; i--) if (f >= mv.at[i][0]) return mv.at[i][1];
  return mv.at[0][1];
}
const MOVES = {
  // ---------------- Cole
  jab1: M([['idle', 2], ['jab1', 5], ['idle', 5]], { f: [2, 4], x: [4, 31], z: [34, 54], dmg: 4, type: 'L' }, { cancel: 5, next: 'jab2', snd: 'hitL' }),
  jab2: M([['idle', 2], ['jab2', 5], ['idle', 5]], { f: [2, 4], x: [4, 31], z: [34, 54], dmg: 4, type: 'L' }, { cancel: 5, next: 'straight', snd: 'hitL' }),
  straight: M([['jab1', 2], ['straight', 6], ['idle', 6]], { f: [2, 5], x: [4, 34], z: [34, 54], dmg: 5, type: 'H' }, { cancel: 6, next: 'hook', step: [[2, 5, 1.2]], snd: 'hitL' }),
  hook: M([['hookA', 3], ['hook', 6], ['hookA', 5]], { f: [3, 6], x: [2, 30], z: [34, 56], dmg: 6, type: 'H' }, { cancel: 7, next: 'roundhouse', alt: 'crash', snd: 'hitH' }),
  roundhouse: M([['rhChamber', 5], ['roundhouse', 9], ['rhChamber', 4], ['idle', 5]], { f: [5, 9], x: [4, 40], z: [20, 54], dmg: 9, type: 'K', kx: 3.4, kz: 3.4 }, { cancel: 99, snd: 'hitH' }),
  crash: M([['blitz1', 4], ['crash', 11], ['idle', 7]], { f: [4, 11], x: [-2, 26], z: [10, 56], dmg: 10, type: 'K', kx: 6, kz: 2.4, proj: true }, { cancel: 99, step: [[4, 11, 3]], snd: 'hitX' }),
  backatk: M([['hookA', 3], ['backElbow', 9], ['idle', 6]], { f: [3, 7], x: [-34, -2], z: [28, 58], dmg: 7, type: 'K', kx: 2.8, kz: 2.8 }, { cancel: 99, snd: 'hitH' }),
  blitz: M([['blitz1', 8], ['blitz2', 12], ['jumpFall', 8]], { f: [3, 15], x: [-2, 30], z: [10, 72], dmg: 12, type: 'K', kx: 2, kz: 5.6 }, { cancel: 99, step: [[0, 9, 3.6], [9, 15, 1]], snd: 'hitX' }),
  haymaker: M([['haymaker', 12], ['idle', 8]], { f: [0, 6], x: [2, 42], z: [26, 58], dmg: 16, type: 'K', kx: 5, kz: 3 }, { cancel: 99, step: [[0, 6, 2.2]], snd: 'hitX' }),
  meteor: M([['haymaker', 14], ['idle', 10]], { f: [0, 7], x: [2, 46], z: [20, 60], dmg: 24, type: 'K', kx: 7.5, kz: 3, proj: true, fire: true }, { cancel: 99, step: [[0, 7, 3]], snd: 'hitX' }),
  specialN: M([['spin1', 5], ['spin2', 5], ['spin1', 5], ['spin3', 12], ['idle', 6]],
    [{ f: [2, 3], x: [-36, 36], z: [0, 70], dmg: 5, type: 'H' }, { f: [8, 9], x: [-36, 36], z: [0, 70], dmg: 5, type: 'H' },
     { f: [15, 20], x: [-38, 38], z: [0, 80], dmg: 8, type: 'K', kx: 3.2, kz: 4.4 }], { cancel: 99, inv: [0, 22], special: true, snd: 'hitH' }),
  specialF: M([['charge1', 6], ['dash', 18], ['idle', 8]],
    [{ f: [6, 8], x: [0, 32], z: [16, 60], dmg: 5, type: 'H' }, { f: [11, 13], x: [0, 32], z: [16, 60], dmg: 5, type: 'H' },
     { f: [16, 18], x: [0, 32], z: [16, 60], dmg: 5, type: 'H' }, { f: [21, 24], x: [0, 36], z: [10, 64], dmg: 8, type: 'K', kx: 4.5, kz: 3 }],
    { cancel: 99, step: [[6, 24, 4.2]], inv: [4, 20], special: true, snd: 'hitH' }),
  jknee: { air: true, pose: 'jumpKnee', hits: [{ f: [3, 99], x: [0, 26], z: [18, 50], dmg: 7, type: 'H' }] },
  jkick: { air: true, pose: 'jumpKick', hits: [{ f: [3, 99], x: [0, 34], z: [10, 52], dmg: 9, type: 'K', kx: 3, kz: 2.6 }] },
  jkick2: { air: true, seq: [['jumpKick', 11], ['jumpKick2', 99]], hits: [{ f: [3, 9], x: [0, 34], z: [10, 52], dmg: 6, type: 'H' }, { f: [13, 99], x: [0, 36], z: [10, 52], dmg: 7, type: 'K', kx: 3.2, kz: 2.8 }] },
  blitz2: M([['uppercutA', 4], ['uppercut', 12], ['jumpFall', 8]], { f: [4, 10], x: [-2, 30], z: [10, 80], dmg: 10, type: 'K', kx: 1.2, kz: 6.2 }, { cancel: 99, step: [[0, 6, 2]] }),
  // ---------------- Anita
  ak1: M([['aIdle', 1], ['aJab', 5], ['aIdle', 4]], { f: [1, 3], x: [4, 32], z: [36, 58], dmg: 4, type: 'L' }, { cancel: 4, next: 'ak2' }),
  ak2: M([['aIdle', 1], ['aLowKick', 6], ['aIdle', 4]], { f: [1, 4], x: [4, 38], z: [10, 40], dmg: 4, type: 'L' }, { cancel: 5, next: 'ak3' }),
  ak3: M([['aChamber', 2], ['aMidKick', 6], ['aIdle', 5]], { f: [2, 5], x: [4, 42], z: [20, 50], dmg: 5, type: 'H' }, { cancel: 6, next: 'ak4', step: [[2, 5, 1]] }),
  ak4: M([['aChamber', 3], ['aHighKick', 7], ['aIdle', 5]], { f: [3, 6], x: [4, 42], z: [36, 70], dmg: 6, type: 'H' }, { cancel: 7, next: 'ak5', alt: 'scissor' }),
  ak5: M([['aChamber', 5], ['aHeel', 10], ['aIdle', 6]], { f: [5, 9], x: [4, 46], z: [30, 72], dmg: 9, type: 'K', kx: 3.6, kz: 3.2 }, { cancel: 99 }),
  scissor: M([['aTuck', 4], ['aScissor', 12], ['land', 7]], { f: [4, 12], x: [-2, 40], z: [10, 60], dmg: 11, type: 'K', kx: 5.5, kz: 2.6, proj: true }, { cancel: 99, step: [[2, 12, 3.2]] }),
  aback: M([['aChamber', 3], ['aBackKick', 9], ['aIdle', 6]], { f: [3, 7], x: [-44, -2], z: [18, 52], dmg: 7, type: 'K', kx: 3, kz: 2.6 }, { cancel: 99 }),
  adash: M([['aSlide', 18], ['land', 8]], { f: [2, 15], x: [-2, 40], z: [0, 40], dmg: 11, type: 'K', kx: 2.6, kz: 4.8 }, { cancel: 99, step: [[0, 14, 4]] }),
  adashSpin: M([['aTornado1', 6], ['aTornado2', 6], ['aTornado1', 6], ['land', 8]],
    [{ f: [1, 6], x: [-10, 42], z: [20, 60], dmg: 7, type: 'H' }, { f: [9, 16], x: [-10, 44], z: [20, 60], dmg: 9, type: 'K', kx: 3.5, kz: 4.4 }], { cancel: 99, step: [[0, 16, 3.4]] }),
  aspN: M([['aHeli1', 5], ['aHeli2', 5], ['aHeli1', 5], ['aHeli2', 10], ['aIdle', 6]],
    [{ f: [2, 3], x: [-40, 40], z: [10, 60], dmg: 5, type: 'H' }, { f: [8, 9], x: [-40, 40], z: [10, 60], dmg: 5, type: 'H' },
     { f: [15, 20], x: [-42, 42], z: [10, 70], dmg: 8, type: 'K', kx: 3.2, kz: 4.4 }], { cancel: 99, inv: [0, 22], special: true }),
  aspF: M([['aChamber', 5], ['aDrive', 18], ['land', 8]],
    [{ f: [5, 9], x: [0, 34], z: [16, 60], dmg: 6, type: 'H' }, { f: [12, 16], x: [0, 34], z: [16, 60], dmg: 6, type: 'H' },
     { f: [19, 23], x: [0, 38], z: [10, 64], dmg: 9, type: 'K', kx: 4.5, kz: 3.4 }], { cancel: 99, step: [[5, 23, 4.6]], inv: [3, 20], special: true }),
  axe: M([['aAxeUp', 10], ['aAxeDown', 8], ['aIdle', 8]], { f: [10, 14], x: [4, 44], z: [0, 90], dmg: 16, type: 'K', kx: 2, kz: 2 }, { cancel: 99 }),
  ajknee: { air: true, pose: 'jumpKnee', hits: [{ f: [3, 99], x: [0, 28], z: [18, 50], dmg: 6, type: 'H' }] },
  ajkick: { air: true, pose: 'aFlyKick', hits: [{ f: [3, 99], x: [0, 40], z: [8, 50], dmg: 8, type: 'K', kx: 3, kz: 2.6 }] },
  ajkick2: { air: true, pose: 'aFlyKick2', hits: [{ f: [2, 99], x: [0, 40], z: [8, 50], dmg: 8, type: 'K', kx: 3.4, kz: 3 }] },
  athrow: { air: true, pose: 'aAirThrow', hits: [] },
  // ---------------- Tank (heavy grappler)
  k1: M([['kIdle', 3], ['kJab', 6], ['kIdle', 7]], { f: [3, 6], x: [4, 34], z: [32, 56], dmg: 6, type: 'L' }, { cancel: 7, next: 'k2', snd: 'hitL' }),
  k2: M([['kHookA', 3], ['kHook', 7], ['kIdle', 7]], { f: [3, 7], x: [2, 34], z: [32, 58], dmg: 7, type: 'H' }, { cancel: 8, next: 'k3', snd: 'hitH' }),
  k3: M([['kHookA', 4], ['kHook', 8], ['kIdle', 8]], { f: [4, 8], x: [2, 36], z: [30, 60], dmg: 9, type: 'H' }, { cancel: 9, next: 'k4', alt: 'kslam', snd: 'hitH' }),
  k4: M([['kSlamA', 7], ['kSlam', 10], ['kIdle', 9]], { f: [7, 11], x: [0, 40], z: [0, 66], dmg: 14, type: 'K', kx: 4, kz: 4 }, { cancel: 99, snd: 'hitX' }),
  kslam: M([['kSlamA', 6], ['kSlam', 12], ['kIdle', 9]], { f: [6, 12], x: [-2, 42], z: [0, 72], dmg: 16, type: 'K', kx: 2.4, kz: 5.2, proj: true }, { cancel: 99, step: [[4, 10, 1.6]], snd: 'hitX' }),
  kback: M([['kHookA', 4], ['kBack', 9], ['kIdle', 7]], { f: [4, 8], x: [-38, -2], z: [26, 58], dmg: 9, type: 'K', kx: 3.2, kz: 3 }, { cancel: 99, snd: 'hitH' }),
  kbull: M([['kBull', 6], ['kBull2', 6], ['kBull', 6], ['kBull2', 6], ['kIdle', 9]],
    { f: [2, 22], x: [-2, 30], z: [10, 64], dmg: 12, type: 'K', kx: 4.6, kz: 2.8 }, { cancel: 99, step: [[0, 24, 3.2]], snd: 'hitX' }),
  kbull3: M([['kBull', 6], ['kBull2', 6], ['kBull', 6], ['kBull2', 6], ['kBull', 6], ['kIdle', 9]],
    [{ f: [2, 8], x: [-2, 30], z: [10, 64], dmg: 6, type: 'H' }, { f: [10, 18], x: [-2, 30], z: [10, 64], dmg: 6, type: 'H' },
     { f: [20, 28], x: [-2, 32], z: [10, 66], dmg: 10, type: 'K', kx: 4.8, kz: 3 }], { cancel: 99, step: [[0, 30, 3.4]], snd: 'hitX' }),
  klariat: M([['kLariat1', 5], ['kLariat2', 5], ['kLariat1', 5], ['kLariat2', 5], ['kIdle', 8]],
    [{ f: [2, 3], x: [-40, 40], z: [20, 72], dmg: 6, type: 'H' }, { f: [7, 8], x: [-40, 40], z: [20, 72], dmg: 6, type: 'H' },
     { f: [12, 13], x: [-40, 40], z: [20, 72], dmg: 6, type: 'H' }, { f: [16, 19], x: [-44, 44], z: [16, 76], dmg: 10, type: 'K', kx: 3.6, kz: 4.2 }],
    { cancel: 99, inv: [0, 20], special: true, snd: 'hitH' }),
  klariat2: M([['kLariat1', 5], ['kLariat2', 5], ['kLariat1', 5], ['kLariat2', 5], ['kLariat1', 5], ['kLariat2', 5], ['kIdle', 8]],
    [{ f: [2, 3], x: [-42, 42], z: [20, 72], dmg: 6, type: 'H' }, { f: [7, 8], x: [-42, 42], z: [20, 72], dmg: 6, type: 'H' },
     { f: [12, 13], x: [-42, 42], z: [20, 72], dmg: 6, type: 'H' }, { f: [17, 18], x: [-42, 42], z: [20, 72], dmg: 6, type: 'H' },
     { f: [22, 25], x: [-46, 46], z: [16, 78], dmg: 11, type: 'K', kx: 3.8, kz: 4.4 }],
    { cancel: 99, inv: [0, 28], special: true, snd: 'hitH' }),
  kquake: M([['kGutA', 6], ['kBull', 8], ['kBull2', 8], ['kQuakeA', 6], ['kQuake', 8], ['kIdle', 8]],
    [{ f: [6, 20], x: [0, 32], z: [10, 62], dmg: 7, type: 'H' }, { f: [27, 31], x: [-34, 42], z: [0, 44], dmg: 13, type: 'K', kx: 3.6, kz: 4.4, proj: true }],
    { cancel: 99, step: [[6, 22, 4.2]], inv: [4, 20], special: true, snd: 'hitX' }),
  kgut: M([['kGutA', 8], ['kGut', 10], ['kIdle', 9]], { f: [8, 13], x: [2, 40], z: [24, 58], dmg: 19, type: 'K', kx: 5, kz: 3 }, { cancel: 99, step: [[8, 13, 2.2]], snd: 'hitX' }),
  kquake2: M([['kQuakeA', 10], ['kQuake', 10], ['kIdle', 10]], { f: [10, 15], x: [-42, 48], z: [0, 40], dmg: 27, type: 'K', kx: 6, kz: 4.6, proj: true }, { cancel: 99, quake: true, snd: 'hitX' }),
  kclutch: M([['kReach', 7], ['kClutch', 8], ['kIdle', 10]], { f: [7, 13], x: [4, 44], z: [18, 62], dmg: 2, type: 'L', grabs: true }, { cancel: 99, step: [[5, 12, 2.4]] }),
  kclutchL: M([['kReach', 6], ['kClutch', 10], ['kIdle', 9]], { f: [6, 15], x: [4, 62], z: [14, 66], dmg: 2, type: 'L', grabs: true }, { cancel: 99, step: [[4, 14, 3.4]] }),
  kjknee: { air: true, pose: 'kKnee', hits: [{ f: [3, 99], x: [0, 28], z: [14, 50], dmg: 9, type: 'H' }] },
  kjsplash: { air: true, pose: 'kSplash', hits: [{ f: [3, 99], x: [-14, 30], z: [0, 46], dmg: 12, type: 'K', kx: 2.6, kz: 2.8 }] },
  // ---------------- Jett (speedster)
  j1: M([['jIdle', 1], ['jJab', 4], ['jIdle', 4]], { f: [1, 3], x: [4, 30], z: [34, 56], dmg: 3, type: 'L' }, { cancel: 4, next: 'j2' }),
  j2: M([['jIdle', 1], ['jJab2', 4], ['jIdle', 4]], { f: [1, 3], x: [4, 31], z: [34, 56], dmg: 3, type: 'L' }, { cancel: 4, next: 'j3' }),
  j3: M([['jIdle', 1], ['jElbow', 5], ['jIdle', 4]], { f: [1, 4], x: [2, 30], z: [30, 54], dmg: 4, type: 'L' }, { cancel: 5, next: 'j4' }),
  j4: M([['jIdle', 2], ['jLow', 5], ['jIdle', 5]], { f: [2, 5], x: [4, 36], z: [10, 38], dmg: 5, type: 'H' }, { cancel: 6, next: 'j5', alt: 'jdrill' }),
  j5: M([['jSpinA', 4], ['jSpin', 8], ['jIdle', 6]], { f: [4, 8], x: [4, 44], z: [26, 70], dmg: 9, type: 'K', kx: 3.8, kz: 3.2 }, { cancel: 99 }),
  jdrill: M([['jSpinA', 3], ['jDrill', 12], ['land', 6]], { f: [3, 12], x: [0, 40], z: [8, 58], dmg: 11, type: 'K', kx: 4.6, kz: 2.6, proj: true }, { cancel: 99, step: [[2, 12, 3.6]] }),
  jback: M([['jSpinA', 3], ['jBack', 8], ['jIdle', 5]], { f: [3, 7], x: [-42, -2], z: [18, 52], dmg: 7, type: 'K', kx: 3, kz: 2.6 }, { cancel: 99 }),
  jslide: M([['jSlide', 16], ['land', 7]], { f: [2, 13], x: [-2, 42], z: [0, 36], dmg: 10, type: 'K', kx: 2.4, kz: 4.6 }, { cancel: 99, step: [[0, 13, 4.6]] }),
  jslide2: M([['jSlide', 20], ['land', 7]], [{ f: [2, 8], x: [-2, 42], z: [0, 36], dmg: 6, type: 'H' }, { f: [10, 18], x: [-2, 44], z: [0, 38], dmg: 8, type: 'K', kx: 2.6, kz: 4.8 }], { cancel: 99, step: [[0, 18, 5]] }),
  jheli: M([['jHeli1', 4], ['jHeli2', 4], ['jHeli1', 4], ['jHeli2', 9], ['jIdle', 6]],
    [{ f: [2, 3], x: [-38, 38], z: [10, 66], dmg: 5, type: 'H' }, { f: [7, 8], x: [-38, 38], z: [10, 66], dmg: 5, type: 'H' },
     { f: [13, 18], x: [-40, 40], z: [10, 78], dmg: 9, type: 'K', kx: 3, kz: 4.6 }], { cancel: 99, inv: [0, 20], special: true }),
  jrush: M([['jDash', 4], ['jJab', 3], ['jJab2', 3], ['jJab', 3], ['jJab2', 3], ['jElbow', 6], ['jIdle', 7]],
    [{ f: [4, 6], x: [0, 32], z: [16, 58], dmg: 4, type: 'L' }, { f: [7, 9], x: [0, 32], z: [16, 58], dmg: 4, type: 'L' },
     { f: [10, 12], x: [0, 32], z: [16, 58], dmg: 4, type: 'L' }, { f: [13, 15], x: [0, 32], z: [16, 58], dmg: 4, type: 'L' },
     { f: [16, 20], x: [0, 36], z: [10, 62], dmg: 9, type: 'K', kx: 4.4, kz: 3 }], { cancel: 99, step: [[0, 18, 3.8]], inv: [2, 18], special: true }),
  jupper: M([['jUpperA', 5], ['jUpper', 12], ['jumpFall', 8]], { f: [5, 11], x: [-2, 30], z: [10, 84], dmg: 16, type: 'K', kx: 1.4, kz: 6.4 }, { cancel: 99, step: [[0, 6, 2]] }),
  jjknee: { air: true, pose: 'jumpKnee', hits: [{ f: [3, 99], x: [0, 26], z: [18, 50], dmg: 5, type: 'H' }] },
  jjfly: { air: true, pose: 'jFly', hits: [{ f: [3, 99], x: [0, 38], z: [8, 50], dmg: 7, type: 'K', kx: 2.8, kz: 2.4 }] },
  jjfly2: { air: true, pose: 'jFly2', hits: [{ f: [2, 99], x: [0, 38], z: [8, 50], dmg: 7, type: 'K', kx: 3, kz: 2.8 }] },
  jdash: { air: true, pose: 'jDash', hits: [] },
  // mastery 5: the air-down drop, one per fighter
  cElbow: { air: true, drop: 5.6, pose: 'elbowDrop', shock: 52, hits: [{ f: [2, 99], x: [-10, 30], z: [0, 46], dmg: 14, type: 'K', kx: 2.4, kz: 3.2 }] },
  aHeelDrop: { air: true, drop: 5.2, pose: 'aAxeDown', shock: 44, hits: [{ f: [2, 99], x: [0, 36], z: [0, 50], dmg: 12, type: 'K', kx: 2.2, kz: 3.4 }] },
  kPress: { air: true, drop: 6.2, pose: 'kSplash', shock: 74, hits: [{ f: [2, 99], x: [-16, 32], z: [0, 44], dmg: 16, type: 'K', kx: 2.6, kz: 3 }] },
  jMeteor: { air: true, drop: 6.4, pose: 'jDrill', shock: 40, hits: [{ f: [2, 99], x: [-6, 32], z: [0, 48], dmg: 11, type: 'K', kx: 2.2, kz: 3.6 }] },
  // mastery 6: the forward special, upgraded
  specialFP: M([['charge1', 5], ['dash', 22], ['idle', 8]],
    [{ f: [5, 7], x: [0, 34], z: [16, 60], dmg: 6, type: 'H' }, { f: [10, 12], x: [0, 34], z: [16, 60], dmg: 6, type: 'H' },
     { f: [15, 17], x: [0, 34], z: [16, 60], dmg: 6, type: 'H' }, { f: [20, 22], x: [0, 34], z: [16, 60], dmg: 6, type: 'H' },
     { f: [25, 28], x: [0, 40], z: [10, 66], dmg: 12, type: 'K', kx: 5.2, kz: 3.4, fire: true }],
    { cancel: 99, step: [[5, 28, 4.6]], inv: [4, 24], special: true, snd: 'hitH' }),
  aspFP: M([['aChamber', 4], ['aDrive', 22], ['land', 8]],
    [{ f: [4, 8], x: [0, 36], z: [16, 60], dmg: 7, type: 'H' }, { f: [11, 15], x: [0, 36], z: [16, 60], dmg: 7, type: 'H' },
     { f: [18, 22], x: [0, 36], z: [16, 60], dmg: 7, type: 'H' }, { f: [24, 28], x: [0, 42], z: [10, 68], dmg: 12, type: 'K', kx: 5.2, kz: 3.8, fire: true }],
    { cancel: 99, step: [[4, 28, 5]], inv: [3, 24], special: true }),
  kquakeP: M([['kGutA', 5], ['kBull', 8], ['kBull2', 8], ['kBull', 8], ['kQuakeA', 5], ['kQuake', 9], ['kIdle', 8]],
    [{ f: [5, 28], x: [0, 34], z: [10, 64], dmg: 9, type: 'H' }, { f: [34, 39], x: [-40, 48], z: [0, 46], dmg: 17, type: 'K', kx: 4.2, kz: 4.8, proj: true, fire: true }],
    { cancel: 99, step: [[5, 30, 4.6]], inv: [4, 26], special: true, snd: 'hitX' }),
  jrushP: M([['jDash', 3], ['jJab', 3], ['jJab2', 3], ['jJab', 3], ['jJab2', 3], ['jJab', 3], ['jJab2', 3], ['jElbow', 6], ['jIdle', 7]],
    [{ f: [3, 5], x: [0, 34], z: [16, 58], dmg: 5, type: 'L' }, { f: [6, 8], x: [0, 34], z: [16, 58], dmg: 5, type: 'L' },
     { f: [9, 11], x: [0, 34], z: [16, 58], dmg: 5, type: 'L' }, { f: [12, 14], x: [0, 34], z: [16, 58], dmg: 5, type: 'L' },
     { f: [15, 17], x: [0, 34], z: [16, 58], dmg: 5, type: 'L' }, { f: [18, 20], x: [0, 34], z: [16, 58], dmg: 5, type: 'L' },
     { f: [21, 26], x: [0, 40], z: [10, 64], dmg: 12, type: 'K', kx: 5, kz: 3.2, fire: true }],
    { cancel: 99, step: [[0, 24, 4.2]], inv: [2, 22], special: true }),
  pickup: M([['pickup', 10]], [], { cancel: 99 }),
  // grapples (damage applied by script, not boxes)
  knee: M([['kneePrep', 4], ['knee', 8], ['grab', 6]], [], { cancel: 99 }),
  throwMv: M([['liftA', 12], ['liftB', 14]], [], { cancel: 99 }),
  suplex: M([['sup1', 8], ['sup2', 10], ['sup3', 16], ['getup', 10]], [], { cancel: 99 }),
  screenThrow: M([['liftA', 16], ['liftB', 18]], [], { cancel: 99 }),
  // weapons
  wpn1: M([['wpnWind', 4], ['wpnSwing', 7], ['idle', 6]], { f: [4, 7], x: [4, 46], z: [20, 60], dmg: 8, type: 'H' }, { cancel: 7, next: 'wpn2', snd: 'clank' }),
  wpn2: M([['wpnWind', 4], ['wpnSwing', 7], ['idle', 6]], { f: [4, 7], x: [4, 46], z: [20, 60], dmg: 8, type: 'H' }, { cancel: 7, next: 'wpn3', snd: 'clank' }),
  wpn3: M([['wpnHigh', 7], ['wpnChop', 9], ['idle', 8]], { f: [7, 10], x: [4, 46], z: [10, 70], dmg: 12, type: 'K', kx: 3.5, kz: 3.5 }, { cancel: 99, snd: 'clank' }),
  kn1: M([['slash1', 3], ['slash2', 5], ['idle', 5]], { f: [3, 5], x: [4, 32], z: [26, 58], dmg: 7, type: 'H' }, { cancel: 6, next: 'kn2', snd: 'knife' }),
  kn2: M([['slash1', 3], ['slash2', 5], ['idle', 5]], { f: [3, 5], x: [4, 32], z: [26, 58], dmg: 7, type: 'H' }, { cancel: 6, next: 'kn3', snd: 'knife' }),
  kn3: M([['slash1', 5], ['slash2', 8], ['idle', 7]], { f: [5, 8], x: [4, 34], z: [20, 60], dmg: 10, type: 'K', kx: 3, kz: 3 }, { cancel: 99, snd: 'knife' }),
  wpnSpecial: M([['spin1', 4], ['spin2', 4], ['spin1', 4], ['spin2', 4], ['spin3', 8], ['idle', 5]],
    [{ f: [2, 3], x: [-46, 46], z: [0, 70], dmg: 7, type: 'H' }, { f: [10, 11], x: [-46, 46], z: [0, 70], dmg: 7, type: 'H' },
     { f: [16, 20], x: [-48, 48], z: [0, 80], dmg: 10, type: 'K', kx: 3.5, kz: 4 }], { cancel: 99, inv: [0, 18], special: true, snd: 'clank' }),
  toss: M([['tossA', 6], ['tossB', 8]], [], { cancel: 99 }),
  // ---------------- enemies
  ePunch: M([['idle', 9], ['jab1', 6], ['idle', 12]], { f: [9, 11], x: [4, 30], z: [32, 54], dmg: 5, type: 'L' }, { cancel: 99, snd: 'hitL' }),
  ePunch2: M([['hookA', 6], ['straight', 7], ['idle', 16]], { f: [6, 9], x: [4, 32], z: [32, 54], dmg: 6, type: 'K', kx: 2.6, kz: 2.2 }, { cancel: 99, snd: 'hitH' }),
  eSlash: M([['slash1', 12], ['slash2', 7], ['idle', 14]], { f: [12, 15], x: [4, 34], z: [26, 58], dmg: 8, type: 'H' }, { cancel: 99, snd: 'knife' }),
  eSwing: M([['wpnWind', 14], ['wpnSwing', 8], ['idle', 16]], { f: [14, 17], x: [4, 44], z: [20, 60], dmg: 10, type: 'K', kx: 3, kz: 2.8 }, { cancel: 99, snd: 'clank' }),
  eToss: M([['tossA', 18], ['tossB', 12]], [], { cancel: 99 }),
  eHay: M([['charge1', 20], ['haymaker', 10], ['idle', 18]], { f: [20, 26], x: [2, 40], z: [26, 64], dmg: 12, type: 'K', kx: 4, kz: 3 }, { cancel: 99, step: [[20, 26, 1.8]], snd: 'hitX' }),
  eReach: M([['reach', 16], ['idle', 18]], [], { cancel: 99 }),
  eRush: M([['paw1', 8], ['paw2', 8], ['charge', 6], ['charge2', 6], ['charge', 6], ['charge2', 6], ['idle', 16]],
    { f: [16, 40], x: [0, 30], z: [10, 64], dmg: 10, type: 'K', kx: 4, kz: 3 }, { cancel: 99, step: [[16, 40, 3.8]], snd: 'hitH' }),
  eWhip: M([['wWind', 18], ['wCrack', 12], ['idle', 16]], { f: [18, 22], x: [10, 72], z: [24, 60], dmg: 8, type: 'H' }, { cancel: 99 }),
  eKick: M([['rhChamber', 11], ['roundhouse', 8], ['idle', 14]], { f: [11, 15], x: [4, 40], z: [16, 52], dmg: 7, type: 'K', kx: 2.4, kz: 2.4 }, { cancel: 99, snd: 'hitH' }),
  eSlam: M([['pileLift', 40], ['pileDrop', 14], ['idle', 16]], [], { cancel: 99 }),
};

const DIFFS = [
  { name: 'EASY',   hp: 0.8,  dmg: 0.6,  tokens: 1, react: 48, extra: -1, drop: 1.25, bank: 0.5, boss: 0, col: '#5ad06a' },
  { name: 'MEDIUM', hp: 1.0,  dmg: 1.0,  tokens: 2, react: 30, extra: 0,  drop: 1.0,  bank: 1.0, boss: 1, col: '#e8d040' },
  { name: 'HARD',   hp: 1.2,  dmg: 1.35, tokens: 3, react: 20, extra: 1,  drop: 0.8,  bank: 1.5, boss: 2, col: '#f08030' },
  { name: 'MANIA',  hp: 1.4 * 1.25, dmg: 1.7, tokens: 3, react: 12, extra: 2, drop: 0.6, bank: 2.0, boss: 3, col: '#e8283a' },
];
const GRADES = [
  { g: 'S', min: 90, mult: 1.5, col: '#f2c94c' },
  { g: 'A', min: 75, mult: 1.3, col: '#e8e8f0' },
  { g: 'B', min: 55, mult: 1.1, col: '#4ac0e8' },
  { g: 'C', min: 35, mult: 0.95, col: '#5ad06a' },
  { g: 'D', min: -999, mult: 0.8, col: '#b08a8a' },
];
const GRADE_ORDER = 'SABCD';

const KITS = {
  cole: { name: 'COLE', combo: 'jab1', back: 'backatk', blitz: 'blitz', blitzFollow: 'blitz2', spN: 'specialN', spF: 'specialF',
    jN: 'jknee', jF: 'jkick', jFUp: 'jkick2', hold1: 'haymaker', hold2: 'meteor', hold2T: 90, look: 'cole', cpuLook: 'coleCPU',
    jumps: 1, speed: 1, grabPose: 'grab',
    airThrow: 'aAirThrow', airDown: 'cElbow', spFPlus: 'specialFP' },
  anita: { name: 'ANITA', combo: 'ak1', back: 'aback', blitz: 'adash', blitzAlt: 'adashSpin', blitzAltId: 'spindash', spN: 'aspN', spF: 'aspF',
    jN: 'ajknee', jF: 'ajkick', air2: 'ajkick2', hold1: null, hold2: 'axe', hold2T: 40, look: 'anita', cpuLook: 'anitaCPU',
    jumps: 2, speed: 1.12, jump: 1.08,
    airThrow: 'aAirThrow', airDown: 'aHeelDrop', spFPlus: 'aspFP' },
  tank: { name: 'TANK', combo: 'k1', back: 'kback', blitz: 'kbull', blitzAlt: 'kbull3', blitzAltId: 'bulldoze',
    spN: 'klariat', spNAlt: 'klariat2', spNAltId: 'longarm', spF: 'kquake',
    jN: 'kjknee', jF: 'kjsplash', hold1: 'kgut', hold2: 'kquake2', hold2T: 95, look: 'tank', cpuLook: 'tankCPU',
    jumps: 1, speed: 0.86, jump: 0.92, grabMove: 'kclutch', grabMoveAlt: 'kclutchL', grabMoveAltId: 'clutchx', grabPose: 'grab',
    airThrow: 'kLift', airDown: 'kPress', spFPlus: 'kquakeP' },
  jett: { name: 'JETT', combo: 'j1', back: 'jback', blitz: 'jslide', blitzAlt: 'jslide2', blitzAltId: 'boost',
    spN: 'jheli', spF: 'jrush', jN: 'jjknee', jF: 'jjfly', air2: 'jjfly2', hold1: null, hold2: 'jupper', hold2T: 44,
    look: 'jett', cpuLook: 'jettCPU', jumps: 1, speed: 1.26, jump: 1.04, airDash: 'jdash', airDashes: 1,
    airThrow: 'aAirThrow', airDown: 'jMeteor', spFPlus: 'jrushP' },
};
KITS.vex = Object.assign({}, KITS.anita, { name: 'VEX', look: 'vex', cpuLook: 'vexCPU', speed: 1.16, jump: 1.0, jumps: 1,
  hold2: 'scissor', hold2T: 50 });
KITS.unit9 = Object.assign({}, KITS.tank, { name: 'UNIT-9', look: 'unit9', cpuLook: 'unit9CPU', speed: 0.98, jump: 0.96,
  grabMove: 'kclutchL', hold2T: 80 });
const SPECIAL_NAMES = ['DONOVAN', 'Y SIGNAL', 'SQUIDWARD', 'DOOSH', 'SERGE'];
const ENEMY_TYPES = {
  punk:    { hp: 30, speed: 1.1, pts: 500, looks: ['punkA', 'punkB', 'punkC'], names: ['SLADE', 'DUKE', 'RAZZ', 'GUNNER', 'MOTOR', 'SPIKE'], w: 11 },
  blade:   { hp: 34, speed: 1.25, pts: 700, looks: ['bladeA', 'bladeB'], names: ['JACKAL', 'VIPER', 'SHIV', 'ROXY'], w: 11, weapon: 'knife' },
  bruiser: { hp: 80, speed: 0.8, pts: 1500, looks: ['bruiserA', 'bruiserB'], names: ['HAMMER', 'OX', 'BULLDOG', 'TANKER'], w: 16, heavy: true },
  kicker:  { hp: 32, speed: 1.5, pts: 800, looks: ['kickerA', 'kickerB'], names: ['SWITCH', 'FLICK', 'NOVA', 'DART'], w: 10 },
  whip:    { hp: 36, speed: 1.1, pts: 900, looks: ['whipA', 'whipB'], names: ['LASH', 'VELVET', 'CANDY', 'SABLE'], w: 10, weapon: 'whip' },
  robot:   { hp: 90, speed: 0.85, pts: 2500, looks: ['robot'], names: ['SX-7', 'SX-9', 'UNIT-4', 'DRONE'], w: 13, robot: true, heavy: true },
  dummy:   { hp: 9999, speed: 0.9, pts: 0, looks: ['dummy'], names: ['DUMMY'], w: 11 },
  suit:    { hp: 46, speed: 1.3, pts: 1200, looks: ['suitA', 'suitB'], names: ['MERCER', 'HOLT', 'PAIGE', 'CRANE', 'DELACOUR'], w: 11 },
  guard:   { hp: 54, speed: 1.0, pts: 1300, looks: ['guardA', 'guardB'], names: ['POST 4', 'POST 7', 'WARD', 'KEEL', 'BOLT'], w: 12, weapon: 'pipe' },
  biker:   { hp: 42, speed: 1.45, pts: 1100, looks: ['bikerA', 'bikerB'], names: ['REDLINE', 'TORQUE', 'COGS', 'ASH', 'MAVERICK'], w: 11, weapon: 'knife' },
  hvbot:   { hp: 126, speed: 0.78, pts: 3400, looks: ['robotB'], names: ['SX-11', 'SX-12', 'UNIT-6', 'HEAVY'], w: 15, robot: true, heavy: true },
};
const BOSS_DEFS = {
  brick: { name: 'BIG BRICK HARLAN', sub: 'SYNDICATE MUSCLE', hp: 420, pts: 20000, look: 'brick', w: 22, h: 88, type: 'brick', speed: 0.95 },
  ruby: { name: 'RUBY', sub: 'THE VOSS TWINS', hp: 230, pts: 12000, look: 'ruby', w: 11, h: 64, type: 'twin', speed: 1.6 },
  onyx: { name: 'ONYX', sub: 'THE VOSS TWINS', hp: 230, pts: 12000, look: 'onyx', w: 11, h: 64, type: 'twin', speed: 1.6 },
  mech: { name: 'WRECKER MK-II', sub: 'SYNDICATE CONSTRUCTION MECH', hp: 520, pts: 25000, look: 'mech', w: 34, h: 110, type: 'mech', speed: 0.6 },
  rivet: { name: 'RIVET', sub: 'THE PILOT', hp: 170, pts: 10000, look: 'rivet', w: 14, h: 70, type: 'brick', speed: 1.2, mini: true },
  gauge: { name: 'GAUGE HOLLIS', sub: 'RAIL CREW BOSS', hp: 480, pts: 22000, look: 'gauge', w: 22, h: 88, type: 'brick', speed: 1.05 },
  vexb: { name: 'VEX', sub: 'SYNDICATE ENFORCER', hp: 430, pts: 26000, look: 'vex', w: 12, h: 66, type: 'vex', speed: 1.7 },
  slag: { name: 'SLAG', sub: 'FOUNDRY FOREMAN', hp: 580, pts: 28000, look: 'slag', w: 24, h: 92, type: 'brick', speed: 0.92, fire: true },
  warden: { name: 'UNIT-8 "WARDEN"', sub: 'LAB PROTOTYPE', hp: 560, pts: 30000, look: 'warden', w: 20, h: 86, type: 'brick', speed: 1.0,
    robot: true, beam: true, noPole: true },
  dray: { name: 'MARQUESS DRAY', sub: 'HEAD OF THE SYNDICATE', hp: 400, pts: 30000, look: 'dray', w: 12, h: 66, type: 'vex', speed: 1.45,
    next: 'drayx', noPole: true },
  drayx: { name: 'DRAY // WARLORD FRAME', sub: 'THE LAST FIGHT', hp: 680, pts: 70000, look: 'drayx', w: 22, h: 92, type: 'brick',
    speed: 1.15, dmgMult: 1.15, final: true },
  // stage 8 rematches: old faces, paid better, angrier
  brick2: { name: 'BIG BRICK HARLAN', sub: 'BACK FOR THE REMATCH', hp: 540, pts: 26000, look: 'brick', w: 22, h: 88, type: 'brick', speed: 1.1 },
  ruby2: { name: 'RUBY', sub: 'THE VOSS TWINS, AGAIN', hp: 300, pts: 15000, look: 'ruby', w: 11, h: 64, type: 'twin', speed: 1.75 },
  onyx2: { name: 'ONYX', sub: 'THE VOSS TWINS, AGAIN', hp: 300, pts: 15000, look: 'onyx', w: 11, h: 64, type: 'twin', speed: 1.75 },
  rivet2: { name: 'RIVET', sub: 'WITHOUT HIS MECH THIS TIME', hp: 280, pts: 14000, look: 'rivet', w: 14, h: 70, type: 'brick', speed: 1.35, mini: true },
};
// the order Boss Rush runs them in
const BOSS_RUSH = ['brick', 'ruby', 'mech', 'gauge', 'vexb', 'slag', 'warden', 'drayx'];
const BOSS_DEF = BOSS_DEFS.brick;

// ------------------------------------------------------------ shop
const TIER_PRICES = [30000, 60000, 110000, 180000, 280000];
const STAT_UPS = [
  { id: 'atk', name: 'ATTACK POWER', desc: '+10% damage per tier', per: '+10%' },
  { id: 'hp', name: 'MAX HEALTH', desc: '+10% health per tier', per: '+10%' },
  { id: 'meter', name: 'SPECIAL REFILL', desc: '+10% meter speed per tier', per: '+10%' },
  { id: 'def', name: 'DEFENSE', desc: '-6% damage taken per tier', per: '-6%' },
];
const CAPSTONES = [
  { id: 'starlock', name: 'STAR LOCK', price: 700000, desc: 'Start at max stars. Stars never lost.' },
  { id: 'freesp', name: 'FREE SPECIALS', price: 700000, desc: 'Specials never cost health.' },
];
const PERKS = [
  { id: 'armed', name: 'ARMED START', price: 25000, desc: 'Start every stage holding a pipe.' },
  { id: 'hearty', name: 'HEARTY EATER', price: 20000, desc: 'Food heals 50% more.' },
  { id: 'longpow', name: 'LONG FUSE', price: 30000, desc: 'Power-ups last 50% longer.' },
  { id: 'tough', name: 'IRON GRIP', price: 20000, desc: 'Weapons last twice as long.' },
  { id: 'reach', name: 'LONG ARMS', price: 35000, desc: 'Grab enemies from further away.' },
  { id: 'starter', name: 'HEAD START', price: 60000, desc: 'Start every stage with 2 stars.' },
];
const SLOT_PRICES = { 3: 90000, 4: 220000 };
const CONSUMABLES = [
  { id: 'life', name: 'EXTRA LIFE', price: 8000, desc: '+1 life at the next stage start.' },
  { id: 'weapon', name: 'STARTER PIPE', price: 5000, desc: 'Hold a pipe at the next stage start.' },
  { id: 'rage', name: 'RAGE SHOT', price: 10000, desc: 'Rage for the first 20 s of the next stage.' },
];
const SHOP_CHEATS = [
  { id: 'bigheads', name: 'BIG HEADS', price: 25000, desc: 'Everyone gets a huge head.' },
  { id: 'turbo', name: 'TURBO LEGS', price: 40000, desc: 'You move 40% faster.' },
  { id: 'wrain', name: 'WEAPON RAIN', price: 35000, desc: 'Weapons fall from the sky.' },
];
const SHOP_UNLOCKS = [
  { id: 'bossrush', name: 'BOSS RUSH', price: 250000, desc: 'Every boss, back to back, against the clock.' },
  { id: 'soundtest', name: 'SOUND TEST', price: 15000, desc: 'Play any music track.' },
  { id: 'gallery', name: 'GALLERY', price: 20000, desc: 'Enemy and boss files.' },
];
const MASTERY_XP = [0, 600, 1600, 3000, 4800, 7000, 9600, 12600, 16000, 20000];
const SHOP_MOVES = {
  cole: [
    { id: 'blitz2', name: 'BLITZ FOLLOW-UP', price: 60000, desc: 'After a Blitz lands, press X again for a launching uppercut.' },
    { id: 'dkick', name: 'DOUBLE FLYING KICK', price: 50000, desc: 'Your moving jump kick hits twice.' },
  ],
  anita: [
    { id: 'triple', name: 'TRIPLE JUMP', price: 70000, desc: 'A third jump in the air.' },
    { id: 'aircombo', name: 'AIR COMBO', price: 60000, desc: 'After an air kick lands, press X again for a second kick.' },
    { id: 'spindash', name: 'SPINNING DASH KICK', price: 60000, desc: 'Her dash kick spins and hits twice.' },
    { id: 'stiletto', name: 'STILETTO THROW', price: 80000, desc: 'Press B in the air to throw a knife. Uses the SP bar, or health.' },
  ],
  tank: [
    { id: 'clutchx', name: 'LONG CLUTCH', price: 70000, desc: 'The running clutch reaches much further and pulls harder.' },
    { id: 'bulldoze', name: 'BULLDOZER', price: 50000, desc: 'His running shoulder plows on and hits three times.' },
    { id: 'longarm', name: 'DOUBLE LARIAT', price: 60000, desc: 'The lariat spins twice as long.' },
    { id: 'ironhide', name: 'IRON HIDE', price: 80000, desc: 'He shrugs off the first hit of any charge attack.' },
  ],
  jett: [
    { id: 'airdash2', name: 'DOUBLE AIR DASH', price: 60000, desc: 'Two air dashes per jump.' },
    { id: 'aircombo', name: 'AIR COMBO', price: 60000, desc: 'After an air kick lands, press X again for a second kick.' },
    { id: 'boost', name: 'BOOST SLIDE', price: 50000, desc: 'The slide kick travels further and hits twice.' },
    { id: 'afterburn', name: 'AFTERBURN', price: 80000, desc: 'The air dash burns anyone it passes through.' },
  ],
};
SHOP_MOVES.vex = SHOP_MOVES.anita;
SHOP_MOVES.unit9 = SHOP_MOVES.tank;
const MASTERY_BY_CHAR = {};
const MASTERY_MOVES = [
  null,
  { name: 'CRASH SHOULDER', input: '4TH HIT: → + X', live: true },
  { name: 'METEOR HAYMAKER', input: 'HOLD X LONGER', live: true },
  { name: 'AIR THROW', input: 'X ON A JUMPING FOE', live: true },
  { name: 'ELBOW DROP', input: 'AIR: DOWN + X', live: true },
  { name: 'BURNING CHARGE+', input: '-> + B (UPGRADED)', live: true },
  { name: 'CYCLONE KICK' }, { name: 'COUNTER SLAM' }, { name: 'RUSH COMBO' }, { name: 'FINAL KNUCKLE' },
];
MASTERY_BY_CHAR.cole = MASTERY_MOVES;
MASTERY_BY_CHAR.tank = [
  null,
  { name: 'OVERHEAD SMASH', input: '3RD HIT: -> + X', live: true },
  { name: 'EARTHQUAKE', input: 'HOLD X LONGER', live: true },
  { name: 'AIR THROW', input: 'X ON A JUMPING FOE', live: true },
  { name: 'QUAKE PRESS', input: 'AIR: DOWN + X', live: true },
  { name: 'QUAKE TACKLE+', input: '-> + B (UPGRADED)', live: true },
  { name: 'GIANT SWING' }, { name: 'COUNTER CATCH' }, { name: 'IRON WALL' }, { name: 'FINAL SLAM' },
];
MASTERY_BY_CHAR.jett = [
  null,
  { name: 'DRILL KICK', input: '4TH HIT: -> + X', live: true },
  { name: 'RISING BLADE', input: 'HOLD X, RELEASE', live: true },
  { name: 'AIR THROW', input: 'X ON A JUMPING FOE', live: true },
  { name: 'METEOR KICK', input: 'AIR: DOWN + X', live: true },
  { name: 'BLUR RUSH+', input: '-> + B (UPGRADED)', live: true },
  { name: 'SPIN CUTTER' }, { name: 'COUNTER STEP' }, { name: 'BLUR COMBO' }, { name: 'LAST LAP' },
];
MASTERY_BY_CHAR.anita = [
  null,
  { name: 'SCISSOR TAKEDOWN', input: '4TH HIT: → + X', live: true },
  { name: 'AXE KICK', input: 'HOLD X, RELEASE', live: true },
  { name: 'AIR THROW', input: 'X ON A JUMPING FOE', live: true },
  { name: 'HEEL DROP', input: 'AIR: DOWN + X', live: true },
  { name: 'DRIVE KNEE+', input: '-> + B (UPGRADED)', live: true },
  { name: 'SPLIT KICK' }, { name: 'COUNTER FLIP' }, { name: 'RED RUSH' }, { name: 'KNOCKOUT' },
];
MASTERY_BY_CHAR.vex = MASTERY_BY_CHAR.anita;
MASTERY_BY_CHAR.unit9 = MASTERY_BY_CHAR.tank;
function masteryLevel(xp) { let l = 0; for (let i = 0; i < MASTERY_XP.length; i++) if (xp >= MASTERY_XP[i]) l = i + 1; return l; }

// ------------------------------------------------------------ cheats
const CHEAT_DEFS = [
  { id: 'invincible', name: 'INVINCIBLE' },
  { id: 'inflives', name: 'INFINITE LIVES' },
  { id: 'infspecial', name: 'INFINITE SPECIAL' },
  { id: 'allstages', name: 'ALL STAGES' },
  { id: 'onehit', name: 'ONE-HIT KO' },
  { id: 'maxstars', name: 'MAX STARS' },
  { id: 'unlockall', name: 'UNLOCK ALL FIGHTERS' },
  { id: 'weapon', name: 'START WEAPON', values: ['OFF', 'PIPE', 'KNIFE'] },
  { id: 'bigheads', name: 'BIG HEADS', shop: true },
  { id: 'turbo', name: 'TURBO LEGS', shop: true },
  { id: 'wrain', name: 'WEAPON RAIN', shop: true },
];
const CHEAT = {};
function clearCheats() { for (const c of CHEAT_DEFS) CHEAT[c.id] = 0; }
clearCheats();
function cheatsActive() { return CHEAT_DEFS.some(c => CHEAT[c.id]); }

// ------------------------------------------------------------ roster
const ROSTER = [
  { id: 'cole', name: 'COLE BRENNAN', tag: 'BALANCED BRAWLER', look: 'cole', stats: { POWER: 3, SPEED: 3, JUMP: 3, REACH: 3 }, live: true,
    unique: 'CHARGE PUNCH' },
  { id: 'anita', name: 'ANITA KNOCKOUT', tag: 'FAST KICKER', look: 'anita', stats: { POWER: 2, SPEED: 4, JUMP: 5, REACH: 3 }, live: true, unique: 'DOUBLE JUMP' },
  { id: 'tank', name: 'BRUNO "TANK" KOVAC', tag: 'POWER GRAPPLER', look: 'tank', stats: { POWER: 5, SPEED: 1, JUMP: 2, REACH: 4 },
    live: true, unique: 'RUNNING CLUTCH' },
  { id: 'jett', name: 'JETT RIVERA', tag: 'SPEEDSTER', look: 'jett', stats: { POWER: 2, SPEED: 5, JUMP: 4, REACH: 2 },
    live: true, unique: 'AIR DASH' },
  { id: 'vex', name: 'VEX', tag: 'SYNDICATE ENFORCER', look: 'vex', stats: { POWER: 4, SPEED: 4, JUMP: 3, REACH: 3 }, live: true,
    hidden: true, unique: 'BLINK STEP', code: ['left','left','right','right','back','attack'] },
  { id: 'unit9', name: 'UNIT-9', tag: 'COMBAT ROBOT', look: 'unit9', stats: { POWER: 4, SPEED: 2, JUMP: 2, REACH: 5 }, live: true,
    hidden: true, unique: 'MAGNET CLAW', code: ['down','down','up','up','special','special','jump'] },
];
const STAGES = [
  { n: 1, name: 'MEAN STREETS', live: true },
  { n: 2, name: 'NIGHTCLUB NEON', live: true }, { n: 3, name: 'STEEL SKELETON', live: true }, { n: 4, name: 'LAST TRAIN', live: true },
  { n: 5, name: 'HIGHWAY HEAT', live: true }, { n: 6, name: 'SYNDICATE WORKS', live: true }, { n: 7, name: 'THE LAB', live: true },
  { n: 8, name: 'TOWER TOP', live: true },
];

// ------------------------------------------------------------ stage 1
const STAGE1 = {
  scenes: [
    {
      name: 'UNDER THE EL', bg: 'elevated', len: 1560, music: 'stage1a',
      breakables: [
        { x: 210, y: 160, kind: 'can', item: 'apple' }, { x: 470, y: 176, kind: 'crate', item: 'cash' },
        { x: 760, y: 162, kind: 'can', item: 'pipe' }, { x: 1190, y: 166, kind: 'barrel', item: 'p:rage' },
        { x: 1390, y: 172, kind: 'crate', item: 'apple' }, { x: 1500, y: 160, kind: 'can', item: 'gold' },
      ],
      hazards: [{ kind: 'hydrant', x: 560, y: 186 }, { kind: 'manhole', x: 930, y: 208 }],
      waves: [
        { at: 0, groups: [{ t: ['punk', 'punk'], side: 'R' }] },
        { at: 300, groups: [{ t: ['punk', 'blade'], side: 'R' }, { t: ['punk'], side: 'L', delay: 60 }] },
        { at: 640, groups: [{ t: ['kicker', 'punk'], side: 'R' }, { t: ['blade', 'punk'], side: 'L', delay: 120 }] },
        { at: 1000, groups: [{ t: ['bruiser', 'punk'], side: 'R' }, { t: ['punk'], side: 'L', delay: 90 }], car: 200 },
        { at: 1134, groups: [{ t: ['blade', 'kicker', 'punk'], side: 'B' }, { t: ['punk', 'blade'], side: 'R', delay: 150 }], car: 60 },
      ],
    },
    {
      name: 'THE ROOFTOPS', bg: 'roofs', len: 1320, music: 'stage1b',
      breakables: [
        { x: 160, y: 168, kind: 'crate', item: 'knife' }, { x: 430, y: 158, kind: 'can', item: 'apple' },
        { x: 650, y: 178, kind: 'barrel', item: 'p:starup' }, { x: 830, y: 162, kind: 'crate', item: 'roast' },
        { x: 1010, y: 170, kind: 'can', item: 'p:refill' }, { x: 1250, y: 160, kind: 'barrel', item: 'p:oneup' },
      ],
      hazards: [{ kind: 'hydrant', skin: 'vent', x: 520, y: 170 }],
      waves: [
        { at: 0, groups: [{ t: ['punk', 'punk', 'kicker'], side: 'R' }] },
        { at: 360, groups: [{ t: ['bruiser', 'blade'], side: 'R' }, { t: ['blade'], side: 'L', delay: 80 }] },
        { at: 700, groups: [{ t: ['kicker', 'kicker', 'punk'], side: 'B' }, { t: ['bruiser'], side: 'R', delay: 150 }] },
        { at: 894, boss: ['brick'], groups: [] },
      ],
    },
  ],
};
const STAGE2 = {
  scenes: [
    {
      name: 'NEON CANYON', bg: 'canyon', len: 1400, music: 'stage2a',
      breakables: [
        { x: 230, y: 170, kind: 'can', item: 'cash' }, { x: 520, y: 160, kind: 'crate', item: 'apple' },
        { x: 700, y: 200, kind: 'barrel', item: 'knife' }, { x: 900, y: 165, kind: 'can', item: 'p:overdrive' },
        { x: 1150, y: 178, kind: 'crate', item: 'roast' }, { x: 1330, y: 160, kind: 'can', item: 'gold' },
      ],
      hazards: [{ kind: 'wire', x: 610, y: 205 }, { kind: 'hydrant', skin: 'vent', x: 1060, y: 172 }],
      waves: [
        { at: 0, groups: [{ t: ['punk', 'whip'], side: 'R' }] },
        { at: 300, groups: [{ t: ['kicker', 'punk'], side: 'R' }, { t: ['blade'], side: 'L', delay: 90 }] },
        { at: 620, groups: [{ t: ['whip', 'whip', 'punk'], side: 'B' }, { t: ['bruiser'], side: 'R', delay: 160 }] },
        { at: 974, groups: [{ t: ['blade', 'whip', 'kicker'], side: 'R' }, { t: ['punk', 'bruiser'], side: 'L', delay: 150 }] },
      ],
    },
    {
      name: 'THE BASEMENT', bg: 'basement', len: 1200, music: 'stage2b',
      breakables: [
        { x: 200, y: 160, kind: 'barrel', item: 'pipe' }, { x: 470, y: 176, kind: 'crate', item: 'p:rage' },
        { x: 640, y: 158, kind: 'can', item: 'apple' }, { x: 1050, y: 162, kind: 'crate', item: 'roast' },
        { x: 1150, y: 196, kind: 'barrel', item: 'p:oneup' },
      ],
      hazards: [{ kind: 'wire', x: 420, y: 190 }],
      waves: [
        { at: 0, groups: [{ t: ['whip', 'kicker', 'punk'], side: 'B' }] },
        { at: 360, groups: [{ t: ['bruiser', 'whip'], side: 'R' }, { t: ['blade', 'kicker'], side: 'L', delay: 120 }] },
        { at: 774, boss: ['ruby', 'onyx'], groups: [] },
      ],
    },
  ],
};
const STAGE3 = {
  scenes: [
    {
      name: 'GROUND LEVEL', bg: 'found', len: 1500, music: 'stage3a',
      breakables: [
        { x: 240, y: 168, kind: 'barrel', item: 'pipe' }, { x: 470, y: 190, kind: 'crate', item: 'apple' },
        { x: 640, y: 160, kind: 'crate', item: 'p:iron' }, { x: 1000, y: 176, kind: 'barrel', item: 'cash' },
        { x: 1260, y: 162, kind: 'crate', item: 'roast' }, { x: 1440, y: 200, kind: 'barrel', item: 'p:refill' },
      ],
      hazards: [{ kind: 'beams', every: 330 }, { kind: 'pit', x: 820, y: 196 }],
      waves: [
        { at: 0, groups: [{ t: ['punk', 'punk', 'blade'], side: 'R' }] },
        { at: 330, groups: [{ t: ['robot'], side: 'R' }, { t: ['kicker', 'punk'], side: 'L', delay: 80 }] },
        { at: 680, groups: [{ t: ['bruiser', 'blade'], side: 'R' }, { t: ['robot', 'punk'], side: 'L', delay: 160 }] },
        { at: 1074, groups: [{ t: ['robot', 'whip', 'kicker'], side: 'B' }, { t: ['bruiser', 'robot'], side: 'R', delay: 200 }] },
      ],
    },
    {
      name: 'THE GLASS FLOOR', bg: 'glass', len: 1200, music: 'stage3b',
      breakables: [
        { x: 220, y: 170, kind: 'crate', item: 'knife' }, { x: 520, y: 196, kind: 'barrel', item: 'p:starup' },
        { x: 700, y: 160, kind: 'crate', item: 'roast' }, { x: 1120, y: 170, kind: 'barrel', item: 'p:oneup' },
      ],
      hazards: [{ kind: 'beams', every: 420 }],
      waves: [
        { at: 0, groups: [{ t: ['robot', 'punk', 'kicker'], side: 'B' }] },
        { at: 380, groups: [{ t: ['robot', 'robot'], side: 'R' }, { t: ['blade', 'whip'], side: 'L', delay: 140 }] },
        { at: 774, boss: ['mech'], groups: [] },
      ],
    },
  ],
};
// ------------------------------------------------------------ stage 4: LAST TRAIN
const STAGE4 = {
  scenes: [
    {
      name: 'THE ROUNDHOUSE', bg: 'shed', len: 1540, music: 'stage4a',
      breakables: [
        { x: 200, y: 166, kind: 'crate', item: 'apple' }, { x: 430, y: 192, kind: 'barrel', item: 'pipe' },
        { x: 660, y: 160, kind: 'can', item: 'cash' }, { x: 900, y: 178, kind: 'crate', item: 'p:iron' },
        { x: 1160, y: 164, kind: 'barrel', item: 'roast' }, { x: 1420, y: 200, kind: 'can', item: 'p:refill' },
      ],
      hazards: [{ kind: 'hydrant', skin: 'vent', x: 580, y: 174 }, { kind: 'manhole', skin: 'pit', x: 1020, y: 212 }],
      waves: [
        { at: 0, groups: [{ t: ['punk', 'suit'], side: 'R' }] },
        { at: 320, groups: [{ t: ['suit', 'kicker'], side: 'R' }, { t: ['punk'], side: 'L', delay: 70 }] },
        { at: 660, groups: [{ t: ['bruiser', 'suit', 'blade'], side: 'B' }, { t: ['kicker'], side: 'R', delay: 140 }], car: 180 },
        { at: 1000, groups: [{ t: ['suit', 'suit', 'whip'], side: 'R' }, { t: ['bruiser', 'punk'], side: 'L', delay: 160 }] },
        { at: 1114, groups: [{ t: ['blade', 'suit', 'kicker'], side: 'B' }, { t: ['bruiser'], side: 'R', delay: 150 }], car: 70 },
      ],
    },
    {
      name: 'THE BRIDGE RUN', bg: 'bridge', len: 1240, music: 'stage4b',
      breakables: [
        { x: 180, y: 170, kind: 'crate', item: 'knife' }, { x: 470, y: 200, kind: 'crate', item: 'apple' },
        { x: 720, y: 164, kind: 'barrel', item: 'p:rage' }, { x: 1020, y: 182, kind: 'crate', item: 'roast' },
      ],
      hazards: [{ kind: 'beams', every: 300 }],
      waves: [
        { at: 0, groups: [{ t: ['suit', 'kicker', 'punk'], side: 'B' }] },
        { at: 340, groups: [{ t: ['suit', 'blade'], side: 'R' }, { t: ['whip', 'kicker'], side: 'L', delay: 120 }] },
        { at: 640, groups: [{ t: ['bruiser', 'suit', 'suit'], side: 'B' }, { t: ['blade'], side: 'R', delay: 170 }] },
        { at: 814, boss: ['gauge'], groups: [] },
      ],
    },
  ],
};
// ------------------------------------------------------------ stage 5: HIGHWAY HEAT
const STAGE5 = {
  scenes: [
    {
      name: 'THE UNDERPASS', bg: 'roadtun', len: 1520, music: 'stage5a',
      breakables: [
        { x: 240, y: 172, kind: 'barrel', item: 'apple' }, { x: 520, y: 200, kind: 'crate', item: 'pipe' },
        { x: 800, y: 166, kind: 'can', item: 'p:overdrive' }, { x: 1080, y: 190, kind: 'barrel', item: 'cash' },
        { x: 1340, y: 168, kind: 'crate', item: 'roast' },
      ],
      hazards: [],
      waves: [
        { at: 0, groups: [{ t: ['biker', 'biker'], side: 'R' }], car: 90 },
        { at: 320, groups: [{ t: ['biker', 'punk'], side: 'R' }, { t: ['suit'], side: 'L', delay: 80 }], car: 60 },
        { at: 660, groups: [{ t: ['biker', 'kicker', 'suit'], side: 'B' }, { t: ['bruiser'], side: 'R', delay: 150 }], car: 40 },
        { at: 1000, groups: [{ t: ['biker', 'biker', 'blade'], side: 'R' }, { t: ['suit', 'kicker'], side: 'L', delay: 140 }], car: 50 },
        { at: 1094, groups: [{ t: ['bruiser', 'biker', 'suit'], side: 'B' }, { t: ['biker'], side: 'L', delay: 160 }], car: 100 },
      ],
    },
    {
      // board run: the road pulls you along, you fight for position on it
      name: 'FAST LANE', bg: 'dawnroad', len: 1340, music: 'stage5b', ride: true,
      breakables: [
        { x: 200, y: 196, kind: 'crate', item: 'p:iron' }, { x: 560, y: 166, kind: 'barrel', item: 'apple' },
        { x: 900, y: 188, kind: 'crate', item: 'p:oneup' }, { x: 1160, y: 168, kind: 'can', item: 'roast' },
      ],
      hazards: [],
      waves: [
        { at: 0, groups: [{ t: ['biker', 'suit', 'biker'], side: 'B' }], car: 70 },
        { at: 320, groups: [{ t: ['biker', 'bruiser'], side: 'R' }, { t: ['blade', 'biker'], side: 'L', delay: 130 }], car: 60 },
        { at: 620, groups: [{ t: ['suit', 'suit', 'kicker'], side: 'R' }, { t: ['biker'], side: 'L', delay: 120 }], car: 50 },
        { at: 880, groups: [{ t: ['biker', 'biker', 'bruiser'], side: 'B' }, { t: ['suit'], side: 'L', delay: 150 }], car: 40 },
        { at: 914, boss: ['vexb'], groups: [] },
      ],
    },
  ],
};
// ------------------------------------------------------------ stage 6: SYNDICATE WORKS
const STAGE6 = {
  scenes: [
    {
      name: 'THE CAST HOUSE', bg: 'cast', len: 1560, music: 'stage6a',
      breakables: [
        { x: 230, y: 170, kind: 'barrel', item: 'pipe' }, { x: 500, y: 196, kind: 'crate', item: 'apple' },
        { x: 760, y: 162, kind: 'crate', item: 'p:rage' }, { x: 1040, y: 188, kind: 'barrel', item: 'cash' },
        { x: 1300, y: 166, kind: 'crate', item: 'roast' }, { x: 1470, y: 202, kind: 'barrel', item: 'p:refill' },
      ],
      hazards: [{ kind: 'pit', label: 'PIT', x: 690, y: 200 }, { kind: 'beams', every: 300 }],
      waves: [
        { at: 0, groups: [{ t: ['guard', 'punk'], side: 'R' }] },
        { at: 330, groups: [{ t: ['guard', 'robot'], side: 'R' }, { t: ['suit'], side: 'L', delay: 90 }] },
        { at: 680, groups: [{ t: ['hvbot', 'guard'], side: 'R' }, { t: ['bruiser', 'suit'], side: 'L', delay: 160 }] },
        { at: 1020, groups: [{ t: ['guard', 'guard', 'robot'], side: 'B' }, { t: ['hvbot'], side: 'R', delay: 180 }] },
        { at: 1134, groups: [{ t: ['bruiser', 'guard', 'blade'], side: 'B' }, { t: ['robot', 'suit'], side: 'R', delay: 170 }] },
      ],
    },
    {
      name: 'ASSEMBLY LINE', bg: 'line', len: 1320, music: 'stage6b',
      breakables: [
        { x: 210, y: 168, kind: 'crate', item: 'knife' }, { x: 540, y: 198, kind: 'barrel', item: 'p:starup' },
        { x: 820, y: 164, kind: 'crate', item: 'roast' }, { x: 1120, y: 186, kind: 'barrel', item: 'apple' },
      ],
      hazards: [{ kind: 'wire', x: 470, y: 206 }, { kind: 'beams', every: 380 }],
      waves: [
        { at: 0, groups: [{ t: ['hvbot', 'guard', 'suit'], side: 'B' }] },
        { at: 340, groups: [{ t: ['robot', 'robot', 'guard'], side: 'R' }, { t: ['bruiser'], side: 'L', delay: 150 }] },
        { at: 680, groups: [{ t: ['guard', 'hvbot', 'blade'], side: 'B' }, { t: ['suit', 'robot'], side: 'R', delay: 170 }] },
        { at: 894, groups: [{ t: ['hvbot', 'guard', 'guard'], side: 'R' }, { t: ['bruiser', 'suit'], side: 'L', delay: 160 }] },
      ],
    },
    {
      name: 'THE TORPEDO YARD', bg: 'torpedo', len: 1180, music: 'stage6c',
      breakables: [
        { x: 200, y: 172, kind: 'barrel', item: 'pipe' }, { x: 520, y: 196, kind: 'crate', item: 'roast' },
        { x: 880, y: 166, kind: 'barrel', item: 'p:oneup' },
      ],
      hazards: [{ kind: 'beams', every: 420 }],
      waves: [
        { at: 0, groups: [{ t: ['guard', 'hvbot'], side: 'B' }] },
        { at: 754, boss: ['slag'], groups: [] },
      ],
    },
  ],
};
// ------------------------------------------------------------ stage 7: THE LAB
const STAGE7 = {
  scenes: [
    {
      name: 'CLEAN CORRIDOR', bg: 'corridor', len: 1500, music: 'stage7a',
      breakables: [
        { x: 220, y: 172, kind: 'can', item: 'apple' }, { x: 500, y: 194, kind: 'crate', item: 'pipe' },
        { x: 780, y: 164, kind: 'barrel', item: 'p:iron' }, { x: 1060, y: 190, kind: 'crate', item: 'cash' },
        { x: 1330, y: 168, kind: 'can', item: 'roast' },
      ],
      hazards: [{ kind: 'wire', x: 620, y: 200 }, { kind: 'wire', x: 1140, y: 188 }],
      waves: [
        { at: 0, groups: [{ t: ['guard', 'guard'], side: 'R' }] },
        { at: 330, groups: [{ t: ['robot', 'guard', 'suit'], side: 'B' }] },
        { at: 660, groups: [{ t: ['hvbot', 'robot'], side: 'R' }, { t: ['guard', 'kicker'], side: 'L', delay: 150 }] },
        { at: 1010, groups: [{ t: ['guard', 'hvbot', 'suit'], side: 'B' }, { t: ['robot', 'robot'], side: 'R', delay: 190 }] },
        { at: 1074, groups: [{ t: ['bruiser', 'guard', 'guard'], side: 'B' }, { t: ['hvbot'], side: 'L', delay: 170 }] },
      ],
    },
    {
      name: 'THE COLD STORE', bg: 'coldstore', len: 1280, music: 'stage7b',
      breakables: [
        { x: 240, y: 170, kind: 'can', item: 'apple' }, { x: 560, y: 196, kind: 'crate', item: 'p:overdrive' },
        { x: 900, y: 168, kind: 'barrel', item: 'cash' }, { x: 1140, y: 190, kind: 'crate', item: 'roast' },
      ],
      hazards: [{ kind: 'wire', x: 700, y: 202 }, { kind: 'pit', label: 'WELL', x: 1020, y: 190 }],
      waves: [
        { at: 0, groups: [{ t: ['robot', 'guard', 'suit'], side: 'B' }] },
        { at: 350, groups: [{ t: ['hvbot', 'guard'], side: 'R' }, { t: ['robot', 'kicker'], side: 'L', delay: 140 }] },
        { at: 700, groups: [{ t: ['guard', 'guard', 'robot'], side: 'R' }, { t: ['hvbot', 'suit'], side: 'L', delay: 180 }] },
        { at: 854, groups: [{ t: ['bruiser', 'hvbot', 'guard'], side: 'B' }, { t: ['robot', 'robot'], side: 'R', delay: 190 }] },
      ],
    },
    {
      name: 'THE BIRTHING FLOOR', bg: 'birth', len: 1220, music: 'stage7c',
      breakables: [
        { x: 240, y: 170, kind: 'crate', item: 'knife' }, { x: 560, y: 196, kind: 'barrel', item: 'p:rage' },
        { x: 700, y: 176, kind: 'capsule', item: 'p:oneup', objective: 'unit9' },
        { x: 980, y: 166, kind: 'crate', item: 'roast' },
      ],
      hazards: [{ kind: 'beams', every: 420 }],
      waves: [
        { at: 0, groups: [{ t: ['guard', 'robot', 'guard'], side: 'B' }] },
        { at: 360, groups: [{ t: ['hvbot', 'hvbot'], side: 'R' }, { t: ['guard', 'suit'], side: 'L', delay: 160 }] },
        { at: 794, boss: ['warden'], groups: [] },
      ],
    },
  ],
};
// ------------------------------------------------------------ stage 8: TOWER TOP
const STAGE8 = {
  scenes: [
    {
      name: 'THE BLACKOUT LOBBY', bg: 'blackout', len: 1540, music: 'stage8a',
      breakables: [
        { x: 250, y: 172, kind: 'crate', item: 'apple' }, { x: 540, y: 198, kind: 'barrel', item: 'pipe' },
        { x: 820, y: 166, kind: 'crate', item: 'p:overdrive' }, { x: 1100, y: 190, kind: 'barrel', item: 'roast' },
        { x: 1360, y: 168, kind: 'crate', item: 'p:refill' },
      ],
      hazards: [{ kind: 'pit', x: 960, y: 204 }],
      waves: [
        { at: 0, groups: [{ t: ['suit', 'guard', 'suit'], side: 'B' }] },
        { at: 330, groups: [{ t: ['hvbot', 'suit'], side: 'R' }, { t: ['blade', 'kicker'], side: 'L', delay: 130 }] },
        { at: 680, groups: [{ t: ['bruiser', 'guard', 'robot'], side: 'B' }, { t: ['suit', 'suit'], side: 'R', delay: 170 }] },
        { at: 1020, groups: [{ t: ['whip', 'hvbot', 'suit'], side: 'R' }, { t: ['bruiser', 'guard'], side: 'L', delay: 180 }] },
        { at: 1114, groups: [{ t: ['guard', 'guard', 'hvbot'], side: 'B' }, { t: ['suit', 'blade'], side: 'R', delay: 160 }] },
      ],
    },
    {
      // the old faces are all on the payroll again, waiting among his models
      name: 'THE MODEL ROOM', bg: 'modelroom', len: 1420, music: 'stage8b',
      breakables: [
        { x: 240, y: 172, kind: 'crate', item: 'roast' }, { x: 620, y: 196, kind: 'barrel', item: 'p:rage' },
        { x: 1000, y: 168, kind: 'crate', item: 'apple' }, { x: 1280, y: 194, kind: 'barrel', item: 'p:refill' },
      ],
      hazards: [],
      waves: [
        { at: 0, groups: [{ t: ['suit', 'guard'], side: 'R' }] },
        { at: 330, boss: ['brick2'], music: 'boss', groups: [{ t: ['suit'], side: 'L', delay: 200 }] },
        { at: 700, groups: [{ t: ['hvbot', 'suit', 'whip'], side: 'B' }] },
        { at: 994, boss: ['ruby2', 'onyx2'], music: 'boss2', groups: [] },
      ],
    },
    {
      name: 'THE HELIPAD', bg: 'stormpad', len: 1240, music: 'stage8c',
      breakables: [
        { x: 220, y: 170, kind: 'crate', item: 'p:iron' }, { x: 520, y: 198, kind: 'barrel', item: 'roast' },
        { x: 860, y: 168, kind: 'crate', item: 'p:oneup' }, { x: 1060, y: 192, kind: 'barrel', item: 'p:refill' },
      ],
      hazards: [],
      waves: [
        { at: 0, groups: [{ t: ['suit', 'hvbot', 'guard'], side: 'B' }] },
        { at: 300, boss: ['rivet2'], music: 'boss3', groups: [{ t: ['guard'], side: 'L', delay: 210 }] },
        { at: 620, groups: [{ t: ['bruiser', 'suit', 'guard'], side: 'R' }, { t: ['hvbot', 'blade'], side: 'L', delay: 150 }] },
        { at: 814, boss: ['dray'], groups: [] },
      ],
    },
  ],
};
const STAGE_DATA = { 1: STAGE1, 2: STAGE2, 3: STAGE3, 4: STAGE4, 5: STAGE5, 6: STAGE6, 7: STAGE7, 8: STAGE8 };
const STAGE_TEXT = {
  2: ['THE SYNDICATE RUNS ITS MONEY', 'THROUGH A CLUB ON THE STRIP.', 'TIME TO SHUT THE PARTY DOWN.'],
  3: ['THE CLUB WAS A FRONT.', 'THE REAL WORK HAPPENS AT A TOWER', 'THE SYNDICATE IS BUILDING DOWNTOWN.'],
  4: ['THE PILOT TALKED BEFORE HE PASSED OUT.', 'EVERYTHING THEY MOVE, THEY MOVE BY RAIL.', 'THE 2:40 FREIGHT LEAVES IN TEN MINUTES.'],
  5: ['THE FREIGHT WAS A DECOY.', 'THE REAL CARGO IS ON THE HIGHWAY,', 'AND SOMETHING IS CHASING IT DOWN TOO.'],
  6: ['VEX SAID ONE WORD BEFORE SHE WENT DOWN:', 'THE WORKS. WHERE THEY BUILD THE THINGS', 'THAT DO NOT BLEED.'],
  7: ['UNDER THE WORKS IS A LAB.', 'THEY ARE NOT BUILDING MACHINES DOWN THERE.', 'THEY ARE BUILDING REPLACEMENTS.'],
  8: ['EIGHTY FLOORS UP, THE MAN WHO BOUGHT', 'THIS CITY IS WAITING FOR HIS HELICOPTER.', 'THE WEATHER SAYS HE IS GOING TO MISS IT.'],
};
// ------------------------------------------------------------ boss rush
const BOSS_RUSH_MUSIC = { brick: 'boss', ruby: 'boss2', mech: 'boss3', gauge: 'boss4', vexb: 'boss5', slag: 'boss6', warden: 'boss7', drayx: 'boss8x' };
// When a boss phases into another one, the music changes with it.
const BOSS_PHASE_MUSIC = { drayx: 'boss8x' };
const BOSS_RUSH_STAGE = {
  scenes: [{
    name: 'BOSS RUSH', bg: 'deck', len: 426, music: 'boss',
    breakables: [], hazards: [],
    waves: BOSS_RUSH.map(k => ({ at: 0, boss: k === 'ruby' ? ['ruby', 'onyx'] : [k], groups: [], music: BOSS_RUSH_MUSIC[k] })),
  }],
};
const ENDINGS = {
  best: { id: 'best', title: 'BEST ENDING', col: '#f2c94c', lines: [
    'DRAY GOES OFF THE ROOF WITHOUT HIS HELICOPTER.',
    'UNIT-9 WALKS OUT OF THE LAB ON ITS OWN FEET AND',
    'HANDS THE WHOLE LEDGER TO THE ONE HONEST PAPER LEFT.',
    '',
    'EVERY NAME IN IT IS IN COURT BY FRIDAY.',
    'THE CIRCUIT IS OPEN. THE CITY IS YOURS AGAIN.',
  ] },
  good: { id: 'good', title: 'GOOD ENDING', col: '#5ad06a', lines: [
    'DRAY GOES OFF THE ROOF WITHOUT HIS HELICOPTER.',
    'THE SYNDICATE COMES APART IN A WEEK OF ARRESTS.',
    '',
    'BUT THE LAB BURNED WITH EVERYTHING STILL INSIDE IT,',
    'AND NOBODY EVER FOUND OUT WHAT WAS IN THE TANKS.',
    'SOMEWHERE, SOMEONE IS ALREADY REBUILDING.',
  ] },
  ok: { id: 'ok', title: 'ENDING', col: '#4ac0e8', lines: [
    'DRAY IS FINISHED. THE TOWER GOES DARK.',
    '',
    'YOU WENT EASY ON THEM, AND THEY NOTICED.',
    'BY MORNING HALF THE ORGANISATION HAS A NEW ADDRESS',
    'AND THE SAME OLD BUSINESS.',
    '',
    'TRY IT AGAIN ON MEDIUM OR HARDER.',
  ] },
};
const TRAINING_SCENE = { name: 'TRAINING ROOM', bg: 'gym', len: 426, music: 'training', breakables: [], hazards: [], waves: [] };
