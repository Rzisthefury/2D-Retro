// ============================================================ SCREENS / MAIN LOOP
let SCREEN = 'boot';
let S = {};                      // per-screen state
const SESSION = { unlocked: {}, introSeen: false };
const BUILD = 'BUILD 15 - TOUCH';
function go(name, st = {}) { SCREEN = name; S = Object.assign({ t: 0, cur: 0 }, st); Input.clearAll(); }

// ------------------------------------------------------------ glyph text
const PAD_GLYPH = { X: '#3a7ae8', Y: '#e8c020', A: '#3ab84a', B: '#e8283a' };
function keyLabel(code) { return code.replace('Key', '').replace('Arrow', '').replace('Digit', '').replace('Enter', 'ENT').slice(0, 5); }
const TOUCH_LABELS = { attack: 'ATK', back: 'BCK', jump: 'JMP', special: 'SP', pick: 'ATK', ally: 'PAUSE' };
function glyphFor(tok) {
  const map = { X: 'attack', Y: 'back', A: 'jump', B: 'special', LB: 'pick', RB: 'ally' };
  const act = map[tok];
  if (Input.lastDevice === 'touch') return { pad: false, label: TOUCH_LABELS[act] || tok };
  if (Input.lastDevice === 'pad') {
    const idx = Input.padMap()[act];
    return { pad: true, label: PAD_NAMES[idx] || tok };
  }
  return { pad: false, label: keyLabel(Input.keyMap()[act]) };
}
// draws text with {X} {Y} {A} {B} {LB} {RB} button glyphs
function gtext(str, x, y, col = '#fff') {
  const parts = str.split(/(\{[A-Z]+\})/);
  let cx = x;
  for (const part of parts) {
    if (!part) continue;
    const m = part.match(/^\{([A-Z]+)\}$/);
    if (m) {
      const g = glyphFor(m[1]);
      const w = textWidth(g.label) + 4;
      const c = g.pad ? (PAD_GLYPH[g.label] || '#6a6a88') : '#4a4a66';
      ctx.fillStyle = '#120a14'; ctx.fillRect(cx - 1, y - 2, w + 2, 11);
      ctx.fillStyle = c;
      if (g.pad && g.label.length === 1) { ctx.beginPath(); ctx.arc(cx + w / 2, y + 3.5, 5, 0, 7); ctx.fill(); }
      else ctx.fillRect(cx, y - 1, w, 9);
      text(g.label, cx + 2, y, '#fff', 1, 0, null);
      cx += w + 3;
    } else { text(part, cx, y, col); cx += textWidth(part.toUpperCase()) + 6; }
  }
}

// ------------------------------------------------------------ backdrop
let titleBg = null;
function drawCityBackdrop(t, dim = 0.45) {
  if (!titleBg) titleBg = buildBackground('street', 1560);
  const cx = (t * 0.6) % 1100;
  bgDraw(titleBg.far, -Math.round(cx * 0.25), 0);
  bgDraw(titleBg.mid, -Math.round(cx * 0.55), 0);
  bgDraw(titleBg.near, -Math.round(cx), 0);
  px(0, 0, W, H, `rgba(6,4,12,${dim})`);
}
function panel(x, y, w, h, title) {
  px(x, y, w, h, 'rgba(10,8,20,0.9)');
  ctx.strokeStyle = '#4a3a7a'; ctx.lineWidth = 1; ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  if (title) { px(x, y, w, 11, '#2a2050'); text(title, x + 4, y + 2, '#f2c94c', 1, 0, null); }
}
function menuList(items, cur, x, y, gap = 12, align = 1) {
  items.forEach((it, i) => {
    const sel = i === cur;
    const lab = typeof it === 'string' ? it : it.label;
    const dis = typeof it === 'object' && it.disabled;
    let col = dis ? '#5a5670' : sel ? '#f2c94c' : '#e8e8f0';
    text(lab, x, y + i * gap, col, 1, align);
    if (sel && Math.floor(S.t / 16) % 2 === 0) {
      const w = textWidth(lab);
      const lx = align === 1 ? x - w / 2 - 10 : x - 10;
      text('→', lx, y + i * gap, '#f2c94c', 1, 0);
    }
  });
}
function moveCursor(n) {
  const v = navV();
  if (v) { S.cur = (S.cur + v + n) % n; sfx('move'); }
  return v;
}

// ------------------------------------------------------------ boot / title
function titleItems() {
  const it = [
    { label: 'START GAME', id: 'start' },
    { label: 'SHOP', id: 'shop' },
    { label: 'TRAINING', id: 'training' },
    { label: 'BOSS RUSH', id: 'bossrush', disabled: !(SAVE.cleared || SAVE.unlocks.bossrush || CHEAT.allstages) },
    { label: 'OPTIONS', id: 'options' },
    { label: 'CHEATS', id: 'cheats' },
  ];
  if (SAVE.cheatsOwned.includes('soundtest')) it.push({ label: 'SOUND TEST', id: 'soundtest' });
  if (SAVE.cheatsOwned.includes('gallery')) it.push({ label: 'GALLERY', id: 'gallery' });
  return it;
}
function updateTitle() {
  Music.play('title');
  if (!S.menu) {
    if (Input.pressed.start || Input.pressed.confirm) { S.menu = true; S.cur = 0; sfx('ok'); }
    return;
  }
  const items = titleItems();
  moveCursor(items.length);
  if (Input.pressed.confirm) {
    const it = items[S.cur];
    if (it.disabled) { sfx('err'); S.msg = 'CLEAR THE GAME (OR BUY IT IN THE SHOP) TO UNLOCK'; S.msgT = 120; return; }
    sfx('ok');
    if (it.id === 'start') go('setup', { cur: 0, from: 'title' });
    else if (it.id === 'shop') go('shop', { tab: 0, from: 'title' });
    else if (it.id === 'training') { startRun({ mode: 'training', char: SESSION.lastChar || 'cole' }); go('play'); }
    else if (it.id === 'bossrush') go('setup', { cur: 0, from: 'title', rush: true, init: false });
    else if (it.id === 'options') go('options', { from: 'title' });
    else if (it.id === 'cheats') go('cheats', { from: 'title' });
    else if (it.id === 'soundtest') go('soundtest', {});
    else if (it.id === 'gallery') go('gallery', { page: 0 });
  }
  if (Input.pressed.cancel) { S.menu = false; sfx('back'); }
}
function drawLogo(y) {
  const word = 'RAGE', word2 = 'CIRCUIT';
  const s = 5;
  const x1 = W / 2 - textWidth(word, s) / 2;
  text(word, x1 + 3, y + 3, '#4a0a14', s, 0, null);
  text(word, x1, y, '#e8283a', s, 0, '#120a14');
  ctx.fillStyle = 'rgba(255,200,80,0.55)'; ctx.fillRect(x1, y + 14, textWidth(word, s), 3);
  const s2 = 3, x2 = W / 2 - textWidth(word2, s2) / 2;
  text(word2, x2, y + 42, '#f2c94c', s2, 0, '#120a14');
  px(W / 2 - 90, y + 68, 180, 1, '#e8283a');
}
function renderTitle() {
  drawCityBackdrop(S.t, 0.35);
  drawFigure(356, 222, -1, 'victory', LOOKS.cole, {});
  drawFigure(310, 226, -1, 'aVictory', LOOKS.anita, {});
  drawFigure(70, 222, 1, 'idle', LOOKS.punkA, { alpha: 0.9 });
  drawFigure(110, 226, 1, 'heavyIdle', LOOKS.brick, { alpha: 0.9 });
  drawLogo(24);
  text('THE STREETS HIT BACK', W / 2, 98, '#e8e8f0', 1, 1);
  if (!S.menu) {
    if (Math.floor(S.t / 28) % 2 === 0) text('PRESS START', W / 2, 150, '#fff', 2, 1);
  } else {
    const items = titleItems();
    panel(W / 2 - 62, 110, 124, items.length * 11 + 10);
    menuList(items, S.cur, W / 2, 116, 11);
  }
  text('BANK ' + fmt(SAVE.bank), 6, H - 10, '#f2c94c');
  text(BUILD, W - 6, H - 10, '#6a6688', 1, 2);
  if (S.msgT > 0) { S.msgT--; text(S.msg, W / 2, 226, '#e8283a', 1, 1); }
  if (!storageOK) text('SAVING UNAVAILABLE IN THIS BROWSER', W / 2, 216, '#e8283a', 1, 1);
  if (audioBlocked() && Math.floor(S.t / 40) % 2 === 0) text('CLICK OR PRESS A KEY FOR SOUND', W / 2, 228, '#8a88a8', 1, 1);
}

// ------------------------------------------------------------ setup (stage / fighter / partner / difficulty)
function fighterUnlocked(r) {
  if (!r.hidden) return true;
  return SAVE.unlocks[r.id] || SESSION.unlocked[r.id] || CHEAT.unlockall;
}
function setupFighters() { return ROSTER.filter(fighterUnlocked); }
function partnerOpts() { return [null].concat(ROSTER.filter(r => r.live && fighterUnlocked(r)).map(r => r.id)); }
function stagesAvail() {
  const n = CHEAT.allstages ? 8 : Math.min(8, SAVE.reached);
  return STAGES.slice(0, Math.max(1, n));
}
function updateSetup() {
  Music.play('menu');
  if (!S.init) {
    S.init = true;
    S.stage = 0; S.fighter = 0; S.partner = S.partner || 0; S.cmd = S.cmd || 0;
    S.diff = S.diff === undefined ? 1 : S.diff; S.classic = S.classic || 0;
    S.codeBuf = [];
  }
  // code entry: hold LB + RB
  const coding = Input.held.pick && Input.held.ally;
  if (coding) {
    for (const a of ['left', 'right', 'up', 'down', 'attack', 'back', 'special', 'jump']) {
      if (Input.pressed[a]) {
        S.codeBuf.push(a); if (S.codeBuf.length > 10) S.codeBuf.shift();
        for (const r of ROSTER) if (r.code) {
          const c = r.code, tail = S.codeBuf.slice(-c.length);
          if (tail.length === c.length && tail.every((v, i) => v === c[i])) {
            SESSION.unlocked[r.id] = true; sfx('levelup');
            S.msg = r.name + ' UNLOCKED FOR THIS SESSION'; S.msgT = 180; S.codeBuf = [];
          }
        }
      }
    }
    return;
  } else S.codeBuf = [];
  const rows = S.rush ? ['fighter', 'partner', 'cmd', 'diff', 'start'] : ['stage', 'fighter', 'partner', 'cmd', 'diff', 'rules', 'start'];
  const v = navV();
  if (v) {
    do { S.cur = (S.cur + v + rows.length) % rows.length; } while (rows[S.cur] === 'cmd' && !S.partner);
    sfx('move');
  }
  const h = v ? 0 : navH();
  const row = rows[S.cur];
  if (h) {
    sfx('move');
    if (row === 'stage') S.stage = (S.stage + h + stagesAvail().length) % stagesAvail().length;
    if (row === 'fighter') S.fighter = (S.fighter + h + setupFighters().length) % setupFighters().length;
    if (row === 'partner') S.partner = (S.partner + h + partnerOpts().length) % partnerOpts().length;
    if (row === 'cmd') S.cmd = (S.cmd + h + 3) % 3;
    if (row === 'diff') S.diff = (S.diff + h + 4) % 4;
    if (row === 'rules') S.classic = S.classic ? 0 : 1;
  }
  if (Input.pressed.cancel) { sfx('back'); go('title', { menu: true }); return; }
  if (Input.pressed.confirm || Input.pressed.start) {
    if (row !== 'start' && !Input.pressed.start) { S.cur = rows.length - 1; sfx('move'); return; }
    const st = stagesAvail()[S.stage], fr = setupFighters()[S.fighter];
    if (!S.rush && !st.live) { sfx('err'); S.msg = 'STAGE ' + st.n + ' IS NOT IN THIS BUILD YET'; S.msgT = 150; return; }
    if (!fr.live) { sfx('err'); S.msg = fr.name + ' IS STILL IN DEVELOPMENT'; S.msgT = 150; return; }
    sfx('ok');
    const pc = partnerOpts()[S.partner];
    SESSION.lastChar = fr.id;
    const opts = { mode: 'story', diff: S.diff, classic: !!S.classic, char: fr.id, partner: !!pc, partnerChar: pc, allyCmd: S.cmd,
      stage: S.rush ? 8 : st.n, rush: !!S.rush };
    const launch = () => { startRun(opts); if (cheatsActive()) G.cheated = true; go('play'); };
    if (!SESSION.introSeen && !S.rush) { SESSION.introSeen = true; go('intro', { next: launch, line: 0 }); }
    else launch();
  }
}
const PREVIEW_POSES = {
  cole: ['idle', 'idle2', 'jab1', 'idle', 'straight', 'idle', 'roundhouse', 'idle'],
  anita: ['aIdle', 'aIdle2', 'aLowKick', 'aIdle', 'aMidKick', 'aIdle', 'aHighKick', 'aIdle'],
  tank: ['kIdle', 'kIdle2', 'kJab', 'kIdle', 'kHook', 'kIdle', 'kSlam', 'kIdle'],
  jett: ['jIdle', 'jIdle2', 'jJab', 'jIdle', 'jElbow', 'jIdle', 'jSpin', 'jIdle'],
  vex: ['aIdle', 'aIdle2', 'vexReady', 'aIdle', 'vexLunge', 'aIdle', 'vexThrow', 'aIdle'],
  unit9: ['kIdle', 'kIdle2', 'kJab', 'kIdle', 'kReach', 'kIdle', 'kSlam', 'kIdle'],
};
function statBars(x, y, stats) {
  let i = 0;
  for (const k in stats) {
    text(k, x, y + i * 9, '#a8a8c8');
    for (let j = 0; j < 5; j++) px(x + 40 + j * 9, y + i * 9, 7, 5, j < stats[k] ? '#f2c94c' : '#2a2640');
    i++;
  }
}
function renderSetup() {
  drawCityBackdrop(S.t, 0.62);
  if (!S.init) return;
  text(S.rush ? 'BOSS RUSH' : 'SELECT', 12, 8, '#f2c94c', 2);
  const st = stagesAvail()[S.stage] || STAGES[0];
  const fr = setupFighters()[S.fighter] || ROSTER[0];
  const d = DIFFS[S.diff];
  panel(8, 30, 200, 180);
  const rows = (S.rush ? [] : [['STAGE', `${st.n}  ${st.name}` + (st.live ? '' : ' *')]]).concat([
    ['FIGHTER', fr.name],
    ['PARTNER', S.partner ? 'CPU ' + ROSTER.find(r => r.id === partnerOpts()[S.partner]).name : 'NONE'],
    ['COMMAND', S.partner ? ALLY_CMDS[S.cmd] : '-'],
    ['DIFFICULTY', d.name],
  ], S.rush ? [] : [['RULES', S.classic ? 'CLASSIC' : 'UPGRADED']]);
  rows.forEach(([k, v], i) => {
    const y = 40 + i * 22, sel = S.cur === i;
    const dis = k === 'COMMAND' && !S.partner;
    text(k, 16, y, dis ? '#4a4660' : '#8a88a8');
    const col = dis ? '#4a4660' : sel ? '#f2c94c' : (k === 'DIFFICULTY' ? d.col : '#fff');
    text((sel ? '< ' : '') + v + (sel ? ' >' : ''), 16, y + 9, col);
  });
  const sy = 40 + rows.length * 22 + 4;
  const ss = S.cur === rows.length;
  px(16, sy - 3, 184, 14, ss ? '#e8283a' : '#3a1a24');
  text('START', 108, sy, '#fff', 1, 1);
  // fighter card
  panel(216, 30, 202, 180, fr.tag);
  if (fr.live) {
    const look = LOOKS[fr.look];
    const seq = PREVIEW_POSES[fr.id] || PREVIEW_POSES.cole;
    const pz = seq[Math.floor(S.t / 20) % 8];
    drawFigure(262, 170, 1, pz, look, { scale: 1.2 });
  } else {
    ctx.fillStyle = '#1a1630'; ctx.beginPath(); ctx.ellipse(262, 110, 22, 40, 0, 0, 7); ctx.fill();
    text('?', 262, 100, '#4a4670', 3, 1);
    text(fr.hidden ? 'NOT IN THIS BUILD' : 'IN DEVELOPMENT', 262, 158, '#e8283a', 1, 1);
  }
  text(fr.name, 316, 44, '#fff', 1, 0);
  statBars(316, 58, fr.stats);
  text('UNIQUE:', 316, 100, '#8a88a8'); text(fr.unique || '???', 316, 109, '#4ac0e8');
  if (fr.live) {
    const cs = SAVE.chars[fr.id];
    const lvl = masteryLevel(cs.xp);
    text('MASTERY ' + lvl, 316, 124, '#f2c94c');
    const nx = MASTERY_XP[lvl] || MASTERY_XP[MASTERY_XP.length - 1], pv = MASTERY_XP[lvl - 1];
    bar(316, 134, 90, 3, lvl >= 10 ? 1 : (cs.xp - pv) / (nx - pv), '#f2c94c', '#2a2640');
    if (!S.classic) {
      text('PERKS', 316, 144, '#8a88a8');
      const pk = cs.perks.slice(0, SAVE.slots);
      if (!pk.length) text('NONE', 316, 153, '#5a5670');
      pk.forEach((id, i) => text(PERKS.find(p => p.id === id).name, 316, 153 + i * 8, '#e8e8f0'));
      const armed = CONSUMABLES.filter(c => SAVE.consumables[c.id] > 0).map(c => c.name);
      if (armed.length) { text('NEXT STAGE:', 222, 176, '#8a88a8'); armed.forEach((a, i) => text(a, 222, 185 + i * 8, '#5ad06a')); }
      text('ATK' + cs.atk + ' HP' + cs.hp + ' SP' + cs.meter + ' DF' + cs.def, 316, 186, '#a8a8c8');
    } else text('UPGRADES OFF', 316, 150, '#e8283a');
    const gk = `${S.classic ? 'c' : 'u'}_${S.diff}_${st.n}`;
    const g = SAVE.grades[gk];
    text('BEST GRADE: ' + (g || '-'), 316, 200, g ? GRADES.find(x => x.g === g).col : '#5a5670');
  }
  gtext('HOLD {LB}+{RB} + INPUTS = SECRET CODE', 12, 218, '#6a6688');
  if (Input.held.pick && Input.held.ally) {
    panel(110, 90, 206, 40, 'CODE ENTRY');
    const s = S.codeBuf.map(a => ({ left: '←', right: '→', up: '↑', down: '↓', attack: 'X', back: 'Y', special: 'B', jump: 'A' }[a])).join(' ');
    text(s || '...', 213, 110, '#f2c94c', 1, 1);
  }
  if (S.msgT > 0) { S.msgT--; px(0, 226, W, 12, 'rgba(0,0,0,0.8)'); text(S.msg, W / 2, 228, '#f2c94c', 1, 1); }
  else text('←→ CHANGE   ↑↓ MOVE', W - 8, 228, '#6a6688', 1, 2);
}

// ------------------------------------------------------------ intro text
const INTRO_LINES = [
  'THE SYNDICATE OWNS THIS CITY.',
  'COPS, JUDGES, THE MAYOR - ALL BOUGHT.',
  'COLE BRENNAN AND ANITA KNOCKOUT',
  'SAW TOO MUCH. NOW THEY ARE MARKED.',
  'TONIGHT, THEY HIT BACK.',
];
function updateIntro() {
  Music.play('menu');
  if (Input.pressed.start) { S.next(); return; }
  if (Input.pressed.confirm) {
    const full = INTRO_LINES[S.line].length;
    if (S.t < full * 2) S.t = full * 2;
    else { S.line++; S.t = 0; if (S.line >= INTRO_LINES.length) S.next(); }
  }
}
function renderIntro() {
  drawCityBackdrop(S.t * 0.3 + 300, 0.75);
  for (let i = 0; i <= S.line && i < INTRO_LINES.length; i++) {
    const l = INTRO_LINES[i];
    const shown = i < S.line ? l : l.slice(0, Math.floor(S.t / 2));
    text(shown, W / 2, 70 + i * 18, i === INTRO_LINES.length - 1 ? '#e8283a' : '#fff', 1, 1);
  }
  gtext('{A} NEXT   START SKIP', 150, 220, '#8a88a8');
}

// ------------------------------------------------------------ play / pause
function updatePlay() {
  if (G.loadQ && G.loadQ.length) { prewarm(G.loadQ, 14); return; }
  if (Input.pressed.start && !G.done) { sfx('ok'); go('pause', { cur: 0 }); return; }
  if (G.mode === 'story' && cheatsActive()) G.cheated = true;
  if (Input.pressed.ally && G.partner && G.ally) {
    G.allyCmd = (G.allyCmd + 1) % 3; sfx('move');
    popText('CPU: ' + ALLY_CMDS[G.allyCmd], G.ally.x, G.ally.y - 60, '#5ad06a');
  }
  stepWorld();
  if (G.gameOver) { go('continue', { n: 10 }); Music.stop(); jingle('over'); return; }
  if (G.done) { finishStage(); return; }
}
function stepWorld() {
  G.frames++;
  if (G.slowmo > 0) { G.slowmo--; if (G.slowmo % 3 !== 0) { updateFx(); return; } }
  if (G.fadeDir) {
    G.fade += G.fadeDir * 0.05;
    if (G.fadeDir > 0 && G.fade >= 1) { G.fade = 1; G.fadeDir = 0; const cb = G.fadeCb; G.fadeCb = null; if (cb) cb(); return; }
    if (G.fadeDir < 0 && G.fade <= 0) { G.fade = 0; G.fadeDir = 0; }
  }
  updateFighters();
  updateProjs();
  updateItems();
  updateHazards();
  updateStage();
  updateFx();
  if (G.comboT > 0) { G.comboT--; if (G.comboT === 0) resetCombo(false); }
  if (G.comboShow > 0) G.comboShow--;
  if (G.shake > 0) G.shake = Math.max(0, G.shake - 0.5);
  if (G.flashT > 0) G.flashT--;
  if (G.banner) G.banner.t--;
  if (!G.clearT) G.stageFrames++;
}
function renderPlay() {
  if (G.loadQ && G.loadQ.length) {
    ctx.fillStyle = '#07060b'; ctx.fillRect(0, 0, W, H);
    const k = 1 - G.loadQ.length / (G.loadQ.total || 1);
    text('STAGE ' + G.stage + (G.mode === 'training' ? '' : ' - ' + STAGES[G.stage - 1].name), W / 2, 96, '#f2c94c', 1, 1);
    text('LOADING FIGHTERS', W / 2, 112, '#8a88a8', 1, 1);
    bar(W / 2 - 80, 128, 160, 4, k, '#e8283a', '#2a1a24');
    return;
  }
  renderWorld();
  drawHUD();
  drawBanner();
  if (G.flashT > 0) px(0, 0, W, H, 'rgba(255,255,255,0.35)');
  if (G.fade > 0) px(0, 0, W, H, `rgba(0,0,0,${G.fade})`);
}
function pauseItems() {
  if (G.mode === 'training') return [
    { id: 'resume', label: 'RESUME' },
    { id: 'dummy', label: 'DUMMY: ' + ['STAND', 'WALK', 'GUARD', 'ATTACK'][G.trainDummy] },
    { id: 'count', label: 'DUMMIES: ' + G.trainCount },
    { id: 'moves', label: 'MOVE LIST' },
    { id: 'options', label: 'OPTIONS' },
    { id: 'quit', label: 'QUIT TO TITLE' },
  ];
  const it = [{ id: 'resume', label: 'RESUME' }, { id: 'moves', label: 'MOVE LIST' }];
  if (G.partner && G.ally) it.push({ id: 'cmd', label: 'CPU: ' + ALLY_CMDS[G.allyCmd] });
  it.push({ id: 'cheats', label: 'CHEATS' }, { id: 'options', label: 'OPTIONS' }, { id: 'quit', label: 'QUIT TO TITLE' });
  return it;
}
function updatePause() {
  const items = pauseItems();
  moveCursor(items.length);
  const it = items[S.cur];
  const h = navH();
  if (h && it.id === 'dummy') { G.trainDummy = (G.trainDummy + h + 4) % 4; sfx('move'); }
  if (h && it.id === 'count') { G.trainCount = clamp(G.trainCount + h, 1, 3); trainingSpawn(); sfx('move'); }
  if (h && it.id === 'cmd') { G.allyCmd = (G.allyCmd + h + 3) % 3; sfx('move'); }
  if ((Input.pressed.start && !Input.pressed.confirm) || Input.pressed.cancel) { sfx('back'); go('play'); return; }
  if (Input.pressed.confirm) {
    sfx('ok');
    if (it.id === 'resume') go('play');
    else if (it.id === 'moves') go('movelist', { back: 'pause' });
    else if (it.id === 'cheats') go('cheats', { from: 'pause' });
    else if (it.id === 'options') go('options', { from: 'pause' });
    else if (it.id === 'dummy') G.trainDummy = (G.trainDummy + 1) % 4;
    else if (it.id === 'count') { G.trainCount = G.trainCount % 3 + 1; trainingSpawn(); }
    else if (it.id === 'cmd') G.allyCmd = (G.allyCmd + 1) % 3;
    else if (it.id === 'quit') { Music.stop(); G = null; go('title', { menu: true }); }
  }
}
function renderPause() {
  renderWorld(); drawHUD();
  px(0, 0, W, H, 'rgba(0,0,0,0.55)');
  text('PAUSED', W / 2, 50, '#f2c94c', 2, 1);
  const items = pauseItems();
  panel(W / 2 - 70, 76, 140, items.length * 12 + 10);
  menuList(items, S.cur, W / 2, 82, 12);
  if (G.mode === 'story') {
    text(DIFFS[G.diff].name + (G.classic ? ' / CLASSIC' : ' / UPGRADED'), W / 2, 200, DIFFS[G.diff].col, 1, 1);
    if (G.cheated) text('CHEATS USED - THIS RUN WILL NOT SAVE OR BANK', W / 2, 212, '#c86aff', 1, 1);
    if (G.loadout.length) text('PERKS: ' + G.loadout.map(id => PERKS.find(p => p.id === id).name).join(', '), W / 2, 224, '#8a88a8', 1, 1);
  }
}

// ------------------------------------------------------------ move list
const MOVE_COMMON = [
  ['RUN', '→ → FAST'],
  ['DODGE ROLL', '↑↑ OR ↓↓'],
  ['GRAB', 'WALK INTO FOE'],
  ['KNEE / THROW', '{X} / ← + {X}'],
  ['VAULT / SUPLEX', '{A} / BACK {X}'],
  ['SCREEN THROW', 'GRAB + {Y}'],
  ['PICK UP / DROP', '{LB} OR {X}'],
  ['THROW WEAPON', '{Y} / {B}'],
  ['ALLY ORDER', '{RB}'],
  ['BREAK FREE', 'MASH'],
];
const MOVE_LISTS = {
  cole: [
    ['COMBO', '{X} {X} {X} {X} {X}'], ['BACK ATTACK', '{Y}'], ['JUMP KNEE / FLYING KICK', '{A} THEN {X}'],
    ['BLITZ', 'RUN + {X}'], ['CHARGE PUNCH', 'HOLD {X}, RELEASE'], ['RISING KNUCKLE', '{B}'], ['BURNING CHARGE', '→ + {B}'],
  ],
  anita: [
    ['KICK COMBO', '{X} {X} {X} {X} {X}'], ['BACK KICK', '{Y}'], ['DOUBLE JUMP', '{A} IN THE AIR'], ['FLYING KICK', '{A} THEN {X}'],
    ['DASH KICK', 'RUN + {X}'], ['HELICOPTER KICK', '{B}'], ['DRIVE KNEE', '→ + {B}'],
  ],
  tank: [
    ['HEAVY COMBO', '{X} {X} {X} {X}'], ['BACK HAMMER', '{Y}'], ['RUNNING CLUTCH', 'RUN + {Y}'], ['BODY SPLASH', '{A} THEN {X}'],
    ['BULL RUSH', 'RUN + {X}'], ['GUT PUNCH', 'HOLD {X}, RELEASE'], ['SPINNING LARIAT', '{B}'], ['QUAKE TACKLE', '→ + {B}'],
  ],
  jett: [
    ['RAPID COMBO', '{X} {X} {X} {X} {X}'], ['SPIN BACK KICK', '{Y}'], ['AIR DASH', '{Y} IN THE AIR'], ['FLYING KICK', '{A} THEN {X}'],
    ['SLIDE KICK', 'RUN + {X}'], ['HELIX KICK', '{B}'], ['BLUR RUSH', '→ + {B}'],
  ],
};
MOVE_LISTS.vex = MOVE_LISTS.anita;
MOVE_LISTS.unit9 = MOVE_LISTS.tank;
const MOVE_EXTRAS = {
  cole: [['m', 2, 'CRASH SHOULDER', '4TH HIT: → + {X}'], ['m', 3, 'METEOR HAYMAKER', 'HOLD {X} LONGER'],
    ['m', 4, 'AIR THROW', '{X} ON A JUMPER'], ['m', 5, 'ELBOW DROP', 'AIR: ↓ + {X}'], ['m', 6, 'BURNING CHARGE+', '→ + {B}'],
    ['s', 'blitz2', 'BLITZ FOLLOW-UP', 'AFTER BLITZ: {X}'], ['s', 'dkick', 'DOUBLE FLYING KICK', 'MOVING JUMP: {X}']],
  anita: [['m', 2, 'SCISSOR TAKEDOWN', '4TH HIT: → + {X}'], ['m', 3, 'AXE KICK', 'HOLD {X}, RELEASE'],
    ['m', 4, 'AIR THROW', '{X} ON A JUMPER'], ['m', 5, 'HEEL DROP', 'AIR: ↓ + {X}'], ['m', 6, 'DRIVE KNEE+', '→ + {B}'],
    ['s', 'triple', 'TRIPLE JUMP', '{A} {A} {A}'], ['s', 'aircombo', 'AIR COMBO', 'AIR KICK HITS: {X}'],
    ['s', 'spindash', 'SPINNING DASH KICK', 'RUN + {X}'], ['s', 'stiletto', 'STILETTO THROW', '{B} IN THE AIR']],
  tank: [['m', 2, 'OVERHEAD SMASH', '3RD HIT: → + {X}'], ['m', 3, 'EARTHQUAKE', 'HOLD {X} LONGER'],
    ['m', 4, 'AIR THROW', '{X} ON A JUMPER'], ['m', 5, 'QUAKE PRESS', 'AIR: ↓ + {X}'], ['m', 6, 'QUAKE TACKLE+', '→ + {B}'],
    ['s', 'clutchx', 'LONG CLUTCH', 'RUN + {Y}'], ['s', 'bulldoze', 'BULLDOZER', 'RUN + {X}'],
    ['s', 'longarm', 'DOUBLE LARIAT', '{B}'], ['s', 'ironhide', 'IRON HIDE', 'PASSIVE']],
  jett: [['m', 2, 'DRILL KICK', '4TH HIT: → + {X}'], ['m', 3, 'RISING BLADE', 'HOLD {X}, RELEASE'],
    ['m', 4, 'AIR THROW', '{X} ON A JUMPER'], ['m', 5, 'METEOR KICK', 'AIR: ↓ + {X}'], ['m', 6, 'BLUR RUSH+', '→ + {B}'],
    ['s', 'airdash2', 'DOUBLE AIR DASH', '{Y} {Y} IN THE AIR'], ['s', 'aircombo', 'AIR COMBO', 'AIR KICK HITS: {X}'],
    ['s', 'boost', 'BOOST SLIDE', 'RUN + {X}'], ['s', 'afterburn', 'AFTERBURN', 'AIR DASH BURNS']],
};
MOVE_EXTRAS.vex = MOVE_EXTRAS.anita;
MOVE_EXTRAS.unit9 = MOVE_EXTRAS.tank;
function updateMovelist() {
  if (Input.pressed.cancel || Input.pressed.confirm || Input.pressed.start) { sfx('back'); go(S.back, { cur: 1 }); }
}
function renderMovelist() {
  if (G) { renderWorld(); px(0, 0, W, H, 'rgba(0,0,0,0.8)'); } else drawCityBackdrop(0, 0.8);
  const cid = G ? G.char : 'cole';
  const r = ROSTER.find(x => x.id === cid);
  text(r.name + ' - MOVE LIST', W / 2, 3, '#f2c94c', 1, 1);
  const up = !(G && G.mode === 'story' && !upgradesOn());
  const cs = SAVE.chars[cid];
  const lvl = up ? masteryLevel(cs.xp) : 0;
  const col = (rows, x0, x1, y0) => rows.forEach(([n, inp, c], i) => {
    const y = y0 + i * 9;
    text(n, x0, y, c || '#a8a8c8');
    gtext(inp, x1, y, c === '#5a5670' ? '#5a5670' : '#fff');
  });
  const own = MOVE_LISTS[cid];
  text(r.tag, 8, 14, '#4ac0e8');
  col(own, 8, 104, 25);
  const y2 = 25 + own.length * 9 + 6;
  text('EARNED AND BOUGHT', 8, y2, '#f2c94c');
  const extras = MOVE_EXTRAS[cid].map(m => {
    const have = m[0] === 'm' ? lvl >= m[1] : up && cs.moves.includes(m[1]);
    return have ? [m[2], m[3], '#f2c94c'] : ['?????', '(' + (m[0] === 'm' ? 'MASTERY ' + m[1] : 'SHOP') + ')', '#5a5670'];
  });
  col(extras, 8, 104, y2 + 11);
  text('EVERY FIGHTER', 228, 14, '#4ac0e8');
  col(MOVE_COMMON, 228, 330, 25);
  const my = 25 + MOVE_COMMON.length * 9 + 8;
  text('MASTERY ' + lvl + ' / 10', 228, my, '#f2c94c');
  bar(228, my + 10, 110, 3,
    lvl >= 10 ? 1 : (cs.xp - (MASTERY_XP[lvl - 1] || 0)) / ((MASTERY_XP[lvl] || 1) - (MASTERY_XP[lvl - 1] || 0)), '#f2c94c', '#2a2640');
  text('SPECIALS COST HEALTH UNLESS THE SP BAR IS FULL', W / 2, 231, '#8a88a8', 1, 1);
}

// ------------------------------------------------------------ cheats
function cheatRows() {
  const rows = CHEAT_DEFS.filter(c => !c.shop || SAVE.cheatsOwned.includes(c.id)).map(c => ({ type: 'cheat', c }));
  if (S.from === 'pause' && G && G.mode === 'story') rows.push({ type: 'act', id: 'skip', label: 'SKIP THIS SCENE' }, { type: 'act', id: 'kill', label: 'KILL ALL FOES' }, { type: 'act', id: 'full', label: 'FULL POWER NOW' });
  rows.push({ type: 'act', id: 'all', label: 'ALL CORE CHEATS ON' }, { type: 'act', id: 'clear', label: 'CLEAR ALL' }, { type: 'act', id: 'back', label: 'BACK' });
  return rows;
}
function updateCheats() {
  const rows = cheatRows();
  moveCursor(rows.length);
  const r = rows[S.cur];
  const h = navH();
  const back = () => { go(S.from === 'pause' ? 'pause' : 'title', S.from === 'pause' ? { cur: 3 } : { menu: true, cur: 5 }); };
  if (Input.pressed.cancel) { sfx('back'); back(); return; }
  if (r.type === 'cheat' && (h || Input.pressed.confirm)) {
    const c = r.c;
    if (c.values) CHEAT[c.id] = (CHEAT[c.id] + (h || 1) + c.values.length) % c.values.length;
    else CHEAT[c.id] = CHEAT[c.id] ? 0 : 1;
    sfx('ok');
    if (G && G.mode === 'story' && cheatsActive()) G.cheated = true;
    if (c.id === 'maxstars' && G && CHEAT.maxstars) G.stars = 3;
    return;
  }
  if (Input.pressed.confirm && r.type === 'act') {
    sfx('ok');
    if (r.id === 'back') { back(); return; }
    if (r.id === 'clear') clearCheats();
    if (r.id === 'all') for (const c of CHEAT_DEFS) if (!c.shop && !c.values) CHEAT[c.id] = 1;
    if (r.id === 'skip' || r.id === 'kill' || r.id === 'full') {
      G.cheated = true;
      if (r.id === 'kill') for (const e of G.ents) if (e.team === 'foe' && !e.killed) { e.hp = 0; }
      if (r.id === 'skip') {
        G.spawnQ = []; for (const e of G.ents) if (e.team === 'foe') e.remove = true;
        G.waveIdx = G.scene.waves.length; G.wave = null; G.lockX = null;
        if (G.sceneIdx < stageDef().scenes.length - 1) { G.fadeDir = 1; G.fade = 0; G.fadeCb = () => loadScene(G.sceneIdx + 1, false); }
        else { G.bossDead = true; G.clearT = 1; }
      }
      if (r.id === 'full') { const p = G.player; p.hp = p.maxHp; p.meter = 1; G.stars = 3; }
      go('play');
      return;
    }
    if (G && G.mode === 'story' && cheatsActive()) G.cheated = true;
  }
}
function renderCheats() {
  if (G) { renderWorld(); px(0, 0, W, H, 'rgba(0,0,0,0.75)'); } else drawCityBackdrop(S.t, 0.7);
  text('CHEATS', W / 2, 8, '#c86aff', 2, 1);
  const rows = cheatRows();
  panel(90, 28, 246, rows.length * 11 + 10);
  rows.forEach((r, i) => {
    const y = 34 + i * 11, sel = i === S.cur;
    const col = sel ? '#f2c94c' : '#e8e8f0';
    if (r.type === 'cheat') {
      text(r.c.name, 100, y, col);
      const v = r.c.values ? r.c.values[CHEAT[r.c.id]] : CHEAT[r.c.id] ? 'ON' : 'OFF';
      text(v, 326, y, CHEAT[r.c.id] ? '#5ad06a' : '#6a6688', 1, 2);
    } else text(r.label, 213, y, col, 1, 1);
    if (sel) text('→', 92, y, '#f2c94c');
  });
  text('ANY CHEAT ON: NO SAVING, NO BANKING, NO GRADES', W / 2, 220, '#c86aff', 1, 1);
  text('CHEATS RESET WHEN THE GAME RELOADS', W / 2, 230, '#6a6688', 1, 1);
}

// ------------------------------------------------------------ options / controls / erase
function optionRows() {
  const o = SAVE.options;
  return [
    { id: 'music', label: 'MUSIC', val: o.music },
    { id: 'sfx', label: 'SOUND FX', val: o.sfx },
    { id: 'vibration', label: 'VIBRATION', val: o.vibration ? 'ON' : 'OFF' },
    { id: 'friendly', label: 'FRIENDLY FIRE', val: o.friendly ? 'ON' : 'OFF' },
    { id: 'scanlines', label: 'SCANLINES', val: o.scanlines ? 'ON' : 'OFF' },
    { id: 'flashing', label: 'FLASHING LIGHTS', val: o.flashing ? 'ON' : 'OFF' },
    { id: 'touch', label: 'TOUCH CONTROLS', val: (o.touch || 'auto').toUpperCase() },
    { id: 'controls', label: 'CONTROLS', val: '>' },
    { id: 'erase', label: 'ERASE SAVE', val: '>' },
    { id: 'back', label: 'BACK', val: '' },
  ];
}
function updateOptions() {
  const rows = optionRows();
  moveCursor(rows.length);
  const r = rows[S.cur], o = SAVE.options;
  const h = navH();
  const back = () => { writeSave(); go(S.from === 'pause' ? 'pause' : 'title', S.from === 'pause' ? { cur: 1 } : { menu: true, cur: 4 }); };
  if (Input.pressed.cancel) { sfx('back'); back(); return; }
  const tog = h || (Input.pressed.confirm ? 1 : 0);
  if (!tog) return;
  if (r.id === 'music') { o.music = clamp(o.music + (h || 1), 0, 10); if (!h && o.music === 10 && Input.pressed.confirm) o.music = 0; applyVolumes(); sfx('move'); }
  if (r.id === 'sfx') { o.sfx = clamp(o.sfx + (h || 1), 0, 10); if (!h && o.sfx === 10 && Input.pressed.confirm) o.sfx = 0; applyVolumes(); sfx('hitL'); }
  if (r.id === 'vibration') { o.vibration = !o.vibration; if (o.vibration) rumble(0.6, 0.6, 250); sfx('move'); }
  if (r.id === 'friendly') { o.friendly = !o.friendly; sfx('move'); }
  if (r.id === 'scanlines') { o.scanlines = !o.scanlines; sfx('move'); }
  if (r.id === 'flashing') { o.flashing = !o.flashing; sfx('move'); }
  if (r.id === 'touch') {
    const seq = ['auto', 'on', 'off'];
    const i = Math.max(0, seq.indexOf(o.touch || 'auto'));
    o.touch = seq[(i + (h > 0 ? 1 : h < 0 ? seq.length - 1 : 1)) % seq.length];
    Touch.apply(); fitCanvas(); sfx('move');
  }
  if (Input.pressed.confirm) {
    if (r.id === 'controls') { sfx('ok'); go('controls', { from: S.from }); return; }
    if (r.id === 'erase') { sfx('ok'); go('erase', { from: S.from, cur: 1 }); return; }
    if (r.id === 'back') { sfx('back'); back(); return; }
  }
  writeSave();
}
function renderOptions() {
  if (G) { renderWorld(); px(0, 0, W, H, 'rgba(0,0,0,0.75)'); } else drawCityBackdrop(S.t, 0.7);
  text('OPTIONS', W / 2, 10, '#f2c94c', 2, 1);
  const rows = optionRows();
  panel(110, 36, 206, rows.length * 14 + 10);
  rows.forEach((r, i) => {
    const y = 43 + i * 14, sel = i === S.cur;
    text(r.label, 124, y, sel ? '#f2c94c' : '#e8e8f0');
    if (typeof r.val === 'number') { for (let k = 0; k < 10; k++) px(230 + k * 7, y, 5, 7, k < r.val ? '#f2c94c' : '#2a2640'); }
    else text(String(r.val), 304, y, '#a8a8c8', 1, 2);
    if (sel) text('→', 114, y, '#f2c94c');
  });
  const desc = { touch: 'ON-SCREEN STICK AND BUTTONS FOR PHONES - AUTO SHOWS THEM ON TOUCH SCREENS ONLY',
    flashing: 'STROBE AND PULSING LIGHT IN THE CLUB STAGES - TURN OFF IF IT BOTHERS YOU',
    friendly: 'YOU AND THE CPU PARTNER CAN HIT EACH OTHER (HALF DAMAGE)', vibration: 'XBOX CONTROLLER RUMBLE (CHROME / EDGE)', controls: 'REMAP BUTTONS AND KEYS', erase: 'DELETE ALL PROGRESS, BANK AND UPGRADES' }[rows[S.cur].id];
  if (desc) text(desc, W / 2, 200, '#8a88a8', 1, 1);
  text(Input.pad ? 'CONTROLLER: ' + Input.pad.id.slice(0, 40).toUpperCase().replace(/[^A-Z0-9 ()-]/g, '') : 'NO CONTROLLER DETECTED - PRESS A BUTTON ON IT', W / 2, 220, Input.pad ? '#5ad06a' : '#6a6688', 1, 1);
}
function updateControls() {
  const rows = REMAP_ACTIONS.length + 2;
  if (S.wait) {
    S.waitT = (S.waitT || 0) + 1;
    if (Input.pressed.cancel && S.waitT > 2 && Input.lastRawKey === 'Escape') { S.wait = null; sfx('back'); return; }
    const a = S.wait;
    const pb = Input.rawPadPressed();
    if (pb >= 0 && S.waitT > 4) {
      SAVE.options.pad = Object.assign({}, SAVE.options.pad || {}, { [a]: pb });
      S.wait = null; sfx('ok'); writeSave(); return;
    }
    if (Input.lastRawKey && S.waitT > 4 && Input.lastRawKey !== S.keyAtStart) {
      const k = Input.lastRawKey;
      if (!/Arrow|Escape|Enter|Key[WASD]$/.test(k)) {
        SAVE.options.keys = Object.assign({}, SAVE.options.keys || {}, { [a]: k });
        S.wait = null; sfx('ok'); writeSave();
      } else { S.keyAtStart = k; sfx('err'); }
    }
    return;
  }
  moveCursor(rows);
  if (Input.pressed.cancel) { sfx('back'); go('options', { from: S.from, cur: 5 }); return; }
  if (Input.pressed.confirm) {
    if (S.cur < REMAP_ACTIONS.length) { S.wait = REMAP_ACTIONS[S.cur]; S.waitT = 0; Input.lastRawKey = null; S.keyAtStart = null; sfx('ok'); }
    else if (S.cur === REMAP_ACTIONS.length) { SAVE.options.pad = null; SAVE.options.keys = null; writeSave(); sfx('ok'); }
    else { sfx('back'); go('options', { from: S.from, cur: 5 }); }
  }
}
function renderControls() {
  if (G) { renderWorld(); px(0, 0, W, H, 'rgba(0,0,0,0.8)'); } else drawCityBackdrop(S.t, 0.75);
  text('CONTROLS', W / 2, 10, '#f2c94c', 2, 1);
  panel(70, 34, 286, 130);
  text('ACTION', 84, 40, '#8a88a8'); text('PAD', 220, 40, '#8a88a8'); text('KEY', 290, 40, '#8a88a8');
  const pm = Input.padMap(), km = Input.keyMap();
  const names = { attack: 'ATTACK', jump: 'JUMP', special: 'SPECIAL', back: 'BACK ATTACK', pick: 'PICK UP', ally: 'ALLY COMMAND' };
  REMAP_ACTIONS.forEach((a, i) => {
    const y = 54 + i * 12, sel = S.cur === i;
    text(names[a], 84, y, sel ? '#f2c94c' : '#e8e8f0');
    const waiting = S.wait === a && Math.floor(S.t / 8) % 2;
    text(waiting ? '...' : PAD_NAMES[pm[a]], 220, y, '#4ac0e8');
    text(waiting ? '...' : keyLabel(km[a]), 290, y, '#5ad06a');
    if (sel) text('→', 74, y, '#f2c94c');
  });
  const y1 = 54 + REMAP_ACTIONS.length * 12 + 4;
  text('RESET TO DEFAULTS', 213, y1, S.cur === REMAP_ACTIONS.length ? '#f2c94c' : '#e8e8f0', 1, 1);
  text('BACK', 213, y1 + 12, S.cur === REMAP_ACTIONS.length + 1 ? '#f2c94c' : '#e8e8f0', 1, 1);
  if (S.wait) text('PRESS A CONTROLLER BUTTON OR A KEY  (ESC CANCELS)', W / 2, 180, '#f2c94c', 1, 1);
  text('MOVE: STICK / D-PAD / ARROWS / WASD    PAUSE: START / ENTER / ESC', W / 2, 206, '#8a88a8', 1, 1);
  text('DEFAULT PAD: X ATTACK  A JUMP  B SPECIAL  Y BACK  LB PICK  RB ALLY', W / 2, 218, '#6a6688', 1, 1);
}
function updateErase() {
  const v = navV() || navH();
  if (v) { S.cur = S.cur ? 0 : 1; sfx('move'); }
  if (Input.pressed.cancel) { sfx('back'); go('options', { from: S.from, cur: 6 }); return; }
  if (Input.pressed.confirm) {
    if (S.cur === 0) { eraseSave(); sfx('brk'); go('options', { from: S.from, cur: 6, msg: 'SAVE ERASED' }); }
    else { sfx('back'); go('options', { from: S.from, cur: 6 }); }
  }
}
function renderErase() {
  drawCityBackdrop(S.t, 0.8);
  panel(90, 70, 246, 90, 'ERASE SAVE');
  text('ERASE ALL PROGRESS?', W / 2, 92, '#e8283a', 1, 1);
  text('BANK ' + fmt(SAVE.bank) + ', UPGRADES, PERKS, GRADES', W / 2, 106, '#e8e8f0', 1, 1);
  text('THIS CANNOT BE UNDONE.', W / 2, 118, '#8a88a8', 1, 1);
  text('YES', 170, 138, S.cur === 0 ? '#e8283a' : '#6a6688', 2, 1);
  text('NO', 256, 138, S.cur === 1 ? '#f2c94c' : '#6a6688', 2, 1);
}

// ------------------------------------------------------------ shop
const SHOP_TABS = ['UPGRADES', 'MOVES', 'PERKS', 'ITEMS', 'EXTRAS', 'MASTERY'];
const shopFighters = () => ROSTER.filter(r => r.live && fighterUnlocked(r)).map(r => r.id);
function shopFid() { return S.fid || SESSION.lastChar || 'cole'; }
function shopRows() {
  const fid = shopFid();
  const cs = SAVE.chars[fid];
  const tab = S.tab;
  if (tab === 1) return SHOP_MOVES[fid].map(m => ({ kind: 'move', m, label: m.name, owned: cs.moves.includes(m.id), price: m.price, desc: m.desc }));
  if (tab === 0) {
    const r = STAT_UPS.map(u => {
      const tier = cs[u.id];
      return { kind: 'stat', u, label: u.name, tier, price: tier < 5 ? TIER_PRICES[tier] : null, desc: u.desc };
    });
    const maxed = STAT_UPS.every(u => cs[u.id] >= 5);
    for (const c of CAPSTONES) r.push({ kind: 'cap', c, label: c.name, owned: cs[c.id], price: cs[c.id] ? null : c.price, locked: !maxed, desc: c.desc + (maxed ? '' : ' NEEDS ALL 4 STATS AT TIER 5.') });
    r.push({ kind: 'respec', label: 'RESPEC (FREE REFUND)', desc: 'Refund every stat and capstone point spent on this fighter.' });
    return r;
  }
  if (tab === 2) {
    const r = PERKS.map(p => ({ kind: 'perk', p, label: p.name, owned: SAVE.perksOwned.includes(p.id), eq: cs.perks.includes(p.id), price: p.price, desc: p.desc }));
    if (SAVE.slots < 4) r.push({ kind: 'slot', label: 'PERK SLOT ' + (SAVE.slots + 1), price: SLOT_PRICES[SAVE.slots + 1], desc: 'Equip one more perk at a time.' });
    return r;
  }
  if (tab === 3) return CONSUMABLES.map(c => ({ kind: 'cons', c, label: c.name, count: SAVE.consumables[c.id], price: c.price, desc: c.desc + ' Used automatically.' }));
  if (tab === 4) {
    const r = SHOP_CHEATS.map(c => ({ kind: 'cheat', c, label: c.name + ' (CHEAT)', owned: SAVE.cheatsOwned.includes(c.id), price: c.price, desc: c.desc + ' Toggle it in CHEATS.' }));
    for (const u of SHOP_UNLOCKS) r.push({ kind: 'unlock', u, label: u.name, owned: u.char ? SAVE.unlocks[u.id] : SAVE.cheatsOwned.includes(u.id), price: u.price, desc: u.desc });
    return r;
  }
  return MASTERY_BY_CHAR[fid].map((m, i) => ({ kind: 'mastery', label: 'LV ' + (i + 1) + '  ' + (m ? m.name : 'BASE MOVESET'), lvl: i + 1, m, desc: m ? (m.live ? 'INPUT: ' + m.input : 'Coming in a later build.') : 'Everything in the move list.' }));
}
function spendBank(price) {
  if (SAVE.bank < price) { sfx('err'); S.msg = 'NOT ENOUGH POINTS'; S.msgT = 90; return false; }
  SAVE.bank -= price; sfx('buy'); return true;
}
function updateShop() {
  Music.play('shop');
  const rows = shopRows();
  if (S.cur >= rows.length) S.cur = rows.length - 1;
  moveCursor(rows.length);
  const h = navH() || (Input.pressed.pick ? -1 : 0) || (Input.pressed.ally ? 1 : 0);
  if (h) { S.tab = (S.tab + h + SHOP_TABS.length) % SHOP_TABS.length; S.cur = 0; S.confirmRespec = false; sfx('move'); return; }
  if (Input.pressed.back) { const fs = shopFighters(); S.fid = fs[(fs.indexOf(shopFid()) + 1) % fs.length]; S.confirmRespec = false; sfx('move'); return; }
  if (Input.pressed.cancel) { sfx('back'); writeSave(); go('title', { menu: true, cur: 1 }); return; }
  if (!Input.pressed.confirm) return;
  const r = rows[S.cur], cs = SAVE.chars[shopFid()];
  if (r.kind === 'stat') {
    if (r.tier >= 5) { sfx('err'); S.msg = 'MAXED'; S.msgT = 60; }
    else if (spendBank(r.price)) cs[r.u.id]++;
  } else if (r.kind === 'cap') {
    if (r.owned) { sfx('err'); }
    else if (r.locked) { sfx('err'); S.msg = 'MAX ALL 4 STATS FIRST'; S.msgT = 90; }
    else if (spendBank(r.price)) cs[r.c.id] = true;
  } else if (r.kind === 'respec') {
    if (!S.confirmRespec) { S.confirmRespec = true; sfx('warn'); S.msg = 'PRESS AGAIN TO REFUND'; S.msgT = 120; return; }
    let refund = 0;
    for (const u of STAT_UPS) { for (let t = 0; t < cs[u.id]; t++) refund += TIER_PRICES[t]; cs[u.id] = 0; }
    for (const c of CAPSTONES) if (cs[c.id]) { refund += c.price; cs[c.id] = false; }
    SAVE.bank += refund; S.confirmRespec = false;
    sfx('buy'); S.msg = 'REFUNDED ' + fmt(refund); S.msgT = 120;
  } else if (r.kind === 'move') {
    if (r.owned) { sfx('err'); S.msg = 'OWNED'; S.msgT = 60; }
    else if (spendBank(r.price)) cs.moves.push(r.m.id);
  } else if (r.kind === 'perk') {
    if (!r.owned) { if (spendBank(r.price)) { SAVE.perksOwned.push(r.p.id); if (cs.perks.length < SAVE.slots) cs.perks.push(r.p.id); } }
    else if (r.eq) { cs.perks = cs.perks.filter(x => x !== r.p.id); sfx('back'); }
    else if (cs.perks.length < SAVE.slots) { cs.perks.push(r.p.id); sfx('ok'); }
    else { sfx('err'); S.msg = 'ALL SLOTS FULL - UNEQUIP ONE'; S.msgT = 90; }
  } else if (r.kind === 'slot') {
    if (spendBank(r.price)) SAVE.slots++;
  } else if (r.kind === 'cons') {
    if (r.count >= 9) { sfx('err'); S.msg = 'CARRY LIMIT 9'; S.msgT = 60; }
    else if (spendBank(r.price)) SAVE.consumables[r.c.id]++;
  } else if (r.kind === 'cheat') {
    if (r.owned) { sfx('err'); S.msg = 'OWNED - TOGGLE IT IN CHEATS'; S.msgT = 90; }
    else if (spendBank(r.price)) SAVE.cheatsOwned.push(r.c.id);
  } else if (r.kind === 'unlock') {
    if (r.owned) sfx('err');
    else if (spendBank(r.price)) { if (r.u.char) SAVE.unlocks[r.u.id] = true; else SAVE.cheatsOwned.push(r.u.id); }
  } else sfx('move');
  S.confirmRespec = r.kind === 'respec' ? S.confirmRespec : false;
  writeSave();
}
function renderShop() {
  drawCityBackdrop(S.t * 0.2, 0.78);
  text('SHOP', 10, 6, '#f2c94c', 2);
  text('BANK ' + fmt(SAVE.bank), W - 8, 10, '#f2c94c', 1, 2);
  SHOP_TABS.forEach((t, i) => {
    const x = 10 + i * 69, sel = i === S.tab;
    px(x, 26, 66, 12, sel ? '#e8283a' : '#2a2050');
    text(t, x + 33, 29, sel ? '#fff' : '#a8a8c8', 1, 1, null);
  });
  gtext('{LB} {RB} OR ←→ TABS   {Y} SWITCH FIGHTER', 10, 228, '#6a6688');
  const rows = shopRows();
  const fid = shopFid();
  const cs = SAVE.chars[fid];
  const fname = ROSTER.find(x => x.id === fid).name;
  const perFighter = S.tab <= 2 || S.tab === 5;
  panel(10, 44, 406, 150, perFighter ? 'FIGHTER: ' + fname + (S.tab === 5 ? '   MASTERY ' + masteryLevel(cs.xp) + '  (' + fmt(cs.xp) + ' XP)' : '') : null);

  const top = 60;
  rows.forEach((r, i) => {
    const y = top + i * 12, sel = i === S.cur;
    if (y > 188) return;
    let col = sel ? '#f2c94c' : '#e8e8f0';
    if (r.locked || (r.kind === 'mastery' && r.m && !r.m.live)) col = sel ? '#b8a860' : '#5a5670';
    text(r.label, 24, y, col);
    if (sel) text('→', 14, y, '#f2c94c');
    let right = '';
    if (r.kind === 'stat') { for (let k = 0; k < 5; k++) px(200 + k * 10, y, 8, 7, k < r.tier ? '#f2c94c' : '#2a2640'); right = r.price ? fmt(r.price) : 'MAX'; }
    else if (r.kind === 'cap') right = r.owned ? 'OWNED' : r.locked ? 'LOCKED ' + fmt(r.price) : fmt(r.price);
    else if (r.kind === 'perk') right = r.eq ? 'EQUIPPED' : r.owned ? 'OWNED' : fmt(r.price);
    else if (r.kind === 'slot') right = fmt(r.price);
    else if (r.kind === 'cons') right = 'HAVE ' + r.count + '   ' + fmt(r.price);
    else if (r.kind === 'cheat' || r.kind === 'unlock' || r.kind === 'move') right = r.owned ? 'OWNED' : fmt(r.price);
    else if (r.kind === 'mastery') { const l = masteryLevel(cs.xp); right = l >= r.lvl ? 'LEARNED' : fmt(MASTERY_XP[r.lvl - 1]) + ' XP'; }
    const rc = right === 'EQUIPPED' || right === 'LEARNED' ? '#5ad06a' : right === 'OWNED' ? '#4ac0e8' : (r.price && r.price > SAVE.bank ? '#8a5a5a' : '#f2c94c');
    text(right, 404, y, rc, 1, 2);
  });
  if (S.tab === 2) text('SLOTS ' + cs.perks.length + '/' + SAVE.slots, 370, 47, '#fff', 1, 2, null);
  const r = rows[S.cur];
  panel(10, 198, 406, 26);
  text(r ? r.desc : '', 16, 204, '#e8e8f0');
  if (S.tab <= 1) text('UPGRADES AND MOVES ARE OFF IN CLASSIC RULES', 16, 214, '#6a6688');
  if (S.tab === 2) text('PERKS ARE BOUGHT ONCE, EQUIPPED PER FIGHTER', 16, 214, '#6a6688');
  if (S.tab === 5) text('MASTERY IS EARNED BY PLAYING, NOT BOUGHT', 16, 214, '#6a6688');
  if (S.msgT > 0) { S.msgT--; text(S.msg, 404, 214, '#e8283a', 1, 2); }
}

// ------------------------------------------------------------ stage end tally
function computeGrade() {
  const p = G.player;
  const dmgPts = 40 * (1 - Math.min(1, G.dmgTaken / ((p ? p.maxHp : 100) * 3)));
  const livesPts = G.livesLost === 0 ? 20 : G.livesLost === 1 ? 10 : 0;
  const comboPts = 20 * Math.min(1, G.bestCombo / 20);
  const par = 60 * 60 * 4;
  const speedPts = 20 * clamp((par * 1.75 - G.stageFrames) / (par * 0.75), 0, 1);
  let total = dmgPts + livesPts + comboPts + speedPts;
  let g = GRADES.find(x => total >= x.min);
  if (G.continued && 'SAB'.includes(g.g)) g = GRADES.find(x => x.g === 'C');
  return { g, total, dmgPts, livesPts, comboPts, speedPts };
}
function finishStage() {
  const lifeB = Math.max(0, G.lives) * 1000;
  const comboB = G.bestCombo * 100;
  const nodmgB = G.dmgTaken === 0 ? 20000 : 0;
  const itemB = G.breaks * 300;
  const pre = G.score;
  const lines = [
    ['STAGE SCORE', pre - G.stageScore0],
    ['LIFE BONUS', lifeB],
    ['COMBO BONUS', comboB],
    ['NO-DAMAGE BONUS', nodmgB],
    ['ITEMS BONUS', itemB],
  ];
  addScore(lifeB + comboB + nodmgB + itemB);
  const gr = computeGrade();
  const earned = G.score - G.stageScore0;
  const T = { lines, gr, earned, bank: 0, xp: 0, lvlUp: null, saved: false, newBest: false };
  if (!G.cheated) {
    const d = diffOf();
    T.bank = Math.round(earned * d.bank * gr.g.mult);
    SAVE.bank += T.bank;
    const cs = charSave();
    const before = masteryLevel(cs.xp);
    T.xp = Math.round(G.kos * 10 + 300 + 400 * gr.g.mult);
    cs.xp += T.xp;
    const after = masteryLevel(cs.xp);
    if (after > before) T.lvlUp = { lvl: after, move: MASTERY_BY_CHAR[G.char][after - 1] };
    if (!G.rush) SAVE.reached = Math.min(8, Math.max(SAVE.reached, G.stage + 1));
    const gk = `${G.classic ? 'c' : 'u'}_${G.rush ? 'rush' : G.diff}_${G.stage}`;
    const old = SAVE.grades[gk];
    if (!old || GRADE_ORDER.indexOf(gr.g.g) < GRADE_ORDER.indexOf(old)) SAVE.grades[gk] = gr.g.g;
    const bk = `${G.classic ? 'c' : 'u'}_${G.diff}`;
    if (!SAVE.best[bk] || G.score > SAVE.best[bk]) { SAVE.best[bk] = G.score; T.newBest = true; }
    SAVE.stats.kos += G.kos; SAVE.stats.clears++;
    if (G.rush) {
      const rk = 'd' + G.diff;
      T.rushTime = G.stageFrames;
      if (!SAVE.bossRushTimes[rk] || G.stageFrames < SAVE.bossRushTimes[rk]) { SAVE.bossRushTimes[rk] = G.stageFrames; T.rushBest = true; }
    } else {
      // beating Vex on the highway wins her over
      if (G.stage === 5 && !SAVE.unlocks.vex) { SAVE.unlocks.vex = true; T.unlocked = 'VEX JOINS YOU'; }
      if (G.stage === 8) {
        SAVE.cleared = true;
        if (!SAVE.unlocks.bossrush) { SAVE.unlocks.bossrush = true; T.unlocked = 'BOSS RUSH UNLOCKED'; }
        T.ending = endingFor();
        SAVE.endings[T.ending.id] = true;
      }
    }
    T.saved = writeSave();
  }
  Music.play('menu');
  go('tally', { T, step: 0 });
}
// which of the three endings this clear earned
function endingFor() {
  if (G.diff >= 1 && G.freedUnit) return ENDINGS.best;
  if (G.diff >= 1) return ENDINGS.good;
  return ENDINGS.ok;
}
function updateTally() {
  if (S.t % 18 === 0 && S.step < 9) { S.step++; sfx(S.step === 6 ? 'hitX' : 'move'); if (S.step === 8 && S.T.lvlUp) sfx('levelup'); }
  if ((Input.pressed.confirm || Input.pressed.start) && S.t > 20) {
    if (S.step < 9) { S.step = 9; return; }
    sfx('ok');
    if (G.rush) { Music.stop(); go('title', { menu: true, cur: 3 }); return; }
    if (G.stage >= 8) { go('ending', { e: S.T.ending || endingFor(), line: 0, t2: 0 }); return; }
    const nx = STAGES[G.stage];
    if (nx && nx.live) go('stageintro', { n: nx.n });
    else go('coming', {});
  }
}
function renderTally() {
  drawCityBackdrop(S.t * 0.2, 0.8);
  const T = S.T;
  text('STAGE ' + G.stage + ' CLEAR', W / 2, 8, '#f2c94c', 2, 1);
  text(DIFFS[G.diff].name + (G.classic ? ' / CLASSIC' : ' / UPGRADED'), W / 2, 26, DIFFS[G.diff].col, 1, 1);
  panel(14, 38, 220, 96);
  T.lines.forEach(([n, v], i) => {
    if (S.step <= i) return;
    text(n, 22, 46 + i * 12, '#a8a8c8');
    text(fmt(v), 226, 46 + i * 12, '#fff', 1, 2);
  });
  if (S.step > 5) { text('TOTAL', 22, 110, '#f2c94c'); text(fmt(G.score), 226, 110, '#f2c94c', 1, 2); if (T.newBest) text('NEW BEST!', 226, 121, '#5ad06a', 1, 2); }
  panel(242, 38, 170, 96, 'GRADE');
  if (S.step > 6) {
    const g = T.gr.g;
    const s = 6 + (S.step === 7 ? Math.max(0, 3 - (S.t % 18) / 4) : 0);
    text(g.g, 290, 60, g.col, Math.round(s), 1);
    const c = T.gr;
    [['DAMAGE', c.dmgPts, 40], ['LIVES', c.livesPts, 20], ['COMBO', c.comboPts, 20], ['SPEED', c.speedPts, 20]].forEach(([n, v, m], i) => {
      text(n, 328, 56 + i * 12, '#a8a8c8'); bar(372, 58 + i * 12, 34, 3, v / m, '#f2c94c', '#2a2640');
    });
    if (G.continued) text('CONTINUED: MAX C', 328, 110, '#e8283a');
  }
  panel(14, 140, 398, 70);
  if (S.step > 7) {
    if (G.cheated) text('CHEATS WERE USED - NOTHING SAVED OR BANKED', W / 2, 150, '#c86aff', 1, 1);
    else {
      text('BANKED  +' + fmt(T.bank), 24, 150, '#f2c94c', 1);
      text(`${fmt(T.earned)} × ${DIFFS[G.diff].bank} (${DIFFS[G.diff].name}) × ${T.gr.g.mult} (GRADE ${T.gr.g.g})`, 24, 160, '#8a88a8');
      text('MASTERY +' + fmt(T.xp) + ' XP', 24, 174, '#4ac0e8');
      if (T.lvlUp && S.step > 8) {
        text('MASTERY LEVEL ' + T.lvlUp.lvl + '!', 24, 186, Math.floor(S.t / 8) % 2 ? '#f2c94c' : '#fff');
        if (T.lvlUp.move) text('NEW MOVE: ' + T.lvlUp.move.name + (T.lvlUp.move.live ? '' : ' (LATER BUILD)'), 24, 196, '#5ad06a');
      }
      text('BANK ' + fmt(SAVE.bank), 402, 150, '#fff', 1, 2);
      text(T.saved ? 'SAVED' : 'COULD NOT SAVE', 402, 196, T.saved ? '#5ad06a' : '#e8283a', 1, 2);
    }
  }
  if (S.step >= 9 && Math.floor(S.t / 24) % 2 === 0) text('PRESS START', W / 2, 222, '#fff', 1, 1);
}
function updateStageIntro() {
  Music.play('menu');
  if ((Input.pressed.confirm || Input.pressed.start) && S.t > 30) {
    sfx('ok');
    G.stage = S.n;
    startStage();
    go('play');
  }
}
function renderStageIntro() {
  drawCityBackdrop(S.t * 0.3 + S.n * 200, 0.8);
  text('STAGE ' + S.n, W / 2, 50, '#e8283a', 3, 1);
  text(STAGES[S.n - 1].name, W / 2, 78, '#f2c94c', 2, 1);
  (STAGE_TEXT[S.n] || []).forEach((l, i) => text(l, W / 2, 120 + i * 14, '#e8e8f0', 1, 1));
  text('SCORE ' + fmt(G.score) + '   LIVES ' + G.lives, W / 2, 180, '#8a88a8', 1, 1);
  if (S.t > 30 && Math.floor(S.t / 24) % 2 === 0) text('PRESS START', W / 2, 206, '#fff', 1, 1);
}
// ------------------------------------------------------------ ending + credits
const CREDITS = [
  ['RAGE CIRCUIT', 2],
  ['', 1],
  ['DESIGN, CODE, ART AND MUSIC', 1],
  ['BUILT FOR MICHAEL', 1],
  ['', 1],
  ['THE CAST', 1],
  ['COLE BRENNAN    ANITA KNOCKOUT', 1],
  ['BRUNO "TANK" KOVAC    JETT RIVERA', 1],
  ['VEX    UNIT-9', 1],
  ['', 1],
  ['AND THE SYNDICATE', 1],
  ['BIG BRICK HARLAN    RUBY & ONYX', 1],
  ['WRECKER MK-II    RIVET    GAUGE HOLLIS', 1],
  ['SLAG    UNIT-8 WARDEN', 1],
  ['MARQUESS DRAY', 1],
  ['', 1],
  ['NO ASSETS. ONE HTML FILE.', 1],
  ['', 1],
  ['THANKS FOR PLAYING', 2],
];
function updateEnding() {
  Music.play('ending');
  if (Input.pressed.confirm || Input.pressed.start) {
    if (S.line < S.e.lines.length) { S.line = S.e.lines.length; return; }
    if (S.t2 < 1) { S.t2 = 1; S.t = 0; return; }
    sfx('ok'); G = null; go('title', { menu: true });
    return;
  }
  if (S.t2 < 1) { if (S.t % 26 === 0 && S.line < S.e.lines.length) S.line++; }
  else if (S.t > 60 + CREDITS.length * 34) { S.t2 = 2; }
}
function renderEnding() {
  drawCityBackdrop(S.t * 0.25, S.t2 ? 0.8 : 0.72);
  if (S.t2 < 1) {
    text(S.e.title, W / 2, 26, S.e.col, 2, 1);
    for (let i = 0; i < S.line && i < S.e.lines.length; i++) text(S.e.lines[i], W / 2, 68 + i * 14, '#e8e8f0', 1, 1);
    if (S.line >= S.e.lines.length) {
      const got = Object.keys(SAVE.endings).length;
      text('ENDINGS SEEN: ' + got + ' / 3', W / 2, 190, '#8a88a8', 1, 1);
      if (S.e.id !== 'best') text('THE BEST ENDING NEEDS MEDIUM OR HARDER - AND THE CAPSULE ON THE BIRTHING FLOOR.', W / 2, 202, '#8a88a8', 1, 1);
      if (Math.floor(S.t / 24) % 2 === 0) text('PRESS START FOR THE CREDITS', W / 2, 220, '#f2c94c', 1, 1);
    }
    return;
  }
  const off = S.t2 === 2 ? 60 + CREDITS.length * 34 : S.t;
  let y = H + 10 - (off - 60) * 0.55;
  for (const [line, sz] of CREDITS) {
    if (y > -20 && y < H + 20) text(line, W / 2, y, sz > 1 ? '#f2c94c' : '#e8e8f0', sz, 1);
    y += sz > 1 ? 34 : 20;
  }
  if (S.t2 === 2 && Math.floor(S.t / 24) % 2 === 0) text('PRESS START', W / 2, 220, '#f2c94c', 1, 1);
}
function updateComing() { if ((Input.pressed.confirm || Input.pressed.start) && S.t > 20) { sfx('ok'); G = null; go('title', { menu: true }); } }
function renderComing() {
  drawCityBackdrop(S.t, 0.7);
  text('TO BE CONTINUED', W / 2, 70, '#e8283a', 2, 1);
  const nx = STAGES[G ? G.stage : 3] || STAGES[3];
  text('STAGE ' + nx.n + ' - ' + nx.name, W / 2, 100, '#fff', 1, 1);
  text('ARRIVES IN THE NEXT BUILD.', W / 2, 112, '#fff', 1, 1);
  text('YOUR BANK AND MASTERY ARE SAVED.', W / 2, 134, '#8a88a8', 1, 1);
  text('SPEND THEM IN THE SHOP, THEN RUN IT BACK ON A HARDER SETTING.', W / 2, 146, '#8a88a8', 1, 1);
  if (Math.floor(S.t / 24) % 2 === 0) text('PRESS START', W / 2, 200, '#f2c94c', 1, 1);
}

// ------------------------------------------------------------ continue / game over
function updateContinue() {
  if (S.t % 60 === 0 && S.t > 0) { S.n--; sfx('move'); }
  if (S.n < 0 || Input.pressed.cancel) { go('gameover', {}); return; }
  if ((Input.pressed.confirm || Input.pressed.start) && S.t > 30) {
    sfx('ok');
    G.score = 0; G.nextOneUp = TUNING.oneUpEvery; G.starsFromScore = 1; G.lives = 5; G.continued = true; G.gameOver = false;
    G.stars = baseStars();
    G.allyLives = 5;
    const i = G.sceneIdx;
    G.breakTotal -= stageDef().scenes[i].breakables.length;
    loadScene(i, true);
    G.player.inv = TUNING.respawnInv;
    G.banner = { s: 'CONTINUE', t: 90, col: '#fff' };
    go('play');
  }
}
function renderContinue() {
  renderWorld();
  px(0, 0, W, H, 'rgba(0,0,0,0.7)');
  text('CONTINUE?', W / 2, 70, '#fff', 3, 1);
  text(String(Math.max(0, S.n)), W / 2, 110, '#e8283a', 4, 1);
  text('SCORE RESETS TO 0 - 5 LIVES - SAME SCENE', W / 2, 160, '#8a88a8', 1, 1);
  gtext('{A} YES     {B} NO', 170, 190);
}
function updateGameOver() { if ((Input.pressed.confirm || Input.pressed.start) && S.t > 40 || S.t > 60 * 8) { G = null; go('title', { menu: true }); } }
function renderGameOver() {
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
  text('GAME OVER', W / 2, 100, '#e8283a', 3, 1);
  text('NOTHING BANKED FROM AN UNFINISHED STAGE', W / 2, 140, '#6a6688', 1, 1);
}

// ------------------------------------------------------------ sound test / gallery
// Every track the game can play, whichever engine owns it: the band's list
// first (that is nearly all of them now), then anything left on the old
// engine that was never rewritten.
function musicList() {
  const out = RCBand.names().slice();
  for (const n in TRACKS) if (out.indexOf(n) < 0) out.push(n);
  return out;
}
function updateSoundTest() {
  const names = musicList().concat(['STOP']);
  moveCursor(names.length);
  if (Input.pressed.confirm) { const n = names[S.cur]; if (n === 'STOP') Music.stop(); else { Music.stop(); Music.play(n); } }
  if (Input.pressed.cancel) { sfx('back'); go('title', { menu: true }); }
}
function renderSoundTest() {
  drawCityBackdrop(S.t, 0.7);
  text('SOUND TEST', W / 2, 16, '#f2c94c', 2, 1);
  const names = musicList().map(n => n.toUpperCase() + (Music.name === n ? '  ♪' : '')).concat(['STOP']);
  // the list is long enough now that it needs two columns and a smaller step
  const half = Math.ceil(names.length / 2), step = 10;
  panel(96, 40, 234, half * step + 12);
  // -1 as the cursor means no row is selected, which is how the column the
  // player is not in stays quiet. (The sixth argument is alignment, not a
  // cursor flag - passing a boolean there silently left-aligns the column.)
  menuList(names.slice(0, half).map(n => n.replace('♪', '*')), S.cur < half ? S.cur : -1, W / 2 - 58, 46, step);
  menuList(names.slice(half).map(n => n.replace('♪', '*')), S.cur >= half ? S.cur - half : -1, W / 2 + 58, 46, step);
}
const GALLERY = [
  { look: 'punkA', name: 'PUNK', bio: 'STREET MUSCLE. CHEAP, LOUD, EVERYWHERE. PICKS UP ANY WEAPON HE FINDS.' },
  { look: 'bladeA', name: 'BLADE', bio: 'KNIFE ARTIST. SLASHES UP CLOSE AND THROWS FROM RANGE. KNOCK THE KNIFE LOOSE.' },
  { look: 'bruiserA', name: 'BRUISER', bio: 'SLOW AND HEAVY. GRABS AND SLAMS. ON HARD HE CHARGES FROM ACROSS THE SCREEN.' },
  { look: 'kickerA', name: 'KICKER', bio: 'KEEPS HER DISTANCE, THEN FLIES IN WITH A JUMP KICK. ROLL OR MEET HER EARLY.' },
  { look: 'whipA', name: 'WHIP', pose: 'wWind', bio: 'CLUB ENFORCER WITH A LONG REACH. HER WHIP HITS FROM TWICE PUNCHING DISTANCE. GET INSIDE IT.' },
  { look: 'robot', name: 'SYNDICATE ROBOT', bio: 'ARMORED. SHRUGS OFF LIGHT HITS, CANNOT BE GRABBED, AND BLOWS UP WHEN IT DIES. STAND BACK.' },
  { look: 'ruby', name: 'RUBY & ONYX', pose: 'tTaunt', bio: 'THE VOSS TWINS. CARTWHEELS DOWN YOUR LANE AND FLIPS OVER YOUR HEAD. THEY TAUNT AFTER A CARTWHEEL - GRAB THEM THEN.' },
  { look: 'rivet', name: 'RIVET', bio: 'PILOTS THE WRECKER MK-II. OVERHEAT THE MECH WITH STEADY DAMAGE, THEN FINISH THE PILOT WHEN HE BAILS OUT.' },
  { look: 'brick', name: 'BIG BRICK HARLAN', bio: 'BOUNCER TURNED SYNDICATE ENFORCER. CHARGES, SLAMS, RIPS OUT LAMPPOSTS. DAZE HIM, GRAB HIM, THROW HIM AT THE SCREEN.' },
  { look: 'suitA', name: 'SYNDICATE SUIT', bio: 'MIDDLE MANAGEMENT WITH A KNIFE IN THE JACKET. FAST, TIDY, AND HE NEVER COMES ALONE.' },
  { look: 'bikerA', name: 'BIKER', bio: 'HIGHWAY CREW. THE QUICKEST THING ON FOOT IN THE GAME AND HE THROWS WHAT HE IS HOLDING.' },
  { look: 'guardA', name: 'WORKS GUARD', bio: 'COMPANY SECURITY WITH A STUN BATON. THE BATON HAS REACH - TAKE IT OFF HIM AND USE IT.' },
  { look: 'robotB', name: 'HEAVY UNIT', bio: 'THE BIG COUSIN OF THE SYNDICATE ROBOT. MORE ARMOR, WIDER BLAST WHEN IT GOES. DO NOT BE NEXT TO IT.' },
  { look: 'gauge', name: 'GAUGE HOLLIS', bio: 'RUNS THE RAIL CREW. SWINGS A COUPLER LIKE A CLUB AND WILL RUN THE WHOLE LENGTH OF THE ROOF TO REACH YOU.' },
  { look: 'vex', name: 'VEX', pose: 'vexReady', bio: 'THE SYNDICATE PAID HER TO END THIS ON THE HIGHWAY. SHE BLINKS BEHIND YOU AND THROWS KNIVES. BEAT HER AND SHE COMES OVER.' },
  { look: 'slag', name: 'SLAG', bio: 'FOUNDRY FOREMAN. EVERYTHING HE TOUCHES CATCHES. HIS SLAM LEAVES FIRE ON BOTH SIDES - MOVE OFF THE POOLS.' },
  { look: 'warden', name: 'UNIT-8 "WARDEN"', pose: 'wardenAim', bio: 'THE PROTOTYPE THEY KEPT. IT SIGHTS DOWN YOUR LANE BEFORE IT FIRES - CHANGE ROWS WHEN THE STRIPE LIGHTS UP.' },
  { look: 'dray', name: 'MARQUESS DRAY', bio: 'HE BOUGHT THE CITY AND KEEPS IT UNDER GLASS ON HIS OWN FLOOR. WHEN HIS SUIT GOES DOWN, SOMETHING WORSE STANDS UP IN IT.' },
  { look: 'unit9', name: 'UNIT-9', bio: 'STILL IN ITS CAPSULE ON THE BIRTHING FLOOR. BREAK IT AND IT WALKS OUT ON ITS OWN - AND IT REMEMBERS WHO OPENED IT.' },
];
function updateGallery() {
  const h = navH(); if (h) { S.page = (S.page + h + GALLERY.length) % GALLERY.length; sfx('move'); }
  if (Input.pressed.cancel || Input.pressed.confirm) { sfx('back'); go('title', { menu: true }); }
}
function renderGallery() {
  drawCityBackdrop(S.t, 0.75);
  const g = GALLERY[S.page];
  text('GALLERY ' + (S.page + 1) + '/' + GALLERY.length, W / 2, 10, '#f2c94c', 1, 1);
  const glook = LOOKS[g.look];
  const gp = g.pose || mapPose(glook, ['idle', 'idle2'][Math.floor(S.t / 30) % 2]);
  drawFigure(120, 200, 1, gp, glook, { scale: 1.5 / Math.max(1, (glook.scale || 1) * 1.15) });
  text(g.name, 220, 60, '#e8283a', 2);
  const words = g.bio.split(' '); let line = '', y = 90;
  for (const w of words) { if ((line + w).length > 30) { text(line, 220, y, '#e8e8f0'); y += 11; line = ''; } line += w + ' '; }
  text(line, 220, y, '#e8e8f0');
  text('←→ BROWSE', W / 2, 228, '#6a6688', 1, 1);
}

// ------------------------------------------------------------ main loop
const SCREENS = {
  title: [updateTitle, renderTitle], setup: [updateSetup, renderSetup], intro: [updateIntro, renderIntro],
  play: [updatePlay, renderPlay], pause: [updatePause, renderPause], movelist: [updateMovelist, renderMovelist],
  cheats: [updateCheats, renderCheats], options: [updateOptions, renderOptions], controls: [updateControls, renderControls],
  erase: [updateErase, renderErase], shop: [updateShop, renderShop], tally: [updateTally, renderTally],
  ending: [updateEnding, renderEnding], coming: [updateComing, renderComing], stageintro: [updateStageIntro, renderStageIntro], continue: [updateContinue, renderContinue], gameover: [updateGameOver, renderGameOver],
  soundtest: [updateSoundTest, renderSoundTest], gallery: [updateGallery, renderGallery],
};
let frozen = false, last = 0, acc = 0;
function tick() {
  Input.poll();
  const s = SCREENS[SCREEN];
  if (s) s[0]();
  S.t++;
}
function render() {
  ctx.setTransform(PX, 0, 0, PX, 0, 0);
  ctx.imageSmoothingEnabled = false;
  const s = SCREENS[SCREEN];
  if (s) s[1]();
  if (SAVE.options.scanlines) { ctx.fillStyle = 'rgba(0,0,0,0.18)'; for (let y = 0; y < H; y += 2) ctx.fillRect(0, y, W, 1); }
}
function frame(ts) {
  if (!frozen) {
    if (!last) last = ts;
    acc += Math.min(100, ts - last);
    last = ts;
    let n = 0;
    while (acc >= STEP && n < 4) { tick(); acc -= STEP; n++; }
    if (n) render();
  }
  requestAnimationFrame(frame);
}
function boot() {
  loadSave();
  // The viewport meta decides whether a phone lets the page be pinched and
  // double-tap zoomed, which would fight every swipe. The artifact build does
  // not own the document head, so set it here either way.
  try {
    let mv = document.querySelector('meta[name="viewport"]');
    if (!mv) { mv = document.createElement('meta'); mv.name = 'viewport'; document.head.appendChild(mv); }
    mv.content = 'width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover';
  } catch (_) {}
  Touch.apply();
  fitCanvas();
  clearCheats();
  go('title');
  cv.focus();
  requestAnimationFrame(frame);
}
// test hooks
window.__rc = {
  get G() { return G; }, get SCREEN() { return SCREEN; }, get S() { return S; }, SAVE: () => SAVE,
  go, startRun, CHEAT, Input, tick, render, POSES, LOOKS, MOVES, spawnEnemy, spawnBoss, loadScene, writeSave, loadSave,
  freeze(v) { frozen = v; }, setIntent(fn) { if (G) G.demoIntent = fn; }, finishStage, computeGrade, masteryLevel,
  ctx, eraseSave, applyHit, SESSION, KITS, MASTERY_BY_CHAR, SHOP_MOVES, MOVE_LISTS, ROSTER, STAGES, STAGE_DATA, BOSS_DEFS,
  startMove, startGrab, ENEMY_TYPES, endingFor, ENDINGS, BOSS_RUSH, BOSS_RUSH_STAGE, spawnItem, doSpecial,
  // music: the suite needs to break the capsule, phase the final boss, and
  // start the audio context by hand, since nothing in a headless test ever
  // makes the user gesture that normally unlocks it
  breakProp, phaseInto, musicList, initAudio,
  // the world with no HUD over it - for grabbing a clean backdrop still
  renderWorldOnly() { ctx.setTransform(PX, 0, 0, PX, 0, 0); ctx.imageSmoothingEnabled = false; renderWorld(); },
};
boot();
