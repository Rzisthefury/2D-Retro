// ============================================================ TOUCH CONTROLS
// Playing this on a phone. The controls are DOM elements rather than something
// drawn into the canvas, for two reasons: they have to sit in the black bars
// OUTSIDE the 426x240 picture, and they must not scale with the pixel art - a
// button that is 12 game-pixels wide is unusable however crisp it looks.
//
// Nothing in the fight code knows this exists. The whole layer does one job:
// set flags that Input.poll() ORs in alongside the keyboard and the pad. So
// every move, every menu and every test keeps working off the same `Input`.
//
// Michael's choices (2026-09-30): floating thumbstick, four buttons (attack,
// jump, special, back attack) plus a dedicated dodge and a pause, controls in
// the side bars so they never cover the picture.

const TOUCH_R = 52;          // stick throw, in CSS pixels
const TOUCH_DEAD = 0.24;     // below this the stick reads as centred
const TOUCH_RUN = 0.72;      // push past this and you run
const TOUCH_MIN_BAR = 88;    // a side bar narrower than this cannot hold controls
const TOUCH_ATK = 1.42;      // attack is this much bigger than the other buttons
// Lift-and-press-again inside this many ms on the stick counts as a deliberate
// double tap, and runs. Kept short: repositioning a thumb takes longer, and an
// accidental run is worse than a missed one.
const TOUCH_DBL = 260;
// how many button-widths a cluster of five needs, attack and the roll included
const TOUCH_SPAN = TOUCH_ATK + 1 + 0.72 + 1 + 1;

const Touch = {
  built: false, on: false, mode: 'off',
  // st: what the game sees this frame. latch: a tap that started and finished
  // between two ticks, which would otherwise be dropped entirely.
  st: {}, latch: {}, down: {},
  stick: { id: null, ox: 0, oy: 0, dx: 0, dy: 0 },
  dodgeQ: false, seen: false,
  lastZoneDown: 0, tapRun: false,   // a deliberate double tap on the stick
  lastTouchEnd: 0,                  // for killing the browser's double-tap zoom

  // ---- is this a touch device at all -------------------------------------
  capable() {
    return ('ontouchstart' in window) || (navigator.maxTouchPoints || 0) > 0;
  },
  wanted() {
    const pref = SAVE.options.touch || 'auto';
    if (pref === 'off') return false;
    if (pref === 'on') return true;
    return this.capable();
  },

  // ---- build the DOM once ------------------------------------------------
  build() {
    if (this.built) return;
    this.built = true;
    const mk = (tag, id, cls, parent, txt) => {
      const e = document.createElement(tag);
      if (id) e.id = id;
      if (cls) e.className = cls;
      if (txt !== undefined) e.textContent = txt;
      (parent || document.body).appendChild(e);
      return e;
    };
    const root = mk('div', 'tc', null, document.body);
    this.root = root;
    // the stick: a ring that appears where the thumb lands
    this.zone = mk('div', 'tzone', null, root);
    this.ring = mk('div', 'tring', null, root);
    this.knob = mk('div', 'tknob', null, this.ring);
    // the buttons. Order is the order they are laid out in the cluster.
    this.btns = mk('div', 'tbtns', null, root);
    // Listed nearest-thumb first, and the cluster is laid out reversed, so
    // attack ends up in the corner where the thumb rests and back attack -
    // the one you reach for least - ends up furthest away. Roll sits third
    // because it is a panic button: it has to be reachable without looking.
    const B = [
      ['attack', 'ATK', 'b-atk'], ['jump', 'JMP', 'b-jmp'],
      ['dodge', 'ROLL', 'b-dodge'], ['special', 'SP', 'b-sp'],
      ['back', 'BCK', 'b-bck'],
    ];
    this.btnEls = B.map(([act, label, cls]) => {
      const e = mk('div', null, 'tbtn ' + cls, this.btns, label);
      e.dataset.act = act;
      return e;
    });
    this.pause = mk('div', 'tpause', null, root, '❚❚');
    this.pause.dataset.act = 'start';
    this.rot = mk('div', 'trot', null, document.body, 'TURN YOUR PHONE SIDEWAYS');

    // ---- input plumbing --------------------------------------------------
    // Pointer events cover touch and mouse together, and pointerId is what
    // makes two thumbs at once work.
    const stop = e => { e.preventDefault(); };
    root.addEventListener('contextmenu', stop);

    const btnTargets = this.btnEls.concat([this.pause]);
    for (const el of btnTargets) {
      el.addEventListener('pointerdown', e => {
        e.preventDefault();
        this.wake();
        const a = el.dataset.act;
        this.down[e.pointerId] = a;
        this.latch[a] = true;
        if (a === 'dodge') this.dodgeQ = true;
        el.classList.add('lit');
        try { el.setPointerCapture(e.pointerId); } catch (_) {}
      });
      const up = e => {
        const a = this.down[e.pointerId];
        if (a === undefined) return;
        delete this.down[e.pointerId];
        el.classList.remove('lit');
      };
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
    }

    this.zone.addEventListener('pointerdown', e => {
      e.preventDefault();
      this.wake();
      if (this.stick.id !== null) return;
      const now = Date.now();
      this.tapRun = (now - this.lastZoneDown) < TOUCH_DBL;
      this.lastZoneDown = now;
      this.stick.id = e.pointerId;
      this.stick.ox = e.clientX; this.stick.oy = e.clientY;
      this.stick.dx = 0; this.stick.dy = 0;
      this.ring.style.left = e.clientX + 'px';
      this.ring.style.top = e.clientY + 'px';
      this.ring.classList.add('lit');
      this.drawKnob();
      try { this.zone.setPointerCapture(e.pointerId); } catch (_) {}
    });
    this.zone.addEventListener('pointermove', e => {
      if (e.pointerId !== this.stick.id) return;
      e.preventDefault();
      let dx = e.clientX - this.stick.ox, dy = e.clientY - this.stick.oy;
      const m = Math.hypot(dx, dy);
      if (m > TOUCH_R) { dx = dx / m * TOUCH_R; dy = dy / m * TOUCH_R; }
      this.stick.dx = dx; this.stick.dy = dy;
      this.drawKnob();
    });
    const release = e => {
      if (e.pointerId !== this.stick.id) return;
      this.stick.id = null; this.stick.dx = 0; this.stick.dy = 0; this.tapRun = false;
      this.ring.classList.remove('lit');
      this.drawKnob();
    };
    this.zone.addEventListener('pointerup', release);
    this.zone.addEventListener('pointercancel', release);

    this.rot.addEventListener('pointerdown', e => { e.preventDefault(); this.rot.classList.add('gone'); });
    window.addEventListener('orientationchange', () => setTimeout(() => this.layout(), 120));

    // Belt and braces on the double-tap zoom. touch-action in the stylesheet
    // is the real fix, but iOS Safari has historically ignored bits of it, and
    // a page you cannot zoom back out of is the worst possible outcome - so the
    // second tap of a quick pair gets cancelled outright.
    document.addEventListener('touchend', e => {
      if (!this.on) return;
      const now = Date.now();
      if (now - this.lastTouchEnd < 320) e.preventDefault();
      this.lastTouchEnd = now;
    }, { passive: false });
    // Safari's pinch gestures, which are not touch events at all
    for (const g of ['gesturestart', 'gesturechange', 'gestureend']) {
      document.addEventListener(g, e => { if (this.on) e.preventDefault(); }, { passive: false });
    }
    document.addEventListener('dblclick', e => { if (this.on) e.preventDefault(); }, { passive: false });
  },

  // first touch anywhere is also what unlocks audio on iOS
  wake() {
    tryResumeAudio();
    Input.lastDevice = 'touch';
    this.seen = true;
  },
  drawKnob() {
    this.knob.style.transform = `translate(calc(-50% + ${this.stick.dx}px), calc(-50% + ${this.stick.dy}px))`;
  },

  // ---- show / hide and place ---------------------------------------------
  apply() {
    const want = this.wanted();
    if (want) this.build();
    this.on = want;
    if (!this.built) return;
    document.body.classList.toggle('touch', want);
    this.root.style.display = want ? 'block' : 'none';
    if (want) this.layout();
    else this.rot.classList.add('gone');
  },
  // Put the stick and the buttons in whatever dead space the screen has. In
  // landscape on a phone the picture is 16:9-ish and the screen is wider, so
  // there is a bar each side wide enough to hold them without covering
  // anything. A squarer screen has bars top and bottom instead. If neither is
  // big enough the controls go over the picture, translucent, as a fallback.
  layout() {
    if (!this.built || !this.on) return;
    const r = cv.getBoundingClientRect();
    const W2 = window.innerWidth, H2 = window.innerHeight;
    const left = r.left, right = W2 - r.right, below = H2 - r.bottom;
    let mode;
    if (Math.min(left, right) >= TOUCH_MIN_BAR) mode = 'bars';
    else if (below >= 120) mode = 'below';
    else mode = 'over';
    this.mode = mode;
    this.root.dataset.mode = mode;
    // Pause lives top-left in bars mode - the top of the left bar is the only
    // truly empty space, and the first version of this sat straight on top of
    // the attack button.
    this.pause.style.cssText = mode === 'bars'
      ? 'left:6px;top:6px;right:auto'
      : 'right:6px;top:6px;left:auto';

    if (mode === 'bars') {
      // The stick zone reaches a little over the edge of the picture on purpose:
      // thumb reach beats purity, and there is nothing else on the canvas that
      // wants those touches. Only the VISIBLE controls stay clear of the game.
      this.zone.style.cssText = `left:0;top:0;width:${Math.round(r.left + 44)}px;height:100%`;
      // A phone's side bar is about 100px, so the buttons size themselves to it
      // and stack in one column rather than insisting on a two-wide cluster.
      const bar = Math.round(right) - 10;
      const column = bar < 150;
      // Five buttons stacked have to fit the screen AND stay near the bottom
      // corner: anything up by the top edge needs a second hand to reach.
      const reach = Math.min(H2 - 56, 360);
      const size = column
        ? Math.max(40, Math.min(64, Math.floor((reach - 4 * 7) / TOUCH_SPAN), Math.floor((bar - 10) / TOUCH_ATK)))
        : Math.max(44, Math.min(68, Math.floor((bar - 12) / TOUCH_ATK)));
      this.btns.style.cssText = `right:5px;bottom:6px;width:${bar}px`;
      this.setSize(size, column);
    } else if (mode === 'below') {
      const h = Math.round(below);
      this.zone.style.cssText = `left:0;bottom:0;width:38%;height:${h}px`;
      // A row of five has to fit the width it is given, or the last button
      // hangs off the edge - which is exactly what portrait did.
      const aw = Math.round(W2 * 0.60) - 8;
      this.btns.style.cssText = `right:8px;bottom:8px;width:${aw}px`;
      this.setSize(Math.max(38, Math.min(66, Math.floor((aw - 4 * 9) / TOUCH_SPAN), Math.floor((h / 2 - 8) / TOUCH_ATK))), false);
    } else {
      this.zone.style.cssText = 'left:0;top:22%;width:40%;height:78%';
      const aw2 = Math.min(240, Math.round(W2 * 0.56));
      this.btns.style.cssText = `right:6px;bottom:6px;width:${aw2}px`;
      this.setSize(Math.max(38, Math.min(58, Math.floor((aw2 - 4 * 8) / TOUCH_SPAN))), false);
    }
    // portrait is playable but tiny, so say so rather than silently shipping it
    const portrait = H2 > W2 * 1.1;
    if (portrait) this.rot.classList.remove('gone');
    else this.rot.classList.add('gone');
  },

  // Buttons scale to whatever room there is. `column` stacks them vertically,
  // which is what a ~100px phone bar needs.
  // Call this AFTER any style.cssText assignment on #tbtns - cssText replaces
  // the entire inline declaration and would throw these away.
  setSize(px, column) {
    for (const el of this.btnEls) {
      const act = el.dataset.act;
      const wide = act === 'dodge';
      // Attack is the one you hold down for the whole game, so it gets to be
      // noticeably bigger than the rest and sits in the corner.
      const k = act === 'attack' ? TOUCH_ATK : 1;
      const w = wide ? px * 1.15 : px * k;
      const hh = wide ? px * 0.72 : px * k;
      el.style.width = Math.round(w) + 'px';
      el.style.height = Math.round(hh) + 'px';
      el.style.borderRadius = (wide ? Math.round(px * 0.36) : Math.round(w / 2)) + 'px';
      el.style.fontSize = Math.max(9, Math.round(w * 0.21)) + 'px';
    }
    // reversed so the first button in the list is the one nearest the thumb.
    // flex-wrap has to be off: wrapping a reversed column re-orders it.
    this.btns.style.flexWrap = 'nowrap';
    this.btns.style.flexDirection = column ? 'column-reverse' : 'row-reverse';
    this.btns.style.alignItems = column ? 'flex-end' : 'flex-end';
    this.btns.style.gap = (column ? 7 : 10) + 'px';
  },

  // ---- what the game reads ----------------------------------------------
  // Called once per tick from Input.poll(). Returns the flags to OR in, and
  // clears the one-shot latches so a tap counts exactly once.
  take() {
    const s = this.st;
    for (const a of ACTIONS) s[a] = false;
    s.runX = 0; s.dodgeY = 0;
    if (!this.on) return s;

    // buttons: held right now, plus anything tapped since the last tick
    const heldActs = {};
    for (const id in this.down) heldActs[this.down[id]] = true;
    for (const a of ['attack', 'jump', 'special', 'back', 'start']) {
      if (heldActs[a] || this.latch[a]) s[a] = true;
    }

    // stick: direction, and run from how far it is pushed
    const dx = this.stick.dx, dy = this.stick.dy;
    const m = Math.hypot(dx, dy) / TOUCH_R;
    if (m > TOUCH_DEAD) {
      const ax = Math.abs(dx), ay = Math.abs(dy);
      // generous diagonals: a lane change while walking should not need care
      if (ax > ay * 0.45) s[dx < 0 ? 'left' : 'right'] = true;
      if (ay > ax * 0.45) s[dy < 0 ? 'up' : 'down'] = true;
      // Running. Michael asked to keep run on a double tap, and that still
      // works - the stick generates real direction presses, so a flick out and
      // back twice reads as one. But double tapping a stick you are already
      // holding is genuinely awkward, so pushing it to the edge runs as well.
      // run: push it to the edge, OR double tap the stick and push
      if ((m > TOUCH_RUN || this.tapRun) && ax > ay) s.runX = dx < 0 ? -1 : 1;
    }

    // Dodge. The roll wants a direction and the game only rolls when the held
    // direction matches the double tap, so the button supplies both: whichever
    // way the stick is leaning, or toward the camera if it is centred.
    if (this.dodgeQ || heldActs.dodge) {
      const dir = (m > TOUCH_DEAD && Math.abs(dy) > Math.abs(dx) * 0.6) ? (dy < 0 ? -1 : 1) : 1;
      s.dodgeY = dir;
      s[dir < 0 ? 'up' : 'down'] = true;
    }

    for (const k in this.latch) this.latch[k] = false;
    this.dodgeQ = false;
    return s;
  },
};
